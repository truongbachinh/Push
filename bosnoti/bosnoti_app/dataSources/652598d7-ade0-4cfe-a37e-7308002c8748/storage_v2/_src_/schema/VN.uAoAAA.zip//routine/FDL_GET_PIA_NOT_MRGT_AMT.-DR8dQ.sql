create function    fdl_get_pia_not_mrgt_amt
( i_acnt_no        IN     VARCHAR2,
    i_sub_no         IN     VARCHAR2

)  RETURN       NUMBER  AS
    o_pia_amt       number := 0;

/*!
   \file     fdl_get_pia_auto.sql
   \brief    deposit settlement

   \section intro Program Information
        - Program Name              : pia loan not loan_mrgt
        - Service Name              : 04583
        - Related Client Program- Client Program ID : w_04001
        - Related Tables            : dsc01m00, cwd01m00, dlm01m00
                                    : aaa01m00, aaa10m00
        - Dev. Date                 : 2012/11/21
        - Developer                 : thuan
        - Business Logic Desc.      : create pia loan data
        - Latest Modification Date  : 2012/11/21

var o_cnt      number;
var o_err_cnt  number;
exec 2012/11/21('045','20111115','1','045C105599','01','%','Test','Test',:o_cnt,:o_err_cnt);
print o_cnt
print o_err_cnt

*/


    t_vwdate           VARCHAR2(8)   := null;

    t_adj_amt          NUMBER        := 0;


    t_ppre_mth_dt      VARCHAR2(08)  := null;  --

    td_pia_amt         NUMBER        := 0;


    td_lnd_cmsn_amt       NUMBER     := 0;
    td_pay_lnd_cmsn       NUMBER     := 0;
    td_abl_lnd_cmsn       NUMBER     := 0;
    td_lnd_rm_amt         NUMBER     := 0;
    --td_lnd_abl_amt        NUMBER     := 0;
    td_lnd_cmsn_rt        NUMBER     := 0;
    --t_cntr_no             VARCHAR2(8)   := NULL;



BEGIN

    /*========================================================================*/
    /* Input Date CHECK                                                       */
    /*========================================================================*/
    t_vwdate   :=  vn.vwdate;
    --t_pacnt_no :=  'XXXXXXXXXX';


    t_ppre_mth_dt  := vn.fxc_vorderdt_g(to_date(t_vwdate,'yyyymmdd'), -2);


    td_lnd_cmsn_rt  := 0;
    select  vn.fdl_get_lnd_cmsn_rt('10','9999', '1', '1', t_vwdate)
      into  td_lnd_cmsn_rt
      from  dual
    ;
    /*
    begin
        vn.pds_setl_cr_pre_cmsn(t_vwdate , i_acnt_no, i_sub_no, 'Auto_pia', 'Auto_pia');
    end;
    */
    td_pia_amt := 0;

    FOR C2 IN (
       select a.bank_cd
            , a.bank_nm
            , a.mth_dt
            , a.setl_dt
            , a.cdt_tp
            , a.cdt_nm
            , a.mth_amt
            , a.sb_cmsn
            , a.sb_tax
            , a.adj_amt
       from
          (select  bank_cd                            bank_cd
                ,  vn.faa_bank_nm_g(bank_cd)          bank_nm
                ,  mth_dt                             mth_dt
                ,  setl_dt                            setl_dt
                ,  cdt_tp                             cdt_tp
                ,  vn.fxc_tp_nm_g1('cdt_tp',cdt_tp,'V') cdt_nm
                ,  sum(sb_amt)                        mth_amt
                ,  sum(sb_cmsn)                       sb_cmsn
                ,  sum(sb_tax)                        sb_tax
                ,  sum(adj_amt)                       adj_amt
             from  vn.dsc01m00
            where  mth_dt       >=  t_ppre_mth_dt
              and  mth_dt       <  t_vwdate
              and  acnt_no      =  i_acnt_no
              and  sub_no       =  i_sub_no
              and  bank_cd   like  '%'
              and  sb_tp        =  '1'
              and  dpo_setl_yn  =  'N'
              and  mkt_trd_tp  in  ('01','03','05','04','06')
            group  by  mth_dt, bank_cd, setl_dt, cdt_tp
            union
            select  bank_cd                            bank_cd
                ,  vn.faa_bank_nm_g(bank_cd)          bank_nm
                ,  mth_dt                             mth_dt
                ,  setl_dt                            setl_dt
                ,  cdt_tp                             cdt_tp
                ,  vn.fxc_tp_nm_g1('cdt_tp',cdt_tp,'V') cdt_nm
                ,  sum(sb_amt)                        mth_amt
                ,  sum(sb_cmsn)                       sb_cmsn
                ,  sum(sb_tax)                        sb_tax
                ,  sum(adj_amt)                       adj_amt
             from  vn.dsc01m10
            where  mth_dt       =  t_vwdate
              and  acnt_no      =  i_acnt_no
              and  sub_no       =  i_sub_no
              and  bank_cd   like  '%'
              and  sb_tp        =  '1'
              and  dpo_setl_yn  =  'N'
              and  mkt_trd_tp  in  ('01','03','05','04','06')
            group  by  mth_dt, bank_cd, setl_dt, cdt_tp ) a
        order  by  a.mth_dt, a.bank_cd, a.setl_dt, a.cdt_tp
    ) LOOP

        t_adj_amt := C2.adj_amt;

        td_lnd_rm_amt := 0;
        select  nvl(sum(nvl(lnd_amt,0) - nvl(lnd_rpy_amt,0)),0)  lnd_rm_amt
          into  td_lnd_rm_amt
          from  vn.dlm01m20
         where  lnd_tp          =  '10'
           and  acnt_no         =  i_acnt_no
           and  sub_no          =  i_sub_no
           /*and  lnd_dt          =  :ts_vwdate*/
           and  mth_dt          =  C2.mth_dt
           and  expr_dt         =  C2.setl_dt
           and  lnd_bank_cd  like  '%'
           and  cdt_tp          =  C2.cdt_tp
           and  lnd_acpt_tp     =  '01'
           and  cncl_yn         =  'N'
           and  setl_bank_cd   =  C2.bank_cd
        ;

       /* if C2.cdt_tp in ('20','30') then
            td_d0_rpy_amt :=  0;
            td_d1_rpy_amt :=  0;
            td_d2_rpy_amt :=  0;
            td_d3_rpy_amt :=  0;
            td_d0_rpy_int :=  0;
            td_d1_rpy_int :=  0;
            td_d2_rpy_int :=  0;
            td_d3_rpy_int :=  0;
            vn.pdl_mrtg_rpyable_amt ( C2.cdt_tp
                                    , i_acnt_no
                                    , i_sub_no
                                    , '%'
                                    , '%'
                                    , td_d0_rpy_amt,  td_d1_rpy_amt, td_d2_rpy_amt, td_d3_rpy_amt
                                    , td_d0_rpy_int,  td_d1_rpy_int, td_d2_rpy_int, td_d3_rpy_int  );
            if C2.mth_dt = t_vwdate then
                t_adj_amt := t_adj_amt - td_d3_rpy_amt - td_d3_rpy_int;
            elsif C2.mth_dt = t_pre_mth_dt then
                t_adj_amt := t_adj_amt - td_d2_rpy_amt - td_d2_rpy_int;
            elsif C2.mth_dt = t_ppre_mth_dt then
                t_adj_amt := t_adj_amt - td_d1_rpy_amt - td_d1_rpy_int;
            elsif C2.mth_dt = t_pppre_mth_dt then
                t_adj_amt := t_adj_amt - td_d0_rpy_amt - td_d0_rpy_int;
            end if;
        end if;*/

        td_lnd_cmsn_amt :=  0;
        td_pay_lnd_cmsn :=  0;
        td_abl_lnd_cmsn :=  0;
        vn.pdl_get_lnd_cmsn_abl ( '10'
                                 , '9999',  i_acnt_no,  i_sub_no
                                 , t_vwdate    ,  C2.setl_dt
                                 , 0           ,  t_adj_amt
                                 , 0           ,  td_lnd_cmsn_amt    );


        vn.pdl_get_pay_lnd_cmsn ( '10'
                                , '9999',  i_acnt_no,  i_sub_no
                                , C2.mth_dt    ,  C2.setl_dt
                                , t_adj_amt
                                , td_pay_lnd_cmsn,  td_abl_lnd_cmsn  );

        if td_pay_lnd_cmsn = 0 and td_abl_lnd_cmsn = 0 then
            t_adj_amt := t_adj_amt - td_lnd_rm_amt - td_lnd_cmsn_amt;
            if (t_adj_amt  <  0) then
                t_adj_amt := 0;
            end if;

            vn.pxc_log_write('fdl_get_pia_not_mrgt_amt', ' estm_cmsn:'||to_char(td_lnd_cmsn_amt));
            vn.pxc_log_write('fdl_get_pia_not_mrgt_amt', ' lnd_abl_amt:'||to_char(t_adj_amt));
        else
            t_adj_amt := t_adj_amt - td_lnd_rm_amt - td_pay_lnd_cmsn - td_abl_lnd_cmsn ;
            if (t_adj_amt  <  0) then
                t_adj_amt := 0;
            end if;

            vn.pxc_log_write('fdl_get_pia_not_mrgt_amt', ' estm_cmsn:'|| to_char(td_pay_lnd_cmsn + td_abl_lnd_cmsn));
            vn.pxc_log_write('fdl_get_pia_not_mrgt_amt', ' lnd_abl_amt:'||to_char(t_adj_amt));
        end if;

        td_pia_amt := td_pia_amt + t_adj_amt;
    END LOOP;

    o_pia_amt := td_pia_amt;
return o_pia_amt;
end fdl_get_pia_not_mrgt_amt;
/

