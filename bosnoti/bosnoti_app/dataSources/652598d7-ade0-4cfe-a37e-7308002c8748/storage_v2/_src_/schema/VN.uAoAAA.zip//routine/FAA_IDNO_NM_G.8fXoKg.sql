create function faa_idno_nm_g
(
	i_idno		in		varchar2
) return varchar2 as

	o_cust_nm	varchar2(100);


/* ===========================================
	-- Program ID 		: 	faa_idno_nm_g
	-- Date of Program	: 	22/10/2007
	-- Programmer		:	mkkim
	-- Description 		:
			input  :  Id Number
			return : Customer Name
   =========================================== */

begin

	begin
	select	nvl(cust_nm,'!')
	into	o_cust_nm
	from	vn.aaa02m00
	where	idno 	=	i_idno;

		return o_cust_nm;

	exception
	when	 no_data_found then
		return 	'!';
	end;


end ;
/

