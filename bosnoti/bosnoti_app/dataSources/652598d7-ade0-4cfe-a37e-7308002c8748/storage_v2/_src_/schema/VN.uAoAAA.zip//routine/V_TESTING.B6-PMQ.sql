create procedure v_testing (
  ResultSelect   out varchar2) as
begin
      SELECT sysdate
        INTO ResultSelect
			  FROM dual;
end v_testing;
/

