create function fbm_bank_check_bank_stt(i_bank_cd in varchar2)
  return varchar2 as
  o_check_bank varchar2(100);
  t_err_txt    varchar2(100);
  o_check_stt  varchar2(100);

begin

  /*============================================================================*/
  /* º¯¼ö ÃÊ±âÈ­                                                                */
  /*============================================================================*/

  /*============================================================================*/
  /* »ç¿ø¸í Á¶È¸                                                                */
  /*============================================================================*/

  begin
    select 'Y'
      into o_check_bank
      from vn.VW_DRCWDM01 a, vn.cww10m00 b
     where a.BANK_ACC_NUM = i_bank_cd
       and a.BANK_CODE = b.bankcode
       and a.AUTO_PAY_Y_N = 'Y';
  exception
    when NO_DATA_FOUND then
      return 'N';
    when OTHERS then
      t_err_txt := '¿À·ù-[' || to_char(sqlcode) || ']';
      raise_application_error(-20100, t_err_txt);
  end;
  if o_check_bank = 'Y' then
    begin
      select COL_CD_TP
        into o_check_stt
        from XCC01C01
       where col_cd like '%clt_pmt_bhf%';
    exception
      when NO_DATA_FOUND then
        return 'N';
      when OTHERS then
        t_err_txt := '¿À·ù-[' || to_char(sqlcode) || ']';
        raise_application_error(-20100, t_err_txt);
    end;
    if o_check_stt = 'Y' then
      return 'Y';
    else
      return 'N';
    end if;
  else
    return 'N';
  end if;
  return o_check_bank;

end fbm_bank_check_bank_stt;
/

