create FUNCTION    fdl_get_pia_online_acnt_limit
(
    i_acnt_no        in   varchar2,
    i_sub_no         in   varchar2,
    i_dt             in   varchar2
)   RETURN  NUMBER AS

    o_out_number          number    := 0;
    t_onl_acnt_limit      number ;
    t_chk            number    := 1;

begin

    BEGIN --1.Lay tu chinh sach rieng (04599)
        select d1.onl_acnt_limit
            into t_onl_acnt_limit
        from vn.dlm09m51 d1      
        where d1.active_stat = 'Y'
        and d1.acnt_no = i_acnt_no
        and d1.sub_no = i_sub_no
        and d1.apy_dt = ( select max(apy_dt)
                          from dlm09m51
                          where active_stat = 'Y'
                            and acnt_no = i_acnt_no
                            and sub_no = i_sub_no
                            and apy_dt <= i_dt
          );
    EXCEPTION WHEN NO_DATA_FOUND THEN
        t_chk := 0;

    WHEN OTHERS THEN
        vn.pxc_log_write('fdl_get_pia_online_acnt_limit',     'Loi khi lay chinh sach rieng cho han muc online'
                                                    || ' i_acnt_no = '      || i_acnt_no || '-' || ' i_sub_no=' || i_sub_no
                                                    || ' i_dt = '  || i_dt
                        );

        raise_application_error(-20100, ' fdl_get_pia_online_acnt_limit: Loi khi lay chinh sach rieng cho han muc online'
                                                    || ' i_acnt_no = '      || i_acnt_no || '-' || ' i_sub_no=' || i_sub_no
                                                    || ' i_dt = '  || i_dt
                                );
    END;
    if t_onl_acnt_limit is null then
        t_chk := 0;
    end if;

    IF t_chk = 1 THEN
        o_out_number := t_onl_acnt_limit;
    ELSE
        -- 2. Lay chinh sach chung (04598)
        BEGIN
            select  NVL(onl_acnt_limit, 0)
              into  t_onl_acnt_limit
              from  vn.dlm09m50 ;          
        EXCEPTION WHEN OTHERS THEN 
            vn.pxc_log_write('fdl_get_pia_online_acnt_limit',     'Loi khi lay chinh sach rieng cho han muc online :'
                                                    || ' i_acnt_no = '      || i_acnt_no || '-' || ' i_sub_no=' || i_sub_no
                                                    || ' i_dt = '  || i_dt
                            );

            raise_application_error(-20100, ' fdl_get_pia_online_acnt_limit: Loi khi lay chinh sach rieng cho han muc online:'
                                                    || ' i_acnt_no = '      || i_acnt_no || '-' || ' i_sub_no=' || i_sub_no
                                                    || ' i_dt = '  || i_dt
                                    );
        END;

        o_out_number := t_onl_acnt_limit;
    End if;		

    RETURN o_out_number;	

END fdl_get_pia_online_acnt_limit;
/

