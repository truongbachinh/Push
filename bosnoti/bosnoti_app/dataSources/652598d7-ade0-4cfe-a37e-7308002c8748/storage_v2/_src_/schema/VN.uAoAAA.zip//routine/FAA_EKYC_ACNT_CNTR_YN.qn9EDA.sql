create function    faa_ekyc_acnt_cntr_yn(
    i_acnt_no       varchar2
)
return varchar2
/*
    Func is uesed to check if eKYC account has completed the contract or not
*/
as
    t_proc_nm           varchar2(30)    := 'faa_ekyc_acnt_cntr_yn';
    t_ekyc_acnt_yn      varchar2(1)     := null;
    t_has_cntr_yn       varchar2(1)     := null;
    o_ret               varchar2(1)     := 'N';
begin
    -- Check phuong thuc mo TK
    select nvl(ekyc_acnt_yn, 'N') ekyc_acnt_yn
    into t_ekyc_acnt_yn
    from vn.aaa01m00
    where acnt_no = i_acnt_no
    and sub_no = '00';

    -- Neu mo TK mo bang eKYC, can kiem tra trang thai da nhan hop dong hay chua
    if (t_ekyc_acnt_yn = 'Y') then
        select has_cntr_yn
        into t_has_cntr_yn
        from vn.aaa05m00
        where acnt_no = i_acnt_no;

        if (t_has_cntr_yn = 'Y') then
            o_ret := 'Y';
        else
            o_ret := 'N';
            vn.pxc_log_write(t_proc_nm, 'Acnt ' || i_acnt_no
                                        || ' opened via eKYC, but not completed the contract.'
            );
        end if;
    else
        o_ret := 'Y';
    end if;

    return o_ret;

end faa_ekyc_acnt_cntr_yn;
/

