create function    fbm_acnt_revenue_rpt(
    i_user_id           varchar2,       -- User dang nhap
    i_acnt_no           varchar2,       -- STK
    i_sub_no            varchar2,       -- Sub
    i_sub_except_no     varchar2,       -- Except Sub
    i_st_dt             varchar2,       -- Tu ngay
    i_ed_dt             varchar2,       -- Den ngay
    i_brch_cd           varchar2,       -- Ma chi nhanh
    i_agnc_cd           varchar2,       -- Ma phong giao dich
    i_emp_no            varchar2,       -- Nguoi quan ly
    i_acnt_grp_tp_cd    varchar2,       -- Phan loai to chuc / ca nhan
    i_acnt_vip_yn       varchar2,       -- Phan loai tk VIP / thuong
    i_frgn_tp           varchar2,       -- Phan loai trong nuoc / nuoc ngoai
    i_mdm_tp            varchar2        -- Kenh giao dich
)
return sys_refcursor

/* 
    select vn.fbm_acnt_revenue_rpt(
        'lthpt01',          -- i_user_id           varchar2,       -- User dang nhap
        '%',                -- i_acnt_no           varchar2,       -- STK
        '%',                -- i_sub_no            varchar2,       -- Sub
        '!',                -- i_sub_except_no     varchar2,       -- Except Sub
        '20200701',         -- i_st_dt             varchar2,       -- Tu ngay
        '20200707',         -- i_ed_dt             varchar2,       -- Den ngay
        '%',                -- i_brch_cd           varchar2,       -- Ma chi nhanh
        '%',                -- i_agnc_cd           varchar2,       -- Ma phong giao dich
        '%',                -- i_emp_no            varchar2,       -- Nguoi quan ly
        '%',                -- i_acnt_grp_tp_cd    varchar2,       -- Phan loai to chuc / ca nhan
        '%',                -- i_acnt_vip_yn       varchar2,       -- Phan loai tk VIP / thuong
        '%',                -- i_frgn_tp           varchar2,       -- Phan loai trong nuoc / nuoc ngoai
        '%'                 -- i_mdm_tp            varchar2        -- Kenh giao dich
    ) a
    from dual;
*/

is
    t_proc_nm               varchar2(30)    := 'fbm_acnt_revenue_rpt';
    t_vwdate                varchar2(8)     := vn.vwdate;
    t_err_msg               varchar2(500)   := ' ';
    
    t_cursor                sys_refcursor;
    
    t_emp_brch_cd           vn.xca01m01.brch_cd%type;
    t_emp_agnc_brch         vn.xca01m01.agnc_brch%type;
    t_emp_addl_brch_cd      vn.xca01m01.addl_bnh_cd%type;
    t_emp_posi_rt           vn.xca01c01.posi_rt%type;
    
begin
    vn.pxc_log_write(t_proc_nm, '');
    vn.pxc_log_write(t_proc_nm, 'Start '                    || t_proc_nm        || ' for: '
                                || 'i_user_id: '            || i_user_id
                                || ', i_acnt_no: '          || i_acnt_no
                                || ', i_sub_no: '           || i_sub_no
                                || ', i_sub_except_no: '    || i_sub_except_no
                                || ', i_st_dt: '            || i_st_dt
                                || ', i_ed_dt: '            || i_ed_dt
                                || ', i_brch_cd: '          || i_brch_cd
                                || ', i_agnc_cd: '          || i_agnc_cd
                                || ', i_emp_no: '           || i_emp_no
                                || ', i_acnt_grp_tp_cd: '   || i_acnt_grp_tp_cd
                                || ', i_acnt_vip_yn: '      || i_acnt_vip_yn
                                || ', i_frgn_tp: '          || i_frgn_tp
                                || ', i_mdm_tp: '           || i_mdm_tp
                    );
                    
    -- Lay thong tin user thuc hien tra cuu. Cac thong tin nay se duoc dung de check quyen
    begin
        select
            a.brch_cd,
            a.agnc_brch,
            nvl(a.addl_bnh_cd,'999'),
            nvl(b.posi_rt,'N')
        into
            t_emp_brch_cd,
            t_emp_agnc_brch,
            t_emp_addl_brch_cd,
            t_emp_posi_rt
        from vn.xca01m01 a
        inner join vn.xca01c01 b
        on a.posi_cd = b.posi_cd
        where a.emp_no = i_user_id;
    exception
        when others
            then
                t_err_msg  := 'Error when getting employee information: ' || sqlcode || ' - ' || sqlerrm;
                vn.pxc_log_write(t_proc_nm, t_err_msg);
                raise_application_error(-20100,t_err_msg);
    end;
        
    -- Cau lenh chinh de lay du lieu bao cao
    begin
        open t_cursor for
            select 
                acnt_no, sub_no, cust_nm,
                acnt_vip_yn, email, mobile,
                acnt_grp_tp, idno, cntr_no, 
                emp_no, brch_cd_nm, acnt_open_dt, acnt_cls_dt, ctry_nm,
                cash_balance, stk_balance, total_balance, tot_loan, nav,
                tot_sb_amt, revenue, tot_sb_cmsn, pia_lnd_int, mrgn_lnd_int
            from (
                select
                    a01.acnt_no,
                    a01.sub_no,
                    a01.acnt_no || '-' || a01.sub_no                                    acnt_sub_no,
                    a01.cust_nm,
                    case 
                        when a92.acnt_no is not null then 'VIP'
                        else 'Thường'
                    end                                                                 acnt_vip_yn,
                    a21.email,
                    a21.mobile,
                    a02.grp_tp                                                          acnt_grp_tp_cd,
                    vn.fxc_tp_nm_g1('grp_tp', a02.grp_tp, 'V')                          acnt_grp_tp,
                    a01.idno,
                    a01.cntr_no,
                    b01.emp_no                                                          emp_no,
                    a01.acnt_mng_bnh || '.' || a01.agnc_brch                            brch_cd,
                    a01.acnt_mng_bnh || '.' || a01.agnc_brch || '.' || x90.brch_cd_nm   brch_cd_nm,
                    to_char(to_date(a01.acnt_open_dt, 'YYYYMMDD'), 'DD/MM/YYYY')        acnt_open_dt,
                    to_char(to_date(a01.acnt_cls_dt, 'YYYYMMDD'), 'DD/MM/YYYY')         acnt_cls_dt,
                    initcap(a03.ctry_nm)                                                ctry_nm,
                    round(nvl(cw9.cash_balance, 0))                                     cash_balance,
                    round(nvl(cw9.stk_balance, 0))                                      stk_balance,
                    round(nvl(cw9.cash_balance, 0))
                            + round(nvl(cw9.cash_balance, 0))                           total_balance,
                    round(nvl(cw9.tot_loan, 0))                                         tot_loan,
                    round(nvl(cw9.nav, 0))                                              nav,
                    round(nvl(ds1.tot_sb_amt, 0))                                       tot_sb_amt,
                    round(nvl(ds1.tot_sb_cmsn, 0)
                            + nvl(dl1.pia_lnd_int, 0)
                            + nvl(dl1.mrgn_lnd_int, 0))                                 revenue,
                    round(nvl(ds1.tot_sb_cmsn, 0))                                      tot_sb_cmsn,
                    round(nvl(dl1.pia_lnd_int, 0))                                      pia_lnd_int,
                    round(nvl(dl1.mrgn_lnd_int, 0))                                     mrgn_lnd_int
                    
                from 
                    -- account info
                    vn.aaa01m00 a01,
                    vn.aaa02m00 a02,
                    vn.aaa02m10 a21,
                    vn.xcc90m00 x90,
                    vn.aaa03c20 a03,
                    vn.bmi01m00 b01,
                    (
                        select 
                            a9.acnt_no,
                            a9.sub_no
                        from vn.aaa09m20 a9
                        where a9.acnt_no like i_acnt_no
                        and a9.sub_no like i_sub_no
                        and i_ed_dt between a9.apy_dt and a9.cls_dt
                    ) a92,
                    
                    -- real loan + stock balance info
                    (
                        select 
                            acnt_no,
                            sub_no,
                            max(tot_loan)       tot_loan,
                            max(stk_balance)    stk_balance,
                            max(cash_balance)   cash_balance,
                            max(nav)            nav
                        from (
                            select 
                                cm.acnt_no,
                                cm.sub_no,
                                sum(cm.mrgn_loan_nowrm + cm.mrgn_loan_int + cm.dpo_fee_bk)      tot_loan,
                                sum(cm.tot_stk_amt)                                             stk_balance,
                                sum(cm.dpo + cm.reuse_dpo + cm.cdr_amt)                         cash_balance,
                                sum(cm.nav)                                                     nav
                            from vn.cwd99m00 cm
                            where cm.acnt_no like i_acnt_no
                            and cm.sub_no like i_sub_no
                            and cm.sub_no not like i_sub_except_no
                            and t_vwdate = i_ed_dt
                            group by cm.acnt_no, cm.sub_no
                            union all
                            select 
                                ch.acnt_no,
                                ch.sub_no,
                                sum(ch.mrgn_loan_nowrm + ch.mrgn_loan_int + ch.dpo_fee_bk)      tot_loan,
                                sum(ch.tot_stk_amt)                                             stk_balance,
                                sum(ch.dpo + ch.reuse_dpo + ch.cdr_amt)                         cash_balance,
                                sum(ch.nav)                                                     nav
                            from vn.cwd99h00 ch
                            where ch.acnt_no like i_acnt_no
                            and ch.sub_no like i_sub_no
                            and ch.sub_no not like i_sub_except_no
                            and ch.dt = i_ed_dt
                            and t_vwdate > i_ed_dt
                            group by ch.acnt_no, ch.sub_no
                        )
                        group by acnt_no, sub_no
                    ) cw9,
                    
                    -- settlement info
                    (
                        select
                            ds.acnt_no,
                            ds.sub_no,
                            sum(ds.sb_amt) tot_sb_amt,
                            sum(ds.sb_cmsn) tot_sb_cmsn 
                        from vn.dsc01m00 ds
                        where ds.mth_dt between i_st_dt and i_ed_dt
                        and ds.acnt_no like i_acnt_no
                        and ds.sub_no like i_sub_no
                        and ds.sub_no not like i_sub_except_no
                        group by ds.acnt_no, ds.sub_no
                    ) ds1,
                    
                    -- loan info
                    (   
                        select 
                            acnt_no,
                            sub_no,
                            sum(pia_lnd_int) pia_lnd_int,
                            sum(mrgn_lnd_int) mrgn_lnd_int
                        from (
                            select 
                                dl.acnt_no,
                                dl.sub_no,
                                decode(dl.lnd_tp, '10', sum(dl.lnd_int + dl.lnd_int_dly + dl.lnd_cmsn + dl.lnd_cmsn_dly)) pia_lnd_int,
                                decode(dl.lnd_tp, '70', sum(dl.lnd_int + dl.lnd_int_dly + dl.lnd_cmsn + dl.lnd_cmsn_dly)) mrgn_lnd_int
                            from vn.dlm01m10 dl
                            where dl.lnd_rpy_dt between i_st_dt and i_ed_dt
                            and dl.acnt_no like i_acnt_no
                            and dl.sub_no like i_sub_no
                            and dl.sub_no not like i_sub_except_no
                            and dl.lnd_tp in ('70', '10')
                            -- and dl.lnd_amt = dl.lnd_rpy_amt
                            group by dl.acnt_no, dl.sub_no, dl.lnd_tp
                        )
                        group by acnt_no, sub_no
                    ) dl1
                    where a01.idno          = a02.idno(+)
                      and a01.idno          = a21.idno(+)
                      and a01.acnt_mng_bnh  = x90.brch_cd(+)
                      and a02.ctry_cd       = a03.ctry_cd
                      and a01.agnc_brch     = x90.agnc_brch
                      
                      and a01.acnt_no       = b01.acnt_no(+)
                      and a01.sub_no        = b01.sub_no(+)
                      
                      and a01.acnt_no       = a92.acnt_no(+)
                      
                      and a01.acnt_no       = cw9.acnt_no(+)
                      and a01.sub_no        = cw9.sub_no(+)
                      
                      and a01.acnt_no       = ds1.acnt_no(+)
                      and a01.sub_no        = ds1.sub_no(+)
                      
                      and a01.acnt_no       = dl1.acnt_no(+)
                      and a01.sub_no        = dl1.sub_no(+)
                      
                      -- filter
                      and a01.acnt_no           like i_acnt_no
                      and a01.sub_no            like i_sub_no
                      and a01.sub_no        not like i_sub_except_no
                      and a01.acnt_mng_bnh      like i_brch_cd
                      and a01.agnc_brch         like i_agnc_cd
                      and a02.frgn_tp           like i_frgn_tp
                      and (i_acnt_grp_tp_cd        = '%'
                            or a02.grp_tp       like i_acnt_grp_tp_cd
                          )
                      and (i_emp_no           = '%'
                            or b01.emp_no       like i_emp_no
                          )
                      and b01.cls_dtm              = to_date('30000101','yyyymmdd')
                      and (i_acnt_vip_yn           = '%'
                            or (i_acnt_vip_yn = '1' and a92.acnt_no is null)       -- tk thuong
                            or (i_acnt_vip_yn = '2' and a92.acnt_no is not null)   -- tk vip
                           )
                      and substr(a01.acnt_no,4,1) not in ('P', 'E')
                      
                      -- check quyen
                      and (vn.faa_check_emp_no_new(trim(i_user_id), i_mdm_tp, a01.acnt_no, a01.sub_no, 
                                trim(t_emp_brch_cd),
                                trim(t_emp_agnc_brch),
                                trim(t_emp_addl_brch_cd),
                                trim(t_emp_posi_rt),
                                a01.acnt_mng_bnh,
                                a01.agnc_brch
                            ) = 'Y'
                        )
                    order by a01.acnt_no, a01.sub_no
            )
            ;
    exception
        when others then
            t_err_msg  := 'Error when getting main data: ' || sqlcode || ' - ' || sqlerrm;
            vn.pxc_log_write(t_proc_nm, t_err_msg);
            raise_application_error(-20100,t_err_msg);
    end;
    
    return t_cursor;
    
    vn.pxc_log_write(t_proc_nm, 'End.');
    
end fbm_acnt_revenue_rpt;
/

