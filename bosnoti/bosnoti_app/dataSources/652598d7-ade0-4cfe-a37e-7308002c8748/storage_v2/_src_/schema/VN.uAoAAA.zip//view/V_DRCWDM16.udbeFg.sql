create view V_DRCWDM16 as
(SELECT a.bank_fee_grd,
           a.rmrk_cd,
           a.bank_acnt_tp,
           a.fee_calc_tp,
           a.start_date,
           a.end_dt,
           a.work_mn,
           a.work_dtm,
           a.work_trm,
           a.id,
           a.cncl_yn
      FROM drcwdm16 a
     WHERE     a.start_date <= vn.vwdate
           AND a.end_dt >= vn.vwdate
           AND NVL (a.cncl_yn, 'N') <> 'Y')
/

