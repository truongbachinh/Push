create FUNCTION fcw_get_int_rt_cd(i_acnt_no VARCHAR2,
                                             i_sub_no  VARCHAR2,
                                             i_dt      VARCHAR2) RETURN VARCHAR2 AS
  os_int_rt_cd   VARCHAR2(4);
  t_err_msg      VARCHAR2(500);
BEGIN

  -- 1. Kiem tra xem tai khoan nay co dang ky chinh sach rieng khong? neu co thi se lay lai tien gui theo chinh sach rieng
  -- 2. Neu khong co chinh sach rieng thi se lay nhom lai tien gui theo chinh sach chung (theo nhom TK)

  BEGIN
    -- 1. Kiem tra xem tai khoan nay co dang ky chinh sach rieng khong? neu co thi se lay nhom lai theo chinh sach rieng
    SELECT INT_RT_CASH_TP
      INTO os_int_rt_cd
      FROM VN.DLM70M01
     WHERE acnt_no = i_acnt_no
       AND sub_no = i_sub_no
       AND GRP_ACNT_NO = vn.faa_acnt_get_grp_no (I_ACNT_NO, I_SUB_NO,1,VN.Vhdate)
       AND apy_dt IN (SELECT MAX(APY_DT)
                        FROM VN.DLM70M01 D
                       WHERE D.ACNT_NO = I_ACNT_NO
                         AND D.SUB_NO = I_SUB_NO
                         AND D.GRP_ACNT_NO = vn.faa_acnt_get_grp_no (I_ACNT_NO, I_SUB_NO,1,VN.Vhdate)
                         AND D.APY_DT <= I_DT
                         AND D.EXPR_DT >= I_DT
                         AND D.ACTIVE_STAT ='Y')
       AND ACTIVE_STAT ='Y';

  EXCEPTION
    WHEN no_data_found THEN
        -- 2. Neu khong co chinh sach rieng thi se lay phi giao dich theo chinh sach chung (theo nguon)
      BEGIN
        SELECT int_rt_cash_tp
          INTO os_int_rt_cd
          FROM VN.DLM70M00
         WHERE GRP_ACNT_NO = vn.faa_acnt_get_grp_no (I_ACNT_NO, I_SUB_NO,1,VN.Vhdate)
           AND APY_DT = (SELECT MAX(APY_DT)
                           FROM VN.DLM70M00 D
                          WHERE GRP_ACNT_NO = vn.faa_acnt_get_grp_no (I_ACNT_NO, I_SUB_NO,1,VN.Vhdate)
                            AND APY_DT <= I_DT
                            AND EXPR_DT >= I_DT
                            AND ACTIVE_STAT ='Y')
           AND ACTIVE_STAT ='Y';
      END;
    WHEN OTHERS THEN
      t_err_msg := vn.fxc_get_err_msg('V', '8001');
      raise_application_error(-20012,
                              t_err_msg || ' ACNT_NO=' || i_acnt_no || '-' ||
                              i_sub_no);
  END;

  RETURN os_int_rt_cd;

END fcw_get_int_rt_cd;
/

