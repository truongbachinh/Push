create procedure     pxc_cron_xcc10m10_upd
   (
       i_input_date    in   date
   ) is

   ts_holi_tp      varchar2(1) := null;
   ts_sqlcode      number := 0;

begin

   begin
      update vn.xcc10m10 set
         dt_dt = i_input_date - 2
      where base_idx = -2;

   exception
      when others then
         ts_sqlcode := sqlcode;
         raise_application_error(-20100,'error found base_idx -2 ['||ts_sqlcode||']');
   end;

   begin
      update vn.xcc10m10 set
         dt_dt = i_input_date - 1
      where base_idx = -1;

   exception
      when others then
         ts_sqlcode := sqlcode;
         raise_application_error(-20100,'error found base_idx -1 ['||ts_sqlcode||']');
   end;

   begin
      update vn.xcc10m10 set
         dt_dt = i_input_date
      where base_idx = 0;

   exception
      when others then
         ts_sqlcode := sqlcode;
         raise_application_error(-20100,'error found base_idx 0 ['||ts_sqlcode||']');
   end;

   begin
      update vn.xcc10m10 set
         dt_dt = i_input_date + 1
      where base_idx = 1;

   exception
      when others then
         ts_sqlcode := sqlcode;
         raise_application_error(-20100,'error found base_idx 1 ['||ts_sqlcode||']');
   end;

   begin
      update vn.xcc10m10 set
         dt_dt = i_input_date + 2
      where base_idx = 2;

   exception
      when others then
         ts_sqlcode := sqlcode;
         raise_application_error(-20100,'error found base_idx 2 ['||ts_sqlcode||']');
   end;

end pxc_cron_xcc10m10_upd;
/

