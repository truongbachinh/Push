create FUNCTION    fdl_get_lnd_limit(i_acnt_no VARCHAR2,
                                                i_sub_no  VARCHAR2,
                                                i_stk_cd  VARCHAR2,
                                                i_prd_no  VARCHAR2,
                                                i_src_no  VARCHAR2,
                                                i_day_tp  VARCHAR2
												)
  RETURN NUMBER AS

  t_stk_all_lnd_limit  NUMBER := 0;
  t_acnt_all_lnd_limit NUMBER := 0;
  t_acnt_get_grp_no    VARCHAR2(20);
  t_lnd_limit          NUMBER := 0;
-- Neu i_day_tp = '1'- Su dung trong ngay: Co cong them so luong du kien vay (extp) vao so da dung
-- Neu i_day_tp ='2' - Cuoi ngay: Khong cong them so luong du kien vay (extp) vao so da dung
BEGIN
  --Lay ma nhom TK Margin
  t_acnt_get_grp_no := vn.faa_acnt_get_grp_no(i_acnt_no,
                                              i_sub_no,
                                              '2',
                                              vn.vwdate);

  BEGIN

    t_stk_all_lnd_limit := fdl_get_stk_all_lnd_limit(i_acnt_no,
                                                     i_sub_no,
                                                     i_stk_cd,
                                                     i_prd_no,
                                                     i_src_no);

    t_acnt_all_lnd_limit := fdl_get_acnt_all_lnd_limit(i_acnt_no,
                                                       i_sub_no,
                                                       i_src_no,
                                                       i_prd_no,
                                                       t_acnt_get_grp_no,
                                                       i_day_tp); --Trong ngay

  EXCEPTION
    WHEN OTHERS THEN
      t_lnd_limit := 0;
  END;

  /*
  RLL(A,S,S,P,G) = Min[RLL(A,S,P,G),RLL(S,S,P,G)]
  */

  t_lnd_limit := least(t_stk_all_lnd_limit, t_acnt_all_lnd_limit);

  RETURN t_lnd_limit;

END fdl_get_lnd_limit;
/

