create FUNCTION fdl_get_pia_yn(i_acnt_no IN VARCHAR2, --
                                          i_sub_no  IN VARCHAR2)
  RETURN VARCHAR2 AS

  t_vwdate    VARCHAR2(08) := NULL;
  t_mrgn_levl VARCHAR2(02) := NULL;
  t_return    VARCHAR2(01) := NULL;
  t_err_msg   VARCHAR2(500);

BEGIN
  t_return := 'N';

 -- t_mrgn_levl   := vn.fdl_get_mrgn_levl(i_acnt_no, i_sub_no);
  t_mrgn_levl   := vn.faa_acnt_get_grp_no(i_acnt_no, i_sub_no,2,vn.vhdate);
  /* Tai khoan margin khong dung ung truoc tu dong */
  IF t_mrgn_levl IS NULL THEN
    t_return := 'N';
  ELSE
    t_return := 'Y';
  END IF;

  RETURN t_return;

END fdl_get_pia_yn;
/

