create procedure pss_get_tot_cd_qty(
  i_acnt_no   in  varchar,
  i_sub_no    in  varchar,
  i_stk_cd    in  varchar,
  o_tot_qty in out number,
  o_tot_qty_delay in out number
  ) as

begin

	if vn.fsr_chage_rgt_p( i_stk_cd , vn.vwdate ) = 'Y' then -- checking chage stock rights
	   o_tot_qty := 0 ;
       o_tot_qty_delay := 0 ;
    end if ;

	if vn.fss_except_sbst_q( i_stk_cd ) = 'Y' then   -- checking stock status
	   o_tot_qty := 0 ;
       o_tot_qty_delay := 0 ;
    end if ;

    begin
	 select  Greatest( nvl(own_qty      ,0)
		             - nvl(mrtg_lnd_qty ,0)
		             - nvl(mrtg_buy_qty ,0)
					 - nvl(delay_qty    ,0)
					 - nvl(outq_req_qty ,0)
					 - nvl(sb_lim_qty   ,0)
					 - nvl(mov_lim_qty  ,0)  , 0 )

       into  o_tot_qty
       from  vn.ssb01m00
	  where  acnt_no  = i_acnt_no
		and  sub_no   = i_sub_no
	    and  stk_cd   = i_stk_cd ;
    exception
       when others then
		   o_tot_qty := 0 ;
    end  ;


    begin
       select Greatest(nvl(delay_qty,0)-nvl(delay_reg_qty,0),0)

       into  o_tot_qty_delay
       from  vn.ssb01m00
    where  acnt_no  = i_acnt_no
    and  sub_no   = i_sub_no
      and  stk_cd   = i_stk_cd ;
    exception
       when others then
       o_tot_qty_delay := 0 ;
    end  ;

end pss_get_tot_cd_qty;
/

