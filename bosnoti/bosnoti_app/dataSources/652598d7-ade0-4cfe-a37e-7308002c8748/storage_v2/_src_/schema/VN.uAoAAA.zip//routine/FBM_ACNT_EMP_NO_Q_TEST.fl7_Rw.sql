create function fbm_acnt_emp_no_q_test
(
    i_acnt_no   in   varchar2,
    i_sub_no    in   varchar2,
    i_dt        in   varchar2 default vn.vwdate
)
    return          varchar2
as
    o_emp_no    varchar2(100) ;
    t_err_txt       varchar2(100)  ; -- error text buffer

begin

/*============================================================================*/
/* ?? ???                                                                */
/*============================================================================*/
    o_emp_no  :=  NULL;
    t_err_txt :=  NULL;

/*============================================================================*/
/* ???? ??                                                                */
/*============================================================================*/
    begin
    select  emp_no
    into  o_emp_no
    from  vn.bmi01m00
    where acnt_no = i_acnt_no
    and     sub_no = i_sub_no
    and   mng_emp_tp = '1'
    and   i_dt between mng_emp_regi_dt and to_char(cls_dtm, 'yyyymmdd')
    ;
    exception
        when  NO_DATA_FOUND  then
      return  '!';
        when  OTHERS         then
            t_err_txt  :=  '??-['||to_char(sqlcode)||']'||i_acnt_no||i_sub_no;
            raise_application_error (-20100, t_err_txt);
    end;
 vn.pxc_log_write('fbm_acnt_emp_no_q','i_acnt_no  [' || i_acnt_no || ']' );
 vn.pxc_log_write('fbm_acnt_emp_no_q','i_sub_no  [' || i_sub_no || ']' );
 vn.pxc_log_write('fbm_acnt_emp_no_q','o_emp_no  [' || o_emp_no || ']' );

    return  o_emp_no;

end fbm_acnt_emp_no_q_test;
/

