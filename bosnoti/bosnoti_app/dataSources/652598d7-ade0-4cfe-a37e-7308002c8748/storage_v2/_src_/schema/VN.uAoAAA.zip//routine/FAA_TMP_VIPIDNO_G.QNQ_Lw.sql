create function faa_tmp_vipidno_g
(
	i_idno 		in		varchar2
) return varchar2 as

	o_vip_idno 	varchar2(20);
 	t_max_idno varchar2(20);
 	t_max_cnt  number;
/* ===========================================
	-- Program ID 		: 	faa_tmp_vipidno_g
	-- Date of Program	: 	22/10/2007
	-- Programmer		:	mkkim
	-- Description 		:
			input  :  �õ idno
			return :  �ӽ�vip idno
   =========================================== */
begin


	begin
	select max(vip_idno)
	into  t_max_idno
	from vn.aaa90m00
	where idno = i_idno
	and   vip_idno like i_idno||'%'
	and   del_yn ='N';
	exception
	when	 no_data_found then
		return 	i_idno||'_01';
	end;

	if t_max_idno is null then
			return i_idno||'_01';
	else
    	t_max_cnt := to_char(substrb(t_max_idno,lengthb(t_max_idno)-1,2)+1);
	  if  t_max_cnt < 10 then
	      return i_idno||'_0'||to_char(t_max_cnt);
	  else
	  	  return i_idno||'_'||to_char(t_max_cnt);
	  end if;

	end if;
end ;
/

