create procedure pww_sync_vsd_open_date(i_acnt_no varchar2) as

begin

  for c1 in (Select acnt_no, reg_date
               from vn.ww_sync_vsd_open_date
              where nvl(updted_yn, 'N') <> 'Y'
                and acnt_no like i_acnt_no) loop
  
    pxc_log_write('pww_sync_vsd_open_date', c1.acnt_no || c1.reg_date);
    begin
      begin
        update vn.draaam00
           set vsd_open_dtm = c1.reg_date
         where acnt_no = c1.acnt_no;
      exception
        when others then
          pxc_log_write('pww_sync_vsd_open_date', 'error draaam00');
      end;
      begin
        update vn.ww_sync_vsd_open_date
           set updted_yn = 'Y'
         where acnt_no = c1.acnt_no;
      exception
        when others then
          pxc_log_write('pww_sync_vsd_open_date',
                        'error ww_sync_vsd_open_date');
      end;
    exception
      when others then
        update vn.ww_sync_vsd_open_date
           set updted_yn = 'E'
         where acnt_no = c1.acnt_no;
    end;
  end loop;
end pww_sync_vsd_open_date;
/

