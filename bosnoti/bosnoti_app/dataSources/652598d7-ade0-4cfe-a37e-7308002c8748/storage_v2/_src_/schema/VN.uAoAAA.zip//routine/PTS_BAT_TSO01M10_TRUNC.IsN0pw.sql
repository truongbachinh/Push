create procedure pts_bat_tso01m10_trunc (
    i_work_dt       in      varchar2,       -- date(yyyymmdd)
	o_err_code      in      number,         -- error code(0:SUCCESS)
	o_err_msg       in      varchar2,       -- error message
	o_proc_cnt      out     number          -- proc data count
) as

t_err_code      number        := o_err_code;
t_err_msg       varchar2(600) := rtrim(o_err_msg);
t_chk           varchar2(1);
exp_error       exception;

/*!
    \file     pts_bat_tso01m10_trunc
	\brief    tso01m10 table reset

	\section intro Program Information
		- Program Name              : pts_bat_tso01m10_trunc
		- Service Name              :
		- Related Client Program- Client Program ID :
		- Related Tables            : tso01m00
		- Dev. Date                 : 2007/11/27
		- Developer                 : ejlee
		- Business Logic Desc.      :
		- Latest Modification Date  :

	\section history Program Modification History
		- 1.0  2007/11/27

	\section hardcoding Hard-Coding List

	\section info Additional Reference Comments
*/

begin

	t_err_code := 0;
	t_err_msg  := 'SUCCESS';
	t_chk      := 'Y';

	-- 1. �� ��ü��Ϸ��ũ Funüũ

	-- 2. �ֹ�ü�᳻�� ��̺�ʱ�
	if t_chk = 'Y' then
		delete from vn.tso01m10 ;

		o_proc_cnt := SQL%ROWCOUNT;
	else
		t_err_code := -1;
	    t_err_msg  := '�� ��ü��̿Ϸ��ϴ� ü��� � ó����ʽÿ�';
		raise_application_error(-20100,'[pts_bat_tso01m10_trunc] ' || t_err_msg);
	end if;

	exception when  exp_error then
		t_err_code := sqlcode;
		t_err_msg  := sqlerrm;
		raise_application_error(-20100,'[pts_bat_tso01m10_trunc] ' || t_err_msg);

end pts_bat_tso01m10_trunc;
/

