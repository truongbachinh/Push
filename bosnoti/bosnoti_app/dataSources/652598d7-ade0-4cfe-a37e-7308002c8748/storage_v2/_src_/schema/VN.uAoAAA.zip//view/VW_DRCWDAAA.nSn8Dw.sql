create view VW_DRCWDAAA as
select a.BANK_ACC_NUM,a.BANK_CODE
from vn.DRCWDM10 a
where a.CLS_DTM ='30000101'
union
select b.BANK_ACNT_NO,nvl(b.BRANCH,'XXX')
from vn.AAA09M00 b
where b.CLS_DT ='30000101'
/

