create function faa_ifno_idno_nm_g
(
  ifno_idno    in    varchar2
) return varchar2 as

  o_cust_nm varchar2(100);


/* ===========================================
  -- Program ID     :   faa_idno_nm_g
  -- Date of Program  :   22/10/2007
  -- Programmer   : mkkim
  -- Description    :
      input  :  Id Number
      return : Customer Name
   =========================================== */

begin

  begin
  select ifno_idno_nm
  into o_cust_nm
  from (
      select	nvl(cust_nm,'!') as ifno_idno_nm
      from	vn.aaa02m00
      where	idno 	=	ifno_idno
      union
      select nvl(b.emp_nm, '!') as ifno_idno_nm
      from xca01m01 b
      where b.emp_no = ifno_idno
      );

    return o_cust_nm;

  exception
  when   no_data_found then
    return  '!';
  end;


end ;
/

