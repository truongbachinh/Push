create function fcw_bank_knd_tp_q
(
    i_acnt_no   in   varchar2 ,
    i_sub_no    in   varchar2
)
    return          varchar2
as
    o_bank_knd_tp	varchar2(100) ;
    t_err_txt       varchar2(100)  ; -- error text buffer

begin


    o_bank_knd_tp  :=  NULL;


	begin
		select nvl(b.bank_knd_tp,'!')
		  into o_bank_knd_tp
		from vn.aaa01m00 a,
		     vn.cww01h00 b
		where a.acnt_no = i_acnt_no
	    and   a.sub_no  = i_sub_no
		and b.mng_end_dt = to_date('30000101','yyyymmdd')
		and a.bank_cd = b.bank_cd
		and a.bank_cnt_yn = 'Y';
    exception
        when  NO_DATA_FOUND  then
			return  '02';
        when  OTHERS         then
            t_err_txt  :=  '¿À·ù-['||to_char(sqlcode)||']';
            raise_application_error (-20100, t_err_txt);
    end;

    return  o_bank_knd_tp;

end fcw_bank_knd_tp_q;
/

