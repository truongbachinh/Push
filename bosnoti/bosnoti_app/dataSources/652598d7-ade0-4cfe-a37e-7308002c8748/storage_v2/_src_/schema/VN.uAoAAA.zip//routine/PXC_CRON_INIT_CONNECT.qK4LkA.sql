create procedure pxc_cron_init_connect  (

    i_input_dummy    in   varchar2   ) is


t_count NUMBER;
begin

  /*-----------------------------------------*/
  /*        kill sesion loading              */
  /*-----------------------------------------*/
  
  vn.pxc_log_write('pxc_cron_init_connect',' -----------------start ['||to_char(SYSDATE,'yyyymmdd hh24:mm:ss')||']-------------');
  
  SELECT COUNT(*) INTO t_count 
  FROM  vn.xca01h01 
  where  cnnt_end_time is NULL
  AND to_char(WORK_DTM,'yyyymmdd') <> to_char(SYSDATE,'yyyymmdd');
  
  update  vn.xca01h01
  set    cnnt_end_time = sysdate,
        work_mn = 'SYSTEM',
        work_dtm = sysdate,
        work_trm = 'SYSTEM'
  where  cnnt_end_time is NULL
  AND to_char(WORK_DTM,'yyyymmdd') <> to_char(SYSDATE,'yyyymmdd');
  
 vn.pxc_log_write('pxc_cron_init_connect',' clean count sesion :'||t_count||' ');
 vn.pxc_log_write('pxc_cron_init_connect',' -----------------end  ['||to_char(SYSDATE,'yyyymmdd hh24:mm:ss')||']-------------');

end pxc_cron_init_connect;
/

