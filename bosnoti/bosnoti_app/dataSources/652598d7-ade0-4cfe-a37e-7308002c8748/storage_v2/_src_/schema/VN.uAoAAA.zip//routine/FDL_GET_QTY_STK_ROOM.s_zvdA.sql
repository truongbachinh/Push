create function fdl_get_qty_stk_room
(
    i_stk_cd    in   varchar2
)
    return  number
as

    t_lnd_limit_amt number    := 0;
    t_stk_qty_lmit  number    := 0;
    t_lnd_use_qty   number    := 0;
    t_limit_qty     number    := 0;
    t_lnd_use_amt   number    := 0;
    t_lnd_expt_amt  number    := 0;
    t_lnd_expt_qty  number    := 0;
    t_lnd_limit_qty number    := 0;
    t_lnd_limit_qty_vcsc      number    := 0;
    t_lnd_limit_amt_vcsc      number    := 0;
    t_limit_qty_new           number    := 0;
    t_lnd_limit_amt_new       number    := 0;
    t_get_qty_stk_room        number    := 0;

begin

    t_lnd_limit_amt := 0;
    t_stk_qty_lmit  := 0;

    t_lnd_use_qty        := 0;
    t_limit_qty          := 0;
    t_lnd_use_amt        := 0;
    t_lnd_expt_amt       := 0;
    t_lnd_expt_qty       := 0;
    t_lnd_limit_qty      := 0;
    t_lnd_limit_qty_vcsc := 0;
    t_lnd_limit_amt_vcsc := 0;

    t_limit_qty_new      := 0;
    t_lnd_limit_amt_new  := 0;
    t_get_qty_stk_room   := 0;

    select  nvl(a.own_eqt*a.stk_lnd_lmit,0),
            stk_qty_lmit
      into  t_lnd_limit_amt,
            t_stk_qty_lmit
      from  vn.dlm09m30 a
      where a.apy_dt = (select max(b.apy_dt) from vn.dlm09m30 b);

    select  a.lnd_use_qty,
            case
            when vn.fss_get_stk_mkt(a.stk_cd) = '1' then
                nvl(b.list_stk_qty,0)
            when vn.fss_get_stk_mkt(a.stk_cd) = '2' then
                nvl(d.list_stk_qty,0)
            when vn.fss_get_stk_mkt(a.stk_cd) = '4' then
                nvl(e.list_stk_qty,0)
            end,
            a.lnd_use_amt,
            a.lnd_expt_amt,
            a.lnd_expt_qty,
            case
            when vn.fss_get_stk_mkt(a.stk_cd) = '1' then
                nvl(t_stk_qty_lmit*b.list_stk_qty,0)
            when vn.fss_get_stk_mkt(a.stk_cd) = '2' then
                nvl(t_stk_qty_lmit*d.list_stk_qty,0)
            when vn.fss_get_stk_mkt(a.stk_cd) = '4' then
                nvl(t_stk_qty_lmit*e.list_stk_qty,0)
            end,
            c.lmt_lnd_room_qty lmt_num_qty,
            c.lmt_lnd_room_amt lmt_loan_qty
      into  t_lnd_use_qty        ,
            t_limit_qty          ,
            t_lnd_use_amt        ,
            t_lnd_expt_amt       ,
            t_lnd_expt_qty       ,
            t_lnd_limit_qty      ,
            t_lnd_limit_qty_vcsc ,
            t_lnd_limit_amt_vcsc
      from  vn.dlm09m11 a, vn.ssi01m00 b, vn.ssi07m00 c, vn.ssi03m00 d, vn.ssi03m10 e
      where  a.stk_cd   like  i_stk_cd
      and	a.stk_cd 	=	b.stk_cd
      and	a.stk_cd	=	d.stk_cd(+)
      and	a.stk_cd	=	e.stk_cd(+)
      and   a.stk_cd	=	c.stk_cd
      and   vn.fss_get_stk_mkt(a.stk_cd) <> '3'
      and   a.stk_cd in (select t.stk_cd from vn.ssi01m00 t where t.cd_rate > 0
                         union
                         select t.stk_cd from vn.ssi08m00 t where t.cd_rate > 0)  ;

    if t_lnd_limit_qty_vcsc = 0 then
       t_limit_qty_new := t_lnd_limit_qty;
    else
       t_limit_qty_new := t_lnd_limit_qty_vcsc;
    end if;

    if t_lnd_limit_qty > t_limit_qty_new then
       t_get_qty_stk_room := t_limit_qty_new -  ( t_lnd_use_qty +  t_lnd_expt_qty );
    else
       t_get_qty_stk_room := t_lnd_limit_qty -  ( t_lnd_use_qty +  t_lnd_expt_qty );
    end if;

    return t_get_qty_stk_room;

end fdl_get_qty_stk_room;
/

