create PROCEDURE pxc_batch_sms
   (
       in_sec_cd            IN    VARCHAR2,
       in_phone_number      IN    VARCHAR2, -- list of phone number, separate by ","
       in_batch_status      IN    VARCHAR2  -- status of running batch: 0 - didn't run or fail
                                            --                          1 - success
   ) is

   start_pos          number         := 1;
   end_pos            number;
   delim              varchar2(1)    := ',';
   phone_number       varchar2(20);
   the_index          number         := 1;
   send_phone_no      varchar2(20)   := '84439368866';
   work_tp_a          varchar2(3)    := '999';
   work_tp_b          varchar2(1)    := '';
   sms_msg            varchar2(100)  := '';
   work_mn            varchar2(10)   := 'BATCH_SMS';
   work_trm           varchar2(10)   := ' ';
   t_temp             varchar2(10)	 := ' ';

BEGIN

     vn.pxc_log_write('pxc_batch_sms','in_phone_number -['||in_phone_number||']');
     vn.pxc_log_write('pxc_batch_sms','in_batch_status -['||in_batch_status||']');

   select vn.fxc_holi_ck(vn.wdate)
	  into t_temp
	  from dual;

	if t_temp = '0' then
		vn.pxc_log_write('pxc_batch_sms', 'The working day is OK');
	else
		vn.pxc_log_write('pxc_batch_sms', 'Today is not working day');
		raise_application_error (-20100, 'Today is not working day');
	end if;

   -- Begin in_batch_status = 0
	 if vn.fxb_daily_stat_chk ('J','1','5300','5300','*') <> 'Y' then
	   sms_msg := 'BatchJob chua ket thuc. De nghi check lai voi nhan vien nghiep vu!!!';
	 else
	   return ;--sms_msg := 'BatchJob da ket thuc binh thuong! Have a good night ^.^';
	 end if;
   -- End in_batch_status = 0
   sms_msg := in_sec_cd || ' - ' || sms_msg;

   vn.pxc_log_write('pxc_batch_sms', sms_msg);

   while start_pos > 0
   loop

     end_pos := instr(in_phone_number, delim, start_pos, 1);

     if end_pos = 0 then
         phone_number := substr(in_phone_number, start_pos);
     else
         phone_number := substr(in_phone_number, start_pos, end_pos - start_pos);
     end if;

     -- insert to sms table for each phone number
     vn.pxc_sms_ins (to_char(sysdate, 'yyyymmddhh24miss'), phone_number, send_phone_no, work_tp_a, work_tp_b, sms_msg, work_mn, work_trm);

     the_index := the_index + 1;

     start_pos := instr(in_phone_number, delim, 1, the_index - 1);
     if start_pos = 0 then
         exit;
     else
         start_pos := start_pos + length(delim);
     end if;

   end loop;

   vn.pxc_log_write('pxc_batch_sms','sms_msg -['||sms_msg||']');

   EXCEPTION
   WHEN OTHERS THEN
        vn.pxc_log_write('pxc_batch_sms','error -['||sqlerrm||']');


END pxc_batch_sms;
/

