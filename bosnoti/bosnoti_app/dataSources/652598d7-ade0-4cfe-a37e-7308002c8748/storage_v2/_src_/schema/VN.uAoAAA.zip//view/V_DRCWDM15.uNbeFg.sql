create view V_DRCWDM15 as
(SELECT a.bank_fee_grd,
           a.fee_lv,
           a.match,
           a.fee_tp,
           a.min_amt,
           a.max_amt,
           a.min_fee,
           a.max_fee,
           a.int_rt,
           a.strt_dt,
           a.end_dt,
           a.work_mn,
           a.work_dtm,
           a.work_trm,
           a.id,
           a.cncl_yn
      FROM drcwdm15 a
     WHERE     a.strt_dt <= vn.vwdate
           AND a.end_dt >= vn.vwdate
           AND NVL (a.cncl_yn, 'N') <> 'Y')
/

