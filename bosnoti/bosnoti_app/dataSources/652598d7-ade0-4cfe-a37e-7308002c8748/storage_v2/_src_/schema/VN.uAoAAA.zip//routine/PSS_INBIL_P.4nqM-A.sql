create PROCEDURE pss_inbil_p
(   is_trd_dt			in		varchar2,			--
	is_work_bnh			in		varchar2,			--
	is_detl_trd_tp		in		varchar2,			-- rights is only 5
	is_acnt_no			in		varchar2,			--
	is_sub_no			in		varchar2,			--
	is_stk_cd			in		varchar2,			--
	is_stk_nm			in		varchar2,			--
	is_sb_qty			in		varchar2,			--
	is_sb_pri			in		varchar2,			--
	is_apy_dt			in		varchar2,			--  
	is_anth_cd			in		varchar2,			--
	is_anth_acnt_no		in		varchar2,			--
	is_cnte				in		varchar2,			--
	is_rmrk_cd			in		varchar2,			--
	is_work_mn			in		varchar2,			--
	is_work_trm			in		varchar2,			--
	is_dept_no2			in		varchar2,

	os_trd_seq_no		out		varchar2,				--
	os_bil_prerm_qty	out		varchar2,				--
	os_bil_nowrm_qty	out		varchar2				--
) AS

   	tn_cnt					number	:= 0;
   	tn_trd_seq_no			number	:= 0;			--
   	tn_tot_trd_seq_no			number	:= 0;			--

	tn_bil_prerm_qty		number	:= 0;			--
	tn_tot_bil_prerm_qty    number  := 0;
	tn_tot_bil_nowrm_qty    number  := 0;
	tn_sb_pri				number	:= 0;			--
	tn_sb_qty				number	:= 0;			--

	ts_stk_tp				varchar2(2)		:= '';
	ts_step					varchar2(10)	:= '';
	ts_msg					varchar2(1000)	:= '';
	ts_code					varchar2(4)		:= '';

    ts_acnt_tp              varchar2(2)     := '';
	ts_trd_tp               varchar2(3)     := '';

	t_rtn_val               varchar2(1)     := '';
    t_err_txt               varchar2(200);
    t_err_msg               varchar2(500);
	o_cnt    				number	:= 0;			--

    vn_count                number   := 0;
    vn_bank_cd              varchar2(4); -- NHSV-839

	ERR_RTN					EXCEPTION;
/* *********************************** Log changes ***********************************
05-Dec-2018 vnjvthangnm NHSV-839
*********************************************************************************** */
begin

    IF	is_sb_qty = 0	THEN
    	os_trd_seq_no := NULL;
    	os_bil_prerm_qty := NULL;
    	os_bil_nowrm_qty := NULL;
    	return;
    END IF;

    ts_step := '1';

    /*** check closing ***/

    t_rtn_val := 'Y';

	vn.pxc_log_write('pss_inbil_p','is_acnt_no ['|| is_acnt_no ||']');
	vn.pxc_log_write('pss_inbil_p','is_acnt_no ['|| is_sub_no ||']');
    vn.pxc_log_write('pss_inbil_p','is_work_mn ['|| is_work_mn ||']');

    if  is_work_mn  not in ('DAILY','BATCH') then

        vn.pbm_cls_yn_q(  vn.vhdate
                       ,  vn.fbm_emp_bnh_q(     is_work_mn)
                       ,  vn.faa_acnt_bnh_cd_g('0',is_acnt_no, is_sub_no)
                       , '1'
                       ,  t_rtn_val
                       ,  t_err_txt
                       );

        if  t_rtn_val  !=  'N' then
            t_err_msg := vn.fxc_get_err_msg('V','2716');
            raise_application_error(-20100,t_err_msg||t_err_txt);
        end if;

    end if;

    /* Get bank code */
    select bank_cd
    into vn_bank_cd
    from aaa01m00
    where acnt_no = trim(is_acnt_no)
    and sub_no = trim(is_sub_no)
    and acnt_stat = '1'; -- active status

    vn.pxc_psb_seq_cret_p (is_acnt_no, is_sub_no,  is_trd_dt, tn_trd_seq_no, tn_tot_trd_seq_no);  	-- vn.pxc_log_write('pss_inbil_p', '@@@@@@@@');

    --
    IF 	nvl(to_number(is_sb_pri), 0) = 0	THEN
    	ts_step := '3';
    	tn_sb_pri := vn.fss_get_pd_cls_pri( is_stk_cd);

    	IF	tn_sb_pri = 0	THEN
    	    tn_sb_pri := vn.fss_get_fac_pri( is_stk_cd);
    	END IF;
    ELSE
    	tn_sb_pri := to_number(is_sb_pri);
    END IF;

    IF	tn_sb_pri <= 0	THEN
    	ts_code := '9412';
      	ts_msg := '9412';
    	raise ERR_RTN;
    END IF;

	IF is_rmrk_cd in ('205', '206') THEN

	   tn_sb_pri := 0;

    END IF;


    --
    tn_sb_qty := to_number(is_sb_qty);

   	--
 	BEGIN
 		ts_step := '4';
 		SELECT	nvl(own_qty, 0)
	   	  INTO	tn_bil_prerm_qty
	   	  FROM	vn.ssb01m00
	   	 WHERE	acnt_no = is_acnt_no
		   AND  sub_no  = is_sub_no
	   	   AND	stk_cd = is_stk_cd;

		tn_cnt := 1;

		EXCEPTION
				WHEN NO_DATA_FOUND	THEN
					tn_cnt := 0;
					tn_bil_prerm_qty := 0;
	END;

	ts_step := '4.5';
	ts_stk_tp := vn.fss_get_stk_tp( is_stk_cd);

/***** trd_tp *************************************/

  ts_acnt_tp :=   vn.faa_get_acnt_tp( is_acnt_no, is_sub_no ) ;

  if ts_acnt_tp    = '1' then  --  custodian
     ts_trd_tp :=  '20' ;
  elsif ts_acnt_tp = '2' then  -- bank_connect
     ts_trd_tp :=  '22' ;
  elsif ts_acnt_tp = '3' then  -- non-custodian
     ts_trd_tp :=  '24' ;
  end if ;

  tn_tot_bil_prerm_qty := vn.fss_get_tot_prerm_qty(is_acnt_no, is_stk_cd);
  tn_tot_bil_nowrm_qty := tn_tot_bil_prerm_qty + tn_sb_qty;
	--
	ts_step := '5';
	INSERT INTO vn.aaa10m00 ( 	 acnt_no			--
								,sub_no				--
								,trd_dt				--
								,tot_trd_seq_no			--
								,trd_seq_no			--
								,trd_tp				--
								,rmrk_cd			--
								,mdm_tp				--
								,trd_mdm_tp			--
								,cncl_yn			--
								,org_trd_no			--
								,trd_amt			--
								,cmsn				--
								,adj_amt			--
								,dpo_prerm			--
								,dpo_nowrm			--
								,stk_cd				--
								,stk_nm				--
								,sb_pri				--
								,sb_qty				--
								,bil_prerm_qty		--
								,bil_nowrm_qty		--
								,tot_bil_prerm		--
								,tot_bil_nowrm		--
								,book_amt			--
								,stk_tp				--
								,mth_dt				--
								,lnd_tp				--
								,lnd_dt				--
								,lnd_int			--
								,agnt_yn			--
								,acnt_mng_bnh		--
								,work_bnh			--
								,work_mn			--
								,work_dtm			--
								,work_trm			--
								,anth_cd
								,anth_acnt_no
								,agnc_brch
								,proc_agnc_brch
								,cnte
                ,bank_cd      -- NHSV-839
				)	VALUES	(	 is_acnt_no				-- acnt_no
								,is_sub_no				-- trd_dt
								,is_trd_dt				-- trd_dt
								,tn_tot_trd_seq_no			-- trd_seq_no
								,tn_trd_seq_no			-- trd_seq_no
								,ts_trd_tp				-- trd_tp
								,decode(is_detl_trd_tp, '1', '202', '2', '203', '3', '201', '4', '211', '5', is_rmrk_cd)	-- rmrk_cd
								,'00'					-- mdm_tp
								,'99'					-- trd_mdm_tp
								,'N'					-- cncl_yn
								,0						-- org_trd_no
								,0						-- trd_amt
								,0						-- cmsn
								,0						-- adj_amt
								,0						-- dpo_prerm
								,0						-- dpo_nowrm
								,is_stk_cd				-- stk_cd
								,is_stk_nm				-- stk_nm
								,tn_sb_pri				-- sb_pri
								,tn_sb_qty				-- sb_qty
								,tn_bil_prerm_qty		-- bil_prerm_qty
								,tn_bil_prerm_qty + tn_sb_qty				-- bil_nowrm_qty
								,tn_tot_bil_prerm_qty
								,tn_tot_bil_nowrm_qty
								,tn_sb_qty * tn_sb_pri						-- book_amt
								,ts_stk_tp				-- stk_tp
								,is_trd_dt				-- mth_dt
								,null					-- lnd_tp
								,null					-- lnd_dt
								,null					-- lnd_int
								,'N'					-- agnt_yn
								,vn.faa_acnt_bnh_cd_g( '0', is_acnt_no, is_sub_no)			-- acnt_mng_bnh
								,is_work_bnh			-- work_bnh
								,is_work_mn				-- work_mn
								,sysdate				-- work_dtm
								,is_work_trm			-- work_trm
								,is_anth_cd
								,is_anth_acnt_no
								,vn.faa_acnt_bnh_cd_g( '3', is_acnt_no, is_sub_no)
								,is_dept_no2
								,is_cnte
                ,vn_bank_cd   -- NHSV-839
							);

	--
  	IF	tn_cnt > 0	THEN
		ts_step := '6';
		UPDATE	vn.ssb01m00
		   SET	own_qty = own_qty + tn_sb_qty
		   	   ,book_amt = book_amt + (tn_sb_qty * tn_sb_pri)
		   	   ,work_mn = is_work_mn
		   	   ,work_dtm = sysdate
		   	   ,work_trm = is_work_trm
		 WHERE	acnt_no = is_acnt_no
		   AND  sub_no  = is_sub_no
		   AND	stk_cd = is_stk_cd;
	ELSE
		ts_step := '7';
		INSERT INTO vn.ssb01m00 ( 	 acnt_no			--
									,sub_no				--
									,stk_cd				--
									,own_qty			--
									,book_amt			--
									,bclm_qty			--
									,mrtg_lnd_qty		--
									,work_mn			--
									,work_dtm			--
									,work_trm			--
									,stk_tp
					)	VALUES	(	 is_acnt_no			-- acnt_no
									,is_sub_no			-- stk_cd
									,is_stk_cd			-- stk_cd
									,tn_sb_qty					-- own_qty
									,tn_sb_qty * tn_sb_pri		-- book_amt
									,0					-- bclm_qty
									,0					-- mrtg_lnd_qty
									,is_work_mn			-- work_mn
									,sysdate			-- work_dtm
									,is_work_trm		-- work_trm
									,ts_stk_tp
								);
	END IF;

    /*******************************/
    /* call evaluation for margin  */
    /*******************************/
  if is_apy_dt > vn.vwdate then
    begin
     update  vn.ssb01m00
        set  delay_qty = delay_qty + tn_sb_qty
      where  acnt_no   = is_acnt_no
		and  sub_no    = is_sub_no
        and  stk_cd    = is_stk_cd   ;
    exception
    when others then
       t_err_txt  :=   ' ssb01m00 update error ';
       t_err_msg  :=   vn.fxc_get_err_msg('V','2023');
	   raise_application_error(-20100,t_err_msg||t_err_txt);
    end ;
  end if ;
    vn.pdl_crd_loan_rt_proc_td
        (is_trd_dt
        ,'2' -- stock
        ,is_acnt_no
        ,is_sub_no
        ,tn_trd_seq_no
        ,is_work_mn
        ,is_work_trm
        ,o_cnt
       );

    vn.pxc_log_write('pss_inbil_p','pdl_crd_loan_rt_proc_td ['|| o_cnt ||']');


	/* out parametres */
	ts_step := '17';
	os_trd_seq_no 		:= to_char(tn_trd_seq_no);								--
	os_bil_prerm_qty	:= to_char(tn_bil_prerm_qty);							--
	os_bil_nowrm_qty	:= to_char(tn_bil_prerm_qty + tn_sb_qty);				--

	RETURN;

	EXCEPTION
			WHEN 	ERR_RTN	THEN
			     	raise_application_error(-20100, ts_code || ':[pss_inbil_p ' || ts_step || '] ' || ts_msg);
					RETURN;

			WHEN	NO_DATA_FOUND	THEN
					raise_application_error(-20200, '[pss_inbil_p ' || ts_step || '] ' || SQLERRM);
					RETURN;

			WHEN	OTHERS	THEN
					raise_application_error(-20300, '[pss_inbil_p ' || ts_step || '] ' || SQLERRM);
			        RETURN;

END pss_inbil_p;
/

