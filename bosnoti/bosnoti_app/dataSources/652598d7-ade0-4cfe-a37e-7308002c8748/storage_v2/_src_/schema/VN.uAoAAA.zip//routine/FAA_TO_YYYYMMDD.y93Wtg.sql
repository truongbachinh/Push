create function faa_to_yyyymmdd
(
	i_dt		in		varchar2
) return varchar2 as

	o_ddmmyyyy	varchar2(8);

/* ===========================================
	-- Program ID 		: 	faa_to_yyyymmdd
	-- Date of Program	: 	22/10/2007
	-- Programmer		:	mkkim
	-- Description 		:
			input  :  yyyymmdd
			return :  ddmmyyyy
   =========================================== */

begin
		if lengthb(i_dt) = 8 then  -- ddmmyyyy -> yyyymmdd
			return	substr(i_dt,5,4)||substr(i_dt,3,2)||substr(i_dt,1,2);
		elsif lengthb(i_dt) = 6 then  --mmyyyy   -> yyyymm
			return	substr(i_dt,3,6)||substr(i_dt,1,2);
		else
			return ' ';
		end if;
end ;
/

