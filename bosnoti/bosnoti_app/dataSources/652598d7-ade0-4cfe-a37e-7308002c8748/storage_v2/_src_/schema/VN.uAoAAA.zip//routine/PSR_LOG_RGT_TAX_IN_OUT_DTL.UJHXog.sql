create procedure psr_log_rgt_tax_in_out_dtl(
    i_acnt_no               varchar2,
    i_sub_no                varchar2,
    i_stk_cd                varchar2,
    i_trd_tp                varchar2,
    -- i_ord_no                varchar2,
    i_out_dt                varchar2,
    i_setl_dt               varchar2,
    -- i_setl_frct_seq_no      number,
    i_out_qty               number,
    -- i_out_pri               number,
    i_out_amt               number,
    i_rgt_tax_qty           number,
    i_rgt_tax_pri           number,
    i_rgt_tax_rt            number,
    i_rgt_tax_amt           number,
    i_work_mn               varchar2,
    i_work_trm              varchar2
)
as
    t_proc_nm               varchar2(30)    := 'psr_log_rgt_tax_in_out_dtl';
    t_err_msg               varchar2(500)   := null;
    t_err_msg_log           varchar2(500)   := null;
    t_vwdate                varchar2(8)     := vn.vwdate();
    t_sec_cd                varchar2(3)     := null;

    t_rem_rgt_tax_qty       number          := 0;           -- SL co tuc con lai chua xu ly
begin
    vn.pxc_log_write(t_proc_nm, '');
    vn.pxc_log_write(t_proc_nm, 'Start '                    || t_proc_nm        || ' for: '
                                || ' i_acnt_no: '           || i_acnt_no
                                || ', i_sub_no: '           || i_sub_no
                                || ', i_stk_cd: '           || i_stk_cd
    );

    t_sec_cd := vn.fxc_sec_cd('R');
    t_rem_rgt_tax_qty := i_rgt_tax_qty;

    -- Neu nghiep vu ban
    if (i_trd_tp = '1') then
        for c1 in (
            select
                s2.rowid                s2_rowid,
                s2.rgt_std_dt,
                s2.acnt_no,
                s2.sub_no,
                s2.rgt_tp,
                s2.stk_cd,
                s2.seq_no               rgt_seq_no,
                s2.asn_qty,
                s2.rem_rgt_tax_qty,
                s1.apy_dt
            from vn.srr02m00 s2
            inner join vn.srr01m00 s1
            on
                s2.rgt_std_dt = s1.rgt_std_dt
            and s2.stk_cd = s1.stk_cd
            and s2.rgt_tp = s1.rgt_tp
            and s2.seq_no = s1.seq_no
            where
                s2.acnt_no = i_acnt_no
            and s2.sub_no = i_sub_no
            and s2.stk_cd = i_stk_cd
            and s2.rgt_tp in ('2','3')
            and s2.asn_qty > 0
            and s1.rgt_proc_stat >= '5'
            and s1.apy_dt >= '20201205'     -- Ngay dau tien ap dung thue co tuc
            and s1.apy_dt <= i_out_dt
            order by
                s2.acnt_no,
                s2.sub_no,
                s2.stk_cd,
                s1.apy_dt,
                s2.rgt_std_dt,
                s2.rgt_tp
        ) loop
            vn.pxc_log_write(t_proc_nm, 'Start the loop'                || t_proc_nm        || ' for: '
                                        || ' c1.rgt_std_dt: '           || c1.rgt_std_dt
                                        || ' c1.apy_dt: '               || c1.apy_dt
                                        || ', c1.rgt_seq_no: '          || c1.rgt_seq_no
                                        || ', c1.rem_rgt_tax_qty: '     || c1.rem_rgt_tax_qty
            );
            -- Update SL co tuc con lai chua thu thue tren srr02m00
            begin
                vn.pxc_log_write(t_proc_nm, 'Update srr02m00');

                update vn.srr02m00
                set
                    rem_rgt_tax_qty = greatest(0, c1.rem_rgt_tax_qty - t_rem_rgt_tax_qty),
                    work_mn         = i_work_mn,
                    work_trm        = i_work_trm,
                    work_dtm        = sysdate
                where rowid = c1.s2_rowid
                ;
            exception
                when others then
                    t_err_msg       := vn.fxc_get_err_msg('V','2147');
                    t_err_msg_log   := t_err_msg || '. Error when updating srr02m00. '
                                                 || sqlcode || ' - ' || sqlerrm;
                    t_err_msg       := t_err_msg || ' acnt_no: ' || c1.acnt_no || '-' || c1.sub_no || ', stk_cd: ' || c1.stk_cd;

                    vn.pxc_log_write(t_proc_nm, t_err_msg_log);
                    raise_application_error(-20100, t_err_msg);
            end;

            -- Insert vao bang lich su
            begin
                vn.pxc_log_write(t_proc_nm, 'insert srr08m00');

                insert into vn.srr08m00(
                    acnt_no,
                    sub_no,
                    rgt_std_dt,
                    rgt_tp,
                    stk_cd,
                    rgt_seq_no,
                    org_rgt_qty,
                    rem_rgt_qty,
                    rgt_apy_dt,
                    trd_tp,
                    -- ord_no,
                    out_dt,
                    setl_dt,
                    -- setl_frct_seq_no,
                    out_qty,
                    -- out_pri,
                    out_amt,
                    rgt_tax_qty,
                    rgt_tax_pri,
                    rgt_tax_rt,
                    rgt_tax_amt,
                    work_mn,
                    work_dtm,
                    work_trm
                )
                select
                    i_acnt_no                                               acnt_no,
                    i_sub_no                                                sub_no,
                    c1.rgt_std_dt                                           rgt_std_dt,
                    c1.rgt_tp                                               rgt_tp,
                    i_stk_cd                                                stk_cd,
                    c1.rgt_seq_no                                           rgt_seq_no,
                    c1.rem_rgt_tax_qty                                      org_rgt_qty,
                    greatest(0, c1.rem_rgt_tax_qty - t_rem_rgt_tax_qty)     rem_rgt_qty,
                    c1.apy_dt                                               rgt_apy_dt,
                    i_trd_tp                                                trd_tp,
                    -- i_ord_no                                                ord_no,
                    i_out_dt                                                out_dt,
                    i_setl_dt                                               setl_dt,
                    -- i_setl_frct_seq_no                                      setl_frct_seq_no,
                    i_out_qty                                               out_qty,
                    -- i_out_pri                                               out_pri,
                    i_out_amt                                               out_amt,
                    i_rgt_tax_qty                                           rgt_tax_aty,
                    i_rgt_tax_pri                                           rgt_tax_pri,
                    i_rgt_tax_rt                                            rgt_tax_rt,
                    i_rgt_tax_amt                                           rgt_tax_amt,
                    i_work_mn                                               work_mn,
                    sysdate                                                 work_dtm,
                    i_work_trm                                              work_trm
                from dual;
            exception
                when others then
                    t_err_msg       := vn.fxc_get_err_msg('V','2147');
                    t_err_msg_log   := t_err_msg || '. Error when insertint srr08m00. '
                                                 || sqlcode || ' - ' || sqlerrm;
                    t_err_msg       := t_err_msg || ' acnt_no: ' || c1.acnt_no || '-' || c1.sub_no || ', stk_cd: ' || c1.stk_cd;

                    vn.pxc_log_write(t_proc_nm, t_err_msg_log);
                    raise_application_error(-20100, t_err_msg);
            end;

            -- Tinh toan lai SL co tuc can thu thue cho vong loop tiep theo
            t_rem_rgt_tax_qty := greatest(0, t_rem_rgt_tax_qty - c1.rem_rgt_tax_qty);
            vn.pxc_log_write(t_proc_nm, 'New t_rem_rgt_tax_qty for the next iteration: ' || t_rem_rgt_tax_qty);

            if(t_rem_rgt_tax_qty = 0) then
                vn.pxc_log_write(t_proc_nm, 't_rem_rgt_tax_qty = 0. End the loop');
                return;
            end if;

        end loop;
    else
        vn.pxc_log_write(t_proc_nm, 'There is no logic for i_trd_tp = ' || i_trd_tp);
    end if;

    vn.pxc_log_write(t_proc_nm, 'End');
end psr_log_rgt_tax_in_out_dtl;
/

