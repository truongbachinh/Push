create procedure pxb_onln_stat
	( i_dt         in     varchar2,
	  i_pgm_id     in     varchar2,
	  i_err_code   in     varchar2,
	  i_proc_cnt   in     number,
	  o_ret        in out varchar2
	) AS

-- o_ret           varchar2(10);
t_work_stat     varchar2(01);
t_exe_yn        varchar2(01);
t_err_log       varchar2(600);
t_err_txt       varchar2(500);
exp_error       exception;

begin

	o_ret       := '!';
	t_err_txt := '**['||i_pgm_id||']job';

	/*
	  t_err_txt := '**['||i_pgm_id||
	               ']['||vn.fxe_prog_nm(i_pgm_id)||
	               ']['||vn.fxe_prog_desc(i_pgm_id)||']';
	*/
	--dbms_output.put_line('err_code - '||i_err_code);

	begin

		select nvl(exe_yn,'!'), work_stat
		  into t_exe_yn, t_work_stat
		  from vn.xbd01m00
		 where pgm_id = i_pgm_id
		   and exe_dt = i_dt;

	exception when no_data_found then
	   o_ret := 'NO';
	   t_err_log := 'the excecute date of job id ['|| t_err_txt||
	                '] is wrong or JOB ID doesn`t exists.'||']**';
	   vn.pxb_onln_err(i_dt, i_pgm_id, '3', t_err_log,0);
	   return;

	end;

	--raise_application_error(-20001, t_exe_yn||'**'||i_err_code);
	if i_err_code = 'START' then

		-- do not work today
		if t_exe_yn = 'N' then
		   o_ret := 'SKIP';

		-- work today
		elsif t_exe_yn = 'Y' then

			-- do not start, error
			if t_work_stat in ('0', '3') then
				o_ret := 'YES';

				if t_work_stat = '0' then
				   vn.pxb_onln_err(i_dt, i_pgm_id, '1','START',0);
				elsif t_work_stat = '3' then
				   vn.pxb_onln_err(i_dt, i_pgm_id, '4','START',0);
				end if;
			-- doing
			elsif t_work_stat = '1' then
				o_ret := 'NO';
			-- done
			elsif t_work_stat = '2' then
				o_ret := 'SKIP';
			end if;

		end if;

	elsif i_err_code = 'START_PC' then

		-- do not work today
		if t_exe_yn = 'N' then
		   o_ret := 'SKIP';
		else

			if t_work_stat = '1' or t_work_stat = '2' then
				-- doing
				if t_work_stat = '1' then
				   o_ret := 'NO';
				-- done
				elsif t_work_stat = '2' then
				   o_ret := 'SKIP';
				end if;
			-- do not start
			elsif t_work_stat = '0' then
				o_ret := 'YES';
				vn.pxb_onln_err(i_dt, i_pgm_id, '5', 'START',0);
			-- error
			elsif t_work_stat = '3' then
				o_ret := 'YES';
				-- vn.pxb_onln_err(i_dt, i_pgm_id, '5', 'START');
			end if;

		end if;

   elsif i_err_code = 'END' then

      o_ret := 'YES';
      vn.pxb_onln_err(i_dt, i_pgm_id, '2', 'No error',i_proc_cnt);

   elsif i_err_code = 'END_PC' then

      -- work today
      if t_exe_yn = 'Y' then
         if t_work_stat = '2' then
            o_ret := 'YES';
         else
            o_ret := 'NO';
         end if;
      -- do not work today
      else
         o_ret := 'YES';
      end if;

   else

      o_ret := 'NO';
      t_err_log := t_err_txt||'Error. ['||i_err_code||']**';
      vn.pxb_onln_err(i_dt, i_pgm_id, '3', t_err_log,0);

   end if;


   -- dbms_output.put_line(o_ret);
   exception
   when exp_error then
        raise_application_error(-20100, t_err_txt);

END pxb_onln_stat;
/

