create function fdl_get_not_pia_amt_yet
(
    i_acnt_no        in   varchar2,
    i_sub_no         in   varchar2
)
    return  number
as

    t_err_txt      varchar2(80); -- error text buffer
    t_err_msg      varchar2(500);
    ts_work_stat   varchar2(1);
    td_adj_amt     number := 0;
    td_lnd_amt     number := 0;
    t_result       number := 0;
    t_lnd_amt_tot  number := 0;
    t_rpy_cmsn_tot_all number := 0;


    t_ppre_mth_dt      varchar2(08)  := null;  --
    t_pre_mth_dt       varchar2(08)  := null;  --
    t_vwdate           varchar2(08)  := null;  --

BEGIN

/*============================================================================*/
/*============================================================================*/

    t_vwdate   :=  vn.vwdate;
    t_ppre_mth_dt  := vn.fxc_vorderdt_g(to_date(t_vwdate,'yyyymmdd'), -2);
    t_pre_mth_dt   := vn.fxc_vorderdt_g(to_date(t_vwdate,'yyyymmdd'), -1);
    /*--- lay tong tien da ung (tien ung + phi ung) truoc do ---*/
    /*
    Select sum(a.lnd_amt - a.lnd_rpy_amt + a.lnd_int + a.dly_int + a.lnd_fee + a.dly_fee) into  td_lnd_amt
      From dlm01m00 a
     where a.acnt_no      =  i_acnt_no
       and a.sub_no       =  i_sub_no
       and a.lnd_tp = '10'
       and a.lnd_amt - a.lnd_rpy_amt > 0;
     */
     for C1 in (
                select  a.lnd_tp                               lnd_tp
                     ,  a.acnt_no                              acnt_no
                     ,  a.sub_no                 sub_no
                     ,  a.lnd_bank_cd                          lnd_bank_cd
                     ,  a.lnd_dt                               lnd_dt
                     ,  a.expr_dt                              rpy_dt
                     ,  a.lnd_cmsn_rt                          lnd_cmsn_rt
                     ,  vn.faa_acnt_bnh_cd_g('0',a.acnt_no,a.sub_no)    acnt_mng_bnh
                     ,  vn.faa_acnt_bnh_cd_g('3',a.acnt_no,a.sub_no)    agnc_brch
                     ,  sum(a.lnd_amt)                         lnd_amt
                  from  vn.dlm01m00 a
                 where  a.lnd_tp           =  '10'
                   and  a.acnt_no          =  i_acnt_no
                   and  a.sub_no       =  i_sub_no
                   and  nvl(a.lnd_amt,0)- nvl(a.lnd_rpy_amt,0) > 0
                   and  a.lnd_acpt_tp      =  '01'
                 group  by a.lnd_tp, a.acnt_no, a.sub_no, a.lnd_bank_cd, a.lnd_dt, a.expr_dt, a.lnd_cmsn_rt
            ) loop


                t_lnd_amt_tot  := 0;
                t_rpy_cmsn_tot_all := 0;
                t_lnd_amt_tot  := C1.lnd_amt;

                /*====================================================================*/
                /* lnd_cmsn Calc  => 2008/01/30 ������                              */
                /*====================================================================*/
                t_rpy_cmsn_tot_all := 0;
                vn.pdl_get_lnd_cmsn ( C1.lnd_tp
                                    , C1.lnd_bank_cd, C1.acnt_no, C1.sub_no
                                    , C1.lnd_dt     , C1.rpy_dt
                                    , t_lnd_amt_tot
                                    , t_lnd_amt_tot
                                    , C1.lnd_cmsn_rt
                                    , t_rpy_cmsn_tot_all );
              td_lnd_amt := td_lnd_amt + t_lnd_amt_tot + t_rpy_cmsn_tot_all;
              end loop;
    BEGIN
          SELECT NVL(WORK_STAT,'1')
            INTO ts_work_stat
            FROM vn.xbd01m00
           WHERE PGM_ID = '2000'
          ;
    EXCEPTION
    WHEN OTHERS THEN
        ts_work_stat := '1';
    END;

    /*-- Lay gia tri tien ban cho ve sau khi da tru di phi va thue ban--*/
    IF ts_work_stat = '2' THEN
        select  sum(adj_amt) into td_adj_amt
           from  vn.dsc01m00
          where  acnt_no      =  i_acnt_no
            and  sub_no       =  i_sub_no
            and  bank_cd   like  '%'
            and  sb_tp        =  '1'
            and  dpo_setl_yn  =  'N'
            and  mkt_trd_tp  in  ('01','03','05');
    ELSE
          begin
              /*-- tinh du lieu phi va thue chinh xac cho tai khoan nay -> chay du dinh thanh toan truoc - du lieu duoc day vao table tam: dsc01m10 --*/
              vn.pds_setl_cr_pre_cmsn(t_vwdate , i_acnt_no, i_sub_no, 'Get_not_pia_yet', 'Get_not_pia_yet');
          end;

      Select Sum(adj_amt) into td_adj_amt
       From (
             select  sum(adj_amt)  adj_amt
                 from  vn.dsc01m00
                where  mth_dt       >=  t_ppre_mth_dt
                  and  mth_dt       <  t_vwdate
                  and  acnt_no      =  i_acnt_no
                  and  sub_no       =  i_sub_no
                  and  bank_cd   like  '%'
                  and  sb_tp        =  '1'
                  and  dpo_setl_yn  =  'N'
                  and  mkt_trd_tp  in  ('01','03','05')
               union all
               select  sum(adj_amt) adj_amt
                 from  vn.dsc01m10
                where  mth_dt       =  t_vwdate
                  and  acnt_no      =  i_acnt_no
                  and  sub_no       =  i_sub_no
                  and  bank_cd   like  '%'
                  and  sb_tp        =  '1'
                  and  dpo_setl_yn  =  'N'
                  and  mkt_trd_tp  in  ('01','03','05')
             );
    END IF;
    t_result := td_adj_amt - td_lnd_amt;
    return  t_result;

END fdl_get_not_pia_amt_yet;
/

