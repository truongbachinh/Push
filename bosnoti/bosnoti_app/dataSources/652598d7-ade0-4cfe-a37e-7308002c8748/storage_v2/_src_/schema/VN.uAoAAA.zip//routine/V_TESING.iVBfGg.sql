create procedure v_tesing
(
	os_acnt_no   in   varchar2,
  os_sub_no   in   varchar2
) as
  t_acnt_no   varchar2(10);
begin
      SELECT ACNT_NO
      into t_acnt_no
        		  FROM VN.AAA01M00
			 WHERE ACNT_NO = os_acnt_no
			   AND SUB_NO like os_sub_no
			 FOR UPDATE wait 30;
end v_tesing;
/

