create function fdl_get_lnd_setl_bank
(
    i_lnd_bank_cd  in   varchar2
)
    return  varchar2
as
	o_setl_bank_cd	varchar2(100);
begin

/*============================================================================*/
/* Name of the Bank return                                                    */
/*============================================================================*/

	if i_lnd_bank_cd in ('0000') then
		return '0000';
	else
		for C1 IN (
		    select  setl_bank_cd
			  from  vn.dlm12m00
			 where  lnd_bank_cd  =  i_lnd_bank_cd
			   and  apy_dt       =  (select  max(apy_dt)
			                           from  vn.dlm12m00
			                          where  lnd_bank_cd  =  i_lnd_bank_cd)
			 order  by apy_dt desc
		) loop
		    o_setl_bank_cd := C1.setl_bank_cd;
		    return o_setl_bank_cd;
		end loop;

	    return '!';
	end if;

end fdl_get_lnd_setl_bank;
/

