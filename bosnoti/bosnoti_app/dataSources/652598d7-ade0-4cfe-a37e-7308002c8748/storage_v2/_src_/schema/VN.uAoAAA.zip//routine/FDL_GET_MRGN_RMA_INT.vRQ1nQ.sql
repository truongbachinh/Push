create function    fdl_get_mrgn_rma_int
(
    i_lnd_tp          in   varchar2,        --
    i_acnt_no         in   varchar2,        --
    i_sub_no          in   varchar2,
    i_lnd_bank_cd     in   varchar2,        --
    i_int_tp          in   varchar2,        -- 1:int 2:dly_int 3:all
    i_lnd_dt          in   varchar2,        --
    i_rpy_dt          in   varchar2,        --
    i_expr_dt         in   varchar2,        --
    i_last_rpy_dt     in   varchar2,        --
    i_cpt_rpy_tp      in   varchar2,        --
    i_int_rpy_tp      in   varchar2,        -- 1:rm_amt 2:repay_amt
    i_rpy_mthd_tp     in   varchar2,        -- 1:cash 2:sell
    i_int_calc_apy_tp in   varchar2,        -- 1:fix ratio 2:movable ratio
    i_rpy_amt         in   number,          --
    i_lnd_int_rt      in   number           --
)
    return number AS

/*!
   \file     fdl_get_mrgn_rma_int.sql
   \brief    calculate interests and repay loan amount based on total repay amount

   \section intro Program Information
        - Program Name              : calculate interests and repay loan amount based on total repay amount
        - Service Name              : fdl_get_mrgn_rma_int
        - Related Client Program- Client Program ID : w_04001_tab5
        - Related Tables            :
        - Dev. Date                 : 2012/04/01
        - Developer                 : hjcho
        - Business Logic Desc.      : calculate interests and repay loan amount based on total repay amount
        - Latest Modification Date  : 2012/04/01

   \section history Program Modification History
    - 1.0       2010/11/03    New.

   \section hardcoding Hard-Coding List
    - HC-1      2010/11/03     hjcho.    [»çÀ¯]

   \section info Additional Reference Comments
    - Interest calculation

select vn.fdl_get_mrgn_rma_int( '70'
                            ,'045C000004'
                            ,'9999'
                            ,'1' or '2'
                            ,'20101101'
                            ,'20101224'
                            ,'20101130'
                            ,'20101101'
                            ,'1'
                            ,'1'
                            ,'1'
                            ,'2'
                            ,100000
                            ,0.1 )
  from dual;
*/
    o_rt_val                   NUMBER := 0;

    td_lnd_int                 NUMBER := 0;
    td_dly_int                 NUMBER := 0;
    td_lnd_int_rt             NUMBER := 0;
    td_dly_int_rt             NUMBER := 0;

    td_rpy_amt               NUMBER := 0;
    td_rpy_int               NUMBER := 0;
    ts_err_txt               VARCHAR2(80); -- error text buffer

begin
    o_rt_val := 0;
/*
    vn.pxc_log_write('fdl_get_mrgn_rma_int', ' Acnt ='||i_acnt_no||'-'||i_sub_no
                                             ||' i_lnd_tp='||          i_lnd_tp
                                             ||' i_lnd_bank_cd='||     i_lnd_bank_cd
                                             ||' i_int_tp='||          i_int_tp
                                             ||' i_lnd_dt='||          i_lnd_dt
                                             ||' i_rpy_dt='||          i_rpy_dt
                                             ||' i_expr_dt='||         i_expr_dt
                                             ||' i_last_rpy_dt='||     i_last_rpy_dt
                                             ||' i_cpt_rpy_tp='||      i_cpt_rpy_tp
                                             ||' i_int_rpy_tp='||      i_int_rpy_tp
                                             ||' i_rpy_mthd_tp='||     i_rpy_mthd_tp
                                             ||' i_int_calc_apy_tp='|| i_int_calc_apy_tp
                                             ||' i_rpy_amt='||         i_rpy_amt
                                             ||' i_lnd_int_rt='||      i_lnd_int_rt
                                             );
*/

    /*============================================================================*/
    /* Calculate Interests ratio                                                  */
    /*============================================================================*/

    td_lnd_int_rt := vn.fdl_get_mrgn_int( i_lnd_tp
                                        , i_acnt_no
                                        , i_sub_no
                                        , i_lnd_bank_cd
                                        , '4'
                                        , i_lnd_dt
                                        , i_rpy_dt
                                        , i_expr_dt
                                        , i_last_rpy_dt
                                        , i_cpt_rpy_tp
                                        , i_int_rpy_tp
                                        , i_rpy_mthd_tp
                                        , i_int_calc_apy_tp
                                        , 1
                                        , 1
                                        , 1
                                        , i_lnd_int_rt);

    td_dly_int_rt := vn.fdl_get_mrgn_int( i_lnd_tp
                                        , i_acnt_no
                                        , i_sub_no
                                        , i_lnd_bank_cd
                                        , '5'
                                        , i_lnd_dt
                                        , i_rpy_dt
                                        , i_expr_dt
                                        , i_last_rpy_dt
                                        , i_cpt_rpy_tp
                                        , i_int_rpy_tp
                                        , i_rpy_mthd_tp
                                        , i_int_calc_apy_tp
                                        , 1
                                        , 1
                                        , 1
                                        , i_lnd_int_rt);

    td_rpy_amt := round(i_rpy_amt / ( 1+ td_lnd_int_rt + td_dly_int_rt ));
    td_lnd_int := trunc(td_rpy_amt * td_lnd_int_rt,0);
    td_dly_int := trunc(td_rpy_amt * td_dly_int_rt,0);
    td_rpy_int := td_lnd_int + td_dly_int;
  td_rpy_amt := i_rpy_amt - td_rpy_int;


    vn.pxc_log_write('fdl_get_mrgn_rma_int', ' Acnt ='||i_acnt_no||'-'||i_sub_no
                                             ||' Lnd_dt ='||i_lnd_dt
                                             ||' rm_amt='|| to_char(i_rpy_amt)
                                             ||' td_lnd_int ='||to_char(td_lnd_int)||'('||to_char(td_lnd_int_rt)||')'
                                             ||' td_dly_int ='||to_char(td_dly_int)||'('||to_char(td_dly_int_rt)||')'
                                             ||' rpy_amt='|| to_char(td_rpy_amt)
                                             ||' rpy_int='|| to_char(td_rpy_int)
                                             ||' tot_rpy='|| to_char(td_rpy_amt+td_rpy_int)
                                             );

    if i_rpy_dt < i_last_rpy_dt then
        td_lnd_int := 0;
        td_dly_int := 0;
        td_rpy_int := 0;
    end if;

    if  i_int_tp = '1' then
        o_rt_val := trunc(td_rpy_amt,0);
    elsif i_int_tp = '2' then
        o_rt_val := trunc(td_lnd_int,0);
    elsif i_int_tp = '3' then
        o_rt_val := trunc(td_dly_int,0);
    elsif i_int_tp = '4' then
        o_rt_val := trunc(td_rpy_int,0);
    end if;

    return o_rt_val;

end fdl_get_mrgn_rma_int;
/

