create procedure pxc_sunday_saturday
(
    i_date_s  		in        varchar2,
    i_date_e  	   in        varchar2
)is
/*
  Develop by: Mickey
  Date:  2009/04/11
  Request by: Mr.Mung VCSC
  Automatic create Sunday and saturday into table vn.xcc20m00
*/
	 ts_sqlcode      number;
    tn_count        number;
    ts_sunday       varchar2(8);
    ts_saturday     varchar2(8);
begin
	begin
      ts_sunday   := i_date_s;
      ts_saturday := i_date_s;
      tn_count    := 0;
      
      WHILE ts_sunday >= i_date_s and ts_sunday <= i_date_e loop
         --Get saturday
         select to_char(next_day(to_date(ts_saturday, 'yyyymmdd'), 7), 'yyyymmdd')
           into ts_saturday
           from dual;
           
         --Get sunday
         select to_char(next_day(to_date(ts_sunday, 'yyyymmdd'), 1), 'yyyymmdd')
           into ts_sunday
           from dual;
         
         if ts_sunday >= i_date_s and ts_sunday <= i_date_e then
            tn_count := 0;
            select count(*)
              into tn_count
              from vn.xcc20m00
             where to_char(dt_dt, 'yyyymmdd') = ts_saturday
               and holi_tp = '3';
            --Insert into table automatic
            if tn_count = 0 then               
               --Saturday
               insert into vn.xcc20m00(dt_dt, holi_tp)
                    values (to_date(ts_saturday, 'yyyymmdd'), '3');
            end if;
            
            tn_count := 0;
            select count(*)
              into tn_count
              from vn.xcc20m00
             where to_char(dt_dt, 'yyyymmdd') = ts_sunday
               and holi_tp = '1';
            --Insert into table automatic
            if tn_count = 0 then                           
               --Sunday
               insert into vn.xcc20m00(dt_dt, holi_tp)
                    values (to_date(ts_sunday, 'yyyymmdd'), '1');
            end if;
         end if;
      END LOOP;  
	EXCEPTION
      WHEN OTHERS THEN
         ts_sqlcode := sqlcode || ' SqlError: ' || sqlerrm;
         RAISE_APPLICATION_ERROR(-20100,'Oracle error: ['||ts_sqlcode||']');
   END;
END pxc_sunday_saturday;
/

