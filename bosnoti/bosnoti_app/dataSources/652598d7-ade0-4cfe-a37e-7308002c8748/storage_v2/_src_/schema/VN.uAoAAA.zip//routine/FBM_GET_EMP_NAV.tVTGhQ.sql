create function fbm_get_emp_nav(
    i_emp_no        varchar2,
    i_dt            varchar2,
    i_tp            varchar2        -- 1: Tong nav cua KH truc tiep quan ly     2: Tong nav cua broker quan ly truc tiep    3: Tong nav tat ca KH nhanh duoi
)
/*
    select fbm_get_emp_nav(
        'dungnn',       -- i_emp_no       varchar2,
        vwdate,         -- i_dt            varchar2,
        '2'             -- i_tp            varchar2 
    ) a
    from dual;
*/
return number

as
    t_vwdate        varchar2(8)     := vn.vwdate;
    t_nav           number          := 0;
    o_ret           number          := 0;

begin
    -- So du tien: Tien giao dich + Tien ban cho tt chua ung + Co tuc cho ve + Tien phong toa
    -- So du CK: CK giao dich + CK mua cho ve + CK cho giao dich + CK phong toa + CK quyen cho ve
    -- Tong no: No goc margin + Lai vay tam tinh + No phi luu ky

    -- 1. Danh sach broker duoi quyen
    with sub_emp_list as(
        select
            parent_no       mng_emp_no,
            sub_no          sub_emp_no
        from table  (vn.fbm_get_sub_item_hier(
                    '1',            -- i_tp             varchar2(15),
                    i_emp_no,       -- i_mng_emp_no     varchar2(15),
                    i_dt          -- i_dt             varchar2(8)
                    )
                ) hier
        inner join vn.xca01m01 x1
        on hier.sub_no = x1.emp_no
        where x1.biz_emp_tp = '2'       -- Broker
    ),
    acnt_list as(
        select distinct
            bi.acnt_no,
            a1.sub_no
        from sub_emp_list el
        inner join vn.bmi01m00 bi
        on el.sub_emp_no = bi.emp_no
        inner join vn.aaa01m00 a1
        on bi.acnt_no = a1.acnt_no
        where i_dt between bi.mng_emp_regi_dt and to_char(bi.cls_dtm, 'YYYYMMDD')
        and a1.acnt_stat = '1'
    ),
    acnt_nav as(
        select 
            c9.dpo + c9.reuse_dpo + c9.cdr_amt                      cash_balance,
            c9.tot_stk_amt                                          stk_balance,
            c9.mrgn_loan_nowrm + c9.mrgn_loan_int + c1.dpo_fee_bk   tot_loan
        from acnt_list al
        inner join vn.cwd99m00 c9
        on al.acnt_no = c9.acnt_no
        and al.sub_no = c9.sub_no
        inner join cwd01m00 c1
        on al.acnt_no = c1.acnt_no
        and al.sub_no = c1.sub_no
        where t_vwdate = i_dt

        union all

        select 
            c9.dpo + c9.reuse_dpo + c9.cdr_amt                      cash_balance,
            c9.tot_stk_amt                                          stk_balance,
            c9.mrgn_loan_nowrm + c9.mrgn_loan_int + c1.dpo_fee_bk   tot_loan
        from acnt_list al
        inner join vn.cwd99h00 c9
        on al.acnt_no = c9.acnt_no
        and al.sub_no = c9.sub_no
        inner join cwd01h00 c1
        on al.acnt_no = c1.acnt_no
        and al.sub_no = c1.sub_no
        where t_vwdate <> i_dt
        and c9.dt = i_dt
        and c1.std_dt = i_dt

    )
    select
        sum(nvl(cash_balance, 0) + nvl(stk_balance, 0) - nvl(tot_loan, 0))
    into 
        t_nav
    from acnt_nav
    ;

    o_ret := nvl(t_nav, 0);

    return o_ret;

end fbm_get_emp_nav;
/

