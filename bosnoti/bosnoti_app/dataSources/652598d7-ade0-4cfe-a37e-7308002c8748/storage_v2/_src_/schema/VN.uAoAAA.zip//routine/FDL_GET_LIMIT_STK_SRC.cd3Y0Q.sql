create function    fdl_get_limit_stk_src
	(i_stk_cd varchar2,
	 i_src_no varchar2,
	 i_dt varchar2
) return number /* 
- Neu ton tai chung khoan han che nguon thi khong tinh TS cua chung khoan vao tong tai san
- Neu KHONG ton tai thi tinh ts nhu binh thuong
*/
as
  t_limit_stk_src number :=0;
  begin

    BEGIN
	 select count(*) into t_limit_stk_src
	 from dlm60m00
	 where src_no = i_src_no
	   and stk_cd = i_stk_cd
	   and active_stat ='Y'
	   and apy_dt <= i_dt
	   and expr_dt >= i_dt;	 
    EXCEPTION
          WHEN OTHERS THEN
              t_limit_stk_src := 0;
    END;    

	if t_limit_stk_src >0 then
		return 0;
	else
		return 1;
	end if;

end fdl_get_limit_stk_src;
/

