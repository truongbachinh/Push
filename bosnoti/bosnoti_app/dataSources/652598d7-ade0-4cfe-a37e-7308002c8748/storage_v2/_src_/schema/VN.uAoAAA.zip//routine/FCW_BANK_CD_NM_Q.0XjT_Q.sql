create function fcw_bank_cd_nm_q
(
    i_bank_cd   in   varchar2        -- bank_cd
)

	return          varchar2
as
    o_bank_cd_nm		varchar2(100) ;
    t_err_txt       varchar2(100)  ; -- error text buffer

begin

    o_bank_cd_nm  :=  NULL;

   if  i_bank_cd = '0000'  then
       o_bank_cd_nm := 'ALL_BANK' ;
       return  o_bank_cd_nm;
   end if ;

    begin
      	select nvl(bank_nm, ' ')
		  into o_bank_cd_nm
          from vn.cww01h00
         where bank_cd	= i_bank_cd
		   and mng_end_dt	= to_date('30000101','yyyymmdd');
    exception
        when  NO_DATA_FOUND  then
			return  ' ';
        when  OTHERS         then
            t_err_txt  :=  '¿À·ù-['||to_char(sqlcode)||']';
            raise_application_error (-20100, t_err_txt);
    end;

    return  o_bank_cd_nm;

end fcw_bank_cd_nm_q;
/

