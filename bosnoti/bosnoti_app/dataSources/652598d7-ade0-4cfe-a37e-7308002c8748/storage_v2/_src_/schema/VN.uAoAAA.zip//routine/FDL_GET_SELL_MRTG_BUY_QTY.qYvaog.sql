create function fdl_get_sell_mrtg_buy_qty
(
	i_acnt_no      in   varchar2,
	i_sub_no       in   varchar2,
    i_bank_cd      in   varchar2,
    i_stk_cd       in   varchar2

)    return          NUMBER  as
    o_qty           number ;
    t_err_txt       VARCHAR(100) := ' ';

/*
   \file     fts_get_sell_mrtg_buy_qty.sql
   \brief    all quantity of matched order of table dlm01m00
*/

begin
        o_qty      := 0;

        begin
            SELECT NVL(SUM(GREATEST(td_sell_mth_qty + pd_sell_mth_qty + ppd_sell_mth_qty + pppd_sell_mth_qty, 0)), 0)
            INTO o_qty
            FROM vn.dlm01m00
            WHERE ACNT_NO = i_acnt_no
              AND SUB_NO  = i_sub_no
              AND SETL_BANK_CD LIKE i_bank_cd
				      AND STK_CD LIKE i_stk_cd ;

        exception
            when  NO_DATA_FOUND  then
    		    o_qty	 :=  0;
            when  OTHERS         then
                t_err_txt  :=  'error - ' ||  to_char(sqlcode) ;
                raise_application_error (-20100, t_err_txt);
         end;

    return o_qty;

end fdl_get_sell_mrtg_buy_qty;
/

