create FUNCTION fdl_get_move_able_amt
(
    i_bf_stk_cd      in   varchar2,
    i_af_stk_cd      in   varchar2
)   RETURN  NUMBER AS
/*!


select vn.fdl_get_move_able_amt('999','AAA','BBB') from dual;

*/
    o_rtn_val         NUMBER;

    td_sum_val        NUMBER;
    td_used_amt       NUMBER;
    td_used_amt2      NUMBER;

    td_lnd_limit      NUMBER;

begin

/*============================================================================*/
/* Valiabl Initialize
/*============================================================================*/
    td_sum_val     := 0;

	FOR C1 IN (
		SELECT acnt_no
		     , sub_no
		     , lnd_use_amt
		  FROM vn.dlm05m10
		 WHERE stk_cd = i_bf_stk_cd

	) LOOP

		BEGIN
		SELECT lnd_use_amt
		  INTO td_used_amt
		  FROM vn.dlm05m10
		 WHERE acnt_no = C1.acnt_no
		   AND sub_no  = C1.sub_no
		   AND stk_cd  = i_af_stk_cd
		;
		EXCEPTION
		WHEN OTHERS THEN
			td_used_amt := 0;
		END;

		IF td_used_amt <> 0 THEN

			td_sum_val := td_sum_val + C1.lnd_use_amt;

		END IF;

	END LOOP;

    td_lnd_limit   := vn.fdl_get_sec_lnd_info(vn.vwdate, '08' );

	BEGIN
	SELECT lnd_use_amt
	  INTO td_used_amt2
	  FROM vn.dlm05m00
	 WHERE stk_cd  = i_af_stk_cd
	;
	EXCEPTION
	WHEN OTHERS THEN
		td_used_amt2 := 0;
	END;

		 			vn.pxc_log_write('fdl_get_move_able_amt', ' Check ' ||' i_bf_stk_cd = '|| i_bf_stk_cd
		 			                                                    ||' i_af_stk_cd = '|| i_af_stk_cd);

    IF td_lnd_limit - td_used_amt2 > td_sum_val THEN
    	o_rtn_val := td_sum_val;
    ELSE
    	o_rtn_val := td_lnd_limit - td_used_amt2;
	END IF;


    RETURN o_rtn_val;

END fdl_get_move_able_amt;
/

