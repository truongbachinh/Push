create procedure psr_rgt_inoutmon_p
 (i_std_dt       in       varchar2,
  i_stk_cd       in       varchar2,
  i_rgt_tp       in       varchar2,
  i_proc_tp      in       varchar2,
  i_proc_dt      in       varchar2,
  i_seq_no       in       number,
  i_work_mn      in       varchar2,
  i_work_trm     in       varchar2,
  o_proc_cnt     in out   number
 ) is

 vs_acnt_no      varchar2(10);
 vs_sub_no       varchar2(2);
 vs_cnvt_strt_dt varchar2(8);
 vs_cnvt_lst_dt  varchar2(8);
 vs_cnvt_req_dt  varchar2(8);
 vs_dept_no      varchar2(5);
 vs_rmrk_cd      varchar2(3);
 vs_tax_rmrk     varchar2(3);
 vs_bank_cd      varchar2(4);
 vs_agnc_brch    varchar2(2);
 vs_tax_orga	   varchar2(1);
 vn_own_qty      number;
 vn_loan_qty      number;
 vn_outq_qty      number;
 vn_mov_lim_qty   number;
 -- SMS
 vs_msg_lang      varchar2(1);
 vs_fnc_cd        varchar2(10);
 vs_iss_pri       varchar2(10);
 vs_dpo           varchar2(20);
 vs_asn_amt       varchar2(20);
 vs_sms_msg       varchar2(200);
--

 vn_flotq_amt    number;
 vn_asn_amt      number;
 vn_int_amt      number;
 vn_sbst_amt     number;
 vn_tax_amt      number;
 vo_pre_rm       number;
 vo_now_rm       number;
 vn_trd_seq_no   number;

 o_trd_dt        varchar2(8);
 o_trd_seq_no    number;
 o_dpo_prerm     number;
 o_dpo_nowrm     number;
 o_acnt_place    varchar2(5);
 o_bnhof_tp      varchar2(5);
 o_proc_bnhof_tp varchar2(5);
 ts_job_tp       varchar2(1)  := '3' ;

 td_rate         number := 0 ;
 o_cnt					 number := 0;
 os_inq_dt		 number := 0 ;
 vo_trd_seq_no   number;
 vo_rcdb_no      number;

/* ************************************** Log changes ****************************************
02-Jan-2019 vnjvthangnm Gui tin nhan SMS
******************************************************************************************* */
begin
 o_proc_cnt:= 0;
 if i_proc_tp = '1' then

    for  c1  in (

       select   a.acnt_no       acnt_no,
				        a.sub_no        sub_no,
                a.flotq_amt     flotq_amt,
				        a.tax_flotq     tax_amt   ,
				        a.acnt_mng_bnh  acnt_mng_bnh,
                b.agnc_brch     agnc_brch ,
				        NVL(b.bank_cnt_yn,'N') bank_cnt_yn ,
				        NVL(b.bank_cd,'')     bank_cd
	   from     vn.srr02m00 a ,
				vn.aaa01m00 b
       where    a.rgt_std_dt    =  i_std_dt
       and      a.stk_cd        =  i_stk_cd
       and      a.rgt_tp        =  i_rgt_tp
	   and      a.seq_no        =  i_seq_no
	   and      a.flotq_amt     >  0
	   and      a.flotq_trd_no  =  0
	   and      a.acnt_no = b.acnt_no
	   and      a.sub_no  = b.sub_no

    ) loop

       vs_acnt_no       := c1.acnt_no;
       vs_sub_no        := c1.sub_no;
       vn_flotq_amt     := c1.flotq_amt;
       vn_tax_amt       := c1.tax_amt ;
       vs_dept_no       := c1.acnt_mng_bnh;
	   vs_bank_cd       := c1.bank_cd ;
	   vs_agnc_brch     := c1.agnc_brch ;
	   ts_job_tp        := '6' ;

       vn.pxc_log_write('psr_rgt_inoutmon_p', vs_acnt_no||' flotq_amt');

       if i_rgt_tp = '3' then
      select nvl(tax_orga,'0') tax_orga
      into   vs_tax_orga
      from vn.srr01m00
      where stk_cd = i_stk_cd
      and rgt_std_dt = i_std_dt
      and seq_no = i_seq_no
      and rgt_tp = i_rgt_tp ;

      if vs_tax_orga <> '2' then /*thu thue tai CTCK*/
           vn_tax_amt := 0;
      end if;
    end if;

      if c1.bank_cnt_yn = 'Y'  then
          begin

          vn.psr_bat_bank(
					i_proc_dt ,
					vs_acnt_no ,
					vs_sub_no ,
					vs_bank_cd ,
					vs_dept_no ,
					vs_agnc_brch ,
					vn_flotq_amt ,
					vn_tax_amt ,
					'242',
					'252' , -- tax
					i_work_mn ,
					i_work_trm,
					i_stk_cd,
					0    ,
					i_std_dt,
					ts_job_tp ,
					o_trd_seq_no );

        exception

        when others then
             vn.pxc_log_write('psr_rgt_inoutmon_p', 'buy'||vs_acnt_no||'['||sqlcode||']');
             o_trd_seq_no := 0;
        end;

     else

	   begin
	   vn.pcw_cash_inamt_p(
						i_proc_dt,
						vs_acnt_no,
						vs_sub_no,
						'242',
						vn_flotq_amt,
						'00',
						'BATCH',
						'Y',
						vs_dept_no,
						i_work_mn,
						i_work_trm,
						o_trd_dt,
						o_trd_seq_no,
						o_dpo_prerm,
						o_dpo_nowrm,
						o_acnt_place,
						o_bnhof_tp,
						o_proc_bnhof_tp
						);

	   exception
	   when others then
         vn.pxc_log_write('psr_rgt_inoutmon_p', vs_acnt_no||'['||sqlcode||']');
	     o_trd_seq_no := 0;
	   end;

	/* make aaa10m00 gga07m00 */
	   begin
		 vn.psr_his_tax_cr (
							 i_proc_dt
							,i_stk_cd
							,0
							,vs_acnt_no
							,vs_sub_no
							,vs_dept_no
							,vs_agnc_brch
							,'242'
							,vn_flotq_amt
							,'252'
							,vn_tax_amt
							,o_dpo_prerm
							,o_dpo_nowrm
							,i_work_mn
							,i_work_trm
							,o_trd_seq_no ) ;

       exception
       when others then
         vn.pxc_log_write('psr_rgt_inoutmon_p', vs_acnt_no||'['||sqlcode||']');
         vn.pxc_log_write('psr_rgt_inoutmon_p', vs_sub_no||'['||sqlcode||']');
         o_trd_seq_no := 0;
       end;

    end if ;

	o_proc_cnt:= o_proc_cnt+1;
	/* processing profits to rt_reuse  */

	vn.psr_sbst_pay_p (
						'c'          ,
						vn_flotq_amt ,
						i_stk_cd     ,
						vs_acnt_no   ,
						vs_sub_no   ,
						i_work_mn    ,
						i_work_trm
                      )  ;

	update  vn.srr02m00
    set     flotq_trd_no  = o_trd_seq_no
    where   rgt_std_dt    = i_std_dt
    and     stk_cd        = i_stk_cd
    and     rgt_tp        = i_rgt_tp
    and     seq_no        = i_seq_no
	and     acnt_no       = vs_acnt_no
	and     sub_no        = vs_sub_no;

  end loop;

  if  i_rgt_tp = '8' then
	update  vn.srr01m10
	   set  FLOTQ_END_YN = 'Y' ,
		    rgt_proc_stat = '7'
     where  rgt_std_dt    = i_std_dt
	   and  stk_cd        = i_stk_cd
	   and  nvl(FLOTQ_END_YN,'N') <> 'Y' ;
  else

	update  vn.srr01m00
	set     rgt_proc_stat = '7'
	where   rgt_std_dt    = i_std_dt
	and     stk_cd        = i_stk_cd
	and     rgt_tp        = i_rgt_tp
	and     seq_no        = i_seq_no;

  end if;

 elsif  i_proc_tp  = '2' or i_proc_tp = '4' then   /* dividend  4.bond capital  */

	for  f1  in  (

        select   a.acnt_no  acnt_no,
				         a.sub_no   sub_no,
                 a.asn_amt  asn_amt,
				         a.tax_asn  tax_amt,
				         a.own_qty	own_qty,
			           a.acnt_mng_bnh acnt_mng_bnh ,
				         b.agnc_brch agnc_brch ,
				         NVL(b.bank_cnt_yn,'N') bank_cnt_yn ,
				         NVL(b.bank_cd,'') bank_cd
	    from     vn.srr02m00 a ,
	             vn.aaa01m00 b
        where    a.rgt_std_dt    =  i_std_dt
        and      a.stk_cd        =  i_stk_cd
        and      a.rgt_tp        =  i_rgt_tp
		and      a.seq_no        =  i_seq_no
		and      a.asn_amt       >  0
        and      a.rcpt_trd_no    =  0
		and      a.acnt_no = b.acnt_no
		and      a.sub_no  = b.sub_no

    ) loop


      vs_acnt_no       := f1.acnt_no;
      vs_sub_no        := f1.sub_no;
      vn_asn_amt       := f1.asn_amt;
	    vn_own_qty	     := f1.own_qty;
      vn_tax_amt       := f1.tax_amt;
      vs_dept_no       := f1.acnt_mng_bnh;
	    vs_bank_cd       := f1.bank_cd ;
	    vs_agnc_brch     := f1.agnc_brch ;

      td_rate          := 0  ;

	  vn.pxc_log_write('psr_rgt_inoutmon_p', vs_acnt_no||' asn_amt');

      if i_rgt_tp = '3' then
		 vs_rmrk_cd  := '241';
		 vs_tax_rmrk := '251';

	   /* get rate only 241 */

		 select rgt_iss_pri,
     	nvl(tax_orga,'0') tax_orga
		   into td_rate,vs_tax_orga
		   from vn.srr01m00
          where stk_cd = i_stk_cd
			and rgt_std_dt = i_std_dt
			and seq_no = i_seq_no
			and rgt_tp = i_rgt_tp ;

      	if vs_tax_orga <> '2' then /*thu thue tai CTCK*/
				vn_tax_amt := 0;
			end if;
	  else
         vs_rmrk_cd  := '248';
         vs_tax_rmrk := '258';
	  end if;


	  vn.pxc_log_write('psr_rgt_inoutmon_p', 'bank_cnt ' || f1.bank_cnt_yn||' '||vs_acnt_no);

	  if f1.bank_cnt_yn = 'Y' then

        begin
        vn.psr_bat_bank(
					i_proc_dt ,
					vs_acnt_no ,
					vs_sub_no ,
					vs_bank_cd ,
					vs_dept_no ,
					vs_agnc_brch ,
					vn_asn_amt ,
					vn_tax_amt  ,
					vs_rmrk_cd  ,
					vs_tax_rmrk ,
					i_work_mn  ,
					i_work_trm ,
					i_stk_cd   ,
					td_rate    ,
					i_std_dt   ,
					ts_job_tp  ,
					o_trd_seq_no ) ;

        exception
        when others then
             vn.pxc_log_write('psr_rgt_inoutmon_p', 'buy'||vs_acnt_no||'['||sqlcode||']');
             o_trd_seq_no := 0;
        end;

     else

	  begin
	  vn.pcw_cash_inamt_p(
						i_proc_dt,
						vs_acnt_no,
						vs_sub_no,
						vs_rmrk_cd,
						vn_asn_amt,
						'00',
						'BATCH',
						'Y',
						vs_dept_no,
						i_work_mn,
						i_work_trm,
						o_trd_dt,
						o_trd_seq_no,
						o_dpo_prerm,
						o_dpo_nowrm,
						o_acnt_place,
						o_bnhof_tp,
						o_proc_bnhof_tp
						);

	  exception
	  when others then
        vn.pxc_log_write('psr_rgt_inoutmon_p', 'asn '||vs_acnt_no||' pcw_cash_inamt_p ' || '['||sqlcode||']');
	    o_trd_seq_no := 0;
	  end;

      /* make aaa10m00 gga07m00 */
       begin
         vn.psr_his_tax_cr (
                            i_proc_dt
                            ,i_stk_cd
                            ,0
                            ,vs_acnt_no
                            ,vs_sub_no
                            ,vs_dept_no
                            ,vs_agnc_brch
                            ,vs_rmrk_cd
                            ,vn_asn_amt
                            ,vs_tax_rmrk
                            ,vn_tax_amt
                            ,o_dpo_prerm
                            ,o_dpo_nowrm
                            ,i_work_mn
                            ,i_work_trm
                            ,o_trd_seq_no ) ;

       exception
       when others then
         vn.pxc_log_write('psr_rgt_inoutmon_p', vs_acnt_no||'['||sqlcode||']');
         o_trd_seq_no := 0;
       end;

    end if ;

	o_proc_cnt:= o_proc_cnt+1;
    /* processing profits to rt_reuse  */

    vn.psr_sbst_pay_p (
                        'c'          ,
                        vn_asn_amt ,
                        i_stk_cd     ,
                        vs_acnt_no   ,
                        vs_sub_no   ,
                        i_work_mn    ,
                        i_work_trm
                      )  ;

		update  vn.srr02m00
		  set     rcpt_trd_no  = o_trd_seq_no
		  where   rgt_std_dt  = i_std_dt
		  and     stk_cd      = i_stk_cd
		  and     rgt_tp      = i_rgt_tp
		  and     seq_no      = i_seq_no
		  and     acnt_no     = vs_acnt_no
		  and     sub_no      = vs_sub_no;

		if i_proc_tp = '4' then
			begin
				select nvl(own_qty,0) ,
						  nvl(MRTG_LND_QTY,0) + nvl(MRTG_BUY_QTY,0) ,
						  nvl(outq_req_qty, 0 ) ,
						  nvl(MOV_LIM_QTY, 0  )
					 into vn_own_qty  ,
						  vn_loan_qty ,
						  vn_outq_qty ,
						  vn_mov_lim_qty
					 from vn.ssb01m00
					where acnt_no = vs_acnt_no
					  and sub_no  = vs_sub_no
					  and stk_cd  = i_stk_cd  ;
				exception
					 when others then
						  vn_own_qty  := 0 ;
						  vn_loan_qty := 0 ;
						  vn_outq_qty := 0 ;
						  vn_mov_lim_qty := 0 ;
			end ;

			if vn_outq_qty > 0 then

				 update vn.ssb05m00
					set cncl_yn = 'Y'
					where acnt_no = vs_acnt_no
					and sub_no  = vs_sub_no
					and stk_cd  = i_stk_cd
					and trd_tp like '2%'
					and nvl(end_yn,'N') <> 'Y'
					and nvl(cncl_yn,'N') <> 'Y' ;

				update vn.ssb01m00
					set outq_req_qty = 0
				where acnt_no = vs_acnt_no
				   and sub_no  = vs_sub_no
				   and stk_cd  = i_stk_cd ;
			end if ;

			if vn_mov_lim_qty > 0 then

				update vn.ssb01m00
				set mov_lim_qty = 0
				where acnt_no = vs_acnt_no
				and sub_no  = vs_sub_no
				and stk_cd  = i_stk_cd ;

			end if;

			if  vn_own_qty > 0 then

				vn.pss_outbil_p(
				i_proc_dt,
				vs_agnc_brch,
				'5',
				vs_acnt_no,
				vs_sub_no,
				i_stk_cd,
				vn.fss_get_stk_nm( i_stk_cd),
				vn_own_qty,
				'',
				'',
				'',
				'220',
				i_work_mn,
				i_work_trm,
				vn.faa_acnt_bnh_cd_g( '3',vs_acnt_no, vs_sub_no),
				vo_trd_seq_no,
				vo_pre_rm,
				vo_now_rm
				);

				update  vn.srr02m00
				set     OUTQ_TRD_NO   = vo_trd_seq_no
				where    rgt_std_dt   =  i_std_dt
				and      stk_cd     =  i_stk_cd
				and      rgt_tp     =  '8'
				and      acnt_no    =  vs_acnt_no
				and      sub_no     =  vs_sub_no
				and      OUTQ_TRD_NO = 0 	    ;

			end if;
		end if;

    if i_proc_tp = '2' then
      /* Send SMS */
      -- Get language
      select decode(acnt_tp, 'F', 'E', 'V') msg_lang
      into vs_msg_lang
      from vn.aaa01m00
      where acnt_no = vs_acnt_no
      and sub_no = vs_sub_no;

      -- Get execution rate of cash dividend
      select trim(vn.fxc_format_number (rgt_iss_pri,0,vs_msg_lang)) || '%'
      into vs_iss_pri
      from vn.srr01m00
      where rgt_std_dt = i_std_dt
      and stk_cd = i_stk_cd
      and rgt_tp = i_rgt_tp
      and seq_no = i_seq_no;


      vs_fnc_cd := 'F02104';
      vs_dpo := trim(vn.fxc_format_number (o_dpo_nowrm,0,vs_msg_lang));
      vs_asn_amt := '+' || trim(vn.fxc_format_number (vn_asn_amt,0,vs_msg_lang));
--      if vs_msg_lang = 'V' then
--        vn.pxc_log_write('psr_rgt_inoutbil_p', 'tieng viet');
        vs_sms_msg := '||' || vs_acnt_no || '||' || vs_sub_no || '||' || vs_dpo || '||' || i_stk_cd
                      || '||' || vs_iss_pri || '||' || vs_asn_amt;
--      elsif vs_msg_lang = 'E' then
--        vn.pxc_log_write('psr_rgt_inoutbil_p', 'tieng anh');
--        vs_sms_msg := '||' || vs_acnt_no || '||' || vs_sub_no || '||' || vs_dpo || '||' || i_stk_cd
--                      || '||' || vs_iss_pri || '||' || vs_asn_amt;
--      end if;
      vn.pxc_log_write('psr_rgt_inoutmon_p', 'vs_sms_msg: ' || vs_sms_msg);

      vn.pxc_sms_ins(
        null,       --i_send_dt          in varchar2,                         -- can put NULL, get from sysdate
        null,       --i_recv_phone_no    in varchar2,                         -- can put NULL, get from account
        null,       --i_send_phone_no    in varchar2,                         -- can put NULL, get from company
        vs_fnc_cd,  --i_func_cd          in varchar2,                         -- NOT null
        null,       --i_msg_lang         in varchar2,                         -- can put NULL, get from account
        vs_sms_msg, --i_sms_msg          in varchar2,                         -- NOT null
        i_work_mn,  --i_work_mn          in varchar2,                         -- can put NULL
        i_work_trm, --i_work_trm         in varchar2,                         -- can put NULL
        vs_acnt_no, --i_acnt_no          in varchar2      default null,       -- can put NULL
        vs_sub_no   --i_sub_no           in varchar2      default null        -- can put NULL
      );
      /* Push notification */
      vn.pxc_notif_ins(
        vs_acnt_no, --i_acnt_no          in varchar2,    -- NOT NULL
        vs_sub_no,  --i_sub_no           in varchar2,    -- NOT NULL
        vs_fnc_cd,  --i_func_cd          in varchar2,    -- NOT null
        null,       --i_msg_lang         in varchar2,    -- can put NULL, get from account
        vs_sms_msg, --i_sms_msg          in varchar2,    -- NOT null
        '1',        --i_notif_tp         in varchar2,    -- NOT null
        i_work_mn,  --i_work_mn          in varchar2,    -- can put NULL
        i_work_trm  --i_work_trm         in varchar2     -- can put NULL
      );
    end if;

	end loop;

	update  vn.srr01m00
	set     rgt_proc_stat = '6'
	where   rgt_std_dt    = i_std_dt
	and     stk_cd        = i_stk_cd
	and     rgt_tp        = i_rgt_tp
    and     seq_no        = i_seq_no;


  elsif  i_proc_tp  = '3'  then   /* bond interest  */

    for  b1  in  (

        select   a.acnt_no  acnt_no,
                 a.sub_no   sub_no,
                 a.inter_amt  int_amt,
                 a.tax_asn  tax_amt,
                 a.acnt_mng_bnh acnt_mng_bnh ,
                 b.agnc_brch agnc_brch ,
                 NVL(b.bank_cnt_yn,'N') bank_cnt_yn ,
                 NVL(b.bank_cd,'') bank_cd
        from     vn.srr02m00 a ,
                 vn.aaa01m00 b
        where    a.rgt_std_dt    =  i_std_dt
        and      a.stk_cd        =  i_stk_cd
        and      a.rgt_tp        =  i_rgt_tp
        and      a.seq_no        =  i_seq_no
        and      a.inter_amt       >  0
        and      nvl(a.inter_trd_no,0)    =  0
        and      a.acnt_no = b.acnt_no
        and      a.sub_no  = b.sub_no

    ) loop


      vs_acnt_no       := b1.acnt_no;
      vs_sub_no        := b1.sub_no;
      vn_int_amt       := b1.int_amt;
      vn_tax_amt       := b1.tax_amt;
      vs_dept_no       := b1.acnt_mng_bnh;
      vs_bank_cd       := b1.bank_cd ;
      vs_agnc_brch     := b1.agnc_brch ;

      vn.pxc_log_write('psr_rgt_inoutmon_p', 'bond inter amt : '|| vs_acnt_no || ' ' || to_char ( vn_int_amt ) );

      vs_rmrk_cd  := '246';
      vs_tax_rmrk := '256';

      vn.pxc_log_write('psr_rgt_inoutmon_p', 'bank_cnt ' || b1.bank_cnt_yn||' '||vs_acnt_no);

      if b1.bank_cnt_yn = 'Y' then

        begin

        vn.psr_bat_bank(
					i_proc_dt ,
					vs_acnt_no ,
					vs_sub_no  ,
					vs_bank_cd ,
					vs_dept_no ,
					vs_agnc_brch ,
					vn_int_amt ,
					vn_tax_amt ,
					vs_rmrk_cd ,
					vs_tax_rmrk ,
					i_work_mn  ,
					i_work_trm ,
					i_stk_cd   ,
					0          ,
					i_std_dt   ,
					ts_job_tp  ,
					o_trd_seq_no ) ;

        exception
        when others then
             vn.pxc_log_write('psr_rgt_inoutmon_p', 'psr_bat_bank ['|| sqlcode ||']');
             o_trd_seq_no := 0;
        end;

     else

      begin
      vn.pcw_cash_inamt_p(
						i_proc_dt,
						vs_acnt_no,
						vs_sub_no,
						vs_rmrk_cd,
						vn_int_amt,
						'00',
						'BATCH',
						'Y',
						vs_dept_no,
						i_work_mn,
						i_work_trm,
						o_trd_dt,
						o_trd_seq_no,
						o_dpo_prerm,
						o_dpo_nowrm,
						o_acnt_place,
						o_bnhof_tp,
						o_proc_bnhof_tp
						);

      exception
      when others then
        vn.pxc_log_write('psr_rgt_inoutmon_p', 'asn '||vs_acnt_no||' pcw_cash_inamt_p ' || '['||sqlcode||']');
        o_trd_seq_no := 0;
      end;

      /* make aaa10m00 gga07m00 */
       begin
         vn.psr_his_tax_cr (
                            i_proc_dt
                            ,i_stk_cd
                            ,0
                            ,vs_acnt_no
                            ,vs_sub_no
                            ,vs_dept_no
                            ,vs_agnc_brch
                            ,vs_rmrk_cd
                            ,vn_int_amt
                            ,vs_tax_rmrk
                            ,vn_tax_amt
                            ,o_dpo_prerm
                            ,o_dpo_nowrm
                            ,i_work_mn
                            ,i_work_trm
                            ,o_trd_seq_no ) ;

       exception
       when others then
         vn.pxc_log_write('psr_rgt_inoutmon_p', vs_acnt_no||'['||sqlcode||']');
         o_trd_seq_no := 0;
       end;

    end if ;

	o_proc_cnt:= o_proc_cnt+1;
    /* processing profits to rt_reuse  */

    vn.psr_sbst_pay_p (
                        'c'          ,
                        vn_asn_amt ,
                        i_stk_cd     ,
                        vs_acnt_no   ,
                        vs_sub_no   ,
                        i_work_mn    ,
                        i_work_trm
                      )  ;


      update  vn.srr02m00
      set     inter_trd_no  = o_trd_seq_no
      where   rgt_std_dt  = i_std_dt
      and     stk_cd      = i_stk_cd
      and     rgt_tp      = i_rgt_tp
      and     seq_no      = i_seq_no
      and     acnt_no     = vs_acnt_no
      and     sub_no      = vs_sub_no;

    end loop;

    update  vn.srr01m00
    set     rgt_proc_stat = '6'
    where   rgt_std_dt    = i_std_dt
    and     stk_cd        = i_stk_cd
    and     rgt_tp        = i_rgt_tp
    and     seq_no        = i_seq_no;

 end if;

end  psr_rgt_inoutmon_p;
/

