create FUNCTION fdl_get_acnt_stk_bsk_lnd_limit(i_acnt_no   VARCHAR2,
                                                             i_sub_no    VARCHAR2,
                                                             i_basket_cd VARCHAR2,
                                                             i_stk_cd    VARCHAR2)
    RETURN NUMBER AS
    /*!
        \file     fdl_get_acnt_stk_bsk_lnd_limit.sql
        \brief    fdl_get_acnt_stk_bsk_lnd_limit
        \section intro Program Information
            - Program Name              :
            - Service Name              :
            - Related Client Program- Client Program ID :
            - Related Tables            : dlm71m03, ssi01m00, ssi08m00, dlm09m11
            - Dev. Date                 : 2018/05/21
            - Developer                 : GiangLH.
            - Business Logic Desc.      : fdl_get_acnt_stk_bsk_lnd_limit
            - Latest Modification Date  : 2018/05/21
    */
    t_acnt_get_grp_no VARCHAR2(20);
    t_acnt_no         VARCHAR2(10) := i_acnt_no;
    t_sub_no          VARCHAR2(2)  := i_sub_no;

    r_stk_max_amt     NUMBER := 0;
    c_stk_max_amt     NUMBER := 0;

    t_stk_max_amt   NUMBER := 0;
    t_stk_lnd_amt   NUMBER := 0;
    t_stk_lnd_limit NUMBER := 0;
    t_lnd_use_amt_pre NUMBER := 0;
    t_lnd_expt_amt_pre NUMBER := 0;

    t_vwdate            VARCHAR2(8)     := NULL;

    t_err_msg VARCHAR2(500);

BEGIN

    vn.pxc_log_write('fdl_get_acnt_stk_bsk_lnd_limit', '------- Start -------');
    --Lay ma nhom TK Margin
    t_acnt_get_grp_no := vn.faa_acnt_get_grp_no(i_acnt_no,
                                                i_sub_no,
                                                '2',
                                                vn.vwdate);
    vn.pxc_log_write('fdl_get_acnt_stk_bsk_lnd_limit', 'i_acnt_no= ' || i_acnt_no || ' i_sub_no= ' || i_sub_no ||
                                                        ' i_basket_cd= ' || i_basket_cd || ' i_stk_cd= ' || i_stk_cd ||
                                                        ' t_acnt_get_grp_no= '|| t_acnt_get_grp_no);

    --Lay CRS Ro DLM71M03
    BEGIN
        SELECT MAX(nvl(d3.lnd_limit_amt, 0))
        INTO r_stk_max_amt
        FROM vn.dlm71m03 d3
        WHERE d3.acnt_no = i_acnt_no
        AND d3.sub_no = i_sub_no
        AND d3.grp_acnt_no = t_acnt_get_grp_no
        AND d3.basket_cd = i_basket_cd
        AND d3.stk_cd = i_stk_cd
        AND d3.apy_dt <= vn.vwdate()
        AND d3.expr_dt >= vn.vwdate()
        AND d3.active_stat = 'Y';
    EXCEPTION
        WHEN OTHERS THEN
        t_err_msg := vn.fxc_get_err_msg('V', '46052');
        vn.pxc_log_write('fdl_get_acnt_stk_bsk_lnd_limit',
                        ' stk_cd error: ' || t_err_msg || ' stk_cd=' ||
                        i_stk_cd || '-' || i_acnt_no || '-' || i_sub_no);
        raise_application_error(-20100,
                                t_err_msg ||
                                ' fdl_get_acnt_stk_bsk_lnd_limit: stk_cd_i_tp=' ||
                                i_stk_cd || '-' || i_acnt_no || '-' ||
                                i_sub_no);
    END;

    -- 2. Nguoc lai lay theo chinh sach chung (SSI01M00, SSI01M00)
    IF r_stk_max_amt IS NOT NULL THEN
        t_stk_max_amt := r_stk_max_amt;
    ELSE
        IF i_basket_cd = '00000' THEN
        BEGIN
            SELECT nvl(lnd_limit_amt, 0)
            INTO c_stk_max_amt
            FROM vn.ssi01m00
            WHERE stk_cd = i_stk_cd;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
            c_stk_max_amt := 0;
        END;
        ELSE
        BEGIN
            SELECT nvl(lnd_limit_amt, 0)
            INTO c_stk_max_amt
            FROM vn.ssi08m00
            WHERE basket_cd = i_basket_cd
            AND stk_cd = i_stk_cd
            AND active_stat||bk_active in ('Y','M','D','A','WY','WA','WD');
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
            c_stk_max_amt := 0;
        END;
        END IF;
        t_stk_max_amt := nvl(c_stk_max_amt, 0);
    END IF;

    /*NHSV-1535: Check ket qua da book cua tk truoc do*/
    BEGIN
        SELECT SUM(nvl(lnd_use_amt, 0)), SUM(nvl(lnd_expt_amt, 0))
        INTO t_lnd_use_amt_pre,
            t_lnd_expt_amt_pre
        FROM vn.dlm09m11
        WHERE basket_cd = i_basket_cd
        AND stk_cd = i_stk_cd
        AND grp_acnt_no like t_acnt_get_grp_no
        AND acnt_no like i_acnt_no
        AND sub_no like i_sub_no;
    EXCEPTION
        WHEN OTHERS THEN
        t_lnd_use_amt_pre := 0;
        t_lnd_expt_amt_pre := 0;
    END;
    vn.pxc_log_write('fdl_get_acnt_stk_bsk_lnd_limit', 't_lnd_use_amt_pre= ' || t_lnd_use_amt_pre || ' - t_lnd_expt_amt_pre= ' || t_lnd_expt_amt_pre);

    --B2: Xac dinh so tien da dung:
    IF r_stk_max_amt IS NULL THEN
        t_acnt_get_grp_no   := '%';
        t_acnt_no           := '%';
        t_sub_no            := '%';
    END IF;

    BEGIN
        SELECT SUM(nvl(lnd_use_amt, 0)) + SUM(nvl(lnd_expt_amt, 0))
        INTO t_stk_lnd_amt
        FROM vn.dlm09m11
        WHERE basket_cd = i_basket_cd
        AND stk_cd = i_stk_cd
        AND grp_acnt_no like t_acnt_get_grp_no
        AND acnt_no like t_acnt_no
        AND sub_no like t_sub_no;
    EXCEPTION
        WHEN OTHERS THEN
        t_stk_lnd_amt := 0;
    END;

    t_stk_lnd_limit := greatest(0, nvl(t_stk_max_amt, 0) - nvl(t_stk_lnd_amt, 0));

    vn.pxc_log_write('fdl_get_acnt_stk_bsk_lnd_limit',
                        't_stk_max_amt= ' || t_stk_max_amt || ' - t_stk_lnd_amt= ' ||
                        t_stk_lnd_amt || ' - t_stk_lnd_limit= ' || t_stk_lnd_limit);

    vn.pxc_log_write('fdl_get_acnt_stk_bsk_lnd_limit', '------- End -------');

    RETURN t_stk_lnd_limit;

END fdl_get_acnt_stk_bsk_lnd_limit;
/

