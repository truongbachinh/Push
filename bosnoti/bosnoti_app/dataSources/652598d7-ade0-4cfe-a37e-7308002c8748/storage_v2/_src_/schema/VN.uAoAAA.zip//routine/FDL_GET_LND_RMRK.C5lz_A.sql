create function fdl_get_lnd_rmrk
(
	i_tp		in		varchar2,
	i_code		in 		varchar2
) return varchar2 as


begin

	if i_code ='702' then
     if i_tp ='1' then
        return '730';
     end if;
	elsif i_code ='712' then
     if i_tp ='1' then
        return '731';
     elsif i_tp ='2' then
        return '732';
     end if;
  elsif i_code ='718' then
     if i_tp ='1' then
        return '733';
     elsif i_tp ='2' then
        return '734';
     end if;
  elsif i_code ='714' then
     if i_tp ='1' then
        return '735';
     elsif i_tp ='2' then
        return '736';
     end if;
  elsif i_code ='722' then
     if i_tp ='1' then
        return '737';
     elsif i_tp ='2' then
        return '738';
     end if;
  elsif i_code ='728' then
     if i_tp ='1' then
        return '739';
     elsif i_tp ='2' then
        return '740';
     end if;
  elsif i_code ='724' then
     if i_tp ='1' then
        return '741';
     elsif i_tp ='2' then
        return '742';
     end if;
  elsif i_code ='762' then
     if i_tp ='1' then
        return '743';
     elsif i_tp ='2' then
        return '744';
     end if;
  elsif i_code ='764' then
     if i_tp ='1' then
        return '745';
     elsif i_tp ='2' then
        return '746';
     end if;
  elsif i_code ='772' then
     if i_tp ='1' then
        return '747';
     elsif i_tp ='2' then
        return '748';
     end if;
  elsif i_code ='778' then
     if i_tp ='1' then
        return '749';
     elsif i_tp ='2' then
        return '750';
     end if;
  elsif i_code ='774' then
     if i_tp ='1' then
        return '751';
     elsif i_tp ='2' then
        return '752';
     end if;
  end if;

  return i_code ;


end ;
/

