create function faa_idno_etc_tel_g
(
	i_idno		in		varchar2
) return varchar2 as

	o_val	varchar2(30);

/*!
   \file     faa_idno_etc_tel_g.sql
   \brief    etc contact telephone number return

   \section intro Program Information
        - Program Name              :  contact telephone number return
        - Service Name              :
        - Related Client Program- Client Program ID :
        - Related Tables            : aaa01m00 ,aaa02m10
        - Dev. Date                 : 2007/11/08
        - Developer                 : mkkim
        - Business Logic Desc.      :
                	input  : idno
					output :  telephone number return
        - Latest Modification Date  :

   \section history Program Modification History
    - 1.0  2007/11/08

   \section hardcoding Hard-Coding List

   \section info Additional Reference Comments

		if contact type's telephone is not exits, then mobile->office->home

*/
begin

	for c1 in (

		select	nvl(b.etc_tel,' ') etc_tel
		from	vn.aaa01m00 a ,
				vn.aaa02m10 b
		where	a.idno 	=	i_idno
		  and   a.idno  =   b.idno )loop

			return c1.etc_tel;
	end loop;


		return ' ';


end ;
/

