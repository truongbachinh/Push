create procedure  psr_rgt_flotq_asn_p
 (i_proc_tp    in       varchar2,
  i_std_dt     in       varchar2,
  i_stk_cd     in       varchar2,
  i_rgt_tp     in       varchar2,
  i_seq_no     in       number,
  i_work_mn    in       varchar2,
  i_work_trm   in       varchar2,
  o_proc_cnt   in out   number
 ) is

 vs_stk_cd         varchar2(12);
 vs_rgt_tp         varchar2(1) ;
 vn_rgt_asn_rt     number;
 vn_rgt_asn_rt2    number;
 vn_flotq_std_pri  number;
 vn_rgt_iss_pri    number;
 vn_asn_amt        number;
 vn_asn_qty        number;
 vn_flotq_amt      number;
 vn_seq_no         number;
 vn_cash_rate      number;
 vn_r_t_tp         varchar2(1);
 vn_round_tp       varchar2(4);

begin


 if i_proc_tp = 'I' then

    for  c1  in (

       select   stk_cd ,
		        rgt_tp ,
			    rgt_asn_rt       ,
				rgt_asn_pay_rt   ,
			    flotq_std_pri    ,
				rgt_iss_pri          ,
				seq_no               ,
				nvl(tax_rate,0 ) cash_rate      ,
				substr(NVL(Trim(round_tp),'t'),1,1)   r_t_tp    ,
				decode(nvl(round_tp, 't1'),'r1','0','r2','-1','r3' ,'-2' , 't1' , '0' ,'t2', '-1', '-2')  round_tp
       from     vn.srr01m00
       where    rgt_std_dt    =  i_std_dt
       and      stk_cd        =  i_stk_cd
       and      rgt_tp        =  i_rgt_tp
       and      seq_no        =  i_seq_no
       and      rgt_proc_stat <> '7'

    ) loop

         vs_stk_cd        := c1.stk_cd        ;
		 vs_rgt_tp        := c1.rgt_tp        ;
         vn_rgt_asn_rt    := c1.rgt_asn_rt    ;
         vn_rgt_asn_rt2   := c1.rgt_asn_pay_rt;
		 vn_flotq_std_pri := c1.flotq_std_pri ;
	     vn_rgt_iss_pri   := c1.rgt_iss_pri   ;
         vn_seq_no        := c1.seq_no        ;
		 vn_cash_rate     := c1.cash_rate     ;
		 vn_r_t_tp        := c1.r_t_tp        ;
		 vn_round_tp      := c1.round_tp      ;

/* default is trunc   */

         if vn_r_t_tp = '0' then
            vn_r_t_tp := 't' ;
         end if ;

		 if vn_rgt_asn_rt2 = 0 then
			vn_rgt_asn_rt2 := 1;
		 end if;

		 for  c2  in (

           select  acnt_no,
				   sub_no,
                   own_qty * (vn_rgt_asn_rt / vn_rgt_asn_rt2)
                        -  trunc( own_qty * (vn_rgt_asn_rt / vn_rgt_asn_rt2) , vn_round_tp)   flotq_qty
		   from    vn.srr02m00
           where   rgt_std_dt = i_std_dt
           and     stk_cd     = c1.stk_cd
	       and     rgt_tp     = c1.rgt_tp
		   and     seq_no     = c1.seq_no
           order by  acnt_no ,sub_no

         ) loop

             vn.pxc_log_write('psr_rgt_flotq_asn_p','flotq_qty '|| c2.flotq_qty);

             vn_flotq_amt :=  c2.flotq_qty * vn_flotq_std_pri
                                  - (c2.flotq_qty * vn_flotq_std_pri) * (vn_cash_rate / 100 ) ;

			 if vn_r_t_tp = 't' then
                vn_flotq_amt := trunc(vn_flotq_amt);
             else
                vn_flotq_amt := round(vn_flotq_amt);
             end if ;

			 update  vn.srr02m00
		     set     flotq_amt    = vn_flotq_amt
		     where   rgt_std_dt   = i_std_dt
		     and     stk_cd       = vs_stk_cd
		     and     rgt_tp       = vs_rgt_tp
			 and     seq_no       = vn_seq_no
			 and     acnt_no      = c2.acnt_no
			 and     sub_no       = c2.sub_no;

         end loop;

	 end loop;

 else

    for  d1  in (

       select   stk_cd,
		        rgt_tp,
			    rgt_asn_rt,
			    flotq_std_pri,
				seq_no
       from     vn.srr01m00
       where    rgt_std_dt    =  i_std_dt
       and      stk_cd      like i_stk_cd
       and      rgt_tp      like i_rgt_tp
	   and      seq_no      like i_seq_no
       and      rgt_proc_stat <> '7'

    ) loop

		 update  vn.srr02m00
		 set     flotq_amt    = 0
		 where   rgt_std_dt   = i_std_dt
		 and     stk_cd       = d1.stk_cd
		 and     rgt_tp       = d1.rgt_tp
		 and     seq_no       = d1.seq_no;

	end loop;

 end if;

end  psr_rgt_flotq_asn_p;
/

