create function fdl_get_acnt_sub_limit(
  i_acnt_no   in  varchar2,
  i_sub_no    in  varchar2
  ) return number   as

  /*!
     \file     fdl_get_acnt_sub_limit.sql
     \brief    fdl_get_acnt_sub_limit
     \section intro Program Information
          - Program Name              :
          - Service Name              :
          - Related Client Program- Client Program ID :
          - Related Tables            : dlm20m05, dlm00m01
          - Dev. Date                 : 2021/07/16
          - Developer                 : TienLH.
          - Business Logic Desc.      : fdl_get_acnt_sub_limit
          - Modify by                 :
          - Latest Modification Date  :
   */

  t_acnt_csr_amt         number := 0 ;
  t_acnt_sub_limit       number := 0 ;
  t_acc_grp_mrgn_limit   number := 0 ;
  t_acnt_limit           number := 0 ;
  t_err_msg              varchar2(500);

begin

    BEGIN
        vn.pdl_get_lnd_all_sub_limit(i_acnt_no, t_acnt_limit);
    END;

    BEGIN
        SELECT MIN(nvl(d5.acnt_max_amt, 0))
        INTO t_acnt_csr_amt
        FROM vn.dlm20m05 d5 -- chinh sach rieng cua han muc tk
        WHERE d5.acnt_no = i_acnt_no
            AND d5.sub_no = i_sub_no
            AND d5.apy_dt <= vn.vhdate
            AND d5.expr_dt >= vn.vhdate
            AND d5.active_stat = 'Y';
    EXCEPTION
    WHEN OTHERS THEN
        t_err_msg := vn.fxc_get_err_msg('V', '46051');
        vn.pxc_log_write('fdl_get_acnt_sub_limit',
                        ' Chinh sach rieng error: ' || t_err_msg || ' ACNT_NO=' ||
                        i_acnt_no || '-' || i_sub_no );
        raise_application_error(-20100,
                                t_err_msg ||
                                ' fdl_get_acnt_sub_limit: csr ACNT_NO =' ||
                                i_acnt_no || '-' || i_sub_no );
    END;

    IF t_acnt_csr_amt IS NOT NULL THEN
        t_acnt_sub_limit := LEAST(t_acnt_limit, t_acnt_csr_amt);
    ELSE
        BEGIN
            SELECT nvl(a.acc_lnd_lmit, 0)
            INTO t_acc_grp_mrgn_limit         /*B*/
            FROM vn.dlm00m01 a
            WHERE a.item_cd like vn.faa_acnt_get_grp_no(i_acnt_no, i_sub_no, '2', vn.vhdate)
                AND a.active_stat like 'Y'
                AND a.item_tp = '08';
        EXCEPTION
            WHEN no_data_found THEN
                t_acc_grp_mrgn_limit := 0;
            WHEN OTHERS THEN
                t_err_msg := vn.fxc_get_err_msg('V', '461000');
                vn.pxc_log_write('fdl_get_acnt_sub_limit',
                                    ' Select dlm00m01 error: ' || t_err_msg ||
                                    ' ACNT_NO=' || i_acnt_no || '-' || i_sub_no || '-' ||
                                    '08' );
        END;
        t_acnt_sub_limit := LEAST(t_acnt_limit, t_acc_grp_mrgn_limit);
    END IF;

    return t_acnt_sub_limit;

end fdl_get_acnt_sub_limit;
/

