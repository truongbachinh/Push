create function fdl_get_avlb_multi
(
    i_lnd_tp       in   varchar2,
    i_lnd_bank_cd  in   varchar2,
    i_stk_cd       in   varchar2,
    i_lnd_dt       in   varchar2
)
    return  number
as
	o_lnd_avlb_multi    number;
	t_lnd_avlb_multi	number;
	t_bnk_avlb_multi	number;
	t_found				varchar2(1) := 'N';


begin

/*============================================================================*/
/* Valiabl Initialize                                                         */
/*============================================================================*/
    o_lnd_avlb_multi  :=  0;
    t_lnd_avlb_multi  :=  0;
    t_bnk_avlb_multi  :=  0;

/*============================================================================*/
/* generl commission return                                                   */
/*============================================================================*/

	for c1 in (
		select  NVL(lnd_avlb_eval_multi,0)   lnd_avlb_eval_multi
		  from  vn.dlm12m00
		 where  lnd_bank_cd  =  i_lnd_bank_cd
           and  apy_dt       =  (select  max(apy_dt)
	                               from  vn.dlm12m00
	                              where  lnd_bank_cd  in  ('0000',i_lnd_bank_cd)
    	                            and  apy_dt       <=  i_lnd_dt)
	     order  by apy_dt desc
	) loop
	    for c2 IN (
	        select  nvl(lnd_avlb_multi,0) lnd_avlb_multi
	          from  vn.dlm11m10
	         where  lnd_bank_cd  in  ('0000',i_lnd_bank_cd)
               and  lnd_tp        =  i_lnd_tp
	           and  stk_cd        =  i_stk_cd
	           and  del_yn        =  'N'
	           and  apy_dt        =  (select  max(apy_dt)
	                                     from  vn.dlm11m10
	                                    where  lnd_bank_cd  in  ('0000',i_lnd_bank_cd)
	                                      and  lnd_tp        =  i_lnd_tp
	                                      and  stk_cd        =  i_stk_cd
	                                      and  del_yn        =  'N'
		    	                          and  apy_dt       <=  i_lnd_dt)
	         order  by apy_dt desc
	    ) loop

			if c2.lnd_avlb_multi   =  0 then
				t_lnd_avlb_multi  :=  c1.lnd_avlb_eval_multi;
			else
				t_lnd_avlb_multi  :=  c2.lnd_avlb_multi;
			end if;

			t_found  :=  'Y';

		end loop;

		/* t_bnk_avlb_multi  :=  c1.lnd_avlb_eval_multi; */
    end loop;

	if t_found = 'Y' then
		o_lnd_avlb_multi  :=  t_lnd_avlb_multi;
	else
		o_lnd_avlb_multi  :=  t_bnk_avlb_multi;
	end if;

    return o_lnd_avlb_multi;

end fdl_get_avlb_multi;
/

