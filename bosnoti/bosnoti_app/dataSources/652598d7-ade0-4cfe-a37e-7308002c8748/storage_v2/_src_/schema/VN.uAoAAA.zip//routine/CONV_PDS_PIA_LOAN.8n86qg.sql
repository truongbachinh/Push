create PROCEDURE conv_pds_pia_loan
    ( i_dt          IN     VARCHAR2,        --
      i_work_mn     IN     VARCHAR2,
      i_work_trm    IN     VARCHAR2,
      o_cnt         IN OUT NUMBER
    ) AS
/*============================================================================*/
-- 1. Process Name : conv_pds_pia_loan                                       --
-- 2. Process func : margin data conversion                                   --
-- 3. developer    :                                                          --
-- 4. modifier     :                                                          --
-- 5. note         :                                                          --
/*============================================================================*/

/*!
   \file     conv_pds_pia_loan.sql
   \brief    margin data conversion

   \section intro Program Information
        - Program Name              : margin data conversion
        - Service Name              :
        - Related Client Program- Client Program ID :
        - Related Tables            : dlm08h00 / dlm08m00 /
                                      dlm01m00 / dlm01m10 /
        - Dev. Date                 : 2011/10/01
        - Developer                 : Han.
        - Business Logic Desc.      : margin data conversion
        - Latest Modification Date  : 2011/10/01

   \section history Program Modification History
    - 1.0       2011/10/01     Han.    New.

   \section hardcoding Hard-Coding List
    - HC-1      2011/10/01     Han.    [»çÀ¯]

   \section info Additional Reference Comments
    -

var o_cnt number;
exec conv_pds_pia_loan('20130104','CONV','CONV',:o_cnt);
print o_cnt

*/

    t_acnt_cnt         NUMBER       :=  0;
    t_acnt_skip        NUMBER       :=  0;
    t_sub_cnt          NUMBER       :=  0;
    t_cnt              NUMBER       :=  0;

    ts_emp_no          VARCHAR2(100):=  NULL;
    ts_acnt_no         VARCHAR2(10) :=  NULL;
    ts_sub_no          VARCHAR2(02) :=  NULL;
    ts_sub_no1         VARCHAR2(02) :=  NULL;

    t_lnd_cntr_no      VARCHAR2(12) :=  NULL;
    t_lnd_cntr_no2     VARCHAR2(04) :=  NULL;
    t_trd_tp           VARCHAR2(02) :=  NULL;
    t_rmrk_cd          VARCHAR2(03) :=  NULL;
    t_acnt_tp          VARCHAR2(01) :=  NULL;

    t_sell_mth_qty     NUMBER       :=  0;
    t_mrtg_rm_qty      NUMBER       :=  0;
    t_own_qty          NUMBER       :=  0;
    t_book_pri         NUMBER       :=  0;
    t_mrtg_book_amt    NUMBER       :=  0;
    t_org_lnd_pri      NUMBER       :=  0;
    t_sell_rpy_amt     NUMBER       :=  0;
    t_lnd_rm_amt       NUMBER       :=  0;

    t_trd_seq_no       NUMBER       :=  0;
    t_tot_seq_no       NUMBER       :=  0;
    t_tot_preqty       NUMBER       :=  0;
    t_tot_nowqty       NUMBER       :=  0;

    t_dpo              NUMBER       :=  0;
    t_block_ds_amt     NUMBER       :=  0;
    t_block_dl_amt     NUMBER       :=  0;
    t_used_alowa_cd    NUMBER       :=  0;
    t_nonrpy_loan_amt  NUMBER       :=  0;
    t_tot_out_psbamt   NUMBER       :=  0;
    t_rpyable_amt      NUMBER       :=  0;

    t_dpo_prerm        NUMBER       :=  0;
    t_dpo_nowrm        NUMBER       :=  0;


    t_out_trd_dt       VARCHAR2(10) :=  NULL;
    t_out_trd_seq_no   NUMBER       :=  0;
    t_out_dpo_prerm    NUMBER       :=  0;
    t_out_dpo_nowrm    NUMBER       :=  0;
    t_out_acnt_place   VARCHAR2(20) :=  NULL;
    t_out_bnhof_tp     VARCHAR2(20) :=  NULL;
    t_out_proc_bnhof_tp VARCHAR2(20) := NULL;

    t_sqlcode          NUMBER       := 0;
    t_err_msg          VARCHAR2(500);

BEGIN

    o_cnt           :=  0;

    t_acnt_cnt      :=  0;
    t_acnt_skip     :=  0;
    t_sub_cnt       :=  0;

    /*========================================================================*/
    /* Check Batch job Control                                                */
    /*========================================================================*/
    /*========================================================================*/
    /* Input Date CHECK                                                       */
    /*========================================================================*/
    /*========================================================================*/
    /* Prededing job Check                                                    */
    /*========================================================================*/

/*============================================================================*/
/* ( Calculateion )                                                           */
/*============================================================================*/
    vn.pxc_log_write('conv_pds_pia_loan', 'Start : '||i_dt);

    FOR C2 IN (
        SELECT  a.acnt_no
             ,  a.sub_no
          FROM  vn.aaa01m00 a
         WHERE  a.sub_no    = '01'
    ) LOOP

        FOR C1 IN (
            SELECT  a.lnd_tp
                 ,  a.acnt_no
                 ,  a.sub_no
                 ,  a.lnd_dt
                 ,  a.mth_dt
                 ,  a.lnd_bank_cd
                 ,  a.stk_cd
                 ,  a.setl_dt
                 ,  a.mrtg_lnd_qty
                 ,  a.mrtg_rpy_qty
                 ,  a.lnd_amt
                 ,  a.lnd_rpy_amt
                 ,  a.lnd_int_rt
                 ,  a.lnd_cmsn_rt
                 ,  a.last_rpy_dt
                 ,  a.expr_dt
                 ,  a.setl_bank_cd
                 ,  a.lnd_acpt_tp
                 ,  a.lnd_cntr_no
                 ,  a.acnt_mng_bnh
                 ,  a.agnc_brch
                 ,  a.work_bnh
                 ,  a.proc_agnc_brch
              FROM  vn.dlm01m00 a
             WHERE  a.lnd_tp       IN ('10')
               AND  a.lnd_amt - a.lnd_rpy_amt > 0
               and  a.acnt_no   = C2.acnt_no
               and  a.sub_no   = '00'
             ORDER  BY a.acnt_no, a.sub_no, a.lnd_tp, a.lnd_dt, a.mth_dt, a.lnd_bank_cd, a.stk_cd
        ) LOOP

            o_cnt      := o_cnt + 1;

            vn.pxc_log_write('conv_pds_pia_loan', ' Info :'||' Count =' || o_cnt
                                                           ||' ACNT='|| C1.acnt_no
                                                           ||'-'||C1.sub_no
                                                           ||'-'||C1.lnd_tp
                                                           ||'-'||C1.stk_cd
                                                           ||'-'||C1.lnd_dt
                                                           );

                /*========================================================================*/
                /* Margin Account History (dlm08h00)                                      */
                /*========================================================================*/

                /*========================================================================*/
                /* 1. Create the margin level of sub account (dlm08m00)                   */
                /*========================================================================*/


                    /*========================================================================*/
                    /* Create of Sub Account infomation (aaa01m00/cwd01m00)                   */
                    /*========================================================================*/





                      

                /*====================================================================*/
                /* Update (dlm01m00 )                                                 */
                /*====================================================================*/
                BEGIN
                UPDATE  vn.dlm01m00
                   SET  sub_no       =  '01'
                 WHERE  lnd_tp       =  C1.lnd_tp
                   AND  acnt_no      =  C2.acnt_no
                   AND  sub_no       =  '00'
                   AND  lnd_dt       =  C1.lnd_dt
                   AND  mth_dt       =  C1.mth_dt
                   AND  setl_dt      =  C1.setl_dt
                   AND  lnd_bank_cd  =  C1.lnd_bank_cd
                   AND  stk_cd       =  C1.stk_cd
                   AND  lnd_acpt_tp  =  '01'
                ;
                EXCEPTION
                WHEN OTHERS THEN
                    t_sqlcode := sqlcode;
                    t_err_msg := sqlerrm;
                    vn.pxc_log_write('conv_pds_pia_loan', ' 4.UPD dlm01m00 :'||' ACNT   ='||C1.acnt_no
                                                                              ||'-'||C1.sub_no
                                                                              ||'-'||C1.lnd_dt
                                                                              ||'-'||C1.stk_cd
                                                                              ||'-'||t_lnd_rm_amt
                                                                              ||' SQLCODE ='||t_sqlcode);
                    t_err_msg := vn.fxc_get_err_msg('V','2713')||t_err_msg;
                    raise_application_error(-20100,t_err_msg);
                END;





            /*========================================================================*/
            /* 5. Modify the settlement list (dsc01m00) - main -> sub account         */
            /*========================================================================*/

        END LOOP;  /* C1 */

    END LOOP;  /* C2 */

    vn.pxc_log_write('conv_pds_pia_loan', 'Count1:'||' Total Count = '||o_cnt
                                                    ||' Acnt  Count = '||t_acnt_cnt
                                                    ||' Sub   Count = '||t_sub_cnt
                                                    ||' Skip  Count = '||t_acnt_skip);

    vn.pxc_log_write('conv_pds_pia_loan', 'End 1 : '||i_dt);

END conv_pds_pia_loan;
/

