create procedure fcw_check_trans_bank_deposit
(
  is_acnt_no      in    varchar2,
  is_sub_no       in    varchar2,
  i_org_trd_no    in    varchar2,
  os_check          in out  varchar2
) as

 t_proc_nm                         varchar2(50);
 t_rmrk_cd                         varchar2(100);
 t_trd_amt                         varchar2(100);
 t_acc_act_cd                      varchar2(100);
 t_cnte                            varchar2(500);
 t_etc_seq_no                      varchar2(500);
 t_bank_cd_off                     varchar2(100);
 t_bank_acnt_no                    varchar2(100);
 t_dpo_bank_acc                    varchar2(100);
 t_err_txt                          varchar2(100);
 t_seq_no                           varchar2(100);
 t_count_check                      number ;

    t_err_msg    varchar2(500);


begin
t_count_check := 0;
begin
    select  t.seq_no
             ,  t.rmrk_cd
             ,  t.trd_amt
             ,  nvl(trim(t.acc_act_cd),'')
             ,  t.cnte
             ,  t.etc_seq_no
             ,  nvl(trim(t.bank_cd_off),'')
             ,  nvl(trim(t.bank_acnt_no),'')
             ,  nvl(trim(t.dpo_bank_acc),'')
          into  t_seq_no,
                t_rmrk_cd,
                t_trd_amt,
                t_acc_act_cd,
                t_cnte,
                t_etc_seq_no,
                t_bank_cd_off,
                t_bank_acnt_no,
                t_dpo_bank_acc
          from  vn.cwd06m00 t
         where  acnt_no  =  is_acnt_no
           and  sub_no   =  is_sub_no
           and  cncl_yn = 'N'
           and  trd_seq_no = i_org_trd_no
           and to_char(WORK_DTM, 'yyyymmdd')=vn.vhdate;
    EXCEPTION
       when  NO_DATA_FOUND  then
         os_check :='Y';
        WHEN  OTHERS         THEN
            t_err_msg  :=  t_proc_nm
                   ||  ' cwd06m00 select error :'
                   ||  to_char(sqlcode);
      t_err_msg := vn.fxc_get_err_msg('V','2001');
      raise_application_error(-20100,t_err_msg||t_err_txt);
    END;

    if t_rmrk_cd ='026' then
      begin
      select count(*) into t_count_check from cwd11m00
      where std_dt =vn.vhdate
           and acnt_no=is_acnt_no
           and sub_no = is_sub_no
           and RMRK_CD='026'
           and trd_seq_no='1'
           and SENDED_STAT='1';
           EXCEPTION
        WHEN  OTHERS         THEN
            t_err_msg  :=  t_proc_nm
                   ||  ' cwd11m00 select error :'
                   ||  to_char(sqlcode);
      t_err_msg := vn.fxc_get_err_msg('V','2001');
      raise_application_error(-20100,t_err_msg||t_err_txt);
    END;
    if t_count_check >0 then
      os_check :='N';
      else
        os_check :='Y';
        end if;
      else
        os_check :='Y';
        end if;

end fcw_check_trans_bank_deposit;
/

