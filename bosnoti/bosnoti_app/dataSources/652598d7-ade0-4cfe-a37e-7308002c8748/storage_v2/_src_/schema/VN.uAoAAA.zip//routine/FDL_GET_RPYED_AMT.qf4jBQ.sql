create FUNCTION fdl_get_rpyed_amt
(
    i_lnd_tp         IN   VARCHAR2,
    i_acnt_no        IN   VARCHAR2,
    i_sub_no         IN   VARCHAR2,
    i_bank_cd        IN   VARCHAR2,
    i_dt             IN   VARCHAR2,
    i_tp             IN   VARCHAR2
)   RETURN  NUMBER AS

    t_rpyed_amt         NUMBER  := 0 ;

    t_err_txt           VARCHAR2(80) ; -- error text buffer
BEGIN

/*============================================================================*/
/* Valiabl Initialize                                                         */
/*============================================================================*/
    t_rpyed_amt  :=  0;

/*============================================================================*/
/* repaid amount and interest return                                          */
/*============================================================================*/
    /*========================================================================*/
    /* i_tp                                                                   */
    /* 1 : repayment by selling                                               */
    /* 2 : repayment by cash                                                  */
    /* % : repayment by total                                                 */
    /*========================================================================*/
    FOR C1 IN (
        SELECT  lnd_tp
             ,  acnt_no
             ,  sub_no
             ,  lnd_bank_cd
             ,  sum(nvl(lnd_rpy_amt,0))  lnd_rpy_amt
             ,  sum(nvl(lnd_int,0))      lnd_int
             ,  sum(nvl(lnd_cmsn,0))     lnd_cmsn
             ,  sum(nvl(lnd_int_dly,0))  lnd_int_dly
             ,  sum(nvl(lnd_cmsn_dly,0)) lnd_cmsn_dly
          FROM  vn.dlm01m10
         WHERE  lnd_tp         =  i_lnd_tp
           AND  acnt_no        =  i_acnt_no
           AND  sub_no         =  i_sub_no
           AND  lnd_rpy_dt     =  i_dt
           AND  lnd_rpy_tp  LIKE  DECODE(i_tp, '1', DECODE(i_lnd_tp, '10', '11'
                                                                   , '20', '23'
                                                                   , '30', '33'
                                                                   , '50', '53'
                                                          )
                                             , '2', DECODE(i_lnd_tp, '10', '12'
                                                                   , '20', '22'
                                                                   , '30', '32'
                                                                   , '50', '52'
                                                          )
                                             , '3', '%'
                                         )
         GROUP  BY  lnd_tp, acnt_no,  sub_no, lnd_bank_cd
    ) LOOP

        t_rpyed_amt  := t_rpyed_amt + C1.lnd_rpy_amt
                      + C1.lnd_int + C1.lnd_cmsn
                      + C1.lnd_int_dly + C1.lnd_cmsn_dly;

    END LOOP;



    RETURN t_rpyed_amt;

END fdl_get_rpyed_amt;
/

