create function faa_tax_tp_g
(
  i_acnt_no    in    varchar2,
  i_sub_no     in    varchar2
) return varchar2 as

  o_val  number := 0 ;

/*!
   \file     faa_tax_tp_g.sql
   \brief    P /  institution / Domestic  type account don't have tax

   \section intro Program Information
        - Program Name              :  P /  institution / Domestic  type account don't have tax
        - Service Name              :
        - Related Client Program- Client Program ID :
        - Related Tables            : aaa01m00 ,aaa02m00
        - Dev. Date                 : 2006/01/06
        - Developer                 : lehiep
        - Business Logic Desc.      :
                  input  : acnt_no
          output : 0
               1
        - Latest Modification Date  :


*/
begin

  begin

  select  a.calc_tax_yn
  into  o_val
  from  vn.aaa01m00 a,
      vn.aaa02m00 b
  where  a.acnt_no   =  i_acnt_no
  and     a.sub_no    =   i_sub_no
  and     a.idno     =   b.idno  ;

  return o_val;

  exception
  when   no_data_found then
    return   '0';
  when  others then
    return '0' ;
  end;


end ;
/

