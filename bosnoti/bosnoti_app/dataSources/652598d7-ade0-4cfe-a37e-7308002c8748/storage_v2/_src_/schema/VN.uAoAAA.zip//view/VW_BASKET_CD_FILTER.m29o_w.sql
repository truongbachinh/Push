create view VW_BASKET_CD_FILTER as
select '00000' as item_cd, 'Ro Uy ban' as item_name
  from dual
union
select distinct t.item_cd, t.item_name
  from vn.dlm00m01 t
 where t.item_tp = '06'
   and t.active_stat = 'Y'
 order by 1
/

