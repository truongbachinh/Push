create function    fdl_get_other_fee_info(
    i_dt            varchar2,
    i_stk_tp        varchar2,
    i_mkt_trd_tp    varchar2,
    i_apy_rt_tp     varchar2,
    i_ret_tp        varchar2        -- 1: rnge_lrgest_val   2: rnge_min_val     3: apy_val      4: add_val
)
return number
    /* 
        select fdl_get_other_fee_info(
            vwdate,     -- i_dt            varchar2,
            '10',       -- i_stk_tp        varchar2,
            'CPT',      -- i_apy_rt_tp     varchar2,
            '3'         -- i_ret_tp        varchar2        -- 1: rnge_lrgest_val   2: rnge_min_val     3: apy_val      4: add_val
        ) ret
        from dual;
    */
as
    t_proc_nm       varchar2(30)    := 'fdl_get_other_fee_info';
    t_err_msg       varchar2(100)   := ' ';

    t_apy_rt_tp     varchar2(3)     := i_apy_rt_tp;
    o_ret           number          := 0;

begin
    -- Get apy_rt_tp when i_apy_rt_tp is null
    if(i_apy_rt_tp is null) then
        select
            case 
                when i_stk_tp = '20'
                    then 'TPT'
                when i_stk_tp in ('10', '30') and i_mkt_trd_tp in ('05', '06')
                    then 'UPT'
                when i_stk_tp in ('10', '30') and i_mkt_trd_tp not in ('05', '06')
                    then 'CPT'
                when i_stk_tp = '70'
                    then 'CQT'
                when i_stk_tp = '40'
                    then 'ETF'
                else
                    'CPT'
            end apy_rt_tp
        into t_apy_rt_tp
        from dual;
    end if;

    -- Get fee value
    begin
        select
            decode (i_ret_tp,   '1', rnge_lrgest_val,
                                '2', rnge_min_val,
                                '3', apy_val,
                                '4', addl_val
                    ) ret
        into o_ret
        from vn.dsc08m00
        where apy_rt_tp   =  t_apy_rt_tp
        and  apy_yn      =  'Y'
        and  apy_dt      =  (select  max(apy_dt)
                            from  vn.dsc08m00
                            where  apy_rt_tp  =  t_apy_rt_tp
                            and  apy_yn     =  'Y'
                            and  apy_dt    <=  i_dt);
	exception
        when no_data_found then
            o_ret    := 0;
        when others then
            t_err_msg   := 'Error when getting data'
                        || ' sqlcode= ' || sqlcode
                        || ' sqlerrm= ' || sqlerrm;

            vn.pxc_log_write(t_proc_nm, t_err_msg);
            raise_application_error(-20100, t_err_msg);
    end;

    return o_ret;

end fdl_get_other_fee_info;
/

