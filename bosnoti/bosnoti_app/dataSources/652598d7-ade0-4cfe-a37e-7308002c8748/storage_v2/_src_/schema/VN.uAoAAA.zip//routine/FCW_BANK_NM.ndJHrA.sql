create function fcw_bank_nm
(
  i_bank_cd  in   varchar2
) return varchar2 as

  ts_bank_cd  varchar2(100);
  ts_bank_nm  varchar2(300);
  ti_count number := 0;

begin
  
  ti_count:= instr(i_bank_cd,'-');
  
  if ti_count > 0 then

     ts_bank_cd := trim(substr(i_bank_cd,1, instr(i_bank_cd,'-')-1 ));
  else
     
     ts_bank_cd := i_bank_cd ;    
  end if;

  if length(ts_bank_cd) = 0 or ts_bank_cd is null then
     ts_bank_nm := '!'; 
  elsif length(ts_bank_cd) = 4 then
      if ts_bank_cd in ('0000') then
        return '!';
      else
        for C1 IN (
            select lnd_bank_nm
            from  vn.dlm12m00
           where  lnd_bank_cd  =  ts_bank_cd
             and  apy_dt       =  (select  max(apy_dt)
                                     from  vn.dlm12m00
                                    where  lnd_bank_cd  =  ts_bank_cd)
           order  by apy_dt desc
        ) loop
            ts_bank_nm := C1.lnd_bank_nm;
            return ts_bank_nm;
        end loop;

          return '!';
      end if;
  else   
    
      begin
        
        select distinct t.acc_bank_acnt_nm
        into ts_bank_nm
        from vn.gga13t00 t
        where acc_act_cd = ts_bank_cd;
        
            return ts_bank_nm;
            
        exception
        when	 no_data_found then
               return 	'!';
      end;
    
  end if;  
  
    return ts_bank_nm;

end fcw_bank_nm;
/

