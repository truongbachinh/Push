create function faa_order_vip_g
(
	i_acnt_no		in		varchar2,
	i_sub_no		in		varchar2
) return varchar2 as

	o_tp	varchar2(1);

/* ===========================================
	-- Program ID 		: 	faa_order_vip_g
	-- Date of Program	: 	08/06/2009
	-- Programmer		:	mkkim
	-- Description 		:
			*input  :
				i_tp = 1  : Vietnamese country name
				i_tp = 2  : English   country name
			*return : contry name
   =========================================== */

begin

		begin
		  select nvl(a.order_vip,'N')
		into	o_tp
		from	vn.aaa03c30 a ,
				vn.aaa01m00 b
		where	b.acnt_no	=	trim(i_acnt_no )
		and     b.sub_no    =   i_sub_no
		and		b.LEVEL_TP 	=   a.LEVEL_TP
		and     a.col_tp = '1' ;

		exception
		when	 no_data_found then
			return 	'N';
		end;

		return o_tp ;

end ;
/

