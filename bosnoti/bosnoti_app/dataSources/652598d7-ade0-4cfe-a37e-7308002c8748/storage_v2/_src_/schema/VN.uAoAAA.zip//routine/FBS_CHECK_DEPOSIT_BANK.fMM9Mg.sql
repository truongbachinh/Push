create function fbs_check_deposit_bank
(
	i_acnt_no		in		varchar2,
	i_sub_no		in		varchar2
) return varchar2 as
  o_amt_dsc10m00 number;
  o_amt_cww02m10 number;
  o_amt_tso02m00 number;
/* ===========================================
	-- Program ID 		: 	fbs_check_deposit_bank
	-- Date of Program	: 	09/06/2017
	-- Programmer		:	hieudt
	-- Description 		:
			input  :  Account Number
			return :  deposit Y/N
   =========================================== */
begin
begin
	select amt_dsc10m00,
         amt_cww02m10,
         amt_tso02m00
         into 
         o_amt_dsc10m00,
         o_amt_cww02m10,
         o_amt_tso02m00
from
(select acnt_no acnt_no_dsc10m00, sum (t.adj_amt) amt_dsc10m00 from dsc10m00 t
where mth_dt = vn.vwdate
and t.job_tp = '1'
and t.sb_tp = '2' 
and bank_cd = '0002'
and sub_no = '00'
and t.scrt_err_cd = '2475'
group by acnt_no 
order by acnt_no) a,
(select acnt_no acnt_no_cww02m10, sum(proof) amt_cww02m10 from cww02m10 t
where trd_dt = vn.vwdate
and valid_YN = 'Y'
and acnt_no in (select acnt_no from dsc10m00 t
                where mth_dt = vn.vwdate
                and t.job_tp = '1'
                and t.sb_tp = '2' 
                and bank_cd = '0002'
                and t.scrt_err_cd = '2475')
and sub_no = '00'                
group by acnt_no                 
order by acnt_no) b,
(select acnt_no acnt_no_tso02m00, sum(t.td_cash_prof_amt) amt_tso02m00 from tso02m00 t
where acnt_no in (select acnt_no from dsc10m00 t
                where mth_dt = vn.vwdate
                and t.job_tp = '1'
                and t.sb_tp = '2' 
                and bank_cd = '0002'
                and t.scrt_err_cd = '2475')
and sub_no = '00'                
group by acnt_no        
order by acnt_no) c
where a.acnt_no_dsc10m00 = b.acnt_no_cww02m10
and a.acnt_no_dsc10m00 = c.acnt_no_tso02m00
and a.acnt_no_dsc10m00 = i_acnt_no
 ;
if o_amt_dsc10m00 = o_amt_cww02m10 and o_amt_dsc10m00 = o_amt_tso02m00 then
return 'Y';
else 
return 'N';
end if;
		

	exception
	when	 no_data_found then
		return 	'N';
	end;
  


end ;
/

