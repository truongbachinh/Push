create FUNCTION faa_new_sub_generate(i_acnt_no IN VARCHAR2)
  RETURN VARCHAR2 IS

  t_new_sub VARCHAR2(2);
  t_sub_tmp VARCHAR2(2);

  /*
  Tran.Nguyen Add New For NewCore - Used for screen 01212
  */
BEGIN

  BEGIN
    SELECT MAX(a.sub_no)
      INTO t_sub_tmp
      FROM vn.aaa01m00 a
     WHERE a.acnt_no = i_acnt_no
       AND a.sub_no <> '80'; /* Loai bo sub 80 danh cho Phai sinh */
  EXCEPTION
    WHEN OTHERS THEN
      t_sub_tmp := '01';
  END;

  IF t_sub_tmp = '79' THEN
    t_sub_tmp := '80';
  END IF;

  /* New sub_no */
  t_new_sub := lpad(to_number(t_sub_tmp) + 1, 2, '0');

  RETURN t_new_sub;

END faa_new_sub_generate;
/

