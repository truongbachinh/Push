create trigger TSO03M00_LOGGING
    after update
    on TSO03M00
    for each row
declare
  -- local variables here
begin
  Begin
    insert into TSO03m00_log
    values
      (:old.sb_kfx_tp,
       :old.stk_tp,
       :old.mkt_main_sts,
       :old.mkt_drv_tp,
       :old.sb_kfx_tp,
       :old.stk_tp,
       :old.mkt_main_sts,
       :old.mkt_drv_tp,
       user,
       sysdate);
  exception
    when others then
      null;
  end;
end TSO03M00_logging;
/

