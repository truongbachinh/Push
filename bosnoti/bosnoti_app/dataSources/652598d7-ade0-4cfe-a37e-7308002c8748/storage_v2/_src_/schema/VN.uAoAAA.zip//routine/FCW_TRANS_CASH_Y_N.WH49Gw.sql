create function fcw_trans_cash_Y_N
(
  i_acnt_no in varchar2,
  i_sub_no  in    varchar2,
  i_seq_no  in    number,
  i_type    in    number,
  i_trd_dt  in    varchar2
) return varchar2 as

  o_count_num  integer(10);
  ts_job_chk  varchar2(500) := 'N';
  t_err_msg   varchar2(100);

/* ===========================================
  -- Program ID     :   fcw_trans_cash_Y_N
  -- Date of Program  :   19/07/2016
  -- Programmer    :  Mr.Hieu
  -- Description     :
   =========================================== */

begin

  /*Kiem tra xem da backup cwd10h00 chua */
  begin
    select vn.fxb_daily_stat_chk ('E','0','4400','4400','%')
    into ts_job_chk
    from  dual;
    exception
      when others then
      t_err_msg := vn.fxc_get_err_msg('V','2713');
      raise_application_error(-20011,t_err_msg||'Error fcw_trans_cash_Y_N');
  end;

  if i_trd_dt=vn.vwdate and ts_job_chk = 'N' then
    if i_type = '1' then
      begin
      select  count(*)
      into  o_count_num
      from  vn.cwd10m00
      where  OUTAMT_ACNT_NO   =  i_acnt_no
        and OUTAMT_SUB_NO=i_sub_no
        and OUTAMT_ACNT_NO=INAMT_ACNT_NO
        and OUTAMT_TRD_SEQ_NO= i_seq_no
        and to_char(work_dtm,'YYYYMMDD')= i_trd_dt;
      exception
      when   no_data_found then
        o_count_num :=0;
      end;
    else
      begin
        select  count(*)
        into  o_count_num
        from  vn.cwd10m00
        where  INAMT_ACNT_NO   =  i_acnt_no
          and INAMT_SUB_NO=i_sub_no
          and OUTAMT_ACNT_NO=INAMT_ACNT_NO
          and INAMT_TRD_SEQ_NO=i_seq_no
          and to_char(work_dtm,'YYYYMMDD')= i_trd_dt ;
        exception
        when   no_data_found then
          o_count_num :=0;
      end;
    end if;
  else
    if i_type = '1' then
      begin
      select  count(*)
      into  o_count_num
      from  vn.cwd10h00
      where  OUTAMT_ACNT_NO   =  i_acnt_no
        and OUTAMT_SUB_NO=i_sub_no
        and OUTAMT_ACNT_NO=INAMT_ACNT_NO
        and OUTAMT_TRD_SEQ_NO= i_seq_no
        and STD_DT=i_trd_dt;
      exception
      when   no_data_found then
        o_count_num :=0;
      end;
    else
      begin
      select  count(*)
      into  o_count_num
      from  vn.cwd10h00
      where  INAMT_ACNT_NO   =  i_acnt_no
        and INAMT_SUB_NO=i_sub_no
        and OUTAMT_ACNT_NO=INAMT_ACNT_NO
        and INAMT_TRD_SEQ_NO=i_seq_no
        and STD_DT=i_trd_dt;
      exception
      when   no_data_found then
        o_count_num :=0;
      end;
    end if;
  end if;

  if o_count_num = 0 then
    return 'N';
    else
    return 'Y';
  end if;
end ;
/

