create function fdl_emp_no_chk
(
    i_emp_no         in   varchar2
)
    return  VARCHAR2
as
	o_chk             VARCHAR2(1);

begin

/*============================================================================*/
/* Valiabl Initialize                                                         */
/*============================================================================*/
    o_chk  :=  'N';

    if substr(i_emp_no,1,3) = '1Z9' then
    	o_chk := 'Y';
	end if ;

	return o_chk;

end fdl_emp_no_chk;
/

