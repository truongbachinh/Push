create procedure    pxc_sms_ins(
    i_send_dt          in varchar2,                         -- can put NULL, get from sysdate
    i_recv_phone_no    in varchar2,                         -- can put NULL, get from account
    i_send_phone_no    in varchar2,                         -- can put NULL, get from company
    i_func_cd          in varchar2,                         -- NOT null
    i_msg_lang         in varchar2,                         -- can put NULL, get from account
    i_sms_msg          in varchar2,                         -- NOT null
    i_work_mn          in varchar2,                         -- can put NULL
    i_work_trm         in varchar2,                         -- can put NULL
    i_acnt_no          in varchar2      default null,       -- can put NULL
    i_sub_no           in varchar2      default null,       -- can put NULL
    i_func_tp          in varchar2      default '1'         -- can put NULL, -- 1; sms sent to customer     2: sms sent to employee
) IS
/* Declare variable */
    -- Common variable
    t_proc_nm               varchar2(100)   := 'pxc_sms_ins';
    t_err_msg               varchar2(4000)  := ' ';

    -- Info variable
    t_send_st               varchar2(10)    := 9;                       -- default sending status is 9
    t_re_try_cnt            number          := 3;                       -- default re-sending sms is 3
    t_call_back_no          varchar2(20)    := '8400000000';
    t_sms_msg_trunc         varchar2(1000)  := ' ';
    t_sms_msg               varchar2(1000)  := ' ';
    t_sms_msg_max_sz        number          := 160;
    t_sms_yn                varchar2(1)     := 'Y';
    t_func_nm               varchar2(50)    := '';
    t_send_dt               varchar2(14)    := substr(i_send_dt, 1, 8);
    t_recv_phone_no         varchar2(15)    := i_recv_phone_no;
    t_send_phone_no         varchar2(15)    := i_send_phone_no;
    t_msg_lang              varchar2(1)     := i_msg_lang;
    t_sub_no                varchar2(2)     := i_sub_no;
    t_sms_reg_yn            varchar2(1)     := 'Y';

BEGIN
    /* Steps:
        1. Check if account is registered sending sms
        2. Get input values if null
        3. Get message content from input
        4. Validate message content
        5. Insert into xcs01m00
    */

    vn.pxc_log_write(t_proc_nm, '');
    vn.pxc_log_write(t_proc_nm, 'Start pxc_sms_ins for: '
                                || 'function: '         || i_func_cd
                                || ' acnt_no: '         || i_acnt_no        || '-' || i_sub_no
                                || ' recv_phone_no: '   || i_recv_phone_no
                                || ' sms_msg_para: '    || i_sms_msg
                    );

    -- 1. Check if account is registered sending sms
    begin
        if(i_func_tp = '1' and i_func_cd <> 'F00000' and trim(i_acnt_no) is not null) then
            t_sms_reg_yn    := vn.fxc_acnt_sms_reg_chk(i_acnt_no, i_sub_no, i_func_cd);
        else
            t_sms_reg_yn    := 'Y';
        end if;
    exception
        when others then
            vn.Pxc_Log_Write (t_proc_nm, 'Error when getting account sms registration: ' || sqlcode || ' - ' || sqlerrm);
            return;
    end;

    if(t_sms_reg_yn = 'N') then
        vn.pxc_log_write(t_proc_nm, 
                               'Account: ' || i_acnt_no || '-' || i_sub_no
                            || ' is not registered sending sms for: ' || t_func_nm
                        );
        return;
    else
        -- 2. Get input values if null
        begin
            if(i_sub_no is null) then
                t_sub_no := '00';
            end if;

            if(i_send_dt is null) then
                select to_char(sysdate, 'YYYYMMDD') send_dt
                into t_send_dt
                from dual;
            end if;

            if(i_send_phone_no is null) then
                select com_phone
                into t_send_phone_no
                from vn.xcc99m00
                where test_yn = 'R'
                and rownum = 1;
            end if;

            if(i_recv_phone_no is null) then
                select '84' || substr(vn.faa_acnt_mobile_g(i_acnt_no, t_sub_no), 2) recv_phone_no
                into t_recv_phone_no
                from dual;
            end if;

            if(i_msg_lang is null) then
                select decode(acnt_tp, 'F', 'E', 'V') ms_lang
                into t_msg_lang
                from vn.aaa01m00
                where acnt_no = i_acnt_no
                and sub_no = t_sub_no;
            end if;

        exception
            when others then
                vn.Pxc_Log_Write (t_proc_nm, 'Error when replacing NULL input parameter: ' || sqlcode || ' - ' || sqlerrm);
                return;
        end;

        -- 3. Get message content from input
        t_sms_msg_trunc := trim(i_sms_msg);
        t_sms_msg_trunc := regexp_replace(t_sms_msg_trunc, ' {2,}', ' ');
        t_sms_msg_trunc := replace(t_sms_msg_trunc, ' ||' , '||');
        t_sms_msg_trunc := replace(t_sms_msg_trunc, '|| ' , '||');

        begin
            t_sms_msg := vn.fxc_get_sms_msg(
                            i_func_tp,
                            i_func_cd,
                            t_msg_lang,
                            t_sms_msg_trunc
                        );
        exception
            when others then
                vn.Pxc_Log_Write (t_proc_nm, 'Error when getting msg content: ' || sqlcode || ' - ' || sqlerrm);
                return;
        end;

        vn.pxc_log_write(t_proc_nm, 't_sms_msg: ' || t_sms_msg); 

        -- 4. Validate message content
        if trim(t_sms_msg) is null then
            if(i_func_tp = '1') then
                vn.pxc_log_write(t_proc_nm, 'Message content is null');
                return;
            else
                t_sms_msg := i_sms_msg;
            end if;
        end if;

        /*
        if (length(t_sms_msg) > t_sms_msg_max_sz and i_func_cd <> 'F00000')  then
            vn.pxc_log_write(t_proc_nm, 'Length of message is over: ' || t_sms_msg_max_sz);
            return;
        end if;
        */

        vn.pxc_log_write(t_proc_nm, 'Start inserting into xcs01m00');

        -- 5. Insert into xcs01m00
        begin
            insert into vn.xcs01m00(
                sms_seq_no,
                send_dt,
                recv_phone_no,
                call_back_no,
                send_phone_no,
                send_st,
                re_try_cnt,
                work_tp_a,
                sms_msg,
                acnt_no,
                sub_no,
                work_mn,
                work_dtm,
                work_trm)
            values(
                vn.xcs01m00_seq.nextval,
                t_send_dt,
                t_recv_phone_no,
                t_call_back_no,
                t_send_phone_no,
                t_send_st,
                t_re_try_cnt,
                i_func_cd,
                t_sms_msg,
                i_acnt_no,
                t_sub_no,
                i_work_mn,
                sysdate,
                i_work_trm);

        exception
            when others then
                t_err_msg  := 'Error when inserting into xcs01m00: ' || sqlcode || ' - ' || sqlerrm;
                -- raise_application_error(-20100,t_err_msg);
                vn.pxc_log_write(t_proc_nm, t_err_msg);

                return;
        end;

        vn.pxc_log_write(
            t_proc_nm, 
            'Sending sms successfully to: ['    || t_recv_phone_no  || '],'
            || ' sms_msg['                      || t_sms_msg        || ']'
        );

    end if;

end pxc_sms_ins;
/

