create FUNCTION    fdl_get_mrgn_shrt(i_tot_loan     IN NUMBER,
                                             i_tot_asset    IN NUMBER,
                                             i_mrgn_mntn_rt IN NUMBER,
                                             i_tp           IN VARCHAR2)
  RETURN NUMBER AS

  /*!
    \file     fdl_get_mrgn_shrt.sql
    \brief
     \section intro Program Information
         - Program Name              :
         - Service Name              :
         - Related Client Program- Client Program ID :
         - Related Tables            :
         - Dev. Date                 : 2015/05/20
         - Developer                 : Liem
         - Business Logic Desc.      : Tra ra gia tri danh gia chung khoan
         - Latest Modification Date  : 2015/05/20
     \section history Program Modification History
     - 1.0       2015/05/20    New.
     \section hardcoding Hard-Coding List
     \section info Additional Reference Comments
  */

  /*
  i_tp:       01: Gia tri chung khoan lam tai san dam bao
              02: Gia tri chung khoan Margin
              03: Gia tri chung khoan phai bo sung
  */

  o_return NUMBER := 0;

  t_mrgn_shrt_amt     NUMBER := 0;
  t_mrgn_shrt_stk_amt NUMBER := 0;
  t_mrgn_shrt_lnd_amt NUMBER := 0;

BEGIN

  o_return := 0;

  t_mrgn_shrt_amt     := 0;
  t_mrgn_shrt_stk_amt := 0;
  t_mrgn_shrt_lnd_amt := 0;

  vn.pxc_log_write('fdl_get_mrgn_shrt',
                   'Start fdl_get_mrgn_shrt  : ' || ' tot_loan = ' ||
                   i_tot_loan || ' tot_asset = ' || i_tot_asset);

  /* Nop tien de ve ti le MMR */
  IF i_tp = '01' THEN
    IF (i_mrgn_mntn_rt) <> 0 AND i_mrgn_mntn_rt <> 1 THEN

      /* C(in) = MAX{0, L - A(a) [1 - R(min)]} */
      t_mrgn_shrt_amt := greatest(0,
                                  i_tot_loan -
                                  round(i_tot_asset * (1 - i_mrgn_mntn_rt),
                                        0));
      o_return        := t_mrgn_shrt_amt;
    END IF;

    /* Ban chung khoan de ve ti le MMR */
  ELSIF i_tp = '02' THEN
    IF (i_mrgn_mntn_rt) <> 0 AND i_mrgn_mntn_rt <> 1 THEN

      /* 
         S(out) = [TL - TA(1-MMR)]/MMR 
      */
      t_mrgn_shrt_stk_amt := greatest(0,round((i_tot_loan - i_tot_asset*(1-i_mrgn_mntn_rt))/i_mrgn_mntn_rt) );            
      o_return            := t_mrgn_shrt_stk_amt;

    END IF;

    /* Nop chung khoan de ve ti le MMR */
  ELSIF i_tp = '03' THEN
    IF (i_mrgn_mntn_rt) <> 0 AND i_mrgn_mntn_rt <> 1 THEN
      /* 
         S(in) = [TL - TA(1-MMR)]/(1-MMR)
      */
      t_mrgn_shrt_lnd_amt := greatest(0,round((i_tot_loan-i_tot_asset*(1-i_mrgn_mntn_rt))/(1 - i_mrgn_mntn_rt)) );

      o_return := t_mrgn_shrt_lnd_amt;
    END IF;
  ELSE
    o_return := 0;
  END IF;

  vn.pxc_log_write('fdl_get_mrgn_shrt',
                   'i_tp: ' || i_tp || ' o_return =' || o_return);
  vn.pxc_log_write('fdl_get_mrgn_shrt', 'End fdl_get_mrgn_shrt');
  RETURN o_return;
END fdl_get_mrgn_shrt;
/

