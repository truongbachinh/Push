create PROCEDURE	pxc_logon_check(
	i_user_id 				IN 			VARCHAR2, 			--  ≫c¹ø
	i_ip_addr 				IN 			VARCHAR2, 			--   ip AO¼O
	i_mac_addr 				IN 			VARCHAR2, 			--   mac address
	i_lng_tp    			IN 			VARCHAR2, 				--   ¾ð¾i±¸ºÐ
	o_user_nm    			IN OUT 	VARCHAR2, 			--   ≫c¿ø¸i
	o_user_passwd  		IN OUT 	VARCHAR2, 				--   ºn¹Ð¹øE￡
	o_user_passwd2 		IN OUT 	VARCHAR2, 				--   A÷Au ºn¹Ð¹øE￡
	o_passwd_chg_dt 	IN OUT 	VARCHAR2, 			--   AOA¾ ºn¹Ð¹øE￡ º?°æAI
	o_dept_no0 				IN OUT 	VARCHAR2, 			--   ºI¼­AUμa
	o_dept_no1 				IN OUT 	VARCHAR2, 			--   AoA¡AUμa
	o_dept_no2 				IN OUT 	VARCHAR2, 			--   AaAa¼OAUμa
	o_dept_nm1 				IN OUT 	VARCHAR2, 			--   AoA¡¸i
	o_dept_nm2 				IN OUT 	VARCHAR2, 			--   AaAa¼O¸i
	o_dept_option 		IN OUT 	VARCHAR2, 			--   Aß°¡ºI¼­
	o_mp_yn 					IN OUT 	VARCHAR2,  			--   ¸¶½ºAIÆÐ½º¿oμa ≫c¿e¿ⓒºI
	o_agc_no					IN OUT 	VARCHAR2,  			--   ´e¸®A¡AUμa
	o_dev_yn					IN OUT 	VARCHAR2,  			--   °³¹ß¿ⓒºI
	o_exist 					IN OUT 	VARCHAR2,  			--   A¸Ac¿ⓒºI
	o_trd_brch 				IN OUT 	VARCHAR2,  			--   A¸Ac¿ⓒºI
	o_posi_cd 				IN OUT 	VARCHAR2  			--   A¸Ac¿ⓒºI
) IS

ti_connectable_cnt		number		:= 1	 ;	 	-- A￠¼O °¡´E ¼o
ti_connected 			number	  	:= 0	 ;	 	-- A￠¼O ¼o

t_err_msg				varchar2(1000) := null  ;

BEGIN
	o_user_nm 				:= '!' ;
	o_user_passwd  		:= '!' ;
	o_user_passwd2 		:= '!' ;
	o_passwd_chg_dt		:= '!' ;
	o_dept_no0 				:= '!' ;
	o_dept_no1 				:= '!' ;
	o_dept_no2 				:= '!' ;
	o_dept_nm1 				:= '!' ;
	o_dept_nm2 				:= '!' ;
	o_dept_option 		:= '!' ;
	o_mp_yn 					:= 'n!';
	o_dev_yn 					:= 'n' ;
	o_exist 					:= 'n' ;
	o_trd_brch 				:= '!' ;
	o_posi_cd 				:= '!' ;

	/*------------------------------------------------------------------------------*/
	/*   			1. ±aº≫ A¤º¸ A¶E¸. 				 */
	/*------------------------------------------------------------------------------*/

	FOR c1 IN (	SELECT	a.emp_nm  											AS	user_nm,
						b.pswd 																		AS	user_passwd,
						a.brch_cd																	AS	dept_no1,
						a.agnc_brch																AS	dept_no2,
						vn.fxc_dept_nm(a.brch_cd,'00')						AS	dept_nm1,
						vn.fxc_dept_nm(a.brch_cd, a.agnc_brch)		AS	dept_nm2,
						a.brch_cd||','||a.addl_bnh_cd   					AS	dept_option,
						nvl(a.mst_pswd_use_yn,'n')                AS	mp_yn,
						b.bos_cnnt_avlb_cnt												AS	connectable_cnt,
						a.deve_cnnt_avlb_yn												AS	server_choose,
						a.dept_cd																	AS	dept_cd,
						nvl(a.trd_brch, '!')											AS	trd_brch,
						a.posi_cd																	AS 	posi_cd

				FROM	vn.xca01m01 a,	vn.xca01m00 b

				WHERE 	a.emp_no = i_user_id
				AND		a.emp_no = b.id
				AND		NVL(b.cls_dtm, TO_DATE('30000101','yyyymmdd') ) >= SYSDATE - 1
				AND     b.emp_cust_tp = '0'				)
	LOOP
		o_exist      		 				:= 'y';
		o_user_nm    					 	:= nvl(c1.user_nm,'!');
		o_user_passwd    				:= nvl(c1.user_passwd,'!');
		o_dept_no1   		 				:= nvl(c1.dept_no1,'!');
		o_dept_no2   					 	:= nvl(c1.dept_no2,'!');
		o_dept_nm1   		 				:= nvl(c1.dept_nm1,'!');
		o_dept_nm2   					 	:= nvl(c1.dept_nm2,'!');
		o_dept_option					 	:= nvl(c1.dept_option,'!');
		o_mp_yn   			 				:= nvl(c1.mp_yn,'n!');
		ti_connectable_cnt			:= nvl(c1.connectable_cnt,1);
		o_dev_yn		 						:= nvl(c1.server_choose,'n');
		o_dept_no0              := c1.dept_cd;
		o_trd_brch              := c1.trd_brch;
		o_posi_cd	              := c1.posi_cd;
	END LOOP;

	IF nvl(o_exist,'n') != 'y' THEN
		t_err_msg := vn.fxc_get_err_msg(i_lng_tp,'2804');
		raise_application_error(-20001,t_err_msg);
		RETURN;
	END IF;

	/*------------------------------------------------------------------------------*/
	/*		2.¸¶½ºAIÆÐ½º¿oμa ≫c¿e ¿ⓒºI, ºI¼­AUμa A¶E¸	 */
	/*------------------------------------------------------------------------------*/
	BEGIN
		SELECT	o_mp_yn||NVL(trim( head_brch_tp ), '!')
	  	INTO	o_mp_yn
		  FROM	vn.xcc90m00
	 	 WHERE	brch_cd = o_dept_no1
		   AND	agnc_brch = o_dept_no2;
	EXCEPTION
		WHEN no_data_found THEN
			o_mp_yn := o_mp_yn||'!';
	END;

	/*------------------------------------------------------------------------------*/
	/*   	3.AOA¾ ºn¹Ð¹øE￡ º?°æAI, A÷Au ºn¹Ð¹øE￡ A¶E¸	 */
	/*------------------------------------------------------------------------------*/
	BEGIN
		SELECT	NVL(TO_CHAR(MAX(work_dtm),'yyyy/mm/dd hh24:mi:ss'), '!')
		INTO	o_passwd_chg_dt
		FROM	vn.xca01h00
		WHERE	cnnt_ctrl_chg_tp = '13'
		AND		id = i_user_id;
	EXCEPTION
		WHEN no_data_found THEN
			o_passwd_chg_dt := '!';
	END;

	IF o_passwd_chg_dt = '!' THEN
		o_user_passwd2 := '!';
	ELSE
		SELECT	cnnt_ctrl_chg_pre_val
		INTO	o_user_passwd2
		FROM	vn.xca01h00
		WHERE	cnnt_ctrl_chg_tp = '13'
		AND		id = i_user_id
		AND		work_dtm = TO_DATE(o_passwd_chg_dt,'yyyy/mm/dd hh24:mi:ss');

		o_passwd_chg_dt := SUBSTR(o_passwd_chg_dt,1,10);
	END IF;

	BEGIN
		SELECT  NVL(MAX(agnc_brch_cd),'000')
		INTO    o_agc_no
		FROM    vn.xca01m03
		WHERE   i_ip_addr like  ip||'%'
		AND     cls_dt = '30000101';
	END;

	/*-------------------------------------------------------------*/
	/*   		4.CoAc A￠¼O ¼o A¶E¸			*/
	/*-------------------------------------------------------------*/
	BEGIN
		SELECT 	count(*)
		INTO	ti_connected
		FROM 	vn.xca01h01
		WHERE   ip != i_ip_addr
		AND     emp_no = i_user_id
		AND     mdm_tp = '00'
		AND     cnnt_end_time is null;
	EXCEPTION
		WHEN others THEN
			t_err_msg := vn.fxc_get_err_msg(i_lng_tp,'9822');
			raise_application_error(-20004,t_err_msg);
			RETURN;
	END;

	/*---------------------------------------------------------------*/
	/*   	5.A￠¼O ¼o¿I A￠¼O °¡´E ¼o ºn±³		  */
	/*---------------------------------------------------------------*/
	IF i_user_id NOT LIKE '000099%' THEN

		IF ( ti_connectable_cnt = 0 )  THEN
			t_err_msg := vn.fxc_get_err_msg(i_lng_tp,'2824');
			raise_application_error(-20005,t_err_msg);
			RETURN;
		END IF;

		IF (( ti_connectable_cnt = 1 )  AND ( ti_connected = ti_connectable_cnt)) THEN
			t_err_msg := vn.fxc_get_err_msg(i_lng_tp,'2801');
			raise_application_error(-20006,t_err_msg);
			RETURN;
		END IF;

		IF (( ti_connectable_cnt != 1)  AND ( ti_connected >= ti_connectable_cnt)) THEN
			t_err_msg := vn.fxc_get_err_msg(i_lng_tp,'2802');
			raise_application_error(-20007,t_err_msg);
			RETURN;
		END IF;

	END IF;

END pxc_logon_check;
/

