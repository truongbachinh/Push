create PROCEDURE pss_outbil_cl_p
(
	is_acnt_no			in		varchar2,			--
	is_sub_no			in		varchar2,			--
	is_trd_seq_no		in		varchar2,			--
	is_trd_seq_no_st	in		varchar2,
	is_work_bnh			in		varchar2,
	is_work_mn			in		varchar2,			--
	is_work_trm			in		varchar2,			--
	is_dept_no2			in		varchar2,

	os_bil_prerm_qty	out		varchar2,				--
	os_bil_nowrm_qty	out		varchar2				--

) AS

   	tn_cncl_trd_seq_no		number	:= 0;
   	tn_tot_trd_seq_no		number	:= 0;
   	tn_bil_prerm_qty		number	:= 0;			--

	tn_sb_pri				number	:= 0;			--
	tn_sb_qty				number	:= 0;			--
	tn_cnt					number	:= 0;

	ts_stk_cd				varchar2(12)	:= '';
	ts_stk_tp				varchar2(2)		:= '';

	ts_step					varchar2(10)	:= '';
	ts_msg					varchar2(1000)	:= '';
	ts_code					varchar2(4)		:= '';

    t_rtn_val               varchar2(1)     := '';
    t_err_txt               varchar2(200);
    t_err_msg               varchar2(500);
    o_cnt                   number  := 0;           --

	ERR_RTN					EXCEPTION;

BEGIN

    vn.pxc_log_write('pss_outbil_cl_p', 'is_acnt_no : ' || is_acnt_no );
    vn.pxc_log_write('pss_outbil_cl_p', 'is_sub_no  : ' || is_sub_no  );
    vn.pxc_log_write('pss_outbil_cl_p', 'is_trd_seq_no_st : ' || is_trd_seq_no_st );

    /*** check closing ***/

    t_rtn_val := 'Y';

    if  is_work_mn  not in ('DAILY','BATCH') then

        vn.pbm_cls_yn_q(  vn.vhdate
                       ,  vn.fbm_emp_bnh_q    ( is_work_mn)
                       ,  vn.faa_acnt_bnh_cd_g( '0', is_acnt_no, is_sub_no)
                       , '1'
                       ,  t_rtn_val
                       ,  t_err_txt
                       );

        if  t_rtn_val  !=  'N' then
            t_err_msg := vn.fxc_get_err_msg('V','2716');
            raise_application_error(-20100,t_err_msg||t_err_txt);
        end if;

    end if;

/*
    ts_step := '1';
    SELECT	nvl(sum(sb_qty), 0)
  	  INTO	tn_bil_prerm_qty
      FROM  vn.aaa10m00
     WHERE  acnt_no = is_acnt_no
	   AND  sub_no  = is_sub_no
       AND  trd_dt = vn.vwdate()
       AND  trd_seq_no >= to_number(is_trd_seq_no_st)
       AND  trd_tp = '21'
       AND  org_trd_no = 0
       AND  nvl(cncl_yn, 'N') = 'N';


    vn.pxc_log_write('pss_outbil_cl_p', 'ts_step : ' || ts_step );
*/

    --
    ts_step := '2';
   	pxc_psb_seq_cret_p (is_acnt_no, is_sub_no,vn.vwdate(), tn_cncl_trd_seq_no, tn_tot_trd_seq_no);

	--
    ts_step := '3';
    SELECT	bil_nowrm_qty
    	   ,sb_qty
    	   ,sb_pri
    	   ,stk_cd
    	   ,stk_tp
      INTO	tn_bil_prerm_qty
       	   ,tn_sb_qty
       	   ,tn_sb_pri
       	   ,ts_stk_cd
       	   ,ts_stk_tp
      FROM	vn.aaa10m00
     WHERE	acnt_no = is_acnt_no
	   AND  sub_no  = is_sub_no
       AND	trd_dt = vn.vwdate()
       AND	trd_seq_no = to_number(is_trd_seq_no)
	   AND  nvl(cncl_yn, 'N') = 'N' ;

	vn.pxc_log_write('pss_inbil_cl_p', 'ts_step : ' || ts_step );

	--
	ts_step := '4';
	UPDATE	vn.aaa10m00
	   SET	cncl_yn = 'Y'
	       ,work_bnh = is_work_bnh
	       ,work_mn = is_work_mn
	       ,work_dtm = sysdate
	       ,work_trm = is_work_trm
	 WHERE	acnt_no = is_acnt_no
	   AND  sub_no  = is_sub_no
       AND	trd_dt = vn.vwdate()
       AND	trd_seq_no = to_number(is_trd_seq_no);

    vn.pxc_log_write('pss_inbil_cl_p', 'ts_step : ' || ts_step );
	--
	ts_step := '5';

	INSERT INTO vn.aaa10m00 ( 	 acnt_no			--
								,sub_no				--
								,trd_dt				--
								,tot_trd_seq_no			--
								,trd_seq_no			--
								,trd_tp				--
								,rmrk_cd			--
								,mdm_tp				--
								,trd_mdm_tp			--
								,cncl_yn			--
								,org_trd_no			--
								,trd_amt			--
								,cmsn				--
								,adj_amt			--
								,dpo_prerm			--
								,dpo_nowrm			--
								,stk_cd				--
								,stk_nm				--
								,sb_pri				--
								,sb_qty				--
								,bil_prerm_qty		--
								,bil_nowrm_qty		--
								,tot_bil_prerm      --
								,tot_bil_nowrm		--
								,book_amt			--
								,stk_tp				--
								,mth_dt				--
								,lnd_tp
								,lnd_dt
								,lnd_int
								,agnt_yn			--
								,acnt_mng_bnh		--
								,work_bnh			--
								,work_mn			--
								,work_dtm			--
								,work_trm			--
								,agnc_brch
								,proc_agnc_brch
				) ( SELECT	acnt_no 					-- acnt_no
					 	   ,sub_no						-- trd_dt
					 	   ,trd_dt						-- trd_dt
					 	   ,tn_tot_trd_seq_no			-- trd_seq_no
					 	   ,tn_cncl_trd_seq_no			-- trd_seq_no
					 	   ,trd_tp 						-- trd_tp
					 	   ,decode(rmrk_cd, '221', '230', '222', '231', '223', '232', '229', '233')	-- rmrk_cd
					 	   ,mdm_tp						-- mdm_tp
					 	   ,trd_mdm_tp					-- trd_mdm_tp
					 	   ,'N'							-- cncl_yn
					 	   ,trd_seq_no					-- org_trd_no
					 	   ,0							-- trd_amt
						   ,0							-- cmsn
					       ,0							-- adj_amt
					       ,0							-- dpo_prerm			--> ?
					       ,0							-- dpo_nowrm   			--> ?
					       ,stk_cd						-- stk_cd
					       ,stk_nm						-- stk_nm
					       ,sb_pri						-- sb_pri
					       ,sb_qty						-- sb_qty
					       ,bil_nowrm_qty				-- bil_prerm_qty
					       ,bil_nowrm_qty + sb_qty		-- bil_nowrm_qty
					       ,tot_bil_nowrm   		-- tot_bil_prerm_qty
					       ,tot_bil_nowrm + sb_qty   -- tot_bil_prerm_qty
					       ,book_amt					-- book_amt
					       ,stk_tp						-- stk_tp
					       ,null						-- mth_dt
					       ,null
					       ,null
					       ,0
					       ,'N'							-- agnt_yn
					       ,acnt_mng_bnh				-- acnt_mng_bnh
					       ,is_work_bnh					-- work_bnh
						   ,is_work_mn					-- work_mn
						   ,sysdate						-- work_dtm
						   ,is_work_trm					-- work_trm
						   ,agnc_brch
						   ,is_dept_no2
					  FROM	vn.aaa10m00
					 WHERE	acnt_no = is_acnt_no
					   AND  sub_no  = is_sub_no
					   AND	trd_dt = vn.vwdate()
      				   AND	trd_seq_no = to_number(is_trd_seq_no));


	vn.pxc_log_write('pss_inbil_cl_p', 'ts_step : ' || ts_step );
	--
	ts_step := '6';
	UPDATE	vn.ssb01m00
	   SET	own_qty = own_qty + tn_sb_qty
	   	   ,book_amt = book_amt + (tn_sb_qty * tn_sb_pri)
	   	   ,work_mn = is_work_mn
	   	   ,work_dtm = sysdate
	   	   ,work_trm = is_work_trm
	 WHERE	acnt_no = is_acnt_no
	   AND  sub_no  = is_sub_no
	   AND	stk_cd = ts_stk_cd;

    /*******************************/
    /* call evaluation for margin  */
    /*******************************/

    vn.pdl_crd_loan_rt_proc_td
        (vn.vwdate
        ,'2' -- stock
        ,is_acnt_no
		,is_sub_no
        ,tn_cncl_trd_seq_no
        ,is_work_mn
        ,is_work_trm
        ,o_cnt
       );

    vn.pxc_log_write('pss_outbil_cl_p','pdl_crd_loan_rt_proc_td ['|| o_cnt ||']');

	/* out parametres */
	ts_step := '16';

	os_bil_prerm_qty	:= to_char(tn_bil_prerm_qty);							--
	os_bil_nowrm_qty	:= to_char(tn_bil_prerm_qty + tn_sb_qty);				--

	RETURN;

	EXCEPTION
			WHEN 	ERR_RTN	THEN
			     	raise_application_error(-20100, ts_code || ':[pss_outbil_cl_p ' || ts_step || '] ' || ts_msg);
					RETURN;

			WHEN	NO_DATA_FOUND	THEN
					raise_application_error(-20200, '[pss_outbil_cl_p ' || ts_step || '] ' || SQLERRM);
					RETURN;

			WHEN	OTHERS	THEN
					raise_application_error(-20300, '[pss_outbil_cl_p ' || ts_step || '] ' || SQLERRM);
			        RETURN;

END pss_outbil_cl_p;
/

