create FUNCTION    fdl_get_acnt_max_amt_by_item(
    i_acnt_no   VARCHAR2,
    i_sub_no    VARCHAR2,
    i_item_tp   VARCHAR2,
    i_item_cd   VARCHAR2,
    i_day_tp    VARCHAR2) 
RETURN NUMBER
AS
    
    -- Declare variable
    t_vwdate                VARCHAR2(8)     := NULL;

    r_acnt_max_amt          NUMBER          := 0;
    c_acnt_max_amt          NUMBER          := 0;

    t_acnt_max_amt          NUMBER          := 0;
    t_acnt_lnd_amt          NUMBER          := 0;
    t_acnt_lnd_limit        NUMBER          := 0;

    t_err_msg               VARCHAR2(500)   := '';
	t_detail_chk            NUMBER      	:= 1;

BEGIN
    t_vwdate    := vn.vwdate();

    BEGIN
        SELECT MAX(NVL(d5.acnt_max_amt, 0))
        INTO r_acnt_max_amt
        FROM vn.dlm20m05 d5 -- chinh sach rieng cua han muc tk - nguon 
        WHERE d5.apy_tp = i_item_tp
        AND d5.apy_cd = i_item_cd
        AND d5.acnt_no = i_acnt_no
        AND d5.sub_no = i_sub_no
        AND d5.apy_dt <= t_vwdate
        AND d5.expr_dt >= t_vwdate
        AND d5.active_stat = 'Y';
    EXCEPTION
        WHEN OTHERS THEN
        t_err_msg := vn.fxc_get_err_msg('V', '46051');
        vn.pxc_log_write('fdl_get_acnt_lnd_limit',
                        ' account error: ' || t_err_msg || ' ACNT_NO=' ||
                        i_acnt_no || '-' || i_sub_no || '-' || i_item_tp || '-' ||
                        i_item_cd);
        raise_application_error(-20100,
                                t_err_msg ||
                                ' fdl_get_acnt_lnd_limit: ACNT_NO_STK_i_tp=' ||
                                i_acnt_no || '-' || i_sub_no || '-' ||
                                i_item_tp || '-' || i_item_cd);
    END;
    -- 2. Nguoc lai lay theo chinh sach chung (dlm00m01)
    IF r_acnt_max_amt IS NOT NULL THEN
        t_acnt_max_amt := r_acnt_max_amt;
    ELSE
		BEGIN
			SELECT NVL(acc_lnd_lmit, 0)
				INTO c_acnt_max_amt
				FROM vn.dlm00m01
			WHERE item_tp = i_item_tp
				AND item_cd = i_item_cd
				AND active_stat = 'Y'
				AND vn.fdl_item_detail_chk (i_item_tp,i_item_cd,t_vwdate) = 'Y';

		EXCEPTION
		WHEN no_data_found THEN
			c_acnt_max_amt := 0;
		WHEN OTHERS THEN
			t_err_msg := vn.fxc_get_err_msg('V', '46051');
			vn.pxc_log_write('fdl_get_acnt_lnd_limit',
							' Select dlm00m01 error: ' || t_err_msg ||
							' ACNT_NO=' || i_acnt_no || '-' || i_sub_no || '-' ||
							i_item_tp || '-' || i_item_cd);
		END;


        t_acnt_max_amt := NVL(c_acnt_max_amt, 0);
    END IF;

    RETURN t_acnt_max_amt;

END;    -- END fdl_get_acnt_max_amt_by_item
/

