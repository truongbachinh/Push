create FUNCTION FAA_IDNO_CONTACT_ADDR_G
(
	i_idno	IN	VARCHAR2
) RETURN VARCHAR2 AS

	o_val	VARCHAR2(100);

/*!

   	\file	faa_idno_contact_addr_g.sql
   	\brief	contact address return

   	\section intro Program Information
        - Program Name								: Contact address number return
        - Service Name              				:
        - Related Client Program- Client Program ID	:
        - Related Tables            				: VN.AAA01M00, VN.AAA02M10
        - Dev. Date                 				: 2007/11/08
        - Developer                 				: mkkim
        - Business Logic Desc.      				: Input: idno, Output: address number return
        - Latest Modification Date 					: 20210127 (HienND/NHSV-1093)

   	\section history Program Modification History
    	- 1.0	2007/11/08

   	\section hardcoding Hard-Coding List

   	\section info Additional Reference Comments
		- if contact type's address is not exits, then office->home->email

*/

BEGIN

	FOR C1 IN
	(

		SELECT	DECODE(B.CONCT_ADDR_TP,
					'1',	NVL(B.HOME_ADDR,	'!'),
					'2',	NVL(B.OFFICE_ADDR,	'!'),
					'3',	NVL(B.EMAIL,		'!'),
					'4',	NVL(B.CONT_ADDR,	'!'),
					'!') 								ADDR,
				NVL(B.HOME_ADDR,				'!')	HOME_ADDR,
				NVL(B.OFFICE_ADDR,				'!')	OFFICE_ADDR,
				NVL(B.EMAIL,					'!')	EMAIL
		FROM	VN.AAA02M10 B
		WHERE	B.IDNO = I_IDNO

	)
	LOOP

		if C1.ADDR <> '!' then
			return C1.ADDR;
		elsif C1.OFFICE_ADDR <> '!' then
			return C1.OFFICE_ADDR;
		elsif C1.HOME_ADDR <> '!' then
			return C1.HOME_ADDR;
		elsif C1.EMAIL <> '!' then
			return C1.EMAIL;
		else
			return '!';
		end if;

	END LOOP;

	RETURN '!';

END;

/

