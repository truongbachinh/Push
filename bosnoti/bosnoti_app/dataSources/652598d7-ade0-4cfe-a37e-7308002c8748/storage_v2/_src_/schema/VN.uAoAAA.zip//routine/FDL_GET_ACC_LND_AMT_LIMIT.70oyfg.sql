create FUNCTION    fdl_get_acc_lnd_amt_limit(i_acnt_no VARCHAR2,
                                                        i_day_tp  VARCHAR2 default '1')
  RETURN NUMBER AS
  /*!

     \section intro Program Information
          - Program Name              :
          - Service Name              :
          - Related Client Program- Client Program ID :
          - Related Tables            : dlm51m00, dlm90m00, dlm00m01
          - Dev. Date                 : 2021/03/10
          - Developer                 : TienLH.
          - Business Logic Desc.      : Han muc con lai so voi 3% Han muc tinh tren VCSH
          - Latest Modification Date  :
   */
    t_acc_lnd_lmit_amt  NUMBER   := 0;
    t_mrgn_loan_nowrm   NUMBER   := 0;
    t_amt_lmit          NUMBER   := 0;
    t_lnd_use_amt       NUMBER   := 0;
    t_vwdate            VARCHAR2(8) := vn.vwdate;
    t_sec_cd            VARCHAR2(5);
  t_err_msg           VARCHAR2(500) := null;

  -- Neu i_day_tp = '1'- Su dung trong ngay: Co cong them so luong du kien vay (extp) vao so da dung
  -- Neu i_day_tp ='2' - Cuoi ngay: Khong cong them so luong du kien vay (extp) vao so da dung
BEGIN

    vn.pxc_log_write('fdl_get_acc_lnd_amt_limit', '===============Start=============='  );
    vn.pxc_log_write('fdl_get_acc_lnd_amt_limit', 'i_acnt_no = '||i_acnt_no );

    t_sec_cd := vn.fxc_sec_cd('R');

    BEGIN
        SELECT vn.fdl_get_sec_lnd_info(t_vwdate, '06')
        INTO t_acc_lnd_lmit_amt
        FROM dual;
    EXCEPTION
    WHEN OTHERS THEN
        vn.pxc_log_write('fdl_get_acc_lnd_amt_limit', 'Error select fdl_get_sec_lnd_info 06 Error: ' || sqlerrm);
    t_err_msg := vn.fxc_get_err_msg('V', '2157');
        raise_application_error(-20030, t_err_msg);
    END;

  --Du kien vay trong ngay
    SELECT vn.fdl_get_mrgn_expt_amt(i_acnt_no, '%', '3')
    INTO t_lnd_use_amt
    FROM dual;

    IF i_day_tp = '1' then
  --Da vay + Du kien vay trong ngay
    SELECT vn.fdl_get_mrgn_expt_amt(i_acnt_no, '%', '3')
    INTO t_lnd_use_amt
    FROM dual;

    t_amt_lmit := greatest(t_acc_lnd_lmit_amt - t_lnd_use_amt, 0);
    ELSE
  --Da vay
    SELECT vn.fdl_get_mrgn_expt_amt(i_acnt_no, '%', '1')
    INTO t_lnd_use_amt
    FROM dual;

    t_amt_lmit := greatest(t_acc_lnd_lmit_amt - t_lnd_use_amt, 0);
    END IF;


    vn.pxc_log_write('fdl_get_stk_sum_lnd_limit', 't_acc_lnd_lmit_amt = '|| t_acc_lnd_lmit_amt ||
                                                    ' - t_lnd_use_amt = '|| t_lnd_use_amt ||
                          ' - t_amt_lmit = '|| t_amt_lmit );

    vn.pxc_log_write('fdl_get_acc_lnd_amt_limit', '===============End=============='  );

    RETURN t_amt_lmit;

END fdl_get_acc_lnd_amt_limit;
/

