create PROCEDURE drv_pcw_cash_inamt_15711_p
(
  i_trd_dt                in        varchar2
,   i_acnt_no               in        varchar2
,   i_sub_no                in        varchar2
,   i_rmrk_cd               in        varchar2
,   i_cash                  in        number
,   i_mdm_tp                in        varchar2
,   i_tr_cd                 in        varchar2
,   i_cnfm_yn               in        varchar2
,   i_dept_no_3             in        varchar2
,   i_acc_act_cd            in        varchar2
,  i_cnte                  in        varchar2
,  i_gga_yn                in        varchar2  /* Same accounts transfer, not insert into gga07m00 */
,   i_work_mn               in        varchar2
,   i_work_trm              in        varchar2
,   i_bank_acnt_no          in        varchar2
,   o_trd_dt                out       varchar2
,   o_trd_seq_no            out       number
,   o_dpo_prerm             out       number
,   o_dpo_nowrm             out       number
,   o_acnt_place            out       varchar2
,   o_bnhof_tp              out       varchar2
,   o_proc_bnhof_tp         out       varchar2
)
AS
/*
   \file     drv_pcw_cash_inamt_15711_p.sql
   \brief    ????

  \section intro Program Information
        - Program Name              : ????
        - Service Name              : N/A
        - Related Client Program- Client Program ID : Client 07301
        - Related Tables            : cwd01m00
        - Dev. Date                 : 2007/11/30
        - Developer                 :
        - Business Logic Desc.      :
        - Latest Modification Date  : 2007-11-30

  \section history Program Modification History
    - 1.0       2007/11/30     ???    ????

   \section hardcoding Hard-Coding List
    - HC-1

   \section info Additional Reference Comments
    - ???? ??
*/

  t_proc_nm                varchar2(100) ;
    t_err_txt                varchar2(200);
    t_err_cd                 number;
    t_rtn_val                char(1);
    t_work_dtm               date;
    t_amt                    number;
    t_proc_brch              varchar2(3);
    t_std_dt                 varchar2(08) ;

    t_tr_cd           varchar2(20);
    t_seq_no         number := 0 ;
  ts_acnt_stat       varchar2(20);
  ts_acnt_mng_bnh       varchar2(20);
  ts_agnc_brch       varchar2(20);
  ts_proc_bnhof_tp     varchar2(20) := ' ';

    ts_chyes         varchar2(1);

  tn_dpo           number := 0;
  tn_dpo_prerm       number := 0;
  tn_tot_dpo_prerm     number := 0;
  tn_tot_dpo           number := 0;
  tn_inout_cnfm_lim     number := 0;

  t_ATDPST_found_yn      varchar2(1);

    t_trd_dt                 varchar2(20) := ' ';
    t_trd_seq_no             number := 0;
    t_tot_trd_seq_no         number := 0;
    t_dpo_prerm              number := 0;
    t_dpo_nowrm              number := 0;
    t_acnt_place             varchar2(10) := ' ';
    t_bnhof_tp               varchar2(10) := ' ';
    t_proc_bnhof_tp          varchar2(10) := ' ';

    t_proc_brch_cd           varchar2(20) := Null;
    t_proc_agnc_brch         varchar2(20) := Null;

    ts_acnt_stop_yn          varchar2(500) := 'N';

    t_err_msg    varchar2(500);

    t_acnt_no          varchar2(20) := null;
    t_mdm_bnh          varchar2(3)  := null;
    o_result_yn        varchar2(20) := null;

  o_cnt              number := 0;
  o_cwd06m00_seq     number := 0;

BEGIN

/*============================================================================*/
/* ???? ???                                                     */
/*============================================================================*/

    t_proc_nm        :=  'drv_pcw_cash_inamt_15711_p';
    t_work_dtm       :=  SYSDATE;
  t_ATDPST_found_yn           :=  'N';

    SELECT  vn.vhdate() INTO  t_std_dt       FROM  dual;

  vn.pxc_log_write('drv_pcw_cash_inamt_15711_p','start');
  vn.pxc_log_write('drv_pcw_cash_inamt_15711_p',i_acnt_no);

  t_tr_cd          := i_tr_cd;

  t_rtn_val := 'Y';

   vn.pxc_log_write('drv_pcw_cash_inamt_15711_p','START');
   vn.pxc_log_write('drv_pcw_cash_inamt_15711_p','i_trd_dt-'||i_trd_dt);
   vn.pxc_log_write('drv_pcw_cash_inamt_15711_p','i_acnt_no-'||i_acnt_no);
   vn.pxc_log_write('drv_pcw_cash_inamt_15711_p','i_sub_no-'||i_sub_no);
   vn.pxc_log_write('drv_pcw_cash_inamt_15711_p','i_rmrk_cd-'||i_rmrk_cd);
   vn.pxc_log_write('drv_pcw_cash_inamt_15711_p','i_cash-'||i_cash);
   vn.pxc_log_write('drv_pcw_cash_inamt_15711_p','i_mdm_tp-'||i_mdm_tp);
   vn.pxc_log_write('drv_pcw_cash_inamt_15711_p','i_tr_cd-'||i_tr_cd);
   vn.pxc_log_write('drv_pcw_cash_inamt_15711_p','i_cnfm_yn-'||i_cnfm_yn);
   vn.pxc_log_write('drv_pcw_cash_inamt_15711_p','i_dept_no_3-'||i_dept_no_3);
   vn.pxc_log_write('drv_pcw_cash_inamt_15711_p','i_acc_act_cd-'||i_acc_act_cd);
   vn.pxc_log_write('drv_pcw_cash_inamt_15711_p','i_cnte-'||i_cnte);

   vn.pxc_log_write('drv_pcw_cash_inamt_15711_p','i_work_mn-'||i_work_mn);
   vn.pxc_log_write('drv_pcw_cash_inamt_15711_p','i_work_trm-'||i_work_trm);


/*============================================================================*/
/* ??????                                                         */
/*============================================================================*/

    if  i_cash  is  null  or  i_cash  <  0 or i_cash = 0
    then
        t_err_txt  :=  t_proc_nm  ||  '?? ??? ??';
    t_err_msg := vn.fxc_get_err_msg('V','2707');
    raise_application_error(-20100,t_err_msg||t_err_txt);
    end if;


    if  i_trd_dt  IS  NULL
    then
        t_err_txt  :=  t_proc_nm  ||  '??? ??? ??';
    t_err_msg := vn.fxc_get_err_msg('V','2701');
    raise_application_error(-20100,t_err_msg||t_err_txt);
    end if;

    vn.pxc_log_write('drv_pcw_cash_inamt_15711_p','2');

/*============================================================================*/
/* ???? ???                                                     */
/*============================================================================*/

    o_trd_dt                :=  ' '                ;
    o_trd_seq_no            :=  0                  ;

    o_dpo_prerm             :=  0                  ;
    o_dpo_nowrm             :=  0                  ;

    o_acnt_place            :=  ' '                ;
    o_bnhof_tp              :=  ' '                ;
    o_proc_bnhof_tp         :=  ' '                ;

    tn_inout_cnfm_lim       :=  0                  ;

/*============================================================================*/
/* ????                                                               */
/*============================================================================*/

    select decode(i_mdm_tp, '00', vn.fbm_emp_bnh_q( i_work_mn)
              , vn.faa_acnt_bnh_cd_g( '0', i_acnt_no, i_sub_no))
      into t_mdm_bnh
    from dual;


    if  i_work_mn  not in ('DAILY','BATCH')
    then

    vn.pbm_cls_yn_q(  vn.vhdate
                   ,  t_mdm_bnh
                   ,  vn.faa_acnt_bnh_cd_g( '0',i_acnt_no, i_sub_no)
                   , '1'
                   ,  t_rtn_val
                   ,  t_err_txt
                   );

    if  t_rtn_val  !=  'N'
    then
      t_err_msg := vn.fxc_get_err_msg('V','2716');
      raise_application_error(-20100,t_err_msg||t_err_txt);
    end if;

    end if;

/*============================================================================*/
/* ??_?? ????                                                */
/*============================================================================*/

    BEGIN
        select  acnt_stat
             ,  acnt_mng_bnh
             ,  agnc_brch
          into  ts_acnt_stat
             ,  ts_acnt_mng_bnh
             ,  ts_agnc_brch
          from  vn.aaa01m00
         where  acnt_no  =  i_acnt_no
       and  sub_no   =  i_sub_no;
    EXCEPTION
        WHEN  OTHERS         THEN
            t_err_txt  :=  t_proc_nm
                   ||  '??_??(aaa01m00) ????? ????:'
                   ||  to_char(sqlcode);
      t_err_msg := vn.fxc_get_err_msg('V','2001');
      raise_application_error(-20100,t_err_msg||t_err_txt);
    END;

/*============================================================================*/
/* ???? ??                                                        */
/*============================================================================*/

  if i_work_mn in ('DAILY','BATCH') or i_mdm_tp <> '00' then

    t_proc_brch_cd := ts_acnt_mng_bnh;
    t_proc_agnc_brch := ts_agnc_brch;

  else

      BEGIN
          select  brch_cd,
                  agnc_brch
            into  t_proc_brch_cd,
                  t_proc_agnc_brch
            from  vn.xca01m01
            where emp_no = i_work_mn
            ;
      EXCEPTION
          WHEN  OTHERS         THEN
              t_err_txt  :=  t_proc_nm
                     ||  '????????(xca01m01) ????? ????:'
                     ||  to_char(sqlcode);
      t_err_msg := vn.fxc_get_err_msg('V','2819');
      raise_application_error(-20100,t_err_msg||t_err_txt);
      END;

  end if;

    if  ts_acnt_stat  NOT IN ('1')
    then
        if  ts_acnt_stat  =  '2'
        then
            t_err_txt  :=  t_proc_nm  ||  '???? ???';
      t_err_msg := vn.fxc_get_err_msg('V','2023');
      raise_application_error(-20100,t_err_msg||t_err_txt);
        else
            t_err_txt  :=  t_proc_nm  ||  '???? ??????? ???'
                                      ||  '(' || ts_acnt_stat || ')';
      t_err_msg := vn.fxc_get_err_msg('V','2014');
      raise_application_error(-20100,t_err_msg||t_err_txt);
        end if;
    end if;


/*============================================================================*/

  if i_cnfm_yn = 'N'
  then
    tn_inout_cnfm_lim := vn.fcw_inout_cnfm_lim_q( i_dept_no_3,'01');

    if i_cash > tn_inout_cnfm_lim  then  -- VCSC need to confirm HTS also

  /* Insert cash to vn.cwd06m00 that is table for saving approval for waiting */

        BEGIN
        vn.drv_pcw_inout_cnfm_ins_p(i_acnt_no
                  , i_sub_no
                  , '01'
                  , i_rmrk_cd
                  , i_cash
                  , i_work_mn
                  , i_work_trm
                  , i_acc_act_cd
                  , i_cnte
                  , t_seq_no
                  , i_mdm_tp
                  , NULL
                  , NULL
                  , NULL
                  , 'N'
                  ,o_cwd06m00_seq
                  );

        EXCEPTION
            WHEN  OTHERS         THEN
                t_err_txt  :=  t_proc_nm
                       ||  'pcw_inout_cnfm_p_err:'
                       ||  to_char(sqlcode);
                vn.pxc_log_write('drv_pcw_cash_inamt_15711_p','t_err_txt-'||t_err_txt);
        t_err_msg := vn.fxc_get_err_msg('V','2732');
        raise_application_error(-20100,t_err_msg||t_err_txt);
        END;


      o_trd_dt        := t_trd_dt;
      o_trd_seq_no    := t_trd_seq_no;
      o_dpo_prerm     := t_dpo_prerm;
      o_dpo_nowrm     := t_dpo_nowrm;
      o_acnt_place    := t_acnt_place;
      o_bnhof_tp      := t_bnhof_tp;
      o_proc_bnhof_tp := t_proc_bnhof_tp;

            vn.pxc_log_write('drv_pcw_cash_inamt_15711_p','3-1');
      return;

    end if;

  end if;

   /*********************************/
   /* Direct Deposit Start          */
   /*********************************/

   vn.pxc_log_write('drv_pcw_cash_inamt_15711_p','Direct Deposit start' );

   if i_sub_no ='80' then
  /*Tk phai sinh*/
   BEGIN
        select  nvl(dpo,0)
          into  tn_dpo_prerm
          from  vn.DRCWDM00
         where  acnt_no  =  i_acnt_no
       and  sub_no   =  i_sub_no
        /* for  update  of  dpo*/
           for  update;
    EXCEPTION
        WHEN  NO_DATA_FOUND  THEN
            vn.pxc_log_write('drv_pcw_cash_inamt_15711_p',' check 2: ' || sqlcode );
      t_ATDPST_found_yn           :=  'N';
            t_err_txt  :=  t_proc_nm
                   ||  '????(DRCWDM00) ??? ??:'
                   ||  to_char(sqlcode);
      t_err_msg := vn.fxc_get_err_msg('V','2704');
      raise_application_error(-20100,t_err_msg||t_err_txt);
        WHEN  OTHERS         THEN
        vn.pxc_log_write('drv_pcw_cash_inamt_15711_p',' check 3: ' || sqlcode );
            t_err_txt  :=  t_proc_nm
                   ||  '????(DRCWDM00) ??? ??:'
                   ||  to_char(sqlcode);
      t_err_msg := vn.fxc_get_err_msg('V','2704');
      raise_application_error(-20100,t_err_msg||t_err_txt);
   END;
---------------check ---------------
 if tn_dpo_prerm                 IS NULL
   then
        t_err_txt  :=  t_proc_nm
               ||  '?????????? NULL? ?';
    t_err_msg := vn.fxc_get_err_msg('V','2708');
    raise_application_error(-20100,t_err_msg||t_err_txt);
    end if;

   if  tn_dpo_prerm          <  0
   then
        t_err_txt  :=  t_proc_nm
               ||  '????(DRCWDM00)? ??? ??';
    t_err_msg := vn.fxc_get_err_msg('V','2002');
    raise_application_error(-20100,t_err_msg||t_err_txt);
   end if;

   ----------lay seq_no--------
    vn.pxc_psb_seq_cret_p  (   i_acnt_no
               ,  i_sub_no
                           ,  i_trd_dt
                           ,  o_trd_seq_no
                           ,  t_tot_trd_seq_no
                           );

                           ------------lay so du kha dung-------
                            tn_dpo      := tn_dpo_prerm + i_cash;
    tn_tot_dpo_prerm := vn.drv_fcw_tot_dpo_prerm(i_acnt_no);
    tn_tot_dpo       := tn_tot_dpo_prerm + i_cash;


    ----update so du--------
    BEGIN
          update  vn.DRCWDM00
             set  dpo              = tn_dpo
               ,  work_mn          = i_work_mn
               ,  work_dtm         = sysdate
               ,  work_trm         = i_work_trm
           where  acnt_no  =  i_acnt_no
         and  sub_no   =  i_sub_no;
      EXCEPTION
          WHEN  OTHERS         THEN
              t_err_txt  :=  t_proc_nm
                     ||  '??_????(cwd01m00) ??? ??:'
                     ||  to_char(sqlcode);
        t_err_msg := vn.fxc_get_err_msg('V','2703');
        raise_application_error(-20100,t_err_msg||t_err_txt);
      END;

      else

/*Tk co so*/
   BEGIN
        select  nvl(dpo,0)
          into  tn_dpo_prerm
          from  vn.CWD01M00
         where  acnt_no  =  i_acnt_no
       and  sub_no   =  i_sub_no
        /* for  update  of  dpo*/
           for  update;
    EXCEPTION
        WHEN  NO_DATA_FOUND  THEN
            vn.pxc_log_write('drv_pcw_cash_inamt_15711_p',' check 2: ' || sqlcode );
      t_ATDPST_found_yn           :=  'N';
            t_err_txt  :=  t_proc_nm
                   ||  '????(DRCWDM00) ??? ??:'
                   ||  to_char(sqlcode);
      t_err_msg := vn.fxc_get_err_msg('V','2704');
      raise_application_error(-20100,t_err_msg||t_err_txt);
        WHEN  OTHERS         THEN
        vn.pxc_log_write('drv_pcw_cash_inamt_15711_p',' check 3: ' || sqlcode );
            t_err_txt  :=  t_proc_nm
                   ||  '????(DRCWDM00) ??? ??:'
                   ||  to_char(sqlcode);
      t_err_msg := vn.fxc_get_err_msg('V','2704');
      raise_application_error(-20100,t_err_msg||t_err_txt);
   END;
---------------check ---------------
 if tn_dpo_prerm                 IS NULL
   then
        t_err_txt  :=  t_proc_nm
               ||  '?????????? NULL? ?';
    t_err_msg := vn.fxc_get_err_msg('V','2708');
    raise_application_error(-20100,t_err_msg||t_err_txt);
    end if;

   if  tn_dpo_prerm          <  0
   then
        t_err_txt  :=  t_proc_nm
               ||  '????(DRCWDM00)? ??? ??';
    t_err_msg := vn.fxc_get_err_msg('V','2002');
    raise_application_error(-20100,t_err_msg||t_err_txt);
   end if;

   ----------lay seq_no--------
    vn.pxc_psb_seq_cret_p  (   i_acnt_no
               ,  i_sub_no
                           ,  i_trd_dt
                           ,  o_trd_seq_no
                           ,  t_tot_trd_seq_no
                           );

                           ------------lay so du kha dung-------
                            tn_dpo      := tn_dpo_prerm + i_cash;
    tn_tot_dpo_prerm := vn.drv_fcw_tot_dpo_prerm(i_acnt_no);
    tn_tot_dpo       := tn_tot_dpo_prerm + i_cash;


    ----update so du--------
    BEGIN
          update  vn.CWD01M00
             set  dpo              = tn_dpo
               ,  work_mn          = i_work_mn
               ,  work_dtm         = sysdate
               ,  work_trm         = i_work_trm
           where  acnt_no  =  i_acnt_no
         and  sub_no   =  i_sub_no;
      EXCEPTION
          WHEN  OTHERS         THEN
              t_err_txt  :=  t_proc_nm
                     ||  '??_????(cwd01m00) ??? ??:'
                     ||  to_char(sqlcode);
        t_err_msg := vn.fxc_get_err_msg('V','2703');
        raise_application_error(-20100,t_err_msg||t_err_txt);
      END;
      end if;
   /* Account Manager VD limited Reduce */
    BEGIN
        insert  into  vn.aaa10m00
             (
         acnt_no
        ,sub_no
        ,trd_dt
        ,tot_trd_seq_no
        ,trd_seq_no
        ,trd_tp
        ,rmrk_cd
        ,mdm_tp
        ,cncl_yn
        ,org_trd_no
        ,trd_amt
        ,cmsn
        ,adj_amt
        ,dpo_prerm
        ,dpo_nowrm
        ,tot_dpo_prerm
        ,tot_dpo_nowrm
                ,acnt_mng_bnh
                ,agnc_brch
                ,work_bnh
                ,proc_agnc_brch
        ,work_mn
        ,work_dtm
        ,work_trm
        ,cnte
             )
        values
             (
         i_acnt_no
        ,i_sub_no
        ,i_trd_dt
        ,t_tot_trd_seq_no
        ,o_trd_seq_no
        ,'10'
        ,i_rmrk_cd
        ,i_mdm_tp
        ,'N'
        ,0
        ,i_cash
        ,0
        ,i_cash
        ,tn_dpo_prerm
        ,tn_dpo
        ,tn_tot_dpo_prerm
        ,tn_tot_dpo
                ,ts_acnt_mng_bnh
                ,ts_agnc_brch
                ,t_proc_brch_cd
                ,t_proc_agnc_brch
        ,i_work_mn
        ,t_work_dtm
        ,i_work_trm
        ,i_acc_act_cd||'-' || to_char(o_trd_seq_no) || '-' ||i_cnte
             );
    EXCEPTION
        WHEN  OTHERS         THEN
            t_err_txt  :=  t_proc_nm
                   ||  'aaa10m00 error : '
                   ||  to_char(sqlcode);
      t_err_msg := vn.fxc_get_err_msg('V','9405');
      raise_application_error(-20100,t_err_msg||t_err_txt);
    END;

  o_dpo_nowrm     := tn_dpo;


/*******************************/
/* call evaluation for margin  */
/******************************/
if i_sub_no ='01' then
BEGIN
   vn.pdl_crd_loan_rt_proc_td
     (  i_trd_dt
     ,'1' -- cash
     ,i_acnt_no
     ,i_sub_no
     ,o_trd_seq_no
     ,i_work_mn
     ,i_work_trm
     ,o_cnt
       );
    EXCEPTION
     WHEN OTHERS THEN
         t_err_txt := 'call pdl_crd_loan_rt_proc_td error : ' || sqlerrm ;
     t_err_msg := vn.fxc_get_err_msg('V','2748');
     raise_application_error(-20100,t_err_msg||t_err_txt);
   END ;
   end if;
/*============================================================================*/
/* ???? SETTING                                                           */
/*============================================================================*/
    o_trd_dt                := nvl(i_trd_dt, '0')         ;
    o_dpo_prerm             := tn_dpo_prerm           ;
    o_dpo_nowrm             := tn_dpo           ;
    o_acnt_place            := ts_acnt_mng_bnh          ;
    o_bnhof_tp              := ts_agnc_brch       ;
  o_proc_bnhof_tp         := '0'       ;

end  drv_pcw_cash_inamt_15711_p;
/

