create function fdl_get_lnd_sign
(
	i_code		in		varchar2
) return number as

begin

	if i_code in ('702','712','718','722','728','762','772','778') then
     return 1;
	else
     return -1;
	end if;

end ;
/

