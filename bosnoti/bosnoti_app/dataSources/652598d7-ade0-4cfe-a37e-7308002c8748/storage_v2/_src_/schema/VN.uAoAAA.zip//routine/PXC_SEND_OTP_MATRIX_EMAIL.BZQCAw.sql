create procedure    pxc_send_otp_matrix_email(
    i_acnt_no       varchar2,
    i_work_mn       varchar2,
    i_work_trm      varchar2
) 
as
/* ************************************************************************************************
    Author:         hphan
    Created Date:   26-Sep-2021
    Description:    This stored procedure is used to calculcate the profit/loss of stocks which have selling transaction

    Sample call:
        declare
            i_acnt_no   varchar2(10)    := '039C001993';
            i_work_mn   varchar2(15)    := 'lthpt01';
            i_work_trm  varchar2(15)    := '1.1.1.1';
        begin
            vn.pxc_send_otp_matrix_email(
                i_acnt_no,
                i_work_mn,
                i_work_trm
            );
        end;

    MODIFICATION DETAILS:
    -------------------------------------------------------------------------------------------------
    Modified Date   Modified By       Modification Details
    -------------------------------------------------------------------------------------------------
    26-Sep-2021     hphan             Initial creation

**************************************************************************************************/

    -- Common variable
    t_proc_nm           varchar2(30)                := 'pxc_send_otp_matrix_email';
    t_err_msg           varchar2(500)               := null;
    t_err_msg_log       varchar2(500)               := null;
    t_vwdate            varchar2(8)                 := vn.vwdate();

    -- Local variable
    t_otp               clob                        := null;
    t_msg               clob                        := ' ';

    t_com_email         xcc99m00.com_email%type     := 'ekyc@nhsv.vn';
    t_recv_email        varchar2(100)               := null;
    t_cust_nm           varchar2(100)               := null;
    t_func_cd           varchar2(10)                := 'F01106';
    t_msg_lang          varchar2(1)                 := null;
    t_sub_no            varchar2(2)                 := '00';
    t_func_tp           varchar2(1)                 := '1';

    -- Variable for attached file
    t_attach_name       varchar2(50)                := null;
    t_attach_file       blob                        := null;
    t_attach_mime       VARCHAR2(100)               := 'text/plain';
begin

    -- log
    vn.pxc_log_write(t_proc_nm, '');
    vn.pxc_log_write(t_proc_nm, 'Start '                    || t_proc_nm        || ' for: '
                                || ' i_acnt_no: '           || i_acnt_no
    );

    -- Get OTP matrix
    begin
        select
            a1.cust_nm,
            '||' || a9.iss_no   ||
            '||' || a9.m_1      ||
            '||' || a9.m_2      ||
            '||' || a9.m_3      ||
            '||' || a9.m_4      ||
            '||' || a9.m_5      ||
            '||' || a9.m_6      ||
            '||' || a9.m_7      ||
            '||' || a9.m_8      ||
            '||' || a9.m_9      ||
            '||' || a9.m_10     ||
            '||' || a9.m_11     ||
            '||' || a9.m_12     ||
            '||' || a9.m_13     ||
            '||' || a9.m_14     ||
            '||' || a9.m_15     ||
            '||' || a9.m_16     ||
            '||' || a9.m_17     ||
            '||' || a9.m_18     ||
            '||' || a9.m_19     ||
            '||' || a9.m_20     ||
            '||' || a9.m_21     ||
            '||' || a9.m_22     ||
            '||' || a9.m_23     ||
            '||' || a9.m_24     ||
            '||' || a9.m_25     ||
            '||' || a9.m_26     ||
            '||' || a9.m_27     ||
            '||' || a9.m_28     ||
            '||' || a9.m_29     ||
            '||' || a9.m_30     ||
            '||' || a9.m_31     ||
            '||' || a9.m_32     ||
            '||' || a9.m_33     ||
            '||' || a9.m_34     ||
            '||' || a9.m_35             otp,
            a2.otp_matrix_doc           otp_matrix_doc,
            a2.otp_matrix_doc_nm        otp_matrix_doc_nm
        into
            t_cust_nm,
            t_otp,
            t_attach_file,
            t_attach_name
        from vn.aaa01m00 a1
        inner join vn.aaa99m01 a9
        on a1.iss_no = a9.iss_no
        left join vn.aaa99m02 a2
        on a9.iss_no = a2.iss_no
        where
            a1.acnt_no  = i_acnt_no
        and a1.sub_no   = t_sub_no
        and rownum = 1;
    exception
        when others then
            t_err_msg       := vn.fxc_get_err_msg('V','2157');
            t_err_msg_log   := t_err_msg || '. Error when getting data from aaa01m00. ' || sqlcode || ' - ' || sqlerrm;

            vn.pxc_log_write(t_proc_nm, t_err_msg_log);
            raise_application_error(-20100, t_err_msg);
    end;

     vn.pxc_log_write(t_proc_nm, 't_otp: ' || t_otp);
    -- Send email to customer
    begin
        -- Getting file from here, but the table design has not been completed yet

        -- Send email
        vn.pxc_email_ins(
            t_vwdate,                       -- i_send_dt          
            t_recv_email,                   -- i_recv_email_add   
            t_com_email,                    -- i_send_email_add   
            t_func_cd,                      -- i_func_cd          
            t_msg_lang,                     -- i_msg_lang         
            ' ',                          -- i_email_msg        
            t_attach_name,                  -- i_attach_name      
            t_attach_file,                  -- i_attach_file      
            i_work_mn,                      -- i_work_mn          
            i_work_trm,                     -- i_work_trm         
            i_acnt_no,                      -- i_acnt_no          
            t_sub_no,                       -- i_sub_no           
            t_func_tp                       -- i_func_tp          
        );
    exception 
        when others then
            t_err_msg       := vn.fxc_get_err_msg('V','2147');
            t_err_msg_log   := t_err_msg || '. Error when calling pxc_email_ins. '
                                            || sqlcode || ' - ' || sqlerrm;

            vn.pxc_log_write(t_proc_nm, t_err_msg_log);
            raise_application_error(-20100, t_err_msg);
    end;

    -- End
    vn.pxc_log_write(t_proc_nm, 'End.');

end pxc_send_otp_matrix_email;
/

