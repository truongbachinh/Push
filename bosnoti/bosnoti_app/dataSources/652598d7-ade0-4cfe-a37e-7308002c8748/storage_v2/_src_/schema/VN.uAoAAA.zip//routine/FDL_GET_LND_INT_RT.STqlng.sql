create function fdl_get_lnd_int_rt
(
    i_lnd_tp       in   varchar2,        --
    i_lnd_bank_cd  in   varchar2,        --
    i_cpt_rpy_tp   in   varchar2,        --
    i_int_rpy_tp   in   varchar2,        --
    i_lnd_dt       in   varchar2         --
)
    return  number
as

	o_lnd_int_rt   number := 0;
    t_err_txt      varchar2(80)  ; -- error text buffer

begin

/*============================================================================*/
/* Return Loan Interest                                                       */
/*============================================================================*/
	for c1 in (
		select nvl(lnd_apy_val,0) lnd_apy_val
	      from vn.dlm12m10
	     where lnd_bank_cd    =  i_lnd_bank_cd
	       and lnd_tp         =  i_lnd_tp
	       and cpt_rpy_tp     =  i_cpt_rpy_tp
	       and int_rpy_tp     =  i_int_rpy_tp
	       and lnd_apy_val_tp =  '01'
	       and apy_dt	      = (select max(apy_dt)
	                               from vn.dlm12m10
	                              where lnd_bank_cd     =  i_lnd_bank_cd
	                                and lnd_tp          =  i_lnd_tp
	                                and cpt_rpy_tp      =  i_cpt_rpy_tp
	                                and int_rpy_tp      =  i_int_rpy_tp
	                                and lnd_apy_val_tp  =  '01'
	                                and apy_dt         <=  i_lnd_dt)
	) loop
		o_lnd_int_rt := c1.lnd_apy_val;
	end loop;

    return o_lnd_int_rt;

end fdl_get_lnd_int_rt;
/

