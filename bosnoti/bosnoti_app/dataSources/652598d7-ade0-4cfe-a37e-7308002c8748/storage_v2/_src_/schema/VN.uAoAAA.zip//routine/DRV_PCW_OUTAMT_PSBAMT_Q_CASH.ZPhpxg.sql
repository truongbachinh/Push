create procedure drv_pcw_outamt_psbamt_q_cash(i_acnt_no in varchar2 -- account no
                                                     ,
                                                      i_sub_no  in varchar2 -- sub no
                                                     ,
                                                      i_bank_cd in varchar2 -- bank_cd (invest customer  : 9999 )

                                                     ,
                                                      o_dpo             out number -- Total Deposit
                                                     ,
                                                      o_dpo_block       out number -- Block amount in dpo
                                                     ,
                                                      o_outq_dpo_bk     out number -- waiting for withdraw amt ( daily clear )
                                                     ,
                                                     o_tot_out_psbamt  out number -- possible withdraw deposit
                                                      ) AS

  /*
     \file     drv_pcw_outamt_psbamt_q_cash.sql

     \section intro Program Information
          - Program Name              : get able amt drv
          - Service Name              : N/A
          - Related Client Program- Client Program ID :
          - Related Tables            : dpo
          - Dev. Date                 :2017/01/18
          - Developer                 :Hieu.dt
          - Business Logic Desc.      :
          - Latest Modification Date  : 2017/01/18

     \section history Program Modification History

     \section hardcoding Hard-Coding List
      - HC-1

     \section info Additional Reference Comments

  */

  t_proc_nm   varchar2(100); --
  t_err_msg   varchar2(500); --
  t_err_txt   varchar2(500); -- error text buffer
  o_dpo_coll_blf   number ;
  o_collect_ver_lisr number;
  o_dpo_block_ast    number;
  t_fee_tax   number := 0;
BEGIN

  t_proc_nm := 'drv_pcw_outamt_psbamt_q_cash';

  o_dpo         := 0;
  o_dpo_block   := 0;
  o_outq_dpo_bk := 0;
  o_tot_out_psbamt := 0;
  o_dpo_coll_blf    :=0;
  o_collect_ver_lisr  :=0;
  o_dpo_block_ast     :=0;
  vn.pxc_log_write('drv_pcw_outamt_psbamt_q_cash',
                   'acnt_no  ' || i_acnt_no || ',' || i_sub_no || ',' ||
                   i_bank_cd);

  BEGIN
    select nvl(dpo, 0),
           nvl(dpo_block, 0),
           nvl(outq_dpo_bk, 0),
           nvl(dpo_coll_blk, 0),
           nvl(collect_ver_lisr, 0),
           nvl(dpo_block_dlv,0)
      into o_dpo,
           o_dpo_block,
           o_outq_dpo_bk,
           o_dpo_coll_blf,
           o_collect_ver_lisr,
           o_dpo_block_ast
      from vn.drcwdm00
     where acnt_no = i_acnt_no
       and sub_no = i_sub_no;
  EXCEPTION
    WHEN OTHERS THEN
      t_err_txt := t_proc_nm || ' cwd01m00  err:' || to_char(sqlcode) || ' ' ||
                   i_acnt_no;
      t_err_msg := vn.fxc_get_err_msg('V', '2704');
      raise_application_error(-20100, t_err_msg || t_err_txt);
  END;


  vn.pxc_log_write('drv_pcw_outamt_psbamt_q_cash',
                   'o_dpo           : ' || o_dpo);
  vn.pxc_log_write('drv_pcw_outamt_psbamt_q_cash',
                   'o_dpo_block     : ' || o_dpo_block);
  vn.pxc_log_write('drv_pcw_outamt_psbamt_q_cash',
                   'o_outq_dpo_bk   : ' || o_outq_dpo_bk);

  if o_dpo < 0 or o_dpo_block < 0 then
    vn.pxc_log_write('drv_pcw_outamt_psbamt_q_cash', 'select amt is minus ');
    t_err_txt := t_proc_nm || 'amt  is minus ';
    raise_application_error(-20220, t_err_txt);
  end if;
  /*BEGIN
  select vn.fdr_get_unsetl_data (i_acnt_no,i_sub_no)
      into t_fee_tax
from dual;
   EXCEPTION
   WHEN  OTHERS         THEN
      t_err_txt  :=  t_proc_nm
                   ||  ' fdr_get_unsetl_data  err:'
                   ||  to_char(sqlcode)
           ||' ' || i_acnt_no;
            t_err_msg := vn.fxc_get_err_msg('V','2704');
            raise_application_error(-20100,t_err_msg||t_err_txt);
   END;*/

o_tot_out_psbamt := greatest(o_dpo - o_dpo_block - o_outq_dpo_bk - o_dpo_coll_blf - o_collect_ver_lisr - t_fee_tax,0);
end drv_pcw_outamt_psbamt_q_cash;
/

