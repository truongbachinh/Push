create procedure fcw_check_trans_bank_deposit1
(
  is_acnt_no      in    varchar2,
  is_sub_no       in    varchar2,
  os_passwd      in out  varchar2,
  os_idno          in out  varchar2
) as


  ts_passwd varchar2(30) ;
  ts_idno varchar2(30) ;

    t_err_msg    varchar2(500);


begin


    begin
         select  NVL(pswd,'!') ,
             NVL(idno,'!')
        into
           ts_passwd
          ,ts_idno
        from vn.aaa01m00
        where acnt_no = is_acnt_no
          and sub_no  = is_sub_no
                  and acnt_stat =  '1' ;
    exception
    when no_data_found then
             t_err_msg := vn.fxc_get_err_msg('V','2001');
             raise_application_error(-20100,t_err_msg);
    end ;

     os_passwd := ts_passwd ;
     os_idno   := ts_idno ;


end fcw_check_trans_bank_deposit1;
/

