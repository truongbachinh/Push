create function fbm_get_biz_prd_info(
    i_ret_tp            varchar2,       -- 1: net_fee_yn,   2: system_cutoff_rt     3: cost_of_cap_rt   4: rev_pur_factor
    i_dt                varchar2,
    i_acnt_no           varchar2,
    i_sub_no            varchar2,
    i_emp_no            varchar2,
    i_biz_prd_cd        varchar2,
    i_biz_cmsn_tp       varchar2,
    i_biz_cmsn_knd      varchar2
)
return varchar2

as
    t_emp_no                    varchar2(15)    := i_emp_no;
    t_biz_prd_cd                varchar2(20)    := i_biz_prd_cd;

    t_deft_net_fee_yn           varchar2(2)     := 'Y';
    t_deft_system_cutoff_rt     varchar2(38)    := '0';
    t_deft_cost_of_cap_rt       varchar2(38)    := '0';
    t_deft_rev_pur_factor       varchar2(38)    := '1';

    o_ret                       varchar2(38)    := '';

    t_proc_nm                   varchar2(30)    := 'fbm_get_biz_prd_info';
    t_err_msg                   varchar2(500)   := ' ';
begin

    vn.pxc_log_write(t_proc_nm, 'i_biz_cmsn_knd: '  || i_biz_cmsn_knd);

    if(i_acnt_no is not null and t_emp_no is null) then
        begin
            select emp_no
            into t_emp_no
            from vn.bmi01m00
            where acnt_no = i_acnt_no
            and sub_no = '00'
            and i_dt between mng_emp_regi_dt and to_char(cls_dtm, 'YYYYMMDD');
        exception 
            when no_data_found then
                select 
                    decode(i_ret_tp,
                            '1',     t_deft_net_fee_yn,
                            '2',     t_deft_system_cutoff_rt,
                            '3',     t_deft_cost_of_cap_rt,
                            '4',     t_deft_rev_pur_factor,
                            null
                    ) ret
                into o_ret
                from dual;

                return o_ret;
            when others then
                t_err_msg   := 'Error when getting data from bmi01m00 for: '
                        || ' acnt_no = ' || i_acnt_no
                        || ' dt = '      || i_dt
                        || ' sqlcode = ' || sqlcode
                        || ' sqlerrm = ' || sqlerrm;

                vn.pxc_log_write(t_proc_nm, t_err_msg);
                raise_application_error(-20100, t_err_msg);
        end;
    end if;

    if(t_emp_no is not null and t_biz_prd_cd is null) then
        begin
            select biz_prd_cd
            into t_biz_prd_cd
            from vn.rms04m00
            where emp_no = t_emp_no
            and biz_cmsn_tp = i_biz_cmsn_tp
            and i_dt between apy_dt and expr_dt
            and active_stat = 'Y';
        exception 
            when no_data_found then
                select 
                    decode(i_ret_tp,
                            '1',     t_deft_net_fee_yn,
                            '2',     t_deft_system_cutoff_rt,
                            '3',     t_deft_cost_of_cap_rt,
                            '4',     t_deft_rev_pur_factor,
                            null
                    ) ret
                into o_ret
                from dual;

                return o_ret;
            when others then
                t_err_msg   := 'Error when getting data from rms04m00 for: '
                        || ' emp_no = ' || t_emp_no
                        || ' dt = '      || i_dt
                        || ' sqlcode = ' || sqlcode
                        || ' sqlerrm = ' || sqlerrm;

                vn.pxc_log_write(t_proc_nm, t_err_msg);
                raise_application_error(-20100, t_err_msg);
        end;
    end if;

    begin
        select 
            decode(i_ret_tp,
                   '1',     net_fee_yn,
                   '2',     to_char(system_cutoff_rt),
                   '3',     to_char(cost_of_cap_rt),
                   '4',     to_char(rev_pur_factor),
                   null
                   )
        into o_ret
        from vn.rms03m01 rm31                     -- Chi tiet SPHH
        where rm31.biz_prd_cd = t_biz_prd_cd
        and rm31.biz_cmsn_knd = i_biz_cmsn_knd
        and rm31.active_stat = 'Y'
        and (rm31.biz_prd_cd, rm31.biz_cmsn_knd, rm31.apy_dt) in (
                select rm311.biz_prd_cd, rm311.biz_cmsn_knd, max(rm311.apy_dt) max_apy_dt
                from vn.rms03m01 rm311
                where rm311.biz_prd_cd = t_biz_prd_cd
                and rm311.biz_cmsn_knd = i_biz_cmsn_knd
                and rm311.active_stat = 'Y'
                and rm311.apy_dt <= i_dt
                group by rm311.biz_prd_cd, rm311.biz_cmsn_knd
            );
    exception 
        when no_data_found then
            select 
                decode(i_ret_tp,
                        '1',     t_deft_net_fee_yn,
                        '2',     t_deft_system_cutoff_rt,
                        '3',     t_deft_cost_of_cap_rt,
                        '4',     t_deft_rev_pur_factor,
                        null
                ) ret
            into o_ret
            from dual;

            return o_ret;
        when others then
            t_err_msg   := 'Error when getting data from rms03m01 for: '
                    || ' t_biz_prd_cd = '       || t_biz_prd_cd
                    || ' i_biz_cmsn_knd = '     || i_biz_cmsn_knd
                    || ' dt = '                 || i_dt
                    || ' sqlcode = '            || sqlcode
                    || ' sqlerrm = '            || sqlerrm;

            vn.pxc_log_write(t_proc_nm, t_err_msg);
            raise_application_error(-20100, t_err_msg);
    end;

    return o_ret;
end fbm_get_biz_prd_info;
/

