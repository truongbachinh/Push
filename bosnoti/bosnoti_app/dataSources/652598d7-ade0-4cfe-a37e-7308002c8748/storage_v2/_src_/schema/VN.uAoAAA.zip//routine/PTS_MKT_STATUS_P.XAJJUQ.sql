create PROCEDURE PTS_MKT_STATUS_P (
    I_MKT_DRV_TP		IN		VARCHAR2,
    P_ErrCode         	OUT    	NUMBER,    /* ���� ���          */
    P_ErrMsg          	OUT    	VARCHAR2   /* Error Message        */
) AS


/*!
    \file     PTS_MKT_STATUS_P
    \brief    Non conclusion quantity clear

    \section intro Program Information
        - Program Name              : PTS_MKT_STATUS_P
        - Service Name              :
        - Related Client Program- Client Program ID :
        - Related Tables            : TSO03M00
        - Dev. Date                 : 2007/12/08
        - Developer                 : NSKIM
        - Business Logic Desc.      :
        - Latest Modification Date  :

    \section history Program Modification History
        - 1.0  2007/12/08    SB.LEE       First make

    \section hardcoding Hard-Coding List

    \section info Additional Reference Comments
*/



BEGIN
	P_ErrCode := 0;
	P_ErrMsg := ' ';

	if ( I_MKT_DRV_TP = 'P' or I_MKT_DRV_TP = 'O' or I_MKT_DRV_TP = 'A' or I_MKT_DRV_TP = 'C' ) THEN

        UPDATE 	VN.TSO03M00
        SET		MKT_DRV_TP = I_MKT_DRV_TP
        WHERE	SB_KFX_TP = 'HOSTC';

        IF  SQL%NOTFOUND    THEN
        	INSERT INTO VN.TSO03M00
	        (
	        	SB_KFX_TP,
	        	STK_TP,
	        	MKT_DRV_TP,
	        	WORK_MN,
	        	WORK_DTM,
	        	WORK_TRM
	        )
	        VALUES
	        (
	        	'HOSTC',
	        	'10',
	        	I_MKT_DRV_TP,
	        	'BATCH',
	        	SYSDATE,
	        	'BATCH'
	        );

	        INSERT INTO VN.TSO03M00
	        (
	        	SB_KFX_TP,
	        	STK_TP,
	        	MKT_DRV_TP,
	        	WORK_MN,
	        	WORK_DTM,
	        	WORK_TRM
	        )
	        VALUES
	        (
	        	'HOSTC',
	        	'20',
	        	I_MKT_DRV_TP,
	        	'BATCH',
	        	SYSDATE,
	        	'BATCH'
	        );

	        INSERT INTO VN.TSO03M00
	        (
	        	SB_KFX_TP,
	        	STK_TP,
	        	MKT_DRV_TP,
	        	WORK_MN,
	        	WORK_DTM,
	        	WORK_TRM
	        )
	        VALUES
	        (
	        	'HOSTC',
	        	'30',
	        	I_MKT_DRV_TP,
	        	'BATCH',
	        	SYSDATE,
	        	'BATCH'
	        );
        END if;
    END IF;

    EXCEPTION

    WHEN OTHERS THEN
        P_ERRCODE := SQLCODE;
        P_ERRMSG  := SQLERRM;


END PTS_MKT_STATUS_P;
/

