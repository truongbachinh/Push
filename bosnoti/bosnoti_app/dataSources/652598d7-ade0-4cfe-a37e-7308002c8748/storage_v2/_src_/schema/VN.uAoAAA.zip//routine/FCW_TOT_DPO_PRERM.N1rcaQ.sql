create function fcw_tot_dpo_prerm
(

	i_acnt_no  in   varchar2

)

	return          number
as
    t_dpo				number := 0;

begin

    begin

	   select sum(dpo)
	     into t_dpo
	     from vn.cwd01m00
        where acnt_no = i_acnt_no;

	    exception
		     when others then
			      t_dpo := 0;

     end;

  return  t_dpo;

end fcw_tot_dpo_prerm;
/

