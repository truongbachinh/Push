create procedure pts_bat_xih_trunc (
    i_work_dt       in      varchar2,       -- date(yyyymmdd)
	o_err_code      in      number,         -- error code(0:SUCCESS)
	o_err_msg       in      varchar2        -- error message
) as

t_err_code      number        := o_err_code;
t_err_msg       varchar2(600) := rtrim(o_err_msg);
t_chk           varchar2(1);
t_cnt           number;
exp_error       exception;

/*!
    \file     pts_bat_xih_trunc
	\brief    xih03m00, xih03m10 table reset

	\section intro Program Information
		- Program Name              : pts_bat_xih_trunc
		- Service Name              :
		- Related Client Program- Client Program ID :
		- Related Tables            : xih03m00, xih03m10
		- Dev. Date                 : 2007/11/27
		- Developer                 : ejlee
		- Business Logic Desc.      :
		- Latest Modification Date  :

	\section history Program Modification History
		- 1.0  2007/11/27

	\section hardcoding Hard-Coding List

	\section info Additional Reference Comments
*/

begin

	t_err_code := 0;
	t_err_msg  := 'SUCCESS';
	t_chk      := 'Y';

	-- 1. ?? ??ü?????u Funüu

	-- 2. ?????? ??????
	if t_chk = 'Y' then
		delete from vn.xih03m00;
		delete from vn.xih03m01;
		delete from vn.xih03m10;
		delete from vn.xih03m11;
		delete from vn.xih03m12;
		delete from vn.xih03m11_npro;
		delete from vn.xih03m12_npro;    
		delete from vn.xih03m13;
		delete from vn.xih02m10;
		delete from vn.xih02m20;
		delete from vn.xih03m20;
		delete from vn.xih03m21;
		delete from vn.xih03m31;
		delete from vn.xih03m30;
		delete from vn.xih02m11;
	else
		t_err_code := -1;
	    t_err_msg  := '?? ??ü???????? ?? ü???ó?????ÿ?';
		raise_application_error(-20100,'[pts_bat_xih_trunc] ' || t_err_msg);
	end if;

	exception when  exp_error then
		t_err_code := sqlcode;
		t_err_msg  := sqlerrm;
		raise_application_error(-20100,'[pts_bat_xih_trunc] ' || t_err_msg);

end pts_bat_xih_trunc;
/

