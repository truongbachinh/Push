create PROCEDURE return1 (
	i_trd_dt				in		varchar2		-- 거래일
,	i_work_mn				in		varchar2		-- 작업자
,	i_work_trm				in		varchar2		-- 작업단말
,   o_cnt                   out     number          -- 처리결과
) is


    o_tot_prof_rel_amt     NUMBER := 0;		/* 당일현금증거금		*/
    o_tot_prof_vit_amt     NUMBER := 0;		/* 전일현금증거금		*/
    o_tot_prof_amt_ts    NUMBER := 0;		/* 전전일현금증거금		*/
    o_errcode            varchar2(10);		/* 전전전일현금증거금	*/
    t_tot_prof_amt    NUMBER := 0;		/* 총현금증거금			*/
    t_errcode         NUMBER := 0;		/* 오류 코드			*/
    t_errmsg          VARCHAR2(200);	/* Error Message		*/

	t_init_gst_dpo    NUMBER := 0;		/* 초기화 가입금금액	*/

	tn_gst_dpo_prerm	number := 0;
	tn_gst_dpo_nowrm	number := 0;
	o_seq_no	        number := 158;


-- cw_07303_q1 참고

--**********************************************************************
--	MAIN PROCEDURE
--**********************************************************************
    t_err_msg    varchar2(500);
    t_err_txt				varchar2(200) := Null;

begin

	o_cnt := 0;

	for c1 in (

		select
			acnt_no,
			dpo,
			gst_dpo
		from vn.cwd01h00
       where std_dt = '20110509'
		 and gst_dpo > 0
	   order by 1

	)
	loop
begin
    select nvl(sum(TD_CASH_PROF_GST_AMT
			 + PD_CASH_PROF_GST_AMT
			 + PPD_CASH_PROF_GST_AMT
			 + PPPD_CASH_PROF_GST_AMT),0)
      into o_tot_prof_vit_amt
	  from vn.tso02h00
     where TD_CASH_PROF_GST_AMT
		  +PD_CASH_PROF_GST_AMT
		  +PPD_CASH_PROF_GST_AMT
		  +PPPD_CASH_PROF_GST_AMT > 0
       and dt = '20110509'
	   and acnt_no = c1.acnt_no;

	   exception

	   when no_data_found then
			o_tot_prof_vit_amt := 0;
       when others then
			o_tot_prof_vit_amt := 0;

end;

		t_tot_prof_amt :=  o_tot_prof_vit_amt ;

		if  t_tot_prof_amt = 0
		then
			t_init_gst_dpo := c1.gst_dpo;
		else

           select  c1.gst_dpo - o_tot_prof_vit_amt
			 into  t_init_gst_dpo
			 from dual ;

		end if;

		vn.pxc_log_write('return1','acnt_no : [ '||c1.acnt_no ||' ]') ;
		vn.pxc_log_write('return1','t_init_gst_dpo : [ '||t_init_gst_dpo ||' ]') ;


    BEGIN
        update  vn.cwd01h00
          set   gst_dpo		= gst_dpo - t_init_gst_dpo
             ,  work_mn		= i_work_mn
	         ,  work_dtm	= sysdate
	         ,  work_trm	= i_work_trm
	     where  acnt_no		= c1.acnt_no
		   and  std_dt = '20110509';
    EXCEPTION
        WHEN  OTHERS         THEN
			t_err_txt  :=  'gst_dpo update err-'||c1.acnt_no||'-'||to_char(sqlcode);
			vn.pxc_log_write('pcw_gst_dpo_init_p','t_err_txt-'||t_err_txt);
			raise_application_error(sqlcode,t_err_txt);
    END;


		BEGIN
			select
				c1.gst_dpo,
				gst_dpo
			  into
				tn_gst_dpo_prerm,
				tn_gst_dpo_nowrm
			  from  vn.cwd01h00
			 where  acnt_no  =  c1.acnt_no
			   and  std_dt = '20110509'
			 ;
		EXCEPTION
			WHEN  OTHERS         THEN
				t_err_txt  :=  'select gst_dpo(a) err-'||c1.acnt_no||'-'||to_char(sqlcode);
				vn.pxc_log_write('pcw_gst_dpo_init_p','t_err_txt-'||t_err_txt);
				raise_application_error(sqlcode,t_err_txt);
		END;

		BEGIN

		update vn.cwd04h00
		   set rmrk_cd = decode(sign(t_init_gst_dpo) , -1 , '005' , '024' )
               ,trd_amt = decode(sign(t_init_gst_dpo) , -1 , t_init_gst_dpo * -1 , t_init_gst_dpo )
			   ,gst_dpo_prerm = tn_gst_dpo_prerm
			   ,gst_dpo_nowrm = tn_gst_dpo_nowrm
         where acnt_no = c1.acnt_no
		   and std_dt = '20110509';

		EXCEPTION


            when  no_data_found  then


		o_seq_no :=  o_seq_no + 1 ;

				  insert into vn.cwd04h00
				  (
				   std_dt
				   ,seq_no
				   ,acnt_no
				   ,rmrk_cd
				   ,trd_amt
				   ,gst_dpo_prerm
				   ,gst_dpo_nowrm
				   ,trd_seq_no
				   ,add_dcr_tp
				   ,work_mn
				   ,work_dtm
				   ,work_trm
				   )
				   values
				   (
				   '20110510'
				   ,o_seq_no
				   ,c1.acnt_no
				   ,decode(sign(t_init_gst_dpo), -1, '005', '024')
				   ,decode(sign(t_init_gst_dpo), -1, t_init_gst_dpo*-1, t_init_gst_dpo)
				   ,tn_gst_dpo_prerm
				   ,tn_gst_dpo_nowrm
				   ,0
				   ,'2'
				   ,i_work_mn
				   ,sysdate
				   ,i_work_mn
				   );

            vn.pxc_log_write('return1', 'o_seq_no  : ' || o_seq_no  ) ;

			WHEN  OTHERS         THEN
				t_err_txt  :=  'update cwd04h00 err-'||c1.acnt_no||'-'||to_char(sqlcode);
				vn.pxc_log_write('pcw_gst_dpo_init_p','t_err_txt-'||t_err_txt);
				raise_application_error(sqlcode,t_err_txt);
		END;

    vn.pxc_log_write('return1', 't_init_gst_dpo  : ' || t_init_gst_dpo  ) ;


    vn.pxc_log_write('return1', 'o_cnt  : ' || o_cnt  ) ;

	o_cnt := o_cnt + 1;

	end loop;

end return1;
/

