create function    fdl_get_mrgn_rm_amt
(
	i_acnt_no        in   varchar2,        --
	i_sub_no         in   varchar2,
	i_setl_dt        in   varchar2
)
    return  number
as

	o_lnd_rm_amt    number := 0;

	t_lnd_int       number := 0;
	t_dly_int       number := 0;
	t_lnd_rm_amt    number := 0;

	td_max_st_dt    varchar2(08) := null;
	ts_mrgn_rpy_yn  varchar2(01) := null;

    t_err_msg       varchar2(500);

begin

/*============================================================================*/
/* Calculation                                                                */
/*============================================================================*/
	/* To calculate expected margin loan amount from lnd dt to settlement date
	   The last repayment date is Today -1                                       */
	td_max_st_dt := to_char(to_date(vn.vwdate, 'yyyymmdd'),'yyyymmdd') ;

	for C2 in (
        select  acnt_no
              , sub_no
              , lnd_tp
              , lnd_bank_cd
              , mth_dt
              , lnd_dt
              , stk_cd
              , setl_dt
              , expr_dt
              , last_rpy_dt
              , sum(nvl(lnd_amt,0))                           lnd_amt
              , sum(nvl(lnd_rpy_amt,0))                       lnd_rpy_amt
              , sum(nvl(lnd_amt,0)) - sum(nvl(lnd_rpy_amt,0)) lnd_rm_amt
          from  vn.dlm01m00
         where  acnt_no       =   i_acnt_no
           and  sub_no        =   i_sub_no
           and  lnd_tp        =   '10'
           and  lnd_amt > lnd_rpy_amt
         group by acnt_no, sub_no, lnd_tp, lnd_bank_cd, mth_dt, lnd_dt, stk_cd, setl_dt
                 ,expr_dt, last_rpy_dt
         order by lnd_dt
	) loop

		/* If there is PIA that already got
		   When cstomer get the PIA. System already deduct the expected interest amount
		   to each settlement date                                                      */
		IF td_max_st_dt > C2.lnd_dt then
			td_max_st_dt := C2.lnd_dt;

			vn.pxc_log_write('fdl_get_mrgn_rm_amt', 'PIA setl ' || C2.acnt_no ||'-'||C2.sub_no
			                                       ||' Setl date = '|| C2.lnd_dt);

		END IF;
	end loop;

	/* Get the remain margin loan interest from lnad_dt to setl_dt */
	for C1 in (
        select  acnt_no
              , sub_no
              , lnd_tp
              , lnd_bank_cd
              , mth_dt
              , lnd_dt
              , stk_cd
              , setl_dt
              , expr_dt
              , last_rpy_dt
              , sum(nvl(lnd_amt,0))                           lnd_amt
              , sum(nvl(lnd_rpy_amt,0))                       lnd_rpy_amt
              , sum(nvl(lnd_amt,0)) - sum(nvl(lnd_rpy_amt,0)) lnd_rm_amt
          from  vn.dlm01m00
         where  acnt_no       =   i_acnt_no
           and  sub_no        =   i_sub_no
           and  lnd_tp        =   '70'
           and  lnd_amt > lnd_rpy_amt
         group by acnt_no, sub_no, lnd_tp, lnd_bank_cd, mth_dt, lnd_dt, stk_cd, setl_dt
                 ,expr_dt, last_rpy_dt
         order by lnd_dt
	) loop
		t_lnd_int  := 0;
		t_dly_int  := 0;

		t_lnd_int  := vn.fdl_get_mrgn_int(  C1.lnd_tp
	                                    , C1.acnt_no
	                                    , C1.sub_no
	                                    , C1.lnd_bank_cd
	                                    , '1'
	                                    , C1.lnd_dt
	                                    , i_setl_dt
	                                    , C1.expr_dt
	                                    , td_max_st_dt
	                                    , '1'
	                                    , '1'
	                                    , '1'             -- CASH RPY INTEREST
	                                    , '2'
	                                    , C1.lnd_amt
	                                    , C1.lnd_rm_amt
	                                    , C1.lnd_rm_amt
	                                    , vn.fdl_get_mrgn_rt_01(C1.acnt_no, C1.sub_no,'08', C1.lnd_dt)
	                                    );

	    t_dly_int  := vn.fdl_get_mrgn_int( C1.lnd_tp
	                                    , C1.acnt_no
	                                    , C1.sub_no
	                                    , C1.lnd_bank_cd
	                                    , '2'
	                                    , C1.lnd_dt
	                                    , i_setl_dt
	                                    , C1.expr_dt
	                                    , td_max_st_dt
	                                    , '1'
	                                    , '1'
	                                    , '1'             -- CASH RPY INTEREST
	                                    , '2'
	                                    , C1.lnd_amt
	                                    , C1.lnd_rm_amt
	                                    , C1.lnd_rm_amt
	                                    , vn.fdl_get_mrgn_rt_01(C1.acnt_no, C1.sub_no, '09', C1.lnd_dt)
	                                    );

			vn.pxc_log_write('fdl_get_mrgn_rm_amt', 'PIA setl ' || C1.acnt_no ||'-'||C1.sub_no
			                                       ||' C1.lnd_dt = '|| C1.lnd_dt
			                                       ||' i_setl_dt = '|| i_setl_dt
			                                       ||' C1.expr_dt = '|| C1.expr_dt
			                                       ||' td_max_st_dt = '|| td_max_st_dt);

		o_lnd_rm_amt := o_lnd_rm_amt + t_lnd_int + t_dly_int;

	end loop;

	select nvl(mrgn_rpy_yn, 'N')
      into ts_mrgn_rpy_yn
      from dlm08m00
     where acnt_no = i_acnt_no
       and sub_no  = i_sub_no
    ;

	IF ts_mrgn_rpy_yn = 'Y' then
		return o_lnd_rm_amt;
	ELSE
		return 0;
	END IF;

end fdl_get_mrgn_rm_amt;
/

