create PROCEDURE pxc_send_email
   (
    i_sec_cd    IN VARCHAR2,
       i_from_mail      IN    VARCHAR2,
       i_to_mail      IN    VARCHAR2,
       i_subject      IN    VARCHAR2,
       i_body         IN    LONG,
       i_from_name      IN    VARCHAR2,
       i_to_name    IN    VARCHAR2
   ) is

   start_pos          number         := 1;
   end_pos            number;
   delim              varchar2(1)    := ',';
   t_email               varchar2(100);
   the_index          number         := 1;
   t_temp             varchar2(10)   := ' ';
   ts_body            LONG;
   t_err_msg          VARCHAR2(500);

BEGIN
   ts_body    := i_body;
   while start_pos > 0
   loop

     end_pos := instr(i_to_mail, delim, start_pos, 1);

     if end_pos = 0 then
         t_email := substr(i_to_mail, start_pos);
     else
         t_email := substr(i_to_mail, start_pos, end_pos - start_pos);
     end if;

     -- call funs send mail
     t_err_msg:= vn.fxc_send_mail (i_sec_cd, i_from_mail, t_email, i_subject, ts_body, i_from_name, i_to_name);

     the_index := the_index + 1;

     start_pos := instr(i_to_mail, delim, 1, the_index - 1);
     if start_pos = 0 then
         exit;
     else
         start_pos := start_pos + length(delim);
     end if;

   end loop;

   vn.pxc_log_write('pxc_send_email','i_subject -['||t_err_msg||']');

   EXCEPTION
   WHEN OTHERS THEN
         vn.pxc_log_write('pxc_send_email','error -['||sqlerrm||']');
END pxc_send_email;
/

