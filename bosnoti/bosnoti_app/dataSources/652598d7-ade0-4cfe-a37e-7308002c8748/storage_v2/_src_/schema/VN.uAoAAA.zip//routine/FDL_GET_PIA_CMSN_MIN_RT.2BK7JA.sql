create FUNCTION fdl_get_pia_cmsn_min_rt(i_lnd_tp      IN VARCHAR2,
                                                   i_lnd_bank_cd IN VARCHAR2,
                                                   i_lnd_dt      IN VARCHAR2)
  RETURN NUMBER AS

  /*!
    \file     pdl_get_lnd_cmsn_rt.sql
    \brief    get loan repay fee ratio
     \section intro Program Information
         - Program Name              : get loan repay fee ratio
         - Service Name              :
         - Related Client Program- Client Program ID :
         - Related Tables            : dlm12m00, dlm12m10
         - Dev. Date                 : 2008/02/06
         - Developer                 : Lee.
         - Business Logic Desc.      : get loan repay fee ratio
         - Latest Modification Date  : 2008/02/06
     \section history Program Modification History
     - 1.0       2008/02/06     Lee.    New.
     \section hardcoding Hard-Coding List
     - HC-1      2008/02/06     Lee.    [????]
     \section info Additional Reference Comments

        * i_lnd_apy_val_tp
          - 01:lnd_int ratio
          - 02:lnd_int ratio for min duration
          - 03:min lnd_int amt
          - 04:lnd_int dly_rt
          - 11:lnd_fee ratio
          - 12:lnd_fee ratio for min duration
          - 13:min lnd_fee amt
  */

  o_min_lnd_cmsn NUMBER := 0;
  t_err_msg      VARCHAR2(500);

BEGIN

  /*============================================================================*/
  /* commision Calculation                                                      */
  /*============================================================================*/

  FOR c1 IN (SELECT lnd_apy_val_tp, nvl(lnd_apy_val, 0) lnd_apy_val
               FROM vn.dlm12m10
              WHERE lnd_tp = i_lnd_tp /* '10' */
                AND lnd_bank_cd = i_lnd_bank_cd
                AND cpt_rpy_tp = '1'
                AND int_rpy_tp = '1'
                AND (lnd_apy_val_tp, apy_dt) IN
                    (SELECT lnd_apy_val_tp, MAX(apy_dt)
                       FROM vn.dlm12m10
                      WHERE lnd_tp = i_lnd_tp /* '10' */
                        AND lnd_bank_cd = i_lnd_bank_cd
                        AND cpt_rpy_tp = '1'
                        AND int_rpy_tp = '1'
                        AND apy_dt <= i_lnd_dt
                      GROUP BY lnd_apy_val_tp)) LOOP
    IF c1.lnd_apy_val_tp = '15' THEN
      o_min_lnd_cmsn := c1.lnd_apy_val; -- 13:min lnd_fee amt
    END IF;
  END LOOP;
  RETURN o_min_lnd_cmsn;

END fdl_get_pia_cmsn_min_rt;
/

