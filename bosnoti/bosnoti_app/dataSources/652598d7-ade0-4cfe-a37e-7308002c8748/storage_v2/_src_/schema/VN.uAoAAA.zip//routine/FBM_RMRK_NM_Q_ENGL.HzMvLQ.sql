create function fbm_rmrk_nm_q_engl
(
       i_rmrk_cd in varchar2 
) return varchar2 as

  o_rmrk_nm varchar2(100);
  o_use_yn  varchar2(1);
  t_err_txt varchar2(100); -- error text buffer

begin

  o_rmrk_nm := NULL;
  o_use_yn  := NULL;

  begin
    select nvl(trim(rmrk_cd_nm_eng), ' '),
           --               nvl(use_yn, ' ')
           --        select 'Test-'||nvl(rmrk_cd, ' '),
           nvl(use_yn, ' ')
      into o_rmrk_nm, o_use_yn
      from vn.bmi02c00
     where rmrk_cd = i_rmrk_cd;
  exception
    when NO_DATA_FOUND then
      return 'XXXXX';
    when OTHERS then
      t_err_txt := 'Error-[' || to_char(sqlcode) || ']';
      raise_application_error(-20100, t_err_txt);
  end;

  if o_use_yn = 'N' then
    return 'XXXXX';
  else
    return o_rmrk_nm;
  end if;

end ;
/

