create procedure pxc_sms_move_hist as

begin

  insert into vn.xcs01h00
  (sms_seq_no, send_dt, sent_dt, recv_phone_no, call_back_no, send_phone_no, send_st, re_try_cnt, work_tp_a, work_tp_b, sms_msg, work_mn, work_dtm, work_trm, dtm_backup
  ,acnt_no,sub_no)
  select
  sms_seq_no, send_dt, sent_dt, recv_phone_no, call_back_no, send_phone_no, send_st, re_try_cnt, work_tp_a, work_tp_b, sms_msg, work_mn, work_dtm, work_trm, 
  decode(send_dt,NULL, to_char(work_dtm, 'YYYYMMDD'), substr(send_dt, 0, 8))
  ,acnt_no,sub_no
  from vn.xcs01m00
  ;
  
  delete vn.xcs01m00;

  exception when  others then
    vn.pxc_log_write('pxc_sms_move_hist', sqlerrm);
    raise_application_error(-20100,'[pxc_sms_move_hist] ' || sqlerrm);

end pxc_sms_move_hist;
/

