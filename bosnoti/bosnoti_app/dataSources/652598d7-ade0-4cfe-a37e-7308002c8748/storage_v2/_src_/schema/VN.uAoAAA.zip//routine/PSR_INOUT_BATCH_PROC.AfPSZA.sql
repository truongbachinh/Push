create procedure    psr_inout_batch_proc
( i_dt        in    varchar2,
  i_work_mn   in    varchar2,
  i_work_trm  in    varchar2,
  o_cnt       out   number
 ) is

 o_proc_cnt   number;

begin

 vn.pxc_log_write('psr_inout_batch_proc', i_dt);

 o_cnt := 0;



 for  c1  in ( /*Nhap kho CP*/

      select   rgt_std_dt  std_dt,
			   stk_cd,
		       rgt_tp,
			   decode(rgt_tp,'3' , 0 , nvl(rgt_iss_pri,0))   rgt_iss_pri,
			   list_stk_cd,
			   seq_no ,
               nvl(Trim(apy_dt),vn.vwdate)  apy_dt
      from     vn.srr01m00
      where    std_inq_dt   =  i_dt
	  and      rgt_proc_stat in ('4','6','7','8')

	  union all

	  select rgt_std_Dt std_dt ,
			 stk_cd ,
			 '8' rgt_tp ,
			  0  rgt_iss_pri ,
			  cnvt_stk_cd list_stk_cd ,
			  0  seq_no ,
			  nvl(Trim(apy_dt),vn.vwdate) apy_dt
         from vn.srr01m10
		 where std_inq_dt = i_dt
		 and   rgt_proc_stat in('4','7')
		 and   nvl(INOUT_END_YN,'N') <> 'Y'

    ) loop

	  o_cnt := o_cnt + 1;

	  vn.pxc_log_write('psr_inout_batch_proc', 'inq_dt '||c1.stk_cd);

      vn.psr_rgt_inoutbil_p(
								c1.apy_dt,
      							c1.std_dt,
						    	c1.stk_cd,
						    	c1.rgt_tp,
						    	i_dt,
                                '00000000',
							    c1.rgt_iss_pri,
                                c1.list_stk_cd,
	                            c1.seq_no,
							    i_work_mn,
							    i_work_trm,
							    o_proc_cnt);


  end loop;

  for  c6  in ( /*Xuat kho CP*/

      select   rgt_std_dt  std_dt,
			   stk_cd,
		       rgt_tp,
			   decode(rgt_tp,'3' , 0 , nvl(rgt_iss_pri,0))   rgt_iss_pri,
			   list_stk_cd,
			   seq_no ,
               nvl(Trim(apy_dt),vn.vwdate)  apy_dt
      from     vn.srr01m00
      where    std_out_dt   =  i_dt
	  and	   rgt_tp		=  '7'
	  and      rgt_proc_stat in ('4', '5', '7')

    ) loop

	  o_cnt := o_cnt + 1;

	  vn.pxc_log_write('psr_inout_batch_proc', 'out_dt '||c6.stk_cd||'-'||c6.list_stk_cd);

      vn.psr_rgt_inoutbil_p(	c6.apy_dt,
      							c6.std_dt,
						    	c6.stk_cd,
						    	c6.rgt_tp,
						    	'00000000',
                                i_dt,
							    c6.rgt_iss_pri,
                                c6.list_stk_cd,
	                            c6.seq_no,
							    i_work_mn,
							    i_work_trm,
							    o_proc_cnt);


  end loop;

  for  c2  in ( /*Tra co tuc = tien*/

      select   rgt_std_dt  std_dt,
               stk_cd,
               rgt_tp,
               seq_no
      from     vn.srr01m00
     where     divi_pay_dt    =  i_dt
       and      rgt_proc_stat in ('4','5','6','7')

    ) loop

      vn.pxc_log_write('psr_inout_batch_proc', 'dividend '||c2.stk_cd);

      vn.psr_rgt_inoutmon_p(
      				        c2.std_dt,
                            c2.stk_cd,
                            c2.rgt_tp,
                            '2',
                            i_dt,
                            c2.seq_no,
                            i_work_mn,
                            i_work_trm,
                            o_proc_cnt);

  end loop;


 for  c3  in ( /*Tra lo le*/

      select   rgt_std_dt  std_dt,
               stk_cd,
               rgt_tp,
               seq_no
      from     vn.srr01m00
      where    flotq_pay_dt    =  i_dt
      and      rgt_proc_stat  in ('4','5','6','7','8')

	  union all

	  select   rgt_std_dt  std_dt,
               stk_cd ,
			   '8' rgt_tp ,
			    0 seq_no
         from  vn.srr01m10
        where  flotq_pay_dt = i_dt
		  and  rgt_proc_stat in ('4','5')
		  and  nvl(FLOTQ_END_YN,'N') <> 'Y'

    ) loop

      vn.pxc_log_write('psr_inout_batch_proc', 'odd-lot '||c3.stk_cd);

      vn.psr_rgt_inoutmon_p(
					c3.std_dt,
					c3.stk_cd,
					c3.rgt_tp,
					'1',
					i_dt,
					c3.seq_no,
					i_work_mn,
					i_work_trm,
					o_proc_cnt);

  end loop;

  for  c4  in ( --Trai phieu goc

      select   rgt_std_dt  std_dt,
               stk_cd,
               rgt_tp,
               seq_no
       from    vn.srr01m00
      where    list_dt    =  i_dt
        and    rgt_proc_stat  in ('4','5','6','7')

    ) loop

      vn.pxc_log_write('psr_inout_batch_proc', 'list_dt :'||c4.stk_cd);

      vn.psr_rgt_inoutmon_p(
					c4.std_dt,
					c4.stk_cd,
					c4.rgt_tp,
					'2',
					i_dt,
					c4.seq_no,
					i_work_mn,
					i_work_trm,
					o_proc_cnt);

  end loop;


  for  c5  in (  -- Trai phieu lai

      select   rgt_std_dt  std_dt,
               stk_cd,
               rgt_tp,
               seq_no
       from    vn.srr01m00
      where    inter_dt    =  i_dt
        and    rgt_proc_stat  in ('4','5','6','7')

    ) loop

      vn.pxc_log_write('psr_inout_batch_proc', 'list_dt :'||c5.stk_cd);

      vn.psr_rgt_inoutmon_p(
					c5.std_dt,
					c5.stk_cd,
					c5.rgt_tp,
					'3',
					i_dt,
					c5.seq_no,
					i_work_mn,
					i_work_trm,
					o_proc_cnt);

  end loop;

end  psr_inout_batch_proc;
/

