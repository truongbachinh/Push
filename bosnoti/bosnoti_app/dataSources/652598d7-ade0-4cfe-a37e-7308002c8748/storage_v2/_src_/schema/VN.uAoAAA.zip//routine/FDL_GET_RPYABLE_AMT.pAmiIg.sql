create function fdl_get_rpyable_amt
(
    i_lnd_tp       in   varchar2,
    i_acnt_no      in   varchar2,
    i_sub_no	   in   varchar2,
    i_bank_cd      in   varchar2,
    i_dt           in   varchar2
)   return  number as

    t_vwdate            varchar2(08) ;
    t_lnd_dt            varchar2(08) ;
    t_mrtg_dt           varchar2(08) ;
    t_lnd_bank_cd       varchar2(04) ;
    t_stk_cd            varchar2(20) ;
    t_cnt               number  := 0 ;

    t_rpyable_amt       number  := 0 ;
    t_rpy_cmsn          number  := 0 ;

    t_lnd_pri           number  := 0 ;

    t_lnd_rm_amt        number  := 0 ;
    t_lnd_rpy_amt       number  := 0 ;
    t_lnd_rpy_int       number  := 0 ;
    t_rpy_int_dly       number  := 0 ;

    t_err_txt           varchar2(80) ; -- error text buffer
begin

/*============================================================================*/
/* Valiabl Initialize                                                         */
/*============================================================================*/
    t_rpy_cmsn     :=  0;
    t_rpyable_amt  :=  0;

/*============================================================================*/
/* Get today's work date                                                      */
/*============================================================================*/
    t_vwdate := vn.vwdate;

/*============================================================================*/
/* generl commission return                                                   */
/*============================================================================*/

    if  i_lnd_tp  =  '10'  then
        for C1 in (
            select  lnd_tp
                 ,  lnd_bank_cd
                 ,  acnt_no
                 ,  sub_no
                 ,  lnd_dt
                 ,  expr_dt
                 ,  sum(nvl(lnd_amt,0))  lnd_amt
                 ,  sum(nvl(lnd_amt,0))
                 -  sum(nvl(lnd_rpy_amt,0))  lnd_rpy_amt
                 ,  lnd_cmsn_rt
              from  vn.dlm01m00
             where  lnd_tp         =  i_lnd_tp
               and  acnt_no        =  i_acnt_no
               and  sub_no		   =  i_sub_no
               and  setl_bank_cd   =  i_bank_cd
               and  expr_dt        =  i_dt
               and  nvl(lnd_amt,0)
                 -  nvl(lnd_rpy_amt,0) > 0
             group  by  lnd_tp, lnd_bank_cd, acnt_no, sub_no
                    ,   lnd_dt, expr_dt    , lnd_cmsn_rt
        ) loop

        	t_rpy_cmsn     :=  0;

            vn.pdl_get_lnd_cmsn ( C1.lnd_tp
                                , C1.lnd_bank_cd, C1.acnt_no, C1.sub_no
                                , C1.lnd_dt     , C1.expr_dt
                                , C1.lnd_rpy_amt              -- lnd_amt
                                , C1.lnd_rpy_amt              -- rpy_amt
                                , C1.lnd_cmsn_rt
                                , t_rpy_cmsn );

            t_rpyable_amt  := t_rpyable_amt + C1.lnd_rpy_amt + t_rpy_cmsn;

        end loop;
    elsif  i_lnd_tp  in  ('20', '30')  then
        for C2 in (
            select  a.setl_dt
                 ,  a.mth_dt
                 ,  a.acnt_mng_bnh
                 ,  a.agnc_brch
                 ,  a.acnt_no
                 ,  a.sub_no
                 ,  a.bank_cd
                 ,  a.sb_tp
                 ,  a.mkt_trd_tp
                 ,  a.cdt_tp
                 ,  a.lnd_dt
                 ,  a.mrtg_dt
                 ,  a.lnd_bank_cd
                 ,  a.stk_cd
                 ,  sum(nvl(a.sb_qty,0))      sb_qty
                 ,  sum(nvl(a.sb_amt,0))      sb_amt
                 ,  sum(nvl(a.sb_cmsn,0))     sb_cmsn
                 ,  sum(nvl(a.sb_tax,0))      sb_tax
                 ,  sum(nvl(a.adj_amt,0))     adj_amt
                 ,  0     lnd_int
                 ,  0     lnd_cmsn
              from  vn.dsc01m00 a
             where  a.setl_dt        =  i_dt
               and  a.acnt_no        =  i_acnt_no
               and  a.sub_no		 =  i_sub_no
               and  a.bank_cd     like  i_bank_cd
               and  a.cdt_tp      like  i_lnd_tp
               and  a.sb_tp          =  '1'
               and  a.mkt_trd_tp    in  ('01','03','05')
               and  a.dpo_setl_yn   in  ('N')
             group  by  a.setl_dt, a.mth_dt,  a.acnt_no, a.sub_no, a.acnt_mng_bnh, a.agnc_brch
                     ,  a.bank_cd, a.sb_tp,   a.mkt_trd_tp,   a.cdt_tp, a.lnd_dt, a.mrtg_dt, a.lnd_bank_cd, a.stk_cd
        ) loop
            t_cnt         := 0;
            t_lnd_rm_amt  := 0;
            t_lnd_rpy_amt := 0;
            t_lnd_pri     := 0;

            for C22 in (
                select  lnd_tp
                     ,  mth_dt
                     ,  lnd_bank_cd
                     ,  setl_bank_cd
                     ,  stk_cd
                     ,  cpt_rpy_tp
                     ,  int_rpy_tp
                     ,  last_rpy_dt
                     ,  expr_dt
                     ,  nvl(lnd_amt,0)                       		lnd_amt
                     ,  nvl(lnd_rpy_amt,0)                   		lnd_rpy_amt
                     ,  nvl(lnd_amt,0) - nvl(lnd_rpy_amt,0)  		lnd_rm_amt
                     ,  nvl(lnd_int_rt,0)                    		lnd_int_rt
                     ,  nvl(lnd_cmsn_rt,0)                   		lnd_cmsn_rt
                     ,  nvl(mrtg_lnd_qty,0)                  		mrtg_lnd_qty
                     ,  nvl(mrtg_rpy_qty,0)                  		mrtg_rpy_qty
                     ,  nvl(mrtg_lnd_qty,0)- nvl(mrtg_rpy_qty,0)	mrtg_rm_qty
                     ,  nvl(pppd_sell_mth_qty,0)    		        pppd_sell_mth_qty
                  from  vn.dlm01m00
                 where  lnd_tp          =  C2.cdt_tp
                   and  acnt_no         =  C2.acnt_no
                   and  sub_no		 	=  C2.sub_no
                   and  lnd_dt          =  C2.lnd_dt
                   and  mth_dt          =  C2.mrtg_dt
                   and  lnd_bank_cd     =  C2.lnd_bank_cd
                   and  stk_cd          =  C2.stk_cd
                   and  nvl(lnd_amt,0)  -  nvl(lnd_rpy_amt,0) > 0
                   and  lnd_acpt_tp     =  '01'
            ) loop

                t_cnt         := t_cnt + 1;
                if  t_cnt  =  1  then
                    t_lnd_rm_amt  := C22.lnd_rm_amt;
                end if;

                t_lnd_rm_amt  := t_lnd_rm_amt - t_lnd_rpy_amt;

                t_lnd_pri     := 0;
                t_lnd_rpy_amt := 0;

                /*=================================================================*/
                /* loan price   = lnd_amount / mrtg_lnd_qty                        */
                /* repay amount = lnd_amount * repay_qty / lnd_qty                 */
                /* repay qty    = repay_amount / lnd_amount * mrtg_lnd_qty         */
                /*=================================================================*/
                t_lnd_pri     := Round(C22.lnd_rm_amt / C22.mrtg_rm_qty,-1);
                t_lnd_rpy_amt := trunc(C2.sb_qty * t_lnd_pri,0);

                if  t_lnd_rm_amt <= t_lnd_rpy_amt then
                    t_lnd_rpy_amt :=  t_lnd_rm_amt;
                else
					t_lnd_rpy_amt :=  t_lnd_rpy_amt;
                end if;

                t_lnd_rpy_int  := 0;
                t_rpy_int_dly  := 0;

                t_lnd_rpy_int  := vn.fdl_get_lnd_int( C22.lnd_tp
                                                    , C2.acnt_no
                                                    , C2.sub_no
                                                    , C22.lnd_bank_cd
                                                    , '1'
                                                    , C2.lnd_dt
                                                    , i_dt
                                                    , C22.expr_dt
                                                    , C22.last_rpy_dt
                                                    , C22.cpt_rpy_tp
                                                    , C22.int_rpy_tp
                                                    , C22.lnd_amt
                                                    , t_lnd_rpy_amt
                                                    , t_lnd_rm_amt
                                                    , C22.lnd_int_rt
                                                    );
                t_rpy_int_dly  := vn.fdl_get_lnd_int( C22.lnd_tp
                                                    , C2.acnt_no
                                                    , C2.sub_no
                                                    , C22.lnd_bank_cd
                                                    , '2'
                                                    , C2.lnd_dt
                                                    , i_dt
                                                    , C22.expr_dt
                                                    , C22.last_rpy_dt
                                                    , C22.cpt_rpy_tp
                                                    , C22.int_rpy_tp
                                                    , C22.lnd_amt
                                                    , t_lnd_rpy_amt
                                                    , t_lnd_rm_amt
                                                    , C22.lnd_int_rt
                                                    );

                t_rpyable_amt  := t_rpyable_amt + t_lnd_rpy_amt + t_lnd_rpy_int + t_rpy_int_dly;

            end loop;
        end loop;
    end if;

    return t_rpyable_amt;

end fdl_get_rpyable_amt;
/

