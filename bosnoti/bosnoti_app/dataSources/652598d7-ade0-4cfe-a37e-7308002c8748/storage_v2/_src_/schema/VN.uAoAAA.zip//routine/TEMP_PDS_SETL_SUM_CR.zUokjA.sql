create procedure temp_pds_setl_sum_cr
    ( i_dt          in     varchar2,        --
      i_work_mn     in     varchar2,        -- user id
      i_work_trm    in     varchar2,
      o_cnt         in out number
    ) AS

/*!
   \file     temp_pds_setl_sum_cr.sql
   \brief    previous settlement creation

   \section intro Program Information
        - Program Name              : create settle data
        - Service Name              : N/A
        - Related Client Program- Client Program ID : N/A
        - Related Tables            : dsc01m00, dsc02m00
        - Dev. Date                 : 2007/11/08
        - Developer                 : Han.
        - Business Logic Desc.      : create settle data
        - Latest Modification Date  : 2007/11/08

   \section history Program Modification History
    - 1.0       2007/11/08     Han.    New.

   \section hardcoding Hard-Coding List
    - HC-1      2007/11/08     Han.    [��]

   \section info Additional Reference Comments
    - ������ ���var a number;
exec vn.temp_pds_setl_sum_cr('20100507','DAILY','SYSTEM',:a);
*/

    t_setl_dt           varchar2(8) := null;
    t_dt                varchar2(8) := null;

    t_mng_brch_cd       varchar2(3) := null;
    t_agnc_brch         varchar2(2) := null;

    t_bank_cd           varchar2(4) := null;

    t_trd_seq_no        number      := 0;
    t_rmrk_job_tp       varchar2(2) := null;
    t_rmrk_trd_tp       varchar2(3) := null;

    ts_work_stat_min    VARCHAR2(1);
    ts_work_stat_max    VARCHAR2(1);

    t_err_msg           varchar2(500);

begin

    o_cnt := 0;

    /*========================================================================*/
    /* Input Date CHECK                                                       */
    /*========================================================================*/
    if  vn.fxc_holi_ck(to_date(i_dt,'yyyymmdd')) !=  '0' then
    	if  i_work_mn <> 'DAILY' then
	        t_err_msg := vn.fxc_get_err_msg('V','2422');
	        t_err_msg := t_err_msg||' Date = '||i_dt;
	        raise_application_error(-20100,t_err_msg);
		else
			return;
		end if;
	end if;
/*
    if  vn.vwdate  !=  i_dt then
        t_err_msg := vn.fxc_get_err_msg('V','2422');
        raise_application_error(-20100,t_err_msg||' Date = '||i_dt);
    end if;
*/

    /*========================================================================*/
    /* Prededing job Check                                                    */
    /*========================================================================*/
/*
    if fxb_daily_stat_chk ('B','0','2200','2500','*') <> 'Y' then
        t_err_msg := vn.fxc_get_err_msg('V','2458');
        t_err_msg := t_err_msg||'[2200],[2500]'||i_dt;
        raise_application_error(-20100,t_err_msg);
    end if;
*/
    /*========================================================================*/
    /* Date Check                                                             */
    /*========================================================================*/
    t_setl_dt := i_dt;

    t_dt      := vn.fxc_vorderdt_g(to_date(t_setl_dt,'yyyymmdd'), -3);

    /*========================================================================*/
    /* Delete pre-data for reprocessing                                       */
    /*========================================================================*/
	delete from vn.dsc02m00
	 where setl_dt = t_setl_dt;

/*============================================================================*/
/* ( )                                                                        */
/*============================================================================*/

    for C1 in (
        select  a.acnt_mng_bnh  acnt_mng_bnh
             ,  a.agnc_brch     agnc_brch
             ,  a.mth_dt        mth_dt
             ,  a.stk_tp        stk_tp
             ,  a.mkt_trd_tp    mkt_trd_tp
             ,  b.acnt_tp       acnt_tp
             ,  a.sb_tp         sb_tp
             ,  a.cdt_tp        cdt_tp
             ,  a.mdm_tp        mdm_tp
             ,  sum(a.sb_qty)   sb_qty
             ,  sum(a.sb_amt)   sb_amt
             ,  sum(a.sb_cmsn)  sb_cmsn
             ,  sum(a.sb_tax)   sb_tax
          from  vn.dsc01m00 a, vn.aaa01m00 b
         where  a.setl_dt      =  t_setl_dt
           and  a.acnt_no      =  b.acnt_no
           and  a.dpo_setl_yn  =  'Y'
           and  a.stk_setl_yn  =  'Y'
           and  a.cmsn_setl_yn =  'Y'
           and  a.tax_setl_yn  =  'Y'
         group  by  a.acnt_mng_bnh, a.agnc_brch, a.mth_dt, a.stk_tp,
                    a.mkt_trd_tp,   b.acnt_tp,   a.sb_tp,  a.cdt_tp, a.mdm_tp
         order  by  a.acnt_mng_bnh, a.agnc_brch, a.mth_dt, a.stk_tp,
                    a.mkt_trd_tp,   b.acnt_tp,   a.sb_tp,  a.cdt_tp, a.mdm_tp
    ) loop
        o_cnt := o_cnt + 1;


        insert into vn.dsc02m00 (
            SETL_DT,        ACNT_MNG_BNH,   AGNC_BRCH,
            STK_TP,         MKT_TRD_TP,     ACNT_TP,
            SB_TP,          CDT_TP,
            MDM_TP,         MTH_DT,
            SB_QTY,         SB_AMT,
            SB_CMSN,        SB_TAX,
            WORK_MN,        WORK_DTM,       WORK_TRM
        )
        values (
            t_setl_dt,      C1.acnt_mng_bnh, C1.agnc_brch,
            C1.stk_tp,      C1.mkt_trd_tp,   C1.acnt_tp,
            C1.sb_tp,       C1.cdt_tp,
            C1.mdm_tp,      C1.mth_dt,
            C1.sb_qty,      C1.sb_amt,
            C1.sb_cmsn,     C1.sb_tax,
            i_work_mn,      sysdate,         i_work_trm
        );


        t_bank_cd     := '0000';

        /*====================================================================*/
        /* ȸ����                                                           */
        /*====================================================================*/

        /*====================================================================*/
        /* seq_no  create                                                     */
        /*====================================================================*/
        /* t_seq_no := fcz_auto_num('ss',t_dt);  */
/*
        begin
            select  nvl(max(trd_seq_no),0)+1
              into  t_trd_seq_no
              from  vn.gga07m00
             where  proc_dt      =  t_setl_dt
               and  acnt_no      =  C1.acnt_mng_bnh||C1.agnc_brch
            ;
        exception
        when others then
            t_err_msg := vn.fxc_get_err_msg('V','9408');
            raise_application_error(-20010,t_err_msg||' proc_dt='||t_setl_dt);
        end;

        if  C1.acnt_tp  =  'P' then
            if  C1.mkt_trd_tp  in  ('02','04') then
                t_rmrk_job_tp := '25';
            else
                if  C1.stk_tp      =  '10' then
                    t_rmrk_job_tp :=  '21';
                elsif C1.stk_tp    =  '20' then
                    t_rmrk_job_tp :=  '22';
                elsif C1.stk_tp    =  '30' then
                    t_rmrk_job_tp :=  '23';
                else
                    t_err_msg := vn.fxc_get_err_msg('V','2007');
                    raise_application_error(-20100,t_err_msg||' proc_dt='||t_setl_dt);
                end if;
            end if;
        else
            if  C1.mkt_trd_tp  in  ('02','04') then
                t_rmrk_job_tp := '11';
            else
                t_rmrk_job_tp := '10';
            end if;
        end if;

        if  C1.sb_tp  =  '1' then
            t_rmrk_trd_tp := '611';
        else
            t_rmrk_trd_tp := '612';
        end if;

        vn.pds_gga07m00_ins (  t_setl_dt           -- PROC_DT
                             , 'I'                 -- AUTO_SLIP_PROC_TP
                             , C1.acnt_mng_bnh     -- PROC_BRCH_CD
                             , C1.agnc_brch        -- PROC_AGNC_BRCH
                             , C1.acnt_mng_bnh     -- EXCH_BRCH_CD
                             , C1.agnc_brch        -- EXCH_AGNC_BRCH
                             , C1.acnt_mng_bnh||C1.agnc_brch
                                                   -- ACNT_NO
                             , t_setl_dt           -- TRD_DT
                             , t_trd_seq_no        -- TRD_SEQ_NO
                             , 0                   -- ORIG_TRD_SEQ_NO
                             , t_rmrk_job_tp       -- RMRK_JOB_TP
                             , t_rmrk_trd_tp       -- RMRK_TRD_TP
                             , '0000'              -- LND_BANK_CD
                             , C1.sb_amt           -- DR_AMT_01
                             , 0                   -- DR_AMT_02
                             , 0                   -- DR_AMT_03
                             , 0                   -- DR_AMT_04
                             , 0                   -- DR_AMT_05
                             , C1.sb_amt           -- CR_AMT_01
                             , 0                   -- CR_AMT_02
                             , 0                   -- CR_AMT_03
                             , 0                   -- CR_AMT_04
                             , 0                   -- CR_AMT_05
                             , t_bank_cd           -- BANK_CD
                             , i_work_mn           -- WORK_MN
                             , i_work_trm          -- WORK_TRM
                         );
*/
    end loop;

end temp_pds_setl_sum_cr;
/

