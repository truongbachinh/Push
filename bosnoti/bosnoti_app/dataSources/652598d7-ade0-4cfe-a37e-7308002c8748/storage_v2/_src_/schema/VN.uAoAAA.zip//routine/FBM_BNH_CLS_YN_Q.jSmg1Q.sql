create function fbm_bnh_cls_yn_q
(
	i_trd_dt	in	varchar2
,	i_bnh_no	in	varchar2
,	i_cls_tp	in	varchar2

)
    return          varchar2
as
    o_bnh_cls_yn		varchar2(100) ;
    t_err_txt       varchar2(100)  ; -- error text buffer

begin

/*============================================================================*/
/* ���� ���                                                                */
/*============================================================================*/
    o_bnh_cls_yn  :=  NULL;
    t_err_txt :=  NULL;

/*============================================================================*/
/* ����ȣ ��ȸ                                                                */
/*============================================================================*/
    begin

		select	decode(i_cls_tp,'1',nvl(job_cls,'N'), '2', nvl(coe_cls,'N'),'!')
		into	o_bnh_cls_yn
		from	vn.gcb01m00
		where	cls_dt	= i_trd_dt
		and		cls_bnh	= i_bnh_no
		;
    exception
        when  NO_DATA_FOUND  then
			return  'Y';
        when  OTHERS         then
            t_err_txt  :=  '����-['||to_char(sqlcode)||']';
            raise_application_error (-20100, t_err_txt);
    end;

    return  o_bnh_cls_yn;


end fbm_bnh_cls_yn_q;
/

