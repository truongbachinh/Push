create PROCEDURE pss_check_outbil_yn(i_sec_cd      in varchar2,
                                                is_acnt_no    in varchar2,
                                                is_sub_no     in varchar2,
                                                is_stk_cd     in varchar2,
                                                is_qty        in number,
                                                is_sb_lmt_qty in number,
                                                os_result     out varchar2
                                                /*os_err_cd     out varchar2*/) AS
  td_qty       number := 0;
  td_sb_qty    number := 0;
  td_delay_qty number;
begin

  td_qty := vn.fss_get_outbil_able_qty(is_acnt_no, is_sub_no, is_stk_cd);

  td_sb_qty := vn.fss_get_outbil_able_sb_lmt_qty(is_acnt_no,
                                                 is_sub_no,
                                                 is_stk_cd);

  vn.pxc_log_write('pss_check_outbil_yn', td_qty);
  vn.pxc_log_write('pss_check_outbil_yn', td_sb_qty);

  /*select greatest(a.delay_qty - a.delay_reg_qty, 0)
   into td_delay_qty
   from vn.ssb01m00 a
  where a.acnt_no = is_acnt_no
    and a.sub_no = is_sub_no
    and a.stk_cd = is_stk_cd;*/

  if (td_qty < is_qty) then
    os_result := 'N';
    --os_err_cd := '0021';
    RETURN;
  end if;

  if (td_sb_qty < is_sb_lmt_qty) then
    os_result := 'N';
    --os_err_cd := '0022';
    RETURN;
  end if;

  /*if (td_delay_qty < ts_delay_qty) then
    os_result := 'N';
    os_err_cd := '0025';
    RETURN;
  end if;*/

  os_result := 'Y';
  RETURN;

END pss_check_outbil_yn;
/

