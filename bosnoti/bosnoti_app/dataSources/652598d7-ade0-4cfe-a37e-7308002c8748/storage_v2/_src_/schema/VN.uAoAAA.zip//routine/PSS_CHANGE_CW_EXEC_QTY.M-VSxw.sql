create PROCEDURE    pss_change_cw_exec_qty
(
  i_exec_dt       IN      VARCHAR2,
  i_setl_dt       IN      VARCHAR2,
  i_acnt_no       IN      VARCHAR2,
  i_sub_no        IN      VARCHAR2,
  i_cw_cd         IN      VARCHAR2,
  i_rmrk_cd     IN      VARCHAR2,    -- "W03": Thuc hien chung quyen; "W04": Xuat kho CW; "W05": Nhap kho CW
  i_work_mn       IN      VARCHAR2,        -- user id
  i_work_trm      IN      VARCHAR2,
  o_proc_cnt      IN OUT  NUMBER
) AS

/* ************************************************************************************************
  Author:         tienlh
  Created Date:   01-Feb-2018
  Description:    This procedure is used to change quantity, book_amt in ssb01m00 and insert aaa10m00

  Sample call:
    var o_cnt      number;
    exec pss_change_cw_exec_qty('072','20190805','20190812','061C600088','01','VIC','W03','000','01','system','1.1.1.1',:o_cnt);
    print o_cnt


**************************************************************************************************/

    -- Declare variable
    t_setl_dt                   VARCHAR2(8)     := NULL;
  t_exec_dt                   VARCHAR2(8)     := NULL;
  t_trd_seq_no            NUMBER        := 0;
    t_tot_seq_no            NUMBER        := 0;
    t_pre_own_qty               NUMBER          := 0;
    t_now_own_qty               NUMBER          := 0;
    t_book_amt                  NUMBER          := 0;
    t_pre_book_amt              NUMBER          := 0;
    t_now_book_amt              NUMBER          := 0;
  t_waiting_exec_qty      NUMBER          := 0;
  t_acnt_tp               VARCHAR2(1)   := NULL;
  t_trd_tp          VARCHAR2(10)  := NULL;
  t_rmrk_cd         VARCHAR2(10)  := NULL;
  t_acnt_mng_bnh        varchar2(3)   := null;
  t_agnc_brch             varchar2(2)   := null;
  t_cw_matur_dt       VARCHAR2(8)   := NULL;
    t_setl_tp               varchar2(1)   := null;
    t_err_msg                   VARCHAR2(500)   := NULL;
  t_err_txt                   varchar2(200);
  ts_acnt_mng_bnh       varchar2(20);
  ts_agnc_brch        varchar2(20);

  t_proc_brch_cd              varchar2(20) := Null;
    t_proc_agnc_brch            varchar2(20) := Null;
  t_qty           NUMBER          := 0;
  t_ocnt1           NUMBER          := 0;
BEGIN

    o_proc_cnt := 0;

    t_exec_dt := i_exec_dt;

    vn.pxc_log_write('pss_change_cw_exec_qty','START pss_change_cw_exec_qty');

    /* **************************************************************************/
    /*  Checking data before implementing settlement  */
    /* **************************************************************************/
    -- Check if input date is not current date
    IF vn.vwdate != i_exec_dt THEN
        t_err_msg := vn.fxc_get_err_msg('V', '2422');
        t_err_msg := t_err_msg || ' Date = ' || i_exec_dt;
        raise_application_error(-20100, t_err_msg);
    END IF;

    -- Check if input date is holiday
    IF vn.fxc_holi_ck(TO_DATE(i_exec_dt, 'yyyymmdd')) != '0' THEN
        IF i_work_mn <> 'DAILY' THEN
            t_err_msg := vn.fxc_get_err_msg('V', '2422');
            t_err_msg := t_err_msg || ' Date = ' || i_exec_dt;
            raise_application_error(-20100, t_err_msg);
        ELSE
            RETURN;
        END IF;
    END IF;

    /* **************************************************************************/
    /* End checking   */
    /* **************************************************************************/

    /* **************************************************************************/
    /* Stock Settlement   */
    /* **************************************************************************/
    FOR c1 in (
        select
        sc.acnt_no                                              acnt_no,
        sc.sub_no                                               sub_no,
        sc.stk_cd                                               cw_cd,
        sc.reg_qty                                              cw_qty,
        (sc.reg_qty / sb.own_qty) * sb.book_amt             book_amt,
        si.cw_tp                                                cw_tp,
        sc.exec_dt                            exec_dt,
        fxc_vorderdt_g(to_date(sc.exec_dt,'yyyymmdd'), 5)            setl_dt,
        si.cw_exec_tp                                           cw_exec_tp
    from scw05m00 sc, ssb01m00 sb, ssi01m00 si
    where sc.acnt_no = sb.acnt_no
    and sc.sub_no = sb.sub_no
    and sc.stk_cd = sb.stk_cd
    and sc.stk_cd = si.stk_cd
    and si.stk_tp = '70'
    and sc.reg_qty > 0
    and sc.acnt_no    LIKE i_acnt_no
    and sc.sub_no     LIKE i_sub_no
    and sc.stk_cd     LIKE i_cw_cd
    and sc.exec_dt    LIKE t_exec_dt
    and sc.cncl_yn = 'N'
    )
    LOOP
        o_proc_cnt  := o_proc_cnt + 1;

        vn.pxc_log_write('pss_change_cw_exec_qty','pss_change_cw_exec_qty: '
                            || 'acnt_no = '    || c1.acnt_no   || '-' || c1.sub_no
                            || ' | cw_cd = '   || c1.cw_cd
                            || ' | exec_dt = ' || c1.exec_dt);

    /*====================================================================*/
        /* Account management branch                                          */
        /*====================================================================*/

        begin
            select  nvl(acnt_mng_bnh,'000')
         ,  nvl(agnc_brch,'00')
                 ,  setl_tp
              into  t_acnt_mng_bnh
         ,  t_agnc_brch
                 ,  t_setl_tp
              from  vn.aaa01m00
             where  acnt_no      =  c1.acnt_no
             and    sub_no       =  c1.sub_no
            ;
        exception
        when no_data_found then
            t_err_msg := vn.fxc_get_err_msg('V','2006');
            raise_application_error(-20100,t_err_msg||' ACNT_NO='||c1.acnt_no||'-'||c1.sub_no);
        when others then
            t_err_msg := vn.fxc_get_err_msg('V','9002');
            raise_application_error(-20011,t_err_msg||' acnt_no='||c1.acnt_no||'-'||c1.sub_no);
        end;

    /*====================================================================*/
        /* Get the Trade sequence number and Total trade sequence number      */
        /*====================================================================*/
        begin
            vn.pxc_psb_seq_cret_p(c1.acnt_no, c1.sub_no, vn.vwdate, t_trd_seq_no, t_tot_seq_no);
        exception
        when others then
            t_err_msg := vn.fxc_get_err_msg('V','9414');
            t_err_msg := t_err_msg||' Acnt_no= '||c1.acnt_no||'-'||c1.sub_no;
            raise_application_error(-20100,t_err_msg);
        end;

    /*====================================================================*/
        /* stock's balance check                                              */
        /*====================================================================*/
        t_qty               := 0;                    --
        t_pre_own_qty       := 0;                    -- pre balance
        t_now_own_qty       := 0;                    -- now balance
        t_book_amt          := 0;                    --
        t_pre_book_amt      := 0;                    --
    t_waiting_exec_qty  := 0;

    if  t_setl_tp = '1' then
      for C2 in (
        select *
        from vn.ssb01m00
        where acnt_no   = c1.acnt_no
        and    sub_no   = c1.sub_no
        and    stk_cd   = c1.cw_cd
      ) loop

      t_qty               := C2.own_qty;
      t_pre_own_qty       := C2.own_qty;
      t_book_amt          := C2.book_amt;
      t_pre_book_amt      := C2.book_amt;
      t_waiting_exec_qty  := C2.WAITING_EXEC_QTY;

      end loop;

      /*Get maturity date in ssi01m00*/
      select cw_matur_dt
      into t_cw_matur_dt
      from vn.ssi01m00 si1
      where si1.stk_cd like c1.cw_cd;

      if (i_rmrk_cd = 'W03' and t_cw_matur_dt = vn.vwdate) then
        t_now_own_qty := 0;
        t_book_amt    := 0;
        t_waiting_exec_qty :=0;
      else
        /*================================================================*/
        /* qty update                                                     */
        /*================================================================*/
        if i_rmrk_cd = 'W03' or i_rmrk_cd = 'W04' then
          if  c1.cw_qty <= t_pre_own_qty then
            t_now_own_qty  := t_pre_own_qty  -  c1.cw_qty;

          else
            t_now_own_qty  := 0;
            t_err_msg := vn.fxc_get_err_msg('V','2205');
            raise_application_error(-20100,t_err_msg||' ACNT_NO='||c1.acnt_no||'-'||c1.sub_no
                                ||'-'||c1.cw_qty
                                ||'-'||t_pre_own_qty);
          end if;

          t_waiting_exec_qty := t_waiting_exec_qty - c1.cw_qty;
          if t_waiting_exec_qty < 0 then
            t_waiting_exec_qty := 0;
            t_err_msg := vn.fxc_get_err_msg('V','2205');
            raise_application_error(-20100,t_err_msg||' ACNT_NO='||c1.acnt_no||'-'||c1.sub_no
                                ||'-'||c1.cw_qty
                                ||'- t_waiting_exec_qty: '||t_waiting_exec_qty);
          end if;
        else
          t_now_own_qty  := t_pre_own_qty  +  c1.cw_qty;
        end if;

        /*================================================================*/
        /* book_amt update                                                */
        /*================================================================*/
        if  i_rmrk_cd = 'W03' or i_rmrk_cd = 'W04' then
          if  c1.cw_qty < t_pre_own_qty and t_pre_own_qty > 0 then
            t_book_amt := t_book_amt - trunc(t_book_amt * c1.cw_qty / t_pre_own_qty);
          else
            t_book_amt := 0;
          end if;

        else
          if  t_pre_own_qty < 0 then
            if  c1.cw_qty < abs(t_pre_own_qty) then
              t_book_amt := 0;
            else
              t_book_amt := ROUND((c1.cw_qty - abs(t_pre_own_qty)) * c1.book_amt / c1.cw_qty);
            end if;
          else
            t_book_amt := t_book_amt + c1.book_amt;
          end if;

        end if;
      end if;
      /*================================================================*/
      /* update ssb01m00                                               */
      /*================================================================*/
      if(t_cw_matur_dt = vn.vwdate) then
        update  vn.ssb01m00
        set  own_qty   =  t_now_own_qty
          ,  book_amt  =  t_book_amt
          ,  waiting_exec_qty  =  t_waiting_exec_qty
          ,  sbst_dpo       = GREATEST(sbst_dpo - c1.book_amt, 0)
          ,  sbst_able_block  = GREATEST(sbst_able_block - c1.book_amt, 0)
        where   acnt_no    =  c1.acnt_no
        and     sub_no     =  c1.sub_no
        and   stk_cd     =  c1.cw_cd
        ;

        if  sql%notfound or sql%notfound is null then
          insert into vn.ssb01m00
          (acnt_no,      sub_no,         stk_cd,      stk_tp,
          own_qty,      book_amt,
          work_mn,      work_dtm,    work_trm)
          values
          (c1.acnt_no,   c1.sub_no,     c1.cw_cd,   '70',
          t_now_own_qty,  t_book_amt,
          i_work_mn,    sysdate,     i_work_trm);
        end if;
      else
        update  vn.ssb01m00
        set  own_qty   =  t_now_own_qty
          ,  book_amt  =  t_book_amt
          ,  waiting_exec_qty  =  t_waiting_exec_qty
          ,  bclm_qty    = 0
          ,  mrtg_lnd_qty  = 0
          ,  mrtg_buy_qty  = 0
          ,  sb_lim_qty    = 0
          ,  mov_lim_qty   = 0
          ,  outq_req_qty  = 0
          ,  lim_req_qty   = 0
          ,  delay_qty     = 0
          ,  delay_sb_qty  = 0
          ,  delay_mov_qty = 0
          ,  sbst_dpo       = GREATEST(sbst_dpo - c1.book_amt, 0)
          ,  sbst_able_block  = GREATEST(sbst_able_block - c1.book_amt, 0)
        where   acnt_no    =  c1.acnt_no
        and     sub_no     =  c1.sub_no
        and   stk_cd     =  c1.cw_cd
        ;

        if  sql%notfound or sql%notfound is null then
          insert into vn.ssb01m00
          (acnt_no,      sub_no,         stk_cd,      stk_tp,
          own_qty,      book_amt,    bclm_qty,
          mrtg_lnd_qty, mrtg_buy_qty,
          work_mn,      work_dtm,    work_trm)
          values
          (c1.acnt_no,   c1.sub_no,     c1.cw_cd,   '70',
          t_now_own_qty,  t_book_amt,  0,
          0,            0,
          i_work_mn,    sysdate,     i_work_trm);
        end if;
      end if;
    end if;
    /*====================================================================*/
        /* account type (1:Security-Account  2:Bank-Account  3:Non-custodian) */
        /*====================================================================*/
        t_acnt_tp :=  vn.faa_get_acnt_tp(c1.acnt_no, c1.sub_no) ;
        /*====================================================================*/
        /* pds_aaa10m00_ins(????????) Create                                  */
        /*====================================================================*/
        /* 2019.08.07 CTB Account => [W03,W04] */

    if  t_setl_tp = '2' then
            if  c1.cw_tp = '1' then
                t_trd_tp          := '55';
            elsif c1.cw_tp = '2' THEN
                t_trd_tp          := '54';
            end if;
        else
            if  t_acnt_tp  = '1' then
                if  c1.cw_tp = '1' then
                    t_trd_tp  := '51';

                elsif c1.cw_tp = '2' THEN
                    t_trd_tp  := '50';
                end if;
            elsif  t_acnt_tp  = '2' then
                if  c1.cw_tp = '1' then
                    t_trd_tp  := '53';
                elsif c1.cw_tp = '2' THEN
                    t_trd_tp  := '52';
                end if;
            elsif  t_acnt_tp  = '3' then
                if  c1.cw_tp = '1' then
                    t_trd_tp  := '55';
                elsif c1.cw_tp = '2' THEN
                    t_trd_tp  := '54';
                end if;
            end if;
        end if;

      BEGIN
        select  acnt_mng_bnh
             ,  agnc_brch
          into  ts_acnt_mng_bnh
             ,  ts_agnc_brch
        from  vn.aaa01m00
        where  acnt_no  =  c1.acnt_no
      and sub_no   =  c1.sub_no;
    EXCEPTION
        WHEN OTHERS THEN
            t_err_txt  :=  'pss_change_cw_exec_qty.prc select error aaa01m00:'||  to_char(sqlcode);
      t_err_msg := vn.fxc_get_err_msg('V','2001');
      raise_application_error(-20100,t_err_msg||t_err_txt);
    END;

    /*Start - Lay chi nhanh / PGD thuc hien*/
    if i_work_mn in ('DAILY','BATCH') then
      t_proc_brch_cd := ts_acnt_mng_bnh ;
      t_proc_agnc_brch := ts_agnc_brch;
    else
      BEGIN
        select  brch_cd,
            agnc_brch
        into  t_proc_brch_cd,
            t_proc_agnc_brch
        from  vn.xca01m01
        where emp_no = i_work_mn
        ;
      EXCEPTION
        WHEN  OTHERS         THEN
        t_err_txt  :=  'pss_change_cw_exec_qty.prc select error xca01m01:' ||  to_char(sqlcode);
          t_err_msg := vn.fxc_get_err_msg('V','2819');
          raise_application_error(-20100,t_err_msg||t_err_txt);
      END;
    end if;

    vn.pxc_log_write('pcw_cash_outamt_depo_fee','Chi nhanh thuc hien: '||t_proc_brch_cd||', PGD thuc hien: '||t_proc_agnc_brch);
    /*End - Lay chi nhanh / PGD thuc hien*/

    /*Insert aaa01m00*/
    begin
      insert into vn.aaa10m00 (
        ACNT_NO
        , SUB_NO
        , TRD_DT
        , TRD_SEQ_NO
        , TOT_TRD_SEQ_NO
        , TRD_TP
        , RMRK_CD
        , BANK_CD
        , MDM_TP
        , TRD_MDM_TP
        , CNCL_YN
        , ORG_TRD_NO
        , TRD_AMT
        , CMSN
        , SB_TAX
        , ADJ_AMT
        , DPO_PRERM
        , DPO_NOWRM
        , STK_CD
        , STK_NM
        , SB_PRI
        , SB_QTY
        , BIL_PRERM_QTY
        , BIL_NOWRM_QTY
        , BOOK_AMT
        , STK_TP
        , MTH_DT
        , LND_TP
        , LND_DT
        , LND_BANK_CD
        , LND_AMT
        , LND_RPY_AMT
        , LND_INT
        , LND_CMSN
        , LND_INT_DLY
        , LND_CMSN_DLY
        , AGNT_YN
        , ACNT_MNG_BNH
        , AGNC_BRCH
        , WORK_BNH
        , PROC_AGNC_BRCH
        , WORK_MN
        , WORK_DTM
        , WORK_TRM
        , SETL_DT
        , TOT_DPO_PRERM
        , TOT_DPO_NOWRM
        , TOT_BIL_PRERM
        , TOT_BIL_NOWRM
      )
      values (
        c1.acnt_no                  --ACNT_NO
        , c1.sub_no                                 --, SUB_NO
        , t_exec_dt                                 --, TRD_DT
        , t_trd_seq_no                              --, TRD_SEQ_NO
        , t_tot_seq_no                              --, TOT_TRD_SEQ_N
        , t_trd_tp                                  --, TRD_TP
        , i_rmrk_cd                                 --, RMRK_CD
        , ''                                        --, BANK_CD
        , '00'                                      --, MDM_TP
        , '00'                                      --, TRD_MDM_TP
        , 'N'                                       --, CNCL_YN
        , 0                                         --, ORG_TRD_NO
        , 0                                         --, TRD_AMT
        , 0                                         --, CMSN
        , 0                                         --, SB_TAX
        , 0                                         --, ADJ_AMT
        , 0                                         --, DPO_PRERM
        , 0                                         --, DPO_NOWRM
        , c1.cw_cd                                  --, STK_CD
        , vn.fss_get_stk_nm(c1.cw_cd)      --, STK_NM
        , ROUND(c1.book_amt / c1.cw_qty)        --, SB_PRI
        , c1.cw_qty                                 --, SB_QTY
        , t_pre_own_qty                             --, BIL_PRERM_QTY
        , t_now_own_qty                             --, BIL_NOWRM_QTY
        , c1.book_amt                             --, BOOK_AMT
        , '70'                                      --, STK_TP
        , t_exec_dt                                 --, MTH_DT
        , null                                      --, LND_TP
        , null                                      --, LND_DT
        , null                                      --, LND_BANK_CD
        , 0                                         --, LND_AMT
        , 0                                         --, LND_RPY_AMT
        , 0                                         --, LND_INT
        , 0                                         --, LND_CMSN
        , 0                                         --, LND_INT_DLY
        , 0                                         --, LND_CMSN_DLY
        , 'N'                                       --, AGNT_YN
        , t_acnt_mng_bnh                            --, ACNT_MNG_BNH
        , t_agnc_brch                               --, AGNC_BRCH
        , t_proc_brch_cd                            --, WORK_BNH
        , t_proc_agnc_brch                          --, PROC_AGNC_BRC
        , i_work_mn                                 --, WORK_MN
        , sysdate                                   --, WORK_DTM
        , i_work_trm                                --, WORK_TRM
        , c1.setl_dt                                --, SETL_DT
        , 0                                         --, TOT_DPO_PRERM
        , 0                                         --, TOT_DPO_NOWRM
        , t_pre_own_qty                             --, TOT_BIL_PRERM
        , t_now_own_qty                             --, TOT_BIL_NOWRM
      );
      exception
      when others then
        vn.pxc_log_write('pds_aaa10m00_ins', 'END : '||' ACNT ='||i_acnt_no||'-'||i_sub_no);
        t_err_msg := vn.fxc_get_err_msg('V','9405');
        raise_application_error(-20100,t_err_msg||'-['||sqlcode||']ACNT:'||i_acnt_no || '-'||i_sub_no);
    end;

    /*================================================================*/
    /* Danh gia tai san                                               */
    /*================================================================*/
    vn.pdl_crd_loan_rt_proc_td(t_exec_dt,'2',c1.acnt_no,c1.sub_no,0,i_work_mn,i_work_trm,t_ocnt1);

    vn.pxc_log_write('pdl_crd_loan_rt_proc_td','pdl_crd_loan_rt_proc_td: o_cnt1 = '|| t_ocnt1 );

  end loop;

  for C3 in (
      select
        c.acnt_no                         as acnt_no,
        c.sub_no                        as sub_no,
        c.stk_cd                        as cw_cd
      from vn.scw05m00 c,
        vn.ssi01m00 s,
        vn.scw01h00 s1
      where c.stk_cd  = s.stk_cd
      and c.stk_cd  = s1.stk_cd
      and i_exec_dt = s1.dt
      and c.reg_qty > 0
      and c.exec_dt = i_exec_dt
      and (
          (s.cw_tp = '1' and s1.setl_pri > s.cw_exer_price ) -- Chung quyen ban bi lo thi gia thanh toan > gia thuc hien
          Or
          (s.cw_tp = '2' and s1.setl_pri < s.cw_exer_price ) -- Chung quyen Mua bi lo thi gia thanh toan < gia thuc hien
        )
      and c.cncl_yn = 'N'
    ) loop

    /*Update setl_cr_yn trong scw05m00 truong hop cac ma bi lo*/
    BEGIN
      update scw05m00
      set setl_cr_yn = 'C'
      where acnt_no = C3.acnt_no
      and sub_no = C3.sub_no
      and exec_dt = i_exec_dt
      and stk_cd = C3.cw_cd;
    EXCEPTION
    WHEN OTHERS THEN
      t_err_txt  :=  'Update setl_cr_yn trong scw05m00:'||  to_char(sqlcode);
      t_err_msg := vn.fxc_get_err_msg('V','9006');
      raise_application_error(-20100,t_err_msg||t_err_txt);
    END;

  end loop;
  vn.pxc_log_write('pss_change_cw_exec_qty','END pss_change_cw_exec_qty');
END pss_change_cw_exec_qty;
/

