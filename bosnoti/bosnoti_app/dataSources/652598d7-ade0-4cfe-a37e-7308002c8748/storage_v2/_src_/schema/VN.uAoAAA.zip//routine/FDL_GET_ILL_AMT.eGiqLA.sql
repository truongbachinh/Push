create function    fdl_get_ill_amt(
  i_acnt_no in varchar2,
  i_sub_no  in varchar2,
  i_apy_dt  in varchar2
  ) return number   as

  
    t_day_tp        VARCHAR2(1) := '1';
    t_grp_acnt_tp   VARCHAR2(2) := '08';
    t_prd_tp        VARCHAR2(2) := '02';
    t_src_tp        VARCHAR2(2) := '03';  

    t_grp_acnt_no varchar2(5);
    t_acnt_grp_acnt_lnd_limit_max number :=0;   
    t_acnt_prd_lnd_limit_max  number :=0;
    t_acnt_src_lnd_limit_max  number :=0;
    t_acnt_prd_src_lnd_limit  number :=0;
    t_acnt_prd_src_lnd_limit_sum  number :=0;

    t_ill_amount number :=0;

  /*
Lay theo MH 04608: min(sum{ min(hạn mức vay tối đa tk theo nguồn,  hạn mức vay tối đa tk theo sản phẩm) }, hạn mức vay tối đa tk theo nhóm TK)

  */
begin

    t_grp_acnt_no := faa_acnt_get_grp_no(i_acnt_no, i_sub_no,'2', i_apy_dt);

    t_acnt_grp_acnt_lnd_limit_max := vn.fdl_get_acnt_max_amt_by_item(i_acnt_no, i_sub_no, t_grp_acnt_tp, t_grp_acnt_no, t_day_tp);

    For vc in (
    SELECT 
        d90.prd_no,
        d00.src_no
    FROM 
        vn.dlm90m00 d90,
        vn.dlm00m01 d00
    WHERE d90.grp_acnt_no = t_grp_acnt_no
    AND d90.active_stat = 'Y'
    AND d90.apy_dt <= i_apy_dt
    AND d90.expr_dt >= i_apy_dt
    AND d90.prd_no = d00.item_cd
    AND d00.item_tp = '02'  
	AND vn.fdl_item_detail_chk (d00.item_tp,d00.item_cd,i_apy_dt) = 'Y'

    )
    Loop

        t_acnt_prd_lnd_limit_max := vn.fdl_get_acnt_max_amt_by_item(i_acnt_no, i_sub_no, t_prd_tp, vc.prd_no, t_day_tp) ;
        t_acnt_src_lnd_limit_max := vn.fdl_get_acnt_max_amt_by_item(i_acnt_no, i_sub_no, t_src_tp, vc.src_no, t_day_tp) ;
        t_acnt_prd_src_lnd_limit := least (t_acnt_prd_lnd_limit_max,t_acnt_src_lnd_limit_max);

        t_acnt_prd_src_lnd_limit_sum := t_acnt_prd_src_lnd_limit_sum + t_acnt_prd_src_lnd_limit;
    end loop;

    t_ill_amount := least (t_acnt_prd_src_lnd_limit_sum,t_acnt_grp_acnt_lnd_limit_max);

    Return t_ill_amount;
end fdl_get_ill_amt;
/

