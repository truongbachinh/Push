create function    fbm_get_biz_cmsn_rt(
    i_biz_cmsn_grp_cd       varchar2,
    i_dt                    varchar2,
    i_trd_amt               number,
    i_emp_exp_tp            varchar2
)
/*
    select fbm_get_biz_cmsn_rt(
        'HHMGC1_TPT',       -- i_biz_cmsn_grp_cd       varchar2,
        vwdate,             -- i_dt                    varchar2,
        1234567890          -- i_trd_amt               number
    ) cmsn_rt
    from dual;
*/
return number

as  
    t_proc_nm               varchar2(50)    := 'fbm_get_biz_cmsn_rt';
    t_biz_cmsn_grp_id       number;
    t_cmsn_cal_tp           varchar2(1);
    t_max_apy_dt            varchar2(8);
    t_cmsn_rt               number;

    t_err_msg               varchar2(400)   := ' ';
    o_cmsn_rt               number;

begin
    begin
        select cmsn_cal_tp
        into t_cmsn_cal_tp
        from vn.rms01m00
        where biz_cmsn_grp_cd = i_biz_cmsn_grp_cd;
    exception when others then
        o_cmsn_rt := 0;
        return o_cmsn_rt; 
    end;

    if(t_cmsn_cal_tp = '2') then
        begin
            select max(apy_dt) max_apy_dt
            into t_max_apy_dt
            from vn.rms01m01
            where biz_cmsn_grp_cd = i_biz_cmsn_grp_cd
            and emp_exp_tp = i_emp_exp_tp
            and apy_dt <= i_dt
            and active_stat = 'Y'
            group by biz_cmsn_grp_cd;

            select r.cmsn_val
            into t_cmsn_rt
            from vn.rms01m01 r
            where r.biz_cmsn_grp_cd = i_biz_cmsn_grp_cd
            and r.emp_exp_tp = i_emp_exp_tp
            and r.apy_dt = t_max_apy_dt
            and i_trd_amt between r.min_amt and r.max_amt
            and r.active_stat = 'Y';
        exception 
            when no_data_found
                then t_cmsn_rt := 0;
            when others then
                t_err_msg  := 'Error when getting commission rate for: ' 
                || 'i_biz_cmsn_grp_cd: '    || i_biz_cmsn_grp_cd
                || ', i_dt: '               || i_dt
                || ', i_trd_amt: '          || i_trd_amt
                || '. ' || sqlcode || ' - ' || sqlerrm;

                vn.pxc_log_write(t_proc_nm, t_err_msg);
                raise_application_error(-20100,t_err_msg);
        end;
    else
        t_cmsn_rt := 0;
    end if;

    o_cmsn_rt := t_cmsn_rt;

    return o_cmsn_rt;

end;
/

