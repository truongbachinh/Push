create procedure temp_pdl_buy_loan_mrtg
    ( i_dt          in     varchar2,        --
      i_acnt_no     in     varchar2,        --
      i_lnd_bank_cd in     varchar2,        --
      i_stk_cd      in     varchar2,        --
      i_work_mn     in     varchar2,        -- user id
      i_work_trm    in     varchar2,
      o_proc_cnt    in out number
    ) as

/*!
   \file     temp_pdl_buy_loan_mrtg.sql
   \brief    loan for buying(mortgage quantity setting)

   \section intro Program Information
        - Program Name              : loan for buying(mortgage quantity setting)
        - Service Name              : ds_04003_p1.pc
        - Related Client Program- Client Program ID : w_04001
        - Related Tables            : dlm01m00, dlm01m10
                                    : cwd01m00, ssb01m00, aaa01m00, aaa10m00
        - Dev. Date                 : 2007/11/08
        - Developer                 : Han.
        - Business Logic Desc.      : ���ڱ��� �㺸���� ����
        - Latest Modification Date  : 2007/11/08

   \section history Program Modification History
    - 1.0       2007/11/08     Han.    New.

   \section hardcoding Hard-Coding List
    - HC-1      2007/11/08     Han.    [��]

   \section info Additional Reference Comments
    -
var o_cnt number;
exec temp_pdl_buy_loan_mrtg('20091117','068C003234','9999','STB','Conv_man','Conv_man',:o_cnt);
print o_cnt;
*/

    t_pppre_cntr_dt          VARCHAR2(08) := null;  --

    t_err_msg    varchar2(500)      := null;

begin

    /*=========================================================================*/
    /* Input Date CHECK                                                        */
    /*=========================================================================*/
    if  vn.fxc_holi_ck(to_date(i_dt,'yyyymmdd')) !=  '0' then
        if  i_work_mn <> 'DAILY' then
            t_err_msg := vn.fxc_get_err_msg('V','2422');
            t_err_msg := t_err_msg||' Date = '||i_dt;
            raise_application_error(-20100,t_err_msg);
        else
            return;
        end if;
    end if;
/*
    if  vn.vwdate  !=  i_dt then
        t_err_msg := vn.fxc_get_err_msg('V','2422');
        raise_application_error(-20100,t_err_msg||' Date = '||i_dt);
    end if;
*/
    /*=========================================================================*/
    /* Prededing job Check                                                     */
    /*=========================================================================*/
/*
    if  i_acnt_no = '%' and
        vn.fxb_daily_stat_chk ('E','0','2300','2300','*') <> 'Y' then
        t_err_msg := vn.fxc_get_err_msg('V','2458');
        t_err_msg := t_err_msg||'[2300],[2300]'||i_dt;
        raise_application_error(-20100,t_err_msg);
    end if;
*/
    t_pppre_cntr_dt := vn.fxc_vorderdt_g(to_date(i_dt,'yyyymmdd'), -3);

    o_proc_cnt := 0;

/*=============================================================================*/
/* ( )                                                                         */
/*=============================================================================*/
        update  vn.ssb01m00
           set  mrtg_buy_qty =  0
         where  acnt_no   like  i_acnt_no
           and  stk_cd    like  i_stk_cd
        ;

    for C1 in (
        select  acnt_no
             ,  lnd_dt
             ,  mth_dt
             ,  lnd_bank_cd
             ,  stk_cd
             ,  nvl(mrtg_lnd_qty,0) mrtg_lnd_qty
             ,  nvl(mrtg_rpy_qty,0) mrtg_rpy_qty
             ,  nvl(mth_amt,0)      mth_amt
             ,  nvl(lnd_amt,0)      lnd_amt
             ,  nvl(lnd_rpy_amt,0)  lnd_rpy_amt
          from  vn.dlm01m00
         where  lnd_tp          =  '30'
           and  acnt_no      like  i_acnt_no
           and  lnd_bank_cd  like  i_lnd_bank_cd
           and  stk_cd       like  i_stk_cd
           and  setl_dt        <=  i_dt
           -- and  lnd_dt    between  t_pppre_cntr_dt and i_dt
           -- and  mth_dt    between  t_pppre_cntr_dt and i_dt
           -- and  setl_dt         =  i_dt
           and  lnd_acpt_tp     =  '01'
           and  mrtg_lnd_qty - mrtg_rpy_qty > 0
         order  by  acnt_no, lnd_dt, mth_dt
                 ,  lnd_bank_cd,  stk_cd
    ) loop

        o_proc_cnt := o_proc_cnt + 1;

        update  vn.ssb01m00
           set  mrtg_buy_qty =  mrtg_buy_qty + C1.mrtg_lnd_qty - C1.mrtg_rpy_qty
         where  acnt_no      =  C1.acnt_no
           and  stk_cd       =  C1.stk_cd
        ;

        if  sql%notfound or sql%notfound is null then
            insert into vn.ssb01m00
            (acnt_no,      stk_cd,      stk_tp,
             own_qty,      book_amt,    bclm_qty,
             mrtg_lnd_qty,
             mrtg_buy_qty,
             work_mn,      work_dtm,    work_trm)
            values
            (C1.acnt_no,   C1.stk_cd,   vn.fss_get_stk_tp(C1.stk_cd),
             0,            0,           0,
             0,
             C1.mrtg_lnd_qty - C1.mrtg_rpy_qty,
             i_work_mn,    sysdate,     i_work_trm);
        end if;

    end loop;

end temp_pdl_buy_loan_mrtg;
/

