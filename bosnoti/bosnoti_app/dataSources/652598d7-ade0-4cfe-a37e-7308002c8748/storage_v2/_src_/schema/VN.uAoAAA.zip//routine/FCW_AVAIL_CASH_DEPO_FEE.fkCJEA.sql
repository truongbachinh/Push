create function fcw_avail_cash_depo_fee
(
     i_sec_cd   in varchar2
    ,i_acnt_no  in varchar2
    ,i_sub_no  in varchar2
) return number is

  t_temp          number := 0 ;
  t_avl_dpo       number := 0 ;
  t_prof_rel      number := 0 ;
  t_prof_cd       number := 0 ;
  t_prof_vd       number := 0 ;
  t_prof_tot      number := 0 ;

  t_err_msg       varchar2(500)  ;
  t_err_code      varchar2(5)    ;
  t_err_txt       varchar2(500)  ;

  t_avl_cash      number := 0 ;

begin

    begin
      select  Greatest (   nvl(dpo, 0)
                       - nvl(dpo_block, 0 )
                     - nvl(outq_dpo_bk , 0 )
                         - nvl(crd_dpo , 0 )
                         /*+ nvl(dpo_fee_bk , 0 )   Depository fee blocked */
                , 0 )
          into t_avl_dpo
        from vn.cwd01m00
       where acnt_no = i_acnt_no
       and sub_no = i_sub_no;

    EXCEPTION
         WHEN   OTHERS THEN
        return 0 ;
    END;

    BEGIN

    vn.pts_acnt_prof_g(i_acnt_no      ,
                       i_sub_no       ,
                       '9999'         ,
                       t_temp         ,  -- dpo amt
                       t_prof_rel     ,  -- total dpo amt
                       t_temp         ,  -- creadit amt
                       t_prof_cd      ,  -- total creadit amt
                       t_temp         ,  -- VD amt
                       t_prof_vd      ,  -- total vd amt
                       t_temp         ,  -- reuse of matched
                       t_temp         ,  -- matched on today
                       t_temp         ,  -- except td_buy diff from matched( BP excepts td_buy diff )
                       t_temp         ,
                       t_err_code     ,
                       t_err_txt);
   EXCEPTION
   WHEN  OTHERS         THEN
            vn.pxc_log_write('pcw_get_dpo_prof_q','pts_acnt_prof_g -'|| t_err_code );
      return 0 ;
   END;

   t_prof_tot := t_prof_rel + t_prof_cd + t_prof_vd ;

   t_avl_cash := Greatest ( t_avl_dpo - t_prof_tot  , 0 )  ;

   return t_avl_cash  ;


end fcw_avail_cash_depo_fee;
/

