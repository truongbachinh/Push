create PROCEDURE PTS_CLEAR_MARGIN_P (
    I_TP     IN  VARCHAR2,   -- 1: Ho Chi Minh, 2: Hanoi
    I_STK_TP IN  VARCHAR2    -- 01 : stock, 02 : bond, 03 : mutual fund
) IS

/*!
    \file     PTS_CLEAR_MARGIN_P
    \brief    Non conclusion quantity clear

    \section intro Program Information
        - Program Name              : PTS_CLEAR_MARGIN_P
        - Service Name              :
        - Related Client Program- Client Program ID :
        - Related Tables            : TSO01M00, TSO02M00
        - Dev. Date                 : 2007/12/08
        - Developer                 : SB.LEE
        - Business Logic Desc.      :
        - Latest Modification Date  :

    \section history Program Modification History
        - 1.0  2007/12/08    SB.LEE       First make

    \section hardcoding Hard-Coding List

    \section info Additional Reference Comments
*/

T_PROF_AMT      NUMBER := 0;
T_TAX           NUMBER := 0;

BEGIN
    IF I_TP = '1' THEN
        FOR C1 IN ( SELECT ACNT_NO, SUB_NO, NMTH_QTY, ORD_PROF_PRI, CASH_PROF_RT
                     FROM VN.TSO01M00
                    WHERE SELL_BUY_TP = '2'
                      AND MKT_TRD_TP  IN('01','02')
                      AND STK_TP      = I_STK_TP
                      AND NMTH_QTY    > 0
                      AND STK_ORD_TP NOT IN ('03', '04')
                    ORDER BY ORD_NO
        ) LOOP
            T_TAX      := TRUNC(C1.NMTH_QTY * C1.ORD_PROF_PRI * C1.CASH_PROF_RT);
            T_PROF_AMT := C1.NMTH_QTY * C1.ORD_PROF_PRI + T_TAX;

            UPDATE VN.TSO02M00
               SET TD_CASH_PROF_AMT = GREATEST(NVL(TD_CASH_PROF_AMT, 0) - T_PROF_AMT, 0)
             WHERE ACNT_NO = C1.ACNT_NO
               AND SUB_NO = C1.SUB_NO;
        END LOOP;

	  FOR C3 IN ( 	SELECT	A.ACNT_NO, A.SUB_NO, A.STK_CD, A.TD_SELL_MTH_QTY
				FROM	TSO04M00 A, SSI01M00 B
				WHERE	A.STK_CD = B.STK_CD
						AND B.STK_MKT_TP ='1'
						AND STK_TP = I_STK_TP
						AND A.TD_SELL_ORD_QTY > 0
						ORDER BY A.ACNT_NO, A.SUB_NO

        ) LOOP

            UPDATE 	VN.TSO04M00
               SET 	TD_SELL_ORD_QTY = TD_SELL_MTH_QTY
             WHERE 	ACNT_NO = C3.ACNT_NO
               AND	SUB_NO = C3.SUB_NO
             			AND STK_CD = C3.STK_CD;
        END LOOP;

        UPDATE VN.TSO03M00
           SET MKT_DRV_TP = 'AC'
         WHERE SB_KFX_TP  = 'HOSTC'
           AND STK_TP     = I_STK_TP;

		UPDATE VN.TSO01M00
		   SET PROF_CLS_YN = 'Y'
		 WHERE MKT_TRD_TP  IN('01','02')
           AND STK_TP      = I_STK_TP;

    ELSIF I_TP = '2' THEN
        FOR C2 IN ( SELECT ACNT_NO, SUB_NO, NMTH_QTY, ORD_PROF_PRI, CASH_PROF_RT
                     FROM VN.TSO01M00
                    WHERE SELL_BUY_TP = '2'
                      AND MKT_TRD_TP  IN('03','04')
                      AND STK_TP      = I_STK_TP
                      AND NMTH_QTY    > 0
                      AND STK_ORD_TP NOT IN ('03', '04')
                    ORDER BY ORD_NO
        ) LOOP
            T_TAX      := TRUNC(C2.NMTH_QTY * C2.ORD_PROF_PRI * C2.CASH_PROF_RT);
            T_PROF_AMT := C2.NMTH_QTY * C2.ORD_PROF_PRI + T_TAX;

            UPDATE VN.TSO02M00
               SET TD_CASH_PROF_AMT = GREATEST(NVL(TD_CASH_PROF_AMT, 0) - T_PROF_AMT, 0)
             WHERE ACNT_NO = C2.ACNT_NO
               AND SUB_NO = C2.SUB_NO;
        END LOOP;

        FOR C4 IN ( 	SELECT	A.ACNT_NO, A.SUB_NO, A.STK_CD, A.TD_SELL_MTH_QTY
				FROM	TSO04M00 A, SSI01M00 B
				WHERE	A.STK_CD = B.STK_CD
						AND B.STK_MKT_TP ='2'
						AND STK_TP = I_STK_TP
						AND A.TD_SELL_ORD_QTY > 0
						ORDER BY A.ACNT_NO, A.SUB_NO

        ) LOOP

            UPDATE 	VN.TSO04M00
               SET 	TD_SELL_ORD_QTY = TD_SELL_MTH_QTY
             WHERE 	ACNT_NO = C4.ACNT_NO
               AND	SUB_NO = C4.SUB_NO
               AND STK_CD = C4.STK_CD;
        END LOOP;

        UPDATE VN.TSO03M00
           SET MKT_DRV_TP = 'AC'
         WHERE SB_KFX_TP  = 'HASTC'
           AND STK_TP     = I_STK_TP;

       	UPDATE VN.TSO01M00
		   SET PROF_CLS_YN = 'Y'
		 WHERE MKT_TRD_TP  IN('03','04')
           AND STK_TP      = I_STK_TP;
    ELSE
        RAISE_APPLICATION_ERROR (-20100, 'Invalid type [' || I_TP || ':'||I_STK_TP||']');
    END IF;


END PTS_CLEAR_MARGIN_P;
/

