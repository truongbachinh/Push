create procedure    pts_bat_tso01h15_ins (
    i_work_dt       in      varchar2,       -- date(yyyymmdd)
	o_err_code      in      number,         -- error code(0:SUCCESS)
	o_err_msg       in      varchar2,       -- error message
	o_proc_cnt      out     number          -- proc data count
) as

t_err_code      number        := o_err_code;
t_err_msg       varchar2(600) := rtrim(o_err_msg);
t_chk           varchar2(1);
cnt             number;
exp_error       exception;

/*!
    \file     pts_bat_tso10h00_ins
	\brief    tso01h15 select, tso01m15 insert

	\section intro Program Information
		- Program Name              : pts_bat_tso01h15_ins
		- Service Name              :
		- Related Client Program- Client Program ID :
		- Related Tables            : tso01m15, tso01h15
		- Dev. Date                 : 2019/05/21
		- Developer                 : HieuPm
		- Business Logic Desc.      :
		- Latest Modification Date  :

	\section history Program Modification History
		- 1.0  2007/11/27

	\section hardcoding Hard-Coding List

	\section info Additional Reference Comments
*/

begin

	t_err_code := 0;
	t_err_msg  := 'SUCCESS';
	t_chk      := 'Y';
    o_proc_cnt := 0;
	cnt        := 0;

	-- 1. ¢¥cAI ¡ÆaA|A¨ù¡Æa ¢¯I¡¤a A¨ùA¨Ï FunA¨ùA¨Ï
	if t_chk = 'N' then
		t_err_code := -1;
	    t_err_msg  := '¢¥cAI ¡ÆaA|A¨ù¡Æa ©öI¢¯I¡¤aAO¢¥I¢¥U. A¨ù¡Æa ¡ÆaA| EA A©ø¢¬¢çCI¨öE¨öA¢¯a.!';
		raise_application_error(-20100,'[pts_bat_tso01h15_ins] ' || t_err_msg);
	else
		select 	count(*)
		into	cnt
		from	TSO01M15;

		if cnt > 0 then
			delete 	TSO01H15
			where	trd_dt = i_work_dt;
	        for  c1  in (
			   SELECT  ACNT_NO,
					   SUB_NO,
					   BNH_CD,
					   STK_CD,
					   SELL_BUY_TP,
					   ORD_NO,
					   ORD_MTH_NO,
					   MTH_TIME,
					   MTH_QTY,
					   MTH_PRI,
					   WORK_MN,
					   PROC_TP
				  FROM TSO01M15
	             ) loop

	             cnt := cnt + 1;
				 insert into vn.tso01H15
				 (
					   TRD_DT,
					   ACNT_NO,
					   SUB_NO,
					   BNH_CD,
					   STK_CD,
					   SELL_BUY_TP,
					   ORD_NO,
					   ORD_MTH_NO,
					   MTH_TIME,
					   MTH_QTY,
					   MTH_PRI,
					   WORK_MN,
					   PROC_TP
	            ) values (
						i_work_dt,
						c1.ACNT_NO,
						c1.SUB_NO,
						c1.BNH_CD,
						c1.STK_CD,
						c1.SELL_BUY_TP,
						c1.ORD_NO,
						c1.ORD_MTH_NO,
						c1.MTH_TIME,
						c1.MTH_QTY,
						c1.MTH_PRI,
						c1.WORK_MN,
						c1.PROC_TP
	            );

	        end loop;
    	end if;
    end if;

	o_proc_cnt := cnt;

	exception when  exp_error then
		t_err_code := sqlcode;
		t_err_msg  := sqlerrm;
		raise_application_error(-20100,'[pts_bat_tso01h15_ins] ' || t_err_msg);

end pts_bat_tso01h15_ins;
/

