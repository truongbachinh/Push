create function    fdl_get_prd_lnd_limit
    (i_prd_no varchar2,
     i_day_tp varchar2)
return number
as
  /*!
     \file     fdl_get_prd_lnd_limit.sql
     \brief    fdl_get_prd_lnd_limit
     \section intro Program Information
          - Program Name              : 
          - Service Name              :
          - Related Client Program- Client Program ID :
          - Related Tables            : dlm00m01, dlm09m10
          - Dev. Date                 : 2018/05/21
          - Developer                 : GiangLH.
          - Business Logic Desc.      : fdl_get_prd_lnd_limit
          - Latest Modification Date  : 2018/05/21
   */
    t_detail_chk varchar2(2) := 'Y';
    t_prd_max_amt number := 0;
    t_prd_lnd_amt number := 0;
    t_prd_lnd_limit number :=0;

-- Neu i_day_tp = '1'- Su dung trong ngay: Co cong them so luong du kien vay (extp) vao so da dung
-- Neu i_day_tp ='2' - Cuoi ngay: Khong cong them so luong du kien vay (extp) vao so da dung
begin
    /*
    RLL(P) = Max(0,Maximum limit(P) - Used(P))          
        Maximum Limit(P): Tong han muc toi da duoc phep cho vay cua san pham P
            Lay tu cot <Han muc tong> doi tuong du lieu "San pham" dang duoc ap dung cua san pham P
        Used(P): Tong gia tri han muc da dung cua san pham P
            Sum(gia tri vay, gia tri du kien vay) theo san pham P tu bang dlm09m10
    */

    t_detail_chk := vn.fdl_item_detail_chk(
                        '02',
                        i_prd_no,
                        vn.vwdate()
                    );

    IF(t_detail_chk = 'Y') THEN
        BEGIN
            SELECT nvl(tot_lnd_lmit,0) 
            INTO t_prd_max_amt
            FROM vn.dlm00m01 a
            WHERE  a.item_tp ='02' --San Pham
              AND a.item_cd = i_prd_no
              AND active_stat ='Y';
        EXCEPTION
            WHEN OTHERS THEN
                t_prd_max_amt := 0;
        END;
    END IF;

    BEGIN
        select sum(nvl(lnd_use_amt,0)) + sum(decode(i_day_tp, '1', nvl(lnd_expt_amt,0), 0))
         into t_prd_lnd_amt
        from vn.dlm09m10
        where lnd_tp in ('70', '80')
            and prd_no =i_prd_no;
    EXCEPTION
          WHEN OTHERS THEN
              t_prd_lnd_amt := 0;
    END;
    t_prd_lnd_limit := greatest(0,nvl(t_prd_max_amt,0)-nvl(t_prd_lnd_amt,0));

    return t_prd_lnd_limit;

end fdl_get_prd_lnd_limit;
/

