create procedure  pss_stk_remn_proc_p
(  i_proc_dt    in   varchar2,
   i_acnt_no    in   varchar2,
   i_sub_no     in   varchar2,
   i_stk_cd     in   varchar2,
   i_tp         in   varchar2,
   i_qty        in   number,
   i_in_uv      in   number,
   i_lnd_qty    in   number
 ) is

 vn_count    number;
 vn_count2   number;
 vn_count3   number;
 vn_count4   number;
 vn_out_qty  number;
 vn_own_qty  number;
 vs_stk_tp   varchar2(2);

begin

 vn.pxc_log_write('pss_stk_remn_proc_p', 'start');

 select  vn.fss_get_stk_tp(i_stk_cd)
 into    vs_stk_tp
 from    dual;

 if  vs_stk_tp <> '10' and vs_stk_tp <> '20' and vs_stk_tp <> '30'  then
     raise_application_error(-20100, '��������߸� �Ǿ����ϴ�');
 end if;

 if  i_tp = '1'  then

	 select   count(*)
	 into     vn_count
	 from     vn.ssb01m00
	 where    acnt_no = i_acnt_no
	 and      sub_no  = i_sub_no
	 and      stk_cd  = i_stk_cd;

	 if  vn_count > 0  then

		  update  vn.ssb01m00
		  set     own_qty  =  own_qty + i_qty,
				  book_amt = book_amt + (i_qty * i_in_uv)
		  where   acnt_no  = i_acnt_no
		  and     sub_no   = i_sub_no
		  and     stk_cd   = i_stk_cd;

	  else

		  insert into  vn.ssb01m00
			 (  acnt_no        ,
				sub_no         ,
				stk_cd         ,
				own_qty        ,
				book_amt       ,
                bclm_qty       ,
				mrtg_lnd_qty   ,
				stk_tp         ,
				work_mn        ,
				work_dtm       ,
				work_trm
              ) values (
			    i_acnt_no       ,
			    i_sub_no        ,
				i_stk_cd        ,
				i_qty           ,
				i_in_uv * i_qty ,
				0               ,
				0               ,
                vs_stk_tp       ,
				'setl'          ,
				sysdate         ,
				'setl'
               ) ;

         end if;

         if  vs_stk_tp = '10'  then

			 select  count(*)
			 into    vn_count2
			 from    vn.ssb02m00
			 where   acnt_no  = i_acnt_no
			 and     sub_no   = i_sub_no
			 and     stk_cd   = i_stk_cd
			 and     buy_dt   = i_proc_dt;

			 if  vn_count2 > 0  then

				 update   vn.ssb02m00
				 set      own_qty  =  own_qty  + i_qty
                 where    acnt_no  = i_acnt_no
				 and      sub_no   = i_sub_no
				 and      stk_cd   = i_stk_cd
				 and      buy_dt   = i_proc_dt;

             else

				 insert into  vn.ssb02m00
				   (   acnt_no ,
					   sub_no  ,
					   stk_cd  ,
					   buy_dt  ,
					   own_qty ,
					   work_mn ,
					   work_dtm,
					   work_trm
                    ) values (
					   i_acnt_no,
					   i_sub_no,
					   i_stk_cd ,
					   i_proc_dt,
					   i_qty    ,
					   'setl'   ,
					   sysdate  ,
					   'setl'
                    );

               end if;

		  elsif  vs_stk_tp = '20'  then

	          select  count(*)
			  into    vn_count3
			  from    vn.ssb03m00
			  where   acnt_no  = i_acnt_no
			  and     sub_no   = i_sub_no
			  and     stk_cd   = i_stk_cd
			  and     buy_dt   = i_proc_dt;

			  if  vn_count3 > 0  then

				  update   vn.ssb03m00
				  set      own_qty  =  own_qty  + i_qty
                  where    acnt_no  = i_acnt_no
				  and      sub_no   = i_sub_no
				  and      stk_cd   = i_stk_cd
				  and      buy_dt   = i_proc_dt;

             else

				  insert into  vn.ssb03m00
				   (   acnt_no,
					   sub_no,
					   stk_cd,
					   buy_dt,
					   own_qty,
					   work_mn,
					   work_dtm,
					   work_trm
                    ) values (
					   i_acnt_no,
					   i_sub_no,
					   i_stk_cd,
					   i_proc_dt,
					   i_qty,
					   'setl',
					   sysdate,
					   'setl'
                    );

               end if;

           else

	          select  count(*)
			  into    vn_count4
			  from    vn.ssb04m00
			  where   acnt_no  = i_acnt_no
			  and     sub_no   = i_sub_no
			  and     stk_cd   = i_stk_cd
			  and     buy_dt   = i_proc_dt;

			  if  vn_count4 > 0  then

				  update   vn.ssb04m00
				  set      own_qty  =  own_qty  + i_qty
                  where    acnt_no  = i_acnt_no
				  and      sub_no   = i_sub_no
				  and      stk_cd   = i_stk_cd
				  and      buy_dt   = i_proc_dt;

             else

				  insert into  vn.ssb04m00
				   (   acnt_no,
					   sub_no,
					   stk_cd,
					   buy_dt,
					   own_qty,
					   work_mn,
					   work_dtm,
					   work_trm
                    ) values (
					   i_acnt_no,
					   i_sub_no,
					   i_stk_cd,
					   i_proc_dt,
					   i_qty,
					   'setl',
					   sysdate,
					   'setl'
                    );

               end if;

            end if;


  else           -- �ŵ��ΰ�

	  update   vn.ssb01m00
	  set      own_qty   =  own_qty  - i_qty,
			   book_amt  =  book_amt - (i_qty * i_in_uv)
      where    acnt_no   =  i_acnt_no
	  and      sub_no    =  i_sub_no
	  and      stk_cd    =  i_stk_cd;

	  if  vs_stk_tp = '10'  then

          vn_out_qty := i_qty;

	      for c1  in (

			 select   acnt_no,
					  stk_cd,
					  buy_dt,
					  own_qty
             from     vn.ssb02m00
             where    acnt_no = i_acnt_no
			   and    sub_no  = i_sub_no
			 and      stk_cd  = i_stk_cd
             order by  buy_dt desc

		   ) loop

	          if  c1.own_qty >=  vn_out_qty  then

			      update  vn.ssb02m00
			      set     own_qty  =  own_qty - vn_out_qty
			      where   acnt_no  =  i_acnt_no
				  and     sub_no   =  i_sub_no
			      and     stk_cd   =  i_stk_cd
			      and     buy_dt   =  c1.buy_dt;

	              exit;

              else

                  if  c1.own_qty > vn_out_qty  then
					  vn_own_qty := c1.own_qty - vn_out_qty;
                  else
					  vn_own_qty := 0;
				  end if;

				  update  vn.ssb02m00
				  set     own_qty = vn_own_qty
				  where   acnt_no = i_acnt_no
				  and     sub_no  = i_sub_no
				  and     stk_cd  = i_stk_cd
				  and     buy_dt  = c1.buy_dt;

                  vn_out_qty := vn_out_qty - c1.own_qty;

              end if;

		   end loop;

      elsif  vs_stk_tp = '20'  then

          vn_out_qty := i_qty;

	      for c1  in (

			 select   acnt_no,
					  stk_cd,
					  buy_dt,
					  own_qty
             from     vn.ssb03m00
             where    acnt_no = i_acnt_no
			 and      sub_no  = i_sub_no
			 and      stk_cd  = i_stk_cd
             order by  buy_dt desc

		   ) loop

	          if  c1.own_qty >=  vn_out_qty  then

			      update  vn.ssb03m00
			      set     own_qty  =  own_qty - vn_out_qty
			      where   acnt_no  =  i_acnt_no
				  and     sub_no   =  i_sub_no
			      and     stk_cd   =  i_stk_cd
			      and     buy_dt   =  c1.buy_dt;

	              exit;

              else

                  if  c1.own_qty > vn_out_qty  then
					  vn_own_qty := c1.own_qty - vn_out_qty;
                  else
					  vn_own_qty := 0;
				  end if;

				  update  vn.ssb03m00
				  set     own_qty = vn_own_qty
				  where   acnt_no = i_acnt_no
				  and     sub_no  = i_sub_no
				  and     stk_cd  = i_stk_cd
				  and     buy_dt  = c1.buy_dt;

                  vn_out_qty := vn_out_qty - c1.own_qty;

              end if;

		   end loop;

	  else

          vn_out_qty := i_qty;

	      for c1  in (

			 select   acnt_no,
					  stk_cd,
					  buy_dt,
					  own_qty
             from     vn.ssb04m00
             where    acnt_no = i_acnt_no
			 and      sub_no  = i_sub_no
			 and      stk_cd  = i_stk_cd
             order by  buy_dt desc

		   ) loop

	          if  c1.own_qty >=  vn_out_qty  then

			      update  vn.ssb04m00
			      set     own_qty  =  own_qty - vn_out_qty
			      where   acnt_no  =  i_acnt_no
				  and     sub_no   =  i_sub_no
			      and     stk_cd   =  i_stk_cd
			      and     buy_dt   =  c1.buy_dt;

	              exit;

              else

                  if  c1.own_qty > vn_out_qty  then
					  vn_own_qty := c1.own_qty - vn_out_qty;
                  else
					  vn_own_qty := 0;
				  end if;

				  update  vn.ssb04m00
				  set     own_qty = vn_own_qty
				  where   acnt_no = i_acnt_no
				  and     sub_no  = i_sub_no
				  and     stk_cd  = i_stk_cd
				  and     buy_dt  = c1.buy_dt;

                  vn_out_qty := vn_out_qty - c1.own_qty;

              end if;

		   end loop;

	  end if;

  end if;

end  pss_stk_remn_proc_p;
/

