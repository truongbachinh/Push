create function    fdl_get_pia_with_cmsn
(
    i_acnt_no        in   varchar2,
    i_sub_no         in   varchar2
) return number is

/*============================================================================*/
/*--- lay tong tien da ung (tien ung + phi ung) truoc do ---*/
/*============================================================================*/
    td_lnd_amt     number := 0;
    t_lnd_amt_tot  number := 0;
    t_rpy_cmsn_tot_all number := 0;

BEGIN
    /*--- lay tong tien da ung (tien ung + phi ung) truoc do ---*/
    /*
    Select sum(a.lnd_amt - a.lnd_rpy_amt + a.lnd_int + a.dly_int + a.lnd_fee + a.dly_fee) into  td_lnd_amt
    From dlm01m00 a
    where a.acnt_no      =  i_acnt_no
    and a.sub_no       =  i_sub_no
    and a.lnd_tp = '10'
    and a.lnd_amt - a.lnd_rpy_amt > 0;
    */
    for C1 in (
            select  a.lnd_tp                               lnd_tp
                 ,  a.acnt_no                              acnt_no
                 ,  a.sub_no                 sub_no
                 ,  a.lnd_bank_cd                          lnd_bank_cd
                 ,  a.lnd_dt                               lnd_dt
                 ,  a.expr_dt                              rpy_dt
                 ,  a.lnd_cmsn_rt                          lnd_cmsn_rt
                 ,  vn.faa_acnt_bnh_cd_g('0',a.acnt_no,a.sub_no)    acnt_mng_bnh
                 ,  vn.faa_acnt_bnh_cd_g('3',a.acnt_no,a.sub_no)    agnc_brch
                 ,  sum(a.lnd_amt)                         lnd_amt
              from  vn.dlm01m00 a
             where  a.lnd_tp           =  '10'
               and  a.acnt_no          =  i_acnt_no
               and  a.sub_no       =  i_sub_no
               and  nvl(a.lnd_amt,0)- nvl(a.lnd_rpy_amt,0) > 0
               and  a.lnd_acpt_tp      =  '01'
             group  by a.lnd_tp, a.acnt_no, a.sub_no, a.lnd_bank_cd, a.lnd_dt, a.expr_dt, a.lnd_cmsn_rt
    ) loop
        t_lnd_amt_tot  := 0;
        t_rpy_cmsn_tot_all := 0;
        t_lnd_amt_tot  := C1.lnd_amt;
        /*====================================================================*/
        /* lnd_cmsn Calc  => 2008/01/30                                       */
        /*====================================================================*/
        t_rpy_cmsn_tot_all := 0;
        vn.pdl_get_lnd_cmsn ( C1.lnd_tp
                            , C1.lnd_bank_cd, C1.acnt_no, C1.sub_no
                            , C1.lnd_dt     , C1.rpy_dt
                            , t_lnd_amt_tot
                            , t_lnd_amt_tot
                            , C1.lnd_cmsn_rt
                            , t_rpy_cmsn_tot_all );
        td_lnd_amt := td_lnd_amt + t_lnd_amt_tot + t_rpy_cmsn_tot_all;
    end loop;

    return td_lnd_amt;

END fdl_get_pia_with_cmsn;
/

