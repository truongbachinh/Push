create procedure pss_acnt_depo_fee_out
( i_sec_cd     in   varchar2,
  i_dt         in   varchar2,
  i_acnt_no    in   varchar2,
  i_sub_no     in   varchar2,
  i_work_mn    in   varchar2,
  i_work_trm   in   varchar2,
  i_bank_avai  in   number default 0
) is

k_rmrk_cd                   varchar2(3) := '247';

vn_tot_out_blk_fee          number := 0;

o_trd_seq_no                number;
o1_rtn_tbl                  varchar2(100) ;              -- return table
o1_rtn_err                  varchar2(100) ;              -- return error code
o1_rtn_msg                  varchar2(254) ;              -- return message
t_cash_bank_avail           number;                      -- cash remaining for bank account
t_avail_depo_fee            number;                      -- cash
t_bank_cd                   varchar2(4) ;                -- bank code
t_cnte                      varchar2(200);               -- note
begin
t_cash_bank_avail := i_bank_avai;
 for c1 in (
   select acnt_no
      ,sub_no
      ,dpo
      ,dpo_fee_bk
    from vn.cwd01m00 t
    where acnt_no like i_acnt_no
    and sub_no like i_sub_no
    and dpo_fee_bk > 0
    order by acnt_no||sub_no
  ) loop
  begin

  vn.pxc_log_write('pss_acnt_depo_fee_out', '['||i_dt||'-'||i_acnt_no||'-'||i_sub_no||']');

  for c2 in (
      select acnt_no
            ,sub_no
            ,usefee
            ,usefee_pay_dt
            ,seq_no
            ,mak_strt_dt
            ,mak_end_dt
      from vn.ssb07m00
      where substr(mak_strt_dt,1,6) = i_dt
            and substr(mak_end_dt,1,6) = i_dt
            and acnt_no = c1.acnt_no
            and sub_no like trim(c1.sub_no)
            and rcpt_trd_no = 0
            and cncl_yn = 'N'
      order by usefee_pay_dt||acnt_no||sub_no||mak_strt_dt
  ) loop

  begin
    -- Get note
    if c2.mak_strt_dt = c2.mak_end_dt then
      t_cnte := to_char(to_date(c2.mak_strt_dt,'YYYYMMDD'),'DD/MM/YYYY');
    elsif c2.mak_strt_dt = to_char(trunc(to_date(c2.mak_strt_dt,'YYYYMMDD'),'MM'),'YYYYMMDD')
        and c2.mak_end_dt = to_char(last_day(to_date(c2.mak_end_dt,'YYYYMMDD')),'YYYYMMDD') then
      t_cnte := to_char(to_date(c2.mak_strt_dt,'YYYYMMDD'),'MM/YYYY');
    else
      t_cnte := to_char(to_date(c2.mak_strt_dt,'YYYYMMDD'),'DD/MM/YYYY')
                || ' - ' || to_char(to_date(c2.mak_end_dt,'YYYYMMDD'),'DD/MM/YYYY');
    end if;

    vn.pxc_log_write('pss_acnt_depo_fee_out','c2.mak_strt_dt: ' || c2.mak_strt_dt || ', c2.mak_end_dt: ' || c2.mak_end_dt ||' t_cnte: '|| t_cnte);

    -- Get bank code
    select  vn.faa_acnt_bank_cd_g(c2.acnt_no, c2.sub_no)
    into    t_bank_cd
    from    dual;

    if t_bank_cd = '!' then
      t_avail_depo_fee := vn.fcw_avail_cash_depo_fee(i_sec_cd,c2.acnt_no,c2.sub_no);
      vn.pxc_log_write('pss_acnt_depo_fee_out',' sub_no: '|| c2.sub_no ||' avail out fee ' ||  t_avail_depo_fee || ' depo fee ' || c2.usefee);
    end if;

       if ((t_bank_cd <> '!' and i_work_mn not in ('DAILY','BATCH') and t_cash_bank_avail >= c2.usefee and c2.usefee > 0)
          or (t_avail_depo_fee >= c2.usefee and c2.usefee > 0)) then
       /* withdraw depo fee after unblock */
       vn.pss_cash_outamt_p(
                        c2.mak_strt_dt, --vn.vwdate,
                        c2.acnt_no,
                        c2.sub_no,
                        k_rmrk_cd,
                        to_char(c2.usefee),
                        '00',
                        ' ',
                        --k_cnfm_yn,
                        t_cnte, --'th?ng ' ||substr(c2.mak_strt_dt,5,2) || '/' || substr(c2.mak_strt_dt,1,4),
                        ' ',
                        i_work_mn,
                        i_work_trm,
                        o_trd_seq_no,
                        o1_rtn_tbl,
                        o1_rtn_err,
                        o1_rtn_msg);

       if  to_number(o1_rtn_err)  <>  0  then /* 3. error */
          vn.pxc_log_write('pss_acnt_depo_fee_out', ' [' || o1_rtn_err || '] [' || o1_rtn_tbl || '] [' || o1_rtn_msg|| ']') ;
          raise_application_error(-20100,'pss_cash_outamt_p '||sqlerrm);
       end if;


        /* update ssb07m00 */
        if (o_trd_seq_no > 0) then
    /*HUEDT add Unblock fee sub dang chay o cursor C2*/
          begin
            vn.pcw_waitting_bk_ubk_p
               ('04'
               ,vn.vwdate
               ,c2.acnt_no
               ,c2.sub_no
               ,c2.usefee
               ,'00'
               ,i_work_mn
               ,i_work_trm
               ,vn_tot_out_blk_fee
               );
          exception
             when others then
              vn.pxc_log_write('pss_acnt_depo_fee_out', ' pcw_waitting_bk_ubk_p 04 ['||sqlcode||']');
          end;

          update  vn.ssb07m00
          set    rcpt_trd_no  = o_trd_seq_no
               --,tot_blk_fee  = 0
                ,work_mn = i_work_mn
                ,work_trm = i_work_trm
                ,work_dtm = sysdate
          where   usefee_pay_dt  = c2.usefee_pay_dt
                  and    mak_strt_dt     = c2.mak_strt_dt
                  and     acnt_no        = c2.acnt_no
                  and     sub_no         = c2.sub_no
                  and     seq_no         = c2.seq_no;

          -- update cash available for bank accounts
          if t_bank_cd <> '!' then
            t_cash_bank_avail := t_cash_bank_avail - c2.usefee;
          end if;
         end if;
        end if;
    end;
  end loop; -- end c2

  end;
  end loop; -- end c1

  return;
end pss_acnt_depo_fee_out;
/

