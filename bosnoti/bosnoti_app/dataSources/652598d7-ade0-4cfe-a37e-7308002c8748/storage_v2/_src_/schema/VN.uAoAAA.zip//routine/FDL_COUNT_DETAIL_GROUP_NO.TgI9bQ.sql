create function fdl_count_detail_group_no(item_cd in varchar2)
  return number as

  o_val number;
  /* tran.nguyen */
begin
  select count(grp_acnt_no)
    into o_val
    from vn.dlm71m00 t
   where t.grp_acnt_no = item_cd
     and t.active_stat = 'Y';

  return o_val;

end fdl_count_detail_group_no;
/

