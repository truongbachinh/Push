create procedure extr_acnt_otp_pdf(
    i_acnt_no       varchar2
)
as
/*
    Sample call:
        declare i_acnt_no varchar2(10) := '039C001993';
        begin
            vn.extr_acnt_otp_pdf(i_acnt_no);
        end;
*/

    t_rc        sys_refcursor;
    t_dir       varchar2(100)       := 'OTP_DIR';
    t_file_nm   varchar2(100)       := null;
begin
    t_file_nm := i_acnt_no || '_otp_' || to_char(sysdate, 'YYYYMMDDHH24MISS') || '.pdf';

    open t_rc for 
        select
            '1' stt_1, a9.m_1 otp_1, '8' stt_2, a9.m_8 otp_2, '15' stt_3, a9.m_15 otp_3, '22' stt_4, a9.m_22 otp_4, '29' stt_5, a9.m_29 otp_5
        from aaa01m00 a1
        inner join aaa99m01 a9
        on a1.iss_no = a9.iss_no
        where
            a1.acnt_no  = i_acnt_no
        and a1.sub_no   = '00'
        and rownum = 1

        UNION ALL

        select
            '2' stt, a9.m_2 otp, '9' stt, a9.m_9 otp, '16' stt, a9.m_16 otp, '23' stt, a9.m_23 otp, '30' stt, a9.m_30 otp
        from aaa01m00 a1
        inner join aaa99m01 a9
        on a1.iss_no = a9.iss_no
        where
            a1.acnt_no  = i_acnt_no
        and a1.sub_no   = '00'
        and rownum = 1

        UNION ALL

        select
            '3' stt, a9.m_3 otp, '10' stt, a9.m_10 otp, '17' stt, a9.m_17 otp, '24' stt, a9.m_24 otp, '31' stt, a9.m_31 otp
        from aaa01m00 a1
        inner join aaa99m01 a9
        on a1.iss_no = a9.iss_no
        where
            a1.acnt_no  = i_acnt_no
        and a1.sub_no   = '00'
        and rownum = 1

        UNION ALL

        select
            '4' stt, a9.m_4 otp, '11' stt, a9.m_11 otp, '18' stt, a9.m_18 otp, '25' stt, a9.m_25 otp, '32' stt, a9.m_32 otp
        from aaa01m00 a1
        inner join aaa99m01 a9
        on a1.iss_no = a9.iss_no
        where
            a1.acnt_no  = i_acnt_no
        and a1.sub_no   = '00'
        and rownum = 1

        UNION ALL

        select
            '5' stt, a9.m_5 otp, '12' stt, a9.m_12 otp, '19' stt, a9.m_19 otp, '26' stt, a9.m_26 otp, '33' stt, a9.m_33 otp
        from aaa01m00 a1
        inner join aaa99m01 a9
        on a1.iss_no = a9.iss_no
        where
            a1.acnt_no  = i_acnt_no
        and a1.sub_no   = '00'
        and rownum = 1

        UNION ALL

        select
            '6' stt, a9.m_6 otp, '13' stt, a9.m_13 otp, '20' stt, a9.m_20 otp, '27' stt, a9.m_27 otp, '34' stt, a9.m_34 otp
        from aaa01m00 a1
        inner join aaa99m01 a9
        on a1.iss_no = a9.iss_no
        where
            a1.acnt_no  = i_acnt_no
        and a1.sub_no   = '00'
        and rownum = 1

        UNION ALL

        select
            '7' stt, a9.m_7 otp, '14' stt, a9.m_14 otp, '21' stt, a9.m_21 otp, '28' stt, a9.m_28 otp, '35' stt, a9.m_35 otp
        from aaa01m00 a1
        inner join aaa99m01 a9
        on a1.iss_no = a9.iss_no
        where
            a1.acnt_no  = i_acnt_no
        and a1.sub_no   = '00'
        and rownum = 1
        ;
    pkg_extr_pdf.refcursor2pdf( t_rc , t_dir, t_file_nm);
end;
/

