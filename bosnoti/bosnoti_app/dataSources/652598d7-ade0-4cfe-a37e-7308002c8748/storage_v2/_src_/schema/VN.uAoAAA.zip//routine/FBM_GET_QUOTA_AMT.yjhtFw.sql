create function fbm_get_quota_amt(
    i_quota_tp          varchar2,
    i_dept_posi_cd      varchar2,
    i_dt                varchar2
)
return number
as  
    t_proc_nm   varchar2(30)    := 'fbm_get_quota_amt';
    t_err_msg   varchar2(1000)  := '';
    o_quota     number;
begin

    begin
        select quota
        into o_quota
        from rms02m00
        where quota_tp = i_quota_tp
        and dept_posi_cd = i_dept_posi_cd
        and apy_dt = (select max(apy_dt)
                        from rms02m00
                        where quota_tp = i_quota_tp
                        and dept_posi_cd = i_dept_posi_cd
                        and apy_dt <= i_dt
                        );
    exception
        when no_data_found then
            o_quota := 0;

        when others then
            t_err_msg   := 'Error when getting quota amount for: '
                        || ' dept_posi_cd: '    || i_dept_posi_cd
                        || ' date: '            || i_dt
                        || ' sqlcode= '         || sqlcode
                        || ' sqlerrm= '         || sqlerrm;

            vn.pxc_log_write(t_proc_nm, t_err_msg);
            raise_application_error(-20100, t_err_msg);
    end;

    return o_quota;
end;
/

