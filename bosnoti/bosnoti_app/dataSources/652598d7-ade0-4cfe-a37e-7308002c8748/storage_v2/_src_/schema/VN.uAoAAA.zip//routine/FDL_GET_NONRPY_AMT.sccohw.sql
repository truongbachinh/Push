create function fdl_get_nonrpy_amt
(
    i_lnd_tp          in       varchar2,
    i_acnt_no         in       varchar2,
    i_sub_no          in       varchar2,
    i_bank_cd         in       varchar2
)   return  number as

    t_err_txt           varchar2(80)  ; -- error text buffer
    t_vwdate            varchar2(8)   ;
    t_nonrpy_loan_amt   number := 0   ;

begin

/*============================================================================*/
/* Valiabl Initialize                                                         */
/*============================================================================*/
    t_nonrpy_loan_amt  :=  0;

/*============================================================================*/
/* Get today's work date                                                      */
/*============================================================================*/
    t_vwdate := vn.vwdate;

/*============================================================================*/
/* generl commission return                                                   */
/*============================================================================*/
    if  i_lnd_tp   =  '10'  then
        for c3 in (
            select  nvl(lnd_amt,0) - nvl(lnd_rpy_amt,0)  lnd_rm_amt
              from  vn.dlm01m00
             where  lnd_tp          =  i_lnd_tp
               and  acnt_no      like  i_acnt_no
               and  sub_no       like  i_sub_no
               and  lnd_bank_cd  like  decode(i_bank_cd,'9999','%',i_bank_cd)
               and  expr_dt         =  t_vwdate
               and  nvl(lnd_amt,0)  >  nvl(lnd_rpy_amt,0)
               and  lnd_acpt_tp     =  '01'
        ) loop
            t_nonrpy_loan_amt  := t_nonrpy_loan_amt + c3.lnd_rm_amt;
        end loop;
    else
        if  i_bank_cd  =  '9999'  then
            for c1 in (
                select  nvl(lnd_amt,0) - nvl(lnd_rpy_amt,0)  lnd_rm_amt
                  from  vn.dlm01m00
                 where  lnd_tp       like  i_lnd_tp
                   and  lnd_tp         <>  '10'
                   and  acnt_no         =  i_acnt_no
                   and  sub_no          =  i_sub_no
                   and  lnd_bank_cd  like  decode(i_bank_cd,'9999','%',i_bank_cd)
                   and  expr_dt         <  t_vwdate
                   and  lnd_acpt_tp     =  '01'
                   and  td_sell_mth_qty  + pd_sell_mth_qty
                     +  ppd_sell_mth_qty + pppd_sell_mth_qty <= 0
            ) loop
                t_nonrpy_loan_amt  := t_nonrpy_loan_amt + c1.lnd_rm_amt;
            end loop;
        else
            for c2 in (
                select  nvl(lnd_amt,0) - nvl(lnd_rpy_amt,0)  lnd_rm_amt
                  from  vn.dlm01m00
                 where  lnd_tp       like  i_lnd_tp
                   and  lnd_tp         <>  '10'
                   and  acnt_no         =  i_acnt_no
                   and  sub_no          =  i_sub_no
                   and  lnd_bank_cd  like  decode(i_bank_cd,'9999','%',i_bank_cd)
                   and  lnd_bank_cd    in (select  lnd_bank_cd
 	                                         from  vn.dlm12m00
	                                        where  setl_bank_cd =  i_bank_cd
                                              and  (lnd_bank_cd, apy_dt) in  (select  lnd_bank_cd, max(apy_dt)
	                                                                            from  vn.dlm12m00
                                	                                           where  setl_bank_cd =  i_bank_cd
	                                                                             and  apy_dt      <=  t_vwdate
	                                                                           group  by lnd_bank_cd)
                                           )
                   and  expr_dt         <  t_vwdate
                   and  lnd_acpt_tp     =  '01'
                   and  td_sell_mth_qty  + pd_sell_mth_qty
                     +  ppd_sell_mth_qty + pppd_sell_mth_qty <= 0
            ) loop
                t_nonrpy_loan_amt  := t_nonrpy_loan_amt + c2.lnd_rm_amt;
            end loop;
        end if;
    end if;

    return t_nonrpy_loan_amt;

end fdl_get_nonrpy_amt;
/

