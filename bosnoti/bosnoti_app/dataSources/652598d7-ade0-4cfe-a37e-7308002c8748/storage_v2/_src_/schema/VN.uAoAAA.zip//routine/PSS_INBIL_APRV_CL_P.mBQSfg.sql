create PROCEDURE pss_inbil_aprv_cl_p
(
 is_proc_dt			in	varchar2,
 is_acnt_no			in	varchar2,
 is_sub_no			in	varchar2,
 is_seq_no			in	varchar2,
 is_work_mn			in	varchar2,
 is_work_trm		in	varchar2,
 is_work_bnh		in	varchar2,
 is_dept_no2		in	varchar2,
 os_end_yn			out	varchar2,
 os_err_msg			out	varchar2

 ) AS

 tn_trd_seq_no		number	:= 0;
 tn_tot_trd_seq_no	number	:= 0;
 tn_cncl_trd_no		number	:= 0;
 tn_sb_pri			number	:= 0;
 tn_qty				number	:= 0;
 tn_sb_lmt_qty		number	:= 0;
 tn_mov_lmy_qty		number	:= 0;
 tn_cnt				number	:= 0;

 tn_own_qty   number  := 0;

 tot_cnt			number	:= 0;
 td_loop_cnt		number	:= 0;

 ts_inq_dt			varchar2(8)	 := '';
 ts_wdate			varchar2(8)	 := '';
 ts_stk_cd			varchar2(12) := '';
 ts_mth_dt			varchar2(8)	 := '';
 ts_stk_tp			varchar2(2)	 := '';
 ts_step			varchar2(10) := '';
 ts_std_inq_dt     	varchar2(8)  := '';    --approving date
 ts_date			varchar2(8)	 := '';
 ts_rgt_chk			varchar2(2)	 := null;

/* apply date from VSD 20100723 by jung */
 ts_apy_dt          varchar2(8)  := null;

 o_cnt       		number	:= 0;

 t_rtn_val          varchar2(1)   := null ;
 t_err_txt          varchar2(200) := null ;
 t_err_msg          varchar2(200) := null ;

 ts_own_chk      varchar2(1)  := null  ;
 ts_sb_chk       varchar2(1)  := null  ;
 t_mov_chk       varchar2(1)  := null  ;

  /* LTHN-248 */
  tn_rgt_tax_qty       number := 0;
  tn_apy_dt            varchar2(8);
  tn_rmrk_cd           varchar2(3);
  tn_tax_qty           number := 0;
  tn_tax_sb_lim_qty    number := 0;
  tn_tax_delay_qty     number := 0;
  tn_tax_delay_sb_qty  number := 0;
  tn_min_proc_dt       number := 0;
  tn_max_proc_dt       number := 0;
  tn_max_id            number := 0;

 ERR_RTN				EXCEPTION;

 BEGIN

 os_end_yn  := '';
 os_err_msg := '';

 -- work_date
 ts_step := '1';
 SELECT	VN.VWDATE()
 INTO   ts_wdate
 FROM DUAL;

 vn.pxc_log_write('pss_inbil_aprv_cl_p','acnt_no '||is_acnt_no ||is_sub_no||' is_proc_dt '|| is_proc_dt ||' seq_no '||is_seq_no);

 /*** check closing ***/

 t_rtn_val := 'Y';

 if is_work_mn  not in ('DAILY','BATCH') then

        vn.pbm_cls_yn_q(  vn.vwdate
                       ,  vn.fbm_emp_bnh_q(    is_work_mn)
                       ,  vn.faa_acnt_bnh_cd_g('0',is_acnt_no, is_sub_no)
                       , '1'
                       ,  t_rtn_val
                       ,  t_err_txt
                       );

        if  t_rtn_val  !=  'N' then
            t_err_msg := vn.fxc_get_err_msg('V','2716');
            raise_application_error(-20100,t_err_msg||t_err_txt);
        end if;

 end if;

 -- ssb05m00
 ts_step := '2';

 SELECT	 inq_dt
        ,trd_seq_no
        ,stk_cd
        ,qty
        ,sb_lmt_qty
        ,mov_lmy_qty
		,std_inq_dt
		,nvl(Trim(apy_dt) ,'!')
        ,nvl(rgt_tax_qty, 0)
        ,rmrk_cd
 INTO   ts_inq_dt
       ,tn_trd_seq_no
       ,ts_stk_cd
       ,tn_qty
       ,tn_sb_lmt_qty
       ,tn_mov_lmy_qty
       ,ts_std_inq_dt
	   ,ts_apy_dt
       ,tn_rgt_tax_qty
       ,tn_rmrk_cd
 FROM	VN.SSB05M00
 WHERE	PROC_DT = is_proc_dt
 AND	ACNT_NO = is_acnt_no
 AND    SUB_NO  = is_sub_no
 AND	SEQ_NO = to_number(is_seq_no);

 /*check change rights */
  select  vn.fsr_chage_rgt_p( ts_stk_cd , ts_wdate)
    into  ts_rgt_chk
    from dual;

  if  ts_rgt_chk = 'Y' then
      os_end_yn := 'N';
	  os_err_msg := '2029';
	  RAISE  ERR_RTN;
  end if ;

 pxc_log_write('pss_inbil_aprv_cl_p','select ssb05m00 inq_dt :' || ts_inq_dt);
 pxc_log_write('pss_inbil_aprv_cl_p','tn_qty :' || tn_qty);

 IF	 ts_wdate <> ts_inq_dt	THEN
     os_end_yn := 'N';
     os_err_msg := '2030';
     RAISE ERR_RTN;
 END IF;

 /* apply date is default inq_dt 20100723 by jung */
 pxc_log_write('pss_inbil_aprv_cl_p','apply date ['|| ts_apy_dt || ']');

 if ts_apy_dt = '!' then
    ts_apy_dt := ts_wdate ; -- same ts_inq_dt
 end if ;

 /** Get Trd_Seq_no **/

 ts_step := '3';
 pxc_log_write('pss_inbil_aprv_cl_p',ts_wdate ||' , '|| ts_std_inq_dt);

 if  ts_wdate =  ts_std_inq_dt then      /* confirm date is today  */
      pxc_psb_seq_cret_p (is_acnt_no, is_sub_no, ts_wdate, tn_cncl_trd_no, tn_tot_trd_seq_no);
 else

    begin
	   select nvl(max(trd_seq_no),0)
	     into tn_cncl_trd_no
	     from vn.aaa10m00
	    where acnt_no = is_acnt_no
		  and sub_no  = is_sub_no
	      and trd_dt  = ts_std_inq_dt ;
       exception
	     when NO_DATA_FOUND then
	          tn_cncl_trd_no := 0;
    end;

	tn_cncl_trd_no := tn_cncl_trd_no + 1 ;

 end if ;

 pxc_log_write('pss_inbil_aprv_cl_p','tn_cncl_trd_no : '|| tn_cncl_trd_no);

 /** Get Unit Price **/

 ts_step := '4';

 SELECT	 stk_tp
        ,sb_pri
        ,mth_dt
 INTO   ts_stk_tp
       ,tn_sb_pri
       ,ts_mth_dt
 FROM 	VN.AAA10M00
 WHERE	acnt_no = is_acnt_no
 AND    sub_no  = is_sub_no
 AND	trd_dt = ts_std_inq_dt
 AND	cnfm_dt = ts_wdate
 AND	trd_seq_no = tn_trd_seq_no;

 ts_step := '5';

 UPDATE vn.aaa10m00
 SET    cncl_yn = 'Y'
       ,work_bnh = is_work_bnh
       ,work_mn = is_work_mn
       ,work_dtm = sysdate
       ,work_trm = is_work_trm
 WHERE  acnt_no = is_acnt_no
 AND    sub_no  = is_sub_no
 AND    trd_dt = ts_std_inq_dt
 AND    trd_seq_no = tn_trd_seq_no
 and    stk_cd= ts_stk_cd ;

 ts_step := '6';

 pxc_log_write('pss_inbil_aprv_cl_p','tn_trd_seq_no : '|| tn_trd_seq_no);

 IF vn.fss_get_able_qty( is_acnt_no , is_sub_no,  ts_stk_cd )  <  (tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty )   THEN
      os_end_yn := 'N';
      os_err_msg := '2205';
      RAISE ERR_RTN;
 END IF;

 pxc_log_write('pss_inbil_aprv_cl_p','check : '|| tn_qty);

 INSERT INTO vn.aaa10m00 (  acnt_no            --
						   ,sub_no
                           ,trd_dt             --
                           ,tot_trd_seq_no         --
                           ,trd_seq_no         --
                           ,trd_tp             --
                           ,rmrk_cd            --
                           ,mdm_tp             --
                           ,trd_mdm_tp         --
                           ,cncl_yn            --
                           ,org_trd_no         --
                           ,trd_amt            --
                           ,cmsn               --
                           ,adj_amt            --
                           ,dpo_prerm          --
                           ,dpo_nowrm          --
                           ,stk_cd             --
                           ,stk_nm             --
                           ,sb_pri             --
                           ,sb_qty             --
                           ,bil_prerm_qty      --
                           ,bil_nowrm_qty      --
                           ,tot_bil_prerm      --
                           ,tot_bil_nowrm      --
                           ,book_amt           --
                           ,stk_tp             --
                           ,mth_dt             --
                           ,lnd_tp
                           ,lnd_dt
                           ,lnd_int
                           ,agnt_yn            --
                           ,acnt_mng_bnh       --
                           ,work_bnh           --
                           ,work_mn            --
                           ,work_dtm           --
                           ,work_trm           --
                           ,agnc_brch
                           ,proc_agnc_brch
                           ,cnfm_dt

    ) (           SELECT     acnt_no                    -- acnt_no
							,sub_no
                            ,trd_dt                     -- trd_dt
                            ,tn_tot_trd_seq_no                     -- trd_dt
                            ,tn_cncl_trd_no         -- trd_seq_no(cancellation)
                            ,trd_tp                         -- trd_tp
                            ,decode(rmrk_cd, '201', '212', '202', '213', '203', '214', '211', '215', '216', '217')      -- rmrk_cd
                            ,mdm_tp                     -- mdm_tp
                            ,trd_mdm_tp                 -- trd_mdm_tp
                            ,'N'                            -- cncl_yn
                            ,trd_seq_no                 -- org_trd_no
                            ,0                          -- trd_amt
                            ,0                          -- cmsn
                            ,0                          -- adj_amt
                            ,0                          -- dpo_prerm            --> ?
                            ,0                          -- dpo_nowrm        --> ?
                            ,stk_cd                     -- stk_cd
                            ,stk_nm                     -- stk_nm
                            ,sb_pri                     -- sb_pri
                            ,sb_qty                     -- sb_qty
                            ,bil_nowrm_qty              -- bil_prerm_qty
                            ,bil_nowrm_qty - sb_qty     -- bil_nowrm_qty
							,tot_bil_nowrm
							,tot_bil_nowrm - sb_qty
                            ,book_amt                   -- book_amt
                            ,stk_tp                     -- stk_tp
                            ,null                       -- mth_dt
                            ,null
                            ,null
                            ,0
                            ,'N'                            -- agnt_yn
                            ,acnt_mng_bnh               -- acnt_mng_bnh
                            ,is_work_bnh                    -- work_bnh
                            ,is_work_mn                 -- work_mn
                            ,sysdate                        -- work_dtm
                            ,is_work_trm                    -- work_trm
                            ,agnc_brch
                            ,is_dept_no2
							,cnfm_dt
                   FROM   vn.aaa10m00
                   WHERE  acnt_no    = is_acnt_no
				   AND    sub_no     = is_sub_no
                   AND    trd_dt     = ts_std_inq_dt
                   AND    trd_seq_no = tn_trd_seq_no);

 pxc_log_write('pss_inbil_aprv_cl_p','check1 : '|| tn_qty);

  /* update aaa10m00  and ssb01h00 */

  if ts_std_inq_dt <> ts_wdate then

 	  select to_date(ts_wdate, 'yyyymmdd') - to_date(ts_std_inq_dt, 'yyyymmdd')
 	    into tot_cnt
 	    from dual;

 	  for c1 in 0..tot_cnt loop

		 select to_char((to_date(ts_std_inq_dt,'yyyymmdd') + td_loop_cnt),'yyyymmdd')
	       into ts_date
	       from dual;

	  if vn.fxc_holi_ck(to_date(ts_date,'yyyymmdd')) =  '0' then

        if ts_date >  ts_std_inq_dt then   /* excepts trd_dt */

          BEGIN
             update vn.aaa10m00
	    		set bil_prerm_qty = bil_prerm_qty - (tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty)
			 	   ,bil_nowrm_qty = bil_nowrm_qty - (tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty)
			 	   ,tot_bil_prerm = tot_bil_prerm - (tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty)
			 	   ,tot_bil_nowrm = tot_bil_nowrm - (tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty)
	  	      where acnt_no = is_acnt_no
				and sub_no  = is_sub_no
	            and stk_cd = ts_stk_cd
		        and trd_dt = ts_date;
	       exception
			    when OTHERS then
				     raise_application_error(-20100,'error' );
		  END;

        end if ;

        if  ts_date < ts_wdate then   /* excepts today  */

             BEGIN
                update vn.ssb01h00
                    set  own_qty = own_qty - (tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty)
                        ,sb_lim_qty = sb_lim_qty - tn_sb_lmt_qty
                        ,mov_lim_qty = mov_lim_qty - tn_mov_lmy_qty
                        ,book_amt = book_amt - ((tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty) * tn_sb_pri)
                        ,work_mn = is_work_mn
                        ,work_dtm = sysdate
                        ,work_trm = is_work_trm
			      where rgt_std_dt = ts_date
			        and acnt_no = is_acnt_no
					and sub_no  = is_sub_no
			        and stk_cd = ts_stk_cd;

             exception
                  when OTHERS then
                      raise_application_error(-20100,'error' );
             END ;

        end if ;

	   end if ;

	   td_loop_cnt := td_loop_cnt + 1 ;

	  end loop;

  end if ;

 pxc_log_write('pss_inbil_aprv_cl_p','check2 : '|| tn_qty);

 UPDATE	vn.ssb01m00
 SET	own_qty     = own_qty - (tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty)
       ,sb_lim_qty  = sb_lim_qty - tn_sb_lmt_qty
       ,mov_lim_qty = mov_lim_qty - tn_mov_lmy_qty
       ,book_amt    = decode(own_qty - (tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty) , 0 , 0
                        , book_amt - ((tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty) * tn_sb_pri) )
       ,delay_qty     = Decode( Sign ( ts_apy_dt - ts_wdate ) , 1  , delay_qty     - tn_qty          , delay_qty       )
       ,delay_sb_qty  = Decode( Sign ( ts_apy_dt - ts_wdate ) , 1  , delay_sb_qty  - tn_sb_lmt_qty   , delay_sb_qty    )
       ,delay_mov_qty = Decode( Sign ( ts_apy_dt - ts_wdate ) , 1  , delay_mov_qty - tn_mov_lmy_qty  , delay_mov_qty   )
       ,work_mn     = is_work_mn
       ,work_dtm    = sysdate
       ,work_trm    = is_work_trm
 WHERE	acnt_no     = is_acnt_no
 AND    sub_no      = is_sub_no
 AND	stk_cd      = ts_stk_cd;

 --
 pxc_log_write('pss_inbil_aprv_cl_p','check3 : '|| tn_qty);

 UPDATE   VN.SSB05M00
 SET      inq_dt = NULL
          ,std_inq_dt = NULL
          ,cncl_trd_no = tn_cncl_trd_no
          ,end_yn = 'N'
          ,err_msg = NULL
          ,work_mn = is_work_mn
          ,work_dtm = sysdate
          ,work_trm = is_work_trm
  WHERE	proc_dt = is_proc_dt
  AND	acnt_no = is_acnt_no
  AND   sub_no  = is_sub_no
  AND	seq_no = to_number(is_seq_no);

 /* out parametres */
 pxc_log_write('pss_inbil_aprv_cl_p','check4 : '|| tn_qty);

 os_end_yn	:= 'N';					--
 os_err_msg	:= 'OK';				--

  /* LTHN-248 */
  if tn_rgt_tax_qty > 0 then
    vn.pxc_log_write('pss_inbil_aprv_cl_p', 'detect type of tax quantity');
    vn.pxc_log_write('pss_inbil_aprv_cl_p', 'ts_apy_dt:' || ts_apy_dt);
    vn.pxc_log_write('pss_inbil_aprv_cl_p', 'tn_qty:' || tn_qty);
    vn.pxc_log_write('pss_inbil_aprv_cl_p', 'tn_sb_lmt_qty:' || tn_sb_lmt_qty);
    vn.pxc_log_write('pss_inbil_aprv_cl_p', 'ts_std_inq_dt:' || ts_std_inq_dt);
    vn.pxc_log_write('pss_inbil_aprv_cl_p', 'is_acnt_no:' || is_acnt_no);
    vn.pxc_log_write('pss_inbil_aprv_cl_p', 'ts_stk_cd:' || ts_stk_cd);
    vn.pxc_log_write('pss_inbil_aprv_cl_p', 'tn_rgt_tax_qty:' || to_char(tn_rgt_tax_qty));

    if ts_apy_dt > vwdate and tn_qty > 0 then -- cho tdcn
      tn_tax_delay_qty := tn_rgt_tax_qty;
    end if;
    if (ts_apy_dt = '00000000' or ts_apy_dt <= vwdate) and tn_qty > 0 then -- tdcn
      tn_tax_qty := tn_rgt_tax_qty;
    end if;

    if ts_apy_dt > vwdate and tn_sb_lmt_qty > 0 then -- cho hccn
      tn_tax_delay_sb_qty := tn_rgt_tax_qty;
    end if;
    if (ts_apy_dt = '00000000' or ts_apy_dt <= vwdate) and tn_sb_lmt_qty > 0 then -- hccn
      tn_tax_sb_lim_qty := tn_rgt_tax_qty;
    end if;
    vn.pxc_log_write('pss_inbil_aprv_cl_p', 'update ssb05m10');
    vn.pxc_log_write('pss_inbil_aprv_cl_p', 'tn_tax_qty: ' || tn_tax_qty);
    vn.pxc_log_write('pss_inbil_aprv_cl_p', 'tn_tax_delay_qty: ' || tn_tax_delay_qty);
    vn.pxc_log_write('pss_inbil_aprv_cl_p', 'tn_tax_sb_lim_qty: ' || tn_tax_sb_lim_qty);
    vn.pxc_log_write('pss_inbil_aprv_cl_p', 'tn_tax_delay_sb_qty: ' || tn_tax_delay_sb_qty);

    update ssb05m10
    set tax_qty = tax_qty - tn_tax_qty,
        tax_sb_lim_qty = tax_sb_lim_qty - tn_tax_sb_lim_qty,
        tax_delay_qty = tax_delay_qty - tn_tax_delay_qty,
        tax_delay_sb_qty = tax_delay_sb_qty - tn_tax_delay_sb_qty,
        work_mn = is_work_mn,
        work_dtm = sysdate,
        work_trm = is_work_trm
    where acnt_no = is_acnt_no
    and stk_cd = ts_stk_cd;

    /* Xu ly cho ssb05h10 */
    /* Do logic cu xu ly khi apy_dt = vwdate thi se thuc hien xu ly nhu la apy_dt = inq_dt */
    if ts_apy_dt = vwdate then
      tn_apy_dt := ts_std_inq_dt;
    elsif ts_apy_dt > vwdate then
      tn_apy_dt := ts_apy_dt;
    end if;

    for c1 in (select max(id) as id_max, proc_dt, acnt_no, stk_cd
                 from ssb05h10
                where proc_dt >= ts_std_inq_dt
                  and acnt_no = is_acnt_no
                  and stk_cd = ts_stk_cd
                group by proc_dt, acnt_no, stk_cd)
    loop
      vn.pxc_log_write('pss_inbil_aprv_cl_p', 'c1.proc_dt: ' || c1.proc_dt || ', ' ||'c1.acnt_no: ' || c1.acnt_no || ', ' || 'c1.stk_cd: ' || c1.stk_cd);
      insert into ssb05h10
            ( id,
              proc_dt,
              acnt_no,
              stk_cd,
              tax_qty,
              tax_sb_lim_qty,
              tax_delay_qty,
              tax_delay_sb_qty,
              wtax_qty,
              wtax_sb_lim_qty,
              wtax_delay_qty,
              wtax_delay_sb_qty,
              cnte,
              create_mn,
              create_dtm,
              create_trm,
              work_mn,
              work_dtm,
              work_trm,
              backup_mn,
              backup_dtm,
              backup_trm)
            select ssb05h10_seq.nextval,
                  c1.proc_dt,
                  acnt_no,
                  stk_cd,
                  tax_qty - tn_tax_qty,
                  tax_sb_lim_qty - tn_tax_sb_lim_qty,
                  tax_delay_qty - tn_tax_delay_qty,
                  tax_delay_sb_qty - tn_tax_delay_sb_qty,
                  wtax_qty,
                  wtax_sb_lim_qty,
                  wtax_delay_qty,
                  wtax_delay_sb_qty,
                  'Huy duỵet backdate ' || fbm_rmrk_nm_q(tn_rmrk_cd),
                  create_mn,
                  create_dtm,
                  create_trm,
                  work_mn,
                  work_dtm,
                  work_trm,
                  is_work_mn,
                  sysdate,
                  is_work_trm
              from ssb05h10
            where acnt_no = c1.acnt_no
              and stk_cd = c1.stk_cd
              and proc_dt = c1.proc_dt
              and id = c1.id_max;
    end loop;
    /* Backup du lieu tu bang ssb05m10 */
    vn.pss_rgt_tax_history
      ( is_acnt_no,     -- i_acnt_no   ,
        ts_stk_cd,      -- i_stk_cd    ,
        '',        -- i_proc_dt   ,
        fbm_rmrk_nm_q(tn_rmrk_cd),           -- i_cnte      ,
        is_work_mn   ,
        is_work_trm
      );
  end if;
  /* End LTHN-248 */

 /*******************************/
 /* call evaluation for margin  */
 /*******************************/
/*huedt add k danh gia tai san*/
 /* vn.pdl_crd_loan_rt_proc_td
        (ts_wdate
        ,'2' -- stock
        ,is_acnt_no
		,is_sub_no
        ,tn_cncl_trd_no
        ,is_work_mn
        ,is_work_trm
        ,o_cnt
       );

  vn.pxc_log_write('pss_inbil_aprv_cl_p','pdl_crd_loan_rt_proc_td ['|| o_cnt ||']');*/

 /* right proc */

 vn.psr_rgt_std_past_proc(
						ts_std_inq_dt,
						ts_stk_cd,
						is_acnt_no,
						is_sub_no,
						tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty,
						'2',
						is_work_mn,
						is_work_trm
						);


 RETURN;

 EXCEPTION
 WHEN 	ERR_RTN	THEN
     raise_application_error(-20100, os_err_msg || ':[pss_inbil_aprv_cl_p ' || ts_step || '] ' || os_err_msg);
   RETURN;

 WHEN	NO_DATA_FOUND	THEN
    raise_application_error(-20200, '[pss_inbil_aprv_cl_p ' || ts_step || '] ' || SQLERRM);
    RETURN;

  WHEN	OTHERS	THEN
    raise_application_error(-20300, '[pss_inbil_aprv_cl_p ' || ts_step || '] ' || SQLERRM);
    RETURN;


 END pss_inbil_aprv_cl_p;
/

