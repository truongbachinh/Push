create procedure pxc_fee_sms(i_sec_cd  in varchar2,
                                        i_acnt_no in varchar2,
                                        i_sub_no  in varchar2,
                                        t_out     out number) is

  t_err     NUMBER := 0;
  t_err_txt varchar2(500);

  t_active      varchar2(8);
  t_succ        NUMBER := 0;
  t_today       varchar2(8);
  ts_acnt_cnt   NUMBER := 0;
  ts_acnt_cnt_1 NUMBER := 0;
  t_sms_grp_cd  varchar2(8);
  t_mobile      varchar2(15);
  t_status      varchar2(8);
  t_batch       varchar2(8);

begin

  vn.Pxc_Log_Write('pxc_fee_sms',
                   '=======START pxc_fee_sms at: ' ||
                   TO_CHAR(SYSDATE, 'dd/mm/yyyy hh24:mi:ss') ||
                   '==========');
  vn.Pxc_Log_Write('pxc_fee_sms', 'NHSV: ' || i_sec_cd || ' Start loop ');

  SELECT to_char(vn.fxc_exprdt_g(trunc(to_date(vn.vwdate, 'yyyymmdd'),'MONTH')),'yyyymmdd'), -- ngay lam viec dau tien cua thang
         -- to_char(trunc(vn.fxc_exprdt_g1(to_date(to_char(last_day(to_date(vn.vwdate,'yyyymmdd')),'yyyymmdd'), 'yyyymmdd')),'MM') +0,'yyyymmdd'),
         --to_char(vn.fxc_exprdt_g1(to_date(to_char(last_day(to_date(vn.vwdate,'yyyymmdd')),'yyyymmdd'), 'yyyymmdd')),'yyyymmdd'),
        -- to_char(sysdate, 'yyyymmdd'),
         to_char(sysdate, 'yyyymmdd')
    into t_active, t_today
    from dual;

  if t_active = t_today then
    -- return;
    --if t_today = t_today then
    /*kiem tra du lieu batch moi thang chi chay 1 lan vao buoi chieu*/
    begin
      select pgm_id
        into t_batch
        from vn.xbd01m00
       where pgm_nm = 'pxc_fee_sms.sql'
             and pgm_id = '3410';
         --and work_stat = '2';
    
    exception
      when others then
        vn.pxc_log_write('pxc_fee_sms', 'sai batch-' || t_err);
        return;
      
    end;
    if t_batch = '3410' then
      -- hang thang thi phai lay het tat ca tk
      --update lai so tien trang thai chua thu,so tien da thu = 0
      update vn.xca01m07
         set fee_obtained = '0', fee_yn = 'N'
       where sms_grp_cd NOT IN ('00', '01');
    
      commit;
    
      for c1 in (SELECT a.acnt_no acnt_no,
                        a.sms_grp_cd sms_grp_cd,
                        '84' || substr(a.mobile, 2, 12) mobile,
                        a.status
                   FROM vn.xca01m07 a, vn.aaa01m00 b
                  WHERE a.acnt_no = b.acnt_no
                    and a.acnt_no like i_acnt_no
                    AND b.sub_no = '00'
                    AND a.mobile is not null
                    and b.acnt_stat = '1'
                    AND b.bank_cnt_yn <> 'Y'
                    and a.fee_yn = 'N'
                    and a.fee_status_yn = 'N'
                       -- AND to_char(a.work_dtm,'yyyymmdd') <> t_active
                    AND a.sms_grp_cd NOT IN ('00', '01')
                 --and a.acnt_no in ('069C001976','069C002950','069C071977')---thu test 3 TK
                  order by a.acnt_no
                 
                 ) loop
      
        begin
          /* pro month */
        
          vn.pxc_sms_fee_out(i_sec_cd,
                             c1.acnt_no,
                             c1.sms_grp_cd,
                             c1.mobile,
                             c1.status,
                             'BATCH',
                             'BOS',
                             t_succ);
        
        exception
          when others then
            RAISE_APPLICATION_ERROR(-20100, SQLERRM);
            t_err_txt := 'sms type err-' || c1.acnt_no || '-' ||
                         to_char(sqlcode);
            vn.pxc_log_write('pxc_fee_sms', 't_err-' || t_err);
          
        end;
      
        ts_acnt_cnt := ts_acnt_cnt + 1;
        Pxc_Log_Write('pxc_fee_sms',
                      'Tong so TK thu phi :' || ts_acnt_cnt ||
                      '...ACNT_NO:' || c1.acnt_no);
        if t_succ = 2 then
          t_err := t_err + 1;
        end if;
      
      end loop;
    
    else
      return;
    
    end if;
  
  else
    -- hang ngay chi lay nhung TK con no tien phi
    for c2 in (select distinct (acnt_no) --851
                 from vn.xca01m10
                where fee_yn = 'N'
                order by acnt_no) loop
      begin
        select a.sms_grp_cd,
               '84' || substr(a.mobile, 2, 12) mobile,
               a.status
          into t_sms_grp_cd, t_mobile, t_status
          from vn.xca01m07 a
         where a.acnt_no = c2.acnt_no
           and a.sms_grp_cd NOT IN ('00', '01')
           and rownum = 1;
      
      exception
        when others then
          Pxc_Log_Write('pxc_fee_sms',
                        'Khong co thong tin nhom thu phi :' ||
                        '...ACNT_NO:' || c2.acnt_no);
        
      end;
    
      begin
        vn.pxc_sms_fee_out_1(i_sec_cd,
                             c2.acnt_no,
                             t_sms_grp_cd,
                             t_mobile,
                             t_status,
                             'BATCH',
                             'BOS',
                             t_succ);
      exception
        when others then
          RAISE_APPLICATION_ERROR(-20100, SQLERRM);
          t_err_txt := 'sms type err-' || c2.acnt_no || '-' ||
                       to_char(sqlcode);
          vn.pxc_log_write('pxc_fee_sms',
                           't_err-' || t_err || ' ' || SQLERRM);
        
      end;
    
      /**/
    
      ts_acnt_cnt := ts_acnt_cnt + 1;
      Pxc_Log_Write('pxc_fee_sms',
                    'Tong so TK thu phi :' || ts_acnt_cnt || '...ACNT_NO:' ||
                    c2.acnt_no);
      if t_succ = 2 then
        t_err := t_err + 1;
      end if;
    
    end loop;
  
  end if;

  vn.Pxc_Log_Write('pxc_fee_sms',
                   '======================================================');
  vn.Pxc_Log_Write('pxc_fee_sms',
                   '================== KHONG THU DUOC SENT  : ' ||
                   TO_CHAR(t_err));
  vn.Pxc_Log_Write('pxc_fee_sms',
                   '================== TOTAL SENT: ' ||
                   TO_CHAR(ts_acnt_cnt));
  vn.Pxc_Log_Write('pxc_fee_sms',
                   '======================================================');
  vn.Pxc_Log_Write('pxc_fee_sms',
                   '=======Finished total account at: ' ||
                   TO_CHAR(SYSDATE, 'dd/mm/yyyy hh24:mi:ss') ||
                   '==========');
  t_out := ts_acnt_cnt;

end pxc_fee_sms;
/

