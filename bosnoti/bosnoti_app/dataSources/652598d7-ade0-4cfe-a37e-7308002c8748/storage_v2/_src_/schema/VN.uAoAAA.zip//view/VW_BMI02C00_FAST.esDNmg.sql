create view VW_BMI02C00_FAST as
SELECT RMRK_CD
       ,RMRK_CD_NM
       ,USE_YN
       ,USE_END_DT
       ,CNTE
       ,WORK_MN
       ,WORK_DTM
       ,WORK_TRM
FROM VN.BMI02C00
/

