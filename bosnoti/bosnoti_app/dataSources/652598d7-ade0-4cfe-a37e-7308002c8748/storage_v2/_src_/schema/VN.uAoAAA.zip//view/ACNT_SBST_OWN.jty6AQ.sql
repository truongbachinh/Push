create view ACNT_SBST_OWN as
(
    SELECT
        ACNT_NO,
        SUB_NO,
        STK_CD,
        ASS_TP,
        SUM(ABLE_QTY)       ABLE_QTY,
        SUM(BUY_MTH_QTY)    BUY_MTH_QTY,
        SUM(BUY_NMTH_QTY)   BUY_NMTH_QTY,
        SUM(SELL_QTY)       SELL_QTY,
        SUM(CDR_AMT)        CDR_AMT
    FROM(
        SELECT
            A.ACNT_NO,
            A.SUB_NO,
            A.STK_CD,
            (NVL(SUM(OWN_QTY), 0) - 
            NVL(SUM(BCLM_QTY), 0) -
            NVL(SUM(MRTG_LND_QTY), 0) -
            NVL(SUM(MRTG_BUY_QTY), 0) -
            NVL(SUM(OUTQ_REQ_QTY), 0) -
            NVL(SUM(MOV_LIM_QTY), 0) -
            NVL(SUM(SB_LIM_QTY), 0) -
            NVL(SUM(DELAY_QTY), 0)) ABLE_QTY,
            0 BUY_MTH_QTY,
            0 BUY_NMTH_QTY,
            0 SELL_QTY,
            '02' ASS_TP,
            0   CDR_AMT
        FROM VN.SSB01M00 A
        WHERE OWN_QTY > 0
        GROUP BY A.ACNT_NO, A.SUB_NO, A.STK_CD
        
        UNION ALL
        
        --1.b so huu ch�? GD: ssb01m00
        SELECT 
            A.ACNT_NO,
            A.SUB_NO,
            STK_CD,
            GREATEST(SUM(NVL(DELAY_QTY, 0) -
                        NVL(DELAY_REG_QTY, 0)),
                    0) ABLE_QTY,
            0 BUY_MTH_QTY,
            0 BUY_NMTH_QTY,
            0 SELL_QTY,
            '04' ASS_TP,
            0   CDR_AMT
        FROM VN.SSB01M00 A
        WHERE A.DELAY_QTY > 0
        GROUP BY A.ACNT_NO, A.SUB_NO, A.STK_CD
        
        UNION ALL
        
        --2.  mua cho ve T1, T2; ban cho di T0, T1, T2 : TSO04m00
        SELECT 
            ACNT_NO,
            SUB_NO,
            STK_CD,
            ABLE_QTY,
            BUY_MTH_QTY,
            BUY_NMTH_QTY,
            SELL_QTY,
            ASS_TP,
            CDR_AMT
        FROM (
            SELECT 
                T.ACNT_NO,
                T.SUB_NO,
                T.STK_CD,
                0 ABLE_QTY,
                NVL(SUM(T.TD_BUY_MTH_QTY), 0) +
                NVL(SUM(T.PD_BUY_MTH_QTY), 0) +
                NVL(SUM(T.PPD_BUY_MTH_QTY), 0) +
                NVL(SUM(T.PPPD_BUY_MTH_QTY), 0) BUY_MTH_QTY,
                0   BUY_NMTH_QTY,
                NVL(SUM(T.TD_SELL_MTH_QTY), 0) +
                NVL(SUM(T.PD_SELL_MTH_QTY), 0) +
                NVL(SUM(T.PPD_SELL_MTH_QTY), 0) +
                NVL(SUM(T.PPPD_SELL_MTH_QTY), 0) SELL_QTY,
                '02' ASS_TP,
                0   CDR_AMT
            FROM VN.TSO04M00 T
            GROUP BY T.ACNT_NO, T.SUB_NO, T.STK_CD
        )
        WHERE BUY_MTH_QTY > 0
        OR SELL_QTY > 0

        UNION ALL

        --3. mua cho ve trong ngay: TSO01m00

        SELECT 
            T.ACNT_NO,
            T.SUB_NO,
            T.STK_CD,
            0 ABLE_QTY,
            0                        BUY_MTH_QTY, -- cuoi ngay 
            NVL(SUM(NMTH_QTY), 0)    BUY_NMTH_QTY, -- trong ngay
            0 SELL_QTY,
            '02' ASS_TP,
            0   CDR_AMT
        FROM VN.TSO01M00 T
        WHERE ACCP_TP <> 'X'
        AND DEL_YN = 'N'
        AND SELL_BUY_TP = '2'
        AND PROF_CLS_YN <> 'Y'
        AND NMTH_QTY > 0
        GROUP BY T.ACNT_NO, T.SUB_NO, T.STK_CD

        UNION ALL

        -- Quy�?n là ti�?n
        SELECT 
            A.ACNT_NO,
            A.SUB_NO,
            A.STK_CD,
            0 ABLE_QTY,
            0 BUY_MTH_QTY,
            0 BUY_NMTH_QTY,
            0 SELL_QTY,
            '08' ASS_TP,
            DECODE(A.RCPT_TRD_NO + A.flotq_trd_no + A.INTER_TRD_NO,
                0,
                NVL(A.ASN_AMT, 0) + NVL(A.FLOTQ_AMT, 0) +
                NVL(A.INTER_AMT, 0),
                0)  CDR_AMT
        FROM VN.SRR02M00 A, VN.SRR01M00 C
        WHERE A.RGT_TP IN ('3', '9')
        AND A.RGT_STD_DT = C.RGT_STD_DT
        AND A.RGT_TP = C.RGT_TP
        AND A.STK_CD = C.STK_CD
        AND A.SEQ_NO = C.SEQ_NO
        AND C.RGT_PROC_STAT >= '3'

        UNION ALL

        -- Quy�?n la CK
        SELECT 
            A.ACNT_NO,
            A.SUB_NO,
            A.STK_CD STK_CD,
            SUM(DECODE(A.RGT_TP,
                    '1',
                    DECODE(A.INQ_TRD_NO,
                            0,
                            NVL(A.CONS_SBST_QTY, 0),
                            0),
                    DECODE(A.INQ_TRD_NO,
                            0,
                            NVL(A.ASN_QTY, 0),
                            0))) ABLE_QTY,
            0 BUY_MTH_QTY,
            0 BUY_NMTH_QTY,
            0 SELL_QTY,
            '06' ASS_TP,
            0   CDR_AMT
        FROM VN.SRR02M00 A, VN.SRR01M00 C
        WHERE A.RGT_TP IN ('1', '2', '7', '3', '5')
        AND A.RGT_STD_DT = C.RGT_STD_DT
        AND A.RGT_TP = C.RGT_TP
        AND A.STK_CD = C.STK_CD
        AND A.SEQ_NO = C.SEQ_NO
        AND C.RGT_PROC_STAT >= '3'
        GROUP BY A.STK_CD, A.ACNT_NO, A.SUB_NO

        UNION ALL

        SELECT 
            A.ACNT_NO,
            A.SUB_NO,
            C.CNVT_STK_CD STK_CD,
            SUM(DECODE(A.INQ_TRD_NO, 0, NVL(A.ASN_QTY, 0), 0)) ABLE_QTY,
            0 BUY_MTH_QTY,
            0 BUY_NMTH_QTY,
            0 SELL_QTY,
            '06' ASS_TP,
            0   CDR_AMT
        FROM VN.SRR02M00 A, VN.SRR01M10 C
        WHERE A.RGT_TP = '8'
        AND A.STK_CD = C.STK_CD
        AND A.RGT_STD_DT = C.RGT_STD_DT
        AND A.STK_CD = C.STK_CD
        AND C.RGT_PROC_STAT >= '3'
        GROUP BY C.CNVT_STK_CD, A.ACNT_NO, A.SUB_NO
        )
    GROUP BY ACNT_NO, SUB_NO, STK_CD, ASS_TP
)
/

