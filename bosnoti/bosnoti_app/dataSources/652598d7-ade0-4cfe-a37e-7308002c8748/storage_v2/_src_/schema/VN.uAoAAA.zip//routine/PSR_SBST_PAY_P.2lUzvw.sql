create procedure    psr_sbst_pay_p
( i_proc_tp   in  varchar2,   -- c : cash  s : stock
  i_amount    in  number  ,
  i_stk_cd    in  varchar2,
  i_acnt_no   in  varchar2,   -- not use '%'
  i_sub_no    in  varchar2,
  i_work_mn   in  varchar2,
  i_work_trm  in  varchar2
 ) is

 tn_reuse_rt  number := 0 ;
 tn_rt_sbst_dpo  number := 0 ;
 t_err_msg    varchar2(200) ;

begin

 vn.pxc_log_write('psr_sbst_pay_p', '[ proc_tp : '||i_proc_tp||' acnt_no : ' || i_acnt_no || ' amount : ' || i_amount || ' ]'  );


 if i_proc_tp = 'c'  then   -- cash

	 tn_reuse_rt := vn.fsr_rgt_cash_rt_acnt(  i_stk_cd, i_acnt_no, i_sub_no);

	 pxc_log_write('psr_sbst_pay_p' , 'reuse_rt : ' || tn_reuse_rt ) ;

	 begin
         update vn.cwd01m00
			 set rgt_reuse = trunc( greatest ( rgt_reuse -  i_amount * tn_reuse_rt , 0   ))
           where acnt_no = i_acnt_no
			 and sub_no  = i_sub_no;
        exception
		  when others then
			  vn.pxc_log_write('psr_sbst_pay_p', i_acnt_no || ' :  deposit error ')  ;
			  t_err_msg := vn.fxc_get_err_msg('V','9006');
			  raise_application_error(-20100,t_err_msg);
        end  ;

		/* need to call recalculate oder block ( reuse )  */

 elsif i_proc_tp = 's'  then   --  import stock

       tn_rt_sbst_dpo :=  i_amount * vn.fss_get_pd_cls_pri( i_stk_cd) * vn.fsr_rgt_sbst_rt_acnt  (  i_stk_cd, i_acnt_no, i_sub_no)
						  * vn.fdl_get_mrgn_grp_acnt_rt( i_acnt_no, i_sub_no,vn.faa_acnt_get_grp_no (i_acnt_no, i_sub_no,'2', vn.vwdate),'02', vn.vwdate);

       begin
          update vn.cwd01m00
             set rgt_sbst = trunc ( greatest ( rgt_sbst -  tn_rt_sbst_dpo  , 0 ) )
           where acnt_no = i_acnt_no
			 and sub_no  = i_sub_no;
        exception
          when others then
              vn.pxc_log_write('psr_sbst_pay_p', i_acnt_no || ' :  imports error')  ;
              t_err_msg := vn.fxc_get_err_msg('V','9006');
              raise_application_error(-20100,t_err_msg);
        end  ;

 else

        vn.pxc_log_write('psr_sbst_pay_p', ' proc_tp error  ')  ;
        t_err_msg := vn.fxc_get_err_msg('V','9006');
        raise_application_error(-20100,t_err_msg);

 end if ;

end  psr_sbst_pay_p;
/

