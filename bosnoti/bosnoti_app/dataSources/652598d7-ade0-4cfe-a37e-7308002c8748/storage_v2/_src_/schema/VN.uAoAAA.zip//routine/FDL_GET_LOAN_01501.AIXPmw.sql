create function fdl_get_loan_01501
(
  i_acnt_no    in    varchar2,
  i_sub_no    in    varchar2,
  i_dt        in    varchar2,
  i_tp        in    varchar2
) return varchar2 as

  o_loan_mt  varchar2(100);
  t_sysdate VARCHAR2(20);

/* ===========================================
  -- Program ID     :   fdl_get_loan_01501
  -- Date of Program  :   11/06/2015
  -- Programmer    :  LVHiep
  -- Description     :
      input  :  Account,sub,dt
      return :  loan
   =========================================== */
BEGIN
  SELECT to_char(SYSDATE,'yyyymmdd') INTO t_sysdate  FROM dual ;
  IF i_tp = '1'THEN
    IF i_dt <> t_sysdate THEN
        BEGIN
            SELECT  mrgn_loan_nowrm
            INTO o_loan_mt
            FROM cwd99h00
            WHERE acnt_no = i_acnt_no
            AND sub_no = i_sub_no
            AND dt = i_dt ;
              RETURN o_loan_mt;
              exception
               when   no_data_found THEN
               RETURN   '0';
               END ;
           ELSE
             IF i_dt = t_sysdate THEN
                BEGIN
                 SELECT  mrgn_loan_nowrm
                 INTO o_loan_mt
                      FROM cwd99m00
                  WHERE acnt_no = i_acnt_no
                  AND sub_no = i_sub_no;
                  EXCEPTION
                   when   no_data_found THEN
                    RETURN '0';
                     END ;
                   END IF ;
                END IF;
              END IF;
     IF i_tp = '2' THEN
         IF i_dt <> t_sysdate THEN
          BEGIN
            SELECT  coll_loan_nowrm + buy_loan_nowrm sum1
            INTO o_loan_mt
            FROM cwd99h00
            WHERE acnt_no = i_acnt_no
            AND sub_no = i_sub_no
             AND dt = i_dt ;

             RETURN o_loan_mt;

           exception
          when   no_data_found THEN
          RETURN  '0';
           END ;
       ELSE
         IF i_dt = t_sysdate THEN
            BEGIN
            SELECT coll_loan_nowrm + buy_loan_nowrm sum1
            INTO o_loan_mt
            FROM cwd99m00
            WHERE acnt_no = i_acnt_no
           AND sub_no = i_sub_no ;

           RETURN o_loan_mt;
           exception
           when   no_data_found THEN
           RETURN '0';
            END ;
            END IF ;
           END IF ;
          END IF ;
     IF i_tp = '3' THEN
        IF i_dt <> t_sysdate THEN
         BEGIN
         SELECT  mony_loan_nowrm
           INTO o_loan_mt
        FROM cwd99h00
        WHERE acnt_no = i_acnt_no
        AND sub_no = i_sub_no
         AND dt = i_dt ;
          RETURN o_loan_mt;
           exception
          when   no_data_found THEN
           RETURN '0';
           END ;
     ELSE
           IF i_dt = t_sysdate THEN
            BEGIN
            SELECT  mony_loan_nowrm
            INTO o_loan_mt
             FROM cwd99m00
             WHERE acnt_no = i_acnt_no
             AND sub_no = i_sub_no ;

             RETURN o_loan_mt;
             exception
             when   no_data_found THEN
              RETURN '0' ;
               END ;
               END IF ;
              END IF ;
            END IF ;
     IF i_tp = '4' THEN
         IF i_dt <> t_sysdate THEN
            BEGIN
            SELECT  pia_loan_nowrm
             INTO o_loan_mt
            FROM cwd99h00
            WHERE acnt_no = i_acnt_no
            AND sub_no = i_sub_no
            AND dt = i_dt ;
          RETURN o_loan_mt;
           exception
           when   no_data_found THEN
           RETURN '0';
           END ;
         ELSE
           IF i_dt = t_sysdate THEN
              BEGIN
                   SELECT pia_loan_nowrm
                    INTO o_loan_mt
                   FROM cwd99m00
                   WHERE acnt_no = i_acnt_no
                   AND sub_no = i_sub_no ;

                   RETURN o_loan_mt;
                   exception
                   when   no_data_found THEN
                  RETURN  '0';
                  END ;
                  END IF ;
               END IF ;
            END IF;
    RETURN o_loan_mt;

end ;
/

