create function fcw_get_tch_bank_err(i_err_cd  in varchar2,
                                                i_bank_cd in varchar2)
  return varchar2 as
  is_err_cd  varchar2(10);
  is_err_msg varchar2(1000);
begin
  is_err_cd := i_err_cd;
  select nvl(bank_err_cd_cont, '!')
    into is_err_msg
    from vn.cww01c00
   where bank_cd = trim(i_bank_cd)
     and trim(bank_err_cd) = trim(is_err_cd);
  return is_err_msg;
exception
  when others then
    return i_err_cd;
  
end fcw_get_tch_bank_err;
/

