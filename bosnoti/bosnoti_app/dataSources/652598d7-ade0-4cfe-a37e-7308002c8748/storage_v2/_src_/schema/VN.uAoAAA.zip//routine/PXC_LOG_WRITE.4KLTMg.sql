create procedure pxc_log_write
	(
		 i_pgm         in      varchar2   		  /* file name     */
		,i_msg         in      varchar2   		  /* message       */
	) is

/*
   \file     pxc_log_write.sql
   \brief    ??????

   \section intro Program Information
        - Program Name              : ??????
        - Service Name              : N/A
        - Related Client Program- Client Program ID : Client 05101
        - Related Tables            : BMB01M00
        - Dev. Date                 : 2007/11/30
        - Developer                 : ????
        - Business Logic Desc.      : ??????
        - Latest Modification Date  : 2007-11-30

   \section history Program Modification History
    - 1.0       2007/11/30     ????    ??????
   \section hardcoding Hard-Coding List
    - HC-1

   \section info Additional Reference Comments
    - ???? ????
*/

  ts_err_msg       varchar2(128):= ' ';        /* error message */
  error_skip        exception;

  v_OutputFile  UTL_FILE.FILE_TYPE;
  v_Dir      VARCHAR2(50) := 'LOG_DIR';
  v_Name      VARCHAR2(50) := ' ';

begin
  v_Name  := i_pgm||'.'||to_char(sysdate,'yyyymmdd');

  v_OutputFile := UTL_FILE.FOPEN(v_Dir,v_Name,'a');

  UTL_FILE.PUTF(v_OutputFile, '[%s] %s \n',
        to_char(sysdate,'yyyy:mm:dd hh24:mi:ss'),i_msg);

  UTL_FILE.FFLUSH(v_OutputFile);
  UTL_FILE.FCLOSE(v_OutputFile);

exception
  when UTL_FILE.INVALID_OPERATION then
    ts_err_msg := 'invalid Operation';
    raise_application_error(-20100,ts_err_msg);
  when UTL_FILE.INVALID_FILEHANDLE then
    ts_err_msg := 'invalid file handle';
    raise_application_error(-20100,ts_err_msg);
  when UTL_FILE.WRITE_ERROR then
    ts_err_msg := 'write error ';
    raise_application_error(-20100,ts_err_msg);
  when UTL_FILE.INVALID_PATH then
    ts_err_msg := 'Invalid Path ';
    raise_application_error(-20100,ts_err_msg);
  when UTL_FILE.INVALID_MODE then
    ts_err_msg := 'Invalid MODE ';
    raise_application_error(-20100,ts_err_msg);
  when UTL_FILE.READ_ERROR then
    ts_err_msg := 'READ_ERROR ';
    raise_application_error(-20100,ts_err_msg);
  when error_skip then
    raise_application_error(-20100,ts_err_msg);
  when others then
    ts_err_msg := 'ty.pxc_log_write  error !';
--    ts_err_msg := sqlerrm;
    raise_application_error(-20100,ts_err_msg);
end pxc_log_write;
/

