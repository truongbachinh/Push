create procedure psr_proc_bank_amt_p
(
	i_proc_dt		        in		varchar2
,	i_job_tp		        in		varchar2   -- 1 int amt , 2 payments
,   i_stk_cd                in      varchar2
,   i_amt                   in      number
,	i_result_yn		        in		varchar2   -- Y , E
,	i_seq		            in		number
,	i_bank_cd	            in		varchar2
,   i_work_mn               in      varchar2
,   i_work_trm              in      varchar2

) as

tn_trd_seq_no  number := 0 ;
t_tot_trd_seq  number := 0 ;

tn_total_own_qty  number := 0;
tn_total_sub_qty  number := 0;

ts_rmrk_cd  varchar2(3) := null ;
ts_trd_tp  varchar2(2) := null ;


BEGIN

	vn.pxc_log_write('psr_proc_bank_amt_p','proc_dt : '|| i_proc_dt || 'job_tp : ' || i_job_tp );
	vn.pxc_log_write('psr_proc_bank_amt_p','result_yn : '|| i_result_yn || 'seq : ' || i_seq );

	if  i_result_yn ='Y' then

         for c1 in (
		   select acnt_no ,
				  sub_no  ,
				  rgt_std_dt ,
				  rgt_tp ,
				  stk_cd ,
				  seq_no ,
				  sbst_dt ,
				  sbst_qty ,
				  sbst_amt ,
				  work_mn ,
				  work_dtm ,
				  work_trm
            from  vn.srr03m00
           where  proc_seq = i_seq
			 and  proc_tp = 'W'
         )loop

		  update vn.srr03m00
			set  proc_tp = 'Y'
           where proc_seq = i_seq ;

         vn.pxc_psb_seq_cret_p  (c1.acnt_no, c1.sub_no , i_proc_dt, tn_trd_seq_no , t_tot_trd_seq );

         vn.pxc_log_write('psr_proc_bank_amt_p', 'acnt_no : ' || c1.acnt_no ||','|| c1.sub_no  );
         vn.pxc_log_write('psr_proc_bank_amt_p', 'trd_seq : ' || tn_trd_seq_no);

	     if i_job_tp = '2' then

			ts_rmrk_cd := '244';
			ts_trd_tp := '63';


		/* sub Account Oh New 20120326 */
		select nvl(sum(own_qty),0)
		  into tn_total_own_qty
			from vn.srr02m00
			where acnt_no = c1.acnt_no
			and rgt_tp = c1.rgt_tp
            and stk_cd = c1.stk_cd
            and seq_no = c1.seq_no
			and rgt_std_dt = c1.rgt_std_dt;

		vn.pxc_log_write('psr_proc_bank_amt_p', 'tn_total_own_qty : ' || tn_total_own_qty);
		vn.pxc_log_write('psr_proc_bank_amt_p', 'c1.sbst_dt       : ' || c1.sbst_dt);
		vn.pxc_log_write('psr_proc_bank_amt_p', 'c1.sbst_qty      : ' || c1.sbst_qty);
		vn.pxc_log_write('psr_proc_bank_amt_p', 'fss_get_stk_mkt  : ' || vn.fss_get_stk_mkt(c1.stk_cd));
		vn.pxc_log_write('psr_proc_bank_amt_p', 'c1.sbst_amt      : ' || c1.sbst_amt);
		vn.pxc_log_write('psr_proc_bank_amt_p', 'c1.sbst_qty      : ' || c1.sbst_qty);

        update vn.srr02m00
           set proc_dt = c1.sbst_dt ,
               pay_yn  = 'Y'   ,
               cons_sbst_qty = trunc(c1.sbst_qty * own_stk_qty / tn_total_own_qty,decode(vn.fss_get_stk_mkt(c1.stk_cd),1,-1,2,-2,3,-2,-1)) ,
               cons_sbst_amt = trunc(c1.sbst_qty * own_stk_qty / tn_total_own_qty,decode(vn.fss_get_stk_mkt(c1.stk_cd),1,-1,2,-2,3,-2,-1)) * c1.sbst_amt/c1.sbst_qty ,
			   outamt_trd_no = 0 ,-- sub account cant register buying right
               work_mn = i_work_mn ,
               work_dtm = sysdate ,
               work_trm = i_work_trm
         where rgt_std_dt = c1.rgt_std_dt
		   and acnt_no = c1.acnt_no
		   and sub_no  = c1.sub_no
		   and stk_cd = c1.stk_cd
		   and rgt_tp = c1.rgt_tp
		   and seq_no = c1.seq_no
           and outamt_trd_no = 0;

		  /* Main Account Oh new 20120326 */
			select nvl(sum(cons_sbst_qty),0)
			into tn_total_sub_qty
			from vn.srr02m00
			where acnt_no = c1.acnt_no
			and sub_no != '00'
			and rgt_tp = c1.rgt_tp
            and stk_cd = c1.stk_cd
            and seq_no = c1.seq_no
			and rgt_std_dt = c1.rgt_std_dt;

		vn.pxc_log_write('psr_proc_bank_amt_p', 'tn_total_sub_qty      : ' || tn_total_sub_qty);

		   update vn.srr02m00
              set proc_dt = c1.sbst_dt ,
                  pay_yn  = 'Y'   ,
                  cons_sbst_qty = c1.sbst_qty - tn_total_sub_qty ,
                  cons_sbst_amt = (c1.sbst_qty - tn_total_sub_qty)  * c1.sbst_amt/c1.sbst_qty ,
                  outamt_trd_no = tn_trd_seq_no ,
                  work_mn = i_work_mn ,
                  work_dtm = sysdate ,
                  work_trm = i_work_trm
            where acnt_no = c1.acnt_no
			  and sub_no = '00'
              and rgt_tp = c1.rgt_tp
              and stk_cd = c1.stk_cd
              and seq_no = c1.seq_no
			  and rgt_std_dt = c1.rgt_std_dt
              and outamt_trd_no = 0 ;


           /* adding reuse amt or sbst dpo by rights */
              vn.psr_sbst_proc_p
              (
                'm'          -- make
              , c1.rgt_tp
              , c1.rgt_std_dt
              , c1.stk_cd
              , c1.seq_no
              , c1.acnt_no  -- all account
			  , '%' -- all sub
              , i_work_mn
              , i_work_trm
              );

             update vn.srr03m00
				set proc_tp = 'Y'
				   ,inq_trd_no = tn_trd_seq_no
              where proc_seq = i_seq;

          else

            update vn.srr02m00
               set cancel_qty = 0
                  ,proc_dt = NULL
                  ,cons_sbst_qty = 0
                  ,cons_sbst_amt = 0
                  ,outamt_trd_no = 0
                  ,pay_yn = 'N'
                  ,work_mn =  c1.work_mn
                  ,work_dtm = sysdate
                  ,work_trm = c1.work_trm
            where rgt_std_dt = c1.rgt_std_dt
              and acnt_no = c1.acnt_no
			  and sub_no  = c1.sub_no
              and stk_cd = c1.stk_cd
              and rgt_tp = '1'
              and seq_no = c1.seq_no ;

           ts_rmrk_cd := '245';
		   ts_trd_tp := '62';

           update vn.srr03m00
			  set proc_tp = 'Y'
				 ,inq_trd_no = tn_trd_seq_no
            where proc_seq =  i_seq ;

		  end if ;

          insert  into  vn.aaa10m00
             (
                 acnt_no
                ,sub_no
                ,trd_dt
				,tot_trd_seq_no
                ,trd_seq_no
                ,trd_tp
                ,rmrk_cd
                ,mdm_tp
                ,cncl_yn
                ,org_trd_no
                ,trd_amt
                ,cmsn
                ,adj_amt
                ,acnt_mng_bnh
                ,agnc_brch
                ,work_bnh
                ,proc_agnc_brch
                ,work_mn
                ,work_dtm
                ,work_trm
				,stk_cd
             )
        values
             (
                 c1.acnt_no
                ,c1.sub_no
                ,i_proc_dt
                ,t_tot_trd_seq
                ,tn_trd_seq_no
                ,ts_trd_tp
                ,ts_rmrk_cd
                ,'00'
                ,'N'
                ,0
                ,c1.sbst_amt
                ,0
                ,c1.sbst_amt
                ,vn.faa_acnt_bnh_cd_g('0', c1.acnt_no , c1.sub_no)
                ,vn.faa_acnt_bnh_cd_g('3', c1.acnt_no , c1.sub_no)
                ,vn.faa_acnt_bnh_cd_g('0', c1.acnt_no , c1.sub_no)
                ,vn.faa_acnt_bnh_cd_g('3', c1.acnt_no , c1.sub_no)
                ,i_work_mn
                ,sysdate
                ,i_work_trm
				,c1.stk_cd
             );

            vn.psr_gga07m00_ins_p (i_proc_dt,
                                   'I',
                                   c1.acnt_no,
								   c1.sub_no,
                                   tn_trd_seq_no,
                                   0,
                                   ts_rmrk_cd,
                                   c1.sbst_amt,
                                   i_work_mn,
                                   i_work_trm,
                                   i_bank_cd );

    end loop ;


  else


	update vn.srr03m00
	   set proc_tp = 'E'
	   where proc_seq = i_seq;


    pxc_log_write('psr_proc_bank_amt_p','err');

  end if ;

end psr_proc_bank_amt_p;
/

