create FUNCTION    fdl_get_mrgn_int_new(
    i_acnt_no               IN VARCHAR2,    --
    i_sub_no                IN VARCHAR2,    --
    i_prd_no                IN VARCHAR2,    -- 
    i_lnd_cntr_no           IN VARCHAR2,
    i_int_tp                IN NUMBER,      -- 1:int;   2:dly_int;  3:all
    i_lnd_dt                IN VARCHAR2,    --
    i_expr_dt               IN VARCHAR2,    --
    i_start_dt              IN VARCHAR2,
    i_end_dt                IN VARCHAR2,    --
    i_int_rpy_tp            IN NUMBER,      -- 1: khong tinh lai ngay tra;  2. tinh luon lai ngay tra
    i_rpy_mthd_tp           IN NUMBER,      -- 1:cash;  2:sell(1. tinh lai tren so tien hoan tra, 2.tinh lai dua tren so du goc con lai)
    i_int_calc_apy_tp       IN NUMBER,      -- 1:lai tinh; 2:lai dong
    i_rpy_amt               IN NUMBER,      -- so tien hoan tra 
    i_remn_amt              IN NUMBER,      -- so tien vay con lai
    i_day_min               IN NUMBER,      -- so ngay tinh lai toi thieu (neu la -1 thi la dung de tinh lai cho ngay ke tiep)
    i_int_waive_day_tp      IN NUMBER,      -- Phan loai ngay mien lai: 1-Ngay theo lich (khong tinh ngay nghi); 2-Ngay lam viec (tinh ngay nghi)
    i_int_waive_days        IN NUMBER,      -- So ngay mien lai 
    i_lnd_int_cal_std_dt    IN NUMBER,      -- So ngay tieu chuan tinh lai
    i_dly_int_yn            IN NUMBER      -- Co tinh lai qua han cua lai hay ko
) RETURN NUMBER AS

    /* Khai bao bien */
    t_lnd_calc_amt          NUMBER          := 0;
    t_tot_prd               NUMBER          := 0;
    t_lnd_int_rt            NUMBER          := 0;
    t_lnd_int_rt_dly        NUMBER          := 0;
    t_lnd_int               NUMBER          := 0;
    t_lnd_int_dly           NUMBER          := 0;
    t_tot_int               number          := 0;
    t_tot_dly_int           number          := 0;
    o_lnd_int               NUMBER          := 0;
    t_cost_of_cap           NUMBER          := 0;
    t_lnd_int_cal_std_dt    NUMBER          := 0;

    -- Cac bien dung cho vong loop
    t_lnd_int_rt_prev       number          := 0;
    t_lnd_int_rt_dly_prev   NUMBER          := 0;
    t_start_dt              VARCHAR2(8)     := i_start_dt;
    t_end_dt                VARCHAR2(8)     := i_start_dt;
    t_prev_start_dt         VARCHAR2(8)     := i_start_dt;

BEGIN

    -- Ghi log
    vn.pxc_log_write('fdl_get_mrgn_int_new',
                    'START fdl_get_mrgn_int_new:' || ' ACNT = ' || i_acnt_no || ' - ' || i_sub_no);

    -- Xoa du lieu cu trong table
    DELETE dlm_lnd_int_temp
    WHERE acnt_no       = i_acnt_no
      AND sub_no        = i_sub_no
      AND prd_no        = i_prd_no
      AND lnd_cntr_no   = i_lnd_cntr_no;

    COMMIT;

    /*==============================================================================================*/
    /*                                          B1. Chuan bi du lieu                                */
    /*==============================================================================================*/
    IF(i_lnd_int_cal_std_dt IS NULL OR i_lnd_int_cal_std_dt <= 0) THEN 
        t_lnd_int_cal_std_dt := 1;
    ELSE
        t_lnd_int_cal_std_dt := i_lnd_int_cal_std_dt;
    END IF;

    -- Lay gia tri so tien se duoc dung de tinh lai tren do:
    SELECT DECODE(i_rpy_mthd_tp, '1', i_remn_amt, i_rpy_amt)
    INTO t_lnd_calc_amt
    FROM DUAL;

    -- Lay khoang thoi gian tinh lai
    t_tot_prd := TO_DATE(i_end_dt, 'YYYYMMDD') - TO_DATE(i_start_dt, 'YYYYMMDD') + 1;

    -- hphan: need edited
    -- Nếu là ưu tien thu lai thi chi tinh ngay tinh lai toi thieu trong lan dau tien.
    -- Con neu lai goc tuong duong thi tinh so ngay toi thieu o bat cu lan tra nao
    IF (i_rpy_mthd_tp = '1' 
        AND i_lnd_dt + i_int_waive_days = i_start_dt 
        AND t_tot_prd < i_day_min) 
        OR
        (i_rpy_mthd_tp = '2' AND t_tot_prd < i_day_min) THEN
        t_tot_prd := i_day_min;
    END IF;

    /*==============================================================================================*/
    /*              B2. Tinh tien lai cho tung ngay trong khoang thoi gian tra cuu                  */
    /*==============================================================================================*/

    FOR i in 0 .. t_tot_prd - 1 LOOP
        t_start_dt              := TO_CHAR(TO_DATE(i_start_dt, 'YYYYMMDD') + i, 'YYYYMMDD');
        t_end_dt                := t_start_dt;

        t_lnd_int_rt_dly_prev   := t_lnd_int_rt_dly;
        t_lnd_int_rt_prev       := t_lnd_int_rt;

        IF i_int_calc_apy_tp = '1' THEN         -- Lai tinh se lay ti lai tai thoi diem phat vay
            t_lnd_int_rt        := VN.fdl_get_mrgn_rt_01(i_acnt_no, i_sub_no, '08', i_lnd_dt); 
            t_lnd_int_rt_dly    := VN.fdl_get_mrgn_rt_01(i_acnt_no, i_sub_no, '09', i_lnd_dt);  

        ELSE                                    -- Lai dong se lay ti le tai tung thoi diem tinh lai
            t_lnd_int_rt        := VN.fdl_get_mrgn_rt_01(i_acnt_no, i_sub_no, '08', t_start_dt); 
            t_lnd_int_rt_dly    := VN.fdl_get_mrgn_rt_01(i_acnt_no, i_sub_no, '09', t_start_dt);  
        END IF;

        IF t_start_dt <= i_expr_dt THEN         -- Ngay tinh lai van con trong han
            t_lnd_int_dly       := 0;
            t_lnd_int           := t_lnd_calc_amt * t_lnd_int_rt / t_lnd_int_cal_std_dt;
            t_tot_int           := t_tot_int + t_lnd_int;
        ELSE                                    -- Ngay tinh lai da qua han
            t_lnd_int := 0;                     -- Neu ma co tinh lai qua han cua lai
            IF i_dly_int_yn = 1 THEN
                t_lnd_int_dly := (t_lnd_calc_amt + t_tot_int) * t_lnd_int_rt_dly / t_lnd_int_cal_std_dt;
            ELSE                                --  Neu ko tinh lai qua han cua lai
                t_lnd_int_dly := t_lnd_calc_amt * t_lnd_int_rt_dly / t_lnd_int_cal_std_dt;
            END IF;

            t_tot_dly_int := t_tot_dly_int + t_lnd_int_dly;
        END IF;

        -- Neu co su thay doi lai suat so voi ngay truoc do, se insert 1 ban ghi moi
        IF (t_lnd_int_rt_prev <> t_lnd_int_rt OR t_lnd_int_rt_dly_prev <> t_lnd_int_rt_dly) THEN

            t_prev_start_dt := t_start_dt;

            INSERT INTO vn.dlm_lnd_int_temp(
                acnt_no,
                sub_no,
                prd_no,
                lnd_cntr_no,
                lnd_dt,
                expr_dt,
                start_dt,
                end_dt,
                day_num ,
                remain_lnd_amt,
                repy_lnd_amt,
                lnd_calc_amt,
                lnd_int,
                lnd_dly_int 
            )
            VALUES(
                i_acnt_no,
                i_sub_no,
                i_prd_no,
                i_lnd_cntr_no,
                i_lnd_dt,
                i_expr_dt,
                t_start_dt,
                t_end_dt,
                1,
                i_remn_amt,
                i_rpy_amt,
                t_lnd_calc_amt,
                t_lnd_int,
                t_lnd_int_dly
            );
         ELSE       -- Neu lai suat ko doi, se cong dong gia tri tien lai
            UPDATE DLM_LND_INT_TEMP
            SET 
                end_dt      = t_end_dt,
                day_num     = day_num       + 1,
                lnd_int     = lnd_int       + t_lnd_int,
                lnd_dly_int = lnd_dly_int   + t_lnd_int_dly
            WHERE acnt_no       = i_acnt_no
              AND sub_no        = i_sub_no
              AND prd_no        = i_prd_no
              AND lnd_cntr_no   = i_lnd_cntr_no
              AND start_dt      = t_prev_start_dt;

        END IF;
    END LOOP;

    COMMIT;

    /*====================================================================================================*/
    --                                      B3. Tinh toan ket qua tra ra
    -- int_tp: 1.interest with ROUND        2.delay with ROUND          3.total interest with ROUND
    -- int_tp: 4.interest without ROUND     5.delay without ROUND       other: total interest without ROUND
    /*=====================================================================================================*/

    t_cost_of_cap := t_tot_prd * i_remn_amt * fdl_get_mrgn_rt_01(i_acnt_no, i_sub_no, '34', i_start_dt);

    IF i_int_tp = '1' THEN
        o_lnd_int := ROUND(t_tot_int);
    ELSIF i_int_tp = '2' THEN
        o_lnd_int := ROUND(t_tot_dly_int);
    ELSIF i_int_tp = '3' THEN
        o_lnd_int := t_tot_int + t_tot_dly_int;
    ELSIF i_int_tp = '4' THEN
        o_lnd_int := t_tot_int;
    ELSIF i_int_tp = '5' THEN
        o_lnd_int := t_tot_dly_int;
    ELSIF i_int_tp = '6' THEN
        o_lnd_int := t_cost_of_cap;
    ELSE
        o_lnd_int := t_tot_int + t_tot_dly_int;
    END IF;

    RETURN o_lnd_int;

    vn.pxc_log_write('fdl_get_mrgn_int_new',
                    'END fdl_get_mrgn_int_new:' || ' ACNT = ' || i_acnt_no || ' - ' || i_sub_no);

END fdl_get_mrgn_int_new;
/

