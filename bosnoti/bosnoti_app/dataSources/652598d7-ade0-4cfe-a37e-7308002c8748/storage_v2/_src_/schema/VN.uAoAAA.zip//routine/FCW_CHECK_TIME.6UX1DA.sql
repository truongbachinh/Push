create function fcw_check_time
(
    is_acnt_no in		varchar2,
		is_sub_no in		varchar2,
		is_mdm_tp in		varchar2,
		is_rmrk_cd in		varchar2	  
) return varchar2 as

	o_bnh_cd	varchar2(3);
	o_agnc_brch	varchar2(2);  
	o_cnt	    number:=0;
	o_check     number;
	o_st_time   number;
	o_end_time  number;

begin
  
	select	acnt_mng_bnh
					,agnc_brch
	into	o_bnh_cd
        ,o_agnc_brch
	from	vn.aaa01m00
	where	acnt_no 	=	substr(is_acnt_no,1,10)
	and   sub_no = is_sub_no
	and		acnt_stat = '1';

	  select count(*)
	   	into o_cnt
	   	from vn.cwd01b00
	   where cls_dt = '30000101'
	     and brch_cd = o_bnh_cd
       and agnc_brch = o_agnc_brch
       and mdm_tp = is_mdm_tp
       and rmrk_cd = is_rmrk_cd		;		
       
if o_cnt > 0 then       

	select to_number(to_char(st_time,'hh24miss'))
	      ,to_number(to_char(end_time,'hh24miss'))
	  into o_st_time
		  ,o_end_time
	  from vn.cwd01b00
	 where cls_dt = '30000101'
       and brch_cd = o_bnh_cd
       and agnc_brch = o_agnc_brch
       and mdm_tp = is_mdm_tp
       and rmrk_cd = is_rmrk_cd;

	   select to_number(to_char(sysdate, 'hh24miss'))
		 into o_check
		 from dual;

     if( o_check < o_st_time or o_check > o_end_time) then

		     return 'N';

     else

		     return 'Y';

	   end if;
else
  
     return 'Y';
     
end if;     

end ;
/

