create procedure pts_update_stop_order(
                                            i_sec_id    in    varchar2
                                           )as

begin
	pxc_log_write('pts_update_stop_order','start ... waiting!');


	/*Kiem tra lenh con hieu luc khong*/
	update tso09m00
	set proc_tp = '9',
		ord_stl_eft = '2',
		ord_veto_cau = decode(mth_qty_stl, ORG_ORD_QTY, 'Done', 'Expired date')
	where ord_stl_eft = '1'
	and   ord_stl = '1'
	and  (ord_end_dt < vn.FXC_VORDERDT_G(to_date(vn.vhdate(),'yyyymmdd'), 1)	OR
		  mth_qty_stl = ORG_ORD_QTY
		 )
	;

	FOR C1 IN
	(
		select
			a.ord_frct_dt			as		ord_frct_dt			,
            a.ORD_NO                as		ORD_NO				,
            a.BNH_CD                as		BNH_CD				,
            a.ACNT_NO				as		ACNT_NO				,
            a.SUB_NO                as		SUB_NO
		from vn.tso09m00 a
        where  ord_stl_eft = '1'
		and   ord_stl = '1'
		and   proc_tp <> '1'
    )loop
		BEGIN
            update tso09m00
            set proc_tp = '1',
                ord_veto_cau = null,
                ri_ord_no = null
            where ord_frct_dt = c1.ord_frct_dt
            and      ord_no  = c1.ord_no
            and      acnt_no = c1.acnt_no
            and      sub_no  = c1.sub_no
            ;

        EXCEPTION
            WHEN OTHERS THEN
            pxc_log_write('pts_update_stop_order','=> ERROR UPDATE :'||to_char(sqlcode)||'messg : '||sqlerrm||', ORD_FRCT_DT: '||c1.ord_frct_dt||', acnt_no: '||C1.acnt_no || ', sub_no: ' || c1.sub_no || ', ord_no: ' || c1.ord_no);
		end;

    END LOOP;
    commit;
pxc_log_write('pts_update_stop_order','end ... thanks waiting!');
end pts_update_stop_order;
/

