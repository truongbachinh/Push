create PROCEDURE PVSD_MT540
(
  i_sec_cd  IN VARCHAR2,
  i_tp      IN VARCHAR2,
  i_biz_cd  IN VARCHAR2,
  i_message IN VARCHAR2
)
/*************************************************
    i_tp: (Dien 540 chi dung cho luu ky chung khoan)
      1: Yeu cau gui luu ky chung khoan
      2: Huy yeu cau luu ky chung khoan


    i_biz_cd:
      001: TK
      002: CK + quyen
      003: Lenh
      004: Thanh toan + Cho vay

    i_mess:
      Cac tham so duoc ngan cach boi chuoi cac ky tu dac biet: !@#
      Doi voi bao cao yeu cau tham so dau tien phai la Ma bao cao. VD: CS001
    *************************************************/
 AS
  TYPE t_array IS TABLE OF VARCHAR2(200) INDEX BY PLS_INTEGER;

  v_send_dat VARCHAR2(4000);
  vn_message VARCHAR2(1000) := i_message;
  vn_pos     NUMBER := 0;
  i          NUMBER := 0;
  vn_var     t_array;
  vn_prev_bos_seq  NUMBER := 0;
  V_ISSU_CD  VARCHAR2(30);

BEGIN

  vn.pxc_log_write('pvsd_mt540', 'type: '|| i_tp || '-' ||i_message);

  IF i_tp = '1' THEN
    WHILE INSTR(vn_message, '!@#') > 0
    LOOP
      i      := i + 1;
      vn_pos := INSTR(vn_message, '!@#');

      vn_var(i) := substr(vn_message, 1, vn_pos - 1);

      vn_message := substr(vn_message, vn_pos + 3);
    END LOOP;

    vn_var(i + 1) := vn_message;

    FOR C1 IN (SELECT A.ACNT_NO,
              A.STK_CD,
              replace(A.CNTE, '/', '?_?') CNTE,
              A.PROC_DT,
              decode(C.ACNT_TP, 'P', 'OWNE', 'NOMI') ACNT_TP,
              decode(VN.FSS_GET_STK_MKT(A.STK_CD)
                ,'1'
                ,'XSTC'
                ,'2'
                ,'HSTC'
                ,'4'
                ,'XHNX'
                ,'3'
                ,'OTCO') STK_MKT_TP,
              decode(A.SB_LMT_QTY, 0, 'NRST', 'RSTR') QTY_NM,
			        decode(sign(to_number(to_char(vn.wdate,'yyyymmdd')) - to_number(a.APY_DT)),-1, 'PEND' , 'NORM') STK_TP,
              decode(A.SB_LMT_QTY, 0, '1', '2') QTY_TP,
              decode(A.SB_LMT_QTY, 0, A.QTY, A.SB_LMT_QTY) STK_QTY,
              decode(D.SEX_TP, '1', 'MR01', 'MADA') SEX_TP,
              replace(C.IDNO, '/', '?_?') IDNO,
             decode(D.IDNO_TP
								,'1'
								,'IDNO'
								,'2'
								,'CCPT'
								,'3'
								,'CORP'
								,'4'
								,'OTHR'
								,'5'
								,'FIIN'
								,'6'
								,'ARNU'
								,'7'
								,'GOVT') IDNO_TP,
              nvl(D.idno_iss_orga, '!') ISS_ORGA,
              nvl(D.idno_iss_dt, '!') ISS_DT,
              C.CUST_NM,
              D.BIRTH_DT,
              (SELECT CURR_CD
               FROM AAA03C20
              WHERE CTRY_CD = D.CTRY_CD) CURR_CD,
              DECODE(E.STK_TP, '20', 'FAMT', 'UNIT') UNIT,
              A.BOS_SEQ_NO,
              VN.fvsd_getbiccode(i_sec_cd) BICCODE,
              decode(A.VSD_BRCH, '02', 'VSDSVN02', 'VSDSVN01') VSD_BRCH_NM,
              A.VSD_BRCH
           FROM VN.SSB05M00 A,
              VN.SSI01M00 E,
              VN.AAA01M00 C,
              VN.AAA02M00 D
          WHERE A.STK_CD = E.STK_CD
            AND A.ACNT_NO = C.ACNT_NO
            AND A.SUB_NO = C.SUB_NO
            AND C.IDNO = D.IDNO
            AND A.PROC_DT = vn_var(1)
            AND A.BOS_SEQ_NO = vn_var(2)
            AND A.BOS_STAT = '1'
            AND A.TRD_TP = '13')
    LOOP

      vn.pxc_log_write('pvsd_mt540', 'type: '|| C1.STK_TP);

      if C1.STK_TP = 'PEND' then

          SELECT ISSU_CD INTO V_ISSU_CD
          FROM   VN.SSI01M00
          WHERE  STK_CD = C1.STK_CD;

           -- Bat dau Block: Thông tin chung
           v_send_dat :=   ':16R:GENL' || chr(13) ||
              ':20C::SEME//' || C1.BOS_SEQ_NO || chr(13) ||
              ':23G:NEWM' || chr(13) ||
              ':98A::PREP//' || to_char(SYSDATE, 'yyyymmdd') || chr(13) ||
              ':16R:LINK' || chr(13) ||
              ':20C::PCTI//'|| V_ISSU_CD || chr(13) ||
              ':16S:LINK' || chr(13) ||
              ':16S:GENL' || chr(13) ||

              -- B?t d?u Block: Thông tin giao d?ch
              ':16R:TRADDET' || chr(13) ||
              ':98A::SETT//' || C1.PROC_DT || chr(13) ||
              ':35B:/VN/' || C1.STK_CD || chr(13) ||
              ':16R:FIA' || chr(13) ||
              --':94B::PLIS//EXCH/' || C1.STK_MKT_TP || chr(13) ||
              ':12A::CLAS//' || C1.STK_TP || '/' || C1.QTY_TP || chr(13) ||
              --':70E::FIAN//' || C1.QTY_NM || chr(13) ||
              ':16S:FIA' || chr(13) ||
              ':70E::SPRO//' ||'SHAR'|| chr(13) ||
              ':16S:TRADDET' || chr(13) ||

             -- B?t d?u Block: Thông tin chi ti?t
              ':16R:FIAC' || chr(13) ||
              ':36B::SETT//' || C1.UNIT || '/' || C1.STK_QTY || chr(13) ||
              ':70D::DENC//' || C1.CNTE || chr(13) ||
              ':95P::ACOW//' || C1.BICCODE || chr(13) ||
              ':97A::SAFE//' || C1.ACNT_NO || chr(13) ||
              ':16S:FIAC' || chr(13) ||

             -- B?t d?u Block: Thông tin thanh toán
              ':16R:SETDET' || chr(13) ||
              ':22F::SETR//' || 'TRAD' || chr(13) ||
              ':22F::STCO//' || 'PHYS' || chr(13) ||

             -- B?t d?u Block: Các d?i tác thanh toán
              ':16R:SETPRTY' || chr(13) ||
              ':95P::PSET//' || C1.VSD_BRCH_NM || chr(13) ||
              ':16S:SETPRTY' || chr(13) ||
              ':16R:SETPRTY' || chr(13) ||
              ':95P::DEAG//' || C1.BICCODE|| chr(13) ||
              ':16S:SETPRTY' || chr(13) ||
              ':16S:SETDET' || chr(13) ||

             -- B?t d?u Block: Thông tin nhà d?u tu
              ':16R:OTHRPRTY' || chr(13) ||
              ':95Q::INVE//' || C1.CUST_NM || chr(13) ||
                      C1.BIRTH_DT || chr(13) ||
                      C1.CURR_CD || chr(13) ||
              ':95S::ALTE/VISD/' || C1.IDNO_TP || '/' ||
											C1.CURR_CD || '/' || C1.IDNO || chr(13) ||
              ':70E::REGI//' || chr(13) ||
                      C1.ISS_ORGA || chr(13) ||
                      C1.ISS_DT || chr(13) ||
              ':16S:OTHRPRTY';
      else
      -- B?t d?u Block: Thông tin chung
      v_send_dat :=   ':16R:GENL' || chr(13) ||
              ':20C::SEME//' || C1.BOS_SEQ_NO || chr(13) ||
              ':23G:NEWM' || chr(13) ||
              ':98A::PREP//' || to_char(SYSDATE, 'yyyymmdd') || chr(13) ||
              --':16R:LINK' || chr(13) ||
              --':20C:PCTI' || chr(13) ||
              --':16S:LINK' || chr(13) ||
              ':16S:GENL' || chr(13) ||

              -- B?t d?u Block: Thông tin giao d?ch
              ':16R:TRADDET' || chr(13) ||
              ':98A::SETT//' || C1.PROC_DT || chr(13) ||
              ':35B:/VN/' || C1.STK_CD || chr(13) ||
              ':16R:FIA' || chr(13) ||
              ---':94B::PLIS//EXCH/' || C1.STK_MKT_TP || chr(13) ||
              ':12A::CLAS//' || C1.STK_TP || '/' || C1.QTY_TP || chr(13) ||
              --':70E::FIAN//' || C1.QTY_NM || chr(13) ||
              ':16S:FIA' || chr(13) ||
              ':70E::SPRO//' ||'SHAR'|| chr(13) ||
              ':16S:TRADDET' || chr(13) ||

             -- B?t d?u Block: Thông tin chi ti?t
              ':16R:FIAC' || chr(13) ||
              ':36B::SETT//' || C1.UNIT || '/' || C1.STK_QTY || chr(13) ||
              ':70D::DENC//' || C1.CNTE || chr(13) ||
              ':95P::ACOW//' || C1.BICCODE || chr(13) ||
              ':97A::SAFE//' || C1.ACNT_NO || chr(13) ||
              ':16S:FIAC' || chr(13) ||

             -- B?t d?u Block: Thông tin thanh toán
              ':16R:SETDET' || chr(13) ||
              ':22F::SETR//' || 'TRAD' || chr(13) ||
              ':22F::STCO//' || 'PHYS' || chr(13) ||

             -- B?t d?u Block: Các d?i tác thanh toán
              ':16R:SETPRTY' || chr(13) ||
              ':95P::PSET//' || C1.VSD_BRCH_NM || chr(13) ||
              ':16S:SETPRTY' || chr(13) ||
              ':16R:SETPRTY' || chr(13) ||
              ':95P::DEAG//' || C1.BICCODE|| chr(13) ||
              ':16S:SETPRTY' || chr(13) ||
              ':16S:SETDET' || chr(13) ||

             -- B?t d?u Block: Thông tin nhà d?u tu
              ':16R:OTHRPRTY' || chr(13) ||
              ':95Q::INVE//' || C1.CUST_NM || chr(13) ||
                      C1.BIRTH_DT || chr(13) ||
                      C1.CURR_CD || chr(13) ||
              ':95S::ALTE/VISD/' || C1.IDNO_TP || '/' ||
											C1.CURR_CD || '/' || C1.IDNO || chr(13) ||
              ':70E::REGI//' || chr(13) ||
                      C1.ISS_ORGA || chr(13) ||
                      C1.ISS_DT || chr(13) ||
              ':16S:OTHRPRTY';
      end if;

      INSERT INTO VN.VSD01M00
        (REG_DT,
         SEQ_NO,
         BIZ_CD,
         DAT_CD,
         SND_DAT,
         SND_TP,
         WORK_DTM,
         VSD_BRCH)
      VALUES
        (to_char(SYSDATE, 'yyyymmdd'),
         C1.BOS_SEQ_NO,
         i_biz_cd,
         '540',
         v_send_dat,
         '1',
         SYSDATE,
         C1.VSD_BRCH);

    END LOOP;

  ELSIF i_tp = '2' THEN

    WHILE INSTR(vn_message, '!@#') > 0
    LOOP
      i      := i + 1;
      vn_pos := INSTR(vn_message, '!@#');

      vn_var(i) := substr(vn_message, 1, vn_pos - 1);

      vn_message := substr(vn_message, vn_pos + 3);
    END LOOP;

    vn_var(i + 1) := vn_message;

    FOR C2 IN (SELECT A.ACNT_NO,
              A.STK_CD,
              replace(A.CNTE, '/', '?_?') CNTE,
              A.PROC_DT,
              decode(C.ACNT_TP, 'P', 'OWNE', 'NOMI') ACNT_TP,
              decode(VN.FSS_GET_STK_MKT(A.STK_CD)
                ,'1'
                ,'XSTC'
                ,'2'
                ,'HSTC'
                ,'4'
                ,'XHNX'
                ,'3'
                ,'OTCO') STK_MKT_TP,
              decode(A.SB_LMT_QTY, 0, 'NRST', 'RSTR') QTY_NM,
			  decode(sign(to_number(to_char(vn.wdate,'yyyymmdd')) - to_number(a.APY_DT)),-1, 'PEND' , 'NORM') STK_TP,
              decode(A.SB_LMT_QTY, 0, '1', '2') QTY_TP,
              decode(A.SB_LMT_QTY, 0, A.QTY, A.SB_LMT_QTY) STK_QTY,
              decode(D.SEX_TP, '1', 'MR01', 'MADA') SEX_TP,
              replace(C.IDNO, '/', '?_?') IDNO,
               decode(D.IDNO_TP
								,'1'
								,'IDNO'
								,'2'
								,'CCPT'
								,'3'
								,'CORP'
								,'4'
								,'OTHR'
								,'5'
								,'FIIN'
								,'6'
								,'ARNU'
								,'7'
								,'GOVT') IDNO_TP,
              nvl(D.idno_iss_orga, '!') ISS_ORGA,
              nvl(D.idno_iss_dt, '!') ISS_DT,
              C.CUST_NM,
              D.BIRTH_DT,
              (SELECT CURR_CD
               FROM AAA03C20
              WHERE CTRY_CD = D.CTRY_CD) CURR_CD,
              DECODE(E.STK_TP, '20', 'FAMT', 'UNIT') UNIT,
              A.BOS_SEQ_NO,
              VN.fvsd_getbiccode(i_sec_cd) BICCODE,
			        A.SEQ_NO,
              decode(A.VSD_BRCH, '02', 'VSDSVN02', 'VSDSVN01') VSD_BRCH_NM,
              A.VSD_BRCH
           FROM VN.SSB05M00 A,
              VN.SSI01M00 E,
              VN.AAA01M00 C,
              VN.AAA02M00 D
          WHERE A.STK_CD = E.STK_CD
            AND A.ACNT_NO = C.ACNT_NO
            AND A.SUB_NO = C.SUB_NO
            AND C.IDNO = D.IDNO
            AND A.PROC_DT = vn_var(1)
            AND A.BOS_SEQ_NO = vn_var(2)
            AND A.BOS_STAT = '1'
            AND A.TRD_TP = '13')
    LOOP

      SELECT     BOS_SEQ_NO
      INTO    vn_prev_bos_seq
      FROM     VN.SSB05M00
      WHERE     ACNT_NO = C2.ACNT_NO
      AND     PROC_DT = C2.PROC_DT
      AND     SEQ_NO = C2.SEQ_NO
      AND      TRD_TP = '13'
      AND      ROWNUM < 2;

      if C2.STK_TP = 'PEND' then
        SELECT ISSU_CD INTO V_ISSU_CD
        FROM   VN.SSI01M00
        WHERE  STK_CD = C2.STK_CD;

        -- B?t d?u Block: Thông tin chung
        v_send_dat :=   ':16R:GENL' || chr(13) ||
              ':20C::SEME//' || C2.BOS_SEQ_NO || chr(13) ||
              ':23G:CANC' || chr(13) ||
              ':98A::PREP//' || to_char(SYSDATE, 'yyyymmdd') || chr(13) ||
              ':16R:LINK' || chr(13) ||
              ':20C::PREV//' || vn_prev_bos_seq || chr(13) ||
              ':16S:LINK' || chr(13) ||
              ':16R:LINK' || chr(13) ||
              ':20C::PCTI//'|| V_ISSU_CD || chr(13) ||
              ':16S:LINK' || chr(13) ||
              ':16S:GENL' || chr(13) ||

              -- B?t d?u Block: Thông tin giao d?ch
              ':16R:TRADDET' || chr(13) ||
              ':98A::SETT//' || C2.PROC_DT || chr(13) ||
              ':35B:/VN/' || C2.STK_CD || chr(13) ||
              ':16R:FIA' || chr(13) ||
              --':94B::PLIS//EXCH/' || C2.STK_MKT_TP || chr(13) ||
              ':12A::CLAS//' || C2.STK_TP || '/' || C2.QTY_TP || chr(13) ||
              --':70E::FIAN//' || C2.QTY_NM || chr(13) ||
              ':16S:FIA' || chr(13) ||
              ':70E::SPRO//' ||'SHAR'|| chr(13) ||
              ':16S:TRADDET' || chr(13) ||

             -- B?t d?u Block: Thông tin chi ti?t
              ':16R:FIAC' || chr(13) ||
              ':36B::SETT//' || C2.UNIT || '/' || C2.STK_QTY || chr(13) ||
              ':70D::DENC//' || C2.CNTE || chr(13) ||
              ':95P::ACOW//' || C2.BICCODE || chr(13) ||
              ':97A::SAFE//' || C2.ACNT_NO || chr(13) ||
              ':16S:FIAC' || chr(13) ||

             -- B?t d?u Block: Thông tin thanh toán
              ':16R:SETDET' || chr(13) ||
              ':22F::SETR//'|| 'TRAD' || chr(13) ||
              ':22F::STCO//' || 'PHYS' || chr(13) ||

             -- B?t d?u Block: Các d?i tác thanh toán
              ':16R:SETPRTY' || chr(13) ||
              ':95P::PSET//' || C2.VSD_BRCH_NM || chr(13) ||
              ':16S:SETPRTY' || chr(13) ||
              ':16R:SETPRTY' || chr(13) ||
              ':95P::DEAG//' || C2.BICCODE|| chr(13) ||
              ':16S:SETPRTY' || chr(13) ||
              ':16S:SETDET' || chr(13) ||

             -- B?t d?u Block: Thông tin nhà d?u tu
              ':16R:OTHRPRTY' || chr(13) ||
              ':95Q::INVE//' || C2.CUST_NM || chr(13) ||
                      C2.BIRTH_DT || chr(13) ||
                      C2.CURR_CD || chr(13) ||
              ':95S::ALTE/VISD/' || C2.IDNO_TP || '/' ||
											C2.CURR_CD || '/' || C2.IDNO || chr(13) ||
              ':70E::REGI//' || chr(13) ||
                      C2.ISS_ORGA || chr(13) ||
                      C2.ISS_DT || chr(13) ||
              ':16S:OTHRPRTY';
      else
        -- Bat dau Block: Thong tin chung
        v_send_dat :=   ':16R:GENL' || chr(13) ||
              ':20C::SEME//' || C2.BOS_SEQ_NO || chr(13) ||
              ':23G:CANC' || chr(13) ||
              ':98A::PREP//' || to_char(SYSDATE, 'yyyymmdd') || chr(13) ||
              ':16R:LINK' || chr(13) ||
              ':20C::PREV//' || vn_prev_bos_seq || chr(13) ||
              ':16S:LINK' || chr(13) ||
              --':16R:LINK' || chr(13) ||
              --':20C:PCTI' || chr(13) ||
              --':16S:LINK' || chr(13) ||
              ':16S:GENL' || chr(13) ||

              -- B?t d?u Block: Thông tin giao d?ch
              ':16R:TRADDET' || chr(13) ||
              ':98A::SETT//' || C2.PROC_DT || chr(13) ||
              ':35B:/VN/' || C2.STK_CD || chr(13) ||
              ':16R:FIA' || chr(13) ||
              --':94B::PLIS//EXCH/' || C2.STK_MKT_TP || chr(13) ||
              ':12A::CLAS//' || C2.STK_TP || '/' || C2.QTY_TP || chr(13) ||
              --':70E::FIAN//' || C2.QTY_NM || chr(13) ||
              ':16S:FIA' || chr(13) ||
              ':70E::SPRO//' ||'SHAR'|| chr(13) ||
              ':16S:TRADDET' || chr(13) ||

             -- B?t d?u Block: Thông tin chi ti?t
              ':16R:FIAC' || chr(13) ||
              ':36B::SETT//' || C2.UNIT || '/' || C2.STK_QTY || chr(13) ||
              ':70D::DENC//' || C2.CNTE || chr(13) ||
              ':95P::ACOW//' || C2.BICCODE || chr(13) ||
              ':97A::SAFE//' || C2.ACNT_NO || chr(13) ||
              ':16S:FIAC' || chr(13) ||

             -- B?t d?u Block: Thông tin thanh toán
              ':16R:SETDET' || chr(13) ||
              ':22F::SETR//'|| 'TRAD' || chr(13) ||
              ':22F::STCO//' || 'PHYS' || chr(13) ||

             -- B?t d?u Block: Các d?i tác thanh toán
              ':16R:SETPRTY' || chr(13) ||
              ':95P::PSET//' || C2.VSD_BRCH_NM || chr(13) ||
              ':16S:SETPRTY' || chr(13) ||
              ':16R:SETPRTY' || chr(13) ||
              ':95P::DEAG//' || C2.BICCODE|| chr(13) ||
              ':16S:SETPRTY' || chr(13) ||
              ':16S:SETDET' || chr(13) ||

             -- B?t d?u Block: Thông tin nhà d?u tu
              ':16R:OTHRPRTY' || chr(13) ||
              ':95Q::INVE//' || C2.CUST_NM || chr(13) ||
                      C2.BIRTH_DT || chr(13) ||
                      C2.CURR_CD || chr(13) ||
              ':95S::ALTE/VISD/' || C2.IDNO_TP || '/' ||
											C2.CURR_CD || '/' || C2.IDNO || chr(13) ||
              ':70E::REGI//' || chr(13) ||
                      C2.ISS_ORGA || chr(13) ||
                      C2.ISS_DT || chr(13) ||
              ':16S:OTHRPRTY';
      end if;

      INSERT INTO VN.VSD01M00
        (REG_DT,
         SEQ_NO,
         BIZ_CD,
         DAT_CD,
         SND_DAT,
         SND_TP,
         WORK_DTM,
         VSD_BRCH)
      VALUES
        (to_char(SYSDATE, 'yyyymmdd'),
         C2.BOS_SEQ_NO,
         i_biz_cd,
         '540',
         v_send_dat,
         '1',
         SYSDATE,
         C2.VSD_BRCH);

    END LOOP;

  END IF;

END PVSD_MT540;
/

