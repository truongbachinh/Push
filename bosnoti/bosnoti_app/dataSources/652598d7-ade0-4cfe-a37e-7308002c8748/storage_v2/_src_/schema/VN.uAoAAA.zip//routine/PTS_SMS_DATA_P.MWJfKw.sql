create PROCEDURE PTS_SMS_DATA_P (
    IS_SMS_SVC_TP		IN VARCHAR2,
	IS_STK_ORD_DT		IN VARCHAR2,
	IS_ACNT_MNG_BNH		IN VARCHAR2,
	ID_ORD_NO			IN NUMBER,
	IS_ACNT_NO			IN VARCHAR2,
	IS_SUB_NO			IN VARCHAR2,
	IS_STK_CD			IN VARCHAR2,
	ID_ORD_QTY			IN NUMBER,
	ID_ORD_PRI			IN NUMBER,
	IS_SELL_BUY_TP		IN VARCHAR2,
	IS_STK_ORD_TP		IN VARCHAR2,
	IS_CRRT_CNCL_TP		IN VARCHAR2,
	ID_MTH_QTY			IN NUMBER,
	ID_MTH_PRI			IN NUMBER,
	IS_ORD_TIME			IN VARCHAR2,
	IS_KFX_ACCP_NO		IN VARCHAR2,
	ID_NMTH_QTY			IN NUMBER,
	ID_ERR_CODE			IN OUT NUMBER,
	IS_ERR_MSG			OUT VARCHAR2
) IS

/*!
    \file     PTS_SMS_DATA_P
    \brief    sms data insert

    \section intro Program Information
        - Program Name              : PTS_SMS_DATA_P
        - Service Name              :
        - Related Client Program- Client Program ID :
        - Related Tables            : tso07m00
        - Dev. Date                 : 2007/12/19
        - Developer                 : vnnskim
        - Business Logic Desc.      :
        - Latest Modification Date  :

    \section history Program Modification History
        - 1.0  2007/12/19    vnnskim       First make
        - 1.1  2008/03/24    SB.LEE        mobile column add

    \section hardcoding Hard-Coding List

    \section info Additional Reference Comments
*/

TS_SDATE	VARCHAR2(8)  := ' ';
TS_WDATE	VARCHAR2(8)  := ' ';
TS_TEL_NO   VARCHAR2(20) := ' ';
TD_RTN		NUMBER		 := 0;


BEGIN
	ID_ERR_CODE := 0;
	IS_ERR_MSG := ' ';

	/*-----------------------------------------------------------------------*/
    /* Search customer's mobile phone number                                 */
    /*-----------------------------------------------------------------------*/
    SELECT  B.MOBILE
      INTO  TS_TEL_NO
      FROM  VN.AAA01M00 A,
            VN.AAA02M10 B
     WHERE  A.ACNT_NO = IS_ACNT_NO
       AND  A.SUB_NO  = IS_SUB_NO
       AND  A.IDNO    = B.IDNO
       AND  B.SMS_YN  = 'Y'
       AND  B.MOBILE  IS NOT NULL;

	/*-----------------------------------------------------------------------*/
    /* order date check : order can not                                      */
    /*-----------------------------------------------------------------------*/

    INSERT INTO VN.TSO07M00
	(
		SMS_DATA_MAK_DT,
		SMS_SEQ_NO,
		SMS_SVC_TP,
		STK_ORD_DT,
		ACNT_MNG_BNH,
		ORD_NO,
		ACNT_NO,
		SUB_NO,
		CUST_NM,
		MOBILE,
		STK_CD,
		ORD_QTY,
		ORD_PRI,
		SELL_BUY_TP,
		STK_ORD_TP,
		CRRT_CNCL_TP,
		MTH_QTY,
		NMTH_QTY,
		MTH_PRI,
		ORD_TIME,
		KFX_ACCP_NO,
		PROC_RSLT_TP,
		WORK_MN,
		WORK_DTM,
		WORK_TRM
	) VALUES (
		VN.VWDATE(),
		VN.TSO07M00_SEQ.NEXTVAL,
		IS_SMS_SVC_TP,
		IS_STK_ORD_DT,
		IS_ACNT_MNG_BNH,
		ID_ORD_NO,
		IS_ACNT_NO,
		IS_SUB_NO,
		VN.FAA_ACNT_NM_G(IS_ACNT_NO, IS_SUB_NO),
		TS_TEL_NO,
		IS_STK_CD,
		ID_ORD_QTY,
		ID_ORD_PRI,
		IS_SELL_BUY_TP,
		IS_STK_ORD_TP,
		IS_CRRT_CNCL_TP,
		ID_MTH_QTY,
		ID_NMTH_QTY,
		ID_MTH_PRI,
		IS_ORD_TIME,
		IS_KFX_ACCP_NO,
		'01',
		'SMS',
		SYSDATE,
		'SMS'
	);

	/*-----------------------------------------------------------------------*/
    /* Update state of SMS                                                   */
    /*-----------------------------------------------------------------------*/
    UPDATE VN.TSO01M00
       SET SMS_PROC_YN = 'Y'
     WHERE BNH_CD = IS_ACNT_MNG_BNH
       AND ORD_NO = ID_ORD_NO;


END PTS_SMS_DATA_P;
/

