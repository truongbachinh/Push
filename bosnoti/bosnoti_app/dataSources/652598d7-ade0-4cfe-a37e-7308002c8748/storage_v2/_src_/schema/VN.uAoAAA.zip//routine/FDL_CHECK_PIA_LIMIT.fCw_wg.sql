create FUNCTION fdl_check_pia_limit
(
    i_acnt_no        in   varchar2,
    i_sub_no         in   varchar2,
    i_pia_amt        in   number,
    i_rt_tp          in   varchar2
)   return  VARCHAR2 AS

    o_pia_stat            VARCHAR2(1) := null;

    t_acnt_pia_remain     NUMBER := 0;

begin

/*============================================================================*/
/* Valiabl Initialize
/*============================================================================*/
    t_acnt_pia_remain   :=  0;
    o_pia_stat          :=  ' ';

    IF  i_rt_tp  =  'ONL' THEN
        select vn.fdl_get_pia_limit(i_acnt_no, i_sub_no, '00')
          into t_acnt_pia_remain
          from dual
        ;
        IF i_pia_amt > t_acnt_pia_remain THEN
           o_pia_stat := 'Y';
        ELSE
           o_pia_stat := 'N';
        END IF;

        RETURN o_pia_stat;

    ELSIF  i_rt_tp  =  'OFF' THEN
        select vn.fdl_get_pia_limit(i_acnt_no, i_sub_no, '03')
          into t_acnt_pia_remain
          from dual
        ;
        IF i_pia_amt > t_acnt_pia_remain THEN
           o_pia_stat := 'Y';
        ELSE
           o_pia_stat := 'N';
        END IF;

        RETURN o_pia_stat;

    ELSE
        RETURN ' ';
    END IF;

END fdl_check_pia_limit;
/

