create FUNCTION    fdl_get_cust_lnd_limit
(
    i_acnt_no      in  VARCHAR2
    ,i_sub_no      in  VARCHAR2
)
  return number   as
  /*!
     \file     fdl_get_cust_lnd_limit.sql
     \brief    fdl_get_cust_lnd_limit
     \section intro Program Information
          - Program Name              :
          - Service Name              :
          - Related Client Program- Client Program ID :
          - Related Tables            :
          - Dev. Date                 : 20210723
          - Developer                 : TienLH
          - Business Logic Desc.      : Han muc kha dung cua khach hang
          - Modify by                 :
          - Latest Modification Date  :
   */

    t_cust_use_amt          NUMBER  := 0;
    t_cust_max_amt          NUMBER  := 0;
    t_cust_limit_amt        NUMBER  := 0;
    t_acnt_sub_max_amt      NUMBER  := 0;
    t_acnt_sub_use_amt      NUMBER  := 0;
    t_acnt_sub_limit_amt    NUMBER  := 0;
    t_cust_lnd_limit        NUMBER  := 0;

    t_err_msg VARCHAR2(500);

BEGIN

    /*Lay han muc theo kh duoc setup*/
    BEGIN
        vn.pdl_get_lnd_all_sub_limit(i_acnt_no, t_cust_max_amt);
    END;

    /*Han muc da dung cua kh*/
    BEGIN
        SELECT vn.fdl_get_mrgn_expt_amt(i_acnt_no, '%', '3')
        INTO t_cust_use_amt          /*G*/
        FROM dual;
    EXCEPTION WHEN OTHERS THEN
        t_err_msg := vn.fxc_get_err_msg('V', '46056');
        vn.pxc_log_write('fdl_get_cust_lnd_limit',
                        ' Han muc da dung cua tk error: ' || t_err_msg || ' ACNT_NO=' || i_acnt_no  );
        raise_application_error(-20100,
                                t_err_msg ||
                                ' fdl_get_cust_lnd_limit: ACNT_NO =' || i_acnt_no);
    END;

    /*Han muc kha dung con lai cua kh*/
    t_cust_limit_amt := greatest(t_cust_max_amt - t_cust_use_amt, 0);

    /*Lay han muc theo tk-sub duoc setup*/
    BEGIN
        SELECT vn.fdl_get_acnt_sub_limit(i_acnt_no, i_sub_no)
        INTO t_acnt_sub_max_amt
        FROM dual;
    EXCEPTION WHEN OTHERS THEN
        t_err_msg := vn.fxc_get_err_msg('V', '46051');
        vn.pxc_log_write('fdl_get_cust_lnd_limit',
                        ' fdl_get_acnt_sub_limit error: ' || t_err_msg || ' ACNT_NO=' ||
                        i_acnt_no || '-' || i_sub_no );
        raise_application_error(-20100,
                                t_err_msg ||
                                ' fdl_get_acnt_sub_limit: csr ACNT_NO =' ||
                                i_acnt_no || '-' || i_sub_no );
    END;

    /*Han muc da dung cua tk - sub*/
    BEGIN
        SELECT vn.fdl_get_mrgn_expt_amt(i_acnt_no, i_sub_no, '3')
        INTO t_acnt_sub_use_amt         /*E*/
        FROM dual;
    EXCEPTION WHEN OTHERS THEN
        t_err_msg := vn.fxc_get_err_msg('V', '46055');
        vn.pxc_log_write('fdl_get_cust_lnd_limit',
                        ' Han muc da dung cua sub tk error: ' || t_err_msg || ' ACNT_NO=' ||
                        i_acnt_no || '-' || i_sub_no);
        raise_application_error(-20100,
                                t_err_msg ||
                                ' fdl_get_cust_lnd_limit: ACNT_NO_STK_i_tp=' ||
                                i_acnt_no || '-' || i_sub_no );
    END;

    /*Han muc kha dung con lai cua tk- sub*/
    t_acnt_sub_limit_amt := greatest(t_acnt_sub_max_amt - t_acnt_sub_use_amt, 0);

    /*Han muc khach hang = Min ( Han muc kha dung con lai cua kh , Han muc kha dung con lai cua tk- sub)*/
    t_cust_lnd_limit := least(t_cust_limit_amt, t_acnt_sub_limit_amt);

    vn.pxc_log_write('fdl_get_cust_lnd_limit', 'i_acnt_no = '|| i_acnt_no ||'  i_sub_no = ' || i_sub_no ||
                         '  t_cust_max_amt = '|| t_cust_max_amt || '  t_cust_use_amt = ' || t_cust_use_amt || '  t_cust_limit_amt = '|| t_cust_limit_amt ||
                         '  t_acnt_sub_max_amt = '|| t_acnt_sub_max_amt || '  t_acnt_sub_use_amt = ' || t_acnt_sub_use_amt || '  t_acnt_sub_limit_amt = '|| t_acnt_sub_limit_amt || '  t_cust_lnd_limit = '|| t_cust_lnd_limit);

    RETURN  t_cust_lnd_limit;

END fdl_get_cust_lnd_limit;
/

