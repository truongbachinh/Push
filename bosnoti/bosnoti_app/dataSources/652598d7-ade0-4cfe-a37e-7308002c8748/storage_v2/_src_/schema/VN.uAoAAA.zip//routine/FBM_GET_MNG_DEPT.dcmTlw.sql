create function fbm_get_mng_dept(
    i_dept_cd           varchar2,
    i_mng_dept_rank     varchar2,
    i_dt                varchar2
)
return varchar2
/*
    select vn.fbm_get_mng_dept(
        '111',      -- i_dept_cd           varchar2,
        '03',       -- i_mng_dept_rank     varchar2,
        vwdate      -- i_dt                varchar2
    ) a
    from dual;
*/

as
    t_mng_dept_cd           xcc90m01.dept_cd%type;

    t_proc_nm               varchar2(30)    := 'fbm_get_mng_dept';
    t_vwdate                varchar2(8)     := vwdate;
    t_err_msg               varchar2(500)   := ' ';

    o_mng_dept_cd           xcc90m01.dept_cd%type;
begin
    begin
        select
            nvl(xc.dept_cd, '!') dept_cd
        into
            t_mng_dept_cd
        from table(vn.fbm_get_sub_item_hier(
                            '4',                -- i_tp             varchar2(15),
                            i_dept_cd,          -- i_dept_cd        varchar2(15),
                            i_dt                -- i_dt             varchar2(8)
                            )
                        ) hier
        inner join vn.xcc90m01 xc             -- Bang Phong ban
        on hier.parent_no = xc.dept_cd
        and xc.dept_rank = i_mng_dept_rank    -- Cap bac phong ban
        and hier.parent_no is not null
        ;
    exception
        when no_data_found then
            t_mng_dept_cd := '!';
        when others then 
            t_err_msg  := 'Error when getting data from xcc90m01:' 
                            || ' i_dept_cd: '           || i_dept_cd
                            || ' i_mng_dept_rank: '     || i_mng_dept_rank
                            || ' i_dt'                  || i_dt
                            || '. '
                            || sqlcode || ' - ' || sqlerrm;
            vn.pxc_log_write(t_proc_nm, t_err_msg);
            raise_application_error(-20100,t_err_msg);
    end;

    o_mng_dept_cd := t_mng_dept_cd;

    return o_mng_dept_cd;

end fbm_get_mng_dept;
/

