create function fdl_get_acnt_stk_all_lnd_limit(
    i_acnt_no   varchar2,
    i_sub_no    varchar2
)
return number

/*
    Description:
        - Get the total stock loan limit that account is owning
    Sample call:
        declare
            o_cnt   number;

        begin
            vn.fdl_get_acnt_stk_all_lnd_limit(
                '039C001993',   -- i_acnt_no   varchar2,
                '01'            -- i_sub_no    varchar2
            );
        end;
*/
as
    t_proc_nm           varchar2(50)    := 'fdl_get_acnt_stk_all_lnd_limit';
    t_vwdate            varchar2(8)     := null;
    t_sum_stk_limit     number          := 0;
    t_acnt_grp_no       varchar2(15)    := null;
begin
    vn.pxc_log_write(t_proc_nm, '');

    t_vwdate        := vn.vwdate;
    t_acnt_grp_no   := vn.faa_acnt_get_grp_no(i_acnt_no, i_sub_no, '2', t_vwdate);

    begin
        select sum(vn.fdl_get_stk_sum_lnd_limit(acnt_no, sub_no, stk_cd)) sum_stk_limit
        into t_sum_stk_limit
        from (
            select distinct
                acnt_no,
                sub_no,
                stk_cd
            from (
                select
                    acnt_no,
                    sub_no,
                    stk_cd,
                    able_qty + buy_mth_qty - sell_qty   own_qty ,
                    ass_tp,
                    vn.fdl_get_mrgn_basket_rt(
                        acnt_no,
                        sub_no,
                        t_acnt_grp_no,
                        '',
                        stk_cd,
                        ass_tp,
                        t_vwdate
                    ) stk_ssr_basket_rt
                from vn.acnt_sbst_own
                where acnt_no = i_acnt_no
                and sub_no = i_sub_no
            )
            where own_qty * stk_ssr_basket_rt > 0
        )
        ;
    exception
        when others then
            t_sum_stk_limit := 0;
    end;

    t_sum_stk_limit := nvl(t_sum_stk_limit, 0);

    vn.pxc_log_write(t_proc_nm, 
                        'i_acnt_no = '              || i_acnt_no
                        || ', i_sub_no = '          || i_sub_no
                        || ', t_sum_stk_limit = '   || t_sum_stk_limit
    );

    return t_sum_stk_limit;

end fdl_get_acnt_stk_all_lnd_limit;
/

