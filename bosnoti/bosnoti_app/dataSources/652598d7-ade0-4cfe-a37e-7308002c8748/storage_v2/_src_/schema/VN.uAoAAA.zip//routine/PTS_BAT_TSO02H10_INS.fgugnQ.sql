create PROCEDURE PTS_BAT_TSO02H10_INS (
    I_WORK_DT       IN      VARCHAR2,       -- DATE(YYYYMMDD)
    I_WORK_MN		IN		VARCHAR2,
    I_WORK_TRM		IN		VARCHAR2,
	O_PROC_CNT      IN  OUT NUMBER          -- PROC DATA COUNT
) AS

/*!
    \FILE     PTS_BAT_TSO20H00_INS
	\BRIEF    TSO02H10 SELECT, TSO02H10 INSERT

	\SECTION INTRO PROGRAM INFORMATION
		- PROGRAM NAME              : PTS_BAT_TSO02H10_INS
		- SERVICE NAME              :
		- RELATED CLIENT PROGRAM- CLIENT PROGRAM ID :
		- RELATED TABLES            : TSO02H10, TSO02H10
		- DEV. DATE                 : 2008/02/10
		- DEVELOPER                 : SB.LEE
		- BUSINESS LOGIC DESC.      :
		- LATEST MODIFICATION DATE  :

	\SECTION HISTORY PROGRAM MODIFICATION HISTORY
		- 1.0  2008/02/10

	\SECTION HARDCODING HARD-CODING LIST

	\SECTION INFO ADDITIONAL REFERENCE COMMENTS
*/

	t_err_txt				varchar2(200) := Null;

    t_err_msg    varchar2(500);
BEGIN


	delete 	TSO02H10
	where	dt = i_work_dt;

    FOR  C1  IN (
        SELECT  DT,
                BNH_CD,
                FIRST_ORG_ORD_NO,
                ACNT_NO,
                SUB_NO,
                BANK_CD,
                REF_NO,
                NVL(TD_CASH_PROF_AMT , 0) AS TD_CASH_PROF_AMT,
                NVL(TD_CDT_PROF_AMT , 0) AS TD_CDT_PROF_AMT,
                NVL(TD_CASH_PROF_GST_AMT, 0) AS TD_CASH_PROF_GST_AMT,
                DEL_YN,
                WORK_MN,
                WORK_DTM,
                WORK_TRM,
                CDT_TP
        FROM VN.TSO02M10
            WHERE DT < vn.fxc_vorderdt_g(vn.vhdate(), -3)
    ) LOOP
		BEGIN
            INSERT INTO VN.TSO02H10 (
                 DT,
                 BNH_CD,
                 FIRST_ORG_ORD_NO,
                 ACNT_NO,
                 SUB_NO,
                 BANK_CD,
                 REF_NO,
                 TD_CASH_PROF_AMT,
                 TD_CDT_PROF_AMT,
                 TD_CASH_PROF_GST_AMT,
                 DEL_YN,
                 WORK_MN,
                 WORK_DTM,
                 WORK_TRM,
                 CDT_TP
            ) VALUES (
                C1.DT,
                C1.BNH_CD,
                C1.FIRST_ORG_ORD_NO,
                C1.ACNT_NO,
                C1.SUB_NO,
                C1.BANK_CD,
                C1.REF_NO,
                C1.TD_CASH_PROF_AMT,
                C1.TD_CDT_PROF_AMT,
                C1.TD_CASH_PROF_GST_AMT,
                C1.DEL_YN,
                C1.WORK_MN,
                C1.WORK_DTM,
                C1.WORK_TRM,
                C1.CDT_TP
            );


		EXCEPTION
        WHEN  OTHERS         THEN
            vn.pxc_log_write('pts_bat_TSO02H10_ins','Insert cwd04h00 Err-['||sqlcode||']');
            t_err_txt  :=  'Insert TSO02H10 Err-'
                   ||  to_char(sqlcode);
			t_err_msg := vn.fxc_get_err_msg('V','2713');
			raise_application_error(-20100,t_err_msg||t_err_txt);
    	END;
    END LOOP;

	O_PROC_CNT := sql%rowcount;


END PTS_BAT_TSO02H10_INS;
/

