create PROCEDURE drv_pcw_inout_behaft_ins_p
(
    i_acnt_no               in        varchar2
,   i_sub_no                in        varchar2
,   i_proc_tp               in        varchar2
,   i_rmrk_cd               in        varchar2
,   i_trd_amt               in out        number
,   i_work_mn               in        varchar2
,   i_work_trm              in        varchar2
,   i_acc_act_cd            in        varchar2
,   i_cnte                  in        varchar2
,   i_seq_no                in        number
,   i_mdm_tp                in        varchar2
,   i_book_time             in        varchar2
,   i_bank_cd_off           in        varchar2
,   i_bank_acnt_no          in        varchar2
,   i_book_off_tp           in        varchar2
,   o_seq_no                out       number
,   i_bank_acnt_nm          in        varchar2 default ' '
,   i_bank_branch          in        varchar2 default ' '
,   i_fee_amt               in        number default 0
,   i_fee_type              in        varchar2 default ' '
,   i_acnt_amt              in        number  default 0
,   i_adt_amt               in        number  default 0
)
AS
    t_proc_nm        varchar2(100);
    t_err_txt        varchar2(200);
    t_err_msg               varchar2(500);

  tn_outq_dpo_bk           number := 0;
  t_seq_no                 number := 0;
  t_seq_no_cwd06           number := 0;
  t_check_bank             varchar2(2);





BEGIN

/*============================================================================*/
/* ???? ???                                                     */
/*============================================================================*/

    t_proc_nm        :=  'drv_pcw_inout_behaft_ins_p:';

vn.pxc_log_write('drv_pcw_inout_behaft_ins_p','i_acnt_no-'||i_acnt_no);
vn.pxc_log_write('drv_pcw_inout_behaft_ins_p','i_sub_no -'||i_sub_no);
vn.pxc_log_write('drv_pcw_inout_behaft_ins_p','i_proc_tp-'||i_proc_tp);
vn.pxc_log_write('drv_pcw_inout_behaft_ins_p','i_rmrk_cd-'||i_rmrk_cd);
vn.pxc_log_write('drv_pcw_inout_behaft_ins_p','i_trd_amt-'||i_trd_amt);
vn.pxc_log_write('drv_pcw_inout_behaft_ins_p','i_work_mn-'||i_work_mn);
vn.pxc_log_write('drv_pcw_inout_behaft_ins_p','i_work_trm-'||i_work_trm);
vn.pxc_log_write('drv_pcw_inout_behaft_ins_p','i_acc_act_cd-'||i_acc_act_cd);
vn.pxc_log_write('drv_pcw_inout_behaft_ins_p','i_cnte-'||i_cnte);
vn.pxc_log_write('drv_pcw_inout_behaft_ins_p','i_seq_no-'||i_seq_no);

/*insert co so*/
 t_seq_no_cwd06:=CWD06M00_SEQ.nextval;
     BEGIN
        insert  into  vn.CWD06M00
      (
       seq_no
      ,acnt_no
      ,sub_no
      ,inout_tp
      ,rmrk_cd
      ,trd_amt
      ,cncl_yn
      ,trd_seq_no
      ,work_mn
      ,work_dtm
      ,work_trm
      ,dpo_bank_acc
      ,acc_act_cd
      ,cnte
      ,etc_seq_no
      ,mdm_tp
      ,bank_cd_off
      ,bank_acnt_no
             )
        values
      (
       t_seq_no_cwd06
      ,Trim(i_acnt_no)
      ,i_sub_no
      ,i_proc_tp
      ,i_rmrk_cd
      ,i_trd_amt
      ,'N'
      ,0
      ,i_work_mn
      ,sysdate
      ,i_work_trm
      ,i_acc_act_cd
      ,i_acc_act_cd
      ,i_cnte
      ,to_number(i_seq_no)
      ,i_mdm_tp
      ,i_bank_cd_off
      ,i_bank_acnt_no
             );
    EXCEPTION
        WHEN  OTHERS         THEN
            t_err_txt  :=  t_proc_nm
                   ||  'cwd06m00_new_insert_err:'
                   ||  to_char(sqlcode);
            vn.pxc_log_write('drv_pcw_inout_behaft_ins_p','t_err_txt-'||t_err_txt);
      t_err_msg := vn.fxc_get_err_msg('V','9008');
      raise_application_error(-20100,t_err_msg||t_err_txt);
    END;
  /*insert cho phai sinh*/
     t_seq_no:=DRCWDM06_SEQ.nextval;
    
     BEGIN
        insert  into  vn.DRCWDM06
      (
       seq_no
      ,acnt_no
      ,sub_no
      ,trd_dt
      ,inout_tp
      ,rmrk_cd
      ,trd_amt
      ,cncl_yn
      ,trd_seq_no
      ,work_mn
      ,work_dtm
      ,work_trm
      ,dpo_bank_acc
      ,acc_act_cd
      ,cnte
      ,etc_seq_no
      ,mdm_tp
      ,bank_cd_off
      ,bank_acnt_no
      ,SEQ_CWD06M00
      ,bank_acnt_nm
      ,bank_branch
      ,fee_amt
      ,fee_type
      ,acnt_amt
      ,adt_amt
      ,cbp_type
      ,trans_stt 
             )
        values
      (
       t_seq_no
      ,Trim(i_acnt_no)
      ,i_sub_no
      ,vn.vwdate
      ,i_proc_tp
      ,i_rmrk_cd
      ,i_trd_amt
      ,'N'
      ,0
      ,i_work_mn
      ,sysdate
      ,i_work_trm
      ,i_acc_act_cd
      ,i_acc_act_cd
      ,i_cnte
      ,to_number(i_seq_no)
      ,i_mdm_tp
      ,i_bank_cd_off
      ,i_bank_acnt_no
      ,t_seq_no_cwd06
      ,i_bank_acnt_nm
      ,i_bank_branch
      ,i_fee_amt
      ,i_fee_type
      ,i_acnt_amt
      ,i_adt_amt
      ,'P' 
      ,'N'
             );
    EXCEPTION
        WHEN  OTHERS         THEN
            t_err_txt  :=  t_proc_nm
                   ||  'cwd06m00_new_insert_err:'
                   ||  to_char(sqlcode);
            vn.pxc_log_write('drv_pcw_inout_behaft_ins_p','t_err_txt-'||t_err_txt);
      t_err_msg := vn.fxc_get_err_msg('V','9008');
      raise_application_error(-20100,t_err_msg||t_err_txt);
    END;
    
    
  if (i_proc_tp = '02') or (i_proc_tp = '04') then
    if i_fee_type ='E' then
     i_trd_amt := i_trd_amt + i_fee_amt;
     else
     i_trd_amt := i_trd_amt;
     end if;
     BEGIN
     vn.drv_pcw_waitting_bk_ubk_p
     (
           '01'
          , vn.vhdate
      , i_acnt_no
      , i_sub_no
      , i_trd_amt
      , i_mdm_tp
      , i_work_mn
      , i_work_trm
      , tn_outq_dpo_bk
         );

       EXCEPTION
      WHEN OTHERS THEN
         t_err_txt := t_proc_nm
            || 'pcw_waitting_block_p_err:'
            || to_char(sqlcode);
               t_err_msg := vn.fxc_get_err_msg('V','9009');
         raise_application_error(-20100,t_err_msg||t_err_txt);
       END;

     end if;
     o_seq_no := t_seq_no;
       

end  drv_pcw_inout_behaft_ins_p;
/

