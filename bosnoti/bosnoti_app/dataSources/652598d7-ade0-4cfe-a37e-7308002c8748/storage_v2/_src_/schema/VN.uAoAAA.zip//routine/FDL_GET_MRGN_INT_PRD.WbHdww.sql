create function    fdl_get_mrgn_int_prd
(
	i_lnd_dt     in varchar2,
	i_rpy_dt     in varchar2,
	i_rpy_dt_tp  in number, --0 is repay date, others are changed interest ratio date
	i_expr_dt    in varchar2,
	i_dt         in varchar2,
	i_dt_tp      in number, -- 1 last_rpy_dt, 2: changed interest ratio date
	i_int_rpy_tp in varchar2,
	i_tp         in varchar2
) return number as

  t_lnd_prd NUMBER := 0;
  t_dly_prd NUMBER := 0;

  t_sec_cd varchar2(3) := '068';

  t_err_txt varchar2(80); -- error text buffer

begin

  /*============================================================================*/
  /*                                                                            */
  /* for Margin check fdl_get_mrgn_rt_01 key '08'                               */
  /* i_tp                                                                       */
  /* 1 : lnad interest period : ÀÌÀÚ ÀÏ¼ö                                       */
  /* 2 : lnd delay interest period : ¿¬Ã¼ ÀÌÀÚ ÀÏ¼ö                             */
  /*============================================================================*/
if t_sec_cd in ('045') then
    if i_expr_dt > i_rpy_dt then
		t_dly_prd := 0;
	    if i_dt_tp = 1 and i_rpy_dt_tp <> 0 then
			t_lnd_prd := to_date(i_rpy_dt, 'yyyymmdd') -
			             to_date(i_dt, 'yyyymmdd') - 1;
			t_lnd_prd := greatest(t_lnd_prd, 0);
	    else
			t_lnd_prd := to_date(i_rpy_dt, 'yyyymmdd') -
			             to_date(i_dt, 'yyyymmdd');
		end if;
    else
	    if i_expr_dt <= i_dt then
			t_lnd_prd := 0;

		    if (i_rpy_dt_tp = 0 and i_dt_tp = 1) or
		   	   (i_rpy_dt_tp <> 0 and i_dt_tp <> 1) then
			    t_dly_prd := to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_dt, 'yyyymmdd');
				t_dly_prd := greatest(t_dly_prd, 0);
		    elsif i_rpy_dt_tp = 0 and i_dt_tp <> 1 then
				t_dly_prd := to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_dt, 'yyyymmdd') + 1;
				t_dly_prd := greatest(t_dly_prd, 0);
		    else
			  t_dly_prd := to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_dt, 'yyyymmdd') - 1;
		    end if;
		else
            if i_rpy_dt_tp = 0 and i_dt_tp = 1 then
		        t_lnd_prd := to_date(i_expr_dt, 'yyyymmdd') - to_date(i_dt, 'yyyymmdd') - 1;
		        t_lnd_prd := greatest(t_lnd_prd, 0);
		        t_dly_prd := to_date(i_rpy_dt, 'yyyymmdd') -  to_date(i_expr_dt, 'yyyymmdd') + 1;
	        elsif i_rpy_dt_tp = 0 and i_dt_tp <> 1 then
				t_lnd_prd := to_date(i_expr_dt, 'yyyymmdd') - to_date(i_dt, 'yyyymmdd');
				t_dly_prd := to_date(i_rpy_dt, 'yyyymmdd') -  to_date(i_expr_dt, 'yyyymmdd') ;
	        elsif i_rpy_dt_tp = 1 and i_dt_tp = 1 then
				t_lnd_prd := to_date(i_expr_dt, 'yyyymmdd') - to_date(i_dt, 'yyyymmdd') - 1;
				t_lnd_prd := greatest(t_lnd_prd, 0);
				t_dly_prd := to_date(i_rpy_dt, 'yyyymmdd') -  to_date(i_expr_dt, 'yyyymmdd');
	        else
				t_lnd_prd := to_date(i_expr_dt, 'yyyymmdd') - to_date(i_dt, 'yyyymmdd');
				t_dly_prd := to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_expr_dt, 'yyyymmdd');
	        end if;
		end if;
	end if;
ELSE
    if  i_expr_dt > i_rpy_dt then
        t_dly_prd  :=  0;

        if  i_int_rpy_tp = '1' then
            t_lnd_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_dt, 'yyyymmdd');
        elsif i_int_rpy_tp = '2' then
            t_lnd_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_dt, 'yyyymmdd');
        else
            t_lnd_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_dt, 'yyyymmdd');
        end if;

    else
        if  i_int_rpy_tp = '1' then
            if  i_expr_dt > i_dt then
                /*==============================================*/
                /* loan period : expire date ~ last repay date  */
                /* dely prriod : repay date ~ expire date       */
                /*==============================================*/
                t_lnd_prd  :=  to_date(i_expr_dt, 'yyyymmdd') - to_date(i_dt, 'yyyymmdd');
                t_dly_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_expr_dt, 'yyyymmdd');
            else
                /*==============================================*/
                /* loan period :                                */
                /* dely prriod : repay date ~ last repay date   */
                /*==============================================*/
                t_dly_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_dt, 'yyyymmdd');
            end if;
        elsif i_int_rpy_tp = '2' then
            /*==============================================*/
            /* loan period : expire date ~ land date        */
            /* dely prriod : repay date ~ expire date       */
            /*==============================================*/
            t_lnd_prd  :=  to_date(i_expr_dt, 'yyyymmdd') - to_date(i_dt, 'yyyymmdd');
            t_dly_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_expr_dt, 'yyyymmdd');
        end if;
    end if;
end if;

  /* return value setting */
  if i_tp = '1' then
    return t_lnd_prd;
  elsif i_tp = '2' then
    return t_dly_prd;
  else
    return t_dly_prd;
  end if;

end fdl_get_mrgn_int_prd;
/

