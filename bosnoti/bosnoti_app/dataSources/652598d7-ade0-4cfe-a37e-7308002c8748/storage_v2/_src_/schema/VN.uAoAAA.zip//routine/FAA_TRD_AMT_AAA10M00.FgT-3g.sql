create function faa_trd_amt_aaa10m00
 (  i_trd_dt         in   varchar2,
    i_acnt_no        in   varchar2,
    i_sub_no         in   varchar2,
    i_tp             in   varchar2
)   RETURN  NUMBER AS
/*!
   \file     faa_trd_amt_aaa10m00.sql
   \brief    Get the trd_dt
   \new      20150601

*/
 t_trd_amt   number  := 0;

begin
     IF i_tp = '1'  THEN
       BEGIN
         SELECT nvl(sum(trd_amt),0)
         INTO t_trd_amt
         from  vn.aaa10m00
         where  trd_dt = i_trd_dt
          AND acnt_no = i_acnt_no
           AND sub_no = i_sub_no
           and cncl_yn = 'N'  --  except orginal tranjaction
           and trd_dt || acnt_no || sub_no || lpad(trd_seq_no,3,'0') > '0'
           and (trd_tp in ('10', '99', '14', '99')
          or substr(rmrk_cd, 1, 2) in ('99', '99', '99', '99','99','99', '99', '99', '99', '99'))
         ;
         exception when others then t_trd_amt := 0;
        END ;
      END IF;
      IF i_tp = '2'  THEN
         BEGIN
         SELECT nvl(sum(trd_amt),0)
         INTO t_trd_amt
         from  vn.aaa10m00
         where  trd_dt = i_trd_dt
        AND acnt_no = i_acnt_no
        AND sub_no = i_sub_no
        and cncl_yn = 'N'  --  except orginal tranjaction
        and trd_dt || acnt_no || sub_no || lpad(trd_seq_no,3,'0') > '0'
        and (trd_tp in ('99', '11', '99', '15')
          or substr(rmrk_cd, 1, 2) in ('99', '99', '99', '99','99','99', '99', '99', '99', '99'))
        ORDER BY  acnt_no || sub_no || lpad(trd_seq_no,3,'0')

         ;
         exception when others then t_trd_amt := 0;
           END ;
         END IF;


  return(t_trd_amt);
end faa_trd_amt_aaa10m00;
/

