create view V_INVESTOR_INFO as
select distinct a.acnt_no so_taikhoan,
       a.sub_no so_tieukhoan,
       b.cust_nm ten_khachhang,
       a.idno so_cmnd,
       b.idno_iss_dt ngaycap_cmnd,
       b.idno_iss_orga noicap_cmnd,
       decode(nvl(trim(c.home_addr),'!') ,'!' ,  nvl(Trim(c.office_addr),'!') , c.home_addr ) diachi,
       c.home_tel so_dtcodinh,
       c.mobile so_didong,
       c.fax    so_fax,
       c.email  email,
       decode(b.sex_tp, '1', '001', '002') gioitinh,
       b.birth_dt ngaysinh,
       d.ctry_nm ten_quocgia,
       decode(b.grp_tp, '1', 'I', 'B') loai_khachhang,
       b.tax_cd maso_thue,
       b.grp_tp||b.frgn_tp nhom_khachhang,
       e.idno cmnd_uq,
       (select a.idno_iss_dt from aaa02m00 a where a.idno = e.idno) ngaycap_uq,
       (select a.idno_iss_orga from aaa02m00 a where a.idno = e.idno) noicap_uq,
       a.acnt_mng_bnh chinhanh,
       f.bank_acnt_no stk_nganhang,
       g.col_cd_tp_nm nganhang
      from  vn.aaa01m00 a ,
            vn.aaa02m00 b ,
            vn.aaa02m10 c ,
            vn.aaa03c20 d ,
            vn.aaa01m20 e,
            vn.aaa09m00 f,
            vn.xcc01c01 g
     where a.idno = b.idno
        and a.acnt_no = f.acnt_no (+)
        and f.bank_cd_off = g.col_cd_tp (+)
        and g.col_cd (+) = 'bank_cd_offline'
        and a.idno = c.idno(+)
        and b.ctry_cd = d.ctry_cd (+)
        and a.acnt_no = e.acnt_no (+)
        and a.sub_no = e.sub_no (+)
/

