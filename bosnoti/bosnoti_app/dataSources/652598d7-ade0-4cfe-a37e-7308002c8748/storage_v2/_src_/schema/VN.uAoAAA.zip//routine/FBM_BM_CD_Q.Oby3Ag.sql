create function fbm_bm_cd_q
(
	 i_cd_knd_tp	in   varchar2
	,I_stk_mkt_tp   in   varchar2
	,i_cd_id		in   varchar2
)
    return          varchar2
as
    o_cd_val		varchar2(100) ;
    t_err_txt       varchar2(100)  ; -- error text buffer

begin

/*============================================================================*/
/* ���� ���                                                                */
/*============================================================================*/
    o_cd_val  :=  NULL;
    t_err_txt  :=  NULL;

/*============================================================================*/
/* ���ȸ                                                                   */
/*============================================================================*/
    begin
      	select nvl(cd_detl_desc, '!')
		  into o_cd_val
          from vn.bmi01c00
         where cd_knd_tp = i_cd_knd_tp
           and cd_id = trim(I_stk_mkt_tp)||trim(i_cd_id)
           ;
    exception
        when  NO_DATA_FOUND  then
			return  '!';
        when  OTHERS         then
            t_err_txt  :=  '����-['||to_char(sqlcode)||']';
            raise_application_error (-20100, t_err_txt);
    end;

    return  o_cd_val;

end fbm_bm_cd_q;
/

