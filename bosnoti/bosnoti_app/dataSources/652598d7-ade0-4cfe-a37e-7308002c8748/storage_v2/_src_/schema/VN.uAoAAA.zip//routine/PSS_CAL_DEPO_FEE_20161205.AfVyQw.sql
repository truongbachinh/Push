create procedure pss_cal_depo_fee_20161205
( i_sec_cd     in   varchar2,
  i_proc_dt    in   varchar2,
  i_acnt_no    in   varchar2,
  i_sub_no     in   varchar2,
  i_stk_cd     in   varchar2,
  i_from_dt    in   varchar2,
  i_to_dt      in   varchar2,
  i_work_mn    in   varchar2,
  i_work_trm   in   varchar2,
  o_proc_cnt   out  number
 ) is

 vn_count number :=0;
 vn_limit_fee number :=0;
 --vn_tot_out_blk_fee number :=0;
-- vn_total_fee_blk number :=0;

/*var o_proc_cnt      number;
exec pss_cal_depo_fee('068','20150302', '%', '%', '%', '20150201', '20150228', 'SYSTEM', 'SYSTEM',:o_proc_cnt);
print o_proc_cnt*/

begin
   o_proc_cnt  := 0;
   /* insert ssb07m10 */
   vn.pxc_log_write('pss_cal_depo_fee', 'start' || '[' ||i_proc_dt || ','|| i_acnt_no|| ','|| i_sub_no || ',' || i_stk_cd || ',' || i_from_dt || ',' || i_to_dt || ']');

   for c1 in(
    SELECT acnt_no
           ,sub_no
           ,stk_cd
           ,dt
           ,sum(own_qty) tot_qty
           ,vn.fss_get_stk_tp(stk_cd) int_rt_tp
           ,(TO_DATE(TRIM(i_to_dt), 'YYYYMMDD') - TO_DATE(TRIM(i_from_dt), 'YYYYMMDD')) + 1 tot_dt_cnt
    FROM (

    SELECT to_char(vn.wdate,'yyyymmdd') dt
              ,a.acnt_no
              ,a.sub_no
              ,a.stk_cd
              ,nvl(a.own_qty,0)   own_qty
      FROM VN.SSB01m00  a
      WHERE  to_char(vn.wdate,'yyyymmdd') between i_from_dt and i_to_dt

      UNION ALL

      SELECT a.rgt_std_dt dt
              ,a.acnt_no
              ,a.sub_no
              ,a.stk_cd
              ,nvl(a.own_qty,0) + nvl(a.cd_qty,0)    own_qty
      FROM VN.SSB01H00  a
      WHERE  a.RGT_STD_DT  >= i_from_dt
      AND a.RGT_STD_DT <= i_to_dt

      UNION ALL

      SELECT b.dt
              ,a.acnt_no
        ,a.sub_no
              ,a.stk_cd
              ,nvl(a.own_qty,0) + nvl(a.cd_qty,0) own_qty
      FROM vn.ssb01h00 a,
        (SELECT to_char(dt_dt, 'yyyymmdd')dt FROM vn.xcc20m00
        WHERE    to_char(dt_dt, 'yyyymmdd') >= i_from_dt
        AND   to_char(dt_dt, 'yyyymmdd') <= i_to_dt
        AND holi_tp IN (1,2,3)) b
      WHERE rgt_std_dt = vn.fxc_vorderdt_g(to_date(b.dt,'yyyymmdd'),-1)
      )
    WHERE vn.faa_acnt_stat_g(acnt_no, sub_no) = '1'
    AND   acnt_no like i_acnt_no
  AND   sub_no like i_sub_no
    AND   stk_cd like i_stk_cd
    and nvl(vn.faa_acnt_check_fee(ACNT_NO, sub_no), 'N')= 'Y'
    GROUP BY acnt_no, sub_no, stk_cd, dt
    ) loop

    /* Already paid the PIT Dont Create new data */
    select count(*)
    into vn_count
    from vn.ssb07m00
    where acnt_no = c1.acnt_no
    and sub_no = c1.sub_no
    and mak_strt_dt = i_from_dt
    and rcpt_trd_no > 0
    and cncl_yn ='N';


    if (vn_count = 0) then

    delete vn.ssb07m10
    where acnt_no = c1.acnt_no
    and sub_no = c1.sub_no
    and mak_strt_dt = i_from_dt
    and stk_cd = c1.stk_cd
    and rgt_std_dt = c1.dt;

    vn.pxc_log_write('pss_cal_depo_fee', 'insert ssb07m10 with: ' || c1.acnt_no||'-'||c1.sub_no||'-'||c1.stk_cd);

    insert into vn.ssb07m10 (
      USEFEE_PAY_DT
      ,ACNT_NO
      ,SUB_NO
      ,STK_CD
      ,rgt_std_dt
      ,MAK_STRT_DT
      ,MAK_END_DT
      ,TOT_DT_CNT
      ,TOT_QTY
      ,INT_RT_TP
      ,WORK_MN
      ,WORK_DTM
      ,WORK_TRM
    )
    VALUES (
           i_proc_dt
           ,c1.acnt_no
           ,c1.sub_no
           ,c1.stk_cd
           ,c1.dt
           ,i_from_dt
           ,i_to_dt
           ,c1.tot_dt_cnt
           ,c1.tot_qty
           ,c1.int_rt_tp
           ,i_work_mn
           ,sysdate
           ,i_work_trm
    );
    end if;
  end loop;

  /* Hoai them 20150702: Jira 988*/
    select vn.fss_get_depo_limit_fee(i_sec_cd,'10','00')
    into vn_limit_fee
    from dual;

  /* insert ssb07m00 */
  for c2 in (
      select  a.usefee_pay_dt
        ,a.acnt_no
        ,a.sub_no
        ,a.mak_strt_dt
        ,a.mak_end_dt
        ,a.tot_dt_cnt
        ,sum(a.tot_qty) tot_qty
        ,ceil(sum(a.usefee)) use_fee
        ,b.ACNT_MNG_BNH
        ,b.AGNC_BRCH
    from
      (select  usefee_pay_dt
          ,acnt_no
          ,sub_no
          ,mak_strt_dt
          ,mak_end_dt
          ,tot_dt_cnt
          ,sum(tot_qty) tot_qty
          ,ceil(sum(tot_qty) * vn.fss_get_depo_fee(i_sec_cd,int_rt_tp,'00')/30) usefee
      from ssb07m10
      group by acnt_no,sub_no,usefee_pay_dt,mak_strt_dt,mak_end_dt,tot_dt_cnt,int_rt_tp) a,
      vn.aaa01m00 b
    where a.acnt_no = b.acnt_no
  and a.sub_no = b.sub_no
    and b.acnt_stat = '1'
    and a.usefee_pay_dt = i_proc_dt
    and a.mak_strt_dt = i_from_dt
    and a.mak_end_dt = i_to_dt
    group by a.acnt_no,a.sub_no,a.usefee_pay_dt,a.mak_strt_dt,a.mak_end_dt,a.tot_dt_cnt,b.ACNT_MNG_BNH,b.AGNC_BRCH
    ) loop

    /* Already paid the PIT Dont Create new data */
    select count(*)
    into vn_count
    from vn.ssb07m00
    where acnt_no = c2.acnt_no
  and sub_no = c2.sub_no
    and mak_strt_dt = i_from_dt
    and rcpt_trd_no > 0
    and cncl_yn = 'N';

    if (vn_count = 0) then
      select count(*)
      into vn_count
      from vn.ssb07m00
      where acnt_no = c2.acnt_no
    and sub_no = c2.sub_no
      and mak_strt_dt = i_from_dt;

      /* Update to X */
      if (vn_count > 0) then

         update vn.ssb07m00
         set cncl_yn = 'X'
         where cncl_yn = 'N'
         and mak_strt_dt = i_from_dt
         and acnt_no = c2.acnt_no
         and sub_no = c2.sub_no;

      end if;

      /* get seq */
      select count(*)
      into vn_count
      from vn.ssb07m00
      where acnt_no = c2.acnt_no
    and sub_no = c2.sub_no
      and mak_strt_dt = i_from_dt
      and usefee_pay_dt = i_proc_dt;

    if round(c2.use_fee/10) >= vn_limit_fee then /* Hoai them 20150702: Jira 988*/
      insert into vn.ssb07m00 (
            USEFEE_PAY_DT
            ,ACNT_NO
      ,SUB_NO
            ,MAK_STRT_DT
            ,MAK_END_DT
            ,TOT_DT_CNT
            ,TOT_QTY
            ,TOT_AVBL_QTY
            ,APY_INT_RT
            ,USEFEE
            ,ACNT_MNG_BNH
            ,AGNC_BRCH
            ,RCPT_TRD_NO
            ,ERR_CONT
            ,CNCL_YN
            ,CNCL_TRD_NO
            ,WORK_MN
            ,WORK_DTM
            ,WORK_TRM
            ,SEQ_NO
      )
      VALUES (
             c2.usefee_pay_dt
             ,c2.acnt_no
       ,c2.sub_no
             ,c2.MAK_STRT_DT
             ,c2.MAK_END_DT
             ,c2.tot_dt_cnt
             ,c2.tot_qty
             ,c2.tot_qty/10
             ,0
             ,round(c2.use_fee/10)
             ,c2.acnt_mng_bnh
             ,c2.agnc_brch
             ,0
             ,0
             ,'N'
             ,0
             ,i_work_mn
             ,sysdate
             ,i_work_trm
             ,vn_count +1
      );
      else
        delete vn.ssb07m10
         where acnt_no = c2.acnt_no
           and sub_no = c2.sub_no
           and usefee_pay_dt = i_proc_dt
           and mak_strt_dt = i_from_dt
           and mak_end_dt = i_to_dt;
      end if;
        /*begin
                 vn.pcw_waitting_bk_ubk_p
                           (i_sec_cd
                           ,'03'
                           ,vn.vwdate
                           ,c2.acnt_no
               ,c2.sub_no
                           ,c2.use_fee
                           ,'00'
                           ,i_work_mn
                           ,i_work_trm
                           ,vn_tot_out_blk_fee
                           );
          exception
                 when others then
                 vn.pxc_log_write('pcw_waitting_bk_ubk_p 03', '['||sqlcode||']');
          end;    */

    end if;
    end loop;

    vn.pxc_log_write('pss_cal_depo_fee', 'finish');

    return;
end pss_cal_depo_fee_20161205;
/

