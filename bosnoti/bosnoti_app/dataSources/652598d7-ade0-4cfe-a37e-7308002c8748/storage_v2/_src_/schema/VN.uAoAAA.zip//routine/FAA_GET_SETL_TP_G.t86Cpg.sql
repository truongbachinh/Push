create function faa_get_setl_tp_g
(
	i_acnt_no		in		varchar2,
	i_sub_no  in varchar2
) return varchar2 as

	o_setl_tp	varchar2(100);

/* ===========================================
	-- Program ID 		: 	faa_get_setl_tp_g
	-- Date of Program	: 	22/10/2007
	-- Programmer		:	mkkim
	-- Description 		:
			input  :  Account Number
			return :  Account Name
   =========================================== */
begin

	begin
	select	nvl(setl_tp,'1')
	into	o_setl_tp
	from	vn.aaa01m00
	where	acnt_no 	=	i_acnt_no
	and sub_no = i_sub_no ;

		return o_setl_tp;

	exception
	when	 no_data_found then
		return 	'1';
	end;


end ;
/

