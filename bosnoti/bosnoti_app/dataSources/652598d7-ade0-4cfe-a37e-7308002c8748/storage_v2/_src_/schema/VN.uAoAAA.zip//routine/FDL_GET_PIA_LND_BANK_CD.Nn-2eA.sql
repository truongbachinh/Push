create FUNCTION    fdl_get_pia_lnd_bank_cd(
    i_acnt_no VARCHAR2,
    i_sub_no  VARCHAR2,
    i_dt  VARCHAR2
)
RETURN VARCHAR2 AS    
    t_pia_lnd_bank_cd   varchar2(4);

BEGIN

    BEGIN
       select d1.lnd_bank_cd
       into t_pia_lnd_bank_cd
        from vn.dlm09m51 d1      
        where d1.active_stat = 'Y'
        and d1.acnt_no = i_acnt_no
        and d1.sub_no = i_sub_no
        and d1.apy_dt = ( select max(apy_dt)
                          from dlm09m51
                          where active_stat = 'Y'
                            and acnt_no = i_acnt_no
                            and sub_no = i_sub_no
                            and apy_dt <= i_dt
          );
    EXCEPTION
        WHEN OTHERS THEN
        t_pia_lnd_bank_cd := '9999';
    END;

    RETURN nvl(t_pia_lnd_bank_cd,'9999');

END fdl_get_pia_lnd_bank_cd;
/

