create function    fdl_get_five_stk_loan
(
	is_sec_id		in		varchar2
) return varchar2 as

	o_val	varchar2(100);

/*!
   \file     fdl_get_five_stk_loan.sql
   \brief    get five stock have max loan
*/
begin

	for c1 in (
		 select d.stk_cd
      from (select c.stk_cd, c.lnd_use_amt
            from dlm09m11 c
            order by c.lnd_use_amt desc) d
     where rownum <= 5  )
  loop
     o_val := o_val || ',' || trim(c1.stk_cd);
	end loop;

	return substr(o_val,2);

end ;
/

