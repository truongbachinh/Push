create function fdl_get_mrtg_rm_qty
(
    i_lnd_tp       in   varchar2,
    i_acnt_no      in   varchar2,
    i_sub_no       in   varchar2,
    i_setl_dt      in   varchar2,
    i_mth_dt       in   varchar2,
    i_bank_cd      in   varchar2,
    i_stk_cd       in   varchar2
)   return  number as

    t_vwdate            varchar2(08) ;

    t_mrtg_rm_qty       number  := 0 ;

    t_err_txt           varchar2(80) ; -- error text buffer
begin

/*============================================================================*/
/* Valiabl Initialize                                                         */
/*============================================================================*/
    t_mrtg_rm_qty  :=  0;

/*============================================================================*/
/* Get today's work date                                                      */
/*============================================================================*/
    t_vwdate := vn.vwdate;

/*============================================================================*/
/* generl commission return                                                   */
/*============================================================================*/

    for C2 in (
	    select  *
	      from  (
	    		  select  lnd_bank_cd
	    		       ,  lnd_dt
	    		       ,  mrtg_dt
	    		       ,  stk_cd
	    		       ,  sum(sb_qty)      sb_qty
	    		    from  vn.dsc01m10
	    		   where  acnt_no      =  i_acnt_no
	    		     and  sub_no       =  i_sub_no
	    		     and  setl_dt      =  i_setl_dt
	    		     and  mth_dt       =  i_mth_dt
	    		     and  bank_cd      =  i_bank_cd
	    		     and  stk_cd    like  i_stk_cd
	    		     and  cdt_tp       =  i_lnd_tp
	    		     and  sb_tp        =  '1'
	    		     and  dpo_setl_yn  =  'N'
	    		   group  by  lnd_bank_cd, lnd_dt, mrtg_dt, stk_cd
	    		  union
	    		  select  lnd_bank_cd
	    		       ,  lnd_dt
	    		       ,  mrtg_dt
	    		       ,  stk_cd
	    		       ,  sum(sb_qty)      sb_qty
	    		    from  vn.dsc01m00
	    		   where  acnt_no      =  i_acnt_no
	    		     and  sub_no       =  i_sub_no
	    		     and  setl_dt      =  i_setl_dt
	    		     and  mth_dt       =  i_mth_dt
	    		     and  bank_cd      =  i_bank_cd
	    		     and  stk_cd    like  i_stk_cd
	    		     and  cdt_tp       =  i_lnd_tp
	    		     and  sb_tp        =  '1'
	    		     and  dpo_setl_yn  =  'N'
	    		   group  by  lnd_bank_cd, lnd_dt, mrtg_dt, stk_cd
               ) X
         order  by  X.lnd_bank_cd, X.lnd_dt, X.mrtg_dt, X.stk_cd
    ) loop

            for C3 in (
                select  lnd_tp
                     ,  mth_dt
                     ,  lnd_bank_cd
                     ,  setl_bank_cd
                     ,  stk_cd
                     ,  nvl(lnd_amt,0)                       lnd_amt
                     ,  nvl(lnd_rpy_amt,0)                   lnd_rpy_amt
                     ,  nvl(lnd_amt,0) - nvl(lnd_rpy_amt,0)  lnd_rm_amt
                     ,  nvl(mrtg_lnd_qty,0)                  mrtg_lnd_qty
                     ,  nvl(mrtg_rpy_qty,0)                  mrtg_rpy_qty
                     ,  nvl(mrtg_lnd_qty,0)
                      - nvl(mrtg_rpy_qty,0)                  mrtg_rm_qty
                     ,  nvl(pppd_sell_mth_qty,0)             pppd_sell_mth_qty
                  from  vn.dlm01m00
                 where  lnd_tp          =  i_lnd_tp
                   and  acnt_no         =  i_acnt_no
                   and  sub_no          =  i_sub_no
                   and  lnd_dt          =  C2.lnd_dt
                   and  mth_dt          =  C2.mrtg_dt
                   and  lnd_bank_cd     =  C2.lnd_bank_cd
                   and  stk_cd          =  C2.stk_cd
                   and  nvl(lnd_amt,0)  -  nvl(lnd_rpy_amt,0) > 0
                   and  lnd_acpt_tp     =  '01'
            ) loop


                t_mrtg_rm_qty  := t_mrtg_rm_qty + C3.mrtg_rm_qty;
                /*
                dbms_output.put_line('===================================================');
                dbms_output.put_line('20. lnd_dt : '||C2.lnd_dt||', mrtg_dt : '||C2.mrtg_dt);
                dbms_output.put_line('20. lnd_bank_cd : '||C2.lnd_bank_cd);
                dbms_output.put_line('===================================================');
                */
            end loop;
    end loop;

    return t_mrtg_rm_qty;

end fdl_get_mrtg_rm_qty;
/

