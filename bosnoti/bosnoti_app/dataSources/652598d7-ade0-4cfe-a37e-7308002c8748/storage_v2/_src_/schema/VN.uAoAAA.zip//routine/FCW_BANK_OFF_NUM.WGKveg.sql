create function fcw_bank_off_num
(
  i_sec_id    in    varchar2
) return varchar2 as

  bank_num  varchar2(100);

begin

  begin

    select nvl(max(t.acc_bank_acnt_sn),0)
      into bank_num from gga13t00 t;

    bank_num := trim(to_char(to_number(bank_num,'999') + 1 , '000')) ;

    return bank_num;

  exception
  when   no_data_found then
    return   '999';
  end;

end ;
/

