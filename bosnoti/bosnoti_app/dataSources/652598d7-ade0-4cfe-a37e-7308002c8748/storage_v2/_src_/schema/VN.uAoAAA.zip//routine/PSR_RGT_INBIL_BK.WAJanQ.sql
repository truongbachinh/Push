create procedure psr_rgt_inbil_bk
( i_acnt_no in  varchar2,
  i_sub_no  in  varchar2,
  i_stk_cd  in  varchar2,
  i_rmrk_cd in  varchar2,
  i_trd_no  in  number  ,
  i_asn_qty in  number  ,
  i_apy_dt  in  varchar2,
  i_work_mn in  varchar2,
  i_work_trm in varchar2
 ) is

  t_err_txt varchar2(100) := null ;
  t_err_msg varchar2(100) := null ;
  t_trd_tp  varchar2(100) := null ;
  t_seq_no  number        :=  0   ;

  t_rgt_tax_qty number    := 0; /* LTHN-248 */
  t_is_rgt_tax  varchar2(1) := 'N'; /* LTHN-248 */
  t_grp_tp      varchar2(1) := '1'; /* LTHN-248 */

begin

   vn.pxc_log_write('psr_rgt_inbil_bk', '[' || i_acnt_no||'][' || i_stk_cd ||'][' || i_asn_qty ||'][' || i_rmrk_cd ||'][' || i_trd_no || ']'  );

   vn.pxc_log_write('psr_rgt_inbil_bk','apply date ['|| i_apy_dt ||']') ;

  if i_apy_dt <= vn.vwdate then
    return  ;
  end if ;

  Begin
    Select NVL(max(Seq_no) + 1  , 1 )
    Into t_seq_no
    From VN.SSB05m00
     Where proc_dt = vn.vwdate
     and acnt_no = i_acnt_no
     and sub_no  = i_sub_no;

  exception
    when others then
      t_err_txt  :=   ' ssb05m00  select seq error ';
      t_err_msg  :=   vn.fxc_get_err_msg('V','2023');
      raise_application_error(-20100,t_err_msg||t_err_txt);
  end ;

  if vn.faa_get_acnt_tp( i_acnt_no, i_sub_no ) = '1' then
    t_trd_tp := '70' ;
  else
    t_trd_tp := '72' ;
  end if ;

  begin
    select distinct b.grp_tp
      into t_grp_tp
      from aaa01m00 a, aaa02m00 b
     where a.acnt_no = i_acnt_no
       and a.acnt_stat = '1'
       and a.idno = b.idno;
  exception
    when others then
      t_err_txt  :=   ' select acnt group error ';
      t_err_msg  :=   vn.fxc_get_err_msg('V','2023');
      raise_application_error(-20100,t_err_msg||t_err_txt);
  end;
  
  if i_rmrk_cd in ('205','206') then
    if t_grp_tp = '1' then
      t_rgt_tax_qty := i_asn_qty;
      t_is_rgt_tax  := 'Y';
    elsif t_grp_tp = '2' then
      t_rgt_tax_qty := 0;
      t_is_rgt_tax  := 'N';
    end if;
  end if;

  Begin
    insert into  vn.ssb05m00
    ( proc_dt     , acnt_no   , sub_no,  seq_no   , trd_tp     , stk_cd   , rmrk_cd       , qty       ,sb_lmt_qty ,
      mov_lmy_qty , INQ_PRI   , BUY_DT   , INQ_DT     , ANTH_CD  , ANTH_ACNT_NO  , is_rgt_tax, rgt_tax_qty,
      CNTE        , CNCL_YN   , END_YN   , TRD_SEQ_NO , std_inq_dt , apy_dt   , WORK_MN  , WORK_DTM , WORK_TRM
    ) values  (
      vn.vwdate   , i_acnt_no , i_sub_no,  t_seq_no , t_trd_tp   , i_stk_cd , i_rmrk_cd     , i_asn_qty , 0         ,
      0           , 0         , null     , vn.vwdate  , null     , null          , t_is_rgt_tax, t_rgt_tax_qty,
      null        , 'N'       , 'Y'      , i_trd_no   , vn.vwdate,i_apy_dt , i_work_mn, sysdate       ,i_work_trm
    );
  exception
    when others then
      t_err_txt  :=   ' ssb05m00 insert error ';
      t_err_msg  :=   vn.fxc_get_err_msg('V','2023');
      raise_application_error(-20100,t_err_msg||t_err_txt);
  end ;

end  psr_rgt_inbil_bk;
/

