create FUNCTION fcw_get_acnt_mng_brch (
    is_dept_no IN VARCHAR2
)RETURN VARCHAR2
AS
BEGIN
    if is_dept_no = '500' then
        return '001';
    elsif is_dept_no = '100' then
        return '002';
    else
        return '';
    end if;
END fcw_get_acnt_mng_brch;
/

