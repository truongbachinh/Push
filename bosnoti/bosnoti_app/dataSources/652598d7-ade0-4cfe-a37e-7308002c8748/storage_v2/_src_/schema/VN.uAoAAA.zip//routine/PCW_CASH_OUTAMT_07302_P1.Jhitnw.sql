create PROCEDURE    pcw_cash_outamt_07302_p1
(
    i_trd_dt                in        varchar2
,   i_acnt_no               in        varchar2
,   i_sub_no                in        varchar2
,   i_rmrk_cd               in        varchar2
,   i_cash                  in        number
,   i_mdm_tp                in        varchar2
,   i_tr_cd                 in        varchar2
,   i_cnfm_yn               in        varchar2
,   i_dept_no_3             in        varchar2
,   i_acc_act_cd            in        varchar2 -- tk bank vcsc
,   i_cnte                  in        varchar2
,   i_bank_acnt_nm          in        varchar2 -- ten tk bank khach
,   i_bank_acnt_no          in        varchar2 -- tk bank khach hang
,   i_bank_branch           in        varchar2 -- chi nhanh mo tk bank khach
,   i_gga_yn                in        varchar2 /* Same account transfer, not insert gga07m00 (accounting) */
,   i_work_mn               in        varchar2
,   i_work_trm              in        varchar2
,   i_bank_cd               in        varchar2 -- ma ngan hang
,   o_trd_dt                out       varchar2
,   o_trd_seq_no            out       number
,   o_dpo_prerm             out       number
,   o_dpo_nowrm             out       number
,   o_acnt_place            out       varchar2
,   o_bnhof_tp              out       varchar2
,   o_proc_bnhof_tp         out       varchar2
,   i_prd_no                in        varchar2
,   i_src_no                in        varchar2
,   i_lnd_tp                in        varchar2
,   i_grp_acnt_no           in        varchar2
,   i_rut_ts                in        varchar2

)
AS
    t_sec_cd VARCHAR2(3) := vn.fxc_sec_cd('R');
    t_proc_nm                         varchar2(100) ;
    t_err_txt                         varchar2(200);

    t_rtn_val                         char(1);
    t_work_dtm                        date;

    t_std_dt                          varchar2(08) ;

    t_tr_cd             varchar2(20);

  ts_acnt_stat             varchar2(20);
  ts_acnt_mng_bnh             varchar2(20);
  ts_agnc_brch             varchar2(20);
  ts_bank_yn                 varchar2(20);


  tn_dpo_prerm        number := 0;
  tn_tot_dpo_prerm      number := 0;
  tn_inout_cnfm_lim      number := 0;

  tn_dpo                      number := 0;
  tn_tot_dpo                  number := 0;
  tn_dpo_block             number := 0;
  tn_outq_dpo_bk           number := 0;
  tn_prof_dpo              number := 0;
  tn_reuse_dpo             number := 0;
  tn_sbst_dpo              number := 0;
  tn_sbst_able_block       number := 0;

  tn_sbst_proof            number := 0;
  tn_gst_dpo               number := 0;
  tn_use_vd                number := 0;
  tn_nonrpy_loan_amt       number := 0;
  tn_mgn_loan_amt          number := 0;
  tn_mgn_lack              number := 0;
  tn_cd_lack               number := 0;
  tn_crd_dpo               number := 0;
  tn_used_alowa_rel        number := 0;
  tn_used_alowa_cd         number := 0;
  tn_used_alowa_vd         number := 0;
  tn_all_prof_rel          number := 0;
  tn_all_prof_cd           number := 0;
  tn_all_prof_vd           number := 0;
  tn_able_block            number := 0;
  tn_tot_out_psbamt        number := 0;

  t_ATDPST_found_yn      varchar2(1);


    t_tot_trd_seq_no            number := 0;
    t_trd_seq_no            number := 0;
    t_dpo_prerm             number := 0;
    t_dpo_nowrm             number := 0;

    t_proc_brch_cd          varchar2(20) := Null;
    t_proc_agnc_brch        varchar2(20) := Null;
    t_mdm_bnh               varchar2(3);
    t_ekyc_cntr_yn          varchar2(1)  := null;

    /* Auto margin loan input, output */
/*==================================================================*/
  t_mrgn_levl             varchar2(2) ;
  t_sub_no                varchar2(2) ;

  t_available             number := 0 ;

  t_loan_amt              number := 0 ;
  t_cash                  number := 0 ;
  t_mgn_loan_seq          number := 0 ;
  t_loan_cal              number := 0 ;
  t_cia                   number := 0 ;

  t_loan_check              number := 0 ;
  t_total_loan_amt   number := 0 ;
/*==================================================================*/

    t_err_msg          varchar2(500);
    t_seq_no           number := 0 ;
    o_cnt              number := 0 ;

BEGIN



        t_proc_nm        :=  'pcw_cash_outamt_07302_p1 :';
        t_work_dtm       :=  SYSDATE;
        t_ATDPST_found_yn           :=  'N';

        SELECT  vn.vhdate() INTO  t_std_dt       FROM  dual;

        t_tr_cd          := i_tr_cd;

        t_rtn_val := 'Y';



      vn.pxc_log_write('pcw_cash_outamt_07302_p1','acnt_no -'|| i_acnt_no);
      vn.pxc_log_write('pcw_cash_outamt_07302_p1','sub-no  -'|| i_sub_no);
      vn.pxc_log_write('pcw_cash_outamt_07302_p1','i_bank_cd -'|| i_bank_cd);
      vn.pxc_log_write('pcw_cash_outamt_07302_p1','i_bank_acnt_no  -'|| i_bank_acnt_no);
      vn.pxc_log_write('pcw_cash_outamt_07302_p1','i_bank_acnt_nm  -'|| i_bank_acnt_nm);
      vn.pxc_log_write('pcw_cash_outamt_07302_p1','i_bank_branch  -'|| i_bank_branch);
      vn.pxc_log_write('pcw_cash_outamt_07302_p1','i_acc_act_cd  -'|| i_acc_act_cd);

        t_cash := i_cash;

        if  i_cash  is  null  or  i_cash  <  0 or i_cash = 0 then
            t_err_txt  :=  t_proc_nm  ||  'i_cash is Error ';
            t_err_msg := vn.fxc_get_err_msg('V','2707');
            raise_application_error(-20100,t_err_msg||t_err_txt);
        end if;


        if  i_trd_dt  IS  NULL then
            t_err_txt  :=  t_proc_nm  ||  'i_trd_dt is NULL ';
            t_err_msg := vn.fxc_get_err_msg('V','2701');
            raise_application_error(-20100,t_err_msg||t_err_txt);
        end if;

        if (vn.fxc_holi_ck(to_date(i_trd_dt, 'yyyymmdd')) != '0') then
            if (i_work_mn <> 'DAILY') then
                t_err_msg := vn.fxc_get_err_msg('V', '2422');
                t_err_msg := t_err_msg || ' Date = ' || i_trd_dt;

                vn.pxc_log_write(t_proc_nm, t_err_msg);
                raise_application_error(-20100, t_err_msg);
            end if;
        end if;    


        o_trd_dt                :=  ' '                ;
        o_trd_seq_no            :=  0                  ;

        o_dpo_prerm             :=  0                  ;
        o_dpo_nowrm             :=  0                  ;

        o_acnt_place            :=  ' '                ;
        o_bnhof_tp              :=  ' '                ;

        tn_inout_cnfm_lim       :=  0                  ;


        select decode(i_mdm_tp, '00', vn.fbm_emp_bnh_q(i_work_mn)
                  , vn.faa_acnt_bnh_cd_g('0',i_acnt_no, i_sub_no))
          into t_mdm_bnh
        from dual;


        if  i_work_mn  not in ('DAILY','BATCH') then
            vn.pbm_cls_yn_q(  vn.vhdate
                           ,  t_mdm_bnh
                           ,  vn.faa_acnt_bnh_cd_g('0',i_acnt_no, i_sub_no)
                           , '1'
                           ,  t_rtn_val
                           ,  t_err_txt
                           );

            if  t_rtn_val  !=  'N' then
               vn.pxc_log_write('pcw_cash_outamt_07302_p','t_rtn_val-'||t_rtn_val);
               vn.pxc_log_write('pcw_cash_outamt_07302_p','t_err_txt-'||t_err_txt);

              t_err_msg := vn.fxc_get_err_msg('V','2716');
              raise_application_error(-20100,t_err_msg||t_err_txt);
            end if;

        end if;

        BEGIN
            select  acnt_stat
                 ,  acnt_mng_bnh
                 ,  agnc_brch
           ,  nvl(bank_cnt_yn,'N')
              into  ts_acnt_stat
                 ,  ts_acnt_mng_bnh
                 ,  ts_agnc_brch
           ,  ts_bank_yn
              from  vn.aaa01m00
             where  acnt_no  =  i_acnt_no
             and  sub_no   =  i_sub_no;
        EXCEPTION
            WHEN  OTHERS  THEN
                t_err_txt  :=  t_proc_nm
                       ||  'Select aaa01m00 Error :'
                       ||  to_char(sqlcode);
              t_err_msg := vn.fxc_get_err_msg('V','2001');
              raise_application_error(-20100,t_err_msg||t_err_txt);
        END;

      if ts_bank_yn ='Y' then
            t_err_txt  :=  t_proc_nm
              || ' bank account ' ;
            t_err_msg := vn.fxc_get_err_msg('V','2421');
            raise_application_error(-20100,t_err_msg||t_err_txt);
      end if ;



      if i_work_mn in ('DAILY','BATCH') or i_mdm_tp <> '00' then

        t_proc_brch_cd := ts_acnt_mng_bnh;
        t_proc_agnc_brch := ts_agnc_brch;

      else

          BEGIN
              select  brch_cd,
                      agnc_brch
                into  t_proc_brch_cd,
                      t_proc_agnc_brch
                from  vn.xca01m01
                where emp_no = i_work_mn
                ;
          EXCEPTION
              WHEN  OTHERS         THEN
                  t_err_txt  :=  t_proc_nm
                         ||  'Select xca01m01 Error :'
                         ||  to_char(sqlcode);
            t_err_msg := vn.fxc_get_err_msg('V','2819');
            raise_application_error(-20100,t_err_msg||t_err_txt);
          END;

      end if;



        if  ts_acnt_stat  NOT IN ('1') then

            if  ts_acnt_stat  =  '2' then
                  t_err_txt  :=  t_proc_nm  ||  'Account is closed ';
                  t_err_msg := vn.fxc_get_err_msg('V','2023');
                  raise_application_error(-20100,t_err_msg||t_err_txt);
            else
                  t_err_txt  :=  t_proc_nm  ||  'Account status is '
                                          ||  '(' || ts_acnt_stat || ')';
                  t_err_msg := vn.fxc_get_err_msg('V','2014');
                  raise_application_error(-20100,t_err_msg||t_err_txt);
            end if;
        end if;

        -- Kiem tra neu tk eKYC chua hoan thien hop dong
        t_ekyc_cntr_yn := vn.faa_ekyc_acnt_cntr_yn(i_acnt_no);
        if (t_ekyc_cntr_yn = 'N') then
          t_err_msg := vn.fxc_get_err_msg('V', '0126');
          vn.pxc_log_write(t_proc_nm, i_acnt_no || ': Tai khoan eKYC chua hoan thien hop dong');
          raise_application_error(-20100, t_err_msg);
        end if;

        tn_dpo_prerm  := 0;
        tn_gst_dpo    := 0;

      BEGIN
         vn.pcw_outamt_psbamt_q
      (    i_acnt_no
          ,  i_sub_no
          ,  '9999'
          ,  tn_dpo
          ,  tn_dpo_block
          ,  tn_outq_dpo_bk
          ,  tn_prof_dpo
          ,  tn_reuse_dpo
          ,  tn_sbst_dpo
          ,  tn_sbst_able_block
          ,  tn_sbst_proof
          ,  tn_gst_dpo
          ,  tn_use_vd
          ,  tn_nonrpy_loan_amt
          ,  tn_mgn_loan_amt
          ,  tn_mgn_lack
          ,  tn_cd_lack
          ,  tn_crd_dpo
          ,  tn_used_alowa_rel
          ,  tn_used_alowa_cd
          ,  tn_used_alowa_vd
          ,  tn_all_prof_rel
          ,  tn_all_prof_cd
          ,  tn_all_prof_vd
          ,  tn_able_block
          ,  tn_tot_out_psbamt
          ,  i_rut_ts
        );
      EXCEPTION
      WHEN  OTHERS THEN
            t_err_txt  :=  t_proc_nm
                 ||  'pcw_outamt_psbamt_q1 Error :'
                 ||  to_char(sqlcode);
            t_err_msg := vn.fxc_get_err_msg('V','2733');
            raise_application_error(-20100,t_err_msg||t_err_txt);
      END;

      /*BEGIN
              vn.pdl_get_auto_mrgn_amt
              (
                i_acnt_no
               ,i_sub_no
               ,tn_tot_out_psbamt
               ,t_loan_check
                  );

      EXCEPTION
      WHEN  OTHERS         THEN
            t_err_txt  :=  t_proc_nm
                 ||  'pdl_get_auto_mrgn_amt Error :'
                 ||  to_char(sqlcode);
            t_err_msg := vn.fxc_get_err_msg('V','2733');
            raise_application_error(-20100,t_err_msg||t_err_txt);
      END;*/

        vn.pxc_log_write('pcw_outamt_psbamt_q1','t_loan_amt  [' || t_loan_amt || ']' );

        vn.pxc_log_write('pcw_cash_outamt_07302_p1','dpo             [' || tn_dpo             || ']');
        vn.pxc_log_write('pcw_cash_outamt_07302_p1','dpo_block       [' || tn_dpo_block       || ']');
        vn.pxc_log_write('pcw_cash_outamt_07302_p1','outq_dpo_bk     [' || tn_outq_dpo_bk     || ']');
        vn.pxc_log_write('pcw_cash_outamt_07302_p1','tot_out_psb_amt [' || tn_tot_out_psbamt  || ']');
        vn.pxc_log_write('pcw_cash_outamt_07302_p1','t_loan_check    [' || t_loan_check       || ']');

        tn_dpo_prerm := tn_dpo;

        t_ATDPST_found_yn           :=  'Y';


        if tn_dpo_prerm IS NULL then
             t_err_txt  :=  t_proc_nm
                  ||  'tn_dpo is null ';
             t_err_msg := vn.fxc_get_err_msg('V','2708');
             raise_application_error(-20100,t_err_msg||t_err_txt);
        end if;

        /* loan is less than 0, cash will be checked here */

          if i_mdm_tp = '00' and  (i_tr_cd = '07302' or i_tr_cd = '07307' or i_tr_cd = '07401') then
             t_loan_check := greatest(0, t_loan_check ) ;
             tn_tot_out_psbamt := tn_tot_out_psbamt + t_loan_check ;
          end if;



          if tn_tot_out_psbamt < i_cash then
             vn.pxc_log_write('pcw_cash_outamt_07302_p1','eror tn_tot_out_psbamt [' || tn_tot_out_psbamt  ||'&'||i_cash|| ']');
                t_err_txt  :=  t_proc_nm
                       ||  'tn_tot_out_psbamt < i_cash then ';
                t_err_msg := vn.fxc_get_err_msg('V','2726');
                raise_application_error(-20100,t_err_msg||' 111 ');
          end if;

        vn.pxc_log_write('pcw_cash_outamt_07302_p1','tn_tot_out_psbamt [' || tn_tot_out_psbamt  || ']');
        vn.pxc_log_write('pcw_cash_outamt_07302_p1','check1');

      if i_cnfm_yn = 'N' then ---moi khoi tao, chua duyet

            tn_inout_cnfm_lim := vn.fcw_inout_cnfm_lim_q(i_dept_no_3,'02');

            vn.pxc_log_write('pcw_cash_outamt_07302_p1','tn_inout_cnfm_lim-'||tn_inout_cnfm_lim);

        if i_cash > tn_inout_cnfm_lim or i_mdm_tp <> '00' then  -- hts

                vn.pxc_log_write('pcw_cash_outamt_07302_p1','pcw_inout_cnfm_ins_p-start');
                vn.pxc_log_write('pcw_cash_outamt_07302_p1','t_tr_cd [' || to_char(t_tr_cd) || ']');

          /*Thu Chi Ho qua VCB va BIDV */

            BEGIN
            vn.pcw_inout_cnfm_ins_p1( i_acnt_no
                                    , i_sub_no
                                    , '02'
                                    , i_rmrk_cd
                                    , i_cash
                                    , i_work_mn
                                    , i_work_trm
                                    , i_bank_branch --
                                    , i_bank_acnt_nm --
                                    , i_acc_act_cd
                                    , i_cnte
                                    , t_seq_no
                                    , i_mdm_tp
                                    , i_bank_cd
                                    , i_bank_acnt_no
                                    );
            EXCEPTION
                WHEN  OTHERS         THEN
                    t_err_txt  :=  t_proc_nm
                           ||  'pcw_inout_cnfm_p_err:'
                           ||  to_char(sqlcode);
                        vn.pxc_log_write('pcw_cash_outamt_07302_p1','t_err_txt-'||t_err_txt);
                    t_err_msg := vn.fxc_get_err_msg('V','2732');
                    raise_application_error(-20100,t_err_msg||t_err_txt);
            END;

          o_trd_dt        := nvl(i_trd_dt, '0');
          o_trd_seq_no    := t_trd_seq_no;
          o_dpo_prerm     := t_dpo_prerm;
          o_dpo_nowrm     := t_dpo_nowrm;
          o_acnt_place    := ts_acnt_mng_bnh;
          o_bnhof_tp      := ts_agnc_brch;
          o_proc_bnhof_tp := to_char(t_seq_no);

          return;

        end if;

      end if;
        vn.pxc_log_write('pcw_cash_outamt_07302_p1','check2');

    /* Auto margin loan */
    /*================================================================================================*/
      t_mrgn_levl := vn.faa_acnt_get_grp_no (i_acnt_no, i_sub_no,'2',vn.wdate);

        if t_mrgn_levl is null then

           t_mrgn_levl := '00000';
        end if;

      if t_mrgn_levl <> '00000' and t_sub_no <> '00' then

            t_available  :=  tn_dpo - tn_dpo_block - tn_outq_dpo_bk ;
            vn.pxc_log_write('pcw_cash_outamt_07302_p1','t_cash_max     [' || t_available || ']');


          if i_cash > t_available then
                 raise_application_error(-20200, 'available error');
          end if;
         end if;
    /*======================================================================================================*/

        vn.pxc_psb_seq_cret_p  (  i_acnt_no
                               ,  i_sub_no
                               ,  i_trd_dt
                               ,  o_trd_seq_no
                               ,  t_tot_trd_seq_no
                               );

        tn_dpo_prerm     := tn_dpo_prerm + t_loan_amt;
        tn_dpo           := tn_dpo_prerm - i_cash;
        tn_tot_dpo_prerm := vn.fcw_tot_dpo_prerm(i_acnt_no);
        tn_tot_dpo       := tn_tot_dpo_prerm - i_cash;

        if  t_ATDPST_found_yn  =  'Y' then

          BEGIN
              update  vn.cwd01m00
                 set  dpo              = tn_dpo
                   ,  work_mn          = i_work_mn
                   ,  work_dtm         = sysdate
                   ,  work_trm         = i_work_trm
               where  acnt_no  =  i_acnt_no
                and  sub_no   =  i_sub_no;
          EXCEPTION
              WHEN  OTHERS         THEN
                  t_err_txt  :=  t_proc_nm
                         ||  'update cwd01m00 Error '
                         ||  to_char(sqlcode);
            t_err_msg := vn.fxc_get_err_msg('V','2703');
            raise_application_error(-20100,t_err_msg||t_err_txt);
          END;

        else


            BEGIN
                insert  into  vn.cwd01m00
                     (  acnt_no
                     ,  sub_no
                     ,  dpo
                     ,  gst_dpo
                     ,  work_mn
                     ,  work_dtm
                     ,  work_trm
                     )
                values
                     (  i_acnt_no
                     ,  i_sub_no
                     ,  tn_dpo
                     ,  0
                     ,  i_work_mn
                     ,  sysdate
                     ,  i_work_trm
                     );
            EXCEPTION
                WHEN  OTHERS         THEN
                    t_err_txt  :=  t_proc_nm
                           ||  'insert cwd01m00 Error '
                           ||  to_char(sqlcode);
            t_err_msg := vn.fxc_get_err_msg('V','2702');
            raise_application_error(-20100,t_err_msg||t_err_txt);
            END;

        end if;

    vn.pxc_log_write('pcw_cash_outamt_07302_p1','9');
    vn.pxc_log_write('pcw_cash_outamt_07302_p1',o_trd_seq_no);
    vn.pxc_log_write('pcw_cash_outamt_07302_p1',t_tot_trd_seq_no);


    /* check again enough dpo */
        if  tn_tot_dpo < 0 then
          vn.pxc_log_write('pcw_cash_outamt_07302_p1','error-'||tn_tot_dpo);
            t_err_txt  :=  t_proc_nm  ||  'Cannot withdraw cash because present cash not enough.';
            t_err_msg := vn.fxc_get_err_msg('V','2707');
            raise_application_error(-20100,t_err_msg||t_err_txt);
        end if;

    /* add column aaa10m00 or cwd06m00 for mgn_loan_amt_seq_no */

        BEGIN
               insert  into  vn.aaa10m00
                 (
             acnt_no
            ,sub_no
            ,trd_dt
            ,tot_trd_seq_no
            ,trd_seq_no
            ,trd_tp
            ,rmrk_cd
            ,mdm_tp
            ,cncl_yn
            ,org_trd_no
            ,trd_amt
            ,cmsn
            ,adj_amt
            ,dpo_prerm
            ,dpo_nowrm
            ,tot_dpo_prerm
            ,tot_dpo_nowrm
                    ,acnt_mng_bnh
                    ,agnc_brch
                    ,work_bnh
                    ,proc_agnc_brch
            ,work_mn
            ,work_dtm
            ,work_trm
            ,cnte
        --    ,bank_cd_off
            ,bank_acnt_no
        --    ,book_time
            ,mgn_loan_amt
            ,mgn_loan_seq
                 )
               values
                 (
             i_acnt_no
            ,i_sub_no
            ,i_trd_dt
            ,t_tot_trd_seq_no
            ,o_trd_seq_no
            ,'11'
            ,i_rmrk_cd
            ,i_mdm_tp
            ,'N'
            ,0
            ,i_cash
            ,0
            ,i_cash
            ,tn_dpo_prerm
            ,tn_dpo
            ,tn_tot_dpo_prerm
            ,tn_tot_dpo
            ,ts_acnt_mng_bnh
            ,ts_agnc_brch
            ,t_proc_brch_cd
            ,t_proc_agnc_brch
            ,i_work_mn
            ,t_work_dtm
            ,i_work_trm
            ,i_acc_act_cd||'-' || to_char(o_trd_seq_no) || '-' || i_cnte
          --  ,i_bank_cd_off
            ,i_bank_acnt_no
          --  ,i_book_time
            ,t_loan_amt
            ,t_mgn_loan_seq
                 );
        EXCEPTION
             WHEN  OTHERS         THEN
               vn.pxc_log_write('pcw_cash_outamt_07302_p1','error- insert aaa10m00 ');
                   t_err_txt  :=  t_proc_nm
                       ||  'insert aaa10m00 Error :'
                       ||  to_char(sqlcode);
             t_err_msg := vn.fxc_get_err_msg('V','9405');
             raise_application_error(-20100,t_err_msg||t_err_txt);
        END;

    /*******************************/
    /* call evaluation for margin  */
    /******************************/
        BEGIN
         vn.pdl_crd_loan_rt_proc_td
           (  vn.vwdate
             ,'1' -- cash
             ,i_acnt_no
             ,i_sub_no
             ,o_trd_seq_no
             ,i_work_mn
             ,i_work_trm
             ,o_cnt
           );
        EXCEPTION
           WHEN OTHERS THEN
             t_err_txt := 'call pdl_crd_loan_rt_proc_td error : ' || sqlerrm ;
             t_err_msg := vn.fxc_get_err_msg('V','2748');
             raise_application_error(-20100,t_err_msg||t_err_txt);
        END ;

        vn.pxc_log_write('pcw_cash_outamt_07302_p1','pdl_crd_loan_rt_proc_td ['|| o_cnt ||']');


        BEGIN
         vn.pcw_gga07m00_ins_07301_p
         (
             i_trd_dt
         ,   'I'
         ,   i_acnt_no
         ,   i_sub_no
         ,   o_trd_seq_no
         ,   0
         ,   i_rmrk_cd
         ,   i_cash
         ,   i_acc_act_cd
         ,   i_work_mn
         ,   i_work_trm
         );
        EXCEPTION
             WHEN  OTHERS         THEN
                   t_err_txt  :=  t_proc_nm
                          ||  'pcw_gga07m00_ins_07301_p Error '
                          ||  sqlerrm;
                   raise_application_error (-20100, t_err_txt);
             t_err_msg := vn.fxc_get_err_msg('V','2731');
             raise_application_error(-20100,t_err_msg||t_err_txt);
        END;

        BEGIN
            vn.pts_loan_cash_unhold
            ( t_sec_cd
            ,   i_acnt_no
            ,   i_sub_no
            ,   -i_cash
            );
        EXCEPTION
            WHEN  OTHERS         THEN
                t_err_txt  :=  t_proc_nm
                       ||  'pts_loan_cash_unhold - err: '
                       ||  sqlerrm;
                t_err_msg := vn.fxc_get_err_msg('V','2731');
                raise_application_error(-20100,t_err_msg||t_err_txt);
        END;

    vn.pxc_log_write('pcw_cash_outamt_07302_p1','o_trd_dt-['||o_trd_dt||']');
    vn.pxc_log_write('pcw_cash_outamt_07302_p1','o_dpo_prerm-['||o_dpo_prerm||']');
    vn.pxc_log_write('pcw_cash_outamt_07302_p1','o_dpo_nowrm-['||o_dpo_nowrm||']');
    vn.pxc_log_write('pcw_cash_outamt_07302_p1','o_acnt_place-['||o_acnt_place||']');
    vn.pxc_log_write('pcw_cash_outamt_07302_p1','o_bnhof_tp-['||o_bnhof_tp||']');


    o_trd_dt                := nvl(i_trd_dt, '0')         ;

    o_dpo_prerm             := tn_dpo_prerm           ;
    o_dpo_nowrm             := tn_dpo           ;

    o_acnt_place            := ts_acnt_mng_bnh          ;
    o_bnhof_tp              := ts_agnc_brch       ;
    o_proc_bnhof_tp         := '0'       ;

END  pcw_cash_outamt_07302_p1;
/

