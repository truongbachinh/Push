create function fdl_get_mrgn_expt_amt
(
	i_acnt_no        in   varchar2,        --
	i_sub_no         in   varchar2,
	i_tp             in   varchar2
)
    return  number

/*

select vn.fdl_get_mrgn_expt_amt('045','045C206888','00','3')
  from dual;

*/
as

	o_lnd_rtn_val    number := 0;

	t_lnd_int       number := 0;
	t_dly_int       number := 0;
	t_lnd_rm_amt    number := 0;

    t_err_msg       varchar2(500);

begin

/*============================================================================*/
/* Calculation                                                                */
/*============================================================================*/

	o_lnd_rtn_val := 0;

	for C1 in (
		SELECT nvl(SUM(LND_USE_AMT), 0)     LND_USE_AMT
		     , nvl(SUM(LND_EXPT_AMT), 0)    LND_EXPT_AMT
		  FROM vn.dlm09m10
		 WHERE acnt_no like i_acnt_no
		   AND sub_no like i_sub_no
		   AND lnd_tp IN ('70', '80')
	) loop

		IF i_tp = '1' then
			o_lnd_rtn_val := C1.LND_USE_AMT;
		ELSIF i_tp = '2' then
			o_lnd_rtn_val := C1.LND_EXPT_AMT;
		ELSIF i_tp = '3' then
			o_lnd_rtn_val := C1.LND_USE_AMT + C1.LND_EXPT_AMT;
		ELSE
			o_lnd_rtn_val := 0;
		END IF;

		vn.pxc_log_write('fdl_get_mrgn_expt_amt', 'Check ' || i_acnt_no ||'-'||i_sub_no
		                                       ||' LND_USE_AMT = '||  C1.LND_USE_AMT
		                                       ||' LND_EXPT_AMT = '|| C1.LND_EXPT_AMT
		                                       ||' o_lnd_rtn_val = '|| o_lnd_rtn_val
		                                       ||' i_tp = '|| i_tp);


	end loop;
  
  
  
    return o_lnd_rtn_val;

end fdl_get_mrgn_expt_amt;
/

