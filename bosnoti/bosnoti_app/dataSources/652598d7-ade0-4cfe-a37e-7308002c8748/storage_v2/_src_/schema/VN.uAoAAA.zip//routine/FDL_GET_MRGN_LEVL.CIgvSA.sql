create FUNCTION    fdl_get_mrgn_levl
(
    i_acnt_no        in   varchar2,
    i_sub_no         in   varchar2
)   RETURN  VARCHAR2 AS
/*!
   \file     fdl_get_mrgn_rt_01.sql
   \brief    margin information
   \modify   20100423 hjcho check "apy_dt <= i_apy_dt"

    select vn.fdl_get_mrgn_rt_01('045C000001','01') from dual;

*/
    t_mrgn_levl         VARCHAR2(02);
    t_grp_tp            VARCHAR2(2)     := '2';
    t_apy_dt            VARCHAR2(8)     := vn.vwdate;

begin

    t_mrgn_levl := vn.faa_acnt_get_grp_no(i_acnt_no, i_sub_no, t_grp_tp, t_apy_dt);

    RETURN t_mrgn_levl;

END fdl_get_mrgn_levl;
/

