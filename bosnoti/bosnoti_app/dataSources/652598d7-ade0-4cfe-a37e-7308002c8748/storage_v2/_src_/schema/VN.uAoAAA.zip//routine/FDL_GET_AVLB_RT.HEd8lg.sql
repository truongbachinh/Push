create function fdl_get_avlb_rt
(
    i_lnd_tp       in   varchar2,
    i_lnd_bank_cd  in   varchar2,
    i_stk_cd       in   varchar2,
    i_lnd_dt       in   varchar2
)
    return  number
as
	o_lnd_avlb_rt       number;
	t_lnd_avlb_rt		number;
	t_bnk_avlb_rt		number;
	t_found				varchar2(1) := 'N';


begin

/*============================================================================*/
/* Valiabl Initialize                                                         */
/*============================================================================*/
    o_lnd_avlb_rt  :=  0;
    t_lnd_avlb_rt  :=  0;
    t_bnk_avlb_rt  :=  0;

/*============================================================================*/
/* generl commission return                                                   */
/*============================================================================*/

	for c1 in (
		select  NVL(lnd_avlb_eval_rt,0)   lnd_avlb_eval_rt
		  from  vn.dlm12m00
		 where  lnd_bank_cd  =  i_lnd_bank_cd
           and  apy_dt       =  (select  max(apy_dt)
	                               from  vn.dlm12m00
	                              where  lnd_bank_cd  in  ('0000',i_lnd_bank_cd)
    	                            and  apy_dt       <=  i_lnd_dt)
	     order  by apy_dt desc
	) loop
	    for c2 IN (
	        select  nvl(lnd_avlb_rt,0) lnd_avlb_rt
	          from  vn.dlm11m10
	         where  lnd_bank_cd  in  ('0000',i_lnd_bank_cd)
               and  lnd_tp        =  i_lnd_tp
	           and  stk_cd        =  i_stk_cd
	           and  del_yn        =  'N'
	           and  apy_dt        =  (select  max(apy_dt)
	                                     from  vn.dlm11m10
	                                    where  lnd_bank_cd  in  ('0000',i_lnd_bank_cd)
	                                      and  lnd_tp        =  i_lnd_tp
	                                      and  stk_cd        =  i_stk_cd
	                                      and  del_yn        =  'N'
		    	                          and  apy_dt       <=  i_lnd_dt)
	         order  by apy_dt desc
	    ) loop

	/*		if c2.lnd_avlb_rt = 0 then
				t_lnd_avlb_rt	:= c1.lnd_avlb_eval_rt;
			else
				t_lnd_avlb_rt	:= c2.lnd_avlb_rt;
			end if;
  */
     		t_lnd_avlb_rt	:= c2.lnd_avlb_rt;

			t_found  :=  'Y';

		end loop;

		/* t_bnk_avlb_rt  :=  c1.lnd_avlb_eval_rt; */
    end loop;

	if t_found = 'Y' then
		o_lnd_avlb_rt := t_lnd_avlb_rt;
	else
		o_lnd_avlb_rt :=  t_bnk_avlb_rt;
	end if;

    return o_lnd_avlb_rt;

end fdl_get_avlb_rt;
/

