create function fcw_acnt_cash
(
  i_acnt_no          in       varchar2
) 
return varchar2 as

  t_cash_dpo    number := 0;
  
begin
  select t.dpo  
  into  t_cash_dpo
  from  vn.cwd01m00 t
  where  acnt_no = i_acnt_no;

  if t_cash_dpo > 0 then
    return 'Y';
  else
    return 'N';
  end if;
  
end ;
/

