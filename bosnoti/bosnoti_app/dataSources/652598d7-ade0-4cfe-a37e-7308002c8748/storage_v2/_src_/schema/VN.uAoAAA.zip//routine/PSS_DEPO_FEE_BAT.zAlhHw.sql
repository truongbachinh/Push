create procedure pss_depo_fee_bat(i_sec_cd   in varchar2,
                                             i_proc_dt  in varchar2,
                                             i_work_mn  in varchar2,
                                             i_work_trm in varchar2,
                                             o_proc_cnt out number) is
/* ******************************** Log change ********************************
15-Nov-2018 vnjvthangnm EESF04  Bo sung tham so chu ky tinh va thu PLK

**************************************************************************** */
  vn_count              number := 0;
  vn_count_q            number := 0;
  vn_withdraw_date      varchar2(8);
  vn_firstworking_month date;
  vn_lastworking_month  date;
  vn_from_dt            varchar2(8);
  vn_to_dt              varchar2(8);
  vn_depo_cal_freq      varchar2(1); /* D)aily M)onthly */ -- EESF04
  vn_depo_with_freq     varchar2(1); /* D)aily M)onthly */ -- EESF04
  vn_cal_date           varchar2(8);  -- EESF04

begin

  vn.pxc_log_write('pss_depo_fee_bat', 'start' || '[' || i_proc_dt || ']');
  o_proc_cnt := 0;

  /* Get the first day, last day of this month */
  select trunc(to_date(i_proc_dt,'YYYYMMDD'), 'MONTH'), last_day(to_date(i_proc_dt,'YYYYMMDD'))
    into vn_firstworking_month,vn_lastworking_month
    from dual;

  /* Get the first working day of this month */
  while vn.fxc_holi_ck (vn_firstworking_month) <> 0
  loop
    vn_firstworking_month := vn_firstworking_month + 1;
  end loop;
  vn.pxc_log_write('pss_depo_fee_bat', 'The first working day of this month is: ' || '[' || to_char(vn_firstworking_month,'YYYYMMDD') || ']');

  /* Get the last working day of this month */
  while vn.fxc_holi_ck (vn_lastworking_month) <> 0
  loop
    vn_lastworking_month := vn_lastworking_month - 1;
  end loop;
  vn.pxc_log_write('pss_depo_fee_bat', 'The last working day of this month is: ' || '[' || to_char(vn_lastworking_month,'YYYYMMDD') || ']');

  /* Get depo cal date, start date, end date */
  select col_cd_tp into vn_depo_cal_freq
    from vn.xcc01c02
   where col_cd = 'depo_cal_freq';

  if vn_depo_cal_freq = 'D' then
    vn_cal_date := i_proc_dt;
    vn_from_dt := i_proc_dt;
    vn_to_dt := i_proc_dt;
  else
    vn_cal_date := to_char(vn_lastworking_month,'YYYYMMDD');
    vn_from_dt := to_char(trunc(to_date(i_proc_dt,'YYYYMMDD'), 'MONTH'),'YYYYMMDD');
    vn_to_dt := to_char(last_day(to_date(i_proc_dt,'YYYYMMDD')),'YYYYMMDD');
  end if;

  /* Get depo withdraw date */
  select col_cd_tp into vn_depo_with_freq
    from vn.xcc01c02
   where col_cd = 'depo_with_freq';

  if vn_depo_with_freq = 'D' then
    vn_withdraw_date := i_proc_dt;
  else
    vn_withdraw_date := to_char(vn_firstworking_month,'YYYYMMDD');
  end if;
vn.pxc_log_write('pss_depo_fee_bat', 'i_proc_dt: ' || i_proc_dt);
vn.pxc_log_write('pss_depo_fee_bat', 'vn_cal_date: ' || vn_cal_date);
vn.pxc_log_write('pss_depo_fee_bat', 'vn_withdraw_date: ' || vn_withdraw_date);
vn.pxc_log_write('pss_depo_fee_bat', 'Start calculate depo fee. ');

  /* Calculate the depositpry fee */
  if i_proc_dt = vn_cal_date then
    begin
      vn.pss_cal_depo_fee(i_sec_cd,
                          i_proc_dt,
                          '%', --acnt_no
                          '%', --sub_no
                          '%', -- stk_cd
                          vn_from_dt, -- start date
                          vn_to_dt, -- end date
                          i_work_mn,
                          i_work_trm,
                          vn_count_q);
      exception
      when others then
          vn.pxc_log_write('pss_cal_depo_fee', '['||sqlcode||']');
    end;

    vn.pxc_log_write('pss_cal_depo_fee',
                     'finish ' || '-' || i_proc_dt || '-' || i_proc_dt);
  end if;

vn.pxc_log_write('pss_depo_fee_bat', 'Start withdraw depo fee. ');
  /* Withdraw depo fee */
  --if i_proc_dt = vn_withdraw_date then
  if i_proc_dt = '20200929' then -- thay doi de test tam
    begin
      vn.pss_acnt_depo_fee_out_dt(i_sec_cd,
                                  '%' --acnt_no
                                 ,
                                  '%' --sub_no
                                 ,
                                  i_work_mn,
                                  i_work_trm);
      exception
      when others then
          vn.pxc_log_write('pss_acnt_depo_fee_out_dt', '['||sqlcode||']');
    end;
    vn.pxc_log_write('pss_acnt_depo_fee_out_dt', 'finish ' || '-' || i_proc_dt || '-' || i_proc_dt);
  end if;

  vn.pxc_log_write('pss_depo_fee_bat', 'finish' || '[' || i_proc_dt || ']');

  return;
end pss_depo_fee_bat;
/

