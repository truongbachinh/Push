create function fcw_check_rmrk_cd_type(i_sec_cd  in varchar2,
                                            i_rmrk_cd in varchar2)
  return varchar2 as
  ti_count varchar2(1);
begin
  begin
    select RMRK_KD
      into ti_count
      from vn.DLM14M00 a
     where a.rmrk_cd=i_rmrk_cd
       AND a.RMRK_KD <> '1';
  exception
    when others then
      return '!';
  end;

    return ti_count;

end;
/

