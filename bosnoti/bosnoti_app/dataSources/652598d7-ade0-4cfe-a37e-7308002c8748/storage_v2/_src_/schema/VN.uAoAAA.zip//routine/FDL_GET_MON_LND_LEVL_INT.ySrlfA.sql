create function    fdl_get_mon_lnd_levl_int
(
    i_lnd_tp          in   varchar2,        --
    i_acnt_no         in   varchar2,        --
    i_sub_no          in   varchar2,
    i_lnd_bank_cd     in   varchar2,        --
    i_int_tp          in   varchar2,        -- 1:int 2:dly_int 3:all
    i_lnd_dt          in   varchar2,        --
    i_rpy_dt          in   varchar2,        --
    i_expr_dt         in   varchar2,        --
    i_last_rpy_dt     in   varchar2,        --
    i_remn_amt        in   number,           --
    i_cpt_rpy_tp      in   varchar2,        --
    i_int_rpy_tp      in   varchar2,        --
    i_int_calc_apy_tp in   varchar2        -- 1:fix ratio 2:movable ratio
)
    return  number
as

	td_mrgn_levl_chg_cnt     NUMBER := 0;

	td_int_calc_apy_tp       NUMBER := 0;

	o_lnd_int               NUMBER := 0;
    ts_err_txt               VARCHAR2(80); -- error text buffer

    ts_mrgn_levl				VARCHAR2(2)	:= NULL;
    ts_bf_mrgn_levl				VARCHAR2(2)	:= NULL;
    ts_af_mrgn_levl				VARCHAR2(2)	:= NULL;

    ts_st_dt                    VARCHAR2(8) := NULL;
    ts_ed_dt                    VARCHAR2(8) := NULL;

 	td_tot_cnt                  NUMBER      := 0;

    td_lnd_int                  NUMBER := 0;
    td_dly_lnd_int              NUMBER := 0;

begin

    o_lnd_int := 0;
    return o_lnd_int;

end fdl_get_mon_lnd_levl_int;
/

