create FUNCTION    fdl_get_pia_avl_amt(i_acnt_no     IN VARCHAR2, --
                                               i_sub_no      IN VARCHAR2,
                                               i_mth_dt      IN VARCHAR,
                                               i_lnd_bank_cd IN VARCHAR2, --
                                               i_rt_tp       IN VARCHAR2)
  RETURN NUMBER AS

  /*!
     \file     pdl_mrgn_loan_proc.sql
     \brief    deposit settlement
      \section intro Program Information
          - Program Name              : margin loan
          - Service Name              : ds_04003_p1.pc
          - Related Client Program- Client Program ID : w_04001
          - Related Tables            : dsc01m00, cwd01m00, dlm01m00
                                      : aaa01m00, aaa10m00
          - Dev. Date                 : 2010/06/25
          - Developer                 : Han.
          - Business Logic Desc.      : create margin-loan data
          - Latest Modification Date  : 2010/06/25
      \section history Program Modification History
      - 1.0       2007/11/08     Han.    New.
      \section hardcoding Hard-Coding List
      - HC-1      2007/11/08     Han.    [>cA?]
      \section info Additional Reference Comments

  var t_cnt      number;
  var t_err_cnt  number;
  exec pdl_mrgn_loan_proc('068','20090807','1','068C006336','9999','Conv_man','Conv_man',:t_cnt,:t_err_cnt);
  print t_cnt
  print t_err_cnt
   */

  td_lnd_rm_amt   NUMBER := 0;
  td_lnd_cmsn_amt NUMBER := 0;
  td_sum_abl_amt  NUMBER := 0;
  td_sum_cmsn     NUMBER := 0;
  td_count        NUMBER := 0;
  td_pay_lnd_cmsn NUMBER := 0;
  td_abl_lnd_cmsn NUMBER := 0;

  td_abl_amt     NUMBER := 0;
  t_ppre_mth_dt  VARCHAR2(08) := NULL;
  t_pre_mth_dt   VARCHAR2(08) := NULL;
  t_pppre_mth_dt VARCHAR2(08) := NULL;
  t_vwdate       VARCHAR2(08) := NULL;

  td_d0_rpy_amt NUMBER := 0;
  td_d1_rpy_amt NUMBER := 0;
  td_d2_rpy_amt NUMBER := 0;
  td_d3_rpy_amt NUMBER := 0;
  td_d0_rpy_int NUMBER := 0;
  td_d1_rpy_int NUMBER := 0;
  td_d2_rpy_int NUMBER := 0;
  td_d3_rpy_int NUMBER := 0; 
  t_bank_cnt_yn VARCHAR2(1) := 'N';
BEGIN

  /* Tam thoi IBSC khong dung ung truoc tu dong */
  RETURN 0;

  t_vwdate       := vn.vwdate;
  t_pppre_mth_dt := vn.fxc_vorderdt_g(to_date(t_vwdate, 'yyyymmdd'), -3);
  t_ppre_mth_dt  := vn.fxc_vorderdt_g(to_date(t_vwdate, 'yyyymmdd'), -2);
  t_pre_mth_dt   := vn.fxc_vorderdt_g(to_date(t_vwdate, 'yyyymmdd'), -1);

  td_sum_abl_amt := 0;

  BEGIN
    SELECT nvl(bank_cnt_yn, 'N')
      INTO t_bank_cnt_yn
      FROM vn.aaa01m00
     WHERE acnt_no = i_acnt_no
       AND sub_no = i_sub_no;
  END;

  IF t_bank_cnt_yn = 'Y' THEN
    RETURN 0;
  END IF;

  FOR c1 IN (

             SELECT *
               FROM (SELECT '1' tp,
                             bank_cd bank_cd,
                             vn.faa_bank_nm_g(bank_cd) bank_nm,
                             mth_dt mth_dt1,
                             setl_dt setl_dt1,
                             to_char(to_date(mth_dt, 'yyyymmdd'), 'ddmmyyyy') mth_dt,
                             to_char(to_date(setl_dt, 'yyyymmdd'), 'ddmmyyyy') setl_dt,
                             cdt_tp cdt_tp,
                             vn.fxc_tp_nm_g1('cdt_tp', cdt_tp, 'V') cdt_nm,
                             SUM(sb_amt) mth_amt,
                             SUM(sb_cmsn) sb_cmsn,
                             SUM(sb_tax) sb_tax,
                             SUM(adj_amt) adj_amt
                        FROM vn.dsc01m10
                       WHERE mth_dt = i_mth_dt
                         AND 1 = decode(vn.vwdate, i_mth_dt, 1, 0)
                         AND acnt_no = i_acnt_no
                         AND sub_no = i_sub_no
                         AND bank_cd LIKE '%'
                         AND sb_tp = '1'
                         AND mkt_trd_tp IN ('01', '03', '05')
                         AND dpo_setl_yn = 'N'
                       GROUP BY bank_cd, mth_dt, setl_dt, cdt_tp

                      UNION ALL

                      SELECT '2' tp,
                             bank_cd bank_cd,
                             vn.faa_bank_nm_g(bank_cd) bank_nm,
                             mth_dt mth_dt1,
                             setl_dt setl_dt1,
                             to_char(to_date(mth_dt, 'yyyymmdd'), 'ddmmyyyy') mth_dt,
                             to_char(to_date(setl_dt, 'yyyymmdd'), 'ddmmyyyy') setl_dt,
                             cdt_tp cdt_tp,
                             vn.fxc_tp_nm_g1('cdt_tp', cdt_tp, 'V') cdt_nm,
                             SUM(sb_amt) mth_amt,
                             SUM(sb_cmsn) sb_cmsn,
                             SUM(sb_tax) sb_tax,
                             SUM(adj_amt) adj_amt
                        FROM vn.dsc01m00
                       WHERE mth_dt BETWEEN t_ppre_mth_dt AND t_pre_mth_dt
                         AND acnt_no = i_acnt_no
                         AND sub_no = i_sub_no
                         AND bank_cd LIKE '%'
                         AND sb_tp = '1'
                         AND mkt_trd_tp IN ('01', '03', '05')
                         AND dpo_setl_yn = 'N'
                       GROUP BY bank_cd, mth_dt, setl_dt, cdt_tp) x
              ORDER BY x.bank_cd, x.mth_dt1, x.setl_dt1, x.cdt_tp) LOOP

    BEGIN
      SELECT nvl(SUM(nvl(lnd_amt, 0) - nvl(lnd_rpy_amt, 0)), 0) lnd_rm_amt
        INTO td_lnd_rm_amt
        FROM vn.dlm01m20
       WHERE lnd_tp = '10'
         AND acnt_no = i_acnt_no
         AND sub_no = i_sub_no
         AND mth_dt = c1.mth_dt1
         AND setl_dt = c1.setl_dt1
         AND expr_dt = c1.setl_dt1
         AND lnd_bank_cd LIKE decode(i_lnd_bank_cd, '9999', '%', '%')
         AND lnd_acpt_tp = '01'
         AND cncl_yn = 'N';
    EXCEPTION
      WHEN OTHERS THEN
        raise_application_error(-20100, 'Error 2');
    END;

    IF c1.cdt_tp IN ('20', '30') THEN
      td_d0_rpy_amt := 0;
      td_d1_rpy_amt := 0;
      td_d2_rpy_amt := 0;
      td_d3_rpy_amt := 0;
      td_d0_rpy_int := 0;
      td_d1_rpy_int := 0;
      td_d2_rpy_int := 0;
      td_d3_rpy_int := 0;

      vn.pdl_mrtg_rpyable_amt(c1.cdt_tp,
                              i_acnt_no,
                              i_sub_no,
                              '%',
                              '%',
                              td_d0_rpy_amt,
                              td_d1_rpy_amt,
                              td_d2_rpy_amt,
                              td_d3_rpy_amt,
                              td_d0_rpy_int,
                              td_d1_rpy_int,
                              td_d2_rpy_int,
                              td_d3_rpy_int);

      IF c1.mth_dt1 = t_vwdate THEN
        c1.adj_amt := c1.adj_amt - td_d3_rpy_amt - td_d3_rpy_int;
      ELSIF c1.mth_dt1 = t_pre_mth_dt THEN
        c1.adj_amt := c1.adj_amt - td_d2_rpy_amt - td_d2_rpy_int;
      ELSIF c1.mth_dt1 = t_ppre_mth_dt THEN
        c1.adj_amt := c1.adj_amt - td_d1_rpy_amt - td_d1_rpy_int;
      ELSIF c1.mth_dt1 = t_pppre_mth_dt THEN
        c1.adj_amt := c1.adj_amt - td_d0_rpy_amt - td_d0_rpy_int;
      END IF;

    END IF;

    BEGIN
      vn.pdl_get_lnd_cmsn('10',
                          i_lnd_bank_cd,
                          i_acnt_no,
                          i_sub_no,
                          vn.vwdate,
                          c1.setl_dt1,
                          0,
                          c1.adj_amt /* :o_mth_amt - :o_sb_cmsn */,
                          0,
                          td_lnd_cmsn_amt);
    EXCEPTION
      WHEN OTHERS THEN
        raise_application_error(-20011,
                                'Error on pdl_get_lnd_cmsn_abl' ||
                                ' ACNT_NO=' || i_acnt_no || '-' || i_sub_no);
    END;

    BEGIN
      vn.pdl_get_pay_lnd_cmsn('10',
                              i_lnd_bank_cd,
                              i_acnt_no,
                              i_sub_no,
                              c1.mth_dt1,
                              c1.setl_dt1,
                              c1.adj_amt,
                              td_pay_lnd_cmsn,
                              td_abl_lnd_cmsn);
    EXCEPTION
      WHEN OTHERS THEN
        raise_application_error(-20011,
                                'Error on pdl_get_pay_lnd_cmsn' ||
                                ' ACNT_NO=' || i_acnt_no || '-' || i_sub_no);
    END;

    IF (td_pay_lnd_cmsn = 0 AND td_abl_lnd_cmsn = 0) THEN
      td_abl_amt := greatest(c1.adj_amt - td_lnd_rm_amt - td_lnd_cmsn_amt,
                             0);
    ELSE
      td_abl_amt := greatest(c1.adj_amt - td_lnd_rm_amt - td_pay_lnd_cmsn -
                             td_abl_lnd_cmsn,
                             0);

    END IF;

    IF td_abl_amt > 0 THEN
      td_count := td_count + 1;
    END IF;

    td_sum_cmsn    := td_sum_cmsn + td_lnd_cmsn_amt;
    td_sum_abl_amt := td_sum_abl_amt + td_abl_amt;
  END LOOP;

  IF i_rt_tp = 3 THEN
    td_sum_abl_amt := td_count;
  END IF;
  RETURN td_sum_abl_amt;
END fdl_get_pia_avl_amt;
/

