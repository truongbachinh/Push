create procedure pxb_daily_err
    ( i_exe_dt     in     varchar2,
      i_pgm_id     in     varchar2,
      i_work_stat  in     varchar2,
      i_err_log    in     varchar2,
	  i_proc_cnt   in     number
    ) as

t_seq_no       number;
t_err_txt      varchar2(500);
exp_error      exception;

begin

	select nvl(max(seq_no),0)
	  into t_seq_no
	  from vn.xbd01m10
	 where pgm_id = i_pgm_id
	   and exe_dt = i_exe_dt;

	t_seq_no := t_seq_no + 1;

	-- Job Start
	if i_work_stat = '1' then
		update vn.xbd01m00
		   set work_stat      = '1'
		     , work_strt_time = sysdate
		 where pgm_id = i_pgm_id;

	-- Job End(No error)
	elsif i_work_stat = '2' then
		update vn.xbd01m00
		   set work_stat     = '2'
		     , work_end_time = sysdate
		     , proc_cnt      = i_proc_cnt
		 where pgm_id = i_pgm_id;
	/*
		insert into vn.xbd01m10
		       ( exe_dt         , pgm_id  , err_log  ,
		         work_stat  , work_time, seq_no)
		values ( i_exe_dt       , i_pgm_id, i_err_log,
		         i_work_stat, sysdate  , t_seq_no);
	*/

	-- Job End(With error)
	elsif i_work_stat = '3' then
		update vn.xbd01m00
		   set work_stat     = '3'
		     , work_end_time = sysdate
		 where pgm_id = i_pgm_id;

		/* Caution : Don't change replace sentence, It's for removal CR/LF */
		insert into vn.xbd01m10
		       ( exe_dt     , pgm_id   , err_log  ,
		         work_stat  , work_dtm , seq_no)
		values ( i_exe_dt   , i_pgm_id ,
		         rtrim(replace(replace(i_err_log,'
',' '),'  ','')),
     	         i_work_stat, sysdate  , t_seq_no);

	-- Job Start after error occured
	-- Only update work_stat to '1'
	elsif i_work_stat = '4' then
		update vn.xbd01m00
		   set work_stat     = '1'
		     , work_end_time = null
		 where pgm_id = i_pgm_id;

	-- Start Binary Programs(START_PC) Only Update WORK_STRT_TIME
	elsif i_work_stat = '5' then
		update vn.xbd01m00
		   set work_strt_time = sysdate
		     , work_end_time  = null
		 where pgm_id = i_pgm_id;
	end if;

	exception when exp_error then
	     raise_application_error(-20100, 'sql error'||t_err_txt);

	commit;

END pxb_daily_err;
/

