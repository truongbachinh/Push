create FUNCTION    fdl_get_prd_acnt_rt(
    i_acnt_no        IN   VARCHAR2, 
    i_sub_no         IN   VARCHAR2,
    i_prd_no         IN   VARCHAR2,
    i_rt_tp          IN   VARCHAR2,
    i_apy_dt         IN   VARCHAR2
)   RETURN  NUMBER AS
/*!
   \file     fdl_get_prd_acnt_rt.sql
   \brief    margin information
   \modify   20180604 hoang nguyen
*/

    t_gen_rate      NUMBER      := NULL;
    t_priv_rate     NUMBER      := NULL;
    t_int_brkt_no   VARCHAR2(5) := NULL;
    t_latest_prd_id NUMBER      := NULL;

    t_gen_chk       NUMBER      := -1;
    t_priv_chk      NUMBER      := -1;

    t_err_msg       VARCHAR2(500);

    o_out_number    NUMBER      := 0; 

BEGIN
/* 
    ******************************************** Cac tham so cua San Pham 
    01: fee_amt_min              - so tien phi toi thieu           default 0         - San pham (dlm30m00) ==> chi co Chinh sach chung   
    02: fee_days_min             - so ngay tinh phi toi thieu      default 0         - San pham (dlm30m00) ==> chi co Chinh sach chung  
    03: int_days_min             - So ngay tinh lai toi thieu      default 0         - San pham (dlm30m00) ==> chi co Chinh sach chung
    04: int_amt_min              - So tien tinh lai toi thieu      default 0         - San pham (dlm30m00) ==> chi co Chinh sach chung
    05: loan_disb_term           - ky han giai ngan                default 0         - San pham (dlm30m01/dlm30m00)
    06: int_rt                   - ti le lai trong han             default 0         - San pham (dlm30m01/dlm30m00)
    07: int_dly_rt               - ti le lai qua han               default 0         - San pham (dlm30m01/dlm30m00)    
    08: fee_rt                   - ti le phi trong han             default 0         - San pham (dlm30m01/dlm30m00)
    09: fee_dly_rt               - ti le phi qua han               default 0         - San pham (dlm30m01/dlm30m00)      
    10: int_waive_days           - so ngay mien lai                default 0         - San pham (dlm30m01/dlm30m00)
    11: int_waive_day_tp         - Phan loai ngay mien lai         default 1         - San pham (dlm30m01/dlm30m00)
    12: rn_num_max               - So lan gia han toi da           default 0         - San pham (dlm30m01/dlm30m00)  
    13: ro_fee_rt                - Ti le phi dao no                default 0         - San pham (dlm30m01/dlm30m00)  
    14: ro_fee_min               - Phi dao no toi thieu            default 0         - San pham (dlm30m01/dlm30m00)    
    15: ro_num_max               - So lan dao no toi da            default 0         - San pham (dlm30m01/dlm30m00)
    16: int_pay_yn               - Thu no tu dong Y/N              default 1         - San pham (dlm30m01/dlm30m00)

*/

    -- Validate input value for i_rt_tp
    IF (i_rt_tp NOT IN ('01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16')) THEN
        t_err_msg := 'Loi khi lay thong tin san pham. Loai tra cuu khong chinh xac'
                  || ' i_rt_tp = ' || i_rt_tp;

        vn.pxc_log_write('fdl_get_prd_acnt_rt', t_err_msg);
        raise_application_error(-20100, t_err_msg);
    END IF;

    -- Validate input value for i_prd_no: must be NOT NULL
    IF(i_prd_no IS NULL) THEN
        t_err_msg := 'Ma san pham phai NOT NULL';

        vn.pxc_log_write('fdl_get_prd_acnt_rt', t_err_msg);
        raise_application_error(-20100, t_err_msg);
    END IF;

    /* ********************************************************************************************
        Quy tac lay data
            - 1. Neu ko co CSC tai ngay tra cuu, thi lay CSC cua ngay ap dung gan nhat
                + Neu ko co CSC nao   --> return default value
            - 2. Neu co CSC:
                + Neu co CSR    --> Lay CSR
                + Neu ko co CRS --> Lay CSC
    **********************************************************************************************/
    -- 1. Lay chinh sach chung
    BEGIN
        t_gen_chk := 1;

        -- Lay setup gan nhat truoc i_apy_dt
        select distinct
            first_value(prd_id) over(partition by prd_no order by apy_dt desc, prd_id desc) latest_prd_id
        into
            t_latest_prd_id
        from vn.dlm30m00
        where prd_no        =  i_prd_no
        and active_stat     = 'Y'
        and apy_dt         <= i_apy_dt
        and apy_dt         <= expr_dt;

        SELECT DECODE(i_rt_tp,  '01', NVL(fee_amt_min, 0)       ,       -- so tien phi toi thieu
                                '02', NVL(fee_days_min, 0)      ,       -- so ngay tinh phi toi thieu
                                '03', NVL(int_days_min, 0)      ,       -- So ngay tinh lai toi thieu
                                '04', NVL(int_amt_min, 0)       ,       -- So tien tinh lai toi thieu
                                '05', NVL(loan_disb_term, 0)    ,       -- ky han giai ngan
                                '06', NVL(int_rt, 0)            ,       -- ti le lai trong han
                                '07', NVL(int_dly_rt, 0)        ,       -- ti le lai qua han
                                '08', NVL(fee_rt, 0)            ,       -- ti le phi trong han
                                '09', NVL(fee_dly_rt, 0)        ,       -- ti le phi qua han
                                '10', NVL(int_waive_days, 0)    ,       -- so ngay mien lai
                                '11', NVL(int_waive_day_tp, 1)  ,       -- Phan loai ngay mien lai
                                '12', NVL(rn_num_max, 0)        ,       -- So lan gia han toi da
                                '13', NVL(ro_fee_rt, 0)         ,       -- Ti le phi dao no
                                '14', NVL(ro_fee_min, 0)        ,       -- Phi dao no toi thieu
                                '15', NVL(ro_num_max, 0)        ,       -- So lan dao no toi da
                                '16', NVL(int_pay_yn, 1)                -- Thu lai tu dong Y/N
                    ) gen_rate,
                NVL(int_brkt_no, '!') int_brkt_no
        INTO t_gen_rate, t_int_brkt_no
        FROM vn.dlm30m00
        WHERE prd_id = t_latest_prd_id;

        -- Rieng voi lai dong, NHSV dang tinh theo khung lai suat, nen phai lay rieng
        IF (i_rt_tp in ('06')) THEN
            IF (t_int_brkt_no <> '!') THEN
                t_gen_rate := vn.fdl_get_int_brkt_rt(null, null, null, t_int_brkt_no, i_apy_dt, 1);
            END IF;
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            t_err_msg := vn.fxc_get_err_msg('V','460000');
            vn.pxc_log_write('fdl_get_prd_acnt_rt',     'Loi khi lay chinh sach chung cho :'
                                                    || ' i_acnt_no = '      || i_acnt_no || '-' || ' i_sub_no=' || i_sub_no
                                                    || ' i_rt_tp = '  || i_rt_tp
                            );

            raise_application_error(-20100, t_err_msg   || ' fdl_get_prd_acnt_rt: Loi khi lay chinh sach chung cho:'
                                                    || ' i_acnt_no = '      || i_acnt_no || '-' || ' i_sub_no=' || i_sub_no
                                                    || ' i_rt_tp = '  || i_rt_tp
                                    );
    END; -- End: Lay CSC

    IF(i_rt_tp IN ('05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16') 
        AND t_gen_chk = 1) THEN
        -- 2. Neu co CSC, kiem tra xem co CSR hay khong
        t_priv_chk := 1;

        BEGIN
            SELECT DECODE(i_rt_tp,  '05', loan_disb_term,       -- ky han giai ngan
                                    '06', int_rt,               -- ti le lai trong han
                                    '07', int_dly_rt,           -- ti le lai qua han
                                    '08', fee_rt,               -- ti le phi trong han
                                    '09', fee_dly_rt,           -- ti le phi qua han
                                    '10', int_waive_days,       -- so ngay mien lai
                                    '11', int_waive_day_tp,     -- Phan loai ngay mien lai
                                    '12', rn_num_max,           -- So lan gia han toi da
                                    '13', ro_fee_rt,            -- Ti le phi dao no
                                    '14', ro_fee_min,           -- Phi dao no toi thieu
                                    '15', ro_num_max,           -- So lan dao no toi da
                                    '16', int_pay_yn            -- Thu lai tu dong Y/N
                    ) priv_rate
            INTO t_priv_rate
            FROM vn.dlm30m01
            WHERE acnt_no    = i_acnt_no
            AND sub_no       = i_sub_no
            AND prd_no       = i_prd_no
            AND apy_dt      <= i_apy_dt
            AND expr_dt     >= i_apy_dt
            AND active_stat  = 'Y';

        EXCEPTION 
            WHEN NO_DATA_FOUND THEN
                t_priv_chk := 0;

            WHEN OTHERS THEN
                t_err_msg := vn.fxc_get_err_msg('V','461000');
                vn.pxc_log_write('fdl_get_prd_acnt_rt',     'Loi khi lay chinh sach rieng cho'
                                                            || ' i_acnt_no = '      || i_acnt_no || '-' || ' i_sub_no=' || i_sub_no
                                                            || ' i_rt_tp = '  || i_rt_tp
                                );

                raise_application_error(-20100, t_err_msg   || ' fdl_get_prd_acnt_rt: Loi khi lay chinh sach rieng cho'
                                                            || ' i_acnt_no = '      || i_acnt_no || '-' || ' i_sub_no=' || i_sub_no
                                                            || ' i_rt_tp = '  || i_rt_tp
                                        );
        END; -- End: Lay CSR
    END IF;

    IF (t_priv_chk = 1 
        AND t_priv_rate IS NOT NULL 
        AND i_rt_tp IN ('05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16'))
    THEN
        o_out_number := t_priv_rate;
    ELSE
        o_out_number := t_gen_rate;
    END IF;

    RETURN o_out_number;

END fdl_get_prd_acnt_rt;
/

