create PROCEDURE PAA_IDNO_PERSONAL_INS
(
    is_ins_tp       IN VARCHAR2,
    is_grp_tp       IN VARCHAR2,
    is_idno         IN VARCHAR2,
    is_cust_nm      IN VARCHAR2,
    is_iss_dt       IN VARCHAR2,
    is_iss_place    IN VARCHAR2,
    is_sex_tp       IN VARCHAR2,
    is_cust_eng_nm  IN VARCHAR2,
    is_ctry_cd      IN VARCHAR2,
    is_birth_dt     IN VARCHAR2,
    is_home_addr    IN VARCHAR2,
    is_home_tel     IN VARCHAR2,
    is_office_addr  IN VARCHAR2,
    is_office_tel   IN VARCHAR2,
    is_job_cd       IN VARCHAR2,
    is_office_nm    IN VARCHAR2,
    is_email        IN VARCHAR2,
    is_mobile       IN VARCHAR2,
    is_fax          IN VARCHAR2,
    is_addr_tp      IN VARCHAR2,
    is_tel_tp       IN VARCHAR2,
    is_sms_yn       IN VARCHAR2,
    is_frgn_tp      IN VARCHAR2,
    is_user_id      IN VARCHAR2,
    is_ip_addr      IN VARCHAR2,
    is_proc_dept    IN VARCHAR2,
    is_etc_tel      IN VARCHAR2,
    is_etc_addr     IN VARCHAR2,
    is_tax_cd       IN VARCHAR2,
    is_staff_yn     IN VARCHAR2,
    is_idno_tp      IN VARCHAR2,
    is_cont_addr    IN VARCHAR2 DEFAULT ' ',    /* NHSV-1247 */
    is_mobile_2     IN VARCHAR2 DEFAULT ' '     /* NHSV-1247 */
) AS
/*
    \file   paa_idno_rep_ins
    \brief  Personal Info insert

    \section intro Program Information

    - Program Name                              : Customer Information insert
    - Service Name                              : paa_idno_rep_ins.pc
    - Related Client Program- Client ProgramID  : w_01101
    - Related Tables                            : aaa02m00,aaa02m10
    - Dev. Date                                 : 2007/10/17
    - Business Logi                             :
    - Latest Modification Date                  : 2020/11/16 (HienND/NHSV-1167)

    \section history Program Modification History
    - 1.0   2007/10/17      mkkim
    - 1.1   2008/02/15      mkkim   optional information NVL(xx, '!') compare

    \section hardcoding Hard-Coding List

    \section info Additional Reference Comments
        **important**
        Personal Information  aaa02m00 Insert /Update
        if Update . insert hisroty list (aaa02h00)

        ** called TUX ->
*/

acntno          VARCHAR2(20);
subno           VARCHAR2(2);
chk             VARCHAR2(1);

ts_idno_cnt     VARCHAR2(1);
ts_active_yn    VARCHAR2(1);
ts_bef_info     VARCHAR2(200);
ts_aft_info     VARCHAR2(200);
ts_chk          CHAR(1)         := 'N';
ts_grp_tp       VARCHAR2(1)     := is_grp_tp;
ts_idno         VARCHAR2(20)    := is_idno;
ts_cust_nm      VARCHAR2(200)   := REPLACE(is_cust_nm,      '~', '-');
ts_iss_dt       VARCHAR2(8)     := is_iss_dt;
ts_iss_place    VARCHAR2(100)    := REPLACE(is_iss_place,    '~', '-');
ts_sex_tp       VARCHAR2(1)     := is_sex_tp;
ts_cust_eng_nm  VARCHAR2(200)   := is_cust_eng_nm;
ts_ctry_cd      VARCHAR2(3)     := is_ctry_cd;
ts_birth_dt     VARCHAR2(8)     := is_birth_dt;
ts_home_addr    VARCHAR2(200)   := REPLACE(is_home_addr,    '~', '-');
ts_home_tel     VARCHAR2(20)    := REPLACE(is_home_tel,     '~', '-');
ts_office_addr  VARCHAR2(200)   := REPLACE(is_office_addr,  '~', '-');
ts_office_tel   VARCHAR2(20)    := REPLACE(is_office_tel,   '~', '-');
ts_job_cd       VARCHAR2(3)     := is_job_cd;
ts_office_nm    VARCHAR2(200)   := REPLACE(is_office_nm,    '~', '-');
ts_email        VARCHAR2(50)    := REPLACE(is_email,        '~', '-');
ts_mobile       VARCHAR2(20)    := REPLACE(is_mobile,       '~', '-');
ts_fax          VARCHAR2(20)    := REPLACE(is_fax,          '~', '-');
ts_addr_tp      VARCHAR2(1)     := is_addr_tp;
ts_tel_tp       VARCHAR2(1)     := is_tel_tp;
ts_sms_yn       VARCHAR2(1)     := is_sms_yn;
ts_frgn_tp      VARCHAR2(1)     := is_frgn_tp;
ts_user_id      VARCHAR2(20)    := is_user_id;
ts_ip_addr      VARCHAR2(15)    := is_ip_addr;
ts_proc_dept    VARCHAR2(10)    := is_proc_dept;
ts_etc_tel      VARCHAR2(20)    := is_etc_tel;
ts_etc_addr     VARCHAR2(200)   := is_etc_addr;
ts_tax_cd       VARCHAR2(20)    := is_tax_cd;
ts_staff_yn     VARCHAR2(1)     := is_staff_yn;
ts_cont_addr    VARCHAR2(200)   := is_cont_addr;
ts_mobile_2     VARCHAR2(20)    := is_mobile_2;
ts_acnt_no      VARCHAR2(10);

/* ------------------------------------------------------------ */
/* Sub Procedure: Changed info history insert                   */
/* ------------------------------------------------------------ */

PROCEDURE SUB_HISTORY_INSERT
            (
                ri_chg_tp       IN VARCHAR2,
                ri_bef_info     IN VARCHAR2,
                ri_aft_info     IN VARCHAR2
            ) IS

    BEGIN

        VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Sub-Procedure: SUB_HISTORY_INSERT - Start!');
        VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Sub-Procedure: SUB_HISTORY_INSERT - Start Select ACTIVE_YN.');

        BEGIN
            SELECT  ACTIVE_YN
            INTO    ts_active_yn
            FROM    VN.AAA01M00
            WHERE   IDNO        = is_idno
                AND SUB_NO      = '00'
                AND ACNT_STAT   = '1';
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
                VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'NO_DATA_FOUND Flag 0');
        END;

        VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Sub-Procedure: SUB_HISTORY_INSERT - End Select ACTIVE_YN.');

        BEGIN

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Sub-Procedure: SUB_HISTORY_INSERT - Start Insert into VN.AAA02H00.');

            INSERT INTO VN.AAA02H00
            (
                IDNO,
                CHG_DTM,
                CUST_INFO_CHG_TP,
                CHG_PRE_CONT,
                CHG_AF_CONT,
                WORK_BNH,
                WORK_MN,
                WORK_TRM,
                WORK_DTM,
                CONF_TYPE,
                SEQ_NO
            )
            VALUES
            (
                is_idno,
                SYSDATE,
                ri_chg_tp,
                ri_bef_info,
                ri_aft_info,
                is_proc_dept,
                is_user_id,
                is_ip_addr,
                SYSDATE,
                DECODE(ts_active_yn, 'Y', 'W', 'A'),
                vn.aaa02h00_seq.nextval
            );
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'NO_DATA_FOUND Flag 0');
                WHEN OTHERS THEN
                    raise_application_error(-20100, '[paa_idno_personal_ins] insert aaa02h00 error!');

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Sub-Procedure: SUB_HISTORY_INSERT - End Insert into VN.AAA02H00.');

        END;

        VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Sub-Procedure: SUB_HISTORY_INSERT - End!');

    END;

/* Sub Procedure End */

/* ------------------------------------------------------------ */
/* Main Procedure: AAA02M00/AAA02M10 update/insert              */
/* ------------------------------------------------------------ */
BEGIN

    VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: PAA_IDNO_PERSONAL_INS - Start!');

    VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: PAA_IDNO_PERSONAL_INS - Check IDNO in AAA02M00 Start!');

    BEGIN
        SELECT  COUNT(*)
        INTO    ts_idno_cnt
        FROM    VN.AAA02M00
        WHERE   IDNO    = ts_idno;
    END;

    VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: PAA_IDNO_PERSONAL_INS - Check IDNO in AAA02M00 End!');

    /* IDNO already exists => Case: IDNO's information Change */
    if ts_idno_cnt <> '0' then

        VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: IDNO already exists!');
        VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: C1 Loop Start!');

        FOR C1 IN
        (
            SELECT  NVL(A.IDNO,             ' ')    IDNO,
                    NVL(A.CUST_NM,          ' ')    CUST_NM,
                    NVL(A.IDNO_ISS_DT,      ' ')    ISS_DT,
                    NVL(A.IDNO_ISS_ORGA,    ' ')    ISS_PLACE,
                    NVL(A.SEX_TP,           ' ')    SEX_TP,
                    NVL(A.CUST_ENG_NM,      ' ')    CUST_ENG_NM,
                    NVL(A.CTRY_CD,          ' ')    CTRY_CD,
                    NVL(A.BIRTH_DT,         ' ')    BIRTH_DT,
                    NVL(B.HOME_ADDR,        ' ')    HOME_ADDR,
                    NVL(B.HOME_TEL,         ' ')    HOME_TEL,
                    NVL(B.OFFICE_ADDR,      ' ')    OFFICE_ADDR,
                    NVL(B.OFFICE_TEL,       ' ')    OFFICE_TEL,
                    NVL(A.JOB_CD,           ' ')    JOB_CD,
                    NVL(A.OFFICE_NM,        ' ')    OFFICE_NM,
                    NVL(B.EMAIL,            ' ')    EMAIL,
                    NVL(B.MOBILE,           ' ')    MOBILE,
                    NVL(B.FAX,              ' ')    FAX,
                    NVL(A.GRP_TP,           '1')    GRP_TP,
                    NVL(B.CONCT_ADDR_TP,    ' ')    ADDR_TP,
                    NVL(B.CONCT_TEL_TP,     ' ')    TEL_TP,
                    NVL(B.SMS_YN,           ' ')    SMS_YN,
                    NVL(A.FRGN_TP,          ' ')    FRGN_TP,
                    NVL(B.ETC_TEL,          ' ')    ETC_TEL,
                    NVL(B.ETC_ADDR,         ' ')    ETC_ADDR,
                    NVL(A.TAX_CD,           ' ')    TAX_CD,
                    NVL(A.STAFF_YN,         'N')    STAFF_YN,
                    NVL(B.CONT_ADDR,        ' ')    CONT_ADDR,
                    NVL(B.MOBILE_2,         ' ')    MOBILE_2
            FROM    VN.AAA02M00 A,
                    VN.AAA02M10 B
            WHERE   A.IDNO = ts_idno
                AND A.IDNO = B.IDNO(+)
        )
        LOOP

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: Change information Case Loop Start!');
            ts_chk := 'Y';

            if is_ins_tp <> '1' then
            /*
                - is_ins_tp = 2: representative
                - is_ins_tp = 4: agent
            */

                ts_cust_eng_nm  := TRIM(C1.CUST_ENG_NM);
                ts_office_nm    := TRIM(C1.OFFICE_NM);
                ts_fax          := TRIM(C1.FAX);
                ts_sms_yn       := TRIM(C1.SMS_YN);

                if is_addr_tp = '1' then
                    ts_office_addr  := TRIM(C1.OFFICE_ADDR);
                else
                    ts_home_addr    := TRIM(C1.HOME_ADDR);
                end if;

                if is_tel_tp = '1' then
                    ts_office_tel   := TRIM(C1.OFFICE_TEL);
                else
                    ts_home_tel     := TRIM(C1.HOME_TEL);
                end if;

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: Start Select ACTIVE_YN.');

            /* Xử lý riêng cho Tài khoản chưa kích hoạt */
            BEGIN
                SELECT  ACTIVE_YN, ACNT_NO
                INTO    ts_active_yn,ts_acnt_no
                FROM    VN.AAA01M00
                WHERE   IDNO        = is_idno
                    AND SUB_NO      = '00'
                    AND ACNT_STAT   = '1';
                EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                        VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'NO_DATA_FOUND Flag 1');
                        ts_active_yn :='N';
            END;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: End Select ACTIVE_YN.');

            if ts_active_yn = 'N' then

                VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: Update AAA02M00 Start.');

                BEGIN
                    UPDATE  VN.AAA02M00
                    SET     CUST_NM         = ts_cust_nm,
                            IDNO_ISS_DT     = ts_iss_dt,
                            IDNO_ISS_ORGA   = ts_iss_place,
                            SEX_TP          = ts_sex_tp,
                            CUST_ENG_NM     = ts_cust_eng_nm,
                            CTRY_CD         = ts_ctry_cd,
                            BIRTH_DT        = ts_birth_dt,
                            JOB_CD          = NVL(ts_job_cd,'99'),
                            OFFICE_NM       = ts_office_nm,
                            GRP_TP          = ts_grp_tp,
                            FRGN_TP         = ts_frgn_tp,
                            TAX_CD          = TRIM(ts_tax_cd),
                            STAFF_YN        = TRIM(ts_staff_yn),
                            WORK_MN         = ts_user_id,
                            WORK_TRM        = ts_ip_addr,
                            WORK_DTM        = SYSDATE,
                            IDNO_TP         = is_idno_tp
                    WHERE   IDNO            = ts_idno ;
                    EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'NO_DATA_FOUND Flag 2');
                        WHEN OTHERS THEN
                            raise_application_error(-20100, '[paa_idno_personal_ins] update aaa02m00 error!');
                END;

                VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: Update AAA02M00 End.');
                VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: Update AAA02M10 Start.');

                BEGIN
                    UPDATE  VN.AAA02M10
                    SET     HOME_ADDR       = ts_home_addr,
                            CONT_ADDR       = ts_cont_addr,
                            HOME_TEL        = ts_home_tel,
                            OFFICE_ADDR     = ts_office_addr,
                            OFFICE_TEL      = ts_office_tel,
                            EMAIL           = ts_email,
                            MOBILE          = ts_mobile,
                            FAX             = ts_fax,
                            CONCT_ADDR_TP   = ts_addr_tp,
                            CONCT_TEL_TP    = ts_tel_tp,
                            SMS_YN          = NVL(ts_sms_yn, 'N'),
                            ETC_TEL         = ts_etc_tel,
                            ETC_ADDR        = ts_etc_addr,
                            WORK_MN         = ts_user_id,
                            WORK_TRM        = ts_ip_addr,
                            WORK_DTM        = SYSDATE
                    WHERE   IDNO            = ts_idno;
                    EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'NO_DATA_FOUND Flag 3');
                        WHEN OTHERS THEN
                            raise_application_error(-20100, '[paa_idno_personal_ins] update aaa02m10 error!');
                END;

                VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: Update AAA02M10 End.');
                VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: Update AAA01M00 Start.');
                BEGIN
                    UPDATE  VN.AAA01M00
                    SET     CUST_NM         = ts_cust_nm
                    WHERE   IDNO            = ts_idno;
                    EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'NO_DATA_FOUND Flag 3');
                        WHEN OTHERS THEN
                            raise_application_error(-20100, '[paa_idno_personal_ins] update AAA01M00 error!');
                END;
                VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: Update AAA01M00 End.');
                VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: Update AAA01M00 Start.');
                BEGIN
                    UPDATE  VN.XCA01M07
                    SET     MOBILE          = ts_mobile
                    WHERE   ACNT_NO         = ts_acnt_no;
                    EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'NO_DATA_FOUND Flag 3');
                        WHEN OTHERS THEN
                            raise_application_error(-20100, '[paa_idno_personal_ins] update XCA01M07 error!');
                END;
                VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: Update XCA01M07 End.');

            end if;
            /* Hết xử lý riêng cho Tài khoản chưa Kích hoạt */

            /* History input data setting */
            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data Start.');

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - GRP_TP.');
            if TRIM(ts_grp_tp) <> TRIM(C1.GRP_TP) then

                SUB_HISTORY_INSERT
                (
                    '01',
                    C1.GRP_TP || '.' || VN.FXC_TP_NM_G('grp_tp', C1.GRP_TP),
                    ts_grp_tp || '.' || VN.FXC_TP_NM_G('grp_tp', ts_grp_tp)
                );

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - CUST_NM.');
            if TRIM(ts_cust_nm) <> TRIM(C1.CUST_NM) then

                SUB_HISTORY_INSERT
                (
                    '02',
                    C1.CUST_NM,
                    ts_cust_nm
                );

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - ISS_DT.');
            if NVL(TRIM(ts_iss_dt), '!') <> NVL(TRIM(C1.ISS_DT), '!') then

                SUB_HISTORY_INSERT
                (
                    '03',
                    SUBSTR(C1.ISS_DT, 7, 2) || '/' || SUBSTR(C1.ISS_DT, 5, 2) || '/' || SUBSTR(C1.ISS_DT, 1, 4),
                    SUBSTR(ts_iss_dt, 7, 2) || '/' || SUBSTR(ts_iss_dt, 5, 2) || '/' || SUBSTR(ts_iss_dt, 1, 4)
                );

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - ISS_PLACE.');
            if NVL(TRIM(ts_iss_place), '!') <> NVL(TRIM(C1.ISS_PLACE), '!') then

                SUB_HISTORY_INSERT
                (
                    '04',
                    C1.ISS_PLACE,
                    ts_iss_place
                );

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - SEX_TP.');
            if TRIM(ts_sex_tp) <> TRIM(C1.SEX_TP) then

                SUB_HISTORY_INSERT
                (
                    '05',
                    C1.SEX_TP || '.' || VN.FXC_TP_NM_G('sex_tp', C1.SEX_TP),
                    ts_sex_tp || '.' || VN.FXC_TP_NM_G('sex_tp', ts_sex_tp)
                );

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - CUST_ENG_NM.');
            if NVL(TRIM(ts_cust_eng_nm), '!') <> NVL(TRIM(C1.CUST_ENG_NM), '!') then

                SUB_HISTORY_INSERT
                (
                    '06',
                    C1.CUST_ENG_NM,
                    ts_cust_eng_nm
                );

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - CTRY_CD.');
            if TRIM(ts_ctry_cd) <> TRIM(C1.CTRY_CD) then

                SUB_HISTORY_INSERT
                (
                    '07',
                    C1.CTRY_CD || '.' || VN.FAA_CTRY_NM_G('1', C1.CTRY_CD),
                    ts_ctry_cd || '.' || VN.FAA_CTRY_NM_G('1', ts_ctry_cd)
                );

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - BIRTH_DT.');
            if NVL(TRIM(ts_birth_dt), '!') <> NVL(TRIM(C1.BIRTH_DT), '!') then

                SUB_HISTORY_INSERT
                (
                    '08',
                    SUBSTR(C1.BIRTH_DT, 7, 2) || '/' || SUBSTR(C1.BIRTH_DT, 5, 2) || '/' || SUBSTR(C1.BIRTH_DT, 1, 4),
                    SUBSTR(ts_birth_dt, 7, 2) || '/' || SUBSTR(ts_birth_dt, 5, 2) || '/' || SUBSTR(ts_birth_dt, 1, 4)
                );

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - JOB_CD.');
            if NVL(TRIM(ts_job_cd), '99') <> NVL(TRIM(C1.JOB_CD), '99') then

                SUB_HISTORY_INSERT
                (
                    '09',
                    C1.JOB_CD || '.' || VN.FXC_TP_NM_G('job_cd', C1.JOB_CD),
                    ts_job_cd || '.' || VN.FXC_TP_NM_G('job_cd', ts_job_cd)
                );

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - OFFICE_NM.');
            if NVL(TRIM(ts_office_nm), '!') <> NVL(TRIM(C1.OFFICE_NM), '!') then

                SUB_HISTORY_INSERT
                (
                    '10',
                    C1.OFFICE_NM,
                    ts_office_nm
                );
            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - HOME_ADDR.');
            if NVL(TRIM(ts_home_addr), '!') <> NVL(TRIM(C1.HOME_ADDR), '!') then

                SUB_HISTORY_INSERT
                (
                    '11',
                    C1.HOME_ADDR,
                    ts_home_addr
                );

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - HOME_TEL.');
            if NVL(TRIM(ts_home_tel), '!') <> NVL(TRIM(C1.HOME_TEL), '!') then

                SUB_HISTORY_INSERT
                (
                    '12',
                    C1.HOME_TEL,
                    ts_home_tel
                );

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - OFFICE_ADDR.');
            if NVL(TRIM(ts_office_addr), '!') <> NVL(TRIM(C1.OFFICE_ADDR), '!') then

                SUB_HISTORY_INSERT
                (
                    '13',
                    C1.OFFICE_ADDR,
                    ts_office_addr
                );

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - OFFICE_TEL.');
            if NVL(TRIM(ts_office_tel), '!') <> NVL(TRIM(C1.OFFICE_TEL), '!') then

                SUB_HISTORY_INSERT
                (
                    '14',
                    C1.OFFICE_TEL,
                    ts_office_tel
                );

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - EMAIL.');
            if NVL(TRIM(ts_email), '!') <> NVL(TRIM(C1.EMAIL), '!') then

                SUB_HISTORY_INSERT
                (
                    '15',
                    C1.EMAIL,
                    ts_email
                );

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - MOBILE.');
            if NVL(TRIM(ts_mobile), '!') <> NVL(TRIM(C1.MOBILE), '!') then

                SUB_HISTORY_INSERT
                (
                    '16',
                    C1.MOBILE,
                    ts_mobile
                );

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - FAX.');
            if NVL(TRIM(ts_fax), '!') <> NVL(TRIM(C1.FAX), '!') then

                SUB_HISTORY_INSERT
                (
                    '17',
                    C1.FAX,
                    ts_fax
                );

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - ADDR_TP.');
            if TRIM(ts_addr_tp) <> TRIM(C1.ADDR_TP) then

                SUB_HISTORY_INSERT
                (
                    '18',
                    C1.ADDR_TP || '.' || VN.FXC_TP_NM_G('addr_adv_tp', C1.ADDR_TP),
                    ts_addr_tp || '.' || VN.FXC_TP_NM_G('addr_adv_tp', ts_addr_tp)
                );
            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - TEL_TP.');
            if TRIM(ts_tel_tp) <> TRIM(C1.TEL_TP) then

                SUB_HISTORY_INSERT
                (
                    '19',
                    C1.TEL_TP || '.' || VN.FXC_TP_NM_G('tel_adv_tp', C1.TEL_TP),
                    ts_tel_tp || '.' || VN.FXC_TP_NM_G('tel_adv_tp', ts_tel_tp)
                );

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - SMS_YN.');
            if TRIM(ts_sms_yn) <> TRIM(C1.SMS_YN) then

                SUB_HISTORY_INSERT
                (
                    '20',
                    C1.SMS_YN,
                    ts_sms_yn
                );

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - FRGN_TP.');
            if TRIM(ts_frgn_tp) <> TRIM(C1.FRGN_TP) then

                SUB_HISTORY_INSERT
                (
                    '21',
                    C1.FRGN_TP || '.' || VN.FXC_TP_NM_G('frgn_tp', C1.FRGN_TP),
                    ts_frgn_tp || '.' || VN.FXC_TP_NM_G('frgn_tp', ts_frgn_tp)
                );

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - ETC_TEL.');
            if NVL(TRIM(ts_etc_tel), '!') <> NVL(TRIM(C1.ETC_TEL), '!') then

                SUB_HISTORY_INSERT
                (
                    '24',
                    C1.ETC_TEL,
                    ts_etc_tel
                );

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - ETC_ADDR.');
            if NVL(TRIM(ts_etc_addr), '!') <> NVL(TRIM(C1.ETC_ADDR), '!') then

                SUB_HISTORY_INSERT
                (
                    '25',
                    C1.ETC_ADDR,
                    ts_etc_addr
                );

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - TAX_CD.');
            if NVL(TRIM(ts_tax_cd), '!') <> NVL(TRIM(C1.TAX_CD), '!') then

                SUB_HISTORY_INSERT
                (
                    '26',
                    C1.TAX_CD,
                    TRIM(ts_tax_cd)
                );

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - STAFF_YN.');
            if TRIM(ts_staff_yn) <> TRIM(C1.STAFF_YN) then

                SUB_HISTORY_INSERT
                (
                    '28',
                    C1.STAFF_YN || '.' || VN.FXC_TP_NM_G('staff_yn', C1.STAFF_YN),
                    ts_staff_yn || '.' || VN.FXC_TP_NM_G('idno_tp', ts_staff_yn)
                );

            end if;

            if NVL(TRIM(ts_cont_addr), '!') <> NVL(TRIM(C1.cont_addr), '!') then

                SUB_HISTORY_INSERT
                (
                    '29',
                    C1.cont_addr,
                    ts_cont_addr
                );

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data - MOBILE_2.');
            if NVL(TRIM(ts_mobile_2), '!') <> NVL(TRIM(C1.MOBILE_2), '!') then

                SUB_HISTORY_INSERT
                (
                    '30',
                    C1.MOBILE_2,
                    ts_mobile_2
                );

            end if;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: History input data End.');

        END LOOP;

        VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: C1 Loop End!');

    /* New Customer => Case: New IDNO Insert */
    else

        VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: New IDNO!');
        VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: New Customer Info Insert Start!');

        if ts_chk = 'N' then

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: New Customer Info Insert - Start Insert into AAA02M00!');

            BEGIN
                INSERT INTO VN.AAA02M00
                (
                    IDNO,
                    CUST_NM,
                    CUST_NM_ABB,
                    CUST_ENG_NM,
                    SEX_TP,
                    GRP_TP,
                    FRGN_TP,
                    IDNO_ISS_DT,
                    IDNO_ISS_ORGA,
                    BIRTH_DT,
                    CTRY_CD,
                    OFFICE_NM,
                    JOB_CD,
                    FRM_REGI_NO,
                    TAX_CD,
                    POSI,
                    WORK_MN,
                    WORK_DTM,
                    WORK_TRM,
                    IDNO_TP
                )
                VALUES
                (
                    ts_idno,
                    ts_cust_nm,
                    NULL,
                    ts_cust_eng_nm,
                    ts_sex_tp,
                    ts_grp_tp,
                    ts_frgn_tp,
                    ts_iss_dt,
                    ts_iss_place,
                    ts_birth_dt,
                    ts_ctry_cd,
                    ts_office_nm,
                    NVL(ts_job_cd, '99'),
                    NULL,
                    TRIM(ts_tax_cd),
                    NULL,
                    ts_user_id,
                    SYSDATE,
                    ts_ip_addr,
                    is_idno_tp
                );
                EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                        VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'NO_DATA_FOUND Flag 4');
                    WHEN OTHERS THEN
                        raise_application_error(-20100, '[paa_idno_personal_ins] insert aaa02m00 error!');
            END;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: New Customer Info Insert - End Insert into AAA02M00!');

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: New Customer Info Insert - Start Insert into AAA02M10!');

            BEGIN
                INSERT INTO VN.AAA02M10
                (
                    IDNO,
                    EMAIL,
                    MOBILE,
                    FAX,
                    HOME_TEL,
                    HOME_ADDR,
                    OFFICE_ADDR,
                    OFFICE_TEL,
                    CONCT_ADDR_TP,
                    CONCT_TEL_TP,
                    SMS_YN,
                    ETC_TEL,
                    ETC_ADDR,
                    WORK_MN,
                    WORK_DTM,
                    WORK_TRM,
                    CONT_ADDR,
                    MOBILE_2
                )
                VALUES
                (
                    ts_idno,
                    ts_email,
                    ts_mobile,
                    ts_fax,
                    ts_home_tel,
                    ts_home_addr,
                    ts_office_addr,
                    ts_office_tel,
                    ts_addr_tp,
                    ts_tel_tp,
                    NVL(ts_sms_yn, 'N'),
                    ts_etc_tel,
                    ts_etc_addr,
                    ts_user_id,
                    SYSDATE,
                    ts_ip_addr,
                    ts_cont_addr,
                    ts_mobile_2
                );
                EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                        VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'NO_DATA_FOUND Flag 5');
                    WHEN OTHERS THEN
                        raise_application_error(-20100, '[paa_idno_personal_ins] insert aaa02m10 error!');
            END;

            VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: New Customer Info Insert - End Insert into AAA02M10!');

        end if;

        VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure: New Customer Info Insert End!');
        VN.PXC_LOG_WRITE('paa_idno_personal_ins', 'Main-Procedure:PAA_IDNO_PERSONAL_INS - End!');

    end if;

END PAA_IDNO_PERSONAL_INS;
/

