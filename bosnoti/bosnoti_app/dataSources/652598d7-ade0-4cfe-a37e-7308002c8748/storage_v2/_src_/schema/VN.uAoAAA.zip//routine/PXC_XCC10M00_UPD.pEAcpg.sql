create procedure    pxc_xcc10m00_upd

   (

       i_input_date    in   date

   ) is

   ts_holi_tp      varchar2(1) := null;

   ts_sqlcode      number := 0;



begin



   ts_holi_tp := fxc_holi_ck(i_input_date);



   if ts_holi_tp in ('1','2') then

      return;

   end if;



   begin

      update vn.xcc10m00 set

         dt_dt =  vn.fxc_wdt_g(i_input_date,-2)

      where base_idx = -2;

   exception

      when others then

         ts_sqlcode := sqlcode;

         raise_application_error(-20100,'error found base_idx -2 ['||ts_sqlcode||']');

   end;



   begin

      update vn.xcc10m00 set

         dt_dt =  vn.fxc_wdt_g(i_input_date,-1)

      where base_idx = -1;

   exception

      when others then

         ts_sqlcode := sqlcode;

         raise_application_error(-20100,'error found base_idx -1 ['||ts_sqlcode||']');

   end;



   begin

      update vn.xcc10m00 set

         dt_dt =  vn.fxc_wdt_g(i_input_date,0)

      where base_idx = 0;

   exception

      when others then

         ts_sqlcode := sqlcode;

         raise_application_error(-20100,'error found base_idx 0 ['||ts_sqlcode||']');

   end;



   begin

      update vn.xcc10m00 set

         dt_dt =  vn.fxc_wdt_g(i_input_date,1)

      where base_idx = 1;

   exception

      when others then

         ts_sqlcode := sqlcode;

         raise_application_error(-20100,'error found base_idx 1 ['||ts_sqlcode||']');

   end;





   begin

      update vn.xcc10m00 set

         dt_dt =  vn.fxc_wdt_g(i_input_date,2)

      where base_idx = 2;

   exception

      when others then

         ts_sqlcode := sqlcode;

         raise_application_error(-20100,'error found base_idx 2 ['||ts_sqlcode||']');

   end;



end pxc_xcc10m00_upd;
/

