create function    fbm_get_new_acnt_qty(
    i_emp_no        varchar2,       -- Ma nhan vien
    i_st_dt         varchar2,       -- Tra cuu tu ngay
    i_ed_dt         varchar2       -- Tra cuu den ngay
)
return number
/*
    select vn.fbm_get_new_acnt_qty(
        'tyhpt01',      -- i_emp_no        varchar2,       -- Ma nhan vien
        '20190101',     -- i_st_dt         varchar2,       -- Tra cuu tu ngay
        vwdate          -- i_ed_dt         varchar2       -- Tra cuu den ngay
    ) a
    from dual;
*/
as
    t_st_acnt_cnt    number;
    t_ed_acnt_cnt    number;
    t_new_acnt_cnt   number;

    o_ret           number;
begin
    select count(hie.sub_no)   st_acnt_cnt
    into t_st_acnt_cnt
    from table (vn.fbm_get_sub_item_hier(
                    '2',            -- i_tp        
                    i_emp_no,       -- i_mng_emp_no
                    i_st_dt         -- i_dt        
                    )
                ) hie
    inner join vn.bmi01m00 b1
    on hie.parent_no = b1.emp_no
    and substr(hie.sub_no, 1, 10) = b1.acnt_no
    and substr(hie.sub_no, 11, 2) = b1.sub_no
    and b1.mng_tp = '1'
    ;

    select count(hie.sub_no)   st_acnt_cnt
    into t_ed_acnt_cnt
    from table (vn.fbm_get_sub_item_hier(
                    '2',            -- i_tp        
                    i_emp_no,       -- i_mng_emp_no
                    i_ed_dt         -- i_dt        
                    )
                ) hie
    inner join vn.bmi01m00 b1
    on hie.parent_no = b1.emp_no
    and substr(hie.sub_no, 1, 10) = b1.acnt_no
    and substr(hie.sub_no, 11, 2) = b1.sub_no
    and b1.mng_tp = '1'
    ;

    select t_ed_acnt_cnt - t_st_acnt_cnt
    into t_new_acnt_cnt
    from dual;

    o_ret := t_new_acnt_cnt;

    return o_ret;
end;
/

