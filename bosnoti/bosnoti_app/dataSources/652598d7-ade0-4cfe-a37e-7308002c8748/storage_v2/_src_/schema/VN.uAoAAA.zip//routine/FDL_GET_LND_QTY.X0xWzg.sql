create function fdl_get_lnd_qty
(
    i_lnd_tp         in   varchar2,        --
    i_acnt_no        in   varchar2,        --
    i_sub_no         in   varchar2,        --
    i_lnd_dt         in   varchar2,        --
    i_mth_dt         in   varchar2,        --
    i_lnd_bank_cd    in   varchar2,        --
    i_stk_cd         in   varchar2         --
)
    return  number
as

    t_err_txt			varchar2(80); -- error text buffer
    t_err_msg           VARCHAR2(500);

begin


/*============================================================================*/
/* generl commission return                                                   */
/*============================================================================*/
	for c1 in (
		select  nvl(mrtg_lnd_qty,0)-nvl(mrtg_rpy_qty,0)
             -( nvl(td_sell_ord_qty,0)+nvl(pd_sell_mth_qty,0)
              + nvl(ppd_sell_mth_qty,0)+nvl(pppd_sell_mth_qty,0)
              ) lnd_abl_qty
	      from  vn.dlm01m00
	     where  lnd_tp       =  i_lnd_tp
	       and  acnt_no      =  i_acnt_no
	       and  sub_no       =  i_sub_no
	       and  lnd_dt       =  i_lnd_dt
	       and  mth_dt       =  i_mth_dt
	       and  lnd_bank_cd  =  i_lnd_bank_cd
	       and  stk_cd       =  i_stk_cd
	       and  lnd_acpt_tp  =  '01'
	) loop
		if  c1.lnd_abl_qty < 0 then
		    return 0;
		else
		    return c1.lnd_abl_qty;
		end if;
	end loop;

    -- No data found error
	return  0;

end fdl_get_lnd_qty;
/

