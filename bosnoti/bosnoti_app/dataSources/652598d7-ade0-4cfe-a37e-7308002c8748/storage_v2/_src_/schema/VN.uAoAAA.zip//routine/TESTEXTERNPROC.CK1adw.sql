create procedure    testExternProc(name IN VARCHAR2,
 name1 IN VARCHAR2, name2 IN OUT VARCHAR2)
 IS LANGUAGE C
 NAME "testText" LIBRARY testEP PARAMETERS (name STRING,
 name1 STRING, name2 STRING);
/

