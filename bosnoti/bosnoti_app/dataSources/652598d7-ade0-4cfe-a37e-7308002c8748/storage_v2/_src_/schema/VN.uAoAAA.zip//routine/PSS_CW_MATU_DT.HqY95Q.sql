create PROCEDURE pss_cw_matu_dt(
    i_dt            in   varchar2,
    i_work_mn       in   varchar2,
    i_work_trm      in   varchar2,
    o_proc_cnt      out  number
)
as
    
/* 
    declare o_proc_cnt number;
    begin
        pss_cw_matu_dt(
            vwdate,         -- i_dt            in   varchar2,
            'DAILY',        -- i_work_mn       in   varchar2,
            'SYSTEM',       -- i_work_trm      in   varchar2,
            o_proc_cnt      -- o_proc_cnt      out  number
        );
    end;
*/

    t_sec_cd            varchar2(5)     := vn.fxi_get_com_cd();
    t_vwdate            varchar2(8)     := vn.vwdate;
    t_proc_nm           varchar2(30)    := 'pss_cw_matu_dt';
    t_err_msg           varchar2(500)   := ' ';
    t_proc_cnt_2        number          := 0;
begin

    /* Steps:
        1. Dang ky tu dong cho cac ma CW dao han
        2. Clear so du CW
        3. Huy dang ky thanh toan doi voi nhung ma do chinh cong ty phat hanh
    */
    vn.pxc_log_write('pss_cw_matu_dt', 'start');
    o_proc_cnt  := 0;

    -- 1. Dang ky tu dong cho cac ma CW dao han
    vn.pxc_log_write('pss_cw_matu_dt', 'Insert data into scw05m00');

    begin
        insert into vn.scw05m00(
            seq_no,
            acnt_no,
            sub_no,
            stk_cd,
            reg_qty,
            book_amt,
            setl_tp,
            exec_dt,
            cncl_yn,
            work_mn,
            work_dtm,
            work_trm
        )
        select 
            vn.scw05m00_seq.nextval     seq_no,
            sb.acnt_no                  acnt_no,
            sb.sub_no                   sub_no,
            sb.stk_cd                   stk_cd,
            sb.own_qty                  reg_qty,
            sb.book_amt                 book_amt,
            '2'                         setl_tp,
            si.cw_matur_dt              exec_dt,
            'N'                         cncl_yn,
            i_work_mn                   work_mn,
            sysdate                     work_dtm,
            i_work_trm                  work_trm
        from vn.ssb01m00 sb
        inner join vn.ssi01m00 si
        on sb.stk_tp = si.stk_tp
        and sb.stk_cd = si.stk_cd
        where sb.stk_tp = '70'
        and sb.own_qty > 0
        and si.cw_matur_dt = i_dt;
    exception
        when others then
            t_err_msg  := 'Error when inserting data into scw05m00: ' || sqlcode || ' - ' || sqlerrm;
            vn.pxc_log_write(t_proc_nm, t_err_msg);
            raise_application_error(-20100,t_err_msg);
    end
    ;

    o_proc_cnt := sql%rowcount;

    -- 2. Clear so du CW
    vn.pxc_log_write('pss_cw_matu_dt', 'Calling sp pss_change_cw_exec_qty');

    begin
        vn.pss_change_cw_exec_qty(

            i_dt,           -- i_exec_dt     	IN      VARCHAR2,
            '%',            -- i_setl_dt     	IN      VARCHAR2,
            '%',            -- i_acnt_no     	IN      VARCHAR2,
            '%',            -- i_sub_no      	IN      VARCHAR2,
            '%',            -- i_cw_cd       	IN      VARCHAR2,
            'W03',          -- i_rmrk_cd		IN      VARCHAR2,		 -- "W03": Thuc hien chung quyen; "W04": Xuat kho CW; "W05": Nhap kho CW
            i_work_mn,      -- i_work_mn     	IN      VARCHAR2,        -- user id
            i_work_trm,     -- i_work_trm    	IN      VARCHAR2,
            t_proc_cnt_2    -- o_proc_cnt    	IN OUT  NUMBER
        );
    exception
        when others then
            t_err_msg  := 'Error when calling pss_change_cw_exec_qty: ' || sqlcode || ' - ' || sqlerrm;
            vn.pxc_log_write(t_proc_nm, t_err_msg);
            raise_application_error(-20100,t_err_msg);
    end
    ;

    -- 3. Huy dang ky thanh toan doi voi nhung ma do chinh cong ty phat hanh
    vn.pxc_log_write('pss_cw_matu_dt', 'Update cncl_yn scw05m00');
    /*
    begin
        update vn.scw05m00 sw
        set sw.cncl_yn = 'C'
        where   exists(
                    select 1
                    from vn.ssi01m00 si
                    where si.stk_cd = sw.stk_cd
                    and nvl(si.cw_selt_issu, 'N') = 'Y'
                )
        and sw.exec_dt = i_dt;
    exception
        when others then
            t_err_msg  := 'Error when updating cncl_yn scw05m00: ' || sqlcode || ' - ' || sqlerrm;
            vn.pxc_log_write(t_proc_nm, t_err_msg);
            raise_application_error(-20100,t_err_msg);
    end
    ;
    */

    vn.pxc_log_write('pss_cw_matu_dt', 'end');

end pss_cw_matu_dt;
/

