create type typ_hier_list
as object(
    parent_no   varchar2(30),
    sub_no      varchar2(30),
    -- tree        varchar2(20),
    lvl         varchar2(2),
    pth         varchar2(4000),
    leaf        varchar2(1)
);
/

