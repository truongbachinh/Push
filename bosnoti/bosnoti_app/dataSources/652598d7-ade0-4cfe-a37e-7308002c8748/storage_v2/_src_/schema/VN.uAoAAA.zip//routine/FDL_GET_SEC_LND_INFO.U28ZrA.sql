create function    fdl_get_sec_lnd_info
(
    i_apy_dt         in   varchar2,
    i_tp             in   varchar2
)
    return  number
as

	o_return_val   number := 0;
	t_sec_cd	   varchar2(3) := '';

begin

    -- Get sec_cd
    begin
        select vn.fxc_sec_cd('R')
        into t_sec_cd
        from dual;
    exception
    when no_data_found then
        t_sec_cd      := '000';
    end;

    /* To get the each value from dlm09m30
       This function is added for sub account */

	for c1 in (
		select  NVL(OWN_EQT, 0)           AS  OWN_EQT
			  , NVL(TOT_LND_USE_AMT, 0)   AS  TOT_LND_USE_AMT
			  , NVL(TOT_LND_LMIT, 0)      AS  TOT_LND_LMIT
			  , NVL(TOT_LND_LMIT_AMT, 0)  AS  TOT_LND_LMIT_AMT
			  , NVL(ACC_LND_LMIT, 0)      AS  ACC_LND_LMIT
			  , NVL(ACC_LND_LMIT_AMT, 0)  AS  ACC_LND_LMIT_AMT
	          , NVL(STK_LND_LMIT, 0)      AS  STK_LND_LMIT
	          , NVL(STK_LND_LMIT_AMT, 0)  AS  STK_LND_LMIT_AMT
	          , NVL(STK_QTY_LMIT, 0)      AS  STK_QTY_LMIT
	      from vn.dlm09m30
	     where sec_cd         =  t_sec_cd
	       and apy_dt	      = (select max(apy_dt)
	                               from vn.dlm09m30
	                              where sec_cd     =  t_sec_cd
	                                and apy_dt    <=  i_apy_dt)
	) loop

		if i_tp = '01' then
			o_return_val := round(c1.OWN_EQT,0);
		elsif i_tp = '02' then
			o_return_val := round(c1.TOT_LND_USE_AMT,0);
		elsif i_tp = '03' then
			o_return_val := c1.TOT_LND_LMIT;
		elsif i_tp = '04' then
			o_return_val := round(c1.TOT_LND_LMIT_AMT,0);
		elsif i_tp = '05' then
			o_return_val := c1.ACC_LND_LMIT;
		elsif i_tp = '06' then
			o_return_val := round(c1.ACC_LND_LMIT_AMT,0);
		elsif i_tp = '07' then
			o_return_val := c1.STK_LND_LMIT;
		elsif i_tp = '08' then
			o_return_val := round(c1.STK_LND_LMIT_AMT,0);
		elsif i_tp = '09' then
			o_return_val := c1.STK_QTY_LMIT;
		else
			o_return_val := 0;
		end if;

	end loop;

    return o_return_val;

end fdl_get_sec_lnd_info;
/

