create procedure    pss_cal_sbst_p_day
( i_proc_dt in 	varchar2,
  i_work_mn in  varchar2
 ) is
/***************************************************************************/
/* calculate of sbst (after batch job )                                    */
/* 'DAILY'
/* 2010-02-22                                                              */
/***************************************************************************/

  o_proc_cnt number := 0 ;

begin

 vn.pxc_log_write('pss_cal_sbst_p_day','START ['|| i_proc_dt ||']' );

 update vn.cwd01m00
	set rgt_sbst = 0
	   ,rgt_reuse = 0 ;

 for sr1 in (

      select  x.acnt_no                   acnt_no  ,
			  x.sub_no                    sub_no   ,
			  nvl(sum(x.rgt_sbst),  0 ) * vn.fdl_get_mrgn_grp_acnt_rt( x.acnt_no, x.sub_no,vn.faa_acnt_get_grp_no (x.acnt_no, x.sub_no,'2', vn.vwdate),'02', vn.vwdate)  rgt_sbst ,
			  nvl(sum(x.reuse_amt), 0 ) * vn.fdl_get_mrgn_grp_acnt_rt( x.acnt_no, x.sub_no,vn.faa_acnt_get_grp_no (x.acnt_no, x.sub_no,'2', vn.vwdate),'02', vn.vwdate)  reuse_amt
       from
         ( select a.acnt_no acnt_no ,
				  a.sub_no  sub_no  ,
				  Decode( c.rgt_tp , '1' , decode (a.inq_trd_no , 0 ,  nvl(a.cons_sbst_qty ,0 ) , 0 ) ,
						  Decode ( a.INQ_TRD_NO   , 0 , nvl(a.asn_qty  ,0)  , 0 ))
                   * vn.fss_get_td_cls_pri( a.stk_cd)
				   * vn.fsr_rgt_sbst_rt_acnt( a.stk_cd ,a.acnt_no, a.sub_no )  rgt_sbst   ,

                  (  Decode(a.FLOTQ_TRD_NO , 0 , nvl(a.flotq_amt,0) , 0 )
				   + Decode(a.RCPT_TRD_NO  , 0 , nvl(a.asn_amt  ,0) , 0 )
				   + Decode(a.INTER_TRD_NO , 0 , nvl(a.inter_amt,0) , 0 ) )
				   * vn.fsr_rgt_cash_rt_acnt( a.stk_cd ,a.acnt_no, a.sub_no)  reuse_amt
             from vn.srr02m00 a ,
                  vn.aaa01m00 b ,
                  vn.srr01m00 c
            where a.rgt_std_dt  = c.rgt_std_dt
              and a.rgt_tp      = c.rgt_tp
              and a.stk_cd      = c.stk_cd
              and a.seq_no      = c.seq_no
              and a.rgt_tp      <> '8'
              and c.rgt_proc_stat >= '3'
              and a.acnt_no      =    b.acnt_no
			  and a.sub_no       =    b.sub_no
              and b.acnt_stat    =   '1'
			  and c.rgt_tp in ( '1','2','3','9')

           union all

           select a.acnt_no acnt_no ,
				  a.sub_no  sub_no  ,
				  Decode( a.inq_trd_no   , 0  , nvl(a.asn_qty   ,0)  , 0 )
                   * vn.fss_get_td_cls_pri( d.cnvt_stk_cd)
                   * vn.fsr_rgt_sbst_rt_acnt( d.cnvt_stk_cd ,a.acnt_no, a.sub_no )  rgt_sbst     ,

                  Decode( a.FLOTQ_TRD_NO , 0  , nvl(a.flotq_amt ,0)  , 0 )
				  * vn.fsr_rgt_cash_rt_acnt( a.stk_cd ,a.acnt_no, a.sub_no)  reuse_amt
              from vn.srr02m00 a ,
                   vn.aaa01m00 b ,
                   vn.srr01m10 d
             where a.rgt_std_dt =  d.rgt_std_dt
              and  a.rgt_tp     =  '8'
              and  a.stk_cd     =  d.stk_cd
              and  a.acnt_no    =  b.acnt_no
			  and  a.sub_no     =  b.sub_no
              and  b.acnt_stat  = '1'
              and  d.rgt_proc_stat >= '3'
           ) x
     where  rgt_sbst > 0 or reuse_amt > 0
	 group by x.acnt_no, x.sub_no
	 order by 1

 ) loop

   update  vn.cwd01m00
	 set   rgt_reuse = trunc( sr1.reuse_amt )
		  ,rgt_sbst  = Trunc( sr1.rgt_sbst  )
   where   acnt_no   = sr1.acnt_no
	 and   sub_no    = sr1.sub_no;


 end loop ;

 vn.pss_cal_sbst_p
          (vn.vwdate
          ,'%'
		  ,'%'
          ,i_work_mn
          ,o_proc_cnt
       );

 vn.pxc_log_write('pss_cal_sbst_p_day','pss_cal_sbst_p ['|| o_proc_cnt ||']');


 vn.pxc_log_write('pss_cal_sbst_p_day','pdl_crd_loan_rt_day [ ' || to_char(sqlcode) ||']');
 vn.pxc_log_write('pss_cal_sbst_p_day','FINISH');

end  pss_cal_sbst_p_day;
/

