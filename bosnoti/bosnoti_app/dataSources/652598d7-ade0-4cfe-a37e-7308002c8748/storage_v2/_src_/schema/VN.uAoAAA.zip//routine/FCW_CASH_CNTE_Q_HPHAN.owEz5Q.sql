create function fcw_cash_cnte_q_hphan
(
    i_acnt_no    in   varchar2,
    i_sub_no     in   varchar2,
    i_trd_dt     in   varchar2,
    i_trd_seq_no in   varchar2
)
  return          varchar2
as
    t_trd_tp         varchar2(2) ;
    t_rmrk_cd        varchar2(3) ;
    t_trd_amt        number := 0 ;
    t_stk_cd         varchar2(20) ;
    t_sb_qty         number := 0 ;
    t_mth_dt         varchar2(8) ;
    t_lnd_dt         varchar2(8) ;
    t_stk_tp         varchar2(1) ;
    t_num            number := 0 ;
    t_type           number := 0 ;
    t_stk_cd_r       varchar2(20) ;
    t_stk_qty_r      number := 0 ;
    t_stk_pri_r      number := 0 ;
    o_cnte           varchar2(200) ;
    t_err_txt        varchar2(100)  ; -- error text buffer
    o_check_rmrk_cd  number := 0;
    o_check_y_rmk    varchar2(1);

begin
  begin
       select NVL(t.trd_tp,'!'),
             NVL(t.rmrk_cd,'!'),
             t.trd_amt,
             NVL(decode(trim(t.stk_cd),'XXX','', decode(substr(t.stk_cd,1,2), '00', '',t.stk_cd)),'!'),
             decode(t.sb_qty, 0, '', t.sb_qty),
             NVL(t.mth_dt,'!'),
             NVL(t.lnd_dt,'!'),
             --NVL(substr(substr(trim(substr(t.cnte,instr(t.cnte,'-')+1)),instr(trim(substr(t.cnte,instr(t.cnte,'-')+1)),'-')),2),'!')
             case when t.rmrk_cd = '247' then
                t.cnte
             else
                decode(instr(t.cnte,'-'),0,t.cnte , NVL(substr(substr(trim(substr(t.cnte,instr(t.cnte,'-')+1)),instr(trim(substr(t.cnte,instr(t.cnte,'-')+1)),'-')),2),'!'))
             end
        into t_trd_tp,
             t_rmrk_cd,
             t_trd_amt,
             t_stk_cd,
             t_sb_qty,
             t_mth_dt,
             t_lnd_dt,
             o_cnte
        from vn.aaa10m00 t
       where t.acnt_no  = i_acnt_no
         and t.sub_no   = i_sub_no
         and t.trd_dt   = i_trd_dt
         and t.trd_seq_no = i_trd_seq_no ;
  EXCEPTION WHEN NO_DATA_FOUND THEN
      dbms_output.put_line('no data found');
      return 1;
  END;

         if o_cnte = '!' then
            if t_stk_cd <> '!' then
               t_stk_tp := vn.fss_get_stk_mkt(t_stk_cd);

               if t_stk_tp = '2' then
                  SELECT MOD(t_sb_qty , 100) into t_num FROM DUAL;
                  if t_num > 0 then
                    t_type := 1 ;
                  end if;
               else
                  SELECT MOD(t_sb_qty , 10) into t_num FROM DUAL;
                  if t_num > 0 then
                    t_type := 1 ;
                  end if;
               end if;

               if t_mth_dt <> '!' then
                  if t_type = '1' then
                     o_cnte := trim(vn.fbm_rmrk_nm_q(t_rmrk_cd))||' lô l? '||t_sb_qty||' '||t_stk_cd||' ngay '||substr(t_mth_dt, 7, 2)||'/'||substr(t_mth_dt, 5, 2)||'/'||substr(t_mth_dt, 1, 4);
                  else
                     if substr(t_rmrk_cd,1,1) = '7' then
                        if t_rmrk_cd = '701' then
                           o_cnte := trim(vn.fbm_rmrk_nm_q(t_rmrk_cd))||' '||t_sb_qty||' '||t_stk_cd||' ngay ban '||substr(t_mth_dt, 7, 2)||'/'||substr(t_mth_dt, 5, 2)||'/'||substr(t_mth_dt, 1, 4);
                        else
                           o_cnte := trim(vn.fbm_rmrk_nm_q(t_rmrk_cd))||' '||t_sb_qty||' '||t_stk_cd||' ngay '||substr(t_lnd_dt, 7, 2)||'/'||substr(t_lnd_dt, 5, 2)||'/'||substr(t_lnd_dt, 1, 4);
                        end if;
                     else
                        o_cnte := trim(vn.fbm_rmrk_nm_q(t_rmrk_cd))||' '||t_sb_qty||' '||t_stk_cd||' ngay '||substr(t_mth_dt, 7, 2)||'/'||substr(t_mth_dt, 5, 2)||'/'||substr(t_mth_dt, 1, 4);
                     end if;
                  end if;
               ELSE
                    if t_rmrk_cd = '241' then
                        SELECT 'Cô t?c' || ': ' || a.stk_cd || ', TL: ' || d.RGT_ISS_PRI || '%' ||
                            ', NDKCC: ' || to_char(to_date(d.rgt_std_dt, 'YYYYMMDD'), 'DD/MM/YYYY')
                        INTO o_cnte
                        FROM vn.aaa10m00 a, vn.srr01m00 d, vn.srr02m00 e
                        WHERE a.stk_cd = d.stk_cd
                          and d.rgt_std_dt = e.rgt_std_dt
                          AND d.rgt_tp = e.rgt_tp
                          AND a.acnt_no = e.acnt_no
                          AND a.sub_no = e.sub_no
                          and d.stk_cd = e.stk_cd
                          and a.cncl_yn = 'N'
                          and a.org_trd_no = 0
                          and a.acnt_no like i_acnt_no
                          ANd a.stk_cd like t_stk_cd
                          AND a.trd_dt between i_trd_dt and i_trd_dt
                          --and e.asn_amt = a.trd_amt
              AND a.trd_seq_no = i_trd_seq_no
                          and d.divi_pay_dt =i_trd_dt
                          AND rownum <2;
                    else
                          o_cnte := trim(vn.fbm_rmrk_nm_q(t_rmrk_cd))||' '||t_sb_qty||' '||t_stk_cd;
                    end if;
               end if;
            else  -- t_stk_cd = '!'
               if t_rmrk_cd = '244' then
                  select x.stk_cd, x.sbst_qty
                    into t_stk_cd_r, t_stk_qty_r
                    from vn.srr03m00 x
                   where x.acnt_no = i_acnt_no
                     and x.sub_no  = i_sub_no
                   --and x.sbst_dt = i_trd_dt --HL - 2011/11/14 - ko dung ngay x.sbst_dt ma dung ngay x.work_dtm. Vi ngay DK PHT va ngay duyet co the khac nhau
                     and to_char(x.work_dtm,'yyyymmdd') = i_trd_dt
                     and x.rgt_tp in ('1','4')
                     and x.inq_trd_no = i_trd_seq_no
                     and x.sbst_amt = t_trd_amt ;

                     t_stk_pri_r := t_trd_amt/t_stk_qty_r;

                  o_cnte := trim(vn.fbm_rmrk_nm_q(t_rmrk_cd))||' '||t_stk_cd_r||' s? lu?ng '||t_stk_qty_r||' giá '||t_stk_pri_r;
                  elsif t_rmrk_cd = '042' then
                  select x.mak_strt_dt
                    into t_mth_dt
                    from vn.ssb07m00 x
                   where x.acnt_no = i_acnt_no
                 and x.sub_no  = i_sub_no
                     and x.usefee_pay_dt = i_trd_dt
                     and x.rcpt_trd_no = i_trd_seq_no
                     and x.usefee = t_trd_amt ;

                  o_cnte := trim(vn.fbm_rmrk_nm_q(t_rmrk_cd))||' thang '||substr(t_mth_dt, 5, 2)||'/'||substr(t_mth_dt, 1, 4)||' TK '||i_acnt_no;
               else
                  if substr(t_rmrk_cd,1,2) >= '76' then
                     o_cnte := trim(vn.fbm_rmrk_nm_q(t_rmrk_cd))||' ngay '||substr(t_lnd_dt, 7, 2)||'/'||substr(t_lnd_dt, 5, 2)||'/'||substr(t_lnd_dt, 1, 4);
                  else
                    if  t_rmrk_cd <> '025' and  t_rmrk_cd <> '026'  then
                     o_cnte := trim(vn.fbm_rmrk_nm_q(t_rmrk_cd));
                     end if;
                  end if;
               end if;
            end if;
         else
           if  t_rmrk_cd = '025' OR  t_rmrk_cd = '026'  then
             SELECT DECODE(t_rmrk_cd,'026','1','2')into o_check_rmrk_cd FROM DUAL;
             select vn.fcw_trans_cash_y_n(i_acnt_no,i_sub_no,i_trd_seq_no,o_check_rmrk_cd,i_trd_dt) into o_check_y_rmk from dual;
             if o_check_y_rmk ='Y' then
               o_cnte:= 'CK cùng TK ' ||substr(trim(o_cnte),1,100);
               else
                     o_cnte := trim(vn.fbm_rmrk_nm_q(t_rmrk_cd))||' ' ||substr(trim(o_cnte),1,100);
                     end if;
              else
           o_cnte := trim(vn.fbm_rmrk_nm_q(t_rmrk_cd))||' '||substr(trim(o_cnte),1,100);
           end if;
         end if;

  return o_cnte;

    exception
        when  NO_DATA_FOUND  then
      return  ' ';
        when  OTHERS         then
            t_err_txt  :=  '['||to_char(sqlcode)||']';
            raise_application_error (-20100, t_err_txt||'*'||i_acnt_no||'*'||i_sub_no||'*'||i_trd_dt||'*'||i_trd_seq_no );

end fcw_cash_cnte_q_hphan;
/

