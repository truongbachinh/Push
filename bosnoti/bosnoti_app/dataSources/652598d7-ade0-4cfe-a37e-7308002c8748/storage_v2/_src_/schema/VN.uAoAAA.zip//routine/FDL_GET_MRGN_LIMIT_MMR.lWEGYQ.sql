create function    fdl_get_mrgn_limit_mmr(i_acnt_no IN VARCHAR2,
                                                     i_sub_no  IN VARCHAR2)
  return number as 

  td_tl            NUMBER := 0;
  t_pia_loan_nowrm NUMBER := 0;
  t_coll_evltv     NUMBER := 0;
  t_buy_evltv      NUMBER := 0;
  t_stk_evltv_asset      NUMBER := 0;
  t_sell_cmsn      NUMBER := 0;
  t_sell_tax       NUMBER := 0;
  t_sell_rgt_tax   NUMBER := 0;
  t_sell_fee       NUMBER := 0;
  t_buy_cmsn       NUMBER := 0;
  t_sell_amt       NUMBER := 0;

  t_dpo          NUMBER := 0;
  t_sbst_proof   NUMBER := 0;
  td_dpo_outq_bk NUMBER := 0;
  t_rgt_rusea    NUMBER := 0;
  t_pia_fee      NUMBER := 0;
  t_rgt_repla    NUMBER := 0;

  t_mrtg_evltv      NUMBER := 0;
  t_buy_wait_evltv  NUMBER := 0;
  t_sell_wait_evltv NUMBER := 0;
  t_buy_amt         NUMBER := 0;
  td_cta            NUMBER := 0;
  t_cmr             NUMBER := 0;
  td_mmr            NUMBER := 0;
  t_rll             NUMBER := 0;

  td_loan_amt NUMBER := 0;
  o_loan_amt  NUMBER;
  t_grp_acnt_no varchar2(15);
begin

  /*====================================================================*/
  /* Calculate amount to reach to MMR ratio                             */
  /*====================================================================*/
  FOR C1 IN (SELECT coll_loan_nowrm + buy_loan_nowrm + mrgn_loan_nowrm +
                    mony_loan_nowrm + coll_loan_int + buy_loan_int +
                    mrgn_loan_int + mony_loan_int TL,
                    MRGN_NOW_MNTN_RT CMR,
                    pia_loan_nowrm,
                    COLL_GRNTA,
                    BUY_GRNTA,
                    STK_EVLTV_ASSET,
                    BUY_WAIT_EVLTV,
                    SELL_WAIT_EVLTV,
                    sell_amt,
                    sell_cmsn,
                    sell_tax,
                    sell_rgt_tax,
                    sell_fee,
                    buy_cmsn,
                    buy_amt
               FROM vn.cwd99m00
              WHERE acnt_no = i_acnt_no
                AND sub_no = i_sub_no) LOOP
    td_tl             := td_tl + C1.TL;
    t_pia_loan_nowrm  := C1.pia_loan_nowrm;
    t_coll_evltv      := C1.COLL_GRNTA;
    t_buy_evltv       := C1.BUY_GRNTA;
    t_stk_evltv_asset       := C1.STK_EVLTV_ASSET;
    t_sell_wait_evltv := C1.SELL_WAIT_EVLTV;
    t_cmr             := C1.CMR;
    t_sell_cmsn       := C1.sell_cmsn;
    t_sell_tax        := C1.sell_tax;
    t_sell_rgt_tax    := C1.sell_rgt_tax;
    t_sell_fee        := C1.sell_fee;
    t_buy_cmsn        := C1.buy_cmsn;
    t_sell_amt        := C1.sell_amt;

  END LOOP;

  BEGIN
    /* Add outp_dpo_bk by hyunjin 20120308 */
    SELECT nvl(A.dpo, 0), nvl(A.sbst_proof, 0), nvl(A.outq_dpo_bk, 0)
      INTO t_dpo, t_sbst_proof, td_dpo_outq_bk
      FROM vn.cwd01m00 A, vn.tso02m00 B
     WHERE A.acnt_no = i_acnt_no
       AND A.sub_no = i_sub_no
       AND A.acnt_no = B.acnt_no
       AND A.sub_no = B.sub_no
       AND B.bank_cd = '9999';
  EXCEPTION
    WHEN OTHERS THEN
      t_dpo          := 0;
      t_sbst_proof   := 0;
      td_dpo_outq_bk := 0;
  END;

  begin
    SELECT nvl(rgt_reuse, 0)
      INTO t_rgt_rusea
      FROM vn.cwd01m00
     WHERE acnt_no = i_acnt_no
       AND sub_no = i_sub_no;
  EXCEPTION
    WHEN OTHERS THEN
      t_rgt_rusea := 0;
  END;

  t_pia_fee := vn.fdl_get_mrgn_rt_01(i_acnt_no, i_sub_no, '21', vn.vwdate);

  t_rgt_repla := vn.fsr_rgt_sbstamt('%', i_acnt_no, i_sub_no);

  t_mrtg_evltv := t_coll_evltv + t_buy_evltv + t_sbst_proof;

  IF vn.fxb_daily_stat_chk('B', '0', '2000', '2800', '*') <> 'Y' THEN
    BEGIN
      SELECT SUM(NVL(td_cash_prof_amt, 0) + NVL(pd_buy_mth_amt, 0) +
                 NVL(ppd_buy_mth_amt, 0) + NVL(pppd_buy_mth_amt, 0)) as buy_amt,
             SUM(EXPT_SBST_ORG_AMT + PD_MGN_BUY_ORG_AMT +
                 PPD_MGN_BUY_ORG_AMT + PPPD_MGN_BUY_ORG_AMT),
             SUM(TD_MGN_SELL_ORG_AMT + PD_MGN_SELL_ORG_AMT +
                 PPD_MGN_SELL_ORG_AMT + PPPD_MGN_SELL_ORG_AMT)
        INTO t_buy_amt, t_buy_wait_evltv, t_sell_wait_evltv
        FROM vn.tso02m00
       WHERE acnt_no = i_acnt_no
         ANd sub_no = i_sub_no;
    EXCEPTION
      WHEN OTHERS THEN
        t_buy_amt         := 0;
        t_buy_wait_evltv  := 0;
        t_sell_wait_evltv := 0;
    END;

  ELSE
    BEGIN
      SELECT SUM(NVL(td_cash_prof_amt, 0) + NVL(pd_buy_mth_amt, 0) +
                 NVL(ppd_buy_mth_amt, 0) + NVL(pppd_buy_mth_amt, 0)) as buy_amt,
             SUM(TD_MGN_BUY_ORG_AMT + PD_MGN_BUY_ORG_AMT +
                 PPD_MGN_BUY_ORG_AMT + PPPD_MGN_BUY_ORG_AMT),
             SUM(TD_MGN_SELL_ORG_AMT + PD_MGN_SELL_ORG_AMT +
                 PPD_MGN_SELL_ORG_AMT + PPPD_MGN_SELL_ORG_AMT)
        INTO t_buy_amt, t_buy_wait_evltv, t_sell_wait_evltv
        FROM vn.tso02m00
       WHERE acnt_no = i_acnt_no
         ANd sub_no = i_sub_no;
    EXCEPTION
      WHEN OTHERS THEN
        t_buy_amt         := 0;
        t_buy_wait_evltv  := 0;
        t_sell_wait_evltv := 0;
    END;

  END IF;

  /* Calculate CTA */
  td_cta := t_dpo - td_dpo_outq_bk + t_sell_amt + t_rgt_rusea -
            t_pia_loan_nowrm - t_sell_cmsn - t_sell_tax - t_sell_rgt_tax - t_sell_fee - 
            t_buy_amt - t_buy_cmsn - t_pia_fee +
            GREATEST(t_stk_evltv_asset + t_rgt_repla + t_mrtg_evltv +
                     t_buy_wait_evltv - (t_sell_wait_evltv),
                     0);
  t_grp_acnt_no := vn.faa_acnt_get_grp_no (i_acnt_no, i_sub_no,2,vn.vwdate);
  td_mmr := vn.fdl_get_mrgn_grp_acnt_rt(i_acnt_no, i_sub_no, t_grp_acnt_no, '03', vn.vwdate);

  vn.pxc_log_write('fdl_get_mrgn_limit_mmr',
                   'Check : ' || ' i_acnt_no =' || i_acnt_no || '-' ||
                   i_sub_no || ' td_cta =' || td_cta || ' td_tl =' || td_tl ||
                   ' td_mmr =' || td_mmr);

  vn.pxc_log_write('fdl_get_mrgn_limit_mmr',
                   'Check : ' || ' i_acnt_no =' || i_acnt_no || '-' ||
                   i_sub_no || ' td_cta =' || td_cta);

  IF t_cmr < td_mmr then
    td_loan_amt := 0;
  ELSE
    td_loan_amt := greatest(ROUND(((td_cta * (1 - td_mmr) - td_tl) / td_mmr), 0) , 0);
  END IF;

  o_loan_amt := td_loan_amt;

  vn.pxc_log_write('fdl_get_mrgn_limit_mmr',
                   'Check : ' || ' i_acnt_no =' || i_acnt_no || '-' ||
                   i_sub_no || ' t_rll =' || t_rll || ' o_loan_amt =' ||
                   o_loan_amt);

  return o_loan_amt;
end fdl_get_mrgn_limit_mmr;
/

