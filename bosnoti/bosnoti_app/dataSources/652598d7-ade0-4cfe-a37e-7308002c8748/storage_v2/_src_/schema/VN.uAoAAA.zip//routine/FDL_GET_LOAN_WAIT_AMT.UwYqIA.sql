create FUNCTION fdl_get_loan_wait_amt
(
    i_acnt_no        in   varchar2,
    i_sub_no         in   varchar2,
    i_lnd_tp         in   varchar2,
    i_tp             in   varchar2
)   RETURN  NUMBER AS
/*!
   \file     fdl_get_loan_wait_amt.sql
   \brief    Get the non settled loan
   \new      20110512

select vn.fdl_get_loan_wait_amt('999','045C000001','30','1') from dual;

*/
	ts_batch_yn         VARCHAR2(01) := NULL;
	ts_wdate            VARCHAR2(08) := NULL;

	td_loan_wait_amt    NUMBER       := 0;
	td_loan_wait_int    NUMBER       := 0;

	td_return_val       NUMBER       := 0;

begin

/*============================================================================*/
/* Valiabl Initialize
/*============================================================================*/

    ts_batch_yn := vn.fxb_daily_stat_chk ('B','0','2500','2500','*');
    ts_wdate    := vn.vwdate;

 	td_loan_wait_amt := 0;
 	td_loan_wait_int := 0;

    /* CASE 1 : The stock settlment didn't process yet */
    IF ts_batch_yn = 'N' THEN
    	FOR C1 in (
          SELECT   A.LND_TP
               ,   A.STK_CD
               ,   NVL(SUM(A.LND_AMT),0)      LND_AMT
               ,   NVL(SUM(A.LND_RPY_AMT),0)  RPY_AMT
               ,   NVL(SUM(A.LND_INT),0)
                +  NVL(SUM(A.DLY_INT),0)
                +  NVL(SUM(A.LND_FEE),0)
                +  NVL(SUM(A.DLY_FEE),0)      LND_INT
             FROM  vn.dlm01m00 A
            WHERE  A.acnt_no      =  i_acnt_no
              AND  A.sub_no       =  i_sub_no
              AND  A.setl_bank_cd =  '9999'
              AND  A.lnd_tp      in  i_lnd_tp
              AND  A.setl_dt     >   decode(A.lnd_tp,'30',ts_wdate
                                                    ,'50',ts_wdate
                                                    , '30000101')
              AND  NVL(A.mrtg_lnd_qty,0)
                 - NVL(A.mrtg_rpy_qty,0)  >  0
            GROUP  BY  A.lnd_tp, A.stk_cd
		) LOOP

			td_loan_wait_amt := td_loan_wait_amt + C1.LND_AMT - C1.RPY_AMT;
			td_loan_wait_int := td_loan_wait_int + C1.LND_INT;


		END LOOP;
    ELSE
	    FOR C2 in (
          SELECT   A.LND_TP
               ,   A.STK_CD
               ,   NVL(SUM(A.LND_AMT),0)      LND_AMT
               ,   NVL(SUM(A.LND_RPY_AMT),0)  RPY_AMT
               ,   NVL(SUM(A.LND_INT),0)
                +  NVL(SUM(A.DLY_INT),0)
                +  NVL(SUM(A.LND_FEE),0)
                +  NVL(SUM(A.DLY_FEE),0)      LND_INT
             FROM  vn.dlm01m00 A
            WHERE  A.acnt_no      =  i_acnt_no
              AND  A.sub_no       =  i_sub_no
              AND  A.setl_bank_cd =  '9999'
              AND  A.lnd_tp      in  i_lnd_tp
              AND  A.setl_dt     >  decode(A.lnd_tp,'30',ts_wdate
                                                   ,'50',ts_wdate
                                                   , '30000101')
              AND  NVL(A.mrtg_lnd_qty,0)
                 - NVL(A.mrtg_rpy_qty,0)  >  0
            GROUP  BY  A.lnd_tp, A.stk_cd
		) LOOP

			td_loan_wait_amt := td_loan_wait_amt + C2.LND_AMT - C2.RPY_AMT;
			td_loan_wait_int := td_loan_wait_int + C2.LND_INT;

		END LOOP;
	END IF;

    /* tp = 1 Loan amount */
    IF i_tp = '1' THEN
    	td_return_val := td_loan_wait_amt;
    /* tp = 2 Int amount  */
    ELSE
    	td_return_val := td_loan_wait_int;
	END IF ;

    RETURN td_return_val;

END fdl_get_loan_wait_amt;
/

