create procedure pss_unbk_delay_p
(
  is_trd_dt   in  varchar2,
  is_work_mn  in  varchar2,
  os_proc_cnt out  number

) as
  t_sec_cd varchar2(3)  := vn.fxc_sec_cd('R');
  o_cnt    number       := 0;
  v_tax_delay_qty       number := 0; /* LTHN-248 */
  v_tax_delay_sb_qty    number := 0; /* LTHN-248 */
  v_wtax_delay_qty      number := 0; /* LTHN-248 */
  v_wtax_delay_sb_qty   number := 0; /* LTHN-248 */
  t_change_tax_qty      number := 0; /* LTHN-248 */
  t_change_tax_sb_qty   number := 0; /* LTHN-248 */
  t_cnte                varchar2(200); /* LTHN-248 */

begin

  vn.pxc_log_write('pss_unbk_delay_p', '[' || is_trd_dt || ']' );

  os_proc_cnt := 0 ;

  for s1 in ( select proc_dt  proc_dt
                    ,acnt_no  acnt_no
                    ,sub_no   sub_no
                    ,seq_no   seq_no
                    ,stk_cd   stk_cd
                    ,nvl(qty         , 0 ) qty
                    ,nvl(sb_lmt_qty  , 0 ) sb_qty
                    ,nvl(mov_lmy_qty , 0 ) mov_qty
                    ,nvl(rgt_tax_qty , 0 ) rgt_tax_qty
                from vn.ssb05m00
               where cncl_yn = 'N'
                 and end_yn = 'Y'
                 and apy_dt = vn.fxc_vorderdt_g( to_date(is_trd_dt , 'yyyymmdd') , 1 )
               order by proc_dt , acnt_no , seq_no , sub_no
            ) loop

    vn.pxc_log_write('pss_unbk_delay_p', '[' || s1.proc_dt || '][' || s1.acnt_no || '][' || s1.seq_no || ']' );

    begin
      update ssb01m00
         set delay_qty      = greatest ( delay_qty      - s1.qty    , 0 )
            ,delay_sb_qty   = greatest ( delay_sb_qty   - s1.sb_qty , 0 )
            ,delay_mov_qty  = greatest ( delay_mov_qty  - s1.sb_qty , 0 )
       where acnt_no = s1.acnt_no
         and sub_no  = s1.sub_no
         and stk_cd  = s1.stk_cd ;
    exception
      when others then
        raise_application_error(-20100 , sqlcode ||','|| sqlerrm ) ;
    end ;

    /* call evaluation for margin  */

    vn.pdl_crd_loan_rt_proc_td
    (  is_trd_dt
      ,'2' -- stock
      ,s1.acnt_no
      ,s1.sub_no
      ,'0'
      ,is_work_mn
      ,'SYSTEM'
      ,o_cnt
    );

    vn.pxc_log_write('pss_unbk_delay_p','pdl_crd_loan_rt_proc_td ['|| o_cnt ||']');

    /* LTHN-248 */
    vn.pxc_log_write('pss_acnt_unbk_delay_tday_p', 'Bat dau tinh toan so luong can tinh thue .');
    begin
    select tax_delay_qty  , tax_delay_sb_qty  , wtax_delay_qty  , wtax_delay_sb_qty
      into v_tax_delay_qty, v_tax_delay_sb_qty, v_wtax_delay_qty, v_wtax_delay_sb_qty
      from ssb05m10
     where acnt_no = s1.acnt_no
       and stk_cd = s1.stk_cd;
    exception
      when no_data_found then
        vn.pxc_log_write('pss_acnt_unbk_delay_tday_p','Khong co du lieu can tinh thue cho tai khoan: '||s1.acnt_no ||', stk_cd: '||s1.stk_cd);
        raise_application_error(-20100,'Tai khoan ' || s1.acnt_no || ' chua co du lieu can tinh thue cho ma ' || s1.stk_cd);
    end;

    if v_wtax_delay_qty + v_wtax_delay_sb_qty > 0 then
      vn.pxc_log_write('pss_acnt_unbk_delay_tday_p','Dang co khoan can tinh thue cho duyet cho tai khoan: '||s1.acnt_no ||', stk_cd: '||s1.stk_cd);
      raise_application_error(-20100,'Tai khoan ' || s1.acnt_no || ' co khoan can tinh thue cho duyet cho ma ' || s1.stk_cd);
    end if;

    if s1.qty > 0 then
      t_change_tax_qty := s1.rgt_tax_qty;
      if v_tax_delay_qty < t_change_tax_qty then
        t_change_tax_qty := v_tax_delay_qty;
      end if;
      t_cnte := 'Chuyen loai ck Cho TDCN sang TDCN';
    elsif s1.sb_qty > 0 then
      t_change_tax_sb_qty := s1.rgt_tax_qty;
      if v_tax_delay_sb_qty < t_change_tax_qty then
        t_change_tax_sb_qty := v_tax_delay_sb_qty;
      end if;
      t_cnte := 'Chuyen loai ck Cho HCCN sang HCCN';
    end if;

    /* Cap nhat ssb05m10 */
    vn.pxc_log_write('pss_acnt_unbk_delay_tday_p','Update ssb05m10');
    begin
    update ssb05m10
       set tax_qty          = tax_qty          + t_change_tax_qty,
           tax_sb_lim_qty   = tax_sb_lim_qty   + t_change_tax_sb_qty,
           tax_delay_qty    = tax_delay_qty    - t_change_tax_qty,
           tax_delay_sb_qty = tax_delay_sb_qty - t_change_tax_sb_qty,
           work_mn  = is_work_mn,
           work_dtm = sysdate,
           work_trm = 'Local'
     where acnt_no = s1.acnt_no
       and stk_cd = s1.stk_cd;
    exception
      when others then
        vn.pxc_log_write('pss_acnt_unbk_delay_tday_p','Loi khi update tai khoan: '||s1.acnt_no ||', stk_cd: '||s1.stk_cd);
        raise_application_error(-20100,' Loi khi update tai khoan ' || s1.acnt_no || ', ma ' || s1.stk_cd);
    end;
    /* Luu lich su */
    vn.pxc_log_write('pss_acnt_unbk_delay_tday_p','Update ssb05h10');
    begin
      pss_rgt_tax_history
      ( s1.acnt_no  ,
        s1.stk_cd   ,
        s1.proc_dt  ,
        t_cnte      ,
        is_work_mn  ,
        'Local'
      );
    exception
      when others then
        vn.pxc_log_write('pss_acnt_unbk_delay_tday_p','Loi khi chay proc pss_rgt_tax_history.');
        raise_application_error(-20100,'Loi khi chay proc pss_rgt_tax_history.');
    end;
    /* End LTHN-248 */

  end loop ;

  begin
    vn.pdl_loan_01407(t_sec_cd,'%','%');

  exception
    when others then
      raise_application_error(-20100 , sqlcode ||','|| sqlerrm ) ;
  end ;
  -- vn.pxc_batch_sms_staff(t_sec_cd, '1');

end pss_unbk_delay_p;
/

