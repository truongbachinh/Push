create function fbm_emp_nm_q
(
    i_emp_no   in   varchar2        -- 관리사번
)
    return          varchar2
as
/*
   \file     fbm_emp_nm_q.sql
   \brief    관리사원명조회

   \section intro Program Information
        - Program Name              : 관리사원명조회
        - Service Name              : N/A
        - Related Client Program- Client Program ID : Client 05101
        - Related Tables            : BMB01M00
        - Dev. Date                 : 2007/11/30
        - Developer                 : 김광동
        - Business Logic Desc.      : 관리사원명조회
        - Latest Modification Date  : 2007-11-30

   \section history Program Modification History
    - 1.0       2007/11/30     김광동    최초개발

   \section hardcoding Hard-Coding List
    - HC-1

   \section info Additional Reference Comments
    - 해당사항 없음
*/
    o_emp_nm		varchar2(100) ;
    t_err_txt       varchar2(100)  ; -- error text buffer

begin

/*============================================================================*/
/* 변수 초기화                                                                */
/*============================================================================*/
    o_emp_nm  :=  NULL;

vn.pxc_log_write('fbm_emp_nm_q','i_emp_no-'||i_emp_no);
/*============================================================================*/
/* 사원명 조회                                                                */
/*============================================================================*/
    begin
      	select nvl(emp_nm, ' ')
		  into o_emp_nm
          from vn.xca01m01
         where emp_no	= i_emp_no;
    exception
        when  NO_DATA_FOUND  then
			return  '!';
        when  OTHERS         then
            t_err_txt  :=  '오류-['||to_char(sqlcode)||']';
            raise_application_error (-20100, t_err_txt);
    end;

    return  o_emp_nm;

end fbm_emp_nm_q;
/

