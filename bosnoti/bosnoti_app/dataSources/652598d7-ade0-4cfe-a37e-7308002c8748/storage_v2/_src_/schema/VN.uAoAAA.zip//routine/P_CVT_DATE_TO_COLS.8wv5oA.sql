create procedure p_cvt_date_to_cols(
    i_date_from     in  varchar2,       --format: YYYYMM
    i_num_of_mon    in  varchar2,       --number of month
    o_results       out sys_refcursor
)
is
    v_sql            varchar2(4000);
    v_pivot_val      varchar2(4000);
    v_with           varchar2(4000);

begin

    v_with := 'with all_data as (
                 select to_char(ADD_MONTHS(to_date(' || i_date_from || ', ''YYYYMM''),(lvl - 1)), ''YYYYMM'') as col_name
                        ,to_char(ADD_MONTHS(to_date(' || i_date_from || ', ''YYYYMM''),(lvl - 1)), ''YYYYMM'') as col_val
                  from (select level lvl 
                       from dual 
                       connect by level <= ' || to_char(i_num_of_mon) || '
                       )
                 )
                ';
    v_sql := v_with || ' SELECT LISTAGG( '''' || col_name || '''', '', '') WITHIN GROUP (ORDER BY col_name) 
                         FROM (select distinct col_name from all_data) ';

    DBMS_OUTPUT.put_line(v_sql);

    execute immediate v_sql into v_pivot_val;

    DBMS_OUTPUT.put_line(v_pivot_val);

    v_sql := v_with || 
             'select * 
              from all_data
              pivot (max(col_val) for col_name in (' || v_pivot_val || '))'
              ;
    DBMS_OUTPUT.put_line(v_sql);

    /* just print the results
    execute immediate v_sql into v_val1, v_val2, v_val3, v_val4, v_val5;
    DBMS_OUTPUT.put_line('The results is v_val1 = [' || v_val1 || '], ' || 
                         'v_val2 = [' || v_val2 || '], ' ||
                         'v_val3 = [' || v_val3 || '], ' ||
                         'v_val4 = [' || v_val4 || '], ' ||
                         'v_val5 = [' || v_val5 || ']'
                         );
    */

    OPEN o_results FOR v_sql;

exception
    when others then
    raise;
end p_cvt_date_to_cols;
/

