create PROCEDURE psr_gga07m00_ins_p
(
   i_trd_dt                in        varchar2
,   i_auto_slip_proc_tp     in        varchar2
,   i_acnt_no               in        varchar2
,   i_sub_no                in        varchar2
,   i_trd_seq_no            in        number
,   i_org_trd_seq_no        in        number
,   i_rmrk_cd               in        varchar2
,   i_trd_amt               in        number
,   i_work_mn               in        varchar2
,   i_work_trm              in        varchar2
,	i_bank_cd				in		  varchar2
)
AS

/*
   \file     psr_gga07m00_ins_p.sql
   \brief

   \section intro Program Information
        - Program Name              :
        - Service Name              : N/A
        - Related Client Program- Client Program ID :
        - Related Tables            : gga07m00
        - Dev. Date                 :
        - Developer                 :
        - Business Logic Desc.      :
        - Latest Modification Date  : 2007-11-30

   \section history Program Modification History
    - 1.0       2007/11/30


   \section hardcoding Hard-Coding List
    - HC-1

   \section info Additional Reference Comments
      t_agnc_brch             varchar2(20) ;

*/

	t_proc_nm				varchar2(20) ;
    t_err_txt               varchar2(200);
    t_acnt_brch_cd          varchar2(20) ;
    t_acnt_agnc_brch        varchar2(20) ;
    t_brch_cd               varchar2(20) ;
    t_agnc_brch             varchar2(20) ;

	t_seq_no                number := 0;

	ts_acc_day_cls_yn       varchar2(10) := Null;
	ts_acc_day_cls_yn_chk1  varchar2(1) := Null;
	ts_acc_day_cls_yn_chk2  varchar2(1) := Null;


    t_err_msg    varchar2(500);
    o_bank_cd    varchar2(5);

BEGIN



    t_proc_nm        :=  'Error';

vn.pxc_log_write('psr_gga07m00_ins_p','1');


    if  i_trd_amt  is  null  or  i_trd_amt  <  0
    then
        t_err_txt  :=  t_proc_nm  ||  'Error';
		t_err_msg := vn.fxc_get_err_msg('V','2707');
		raise_application_error(-20100,t_err_msg||t_err_txt);
    end if;

vn.pxc_log_write('psr_gga07m00_ins_p','2');


    if  i_trd_dt  IS  NULL
    then
        t_err_txt  :=  t_proc_nm  ||  'Error';
		t_err_msg := vn.fxc_get_err_msg('V','2701');
		raise_application_error(-20100,t_err_msg||t_err_txt);
    end if;

    BEGIN
        select  acnt_mng_bnh,
                agnc_brch
          into  t_acnt_brch_cd,
                t_acnt_agnc_brch
          from  vn.aaa01m00
          where acnt_no = i_acnt_no
			and sub_no  = i_sub_no
          ;
    EXCEPTION
        WHEN  OTHERS         THEN
            t_err_txt  :=  t_proc_nm
                   ||  'Error:'
                   ||  to_char(sqlcode);
			t_err_msg := vn.fxc_get_err_msg('V','2001');
			raise_application_error(-20100,t_err_msg||t_err_txt);
    END;

vn.pxc_log_write('psr_gga07m00_ins_p','2-1');

	if i_work_mn in ('DAILY','BATCH') then

		t_brch_cd := t_acnt_brch_cd;
		t_agnc_brch := t_acnt_agnc_brch;

vn.pxc_log_write('psr_gga07m00_ins_p','2-2');
	else

	    BEGIN
	        select  brch_cd,
	                agnc_brch
	          into  t_brch_cd,
	                t_agnc_brch
	          from  vn.xca01m01
	          where emp_no = i_work_mn
	          ;
	    EXCEPTION
			WHEN NO_DATA_FOUND THEN
			     t_seq_no := 0;
	        WHEN  OTHERS         THEN
	            t_err_txt  :=  t_proc_nm
	                   ||  'Error:'
	                   ||  to_char(sqlcode);
				t_err_msg := vn.fxc_get_err_msg('V','9009');
				raise_application_error(-20100,t_err_msg||t_err_txt);
	    END;

vn.pxc_log_write('psr_gga07m00_ins_p','2-3');

	end if;

	if i_rmrk_cd in ('008', '012', '241','242', '243', '246') then
		t_brch_cd := t_acnt_brch_cd;
		t_agnc_brch := t_acnt_agnc_brch;
	end if;

vn.pxc_log_write('psr_gga07m00_ins_p','2-4');
vn.pxc_log_write('psr_gga07m00_ins_p','t_brch_cd-'||t_brch_cd);
vn.pxc_log_write('psr_gga07m00_ins_p','t_agnc_brch-'||t_agnc_brch);
vn.pxc_log_write('psr_gga07m00_ins_p','t_acnt_brch_cd-'||t_acnt_brch_cd);
vn.pxc_log_write('psr_gga07m00_ins_p','t_acnt_agnc_brch-'||t_acnt_agnc_brch);
vn.pxc_log_write('psr_gga07m00_ins_p','i_trd_dt-'||i_trd_dt);

    ts_acc_day_cls_yn := vn.fgg_acc_day_cls_chk2( t_brch_cd, t_agnc_brch, t_acnt_brch_cd, t_acnt_agnc_brch, i_trd_dt);
    ts_acc_day_cls_yn_chk1 := substr(ts_acc_day_cls_yn,1,1);
    ts_acc_day_cls_yn_chk2 := substr(ts_acc_day_cls_yn,2,1);

vn.pxc_log_write('psr_gga07m00_ins_p','ts_acc_day_cls_yn-'||ts_acc_day_cls_yn);

    if ts_acc_day_cls_yn_chk1 <> 'N' then
	    t_err_txt  :=  t_proc_nm
	           ||  'Error'
	           ||  to_char(sqlcode);
		t_err_msg := vn.fxc_get_err_msg('V','2716');
		raise_application_error(-20100,t_err_msg||t_err_txt);
    end if;

    if ts_acc_day_cls_yn_chk2 <> 'N' then
	    t_err_txt  :=  t_proc_nm
	           ||  'Error:'
	           ||  to_char(sqlcode);
		t_err_msg := vn.fxc_get_err_msg('V','2716');
		raise_application_error(-20100,t_err_msg||t_err_txt);
    end if;



/*============================================================================*/
/* seq v?                                                              */
/*============================================================================*/

vn.pxc_log_write('psr_gga07m00_ins_p','3');

    BEGIN
        SELECT vn.GGA07M00_SEQ.nextval 
        into  t_seq_no
        from  dual
          ;
    EXCEPTION
		WHEN NO_DATA_FOUND THEN
		     t_seq_no := 1;
        WHEN  OTHERS         THEN
            t_err_txt  :=  t_proc_nm
                   ||  'Error:'
                   ||  to_char(sqlcode);
			t_err_msg := vn.fxc_get_err_msg('V','2731');
			raise_application_error(-20100,t_err_msg||t_err_txt);
    END;

vn.pxc_log_write('psr_gga07m00_ins_p','5');
vn.pxc_log_write('psr_gga07m00_ins_p','i_trd_dt-'||i_trd_dt);
vn.pxc_log_write('psr_gga07m00_ins_p','t_seq_no-'||t_seq_no);
vn.pxc_log_write('psr_gga07m00_ins_p','i_auto_slip_proc_tp-'||i_auto_slip_proc_tp);
vn.pxc_log_write('psr_gga07m00_ins_p','t_brch_cd-'||t_brch_cd);
vn.pxc_log_write('psr_gga07m00_ins_p','t_agnc_brch-'||t_agnc_brch);
vn.pxc_log_write('psr_gga07m00_ins_p','t_acnt_brch_cd-'||t_acnt_brch_cd);
vn.pxc_log_write('psr_gga07m00_ins_p','t_acnt_agnc_brch-'||t_acnt_agnc_brch);
vn.pxc_log_write('psr_gga07m00_ins_p','i_acnt_no-'||i_acnt_no);
vn.pxc_log_write('psr_gga07m00_ins_p','i_sub_no-'||i_sub_no);
vn.pxc_log_write('psr_gga07m00_ins_p','i_trd_seq_no-'||i_trd_seq_no);
vn.pxc_log_write('psr_gga07m00_ins_p','i_org_trd_seq_no-'||i_org_trd_seq_no);
vn.pxc_log_write('psr_gga07m00_ins_p','i_rmrk_cd-'||i_rmrk_cd);
vn.pxc_log_write('psr_gga07m00_ins_p','i_auto_slip_proc_tp-'||i_auto_slip_proc_tp);
vn.pxc_log_write('psr_gga07m00_ins_p','i_trd_amt-'||i_trd_amt);

	if i_bank_cd = '!' then
	   o_bank_cd := '0000';
    else
	   o_bank_cd := i_bank_cd;
	end if;

    BEGIN

		insert  into  vn.gga07m00
		(
	        proc_dt
	      , seq_no
	      , auto_slip_proc_tp
	      , proc_brch_cd
	      , proc_agnc_brch
	      , exch_brch_cd
	      , exch_agnc_brch
	      , acnt_no
	      , sub_no
	      , trd_dt
	      , trd_seq_no
	      , orig_trd_seq_no
	      , rmrk_job_tp
	      , rmrk_trd_tp
	      , dr_amt_01
	      , dr_amt_02
	      , dr_amt_03
	      , dr_amt_04
	      , dr_amt_05
	      , dr_amt_06
	      , dr_amt_07
	      , dr_amt_08
	      , dr_amt_09
	      , dr_amt_10
	      , cr_amt_01
	      , cr_amt_02
	      , cr_amt_03
	      , cr_amt_04
	      , cr_amt_05
	      , cr_amt_06
	      , cr_amt_07
	      , cr_amt_08
	      , cr_amt_09
	      , cr_amt_10
	      , auto_slip_rfln_tp
	      , auto_slip_proc_mn
	      , auto_slip_proc_dtm
	      , auto_slip_proc_trm
	      , auto_slip_err_cont
	      , bank_cd
	      , work_mn
	      , work_dtm
	      , work_trm
		)
		values
		(
	        i_trd_dt
	      , t_seq_no
	      , i_auto_slip_proc_tp
          , t_acnt_brch_cd
          , t_acnt_agnc_brch
          , t_acnt_brch_cd
          , t_acnt_agnc_brch
	      , i_acnt_no
	      , i_sub_no
	      , i_trd_dt
	      , i_trd_seq_no
	      , i_org_trd_seq_no
	      , '12'
	      , i_rmrk_cd
	      , decode(i_auto_slip_proc_tp,'I',i_trd_amt,0)
	      , 0
	      , 0
	      , 0
	      , 0
	      , 0
	      , 0
	      , 0
	      , 0
	      , 0
	      , decode(i_auto_slip_proc_tp,'I',i_trd_amt,0)
	      , 0
	      , 0
	      , 0
	      , 0
	      , 0
	      , 0
	      , 0
	      , 0
	      , 0
	      , 'N'
	      , Null
	      , Null
	      , Null
	      , Null
	      , o_bank_cd
	      , i_work_mn
	      , sysdate
	      , i_work_trm
		);


    EXCEPTION
        WHEN  OTHERS         THEN
            t_err_txt  :=  t_proc_nm
                   ||  'gga07m00 insert err-:'
                   ||  to_char(sqlcode);
			t_err_msg := vn.fxc_get_err_msg('V','9008');
			raise_application_error(-20100,t_err_msg||t_err_txt);
    END;

end  psr_gga07m00_ins_p;
/

