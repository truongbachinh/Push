create procedure pss_acnt_depo_fee_out_dt_h
( i_sec_cd     in   varchar2,
  i_acnt_no    in   varchar2,
  i_sub_no     in   varchar2,
  i_work_mn    in   varchar2,
  i_work_trm   in   varchar2
) is

 -- Variables
 t_err_txt           varchar2(200) := null ;
 t_err_msg           varchar2(200) := null ;

K_RMRK_CD                VARCHAR2(3) := '247';

t_avail_depo_fee         number :=0;

t_trd_dt                varchar2(20) := ' ';
--t_trd_seq_no            number := 0;
t_dpo_prerm             number := 0;
t_dpo_nowrm             number := 0;
t_acnt_place            varchar2(10) := ' ';
t_bnhof_tp              varchar2(10) := ' ';
t_proc_bnhof_tp         varchar2(10) := ' ';
vn_tot_out_blk_fee      number := 0;
o_dpo                   number := 0;

O_TRD_SEQ_NO    NUMBER;
O1_RTN_TBL      VARCHAR2(100) ;              -- Return Table
O1_RTN_ERR      VARCHAR2(100) ;              -- Return Error Code
O1_RTN_MSG      VARCHAR2(254) ;              -- Return Message
vn_limit_fee      VARCHAR2(254) ;
vn_commit               number := 0;
vn_commit2              number := 0;
begin
 /* Hoai them 20150702: Jira 988*/
    select vn.fss_get_depo_limit_amt(i_sec_cd,'10','00')
    into vn_limit_fee
    from dual;

 for c1 in (
  select acnt_no
      ,sub_no
      ,dpo
    from vn.cwd01m00 t
    where acnt_no like i_acnt_no
    and sub_no like i_sub_no
    and exists(select null from vn.cwd01m00 tt
                   where t.acnt_no = tt.acnt_no
                     and t.sub_no = tt.sub_no
                     /*and tt.dpo_fee_bk > 0*/)
    and t.dpo > vn_limit_fee
   /* and vn.fcw_avail_cash_depo_fee(i_sec_cd,t.acnt_no,t.sub_no) >  vn_limit_fee*/
    order by acnt_no||sub_no
  ) loop --Hoai them 20150305: Check tien > 20k moi thu PLK

  begin

  vn.pxc_log_write('pss_acnt_depo_fee_out_dt', '['||sysdate||'-'||i_acnt_no||'-'||i_sub_no||']');
  /*if (vn.fxb_daily_stat_chk ('B','0','2200','2200','*') <> 'Y' or
     vn.fxb_daily_stat_chk ('B','0','2300','2300','*') <> 'Y' or
     vn.fxb_daily_stat_chk ('B','0','2400','2400','*') <> 'Y' or
     vn.fxb_daily_stat_chk ('B','0','2410','2410','*') <> 'Y' or
     vn.fxb_daily_stat_chk ('B','0','2450','2450','*') <> 'Y')
  then
   vn.pxc_log_write('pss_acnt_depo_fee_out_dt', 'Not finished Previous BATCH');
     return;
  end if;
  */
  for c2 in (
      select acnt_no
         ,sub_no
         ,usefee
         ,usefee_pay_dt
         ,seq_no
         ,mak_strt_dt
      from vn.ssb07m00
      where acnt_no = c1.acnt_no
      and sub_no like trim(c1.sub_no)
      and rcpt_trd_no = 0
      and cncl_yn = 'N'
      and vn.faa_acnt_bank_cd_g(acnt_no, sub_no) <> '0003' and
       vn.faa_acnt_bank_cd_g(acnt_no, sub_no) <> '0002'
      order by acnt_no||mak_strt_dt||sub_no
    ) loop


/*  for c1 in (
      select acnt_no
            ,sub_no
           -- ,tot_blk_fee
            ,usefee
            ,usefee_pay_dt
            ,seq_no
            ,mak_strt_dt
      from vn.ssb07m00
      where substr(mak_strt_dt,1,6) = i_dt
        and substr(mak_end_dt,1,6) = i_dt
        and acnt_no like i_acnt_no
        and sub_no like i_sub_no
        and rcpt_trd_no = 0
        and cncl_yn = 'N'
      order by usefee_pay_dt||acnt_no||sub_no||mak_strt_dt
  ) loop*/

  begin
   /*  t_avail_depo_fee := vn.fcw_avail_cash_depo_fee('068',I_ACNT_NO,I_SUB_NO);

    vn.pxc_log_write('pss_acnt_depo_fee_out',' acnt_no ' || c1.acnt_no ||'-'|| c1.sub_no ||' avail out fee ' ||  t_avail_depo_fee || ' depo fee ' || c1.usefee);

    if (t_avail_depo_fee >= c1.usefee and c1.usefee > 0) then */
       /* withdraw depo fee after unblock */

       VN.PSS_CASH_OUTAMT_P(
                        VN.VWDATE,
                        c2.ACNT_NO,
                        c2.SUB_NO,
                        K_RMRK_CD,
                        c2.usefee,
                        '00',
                        ' ',
                        --K_CNFM_YN,
                        'tháng ' ||substr(c2.mak_strt_dt,5,2) || '/' || substr(c2.mak_strt_dt,1,4),
                        ' ',
                        I_WORK_MN,
                        I_WORK_TRM,
                        O_TRD_SEQ_NO,
                        O1_RTN_TBL,
                        O1_RTN_ERR,
                        O1_RTN_MSG);

       IF  TO_NUMBER(O1_RTN_ERR)  <>  0  THEN /* 3. ERROR */
          vn.pxc_log_write('pss_acnt_depo_fee_out_dt', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG|| ']') ;
          --raise_application_error(-20100,'PSS_CASH_OUTAMT_P '||sqlerrm);
       end if;


        /* Update ssb07m00 */
        if (O_TRD_SEQ_NO > 0) then

            update  vn.ssb07m00
            set    rcpt_trd_no  = O_TRD_SEQ_NO
--                  ,tot_blk_fee  = 0
                  ,work_mn = i_work_mn
                  ,work_trm = i_work_trm
                  ,work_dtm = sysdate
            where   usefee_pay_dt  = c2.usefee_pay_dt
            and    mak_strt_dt     = c2.mak_strt_dt
            and     acnt_no        = c2.acnt_no
            and     sub_no         = c2.sub_no
            and     seq_no         = c2.seq_no;
         end if;
     -- end if;
         vn_commit := vn_commit + 1;
        vn_commit2 := vn_commit2 + 1;
        vn.pxc_log_write('pss_acnt_depo_fee_out','vn_commit'||to_char(vn_commit) );
        vn.pxc_log_write('pss_acnt_depo_fee_out','vn_commit2'||to_char(vn_commit2) );

        if vn_commit >= 500 then
            vn.pxc_log_write('pss_acnt_depo_fee_out', 'I will commit now!');
            vn_commit := 0;
           /* commit;*/
           rollback;
        end if;
    end;
  end loop;

   end;
  end loop;
/*  commit;*/
rollback;
  return;
end pss_acnt_depo_fee_out_dt_h;
/

