create function fdl_get_mrtg_lnd_qty
(
    i_acnt_no        in   varchar2,        --
    i_sub_no         in   varchar2,        --
    i_stk_cd         in   varchar2         --
)
    return  number
as

    t_err_txt			varchar2(80); -- error text buffer
    t_err_msg           VARCHAR2(500);

begin


/*============================================================================*/
/* generl commission return                                                   */
/*============================================================================*/
	for c1 in (
		select  (sum(nvl(mrtg_lnd_qty,0))
		      -  sum(nvl(mrtg_rpy_qty,0))) mrtg_qty
	      from  vn.dlm01m00
	     where  lnd_tp       =  '20'
	       and  acnt_no      =  i_acnt_no
	       and  sub_no       =  i_sub_no
	       and  lnd_bank_cd in  ('0002','0003')
	       and  stk_cd       =  i_stk_cd
	       and  lnd_acpt_tp  =  '01'
	) loop
		return c1.mrtg_qty;
	end loop;

	-- No data found error
	return  0;

end fdl_get_mrtg_lnd_qty;
/

