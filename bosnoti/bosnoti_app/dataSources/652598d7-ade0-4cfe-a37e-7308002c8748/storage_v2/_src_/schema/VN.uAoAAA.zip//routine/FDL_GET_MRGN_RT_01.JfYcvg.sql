create FUNCTION    fdl_get_mrgn_rt_01(i_acnt_no IN VARCHAR2,
                                              i_sub_no  IN VARCHAR2,
                                              i_rt_tp   IN VARCHAR2,
                                              i_apy_dt  IN VARCHAR2)
  RETURN NUMBER AS
  /*!
     \file     fdl_get_mrgn_rt_01.sql
     \brief    margin information
     \modify   20100423 hjcho check "apy_dt <= i_apy_dt"

     select vn.fdl_get_mrgn_rt_01('999','045C000001','01','20100101') from dual;
  */

  t_grp_acnt_no VARCHAR2(5);
  t_prd_no      VARCHAR2(5);
  t_src_no      VARCHAR2(5);
  t_rate        NUMBER;
  t_rate_chk    NUMBER := 1;

  o_out_number NUMBER := 0;
  t_err_msg    VARCHAR2(500);

  ----------------------------------********************************************************************
  r_mrgn_frce_rt NUMBER := 0;
  c_mrgn_frce_rt NUMBER := 0;

  r_mrgn_eval_rt NUMBER := 0;
  c_mrgn_eval_rt NUMBER := 0;

  r_mrgn_mntn_rt NUMBER := 0;
  c_mrgn_mntn_rt NUMBER := 0;

  r_mrgn_call_rt NUMBER := 0;
  c_mrgn_call_rt NUMBER := 0;

  r_mrgn_lnd_prd NUMBER := 0;
  c_mrgn_lnd_prd NUMBER := 0;

  r_int_rt NUMBER := 0;
  c_int_rt NUMBER := 0;

  r_int_dly_rt NUMBER := 0;
  c_int_dly_rt NUMBER := 0;

  r_mrgn_with_rt NUMBER := 0;
  c_mrgn_with_rt NUMBER := 0;

  r_int_waive_days NUMBER := 0;
  c_int_waive_days NUMBER := 0;

  r_buy_able_out_basket_yn NUMBER := 0;
  r_cost_of_cap_rt         NUMBER := 0;
  r_fee_bd_rt              NUMBER := 0;
  r_int_calc_apy_tp        NUMBER := 0;
  r_int_pay_tp             NUMBER := 0;
  r_int_pay_yn             NUMBER := 0;
  r_int_to_prn_yn          NUMBER := 0;
  r_int_waive_day_tp       NUMBER := 0;
  r_lnd_int_cal_std_dt     NUMBER := 0;
  r_mrgn_int_prd_min       NUMBER := 0;
  r_mrgn_imr_rt            NUMBER := 0;
  r_rn_fee_min             NUMBER := 0;
  r_rn_fee_rt              NUMBER := 0;
  r_rn_num_max             NUMBER := 0;
  r_ro_fee_min             NUMBER := 0;
  r_ro_fee_rt              NUMBER := 0;
  r_ro_num_max             NUMBER := 0;

  c_buy_able_out_basket_yn NUMBER := 0;
  c_cost_of_cap_rt         NUMBER := 0;
  c_fee_bd_rt              NUMBER := 0;
  c_int_calc_apy_tp        NUMBER := 0;
  c_int_pay_tp             NUMBER := 0;
  c_int_pay_yn             NUMBER := 0;
  c_int_to_prn_yn          NUMBER := 0;
  c_int_waive_day_tp       NUMBER := 0;
  c_lnd_int_cal_std_dt     NUMBER := 0;
  c_mrgn_int_prd_min       NUMBER := 0;
  c_mrgn_imr_rt            NUMBER := 0;
  c_rn_fee_min             NUMBER := 0;
  c_rn_fee_rt              NUMBER := 0;
  c_rn_num_max             NUMBER := 0;
  c_ro_fee_min             NUMBER := 0;
  c_ro_fee_rt              NUMBER := 0;
  c_ro_num_max             NUMBER := 0;

  t_lnd_use_amt   NUMBER := 0;
  t_lnd_rpy_amt   NUMBER := 0;
  t_lnd_rm_amt    NUMBER := 0;
  t_lnd_int       NUMBER := 0;
  t_mrgn_shrt_amt NUMBER := 0;

  t_crd_mrtg_mna NUMBER := 0;

  -------------------------------------------------

  t_found  VARCHAR2(01);
  t_emp_no VARCHAR2(15);

  t_reuse_rt NUMBER := 0;

  t_pd_cls_pri     NUMBER := 0;
  t_stk_rt         NUMBER := 0;
  t_mrgn_rt        NUMBER := 0;
  t_acnt_limit_amt NUMBER := 0;
  t_emp_limit_amt  NUMBER := 0;

  t_lnd_rm_int NUMBER := 0;
  t_nav        NUMBER := 0;
  t_int_cmsn   NUMBER := 0;
  t_now_cmr    NUMBER := 0;
  t_now_cwr    NUMBER := 0;

  t_mng_brch_cd    VARCHAR2(03) := NULL;
  t_mng_agnc_cd    VARCHAR2(02) := NULL;
  t_brch_limit_amt NUMBER := 0;
  t_agnc_limit_amt NUMBER := 0;

  t_dpo           NUMBER := 0;
  t_dpo_block     NUMBER := 0;
  t_tot_block     NUMBER := 0;
  t_mrgn_expt_amt NUMBER := 0;

  ts_chg_dt VARCHAR2(8) := NULL;

  t_acnt_expt_amt   NUMBER := 0;
  t_acnt_expt_amt_1 NUMBER := 0;
  t_emp_expt_amt    NUMBER := 0;
  t_brch_expt_amt   NUMBER := 0;
  t_agnc_expt_amt   NUMBER := 0;

  t_tot_sec_lnd_amt  NUMBER := 0;
  t_tot_sec_lmit_amt NUMBER := 0;
  t_tot_able_amt     NUMBER := 0;

  t_max_cer  NUMBER := 0;
  t_asset    NUMBER := 0;
  t_lnd      NUMBER := 0;
  t_lnd_max  NUMBER := 0;
  t_pia_amt  NUMBER := 0;
  t_shrt_amt NUMBER := 0;

  t_rpy_cmsn     NUMBER := 0;
  t_rpy_cmsn_tot NUMBER := 0;

  ts_max_sub_no VARCHAR(02) := NULL;

  ts_pd_mth_dt   VARCHAR2(08) := NULL;
  ts_ppd_mth_dt  VARCHAR2(08) := NULL;
  ts_pppd_mth_dt VARCHAR2(08) := NULL;

  t_acnt_limit_vcsh  NUMBER := 0;
  t_lnd_use_acnt_amt NUMBER := 0;
  t_lnd_max_acnt_amt NUMBER := 0;

  t_max_limit NUMBER := 0;

BEGIN

  /*============================================================================*/
  /* Valiabl Initialize
  /*============================================================================*/
  o_out_number := 0;
  t_grp_acnt_no := VN.faa_acnt_get_grp_no(i_acnt_no, i_sub_no, '2', i_apy_dt);
  /*============================================================================*/
  /* i_rt_tp = 0..31 la tp cu; >=32 la tp moi:

   ********************************************Can check lai cac type nay, co the khong dung
     Cac i_rt_tp sau day se Bo, Khong dung logic cu nua; cho nao dung thi Check lai BA

   05:mrgn_max_able- han muc con lai
     12:oringal loan short amount - credit:
   15:Net Asset Value - (tien mat - tien vay):
     18:pia and selling repay - tong so tien vay ung truoc: bo ti le reuse_rt
     20:reuse_rgt: ==> Bo, Khong dung logic cu nua; cho nao dung thi Check lai BA
     22:MAX CER  ==> Bo, Khong dung logic cu nua; cho nao dung thi Check lai BA
   23:mrgn_max_able  ==> Bo, Khong dung logic cu nua; cho nao dung thi Check lai BA
   24:mrgn_ord_rt  ==> Bo, Khong dung logic cu nua; cho nao dung thi Check lai BA
   27:loan need to do to return to cor  ==> Bo, Khong dung logic cu nua; cho nao dung thi Check lai BA
   28:loan need to do to return to cor  ==> Bo, Khong dung logic cu nua; cho nao dung thi Check lai BA
   29:pia today - so tien ung truoc trong ngay  ==> Bo, Khong dung logic cu nua; cho nao dung thi Check lai BA


     Cac i_rt_tp sau day co the dung lai:
     06:reuse_rt     - ti le danh gia chung khoan cho ve ==> mac dinh la 1
   07:pia_rpy_amt(PIA + selling repay) - So tien vay ung truoc
   10:mrgn_use_amt - so tien vay margin con lai:     van giu nguyen logic cu
   11:margin loan short amount:             van giu nguyen logic cu
     13:non-settled buying loan amount          van giu nguyen logic cu
   14:Money loan amt - so tien vay tin chap con lai:  van giu nguyen logic cu
   16:interests + commission- lai margin:       van giu nguyen logic cu
   17:margin loan amount including expired loan amount of margin - tong vay+lai vay margin ==> van giu nguyen logic cu
   19:interest for margin loan and money loan - Lai vay margin+tin chap: van giu nguyen logic cu
   21:pia fee -  phi ung truoc : van giu nguyen logic cu
   25:now cmr - ti le CMR hien thoi cua tai khoan :  van giu nguyen logic cu
   31:short amt to sell stock to CWR - so tien ban chung khoan de ve ti le an toan :  van giu nguyen logic cu
  */
  /*============================================================================*/

  /*  06:reuse_rt     - ti le danh gia chung khoan cho ve ==> mac dinh la 1 */
  IF i_rt_tp = '06' THEN
    t_reuse_rt := vn.fxc_col_cd_tp ('reuse_rt');

    return t_reuse_rt;
    /*  pia (lnd+int) and selling repay */
  ELSIF i_rt_tp = '07' THEN
    t_lnd_use_amt := 0;
    t_lnd_rpy_amt := 0;
    t_lnd_int     := 0;

    BEGIN
      SELECT nvl(sum(lnd_amt-lnd_rpy_amt),0) lnd_rm_amt
        INTO t_lnd_use_amt
        FROM vn.dlm01m00
       WHERE acnt_no = i_acnt_no
         AND sub_no = i_sub_no
         AND nvl((lnd_amt-lnd_rpy_amt),0) > 0
         AND lnd_tp = '10';
    EXCEPTION
      WHEN OTHERS THEN
        t_lnd_use_amt := 0;
    END;

    -- NHSV-929: Tinh phi thuc te, thay vi phi tam tinh tren dlm01m00
    SELECT vn.fdl_get_mrgn_rt_01(i_acnt_no, i_sub_no, '21', i_apy_dt) lnd_int
      INTO t_lnd_int
      FROM DUAL;

    o_out_number := t_lnd_use_amt + NVL(t_lnd_int, 0);
    RETURN o_out_number;
    /*  margin loan amount */
  ELSIF i_rt_tp = '10' THEN
    t_lnd_use_amt := 0;
    BEGIN
      SELECT nvl(sum(lnd_use_amt),0)
        INTO t_lnd_use_amt
        FROM vn.dlm09m10
       WHERE acnt_no = i_acnt_no
         AND sub_no = i_sub_no
         AND lnd_tp <> '10';
    EXCEPTION
      WHEN OTHERS THEN
        t_lnd_use_amt := 0;
    END;

    /*  2010-12-20 add start  han */
    t_lnd_rm_amt := 0;
    BEGIN
      SELECT nvl(SUM(nvl(lnd_amt, 0)) - SUM(nvl(lnd_rpy_amt, 0)), 0) lnd_rm_amt
        INTO t_lnd_rm_amt
        FROM vn.dlm01m00
       WHERE lnd_tp <> '10'
         AND acnt_no = i_acnt_no
         AND sub_no = i_sub_no
         AND expr_dt < vn.vwdate
         AND lnd_acpt_tp = '01';
    EXCEPTION
      WHEN OTHERS THEN
        t_lnd_rm_amt := 0;
    END;

    o_out_number := greatest(t_lnd_use_amt - t_lnd_rm_amt, 0);
    /*  2010-12-20 add end  han */

    RETURN o_out_number;

    /*margin loan short amount*/
  ELSIF i_rt_tp = '11' THEN
    t_mrgn_shrt_amt := 0;
    BEGIN
      SELECT nvl(mrgn_shrt_amt, 0)
        INTO t_mrgn_shrt_amt
        FROM vn.cwd99m00
       WHERE acnt_no = i_acnt_no
         AND sub_no = i_sub_no;
    EXCEPTION
      WHEN OTHERS THEN
        t_mrgn_shrt_amt := 0;
    END;

    o_out_number := t_mrgn_shrt_amt;

    RETURN o_out_number;

    /* non-settled buying loan amount */
  ELSIF i_rt_tp = '13' THEN

    ts_pd_mth_dt   := vn.fxc_vorderdt_g(to_date(vn.vwdate, 'yyyymmdd'), -1);
    ts_ppd_mth_dt  := vn.fxc_vorderdt_g(to_date(vn.vwdate, 'yyyymmdd'), -2);
    ts_pppd_mth_dt := vn.fxc_vorderdt_g(to_date(vn.vwdate, 'yyyymmdd'), -3);

    IF i_sub_no = '00' OR t_prd_no = '' THEN
      o_out_number := 0;
    ELSE
      o_out_number := 0;
      FOR c1 IN (SELECT stk_cd,
                        mth_dt,
                        SUM(mrtg_lnd_qty) mrtg_lnd_qty,
                        SUM(mrtg_rpy_qty) mrtg_rpy_qty,
                        SUM(lnd_amt) lnd_amt,
                        SUM(lnd_rpy_amt) lnd_rpy_amt
                   FROM vn.dlm01m00
                  WHERE lnd_tp = '30'
                    AND acnt_no = i_acnt_no
                    AND sub_no = i_sub_no
                    AND setl_dt >= vn.vwdate
                    AND mrtg_lnd_qty - mrtg_rpy_qty > 0
                  GROUP BY stk_cd, mth_dt
                  ORDER BY stk_cd, mth_dt) LOOP
        t_pd_cls_pri := 0;
        t_stk_rt     := 0;
        t_mrgn_rt    := 0;
        t_pd_cls_pri := vn.fss_get_pd_cls_pri(c1.stk_cd);

        t_mrgn_rt := vn.fdl_get_mrgn_rt_01(i_acnt_no,
                                           i_sub_no,
                                           '01',
                                           i_apy_dt);

        IF c1.mth_dt = ts_pppd_mth_dt THEN
          t_stk_rt := vn.fss_get_match_rate_acnt(c1.stk_cd,
                                                 3,
                                                 i_acnt_no,
                                                 i_sub_no);
        ELSIF c1.mth_dt = ts_ppd_mth_dt THEN
          t_stk_rt := vn.fss_get_match_rate_acnt(c1.stk_cd,
                                                 2,
                                                 i_acnt_no,
                                                 i_sub_no);
        ELSIF c1.mth_dt = ts_pd_mth_dt THEN
          t_stk_rt := vn.fss_get_match_rate_acnt(c1.stk_cd,
                                                 1,
                                                 i_acnt_no,
                                                 i_sub_no);
        ELSIF c1.mth_dt = vn.vwdate THEN
          t_stk_rt := vn.fss_get_match_rate_acnt(c1.stk_cd,
                                                 0,
                                                 i_acnt_no,
                                                 i_sub_no);
        END IF;

        o_out_number := o_out_number +
                        round(((c1.mrtg_lnd_qty - c1.mrtg_rpy_qty) *
                              t_pd_cls_pri) * t_stk_rt * t_mrgn_rt);

      END LOOP;
    END IF;

    RETURN o_out_number;

    /* Money loan amount */
  ELSIF i_rt_tp = '14' THEN
    t_lnd_rm_amt := 0;

    BEGIN
      SELECT SUM(nvl(lnd_amt, 0)) - SUM(nvl(lnd_rpy_amt, 0)) lnd_rm_amt
        INTO t_lnd_rm_amt
        FROM vn.dlm04m00
       WHERE lnd_tp = '60'
         AND acnt_no = i_acnt_no
         AND sub_no = i_sub_no
         AND lnd_bank_cd LIKE '%'
         AND nvl(lnd_amt, 0) - nvl(lnd_rpy_amt, 0) > 0
         AND lnd_acpt_tp = '01'
       GROUP BY acnt_no;
    EXCEPTION
      WHEN OTHERS THEN
        t_lnd_rm_amt := 0;
    END;

    o_out_number := t_lnd_rm_amt;

    RETURN o_out_number;

    /* interests + commission */
  ELSIF i_rt_tp = '16' THEN
    t_int_cmsn := 0;
    BEGIN
      SELECT mrgn_loan_int
        INTO t_int_cmsn
        FROM vn.cwd99m00
       WHERE acnt_no = i_acnt_no
         AND sub_no = i_sub_no;
    EXCEPTION
      WHEN OTHERS THEN
        t_int_cmsn := 0;
    END;

    o_out_number := t_int_cmsn;

    RETURN o_out_number;

    /* margin loan amount including expired loan amount of margin */
  ELSIF i_rt_tp = '17' THEN
    t_lnd_use_amt := 0;
    BEGIN
      SELECT nvl(SUM(lnd_use_amt),0) lnd_use_amt
        INTO t_lnd_use_amt
        FROM vn.dlm09m10
       WHERE acnt_no = i_acnt_no
         AND sub_no = i_sub_no
         AND lnd_tp IN ('70', '80');
    EXCEPTION
      WHEN OTHERS THEN
        t_lnd_use_amt := 0;
    END;

    o_out_number := t_lnd_use_amt;

    RETURN o_out_number;
    /*  interest for margin loan and money loan */
  ELSIF i_rt_tp = '19' THEN

    t_lnd_rm_int := 0;
    BEGIN
      SELECT nvl(SUM(nvl(lnd_int, 0)) + SUM(nvl(dly_int, 0)), 0) lnd_rm_int
        INTO t_lnd_rm_int
        FROM vn.dlm01m00
       WHERE lnd_tp IN ('70', '80')
         AND acnt_no = i_acnt_no
         AND sub_no = i_sub_no
         AND lnd_acpt_tp = '01'
         AND lnd_amt > lnd_rpy_amt;
    EXCEPTION
      WHEN OTHERS THEN
        t_lnd_rm_int := 0;
    END;

    o_out_number := o_out_number + t_lnd_rm_int;

    t_lnd_rm_int := 0;
    BEGIN
      SELECT nvl(SUM(nvl(lnd_int, 0)) + SUM(nvl(dly_int, 0)), 0) lnd_rm_int
        INTO t_lnd_rm_int
        FROM vn.dlm04m00
       WHERE lnd_tp = '60'
         AND acnt_no = i_acnt_no
         AND sub_no = i_sub_no
         AND lnd_acpt_tp = '01'
         AND lnd_amt > lnd_rpy_amt;
    EXCEPTION
      WHEN OTHERS THEN
        t_lnd_rm_int := 0;
    END;

    o_out_number := o_out_number + t_lnd_rm_int;

    t_lnd_rm_int := 0;
    t_lnd_rm_int := vn.fdl_get_mon_rm_int('%',
                                          '70',
                                          i_acnt_no,
                                          i_sub_no,
                                          '%',
                                          '%',
                                          '%');
    o_out_number := o_out_number + t_lnd_rm_int;

    RETURN o_out_number;

    /*  pia fee */
  ELSIF i_rt_tp = '21' THEN

    t_rpy_cmsn_tot := 0;

    FOR c1 IN (SELECT acnt_no,
                      sub_no,
                      SUM(lnd_amt) tot_lnd_amt,
                      lnd_bank_cd,
                      lnd_dt,
                      expr_dt,
                      lnd_cmsn_rt
                 FROM vn.dlm01m00
                WHERE lnd_tp = '10'
                  AND acnt_no = i_acnt_no
                  AND sub_no = i_sub_no
                  AND lnd_amt > lnd_rpy_amt
                GROUP BY acnt_no,
                         sub_no,
                         lnd_bank_cd,
                         lnd_dt,
                         expr_dt,
                         lnd_cmsn_rt

               ) LOOP
      vn.pdl_get_lnd_cmsn('10',
                          c1.lnd_bank_cd,
                          c1.acnt_no,
                          c1.sub_no,
                          c1.lnd_dt,
                          c1.expr_dt,
                          c1.tot_lnd_amt /* lnd_amt */,
                          c1.tot_lnd_amt /* rpy_amt */,
                          c1.lnd_cmsn_rt,
                          t_rpy_cmsn);
      t_rpy_cmsn_tot := t_rpy_cmsn_tot + t_rpy_cmsn;
    END LOOP;

    o_out_number := t_rpy_cmsn_tot;

    RETURN o_out_number;

    /* now cmr */
  ELSIF i_rt_tp = '25' THEN
    t_now_cmr := 0;
    BEGIN
      SELECT mrgn_now_mntn_rt
        INTO t_now_cmr
        FROM vn.cwd99m00
       WHERE acnt_no = i_acnt_no
         AND sub_no = i_sub_no;
    EXCEPTION
      WHEN OTHERS THEN
        t_now_cmr := 0;
    END;

    o_out_number := t_now_cmr;

    RETURN o_out_number;

    /*  mrgn_withdraw_rt */
    ELSIF  i_rt_tp  =  '30' THEN

        o_out_number := VN.fdl_get_mrgn_grp_acnt_rt (i_acnt_no, i_sub_no,t_grp_acnt_no,'05',i_apy_dt );

        RETURN o_out_number;

    /* short amt to sell stock to CWR 
    = [TL - TA(1-CWR)]/CWR 
    */
  ELSIF i_rt_tp = '31' THEN
    t_asset := 0;
    t_lnd :=0;
    BEGIN
      SELECT tot_asset_sbst_amt, loan_nowrm
        INTO t_asset, t_lnd
        FROM vn.cwd99m00
       WHERE acnt_no = i_acnt_no
         AND sub_no = i_sub_no;
    EXCEPTION
      WHEN OTHERS THEN
        t_asset := 0;
        t_lnd  := 0;
    END;

    t_shrt_amt := 0;

    t_now_cwr := 0;
    t_now_cwr := vn.fdl_get_mrgn_rt_01(i_acnt_no, i_sub_no, '30', i_apy_dt);

      t_shrt_amt := greatest( round ((t_lnd - t_asset*(1-t_now_cwr))/t_now_cwr) 
                             ,0);

    vn.pxc_log_write('fdl_get_mrgn_rt_01',
                     ' t_acnt: ' || i_acnt_no || ' t_sub: ' || i_sub_no);
    vn.pxc_log_write('fdl_get_mrgn_rt_01',
                     ' t_asset: ' || to_char(t_asset));
    vn.pxc_log_write('fdl_get_mrgn_rt_01',
                     ' t_lnd: ' || to_char(t_lnd));
    o_out_number := round(t_shrt_amt, 0);
    RETURN o_out_number;
    ------------------------------------------------------------------
  ELSIF i_rt_tp = '31' THEN
    o_out_number := 0;
    RETURN o_out_number;
  ELSE
    t_err_msg := 'Loai tham so i_rt_tp = ' || i_rt_tp ||
                 ' truyen vao khong co';
    vn.pxc_log_write('fdl_get_mrgn_rt_01', t_err_msg);
    raise_application_error(-20100, t_err_msg);
  END IF;

END fdl_get_mrgn_rt_01;
/

