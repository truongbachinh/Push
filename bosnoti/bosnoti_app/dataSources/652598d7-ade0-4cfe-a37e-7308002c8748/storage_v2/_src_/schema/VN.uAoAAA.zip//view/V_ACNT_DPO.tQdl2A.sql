create view V_ACNT_DPO as
select std_dt, acnt_no, sub_no, dpo, bank_cd_off, bank_nm_off, bank_acnt_no
  from
      (
      select vn.vhdate std_dt,
             a.acnt_no  acnt_no,
             a.sub_no   sub_no,
             to_char(b.dpo) dpo,
             nvl(c.bank_cd_off, '!') bank_cd_off,
             nvl(vn.faa_bank_off_nm_g(c.bank_cd_off), '!') bank_nm_off,
             nvl(c.bank_acnt_no, '!') bank_acnt_no
        from vn.aaa01m00 a,
             vn.cwd01m00 b,
             (SELECT acnt_no, sub_no, bank_cd_off, bank_acnt_no, cls_dt, bank_tp
                FROM vn.aaa09m00
               WHERE cls_dt = '30000101'
                 AND bank_tp = '2') c
      where a.acnt_no = b.acnt_no
        and a.sub_no  = b.sub_no
        and c.acnt_no (+) = a.acnt_no
        and c.sub_no (+)  = a.sub_no
      union all
      select std_dt std_dt,
             a.acnt_no  acnt_no,
             a.sub_no   sub_no,
             to_char(b.dpo) dpo,
             nvl(c.bank_cd_off, '!') bank_cd_off,
             nvl(vn.faa_bank_off_nm_g(c.bank_cd_off), '!') bank_nm_off,
             nvl(c.bank_acnt_no, '!') bank_acnt_no
        from vn.aaa01m00 a,
             vn.cwd01h00 b,
             (SELECT acnt_no, sub_no, bank_cd_off, bank_acnt_no, cls_dt, bank_tp
                FROM vn.aaa09m00
               WHERE cls_dt = '30000101'
                 AND bank_tp = '2') c
      where  a.acnt_no = b.acnt_no
        and  a.sub_no  = b.sub_no
        and  c.acnt_no (+) = a.acnt_no
        and  c.sub_no  (+) = a.sub_no
      )
/

