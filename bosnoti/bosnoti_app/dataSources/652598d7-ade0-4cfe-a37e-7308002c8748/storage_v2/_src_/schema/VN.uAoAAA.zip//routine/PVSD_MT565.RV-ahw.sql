create PROCEDURE PVSD_MT565
(
  i_sec_cd  IN VARCHAR2,
  i_tp      IN VARCHAR2,
  i_biz_cd  IN VARCHAR2,
  i_message IN VARCHAR2
)
/*************************************************
    i_tp:
    1: Dang ky dat mua CK

    i_biz_cd:
      001: TK
      002: CK + quyen
      003: Lenh
      004: Thanh toan + Cho vay

    i_mess:
      Cac tham so duoc ngan cach boi chuoi cac ky tu dac biet: !@#
      Doi voi bao cao yeu cau tham so dau tien phai la Ma bao cao. VD: CS001
    *************************************************/
 AS
  TYPE t_array IS TABLE OF VARCHAR2(200) INDEX BY PLS_INTEGER;

  v_send_dat VARCHAR2(4000);
  vn_message VARCHAR2(1000) := trim(i_message);
  vn_pos     NUMBER := 0;
  i          NUMBER := 0;
  vn_var     t_array;

BEGIN

  vn.pxc_log_write('pvsd_mt565', 'Type: '||i_tp || '-' ||i_message);

  IF i_tp = '1' THEN
    WHILE INSTR(vn_message, '!@#') > 0
    LOOP
      i      := i + 1;
      vn_pos := INSTR(vn_message, '!@#');

      vn_var(i) := substr(vn_message, 1, vn_pos - 1);

      vn_message := substr(vn_message, vn_pos + 3);
    END LOOP;

    vn_var(i + 1) := vn_message;

    FOR C1 IN (
    SELECT  B.BOS_SEQ_NO,
			A.RGT_VSD_SEQ,
			B.STK_CD,
			B.ACNT_NO,
			NVL(B.SBST_QTY,0) SBST_QTY,
			decode(D.IDNO_TP
             	,'1'
                ,'IDNO'
                ,'2'
                ,'CCPT'
                ,'3'
                ,'CORP'
                ,'4'
                ,'OTHR'
                ,'5'
                ,'FIIN'
                ,'6'
                ,'ARNU'
                ,'7'
                ,'GOVT') IDNO_TP,
			replace(decode(C.ACNT_TP, 'F', C.FRGN_TRD_CD, D.IDNO), '/', '?_?') IDNO,
			nvl(decode(C.ACNT_TP, 'F', C.FRGN_ISS_DT, D.idno_iss_dt), '!') ISS_DT,
			vn.fss_get_vsd_brch(i_sec_cd, B.STK_CD) VSD_BRCH
    FROM   	VN.SRR01M00 A,
			VN.SRR03M00 B,
			VN.AAA01M00 C,
			VN.AAA02M00 D
	WHERE   A.RGT_TP = B.RGT_TP
	AND    A.RGT_STD_DT = B.RGT_STD_DT
	AND    A.STK_CD = B.STK_CD
	AND    A.SEQ_NO = B.SEQ_NO
	AND    B.ACNT_NO = C.ACNT_NO
	AND    B.SUB_NO = C.SUB_NO
	AND    C.IDNO = D.IDNO
	AND    B.SBST_DT = vn_var(1)
	AND   B.BOS_SEQ_NO = vn_var(2)
	AND   B.BOS_STAT in ('1', '2'))
    LOOP
        --Block: Thong tin chung
      v_send_dat :=
        ':16R:GENL' || chr(13) ||
        ':20C::SEME//' || C1.BOS_SEQ_NO || chr(13) ||
        ':20C:CORP//' || C1.RGT_VSD_SEQ || chr(13) ||
        ':23G:NEWM' || chr(13) ||
        ':22F::CAEV//'||'RHTS' || chr(13) ||
        ':98A::PREP//' || to_char(SYSDATE, 'yyyymmdd') || chr(13) ||
        ':16S:GENL' || chr(13) ||

        --Block: Chung khoan goc
        ':16R:USECU' || chr(13) ||
        ':35B:/VN/' || C1.STK_CD || chr(13) ||
        ':16R:FIA' || chr(13) ||
        ':12A::CLAS//CORP' || '/' || '1' || chr(13) ||
        ':16S:FIA' || chr(13) ||

        --Block: Thong tin tai khoan
        ':16R:ACCTINFO' || chr(13) ||
        ':97A::SAFE//' || C1.ACNT_NO || chr(13) ||
        ':16S:ACCTINFO' || chr(13) ||

		':16S:USECU' || chr(13) ||

        --Block: Thong tin chi dan
        ':16R:CAINST' || chr(13) ||
        ':13A::CAON//' || '001' || chr(13) ||
        ':22F::CAOP//' || 'EXER' || chr(13) ||
        ':36B::QINS//' || 'UNIT/' || C1.SBST_QTY || chr(13) ||
        ':70E::INST//' || chr(13) ||
          C1.IDNO_TP || chr(13) ||
          C1.IDNO || chr(13) ||
          C1.ISS_DT || chr(13) ||
        ':16S:CAINST' || chr(13) ||
        ':16R:ADDINFO' || chr(13) ||
        ':70E::ADTX//' || chr(13) ||
        ':16S:ADDINFO';

        INSERT INTO VN.VSD01M00
                    (REG_DT,
                    SEQ_NO,
                    BIZ_CD,
                    DAT_CD,
                    SND_DAT,
                    SND_TP,
                    WORK_DTM,
					VSD_BRCH)
        VALUES
            (to_char(SYSDATE, 'yyyymmdd'),
            C1.BOS_SEQ_NO,
            i_biz_cd,
            '565',
            v_send_dat,
            '1',
            SYSDATE,
			C1.VSD_BRCH);

    END LOOP;
  END IF;

END PVSD_MT565;
/

