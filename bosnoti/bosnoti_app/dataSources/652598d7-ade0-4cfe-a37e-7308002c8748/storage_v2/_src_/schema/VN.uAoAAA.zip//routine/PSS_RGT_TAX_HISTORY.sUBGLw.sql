create procedure pss_rgt_tax_history
( i_acnt_no   in varchar2,
  i_stk_cd    in varchar2,
  i_proc_dt   in varchar2,
  i_cnte      in varchar2,
  i_work_mn   in varchar2,
  i_work_trm  in varchar2
)
as
/* *******************************************************************
  Muc dich: Luu lai thay doi so luong chung khoan can tinh thue va cho tinh thue.

  Chu y: Thu tuc nay can duoc goi SAU KHI thay doi so luong o bang ssb05m10.

  Lich su thay doi:
  18-Dec-2020 vnjvthangnm Khoi tao thu tuc.
******************************************************************* */
  v_proc_dt varchar2(8);
begin
  vn.pxc_log_write('pss_rgt_tax_history','Bat dau xu ly cho tai khoan: ' || i_acnt_no || ', MaCK: ' || i_stk_cd || ', Ngay:' || i_proc_dt || ', Ghi chu: ' || i_cnte);

  if i_proc_dt is null then
    v_proc_dt := vn.vwdate;
  else
    v_proc_dt := i_proc_dt;
  end if;

  insert into ssb05h10
  ( id,
    proc_dt,
    acnt_no,
    stk_cd,
    tax_qty,
    tax_sb_lim_qty,
    tax_delay_qty,
    tax_delay_sb_qty,
    wtax_qty,
    wtax_sb_lim_qty,
    wtax_delay_qty,
    wtax_delay_sb_qty,
    cnte,
    create_mn,
    create_dtm,
    create_trm,
    work_mn,
    work_dtm,
    work_trm,
    backup_mn,
    backup_dtm,
    backup_trm)
  select ssb05h10_seq.nextval,
         v_proc_dt,
         acnt_no,
         stk_cd,
         tax_qty,
         tax_sb_lim_qty,
         tax_delay_qty,
         tax_delay_sb_qty,
         wtax_qty,
         wtax_sb_lim_qty,
         wtax_delay_qty,
         wtax_delay_sb_qty,
         i_cnte,
         create_mn,
         create_dtm,
         create_trm,
         work_mn,
         work_dtm,
         work_trm,
         i_work_mn,
         sysdate,
         i_work_trm
    from ssb05m10
   where acnt_no = i_acnt_no
     and stk_cd = i_stk_cd;

  if sql%rowcount = 0 then
    vn.pxc_log_write('pss_rgt_tax_history','Khong co du lieu cho tai khoan: '||i_acnt_no ||', stk_cd: '||i_stk_cd);
    raise_application_error(-20100,'Tai khoan ' || i_acnt_no || ' chua co phong toa cho ma ' || i_stk_cd);
  elsif sql%rowcount > 1 then
    vn.pxc_log_write('pss_rgt_tax_history','Co qua nhieu du lieu cho tai khoan: '||i_acnt_no ||', stk_cd: '||i_stk_cd);
    raise_application_error(-20100,'Tai khoan ' || i_acnt_no || ' co qua nhieu du lieu cho ma ' || i_stk_cd);
  end if;

  vn.pxc_log_write('pss_rgt_tax_history','Ket thuc xu ly cho tai khoan: ' || i_acnt_no || ', MaCK: ' || i_stk_cd);
end pss_rgt_tax_history;
/

