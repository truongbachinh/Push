create function fdl_get_prd_brkt_no(
    i_prd_no         in   varchar2,
    i_apy_dt         in   varchar2
)
return varchar2
/*
    Sample call:
        select
            vn.fdl_get_prd_brkt_no(
                'SPK11',        -- i_prd_no         in   varchar2,
                vwdate          -- i_apy_dt         in   varchar2
            ) a
        from dual;
*/

as
    t_proc_nm           varchar2(30)    := 'fdl_get_prd_brkt_no';
    t_err_msg           varchar2(500)   := null;

    t_vwdate            varchar2(8)     := vn.vwdate;
    t_apy_dt            varchar2(8)     := null;
    t_latest_prd_id     number          := 0;
    t_int_brkt_no       varchar2(5)     := null;
    o_ret               varchar2(5)     := null;

begin
    vn.pxc_log_write(t_proc_nm, '');
    vn.pxc_log_write(t_proc_nm, 'Start '                    || t_proc_nm        || ' for: '
                                || 'i_prd_no: '             || i_prd_no
                                || ', i_apy_dt: '           || i_apy_dt
                    );
    
    t_apy_dt    := nvl(i_apy_dt, t_vwdate);
    
    if i_prd_no is null then
      return null;
    end if;

    begin
        -- Lay setup gan nhat truoc i_apy_dt
        select distinct
            first_value(prd_id) over(partition by prd_no order by apy_dt desc, prd_id desc) latest_prd_id
        into
            t_latest_prd_id
        from vn.dlm30m00
        where prd_no        =  i_prd_no
        and active_stat     = 'Y'
        and apy_dt         <= t_apy_dt
        and apy_dt         <= expr_dt;

        -- Lay khung lai suat cua setup gan nhat
        select 
            int_brkt_no
        into 
            t_int_brkt_no
        from vn.dlm30m00
        where prd_id = t_latest_prd_id;
    exception
        when others then
            t_err_msg  := 'Error when getting bracket interest number'
                                || '. Error: '          || sqlcode || ' - '     || sqlerrm || '. ';
            vn.pxc_log_write(t_proc_nm, t_err_msg);
            --raise_application_error(-20100,t_err_msg)
            return null;
    end;

    o_ret := t_int_brkt_no;

    vn.pxc_log_write(t_proc_nm, 'End.');

    return o_ret;
end fdl_get_prd_brkt_no;
/

