create view VW_DRCWDM01 as
select a.BANK_ACC_NUM,a.BANK_CODE,a.BANK_ACC_NM,a.AUTO_PAY_Y_N,a.bank_type
from vn.DRCWDM01 a
where a.CLS_DTM ='30000101'
union
select b.BANK_ACC_NUM,b.BANK_CODE,b.BANK_ACC_NM,b.AUTO_PAY_Y_N,b.bank_type
from vn.DRCWDM10 b
where b.CLS_DTM ='30000101'
/

