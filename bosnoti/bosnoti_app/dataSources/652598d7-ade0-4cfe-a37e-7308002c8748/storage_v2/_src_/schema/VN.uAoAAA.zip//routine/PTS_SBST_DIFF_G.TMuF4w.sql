create procedure pts_sbst_diff_g
(
	i_acnt_no                   IN     VARCHAR2,
	i_sub_no					IN	   VARCHAR2,
	i_bank_cd                   IN     VARCHAR2,
    o_reuse_dpo                 IN OUT NUMBER,
    o_buy_sbst_diff             IN OUT NUMBER,
    o_sell_sbst_diff            IN OUT NUMBER,
    P_ErrCode              IN OUT NUMBER,
    P_ErrMsg               IN OUT VARCHAR2
) as

    t_acnt_no   VARCHAR2(10) := NULL;
    t_sub_no	VARCHAR2(2)	 := NULL;
    t_bank_cd   VARCHAR2(4) := NULL;
begin
    o_reuse_dpo                 := 0;
    o_buy_sbst_diff             := 0;
    o_sell_sbst_diff            := 0;
    P_ErrCode                   := 0;
    P_ErrMsg                    := ' ';

  vn.pxc_log_write('pts_acnt_prof_g',' i_acnt_no['||i_acnt_no||'] i_sub_no['|| i_sub_no || '] i_bank_cd['|| i_bank_cd ||']');

    t_bank_cd := i_bank_cd;


    begin
        select acnt_no,
        	   sub_no
        into t_acnt_no, t_sub_no
        from tso02m00
        where acnt_no = i_acnt_no
            and sub_no like trim ( i_sub_no )
            and bank_cd like t_bank_cd
            and rownum = 1
        ;
        EXCEPTION
        when  NO_DATA_FOUND  then
        		    P_ErrCode	 := 1403;
        		    P_ErrMsg  :=  'error - ' ||  to_char(sqlcode) ;
                when  OTHERS  then
                    P_ErrCode	 := sqlcode;
                    P_ErrMsg  :=  'error - ' ||  to_char(sqlcode) ;
                    raise_application_error (-20100, P_ErrMsg);

    end;
    begin
    	SELECT  SUM(GREATEST(TD_MGN_BUY_DIFF_AMT  + PD_MGN_BUY_DIFF_AMT  + PPD_MGN_BUY_DIFF_AMT  + PPPD_MGN_BUY_DIFF_AMT, 0)),
				SUM(GREATEST(TD_MGN_SELL_DIFF_AMT  + PD_MGN_SELL_DIFF_AMT  + PPD_MGN_SELL_DIFF_AMT  + PPPD_MGN_SELL_DIFF_AMT, 0)),
    	        SUM(GREATEST(REUSE_DPO , 0))
          INTO  o_buy_sbst_diff,
                o_sell_sbst_diff,
                o_reuse_dpo
          FROM VN.TSO02M00
          WHERE acnt_no = i_acnt_no
            and	sub_no like trim ( i_sub_no )
            and bank_cd like t_bank_cd

            ;

        EXCEPTION
               when  NO_DATA_FOUND  then
        		    P_ErrCode	 := 1403;
        		    P_ErrMsg  :=  'error - ' ||  to_char(sqlcode) ;
                when  OTHERS  then
                    P_ErrCode	 := sqlcode;
                    P_ErrMsg  :=  'error - ' ||  to_char(sqlcode) ;
                raise_application_error (-20100, P_ErrMsg);

    end;


end pts_sbst_diff_g;
/

