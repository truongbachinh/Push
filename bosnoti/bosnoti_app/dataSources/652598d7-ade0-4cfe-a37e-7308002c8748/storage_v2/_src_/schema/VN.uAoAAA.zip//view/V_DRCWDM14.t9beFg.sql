create view V_DRCWDM14 as
SELECT a.bank_fee_grd,
          a.fee_grd_nm,
          a.bank_code,
          a.fee_level,
          a.start_date,
          a.end_dt,
          a.work_mn,
          a.work_dtm,
          a.work_trm,
          a.cncl_yn
     FROM drcwdm14 a
    WHERE NVL (a.cncl_yn, 'N') <> 'Y'
/

