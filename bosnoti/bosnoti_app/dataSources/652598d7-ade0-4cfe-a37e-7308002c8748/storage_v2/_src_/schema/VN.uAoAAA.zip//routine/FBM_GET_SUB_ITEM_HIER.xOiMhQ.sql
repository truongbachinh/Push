create function fbm_get_sub_item_hier(
    i_tp            varchar2,       -- 1: mng_emp_no - emp_no    2: mng_emp_no - acnt   3: mng_dept_cd - dept_cd    4: dept_cd - mng_dept_cd
    i_parent_cd     varchar2,
    i_dt            varchar2,
    i_sub_cd        varchar2    default '%'
)
return tbl_hier_list
/* 
    select *
    from table  (vn.fbm_get_sub_item_hier(
                    '1',            -- i_tp             varchar2(15),
                    'dungnn',       -- i_mng_emp_no     varchar2(15),
                    vwdate,         -- i_dt             varchar2(8)
                    'hoangv'        -- i_sub_cd        varchar2
                    )
                )
    ;
*/
is
    t_ret           tbl_hier_list;
    t_acnt_no       vn.aaa01m00.acnt_no%type;
    t_sub_no        vn.aaa01m00.sub_no%type;
begin

    -- 1. Lay ds nhung nhan vien cap duoi cua nguoi quan ly
    if i_tp = '1' then
        select
            typ_hier_list(
                mng_emp_no,
                emp_no,
                lvl,
                pth,
                leaf
            )
        bulk collect into t_ret
        from (
            select 
                connect_by_root emp_no as mng_emp_no,
                emp_no,
                level lvl,
                ltrim(sys_connect_by_path(emp_no, '|'), '|') as pth,
                connect_by_isleaf as leaf
            from (
                select x1.emp_no, x5.mng_emp_no
                from vn.xca01m01 x1
                left join (
                    select r5.* 
                    from vn.rms05m00 r5           -- Ds nhan vien - quan ly
                    inner join vn.xca01m01 x11
                    on r5.mng_emp_no = x11.emp_no
                    and x11.biz_emp_tp <> '1'
                    and i_dt between r5.apy_dt and r5.expr_dt
                ) x5
                on x1.emp_no = x5.emp_no
                and i_dt between x5.apy_dt and x5.expr_dt
                and x1.biz_emp_tp <> '1'
                left join vn.xca01m01 x11
                on x5.emp_no = x11.emp_no
                and x11.biz_emp_tp <> '1'
                )
            connect by nocycle mng_emp_no = prior emp_no
        ) x
        where mng_emp_no like i_parent_cd
        and emp_no like i_sub_cd
        order by mng_emp_no, lvl
        ;

        return t_ret;
    end if;

    -- 2. Lay ds khach hang cap duoi cua nhan vien
    if i_tp = '2' then
        -- Lay thong tin account, sub truyen vao
        if(i_sub_cd <> '%') then
            t_acnt_no   := substr(i_sub_cd, 1, 10);
            t_sub_no    := substr(i_sub_cd, 11, 2);
        else
            t_acnt_no   := '%';
            t_sub_no    := '%';
        end if;

        -- 
        with user_user as (
            select *
            from (
                select
                    connect_by_root mng_emp_no as mng_emp_no,
                    emp_no,
                    level + 1 lvl,
                    ltrim(sys_connect_by_path(mng_emp_no, '->'), '->') || '->' || emp_no as pth,
                    connect_by_isleaf as leaf
                from (select *
                      from rms05m00 
                      where apy_dt <= i_dt
                      and expr_dt = '30000101'
                      ) r5
                start with mng_emp_no like i_parent_cd
                connect by nocycle r5.mng_emp_no = prior r5.emp_no

                union all

                select
                    x1.emp_no   mng_emp_no,
                    x1.emp_no   emp_no,
                    1           lvl,
                    x1.emp_no   pth,
                    0           leaf            -- Not correct for all cases
                from vn.xca01m01 x1
                where x1.emp_no like i_parent_cd
                )
            where mng_emp_no like i_parent_cd
        ),
        ret as(
            select
                mng_emp_no,
                bi.acnt_no || bi.sub_no acnt_sub_no,
                lvl,
                pth,
                leaf
            from user_user u                -- user - user
            inner join vn.bmi01m00 bi       -- user - acnt
            on u.emp_no = bi.emp_no
            where u.mng_emp_no like i_parent_cd
            and bi.acnt_no like t_acnt_no
            and bi.sub_no like t_sub_no
            and bi.mng_emp_regi_dt <= i_dt
            and bi.cls_dtm = to_date('30000101','yyyymmdd')
            order by lvl, bi.acnt_no, bi.sub_no
        )
        select
            typ_hier_list(
                mng_emp_no,
                acnt_sub_no,
                lvl,
                pth,
                leaf
            )
        bulk collect into t_ret
        from ret
        ;

        return t_ret;
    end if;

    -- 3. Lay ds phong ban cap duoi cua phong ban
    if i_tp = '3' then
        select
            typ_hier_list(
                mng_dept_cd,
                dept_cd,
                lvl,
                pth,
                leaf
            )
        bulk collect into t_ret
        from (
            select 
                dept_cd                                         dept_cd,
                level                                           lvl,
                connect_by_root dept_cd                         mng_dept_cd,
                ltrim(sys_connect_by_path(dept_cd, '.'), '.')   pth,
                connect_by_isleaf                               leaf
            from vn.xcc90m01
            connect by nocycle dept_mng_no = prior dept_cd
        ) x
        where mng_dept_cd like i_parent_cd
        and dept_cd like i_sub_cd
        and mng_dept_cd <> '000'
        order by mng_dept_cd, lvl
        ;

        return t_ret;
    end if;

    -- 4. Lay ds phong ban cap tren cua phong ban
    if i_tp = '4' then
        select
            typ_hier_list(
                mng_dept_cd,
                dept_cd,
                lvl,
                pth,
                leaf
            )
        bulk collect into t_ret
        from (
            select
                connect_by_root dept_mng_no                         mng_dept_cd,
                dept_cd                                             dept_cd,
                level                                               lvl,
                ltrim(sys_connect_by_path(dept_mng_no, '.'), '.')   pth,
                connect_by_isleaf                                   leaf
            from vn.xcc90m01
            connect by nocycle dept_mng_no = prior dept_cd
        ) x
        where dept_cd like i_parent_cd
        and mng_dept_cd like i_sub_cd
        and dept_cd <> '000'
        order by dept_cd, lvl
        ;

        return t_ret;
    end if;
end fbm_get_sub_item_hier;
/

