create procedure    pts_bat_tso01h10_ins (
    i_work_dt       in      varchar2,       -- date(yyyymmdd)
	o_err_code      in      number,         -- error code(0:SUCCESS)
	o_err_msg       in      varchar2,       -- error message
	o_proc_cnt      out     number          -- proc data count
) as

t_err_code      number        := o_err_code;
t_err_msg       varchar2(600) := rtrim(o_err_msg);
t_chk           varchar2(1);
cnt             number;
exp_error       exception;

/*!
    \file     pts_bat_tso10h10_ins
	\brief    tso01m10 select, tso01h10 insert

	\section intro Program Information
		- Program Name              : pts_bat_tso01h10_ins
		- Service Name              :
		- Related Client Program- Client Program ID :
		- Related Tables            : tso01m10, tso01h10
		- Dev. Date                 : 2007/11/27
		- Developer                 : ejlee
		- Business Logic Desc.      :
		- Latest Modification Date  :

	\section history Program Modification History
		- 1.0  2007/11/27

	\section hardcoding Hard-Coding List

	\section info Additional Reference Comments
*/

begin

	t_err_code := 0;
	t_err_msg  := 'SUCCESS';
	t_chk      := 'Y';
	o_proc_cnt := 0;
	cnt        := 0;

	-- 1. ?? ??ü?????u Funüu

	if t_chk = 'N' then
		t_err_code := -1;
	    t_err_msg  := '?? ??ü???????? ü??? ? ó?????ÿ?';
		raise_application_error(-20100,'[pts_bat_tso01h10_ins] ' || t_err_msg);

	else
		select 	count(*)
		into	cnt
		from	tso01m10;

		if cnt > 0 then
			delete  tso01h10
					where   stk_ord_dt = i_work_dt;
	        for  c1  in (

			    select  bnh_cd         ,
					    ord_no         ,
					    ord_mth_no     ,
					    acnt_no        ,
					    sub_no		   ,
					    stk_cd         ,
					    mth_qty        ,
					    mth_pri        ,
					    mth_time       ,
					    if_seq_no      ,
					    dat_cd         ,
					    work_mn        ,
					    work_dtm       ,
					    work_trm       ,
					    bank_cd        ,
					    del_yn		   ,
					    bank_cnct_tp   ,
					    rgt_tax_qty    ,
					    rgt_tax_calc_yn
				  from  vn.tso01m10

	             ) loop

				 cnt := cnt + 1;

				 insert into vn.tso01h10
				 (      stk_ord_dt     ,
			            bnh_cd         ,
					    ord_no         ,
					    ord_mth_no     ,
					    acnt_no        ,
					    sub_no		   ,
					    stk_cd         ,
					    mth_qty        ,
					    mth_pri        ,
					    mth_time       ,
					    work_mn        ,
					    work_dtm       ,
					    work_trm       ,
					    bank_cd        ,
					    del_yn		   ,
					    bank_cnct_tp   ,
					    rgt_tax_qty    ,
					    rgt_tax_calc_yn
	            ) values (
				        i_work_dt      ,
			            c1.bnh_cd      ,
					    c1.ord_no      ,
					    c1.ord_mth_no  ,
					    c1.acnt_no     ,
					    c1.sub_no	   ,
					    c1.stk_cd      ,
					    c1.mth_qty     ,
					    c1.mth_pri     ,
					    c1.mth_time    ,
					    c1.work_mn     ,
					    c1.work_dtm    ,
					    c1.work_trm    ,
					    c1.bank_cd     ,
					    c1.del_yn	   ,
					    c1.bank_cnct_tp,
					    c1.rgt_tax_qty ,
					    c1.rgt_tax_calc_yn
	            );

	        end loop;
		end if;
	end if;

    o_proc_cnt := cnt;

	exception when  exp_error then
		t_err_code := sqlcode;
		t_err_msg  := sqlerrm;
		raise_application_error(-20100,'[pts_bat_tso01h10_ins] ' || t_err_msg);

end pts_bat_tso01h10_ins;
/

