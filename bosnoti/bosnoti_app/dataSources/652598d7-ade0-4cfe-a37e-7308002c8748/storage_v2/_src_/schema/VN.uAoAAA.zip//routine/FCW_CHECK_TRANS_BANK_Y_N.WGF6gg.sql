create function fcw_check_trans_bank_y_n
(
	i_acnt_no		in		varchar2,
  i_sub_no    in    varchar2,
  i_bank_cd   in    varchar2,
  i_dt        in    varchar2
) return varchar2 as

	o_acnt_pay	varchar2(30);
  o_cash_pay	number;
  o_acnt_bank	varchar2(30);
  o_cash_bank	number;
  o_acnt_order varchar2(30);
  o_cash_order number;
  
  

/* ===========================================
	-- Program ID 		: 	fcw_check_trans_bank_y_n
	-- Date of Program	: 	01/08/2016
	-- Programmer		:	hieu.dt
	-- Description 		:
			input  :  Account no,sub_no,i_dt
			return :  cash trans to bank balance Y  N
   =========================================== */

begin
  o_cash_pay     := 0;

o_cash_bank    := 0;
o_cash_order   := 0;

	begin
	select a.acnt_no_dsc10m00,
         a.amt_dsc10m00,
         b.acnt_no_cww02m10,
         b.amt_cww02m10,
         c.acnt_no_tso02m00,
         c.amt_tso02m00
         into 
         o_acnt_pay,
         o_cash_pay,
         o_acnt_bank,
         o_cash_bank,
         o_acnt_order,
         o_cash_order
  from(
         select acnt_no acnt_no_dsc10m00, 
         sum (t.adj_amt) amt_dsc10m00 
  from dsc10m00 t
       where mth_dt = i_dt
             and t.job_tp = '1'
             and t.sb_tp = '2' 
             and bank_cd = i_bank_cd
             and sub_no = '00'
             and t.scrt_err_cd = '2475'
        group by acnt_no 
        order by acnt_no) a,
  (select acnt_no acnt_no_cww02m10, 
          sum(proof) amt_cww02m10 
          from cww02m10 t
               where trd_dt = i_dt
               and valid_YN = 'Y'
               and acnt_no in (select acnt_no from dsc10m00 t
          where mth_dt = i_dt
                and t.job_tp = '1'
                and t.sb_tp = '2' 
                and bank_cd = i_bank_cd
                and t.scrt_err_cd = '2475')
                and sub_no = '00'                
         group by acnt_no                 
         order by acnt_no) b,
(select acnt_no acnt_no_tso02m00, 
        sum(t.td_cash_prof_amt) amt_tso02m00 
        from tso02m00 t
        where acnt_no in (
              select acnt_no from dsc10m00 t
                     where mth_dt = i_dt
                     and t.job_tp = '1'
                     and t.sb_tp = '2' 
                     and bank_cd = i_bank_cd
                     and t.scrt_err_cd = '2475')
                     and sub_no = '00'                
          group by acnt_no        
          order by acnt_no) c
          where a.acnt_no_dsc10m00 = b.acnt_no_cww02m10
          and a.acnt_no_dsc10m00 = c.acnt_no_tso02m00
          and a.acnt_no_dsc10m00 = i_acnt_no;
if  o_cash_pay = o_cash_bank and  o_cash_bank = o_cash_order then
  return 'Y';
  else
    return 'N';
    end if;
	exception
	when	 no_data_found then
		return 	'N';
	end;


end ;
/

