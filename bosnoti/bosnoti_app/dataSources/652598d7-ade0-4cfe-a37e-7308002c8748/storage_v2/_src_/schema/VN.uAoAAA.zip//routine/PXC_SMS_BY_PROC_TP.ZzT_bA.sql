create PROCEDURE    pxc_sms_by_proc_tp(
    i_send_dt       VARCHAR2,
    i_proc_tp       VARCHAR2,
    i_work_tp_a     VARCHAR2,
    i_work_tp_b     VARCHAR2,
    i_sms_msg       VARCHAR2,
    i_work_mn       VARCHAR2,
    i_work_trm      VARCHAR2
)
AS
    -- Declare variable
    t_obj_nm            VARCHAR2(50)    := 'pxc_sms_by_proc_tp';
    t_com_phone         VARCHAR2(15);
    t_recv_phone_no     VARCHAR2(50);
    t_snd_date          VARCHAR2(20);
    t_work_tp_a         VARCHAR2(10);
    t_work_tp_b         VARCHAR2(10);

    t_err_msg           VARCHAR2(4000);

BEGIN
    vn.pxc_log_write(t_obj_nm, 'Start sending email for i_proc_tp: ' || i_proc_tp);

    -- Validate input parameter
    IF(i_proc_tp IS NULL OR i_sms_msg IS NULL) THEN
        t_err_msg := 'Input parameter is incorrect: i_proc_tp or i_sms_msg is null';
        vn.pxc_log_write(t_obj_nm, t_err_msg);
        raise_application_error(-20100, t_err_msg);
    END IF;

    -- Set value for NULL parameters
    SELECT 
        NVL2(i_send_dt, TO_CHAR(sysdate, 'YYYYMMDD'), i_send_dt)    t_snd_date,
        NVL2(i_work_tp_a, '999', i_work_tp_a)                       t_work_tp_a,
        NVL2(i_work_tp_b, '999', i_work_tp_b)                       t_work_tp_b
    INTO 
        t_snd_date,
        t_work_tp_a,
        t_work_tp_b
    FROM DUAL;

    -- Get company information
    SELECT TRIM(com_phone)
    INTO t_com_phone
    FROM vn.xcc99m00
    WHERE test_yn = 'R';

    -- Get all mobile phone numbers of people who are in charge of this proc_tp
    FOR c1 IN(
        SELECT 
            rtrim(decode(substr(trim(x9.mobile),1, 1), '0', '84'||substr(trim(x9.mobile),2),  '84'||trim(x9.mobile))) recv_phone_no
        FROM vn.xca99m96 x6
        INNER JOIN vn.xca99m99 x9
        ON x6.jv_cd = x9.jv_cd
        WHERE x6.proc_tp = i_proc_tp
        AND x9.status = '1'
    )
    LOOP
        vn.pxc_log_write(t_obj_nm, 'Sending email for phone number: ' || c1.recv_phone_no);
        -- Start sending sms
        BEGIN
            vn.pxc_sms_ins(
                t_snd_date,             -- i_send_dt          in varchar2,                 
                c1.recv_phone_no,       -- i_recv_phone_no    in varchar2,                 
                t_com_phone,            -- i_send_phone_no    in varchar2,                 
                t_work_tp_a,            -- i_func_cd          in varchar2,                 
                'V',                    -- i_msg_lang         in varchar2,                 
                i_sms_msg,              -- i_sms_msg          in varchar2,                 
                i_work_mn,              -- i_work_mn          in varchar2,                 
                i_work_trm,             -- i_work_trm         in varchar2,                 
                null,                   -- i_acnt_no          in varchar2      default null
                null,                   -- i_sub_no           in varchar2      default null
                '2'
            );

        EXCEPTION
            WHEN OTHERS THEN
                t_err_msg := 'Error when calling pxc_sms_ins';
                vn.pxc_log_write(t_obj_nm, t_err_msg);
                raise_application_error(-20100, t_err_msg);
        END;

    END LOOP;

    vn.pxc_log_write(t_obj_nm, 'Complete sending email for i_proc_tp: ' || i_proc_tp);

END pxc_sms_by_proc_tp;
/

