create FUNCTION    fdl_get_item_tot_lnd_limit(
    i_item_tp   VARCHAR2,
    i_item_cd   VARCHAR2,
    i_day_tp    VARCHAR2)
RETURN NUMBER
AS
    
    -- Declare variable
    t_item_tot_lnd_limit    NUMBER      := 0;
    t_detail_chk            VARCHAR2(2) := 'Y';
    t_vwdate                VARCHAR2(8) := vn.vwdate;

BEGIN

    /* Check if existing detail data for product/source/margin account group */
    t_detail_chk := vn.fdl_item_detail_chk(
                        i_item_tp,
                        i_item_cd,
                        t_vwdate
                    );

    /* Only get loan limit when existing detail data */
    IF(t_detail_chk = 'Y') THEN
        BEGIN
            SELECT NVL(a.tot_lnd_lmit,0)
            INTO t_item_tot_lnd_limit
            FROM vn.dlm00m01 a
            WHERE a.item_tp     = i_item_tp
              AND a.item_cd     = i_item_cd
              AND a.active_stat = 'Y';

        EXCEPTION
            WHEN OTHERS THEN
                t_item_tot_lnd_limit := 0;
        END;
    END IF;

    RETURN t_item_tot_lnd_limit;

END;    -- END fdl_get_item_tot_lnd_limit
/

