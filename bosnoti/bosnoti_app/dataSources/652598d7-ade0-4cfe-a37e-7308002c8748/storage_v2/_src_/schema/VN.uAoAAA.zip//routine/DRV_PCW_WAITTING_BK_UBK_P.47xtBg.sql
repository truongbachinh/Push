create PROCEDURE drv_pcw_waitting_bk_ubk_p
(
  i_block_tp        in        varchar2,
  i_trd_dt          in        varchar2,
  i_acnt_no         in        varchar2,
  i_sub_no          in        varchar2,
  i_cash            in        number,
  i_mdm_tp          in        varchar2,
  i_work_mn         in        varchar2,
  i_work_trm        in        varchar2,

  o_outq_dpo_bk     out       number

)
AS
  t_proc_nm                   varchar2(100);
  t_err_txt                   varchar2(200);
  t_err_msg                   varchar2(500);
  t_err_cd                    number;
  t_rtn_val                   char(1);

  t_mdm_bnh                   varchar2(3);
  t_proc_brch_cd              varchar2(3);
  t_proc_agnc_brch            varchar2(2);


  ts_acnt_stat                varchar2(1);
  ts_acnt_mng_bnh             varchar2(3);
  ts_agnc_brch                varchar2(2);
  ts_bank_yn                  varchar2(1);


  t_work_dtm                  date;

  tn_outq_dpo_bk_prerm        number := 0;
  tn_outq_dpo_bk_nowrm        number := 0;


BEGIN

    t_proc_nm   := 'drv_pcw_waitting_bk_ubk_p :';
  t_work_dtm  := SYSDATE;

  vn.pxc_log_write('drv_pcw_waitting_bk_ubk_p','start');
  vn.pxc_log_write('drv_pcw_waitting_bk_ubk_p', i_acnt_no || ',' || i_sub_no ||',' || i_block_tp );
  vn.pxc_log_write('drv_pcw_waitting_bk_ubk_p', 'AMT : ' || ',' || i_cash );

    if  i_cash  is  null  or  i_cash  < 0 then

        t_err_txt  :=  t_proc_nm  ||  'i_cash is Error ';
    t_err_msg := vn.fxc_get_err_msg('V','2707');
    raise_application_error(-20100,t_err_msg||t_err_txt);

    end if;




/*============================================================================*/
/* °èÁÂ_¿øÀå ÀÚ·áÃëµæ                                                         */
/*============================================================================*/

    BEGIN
        select  acnt_stat
             ,  acnt_mng_bnh
             ,  agnc_brch
       ,  nvl(bank_cnt_yn,'N')
          into  ts_acnt_stat
             ,  ts_acnt_mng_bnh
             ,  ts_agnc_brch
       ,  ts_bank_yn
          from  vn.aaa01m00
         where  acnt_no  =  i_acnt_no
       and  sub_no  = i_sub_no;
    EXCEPTION
        WHEN  OTHERS         THEN
            t_err_txt  :=  t_proc_nm
                   ||  'Select aaa01m00 Error :'
                   ||  to_char(sqlcode);
      t_err_msg := vn.fxc_get_err_msg('V','2001');
      raise_application_error(-20100,t_err_msg||t_err_txt);
    END;

  if ts_bank_yn ='Y' then
    t_err_txt  :=  t_proc_nm
          || ' bank account ' ;
    t_err_msg := vn.fxc_get_err_msg('V','2421');
     raise_application_error(-20100,t_err_msg||t_err_txt);
    end if ;


/*============================================================================*/
/* Ã³¸®ÁöÁ¡ Á¶È¸                                                              */
/*============================================================================*/


  if i_work_mn in ('DAILY','BATCH') or i_mdm_tp <> '00' then

    t_proc_brch_cd := ts_acnt_mng_bnh;
    t_proc_agnc_brch := ts_agnc_brch;

  else

      BEGIN
          select  brch_cd,
                  agnc_brch
            into  t_proc_brch_cd,
                  t_proc_agnc_brch
            from  vn.xca01m01
            where emp_no = i_work_mn
            ;
      EXCEPTION
          WHEN  OTHERS         THEN
              t_err_txt  :=  t_proc_nm
                     ||  'Select xca01m01 Error :'
                     ||  to_char(sqlcode);
        t_err_msg := vn.fxc_get_err_msg('V','2819');
        raise_application_error(-20100,t_err_msg||t_err_txt);
      END;

  end if;

    if  ts_acnt_stat  NOT IN ('1') then

        if  ts_acnt_stat  =  '2' then

            t_err_txt  :=  t_proc_nm  ||  'Account is closed ';
      t_err_msg := vn.fxc_get_err_msg('V','2023');
      raise_application_error(-20100,t_err_msg||t_err_txt);

        else
            t_err_txt  :=  t_proc_nm  ||  'Account status is '
                                      ||  '(' || ts_acnt_stat || ')';
      t_err_msg := vn.fxc_get_err_msg('V','2014');
      raise_application_error(-20100,t_err_msg||t_err_txt);
        end if;

    end if;

 if i_sub_no <> '80' then
     BEGIN
        select outq_dpo_bk
        into tn_outq_dpo_bk_prerm
        from vn.CWD01M00
           where acnt_no = i_acnt_no
       and sub_no  = i_sub_no ;
        EXCEPTION
          WHEN OTHERS        THEN
            t_err_txt := t_proc_nm
             || 'CWD01M00_err_1: '
             || to_char(sqlcode);
              t_err_msg := vn.fxc_get_err_msg('V','2704');
            raise_application_error(-20100,t_err_msg||t_err_txt);

        END;

vn.pxc_log_write('drv_pcw_waitting_bk_ubk_p', 'outq_dpo_bk - '||tn_outq_dpo_bk_prerm);
vn.pxc_log_write('drv_pcw_waitting_bk_ubk_p', 'outq_dpo_bk text'||t_err_txt);


      /* block tp  '01' : block   '02' : unblock */

      if i_block_tp = '01' then

           tn_outq_dpo_bk_nowrm := tn_outq_dpo_bk_prerm + i_cash;

        else

           tn_outq_dpo_bk_nowrm := greatest(tn_outq_dpo_bk_prerm - i_cash,0);

        end if;

        vn.pxc_log_write('drv_pcw_waitting_bk_ubk_p', tn_outq_dpo_bk_nowrm);

      BEGIN
        update vn.CWD01M00
         set outq_dpo_bk = tn_outq_dpo_bk_nowrm
           ,work_mn    = i_work_mn
           ,work_dtm   = sysdate
           ,work_trm   = i_work_trm
           where acnt_no = i_acnt_no
       and sub_no = i_sub_no  ;
        EXCEPTION
          WHEN OTHERS        THEN
            t_err_txt := t_proc_nm
               || 'CWD01M00_err_2: '
                 || to_char(sqlcode);
            t_err_msg := vn.fxc_get_err_msg('V','1234');
            vn.pxc_log_write('drv_pcw_waitting_bk_ubk_p', 'finish error');
            raise_application_error(-20100,t_err_msg||t_err_txt);

      END;
else
  BEGIN
        select outq_dpo_bk
        into tn_outq_dpo_bk_prerm
        from vn.DRCWDM00
           where acnt_no = i_acnt_no
       and sub_no  = i_sub_no ;
        EXCEPTION
          WHEN OTHERS        THEN
            t_err_txt := t_proc_nm
             || 'DRCWDM00_err_1: '
             || to_char(sqlcode);
              t_err_msg := vn.fxc_get_err_msg('V','2704');
            raise_application_error(-20100,t_err_msg||t_err_txt);

        END;

vn.pxc_log_write('drv_pcw_waitting_bk_ubk_p', 'outq_dpo_bk - '||tn_outq_dpo_bk_prerm);
vn.pxc_log_write('drv_pcw_waitting_bk_ubk_p', 'outq_dpo_bk text'||t_err_txt);


      /* block tp  '01' : block   '02' : unblock */

      if i_block_tp = '01' then

           tn_outq_dpo_bk_nowrm := tn_outq_dpo_bk_prerm + i_cash;

        else

           tn_outq_dpo_bk_nowrm := greatest(tn_outq_dpo_bk_prerm - i_cash,0);

        end if;

        vn.pxc_log_write('drv_pcw_waitting_bk_ubk_p', tn_outq_dpo_bk_nowrm);

      BEGIN
        update vn.DRCWDM00
         set outq_dpo_bk = tn_outq_dpo_bk_nowrm
           ,work_mn    = i_work_mn
           ,work_dtm   = sysdate
           ,work_trm   = i_work_trm
           where acnt_no = i_acnt_no
       and sub_no = i_sub_no  ;
        EXCEPTION
          WHEN OTHERS        THEN
            t_err_txt := t_proc_nm
               || 'DRCWDM00_err_2: '
                 || to_char(sqlcode);
            t_err_msg := vn.fxc_get_err_msg('V','1234');
            vn.pxc_log_write('drv_pcw_waitting_bk_ubk_p', 'finish error');
            raise_application_error(-20100,t_err_msg||t_err_txt);

      END;
  end if;
      o_outq_dpo_bk := tn_outq_dpo_bk_nowrm;
vn.pxc_log_write('drv_pcw_waitting_bk_ubk_p', 'ok finish');
END drv_pcw_waitting_bk_ubk_p;
/

