create PROCEDURE pss_outbil_aprv_p_test
(
    is_proc_dt			in	varchar2,
    is_acnt_no			in	varchar2,
    is_sub_no			in	varchar2,
    is_seq_no			in	varchar2,
    is_std_inq_dt		in	varchar2, 			--approving date
    is_work_mn			in	varchar2,
    is_work_trm			in	varchar2,
    is_work_bnh			in	varchar2,
    is_dept_no2			in	varchar2,
    is_trd_amt          in  number,
    is_cmsn             in  number,
    is_sb_tax           in  number,
    is_adj_amt          in  number,
    os_end_yn			out	varchar2,
    os_err_msg			out	varchar2,
    os_inq_dt			out	varchar2
) AS

    tn_bil_prerm_qty		number	:= 0;
    tn_tot_bil_prerm_qty	number	:= 0;
    tn_tot_bil_prerm_qty_h	number	:= 0;

    tn_qty				    number 	:= 0;
    tn_sb_lmt_qty		    number 	:= 0;
	tn_delay_qty		    number 	:= 0;
    tn_inq_pri              number 	:= 0;
    tn_unit_pri             number 	:= 0;
    tn_trd_seq_no		    number 	:= 0;
    tn_tot_trd_seq_no	    number 	:= 0;
    tn_sb_qty			    number 	:= 0;
    tn_own_qty			    number 	:= 0;

    tot_cnt				    number	:=0;
    td_loop_cnt			    number	:=0;

    ts_stk_tp			    varchar2(2)		:= '';
    ts_step				    varchar2(10)	:= '';
    ts_wdate			    varchar2(8)		:= '';
    ts_buy_dt			    varchar2(8)		:= '';
    ts_stk_cd			    varchar2(20)	:= '';
    ts_rmrk_cd			    varchar2(3)		:= '';
    ts_anth_cd			    varchar2(3)		:= '';
    ts_anth_acnt_no			varchar2(20)	:= '';
    ts_cnte				    varchar2(200)	:= '';
    ts_end_yn			    varchar2(200)	:= 'N';
    
    ts_date				    varchar(8)		:= '';

    ts_acnt_tp              varchar(2)      := '';
    ts_trd_tp			    varchar2(2)	    := null;
    ts_rgt_chk              varchar2(2)	    := null;

    vn_count                number   		:= 0;
    o_cnt                   number   		:= 0;

    t_rtn_val               varchar2(1)     := null ;
    t_err_txt               varchar2(200)   := null ;
    t_err_msg               varchar2(200)   := null ;

    ERR_RTN					EXCEPTION;

begin

  os_end_yn := '';
  os_err_msg := '';
  os_inq_dt := '';

  SELECT VN.VWDATE()
    INTO ts_wdate
    FROM DUAL;

  vn.pxc_log_write('pss_outbil_aprv_p','acnt_no '||is_acnt_no ||' is_proc_dt '|| is_proc_dt ||' seq_no '||is_seq_no);

 /*** check closing ***/
 vn.pxc_log_write('pss_outbil_aprv_p', is_work_mn);
 vn.pxc_log_write('pss_outbil_aprv_p', is_sub_no);

 t_rtn_val := 'Y';

 if  is_work_mn  not in ('DAILY','BATCH') then

        vn.pbm_cls_yn_q(  vn.vhdate
                       ,  vn.fbm_emp_bnh_q(  is_work_mn)
                       ,  vn.faa_acnt_bnh_cd_g( '0',is_acnt_no, is_sub_no)
                       , '1'
                       ,  t_rtn_val
                       ,  t_err_txt
                       );

        if  t_rtn_val  !=  'N' then
            vn.pxc_log_write('pss_outbil_aprv_p', 'check3');
            t_err_msg := vn.fxc_get_err_msg('V','2716');
            raise_application_error(-20100,t_err_msg||t_err_txt);
        end if;

 end if;

 vn.pxc_log_write('pss_outbil_aprv_p', 'check1');

 ts_step := '1';

 if is_std_inq_dt <  is_proc_dt or is_std_inq_dt > ts_wdate  then
	  os_end_yn := 'N';
	  os_err_msg := '2031';
	  RAISE  ERR_RTN;
 end if ;

 ts_step := '2';

 vn.pxc_log_write('pss_outbil_aprv_p', 'check5');

   SELECT	trim(stk_cd)
           ,trim(rmrk_cd)
	       ,trim(trd_tp)
           ,nvl(qty, 0)
           ,nvl(sb_lmt_qty, 0)
		   ,nvl(delay_qty, 0)
           ,trim(anth_cd)
           ,trim(anth_acnt_no)
           ,trim(cnte)
           ,trim(buy_dt)
           ,nvl(end_yn, 'N')
     INTO   ts_stk_cd
           ,ts_rmrk_cd
	       ,ts_trd_tp
           ,tn_qty
           ,tn_sb_lmt_qty
		   ,tn_delay_qty
           ,ts_anth_cd
           ,ts_anth_acnt_no
           ,ts_cnte
           ,ts_buy_dt
           ,ts_end_yn
     FROM	VN.SSB05M00
    WHERE	PROC_DT = trim(is_proc_dt)
      AND	ACNT_NO = trim(is_acnt_no)
	  AND   SUB_NO  = trim(is_sub_no)
      AND	SEQ_NO  = to_number(is_seq_no);

  vn.pxc_log_write('pss_outbil_aprv_p', 'check6');

  IF ts_end_yn = 'Y' THEN
		os_end_yn := 'N';
		os_err_msg := '2256';
		RAISE  ERR_RTN;
	END IF;
  vn.pxc_log_write('pss_outbil_aprv_p', 'check61');
  IF tn_qty = 0 AND tn_sb_lmt_qty = 0 and tn_delay_qty = 0 THEN
    os_end_yn := 'N';
    os_err_msg := '2205';
    RAISE ERR_RTN;
  END IF;
vn.pxc_log_write('pss_outbil_aprv_p', 'check62');
  /*check change rights */
  select  vn.fsr_chage_rgt_p( ts_stk_cd , ts_wdate)
    into  ts_rgt_chk
    from dual;

  vn.pxc_log_write('pss_outbil_aprv_p', 'check7');
 /* If is_acnt_no <> '068C200461' then
    if  ts_rgt_chk = 'Y' then
        os_end_yn := 'N';
        os_err_msg := '2029';
        RAISE ERR_RTN;
    end if ;
  End if;*/
/***** trd_tp *************************************/

  ts_acnt_tp :=  vn.faa_get_acnt_tp( is_acnt_no, is_sub_no ) ;


  if ts_rmrk_cd in ('603','604') then

     if ts_acnt_tp    = '1' then  --  custodian
        ts_trd_tp :=  '51' ;
     elsif ts_acnt_tp = '2' then  -- bank_connect
        ts_trd_tp :=  '53' ;
     elsif ts_acnt_tp = '3' then  -- non-custodian
        ts_trd_tp :=  '55' ;
     end if ;

-- ts_trd_tp := '31' ;
  else

     if ts_acnt_tp    = '1' then  --  custodian
		ts_trd_tp :=  '21';
     elsif ts_acnt_tp = '2' then  -- bank_connect
        ts_trd_tp :=  '23' ;
     elsif ts_acnt_tp = '3' then  -- non-custodian
        ts_trd_tp :=  '25' ;
     end if ;

--     ts_trd_tp := '21' ;
  end if ;


  vn.pxc_log_write('pss_outbil_aprv_p', 'check2');
/** Get Trd_Seq_No  **/

  ts_step := '3';

  if  is_std_inq_dt =  ts_wdate then
	pxc_log_write('pss_outbil_aprv_p','Get trd_seq in  pxc_seq ' );
    vn.pxc_psb_seq_cret_p (is_acnt_no, is_sub_no,  ts_wdate, tn_trd_seq_no, tn_tot_trd_seq_no);

  else
  vn.pxc_log_write('pss_outbil_aprv_p', 'check3');
    begin
	  select nvl(max(trd_seq_no),0)
	     into tn_trd_seq_no
	     from vn.aaa10m00
	    where acnt_no = is_acnt_no
		  and sub_no = is_sub_no
	      and trd_dt = is_std_inq_dt;
    exception
      	when NO_DATA_FOUND then
	      tn_trd_seq_no := 0 ;
    end;

	tn_trd_seq_no := tn_trd_seq_no + 1;

  end if ;

  pxc_log_write('pss_outbil_aprv_p','trd_seq_no :' || tn_trd_seq_no );

  ts_step := '4';

  SELECT	trunc(nvl(book_amt, 0)/nvl(own_qty, 0)), nvl(own_qty, 0), stk_tp , (nvl(book_amt, 0)/nvl(own_qty, 0))
    INTO	tn_inq_pri, tn_bil_prerm_qty, ts_stk_tp  , tn_unit_pri
    FROM	vn.ssb01m00
   WHERE	acnt_no = is_acnt_no
	 AND    sub_no = is_sub_no
     AND	stk_cd = ts_stk_cd;

/** Getting balance of approving date(is_std_inq_dt) **/

   ts_step := 5 ;

   if  is_std_inq_dt <  ts_wdate and is_acnt_no <> '068C606869' then

     BEGIN
       SELECT	nvl(own_qty, 0)
         INTO	tn_bil_prerm_qty
         FROM	vn.ssb01h00
        WHERE	acnt_no = is_acnt_no
		  AND   sub_no  = is_sub_no
          AND	stk_cd = ts_stk_cd
          AND	rgt_std_dt = is_std_inq_dt;
     EXCEPTION
     	 WHEN NO_DATA_FOUND	THEN
           tn_bil_prerm_qty := 0;
     END;

	 tn_tot_bil_prerm_qty := vn.fss_get_tot_prerm_qty_h(  is_acnt_no, ts_stk_cd, is_std_inq_dt);

   else
	 BEGIN
	   SELECT nvl(own_qty,0)
		 INTO tn_bil_prerm_qty
         FROM vn.ssb01m00
        WHERE acnt_no = is_acnt_no
		  AND sub_no  = is_sub_no
		  AND stk_cd = ts_stk_cd ;
     EXCEPTION
		 WHEN NO_DATA_FOUND THEN
			tn_bil_prerm_qty := 0;
     END;

	 tn_tot_bil_prerm_qty := vn.fss_get_tot_prerm_qty( is_acnt_no, ts_stk_cd);

   end if;

/* Possible export amount */

   ts_step := 6 ;

   IF tn_bil_prerm_qty  <  (tn_qty + tn_sb_lmt_qty + tn_delay_qty)	THEN
      os_end_yn := 'N';
      os_err_msg := '2205';
      RAISE ERR_RTN;
   END IF;

   pxc_log_write('pss_outbil_aprv_p','tn_bil_prerm_qty :' || tn_bil_prerm_qty );

   INSERT INTO vn.aaa10m00 (  acnt_no			--
                            ,sub_no				--
                            ,trd_dt				--
                            ,tot_trd_seq_no			--
                            ,trd_seq_no			--
                            ,trd_tp				--
                            ,rmrk_cd			--
                            ,mdm_tp			--
                            ,trd_mdm_tp			--
                            ,cncl_yn			--
                            ,org_trd_no			--
                            ,trd_amt			-- odd
                            ,cmsn				-- odd
                            ,adj_amt			-- odd
                            ,sb_tax             -- odd
                            ,dpo_prerm			--
                            ,dpo_nowrm			--
                            ,stk_cd				--
                            ,stk_nm				--
                            ,sb_pri				--
                            ,sb_qty				--
                            ,bil_prerm_qty		--
                            ,bil_nowrm_qty		--
                            ,tot_bil_prerm		--
                            ,tot_bil_nowrm		--
                            ,book_amt			--
                            ,stk_tp				--
                            ,mth_dt				-- odd
                            ,lnd_tp				--
                            ,lnd_dt				--
                            ,lnd_int			--
                            ,agnt_yn			--
                            ,acnt_mng_bnh		--
                            ,work_bnh			--
                            ,work_mn			--
                            ,work_dtm			--
                            ,work_trm			--
                            ,anth_cd
                            ,anth_acnt_no
                            ,agnc_brch
                            ,proc_agnc_brch
                            ,cnte
                            ,cnfm_dt
           )	VALUES	(	 is_acnt_no				-- acnt_no
                ,is_sub_no				-- trd_dt
                ,is_std_inq_dt				-- trd_dt
                ,tn_tot_trd_seq_no			-- trd_seq_no
                ,tn_trd_seq_no			-- trd_seq_no
                ,ts_trd_tp				-- trd_tp
                ,ts_rmrk_cd 			-- rmrk_cd
                ,'00'					-- mdm_tp
                ,'99'					-- trd_mdm_tp
                ,'N'					-- cncl_yn
                ,0						-- org_trd_no
                ,is_trd_amt	    		-- trd_amt
                ,is_cmsn				-- cmsn
                ,is_adj_amt				-- adj_amt
                ,is_sb_tax              -- sb_tax
                ,0						-- dpo_prerm
                ,0						-- dpo_nowrm
                ,ts_stk_cd				-- stk_cd
                ,VN.fss_get_stk_nm( ts_stk_cd)			    -- stk_nm
                ,tn_inq_pri				                            -- sb_pri
                ,(tn_qty + tn_sb_lmt_qty + tn_delay_qty)            -- sb_qty
                ,tn_bil_prerm_qty		                            -- bil_prerm_qty
                ,tn_bil_prerm_qty - (tn_qty + tn_sb_lmt_qty + tn_delay_qty)		-- bil_nowrm_qty
                ,tn_tot_bil_prerm_qty		                        -- bil_prerm_qty
                ,tn_tot_bil_prerm_qty - (tn_qty + tn_sb_lmt_qty + tn_delay_qty)	-- bil_prerm_qty
                ,(tn_qty + tn_sb_lmt_qty + tn_delay_qty) * tn_inq_pri				-- book_amt
                ,ts_stk_tp				                            -- stk_tp
                ,ts_buy_dt	    		                            -- mth_dt
                ,null					-- lnd_tp
                ,null                   -- lnd_dt
                ,null                   -- lnd_int
                ,'N'					-- agnt_yn
                ,faa_acnt_bnh_cd_g( '0', is_acnt_no, is_sub_no)					-- acnt_mng_bnh
                ,is_work_bnh			-- work_bnh
                ,is_work_mn				-- work_mn
                ,sysdate				-- work_dtm
                ,is_work_trm			-- work_trm
                ,ts_anth_cd
                ,ts_anth_acnt_no
                ,faa_acnt_bnh_cd_g( '3', is_acnt_no, is_sub_no)
                ,is_dept_no2
                ,ts_cnte
                ,ts_wdate
              );

/** update aaa10m00 and ssb01h00 **/

    ts_step := '7';

	if is_std_inq_dt <> ts_wdate and is_acnt_no <>  '068C606869' then

       select to_date(ts_wdate, 'yyyymmdd') - to_date(is_std_inq_dt, 'yyyymmdd')
         into tot_cnt
         from dual;

       for c1 in 0..tot_cnt loop

           select to_char((to_date(is_std_inq_dt,'yyyymmdd') + td_loop_cnt),'yyyymmdd')
             into ts_date
             from dual;

        if vn.fxc_holi_ck(to_date(ts_date,'yyyymmdd')) =  '0' then

          if ts_date  > is_std_inq_dt  then  /* execpts trd_dt */

             pxc_log_write('pss_outbil_aprv_p',' update trd_dt  :' || ts_date);

            BEGIN
             update vn.aaa10m00
                set bil_prerm_qty = bil_prerm_qty - (tn_qty + tn_sb_lmt_qty + tn_delay_qty)
                   ,bil_nowrm_qty = bil_nowrm_qty - (tn_qty + tn_sb_lmt_qty + tn_delay_qty)
				   ,tot_bil_prerm = tot_bil_prerm - (tn_qty + tn_sb_lmt_qty + tn_delay_qty)
                   ,tot_bil_nowrm = tot_bil_nowrm - (tn_qty + tn_sb_lmt_qty + tn_delay_qty)
              where acnt_no = is_acnt_no
				and sub_no = is_sub_no
                and stk_cd = ts_stk_cd
                and (nvl(bil_prerm_qty,0) > 0 or nvl(bil_nowrm_qty,0) > 0)
                and trd_dt = ts_date     ;

            pxc_log_write('pss_outbil_aprv_p',' update sqlcode  :' || sqlcode);

            EXCEPTION
               when OTHERS then
                    ts_step := '6.1';
                    raise_application_error(-20100,'error' );
            END;

         end if ;

         if ts_date < ts_wdate   then   /* execpt today */

            begin
              update  vn.ssb01h00
                 set  own_qty = own_qty - (tn_qty + tn_sb_lmt_qty + tn_delay_qty)
					 ,sb_lim_qty = sb_lim_qty - tn_sb_lmt_qty
					 ,delay_qty = delay_qty - tn_delay_qty
                     ,book_amt = book_amt - ((tn_qty + tn_sb_lmt_qty + tn_delay_qty) * tn_inq_pri)
                     ,work_mn = is_work_mn
                     ,work_dtm = sysdate
                     ,work_trm = is_work_trm
                     ,outq_req_qty = greatest(outq_req_qty - tn_qty, 0 )
                     ,lim_req_qty = greatest(lim_req_qty - tn_sb_lmt_qty , 0 )
					 ,delay_reg_qty = greatest(delay_reg_qty - tn_delay_qty , 0 )
               where acnt_no = is_acnt_no
				 and sub_no  = is_sub_no
                 and stk_cd = ts_stk_cd
                 and rgt_std_dt = ts_date;
               exception
                    when OTHERS then
                       raise_application_error(-20100,'error' );
            end;
          end if ;

         end if ;

		 td_loop_cnt := td_loop_cnt + 1 ;
        end loop;
     end if ;


/** update ssb01m00 **/
   ts_step := '8' ;

    UPDATE	vn.ssb01m00
       SET	own_qty = own_qty - (tn_qty + tn_sb_lmt_qty + tn_delay_qty)
           ,book_amt = decode(own_qty - (tn_qty + tn_sb_lmt_qty + tn_delay_qty) , 0 ,0 ,
										  trunc( book_amt - ((tn_qty + tn_sb_lmt_qty + tn_delay_qty) * tn_unit_pri)) )
           ,work_mn = is_work_mn
           ,work_dtm = sysdate
           ,work_trm = is_work_trm
           ,sb_lim_qty = sb_lim_qty - tn_sb_lmt_qty
		   ,delay_qty = delay_qty - tn_delay_qty
           ,outq_req_qty = greatest(outq_req_qty - tn_qty, 0 )
           ,lim_req_qty = greatest(lim_req_qty - tn_sb_lmt_qty , 0 )
		   ,delay_reg_qty = greatest(delay_reg_qty - tn_delay_qty , 0 )
     WHERE	acnt_no = is_acnt_no
	   AND  sub_no  = is_sub_no
       AND	stk_cd = ts_stk_cd;

/* ssb05m00 */
   ts_step := '9';
    UPDATE 	VN.SSB05M00
       SET  inq_dt = ts_wdate
           ,std_inq_dt = is_std_inq_dt
           ,trd_seq_no = tn_trd_seq_no
           ,cncl_trd_no = 0
           ,end_yn = 'Y'
           ,err_msg = 'OK'
           ,work_mn = is_work_mn
           ,work_dtm = sysdate
           ,work_trm = is_work_trm
      WHERE	proc_dt = is_proc_dt
        AND	acnt_no = is_acnt_no
		AND sub_no  = is_sub_no
		AND nvl(end_yn,'N') <> 'Y'
        AND	seq_no = to_number(is_seq_no);

   os_end_yn := 'Y';
   os_err_msg := 'OK';
   os_inq_dt := ts_wdate;

/*******************************/
/* call evaluation for margin  */
/*******************************/

  vn.pdl_crd_loan_rt_proc_td
       ( ts_wdate
        ,'2' -- stock
        ,is_acnt_no
		,is_sub_no
        ,tn_trd_seq_no
        ,is_work_mn
        ,is_work_trm
        ,o_cnt
       );

    vn.pxc_log_write('pss_outbil_aprv_p','pdl_crd_loan_rt_proc_td ['|| o_cnt ||']');

   if ts_rmrk_cd in ('603','604' ) then
      os_inq_dt := tn_trd_seq_no ;
   end if ;

 /* right proc  */

/* vn.psr_rgt_std_past_proc(
						is_std_inq_dt,
						ts_stk_cd,
						is_acnt_no,
						is_sub_no,
						tn_qty + tn_sb_lmt_qty + tn_delay_qty,
						'2',
						is_work_mn,
						is_work_trm
						);
*/
RETURN;

EXCEPTION
WHEN 	ERR_RTN		THEN
raise_application_error(-20100, os_err_msg || ':[pss_outbil_aprv_p ' || ts_step || '] ' || os_err_msg);
RETURN;

WHEN	NO_DATA_FOUND	THEN
raise_application_error(-20200, '[pss_outbil_aprv_p ' || ts_step || '] ' || SQLERRM);
RETURN;

WHEN	OTHERS	THEN
raise_application_error(-20300, '[pss_outbil_aprv_p ' || ts_step || '] ' || SQLERRM);
RETURN;

END pss_outbil_aprv_p_test;
/

