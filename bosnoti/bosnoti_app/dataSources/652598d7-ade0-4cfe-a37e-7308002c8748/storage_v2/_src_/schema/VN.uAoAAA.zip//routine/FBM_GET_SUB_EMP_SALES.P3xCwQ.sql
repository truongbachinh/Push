create function    fbm_get_sub_emp_sales(
    i_tp                varchar2,   -- Phan loai tra cuu:   1. Trd_amt  2. Net_amt  3. Admit_amt    4. Pur_amt  5. using_trd_amt
    i_dt                varchar2,   -- Ngay tra cuu
    i_emp_no            varchar2,   -- Ma nhan vien
    i_biz_emp_tp        varchar2,   -- Phan loai nhan vien
    i_mon_dt            varchar2,   -- Thang tinh hoa hong
    i_biz_cmsn_tp       varchar2,   -- Phan loai giao dich
    i_biz_cmsn_knd      varchar2    -- Phan loai hoa hong
)
return number

as
pragma autonomous_transaction;

    t_sales_amt  number;
    t_proc_nm       varchar2(30)    := 'fbm_get_sub_emp_sales';
    t_vwdate        varchar2(8)     := vwdate;
    t_err_msg       varchar2(500)   := ' ';

    o_ret               number;
begin
    if(i_tp not in ('1', '2', '3', '4', '5')) then
        t_err_msg  := 'Wrong input value. i_tp = ' || i_tp;
        vn.pxc_log_write(t_proc_nm, t_err_msg);
        raise_application_error(-20100,t_err_msg);
    end if;

    begin
        select
            case
                when i_tp = '1'
                    then sum(b3.trd_amt)
                when i_tp = '2'
                    then sum(b3.net_amt)
                when i_tp = '3'
                    then sum(b3.admit_amt)
                when i_tp = '4'
                    then sum(b3.pur_amt)
                when i_tp = '5'
                    then sum(b3.using_trd_amt)
            end sales_amt
        into t_sales_amt
        from vn.bmb30m00 b3
        inner join vn.rms05m00 r5
        on b3.emp_no = r5.emp_no
        and i_dt between r5.apy_dt and r5.expr_dt
        inner join vn.xca01m01 xc            -- Thong tin NV
        on r5.emp_no = xc.emp_no
        where r5.mng_emp_no = i_emp_no
        and b3.mon_dt = i_mon_dt
        and b3.biz_cmsn_tp like i_biz_cmsn_tp
        and xc.biz_emp_tp like i_biz_emp_tp

        ;
    exception
        when no_data_found then
            t_sales_amt    := 0;
        when others then
            t_err_msg   := 'Error when getting data from bmb30m00'
                        || ' sqlcode= ' || sqlcode
                        || ' sqlerrm= ' || sqlerrm;

            vn.pxc_log_write(t_proc_nm, t_err_msg);
            raise_application_error(-20100, t_err_msg);
    end;

    o_ret   := nvl(t_sales_amt, 0);

    return o_ret;

end fbm_get_sub_emp_sales;
/

