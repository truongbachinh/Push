create function fcw_get_user_nm_acnt
(
    --i_sec_cd 	   in 	varchar2,
    i_acnt_no   in varchar2 ,
    i_sub_no   in   varchar2
)
    return          varchar2
as

    o_rem_nm        varchar2(100) ;
    --t_err_txt       varchar2(100)  ; -- error text buffer

begin

    o_rem_nm  :=  NULL;
    begin
        select vn.fxc_emp_nm(a.emp_no) into o_rem_nm
         from vn.bmi01m00 a
         where a.acnt_no=i_acnt_no and a.sub_no=i_sub_no and a.cls_dtm=to_date('30000101','yyyymmdd');
    exception
        when  NO_DATA_FOUND  then
      return  '!';
        when  OTHERS         then
            --t_err_txt  :=  '??-['||to_char(sqlcode)||']';
            --raise_application_error (-20100, t_err_txt);
            return  '!';
    end;

    return  o_rem_nm;

end fcw_get_user_nm_acnt;
/

