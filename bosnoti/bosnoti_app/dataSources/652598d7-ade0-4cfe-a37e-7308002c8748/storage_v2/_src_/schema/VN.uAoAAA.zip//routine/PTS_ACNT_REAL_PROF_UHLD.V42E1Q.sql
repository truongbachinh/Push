create procedure pts_acnt_real_prof_uhld
(
	i_acnt_no              IN     VARCHAR2,
	i_sub_no               IN     VARCHAR2,
	i_bank_cd              IN     VARCHAR2,
    i_input_amt            IN     NUMBER,
    i_input_start          IN     NUMBER,
    o_result_yn            IN OUT VARCHAR2
) as

    t_td_cash_prof_amt          number := 0;
    t_td_cash_prof_gst_amt      number := 0;
    t_pd_cash_prof_amt          number := 0;
    t_pd_cash_prof_gst_amt      number := 0;
    t_ppd_cash_prof_amt         number := 0;
    t_ppd_cash_prof_gst_amt     number := 0;
    t_pppd_cash_prof_amt        number := 0;
    t_pppd_cash_prof_gst_amt    number := 0;

    tmp_td_cash_prof_amt          number := 0;
    tmp_td_cash_prof_gst_amt      number := 0;
    tmp_pd_cash_prof_amt          number := 0;
    tmp_pd_cash_prof_gst_amt      number := 0;
    tmp_ppd_cash_prof_amt         number := 0;
    tmp_ppd_cash_prof_gst_amt     number := 0;
    tmp_pppd_cash_prof_amt        number := 0;
    tmp_pppd_cash_prof_gst_amt    number := 0;

    tmp_input_amt                 number := 0;

    ts_init_prof_amt              number := 0 ;
	ts_result_gst_amt             number := 0 ;
	ts_cal_gst_amt                number := 0 ;
	ts_mkt_cnt                    number := 0 ;
	tn_gst_dpo_prerm              number := 0 ;
	t_err_msg                     varchar2(500) := null;


begin

    if i_bank_cd <> '9999' then
        t_err_msg := vn.fxc_get_err_msg('V','2475');
        t_err_msg := t_err_msg||' i_bank_cd= '||i_bank_cd;
        o_result_yn := 'N';
        raise_application_error(-20100,t_err_msg);

    end if;

    begin
        select count(*)
        into  ts_mkt_cnt
        from vn.tso03m00
        where MKT_DRV_TP in ('O', 'P', 'I', 'K', '13', 'A', 'C', '5', '10', 'RP', 'RO')
        ;
        EXCEPTION
                 when  OTHERS  then
                     o_result_yn	 := to_char(sqlcode);
                     raise_application_error (-20100, 'error - ' ||  to_char(sqlcode));

    end;

    if ts_mkt_cnt > 0 then
        t_err_msg := vn.fxc_get_err_msg('V','0119');
        t_err_msg := t_err_msg||' ts_mkt_cnt= '||ts_mkt_cnt;
        o_result_yn := 'N';
        raise_application_error(-20100,t_err_msg);
    end if;


    if i_input_amt = 0 then
        o_result_yn := 'Y';
    elsif  i_input_amt < 0 then
        o_result_yn := '20100';

    else
         /* ALL SEARCHED IOFOMATIN PROM TSO02M00 */
         begin
            SELECT  NVL(TD_CASH_PROF_AMT, 0 ),
                    NVL(TD_CASH_PROF_GST_AMT, 0),
                    NVL(PD_CASH_PROF_AMT, 0 ),
                    NVL(PD_CASH_PROF_GST_AMT, 0),
                    NVL(PPD_CASH_PROF_AMT, 0),
                    NVL(PPD_CASH_PROF_GST_AMT, 0),
                    NVL(PPPD_CASH_PROF_AMT, 0),
                    NVL(PPPD_CASH_PROF_GST_AMT, 0)
            INTO    t_td_cash_prof_amt,
                    t_td_cash_prof_gst_amt,
                    t_pd_cash_prof_amt,
                    t_pd_cash_prof_gst_amt,
                    t_ppd_cash_prof_amt,
                    t_ppd_cash_prof_gst_amt,
                    t_pppd_cash_prof_amt,
                    t_pppd_cash_prof_gst_amt
            FROM VN.TSO02M00
            WHERE ACNT_NO = i_acnt_no
            	AND SUB_NO = i_sub_no
                AND BANK_CD = i_bank_cd
            ;

            EXCEPTION
                 when  OTHERS  then
                     o_result_yn	 := to_char(sqlcode);
                     raise_application_error (-20100, 'error - ' ||  to_char(sqlcode));

           end;

     ts_init_prof_amt :=  t_td_cash_prof_amt + t_pd_cash_prof_amt + t_ppd_cash_prof_amt + t_pppd_cash_prof_amt ;
     vn.pxc_log_write('pts_acnt_real_prof_uhld','acnt_no init gst_prof_amt ['|| i_acnt_no ||' ' || i_sub_no ||  ' '||  ts_init_prof_amt ||'] ');

        /* data copy */

        tmp_td_cash_prof_amt          :=    t_td_cash_prof_amt      ;
        tmp_td_cash_prof_gst_amt      :=    t_td_cash_prof_gst_amt  ;
        tmp_pd_cash_prof_amt          :=    t_pd_cash_prof_amt      ;
        tmp_pd_cash_prof_gst_amt      :=    t_pd_cash_prof_gst_amt  ;
        tmp_ppd_cash_prof_amt         :=    t_ppd_cash_prof_amt     ;
        tmp_ppd_cash_prof_gst_amt     :=    t_ppd_cash_prof_gst_amt ;
        tmp_pppd_cash_prof_amt        :=    t_pppd_cash_prof_amt    ;
        tmp_pppd_cash_prof_gst_amt    :=    t_pppd_cash_prof_gst_amt;
        tmp_input_amt                 :=    i_input_amt;


        /* T+3 */
        if i_input_start = 3 then
            vn.pxc_log_write('pts_acnt_real_prof_uhld','T+3 tmp_input_amt['||tmp_input_amt||'] ');

            if  tmp_input_amt > 0 then
               if t_ppd_cash_prof_amt > 0 then
                   if  t_ppd_cash_prof_amt > tmp_input_amt then
                       tmp_ppd_cash_prof_amt         := t_ppd_cash_prof_amt - tmp_input_amt ;
                       tmp_ppd_cash_prof_gst_amt     := t_ppd_cash_prof_gst_amt + tmp_input_amt;
                       tmp_input_amt := 0;
                   else
                      tmp_ppd_cash_prof_amt         := 0;
                      tmp_ppd_cash_prof_gst_amt     := t_ppd_cash_prof_gst_amt  + t_ppd_cash_prof_amt;
                      tmp_input_amt  := tmp_input_amt - t_ppd_cash_prof_amt;
                   end if;

                end if;
            end if;
            vn.pxc_log_write('pts_acnt_real_prof_uhld','T+2 tmp_input_amt['||tmp_input_amt||']' );
            /* T+ 2 */
            if  tmp_input_amt > 0 then
               if t_pd_cash_prof_amt > 0 then
                   if  t_pd_cash_prof_amt > tmp_input_amt then
                       tmp_pd_cash_prof_amt := t_pd_cash_prof_amt - tmp_input_amt ;
                       tmp_pd_cash_prof_gst_amt     := t_pd_cash_prof_gst_amt + tmp_input_amt;
                       tmp_input_amt := 0;
                   else
                      tmp_pd_cash_prof_amt  := 0;
                      tmp_pd_cash_prof_gst_amt     := t_pd_cash_prof_gst_amt  + t_pd_cash_prof_amt;
                      tmp_input_amt  := tmp_input_amt - t_pd_cash_prof_amt;
                   end if;

                end if;
            end if;
            vn.pxc_log_write('pts_acnt_real_prof_uhld','T+1 tmp_input_amt['||tmp_input_amt||']' );
            /* T+ 1 */
            if  tmp_input_amt > 0 then
               if t_td_cash_prof_amt > 0 then
                   if  t_td_cash_prof_amt > tmp_input_amt then
                       tmp_td_cash_prof_amt := t_td_cash_prof_amt - tmp_input_amt ;
                       tmp_td_cash_prof_gst_amt     := t_td_cash_prof_gst_amt + tmp_input_amt;
                       tmp_input_amt := 0;
                   else
                      tmp_td_cash_prof_amt  := 0;
                      tmp_td_cash_prof_gst_amt     := t_td_cash_prof_gst_amt  + t_td_cash_prof_amt;
                      tmp_input_amt  := tmp_input_amt - t_td_cash_prof_amt;
                   end if;

                end if;
            end if;

        elsif  i_input_start = 2 then
            vn.pxc_log_write('pts_acnt_real_prof_uhld','T+2 tmp_input_amt['||tmp_input_amt||']' );
            /* T+ 2 */
            if  tmp_input_amt > 0 then
               if t_pd_cash_prof_amt > 0 then
                   if  t_pd_cash_prof_amt > tmp_input_amt then
                       tmp_pd_cash_prof_amt := t_pd_cash_prof_amt - tmp_input_amt ;
                       tmp_pd_cash_prof_gst_amt     := t_pd_cash_prof_gst_amt + tmp_input_amt;
                       tmp_input_amt := 0;
                   else
                      tmp_pd_cash_prof_amt  := 0;
                      tmp_pd_cash_prof_gst_amt     := t_pd_cash_prof_gst_amt  + t_pd_cash_prof_amt;
                      tmp_input_amt  := tmp_input_amt - t_pd_cash_prof_amt;
                   end if;

                end if;
            end if;
            vn.pxc_log_write('pts_acnt_real_prof_uhld','T+1 tmp_input_amt['||tmp_input_amt||']' );
            /* T+ 1 */
            if  tmp_input_amt > 0 then
               if t_td_cash_prof_amt > 0 then
                   if  t_td_cash_prof_amt > tmp_input_amt then
                       tmp_td_cash_prof_amt := t_td_cash_prof_amt - tmp_input_amt ;
                       tmp_td_cash_prof_gst_amt     := t_td_cash_prof_gst_amt + tmp_input_amt;
                       tmp_input_amt := 0;
                   else
                      tmp_td_cash_prof_amt  := 0;
                      tmp_td_cash_prof_gst_amt     := t_td_cash_prof_gst_amt  + t_td_cash_prof_amt;
                      tmp_input_amt  := tmp_input_amt - t_td_cash_prof_amt;
                   end if;

                end if;
            end if;

        elsif  i_input_start = 1 then
             vn.pxc_log_write('pts_acnt_real_prof_uhld','T+1 tmp_input_amt['||tmp_input_amt||']' );
            /* T+ 1 */
            if  tmp_input_amt > 0 then
               if t_td_cash_prof_amt > 0 then
                   if  t_td_cash_prof_amt > tmp_input_amt then
                       tmp_td_cash_prof_amt := t_td_cash_prof_amt - tmp_input_amt ;
                       tmp_td_cash_prof_gst_amt     := t_td_cash_prof_gst_amt + tmp_input_amt;
                       tmp_input_amt := 0;
                   else
                      tmp_td_cash_prof_amt  := 0;
                      tmp_td_cash_prof_gst_amt     := t_td_cash_prof_gst_amt  + t_td_cash_prof_amt;
                      tmp_input_amt  := tmp_input_amt - t_td_cash_prof_amt;
                   end if;

                end if;
            end if;


        end if;

  vn.pxc_log_write('pts_acnt_real_prof_uhld',' i_acnt_no['||i_acnt_no||']  i_bank_cd['|| i_bank_cd ||']');
  vn.pxc_log_write('pts_acnt_real_prof_uhld','tso02m00 update  tmp_td_cash_prof_amt['||tmp_td_cash_prof_amt||']' );
  vn.pxc_log_write('pts_acnt_real_prof_uhld','tso02tmp_input_amtm00 update  tmp_td_cash_prof_gst_amt['||tmp_td_cash_prof_gst_amt||']' );
  vn.pxc_log_write('pts_acnt_real_prof_uhld','tso02m00 update  tmp_pd_cash_prof_amt['||tmp_pd_cash_prof_amt||']' );
  vn.pxc_log_write('pts_acnt_real_prof_uhld','tso02m00 update  tmp_pd_cash_prof_gst_amt['||tmp_pd_cash_prof_gst_amt||']' );
  vn.pxc_log_write('pts_acnt_real_prof_uhld','tso02m00 update  tmp_ppd_cash_prof_amt['||tmp_ppd_cash_prof_amt||']' );
  vn.pxc_log_write('pts_acnt_real_prof_uhld','tso02m00 update  tmp_ppd_cash_prof_gst_amt['||tmp_ppd_cash_prof_gst_amt||']' );
  vn.pxc_log_write('pts_acnt_real_prof_uhld','tso02m00 update  tmp_pppd_cash_prof_amt['||tmp_pppd_cash_prof_amt||']' );
  vn.pxc_log_write('pts_acnt_real_prof_uhld','tso02m00 update  tmp_pppd_cash_prof_gst_amt['||tmp_pppd_cash_prof_gst_amt||']' );

        UPDATE VN.TSO02M00 SET
            TD_CASH_PROF_AMT =         greatest(tmp_td_cash_prof_amt      , 0) ,
            TD_CASH_PROF_GST_AMT  =    greatest(tmp_td_cash_prof_gst_amt  , 0) ,
            PD_CASH_PROF_AMT =         greatest(tmp_pd_cash_prof_amt      , 0) ,
            PD_CASH_PROF_GST_AMT =     greatest(tmp_pd_cash_prof_gst_amt  , 0) ,
            PPD_CASH_PROF_AMT    =     greatest(tmp_ppd_cash_prof_amt     , 0) ,
            PPD_CASH_PROF_GST_AMT =    greatest(tmp_ppd_cash_prof_gst_amt , 0) ,
            PPPD_CASH_PROF_AMT =       greatest(tmp_pppd_cash_prof_amt    , 0) ,
            PPPD_CASH_PROF_GST_AMT =   greatest(tmp_pppd_cash_prof_gst_amt, 0)
        WHERE ACNT_NO = i_acnt_no
        	  AND SUB_NO = i_sub_no
              AND BANK_CD = i_bank_cd
            ;

        o_result_yn := 'Y';

    end if;


end pts_acnt_real_prof_uhld;
/

