create procedure pts_bat_test (
    i_work_dt       in      varchar2,       -- date(yyyymmdd)
	o_err_code      in      number,         -- error code(0:SUCCESS)
	o_err_msg       in      varchar2        -- error message
) as

t_err_code      number        := o_err_code;
t_cnt			number        :=0;
t_err_msg       varchar2(600) := rtrim(o_err_msg);
exp_error       exception;

/*!
    \file     pts_bat_test
    \brief

	\section intro Program Information
		- Program Name              : pts_bat_test
		- Service Name              :
		- Related Client Program- Client Program ID :
		- Related Tables            :
		- Dev. Date                 : 2007/12/03
		- Developer                 : ejlee
		- Business Logic Desc.      :
		- Latest Modification Date  :

	\section history Program Modification History
		- 1.0  2007/12/03

	\section hardcoding Hard-Coding List

	\section info Additional Reference Comments
*/

begin

	pts_bat_tso01h00_ins(i_work_dt, t_err_code, t_err_msg, t_cnt);
	if t_err_code != 0 then
		RETURN;
	end if;

	pts_bat_tso01h10_ins(i_work_dt, t_err_code, t_err_msg, t_cnt);
	if t_err_code != 0 then
		RETURN;
	end if;

	pts_bat_tso01m10_trunc(i_work_dt, t_err_code, t_err_msg, t_cnt);
	if t_err_code != 0 then
		RETURN;
	end if;

    pts_bat_tso01m00_trunc(i_work_dt, t_err_code, t_err_msg, t_cnt);
	if t_err_code != 0 then
		RETURN;
	end if;

	commit;

end pts_bat_test;
/

