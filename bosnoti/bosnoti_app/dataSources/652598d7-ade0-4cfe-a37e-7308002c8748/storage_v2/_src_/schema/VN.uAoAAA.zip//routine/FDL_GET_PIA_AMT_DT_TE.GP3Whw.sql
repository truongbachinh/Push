create FUNCTION fdl_get_pia_amt_dt_te
(
    i_sec_cd         in     varchar2,
    i_acnt_no        in     varchar2,        --
    i_sub_no         in     varchar2,
    i_mth_dt         in     varchar2,
    i_lnd_bank_cd    in     varchar2       --
) RETURN  NUMBER AS

/*!


   \section intro Program Information
        - Program Name              : PIA AUTO MONEY ADVANCE
        - Service Name              :
        - Related Client Program- Client Program ID :
        - Related Tables            : dsc01m00, cwd01m00, dlm01m00
                                    : aaa01m00, aaa10m00
        - Dev. Date                 : 2013/12/16
        - Developer                 : thuan.
        - Business Logic Desc.      : create margin-loan data




*/
 td_lnd_rm_amt   number := 0;

 td_lnd_cmsn_amt number := 0;
 td_pay_lnd_cmsn number := 0;
 td_abl_lnd_cmsn number := 0;

 td_abl_amt      number := 0;

 t_grp_tp        VARCHAR2(1)  := NULL;


 td_sum_abl_amt      number := 0;

 t_pppre_mth_dt     VARCHAR2(08)  := null;  --
 t_ppre_mth_dt      VARCHAR2(08)  := null;  --
 t_pre_mth_dt       VARCHAR2(08)  := null;
 t_vwdate           VARCHAR2(08)  := null;

 td_d0_rpy_amt      NUMBER        :=  0;
 td_d1_rpy_amt      number        :=  0;
 td_d2_rpy_amt      number        :=  0;
 td_d3_rpy_amt        number        :=  0;
 td_d0_rpy_int      number        :=  0;
 td_d1_rpy_int      number        :=  0;
 td_d2_rpy_int      number        :=  0;
 td_d3_rpy_int       number        :=  0;


BEGIN

-- INPUT DATE

t_vwdate       := vn.fxc_vorderdt_g(to_date(vn.vwdate,'yyyymmdd'),0);
t_pppre_mth_dt := vn.fxc_vorderdt_g(to_date(t_vwdate,'yyyymmdd'),-3);
t_ppre_mth_dt  := vn.fxc_vorderdt_g(to_date(t_vwdate,'yyyymmdd'),-2);
t_pre_mth_dt   := vn.fxc_vorderdt_g(to_date(t_vwdate,'yyyymmdd'),-1);




 For C1 in(
    select *
    from (
        select  '1'                                  tp
             ,  bank_cd                              bank_cd
             ,  vn.faa_bank_nm_g(bank_cd) bank_nm
             ,  mth_dt                               mth_dt1
             ,  setl_dt                              setl_dt1
             ,  to_char(to_date(mth_dt,'yyyymmdd'),'ddmmyyyy')
                                                     mth_dt
             ,  to_char(to_date(setl_dt,'yyyymmdd'),'ddmmyyyy')
                                                     setl_dt
             ,  cdt_tp                               cdt_tp
             ,  vn.fxc_tp_nm_g1('cdt_tp',cdt_tp,'V') cdt_nm
             ,  sum(sb_amt)                          mth_amt
             ,  sum(sb_cmsn)                         sb_cmsn
             ,  sum(sb_tax)                          sb_tax
             ,  SUM(ADJ_AMT)                        adj_amt
          from  vn.dsc01m10
         where  mth_dt       =  decode(i_mth_dt,t_vwdate,i_mth_dt,'11111111')
           and  acnt_no      =  i_acnt_no
           and  sub_no       =  i_sub_no
           and  bank_cd   like  '%'
           and  sb_tp        =  '1'
           and  mkt_trd_tp  in  ('01','03','05')
           /*and  dpo_setl_yn  =  'N'*/
         group  by  bank_cd, mth_dt, setl_dt, cdt_tp
    union
        select  '2'                                  tp
             ,  bank_cd                              bank_cd
             ,  vn.faa_bank_nm_g(bank_cd) bank_nm
             ,  mth_dt                               mth_dt1
             ,  setl_dt                              setl_dt1
             ,  to_char(to_date(mth_dt,'yyyymmdd'),'ddmmyyyy')
                                                     mth_dt
             ,  to_char(to_date(setl_dt,'yyyymmdd'),'ddmmyyyy')
                                                     setl_dt
             ,  cdt_tp                               cdt_tp
             ,  vn.fxc_tp_nm_g1('cdt_tp',cdt_tp,'V') cdt_nm
             ,  sum(sb_amt)                          mth_amt
             ,  sum(sb_cmsn)                         sb_cmsn
             ,  sum(sb_tax)                          sb_tax
             , sum(adj_amt)                          adj_amt
          from  vn.dsc01m00
         where  mth_dt      =  i_mth_dt
           and  mth_dt       <  t_vwdate
           and  acnt_no      =  i_acnt_no
           and  sub_no       =  i_sub_no
           and  bank_cd   like  '%'
           and  sb_tp        =  '1'
           and  mkt_trd_tp  in  ('01','03','05')
         group  by  bank_cd, mth_dt, setl_dt, cdt_tp
      )X
      order by X.bank_Cd, X.mth_dt, X.setl_dt, X.cdt_tp
   )Loop

  if i_mth_dt = C1.mth_dt1 then
      BEGIN
        select  nvl(sum(nvl(lnd_amt,0) - nvl(lnd_rpy_amt,0)),0)  lnd_rm_amt
          into  td_lnd_rm_amt
          from  vn.dlm01m20
         where  lnd_tp          =  '10'
           and  acnt_no         =  i_acnt_no
           and  sub_no          =  i_sub_no
           and  mth_dt          =  C1.Mth_Dt1
           and  setl_dt      =     C1.Setl_Dt1
           and  expr_dt         =  C1.Setl_Dt1
           and  lnd_bank_cd  like  decode(i_lnd_bank_cd,'9999','%'
                                     ,'%')
           and  cdt_tp          =  C1.Cdt_Tp
           and  lnd_acpt_tp     =  '01'
           and  cncl_yn         =  'N'
        ;
      exception
      when others then --
        raise_application_error(-20100,'Error 2');
      end;

        if C1.Cdt_Tp in( '20', '30') then
         td_d0_rpy_amt :=  0;
         td_d1_rpy_amt :=  0;
         td_d2_rpy_amt :=  0;
         td_d3_rpy_amt :=  0;
         td_d0_rpy_int :=  0;
         td_d1_rpy_int :=  0;
         td_d2_rpy_int :=  0;
         td_d3_rpy_int :=  0;
         vn.pdl_mrtg_rpyable_amt ( C1.cdt_tp
                      , i_acnt_no
                      , i_sub_no
                      , '%'
                      , '%'
                       , td_d0_rpy_amt,  td_d1_rpy_amt, td_d2_rpy_amt, td_d3_rpy_amt
                       , td_d0_rpy_int,  td_d1_rpy_int, td_d2_rpy_int, td_d3_rpy_int  );
         if C1.mth_dt1 = t_vwdate then
            C1.adj_amt := C1.adj_amt - td_d3_rpy_amt - td_d3_rpy_int;
         elsif C1.mth_dt1 = t_pre_mth_dt then
            C1.adj_amt := C1.adj_amt - td_d2_rpy_amt - td_d2_rpy_int;
         elsif C1.mth_dt1 = t_ppre_mth_dt then
            C1.adj_amt := C1.adj_amt - td_d1_rpy_amt - td_d1_rpy_int;
         elsif C1.mth_dt1 = t_pppre_mth_dt then
            C1.adj_amt := C1.adj_amt - td_d0_rpy_amt - td_d0_rpy_int;
         end if;

        end if;


      BEGIN
          vn.pdl_get_lnd_cmsn_abl (   '10'
                       , i_lnd_bank_cd,  i_acnt_no,    i_sub_no
                       , t_vwdate    ,  C1.setl_dt1
                       , 0             ,  C1.adj_amt   /* :o_mth_amt - :o_sb_cmsn --*/
                       , 0             ,  td_lnd_cmsn_amt    );
      exception
       when others then
         raise_application_error(-20011,'Error on pdl_get_lnd_cmsn_abl'||' ACNT_NO='||i_acnt_no||'-'||i_sub_no);
      end;
 

      BEGIN
          vn.pdl_get_pay_lnd_cmsn (  '10'
                      , i_lnd_bank_cd,  i_acnt_no,   i_sub_no
                      , C1.mth_dt1    ,  C1.setl_dt1
                      , C1.adj_amt
                      , td_pay_lnd_cmsn,  td_abl_lnd_cmsn  );
      exception
       when others then
         raise_application_error(-20011,'Error on pdl_get_pay_lnd_cmsn'||' ACNT_NO='||i_acnt_no||'-'||i_sub_no);
      end;

      IF (td_pay_lnd_cmsn = 0 and td_abl_lnd_cmsn = 0) THEN
          td_abl_amt := GREATEST(C1.adj_amt - td_lnd_rm_amt - td_lnd_cmsn_amt,0);
      ELSE
          td_abl_amt := GREATEST(C1.adj_amt - td_lnd_rm_amt - td_pay_lnd_cmsn - td_abl_lnd_cmsn,0) ;

      END IF;


      td_sum_abl_amt := td_sum_abl_amt + td_abl_amt;
    end if;
  END LOOP;

return td_sum_abl_amt;
END fdl_get_pia_amt_dt_te;
/

