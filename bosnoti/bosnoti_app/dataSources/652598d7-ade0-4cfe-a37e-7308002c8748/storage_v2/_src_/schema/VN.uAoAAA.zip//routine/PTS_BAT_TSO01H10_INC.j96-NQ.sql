create procedure pts_bat_tso01h10_inc (
    i_work_dt       in      varchar2,       -- date(yyyymmdd)
	o_err_code      in      number,         -- error code(0:SUCCESS)
	o_err_msg       in      varchar2        -- error message
) as

t_err_code      number        := o_err_code;
t_err_msg       varchar2(600) := rtrim(o_err_msg);
t_chk           varchar2(1);
t_cnt           number;
exp_error       exception;

/*!
    \file     pts_bat_tso10h10_ins
	\brief    tso01m10 select, tso01h10 insert

	\section intro Program Information
		- Program Name              : pts_bat_tso01h10_inc
		- Service Name              :
		- Related Client Program- Client Program ID :
		- Related Tables            : tso01m10, tso01h10
		- Dev. Date                 : 2007/11/27
		- Developer                 : ejlee
		- Business Logic Desc.      :
		- Latest Modification Date  :

	\section history Program Modification History
		- 1.0  2007/11/27

	\section hardcoding Hard-Coding List

	\section info Additional Reference Comments
*/

begin

	t_err_code := 0;
	t_err_msg  := 'SUCCESS';
	t_chk      := 'N';

	-- 1. �� ��ü��Ϸ��ũ Funüũ

	if t_chk = 'Y' then

        for  c1  in (

		    select  bnh_cd         ,
				    ord_no         ,
				    ord_mth_no     ,
				    acnt_no        ,
				    stk_cd         ,
				    mth_qty        ,
				    mth_pri        ,
				    mth_time       ,
				    if_seq_no      ,
				    dat_cd         ,
				    work_mn        ,
				    work_dtm       ,
				    work_trm
			  from  vn.tso01m10

             ) loop

			 insert into vn.tso01h10
			 (      stk_ord_dt     ,
		            bnh_cd         ,
				    ord_no         ,
				    ord_mth_no     ,
				    acnt_no        ,
				    stk_cd         ,
				    mth_qty        ,
				    mth_pri        ,
				    mth_time       ,
				    work_mn        ,
				    work_dtm       ,
				    work_trm
            ) values (
			        i_work_dt      ,
		            c1.bnh_cd      ,
				    c1.ord_no      ,
				    c1.ord_mth_no  ,
				    c1.acnt_no     ,
				    c1.stk_cd      ,
				    c1.mth_qty     ,
				    c1.mth_pri     ,
				    c1.mth_time    ,
				    c1.work_mn     ,
				    c1.work_dtm    ,
				    c1.work_trm
            );

        end loop;
		commit;
	else
		t_err_code := 0;
	    t_err_msg  := '�� ��ü��̿Ϸ��ϴ� ü��� � ó����ʽÿ�';
		raise_application_error(-20100,'[pts_bat_tso01h10_inc] ' || t_err_msg);
	end if;

	exception when  exp_error then
		t_err_code := sqlcode;
		t_err_msg  := sqlerrm;
		raise_application_error(-20100,'[pts_bat_tso01h10_inc] ' || t_err_msg);

end pts_bat_tso01h10_inc;
/

