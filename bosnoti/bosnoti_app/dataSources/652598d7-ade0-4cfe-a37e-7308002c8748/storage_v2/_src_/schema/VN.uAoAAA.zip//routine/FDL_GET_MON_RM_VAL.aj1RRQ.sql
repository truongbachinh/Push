create function fdl_get_mon_rm_val
(
    i_tp             in     varchar2,        -- 1:int 2:fee 3:all
	i_std_mon        in     varchar2,        --
	i_lnd_tp         in     varchar2,        --
	i_acnt_no        in     varchar2,        --
	i_sub_no         in     varchar2,        --
	i_lnd_dt         in     varchar2,        --
	i_lnd_bank_cd    in     varchar2,        --
	i_stk_cd         in     varchar2         --
)
    return  number
as

	o_lnd_rm_int    number := 0;
	o_lnd_rm_fee    number := 0;
	o_lnd_rm        number := 0;

    t_err_msg       varchar2(500);

begin

/*============================================================================*/
/* Calculation                                                                */
/*============================================================================*/
	for c1 in (
        select  nvl(lnd_int,0) + nvl(dly_int,0)          lnd_int
             ,  nvl(lnd_rpy_int,0) + nvl(dly_rpy_int,0)  rpy_int
             ,  nvl(lnd_fee,0) + nvl(dly_fee,0)          lnd_fee
             ,  nvl(lnd_rpy_fee,0) + nvl(dly_rpy_fee,0)  rpy_fee
          from  vn.dlm02m00
         where  std_mon   like  i_std_mon
           and  lnd_tp       =  i_lnd_tp
           and  acnt_no      =  i_acnt_no
           and  sub_no       =  i_sub_no
           and  lnd_dt       =  i_lnd_dt
           and  lnd_bank_cd  =  i_lnd_bank_cd
           and  stk_cd       =  i_stk_cd
	) loop
		o_lnd_rm_int  :=  o_lnd_rm_int + c1.lnd_int - c1.rpy_int;
		o_lnd_rm_fee  :=  o_lnd_rm_fee + c1.lnd_fee - c1.rpy_fee;
	end loop;

    /*==================================================*/
    /* fee type : 1.fee 2.delay fee 3.all               */
    /*==================================================*/
    if  i_tp = '1' then
        o_lnd_rm := o_lnd_rm_int;
    elsif i_tp = '2' then
        o_lnd_rm := o_lnd_rm_fee;
    else
        o_lnd_rm := o_lnd_rm_int + o_lnd_rm_fee;
    end if;

    return o_lnd_rm;

end fdl_get_mon_rm_val;
/

