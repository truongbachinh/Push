create procedure    pxc_email_ins(
    i_send_dt          in varchar2,                         -- can put NULL, get from sysdate
    i_recv_email_add   in varchar2,                         -- can put NULL, get from account
    i_send_email_add   in varchar2,                         -- can put NULL, get from company
    i_func_cd          in varchar2,                         -- NOT null
    i_msg_lang         in varchar2,                         -- can put NULL, get from account
    i_email_msg        in varchar2,                         -- NOT null
    i_attach_name      in varchar2,                         -- can put NULL
    i_attach_file      in blob,                             -- can put NULL
    i_work_mn          in varchar2,                         -- can put NULL
    i_work_trm         in varchar2,                         -- can put NULL
    i_acnt_no          in varchar2      default null,       -- can put NULL
    i_sub_no           in varchar2      default null,       -- can put NULL
    i_func_tp          in varchar2      default '1',        -- can put NULL, -- 1; email sent to customer     2: email sent to employee
    i_ekyc_seq_no      in number        default 0           -- can put NULL, -- seq_no from aaa05m00
) IS
/*
    Sample call:
        begin
            vn.pxc_email_ins(
                vwdate,                         -- i_send_dt          in varchar2,                         -- can put NULL, get from sysdate
                'phanxuanha88@gmail.com',       -- i_recv_email_add   in varchar2,                         -- can put NULL, get from account
                null,                           -- i_send_email_add   in varchar2,                         -- can put NULL, get from company
                'F09101',                       -- i_func_cd          in varchar2,                         -- NOT null
                'V',                            -- i_msg_lang         in varchar2,                         -- can put NULL, get from account
                '||039C001993',                 -- i_email_msg        in varchar2,                         -- NOT null
                null,                           -- i_attach_name      in varchar2,                         -- can put NULL
                null,                           -- i_attach_file      in blob,                             -- can put NULL
                'SYSTEM',                       -- i_work_mn          in varchar2,                         -- can put NULL
                '1.1.1.1',                      -- i_work_trm         in varchar2,                         -- can put NULL
                null,                           -- i_acnt_no          in varchar2      default null,       -- can put NULL
                null,                           -- i_sub_no           in varchar2      default null,       -- can put NULL
                '1',                            -- i_func_tp          in varchar2      default '1'         -- can put NULL, -- 1; email sent to customer     2: email sent to employee
                47                              -- i_ekyc_seq_no      in number        default 0           -- can put NULL, -- seq_no from aaa05m00
            );
        end;
*/
/* Declare variable */
    -- Common variable
    t_proc_nm               varchar2(100)   := 'pxc_email_ins';
    t_err_msg               varchar2(4000)  := ' ';
    t_sec_cd                varchar2(3)     := null;
    t_vwdate                varchar2(8)     := null;

    -- Info variable
    t_email_msg_trunc       varchar2(4000)  := ' ';
    t_email_msg             clob            := ' ';
    t_email_msg_max_sz      number          := 4000;
    t_email_yn              varchar2(1)     := 'N';
    t_func_nm               varchar2(50)    := '';

    t_seq_no                number          := null;
    t_send_dt               varchar2(14)    := substr(i_send_dt, 1, 8);
    t_recv_email_add        varchar2(50)    := i_recv_email_add;
    t_send_email_add        varchar2(50)    := i_send_email_add;
    t_msg_lang              varchar2(1)     := i_msg_lang;
    t_acnt_no               varchar2(10)    := i_acnt_no;
    t_sub_no                varchar2(2)     := i_sub_no;
    t_email_reg_yn          varchar2(1)     := 'Y';
    t_from_name             varchar2(100)   := null;
    t_to_name               varchar2(100)   := null;
    t_attach_name_1         varchar2(50)    := i_attach_name;
    t_attach_file_1         blob            := i_attach_file;
    t_attach_name_2         varchar2(50)    := null;
    t_attach_file_2         blob            := null;
    t_email_subj            varchar2(100)   := null;
    t_sent_st               varchar2(1)     := 'N';
    t_sent_err_cd           varchar2(20)    := null;
    t_sent_err_msg          varchar2(500)   := null;

    t_ret                   varchar2(1)     := null;

BEGIN
    /* Steps:
        1. Check if account is registered sending email
        2. Get input values if null
        3. Get message content from input
        4. Validate message content
        5. Insert into xcs01m20
    */

    vn.pxc_log_write(t_proc_nm, '');
    vn.pxc_log_write(t_proc_nm, 'Start pxc_email_ins for: '
                                || 'i_send_dt: '            || i_send_dt
                                || ', i_recv_email_add: '   || i_recv_email_add
                                || ', i_send_email_add: '   || i_send_email_add
                                || ', i_func_cd: '          || i_func_cd
                                || ', i_msg_lang: '         || i_msg_lang
                                || ', i_attach_name: '      || i_attach_name
                                || ', i_acnt_no: '          || i_acnt_no
                                || ', i_func_tp: '          || i_func_tp
                                || ', i_ekyc_seq_no: '      || i_ekyc_seq_no
                                || ', i_msg_lang: '         || i_msg_lang
                                || ', i_msg_lang: '         || i_msg_lang
    );

    vn.pxc_log_write(t_proc_nm, 'i_email_msg: ' || i_email_msg);

    -- Assign value to variable
    t_vwdate := vn.vwdate();
    t_sec_cd := vn.fxc_sec_cd('R');

    /*
    -- 1. Check if account is registered sending email
    begin
        if(i_func_tp = '1' and i_func_cd <> 'F00000' and i_acnt_no is not null) then
            t_email_reg_yn    := vn.fxc_acnt_email_reg_chk(i_acnt_no, i_sub_no, i_func_cd);
        else
            t_email_reg_yn    := 'Y';
        end if;
    exception
        when others then
            vn.Pxc_Log_Write (t_proc_nm, 'Error when getting account email registration: ' || sqlcode || ' - ' || sqlerrm);
            return;
    end;
    */

    if(t_email_reg_yn = 'N') then
        vn.pxc_log_write(t_proc_nm, 
                               'Account: ' || i_acnt_no || '-' || i_sub_no
                            || ' is not registered sending email for: ' || t_func_nm
                        );
        return;
    else
        -- 2. Get input values if null
        begin
            if(i_sub_no is null) then
                t_sub_no := '00';
            end if;

            if(i_send_dt is null) then
                select to_char(sysdate, 'YYYYMMDD') send_dt
                into t_send_dt
                from dual;
            end if;

            if(i_send_email_add is null) then
                /*
                select com_email
                into t_send_email_add
                from vn.xcc99m00
                where test_yn = 'R'
                and rownum = 1;
                */ 
                t_send_email_add := 'ekyc@nhsv.vn';
            end if;

            if(i_recv_email_add is null) then
                t_recv_email_add := vn.faa_acnt_email_g(t_sec_cd, i_acnt_no, t_sub_no);
            end if;

            if(i_msg_lang is null) then
                select decode(acnt_tp, 'F', 'E', 'V') ms_lang
                into t_msg_lang
                from vn.aaa01m00
                where acnt_no = i_acnt_no
                and sub_no = t_sub_no;
            end if;
        exception
            when others then
                vn.Pxc_Log_Write (t_proc_nm, 'Error when replacing NULL input parameter: ' || sqlcode || ' - ' || sqlerrm);
                return;
        end;

        -- Get send name
        select decode(t_msg_lang, 'E', com_nm_email_en, com_nm_email_vn) com_nm
        into t_from_name
        from vn.xcc99m00
        where test_yn =  'R'
        and rownum = 1;

        -- 3. Get message content from input
        t_email_msg_trunc := trim(i_email_msg);
        t_email_msg_trunc := regexp_replace(t_email_msg_trunc, ' {2,}', ' ');
        t_email_msg_trunc := replace(t_email_msg_trunc, ' ||' , '||');
        t_email_msg_trunc := replace(t_email_msg_trunc, '|| ' , '||');

        begin
            t_email_msg := vn.fxc_get_email_msg(
                            i_func_tp,
                            i_func_cd,
                            t_msg_lang,
                            t_email_msg_trunc
                        );
        exception
            when others then
                vn.Pxc_Log_Write (t_proc_nm, 'Error when getting msg content: ' || sqlcode || ' - ' || sqlerrm);
                return;
        end;

        vn.pxc_log_write(t_proc_nm, 't_email_msg: ' || t_email_msg); 

        -- 4. Validate message content
        if trim(t_email_msg) is null then
            if(i_func_tp = '1') then
                vn.pxc_log_write(t_proc_nm, 'Message content is null');
                return;
            else
                t_email_msg := i_email_msg;
            end if;
        end if;

        /*
        if (length(t_email_msg) > t_email_msg_max_sz and i_func_cd <> 'F00000')  then
            vn.pxc_log_write(t_proc_nm, 'Length of message is over: ' || t_email_msg_max_sz);
            return;
        end if;
        */

        -- 5. Get additional email data
        select email_subj
        into t_email_subj
        from vn.xcs01m03 x
        where func_cd = i_func_cd
        and msg_lang = t_msg_lang;

        -- 5. Get attached file
        if (i_func_cd IN ('F01107', 'F01109')) then     -- Hop dong mo tai khoan
            select 
                nvl(i_acnt_no, acnt_no)             acnt_no,
                nvl(i_sub_no, '00')                 sub_no,
                nvl(i_attach_file, cntr_doc)        attach_file, 
                nvl(i_attach_name, cntr_doc_nm)     cntr_doc_nm,
                mrgn_cntr_doc                       mrgn_cntr_doc,
                mrgn_cntr_doc_nm                    mrgn_cntr_doc_nm
            into 
                t_acnt_no,
                t_sub_no,
                t_attach_file_1,
                t_attach_name_1,
                t_attach_file_2,
                t_attach_name_2
            from vn.aaa05m00 
            where seq_no = i_ekyc_seq_no;
        end if;

        -- 6. Insert into xcs01m20
        vn.pxc_log_write(t_proc_nm, 'Start inserting into xcs01m20');

        begin
            t_seq_no := vn.xcs01m20_seq.nextval;

            insert into vn.xcs01m20(
                seq_no,
                dt,
                acnt_no,
                sub_no,
                sent_st,
                sent_dtm,
                sent_err_cd,
                sent_err_msg,
                func_cd,
                email_subj,
                send_email_add,
                recv_email_add,
                send_email_nm,
                recv_email_nm,
                email_msg,
                attach_name,
                attach_file,
                attach_name_2,
                attach_file_2,
                email_lang,
                email_tp,
                create_mn,
                create_dtm,
                create_trm,
                work_mn,
                work_dtm,
                work_trm
            )
            values(
                t_seq_no,                   -- seq_no,
                t_vwdate,                   -- dt,
                t_acnt_no,                  -- acnt_no,
                t_sub_no,                   -- sub_no,
                t_sent_st,                  -- sent_st,
                sysdate,                    -- sent_dtm,
                null,                       -- sent_err_cd,
                null,                       -- sent_err_msg,
                i_func_cd,                  -- func_cd,
                t_email_subj,               -- email_subj,
                t_send_email_add,           -- send_email_add,
                t_recv_email_add,           -- recv_email_add,
                t_from_name,                -- send_email_nm,
                t_to_name,                  -- recv_email_nm,
                t_email_msg,                -- email_msg,
                t_attach_name_1,            -- attach_name,
                t_attach_file_1,            -- attach_file,
                t_attach_name_2,            -- attach_name_2,
                t_attach_file_2,            -- attach_file_2,
                t_msg_lang,                 -- email_lang,
                i_func_tp,                  -- email_tp,
                i_work_mn,                  -- create_mn,
                sysdate,                    -- create_dtm,
                i_work_trm,                 -- create_trm,
                null,                       -- work_mn,
                null,                       -- work_dtm,
                null                        -- work_trm
            );

        exception
            when others then
                t_err_msg  := 'Error when inserting into xcs01m20: ' || sqlcode || ' - ' || sqlerrm;
                -- raise_application_error(-20100,t_err_msg);
                vn.pxc_log_write(t_proc_nm, t_err_msg);

                return;
        end;

        -- 7. Send email
        vn.pxc_log_write(t_proc_nm, 'Start calling fxc_send_mail_w_attach');

        begin
            t_sent_st := 'Y';

            select 
                vn.fxc_send_mail_w_attach (
                    t_sec_cd,
                    t_send_email_add,
                    t_recv_email_add,
                    t_email_subj,
                    t_email_msg,
                    t_from_name,
                    t_to_name,
                    t_attach_name_1,
                    t_attach_file_1,
                    t_attach_name_2,
                    t_attach_file_2
                ) a
            into t_ret
            from dual;
        exception
            when others then
                vn.Pxc_Log_Write (t_proc_nm, 'Error when calling fxc_send_mail_w_attach: ' || sqlcode || ' - ' || sqlerrm);
                t_sent_st := 'N';
        end;

        -- 8. Update sending status
        update vn.xcs01m20
        set
            sent_st         = t_sent_st,
            sent_err_cd     = t_sent_err_cd,
            sent_err_msg    = t_sent_err_msg,
            work_mn         = i_work_mn,
            work_dtm        = sysdate,
            work_trm        = i_work_mn
        where seq_no = t_seq_no;

        if(t_sent_st = 'Y') then
            vn.pxc_log_write(
                t_proc_nm, 
                'Sending email successfully to: ['    || t_recv_email_add  || '],'
                || ' email_msg['                      || t_email_msg        || ']'
            );
        end if;

    end if;

    vn.pxc_log_write(t_proc_nm, 'End.');

end pxc_email_ins;
/

