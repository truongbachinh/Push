create FUNCTION    fdl_get_sec_lnd_use_qty(
    i_acnt_no       VARCHAR2,
    i_sub_no        VARCHAR2,
    i_basket_cd     VARCHAR2,
    i_stk_cd        VARCHAR2
)
RETURN NUMBER AS
    
    t_priv_policy_chk   VARCHAR2(1)     := '1';
    t_priv_id           NUMBER          := NULL;

    t_acnt_get_grp_no   VARCHAR2(5)     := NULL;
    t_stk_lnd_qty       NUMBER          := 0;

    t_vwdate            VARCHAR2(8)     := NULL;

    t_err_msg           VARCHAR2(500)   := '';
BEGIN

    t_vwdate    := vn.vwdate();
    --Lay ma nhom TK Margin
    t_acnt_get_grp_no := vn.faa_acnt_get_grp_no(i_acnt_no,
                                                i_sub_no,
                                                '2',
                                                t_vwdate);

    --Lay CRS Ro DLM71M03
    BEGIN
        SELECT id
        INTO t_priv_id
        FROM vn.dlm71m03 d3
        WHERE d3.acnt_no = i_acnt_no
        AND d3.sub_no = i_sub_no
        AND d3.grp_acnt_no = t_acnt_get_grp_no
        AND d3.basket_cd = i_basket_cd
        AND d3.stk_cd = i_stk_cd
        AND d3.apy_dt <= t_vwdate
        AND d3.expr_dt >= t_vwdate
        AND d3.active_stat = 'Y';
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            t_priv_policy_chk := '0';

        WHEN OTHERS THEN
        t_err_msg := vn.fxc_get_err_msg('V', '46052');
        vn.pxc_log_write('fdl_get_sec_lnd_use_qty',
                        ' stk_cd error: ' || t_err_msg || ' stk_cd=' ||
                        i_stk_cd || '-' || i_acnt_no || '-' || i_sub_no);
        raise_application_error(-20100,
                                t_err_msg ||
                                ' fdl_get_sec_lnd_use_qty: stk_cd_i_tp=' ||
                                i_stk_cd || '-' || i_acnt_no || '-' ||
                                i_sub_no);
    END;

    IF t_priv_policy_chk <> '0' THEN -- co CRS
        --B2: xac dinh so luong CK da dung: 
        BEGIN
            SELECT SUM(nvl(lnd_use_qty, 0)) + SUM(nvl(lnd_expt_qty, 0))
            INTO t_stk_lnd_qty
            FROM vn.dlm09m11
            WHERE acnt_no = i_acnt_no
            AND sub_no = i_sub_no
            AND grp_acnt_no = t_acnt_get_grp_no
            AND basket_cd = i_basket_cd
            AND stk_cd = i_stk_cd;
        EXCEPTION
            WHEN OTHERS THEN
                t_stk_lnd_qty := 0;
        END;
    ELSE --Khong co CSR
        BEGIN
            SELECT SUM(nvl(lnd_use_qty, 0)) + SUM(nvl(lnd_expt_qty, 0))
            INTO t_stk_lnd_qty
            FROM vn.dlm09m11
            WHERE basket_cd = i_basket_cd
            AND stk_cd = i_stk_cd;
        EXCEPTION
            WHEN OTHERS THEN
            t_stk_lnd_qty := 0;
        END;
    END IF;

    RETURN nvl(t_stk_lnd_qty, 0);

END fdl_get_sec_lnd_use_qty;
/

