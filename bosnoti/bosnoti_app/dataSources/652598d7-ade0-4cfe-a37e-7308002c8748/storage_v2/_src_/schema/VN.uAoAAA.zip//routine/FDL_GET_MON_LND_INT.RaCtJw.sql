create function    fdl_get_mon_lnd_int
(
    i_lnd_tp          in   varchar2,        --
    i_acnt_no         in   varchar2,        --
    i_sub_no          in   varchar2,        --
    i_lnd_bank_cd     in   varchar2,        --
    i_int_tp          in   varchar2,        -- 1:int 2:dly_int 3:all
    i_lnd_dt          in   varchar2,        --
    i_rpy_dt          in   varchar2,        --
    i_expr_dt         in   varchar2,        --
    i_last_rpy_dt     in   varchar2,        --
    i_remn_amt        in   number,           --
    i_cpt_rpy_tp      in   varchar2,        --
    i_int_rpy_tp      in   varchar2,        --
    i_int_calc_apy_tp in   varchar2         -- 1:fixed ratio 2:Dynamic ratio

)
    return  number
as

    t_last_rpy_dt           VARCHAR2(8) := null;

    t_lnd_int_cal_std_term	NUMBER := 0;
	t_lnd_int_min_term    	NUMBER := 0;
	t_lnd_int_rt            NUMBER := 0; -- 01:lnd_int ratio
	t_lnd_int_rt_min        NUMBER := 0; -- 02:lnd_int ratio for min duration
	t_lnd_int_amt_min       NUMBER := 0; -- 03:min lnd_int amt
	t_lnd_int_rt_dly        NUMBER := 0; -- 04:lnd_int dly_rt
	t_lnd_fee_rt            NUMBER := 0; -- 11:lnd_fee ratio
	t_lnd_fee_rt_min        NUMBER := 0; -- 12:lnd_fee ratio for min duration
	t_lnd_fee_amt_min       NUMBER := 0; -- 13:min lnd_fee amt
	t_lnd_fee_rt_dly        NUMBER := 0; -- 14:min lnd_fee amt

    t_tot_prd               NUMBER := 0;
    t_lnd_prd               NUMBER := 0;
    t_dly_prd               NUMBER := 0;
    t_lnd_int               NUMBER := 0;
    t_lnd_int_dly           NUMBER := 0;

    t_lnd_int_cnt           NUMBER := 0;
	t_lnd_int_cmp_cnt       NUMBER := 0;
	t_lnd_int_cmp_cnt2      NUMBER := 0;

	t_pre_apy_dt            VARCHAR2(08) := null;

	t_int_calc_apy_tp       NUMBER := 0;
	t_lnd_int_prd           NUMBER := 0;

	o_lnd_int               NUMBER := 0;
    t_err_txt               VARCHAR2(80); -- error text buffer

    t_mrgn_levl				VARCHAR2(2)	:= NULL;

    ts_chg_dt               VARCHAR2(8) := NULL;
    t_sec_cd				varchar2(3) := '068';

begin
    return o_lnd_int;

end fdl_get_mon_lnd_int;
/

