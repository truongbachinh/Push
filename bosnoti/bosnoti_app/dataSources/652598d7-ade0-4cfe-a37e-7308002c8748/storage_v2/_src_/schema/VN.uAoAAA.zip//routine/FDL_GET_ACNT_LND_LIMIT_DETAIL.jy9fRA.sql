create FUNCTION    fdl_get_acnt_lnd_limit_detail(
    i_acnt_no       VARCHAR2,
    i_sub_no        VARCHAR2,
    i_stk_cd        VARCHAR2
)
RETURN SYS_REFCURSOR
AS

/* ************************************************************************************************
    Author:         hphan
    Created Date:   12-Jul-2018
    Description:    This function is used to get lend limit details of an account.

    Sample call:
        SELECT fdl_get_acnt_lnd_limit_detail('068C332211', '01', 'AAA') o_val
        FROM DUAL;

    MODIFICATION DETAILS:
    -------------------------------------------------------------------------------------------------
    Modified Date   Modified By       Modification Details
    -------------------------------------------------------------------------------------------------
    12-Jul-2018     hphan             Initial creation
    24-Jun-2021     TienLH

**************************************************************************************************/

    -- Declare variable
    t_vwdate                VARCHAR2(8);
    t_sec_cd                VARCHAR2(5);
    t_day_tp                VARCHAR2(1) := '1';
    t_grp_acnt_tp           VARCHAR2(2) := '08';
    t_prd_tp                VARCHAR2(2) := '02';
    t_src_tp                VARCHAR2(2) := '03';
    o_cnt_src_sec           NUMBER  := 0;
    o_cnt_src_out_sec       NUMBER  := 0;
    o_acnt_limit            NUMBER  := 0;
    o_check                 VARCHAR2(2) := 'Y';

    t_ssc_lnd_limit_qty     NUMBER  := NULL;
    t_ssc_lnd_limit_amt     NUMBER  := NULL;

    t_cust_max_amt          NUMBER  := 0;
    t_all_src_max_limit     NUMBER  := 0;

    c_cursor                SYS_REFCURSOR;

    t_err_msg    varchar2(500) := null;

BEGIN

    -- Bat dau ghi log
    vn.pxc_log_write('fdl_get_acnt_lnd_limit_detail', '');
    vn.pxc_log_write('fdl_get_acnt_lnd_limit_detail', 'START fdl_get_acnt_lnd_limit_detail cho: ');

    vn.pxc_log_write('fdl_get_acnt_lnd_limit_detail',
                        'i_acnt_no = '  || i_acnt_no
                    ||  ', i_sub_no = ' || i_sub_no
                    ||  ', i_stk_cd = ' || NVL(i_stk_cd, '')
                    );

    t_vwdate := vn.vwdate();

    -- Lay ma cong ty chung khoan
    BEGIN
        SELECT vn.fxc_sec_cd('R')
        INTO t_sec_cd
        FROM DUAL;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        t_sec_cd      := '000';
    END;

    -- Lay nguon cua tk
    BEGIN
    vn.pdl_src_count( i_acnt_no
                     , i_sub_no
                     , o_cnt_src_sec
                     , o_cnt_src_out_sec);
    EXCEPTION
    WHEN OTHERS THEN
        t_err_msg := vn.fxc_get_err_msg('V','2157');
        raise_application_error(-20100,t_err_msg||' Acnt_no - '||i_acnt_no||'-'||i_sub_no);
    END;

    -- Lay han muc toan tk
    BEGIN
        vn.pdl_get_lnd_all_sub_limit(i_acnt_no, o_acnt_limit);
    EXCEPTION
    WHEN OTHERS THEN
        t_err_msg := vn.fxc_get_err_msg('V','46053');
        raise_application_error(-20100,t_err_msg||' Acnt_no - '||i_acnt_no||'-'||i_sub_no);
    END;

    -- Kiem tra csr va csc cho han muc tai khoan
    BEGIN
        SELECT MIN(nvl(cust_max_amt, 0))
        INTO t_cust_max_amt
        FROM vn.dlm20m06 t
        WHERE  t.apy_dt <= t_vwdate
            AND t.expr_dt >= t_vwdate
            AND ACTIVE_STAT='Y'
            AND t.acnt_no LIKE i_acnt_no;
    EXCEPTION
    WHEN no_data_found THEN
        BEGIN
            SELECT TO_NUMBER(nvl(col_cd_tp, 0))
            INTO t_all_src_max_limit
            FROM vn.xcc01c02 a
            WHERE  a.col_cd LIKE 'all_src_max_limit'
                AND a.param_tp LIKE '401';
        EXCEPTION
            WHEN no_data_found THEN
                o_check := 'N';
            WHEN OTHERS THEN
            t_err_msg := vn.fxc_get_err_msg('V', '46054');
            vn.pxc_log_write('pdl_get_acnt_max_limit',
                                ' Select xcc01c02 error: ' || t_err_msg ||
                                ' col_cd= all_src_max_limit' );
        END;
    WHEN OTHERS THEN
        t_err_msg := vn.fxc_get_err_msg('V', '46053');
        vn.pxc_log_write('pdl_get_acnt_max_limit',
                        ' Tong han muc cua tai khoan error: ' || t_err_msg || ' ACNT_NO=' || i_acnt_no);
        raise_application_error(-20100,
                                t_err_msg ||
                                ' pdl_get_acnt_max_limit: ACNT_NO_STK_i_tp=' || i_acnt_no);
    END;

    -- Lay han muc con lai cua cty theo ma ck
    IF(i_stk_cd IS NOT NULL) THEN
        t_ssc_lnd_limit_qty := vn.fdl_get_ssc_lnd_limit_qty(i_stk_cd);
        t_ssc_lnd_limit_amt := vn.fdl_get_ssc_lnd_limit_amt(i_stk_cd);
    END IF;

    OPEN c_cursor FOR
        WITH acnt_rel AS(           -- Danh sach tai khoan, nhom TK, san pham, nguon, ro ck
            SELECT DISTINCT
                d51.acnt_no,
                d51.sub_no,
                i_stk_cd    stk_cd,
                d51.grp_acnt_no,
                d90.prd_no,
                d00.src_no,
                d00.lnd_tp,
                vn.faa_acnt_get_basket_cd(t_sec_cd, d51.acnt_no, d51.sub_no, d51.grp_acnt_no, t_vwdate) basket_cd
            FROM
                vn.dlm51m00 d51,
                vn.dlm90m00 d90,
                vn.dlm00m01 d00
            WHERE d51.acnt_no LIKE i_acnt_no
            AND d51.sub_no LIKE i_sub_no
            AND d51.active_stat = 'Y'
            AND (d51.acnt_no, d51.sub_no, d51.apy_dt) IN (  SELECT y.acnt_no, y.sub_no, MAX(y.apy_dt)
                                                            FROM vn.dlm51m00 y
                                                            WHERE y.acnt_no LIKE i_acnt_no
                                                            AND y.sub_no LIKE i_sub_no
                                                            AND y.apy_dt <= t_vwdate
                                                            GROUP BY y.acnt_no, y.sub_no)
            AND d51.grp_acnt_no = d90.grp_acnt_no
            AND d90.active_stat = 'Y'
            AND d90.apy_dt <= t_vwdate
            AND d90.expr_dt >= t_vwdate
            AND d90.prd_no = d00.item_cd
            AND d00.item_tp = '02'
            AND exists
                      (select 1
                        FROM vn.dlm71m00
                        WHERE grp_acnt_no = d51.grp_acnt_no
                        AND t_vwdate BETWEEN apy_dt AND expr_dt
                        AND active_stat = 'Y'
                      )
        ),
        ret AS(                     -- Thong tin han muc
            SELECT
                acnt_no,
                sub_no,
                stk_cd,
                grp_acnt_no,
                prd_no,
                src_no,
                lnd_tp,
                basket_cd,

                -- Han muc toi da cua Nhom TK, San pham, Nguon
                vn.fdl_get_item_tot_lnd_limit(t_grp_acnt_tp, grp_acnt_no, t_day_tp)                     grp_acnt_lnd_limit_max,
                vn.fdl_get_item_tot_lnd_limit(t_prd_tp, prd_no, t_day_tp)                               prd_lnd_limit_max     ,
                vn.fdl_get_item_tot_lnd_limit(t_src_tp, src_no, t_day_tp)                               src_lnd_limit_max     ,

                -- Han muc duoc su dung cua Nhom TK, San pham, Nguon
                vn.fdl_get_grp_acnt_lnd_use_amt(grp_acnt_no, t_day_tp)                                  grp_acnt_lnd_use_amt,
                vn.fdl_get_prd_lnd_use_amt(prd_no, t_day_tp)                                            prd_lnd_use_amt     ,
                vn.fdl_get_src_lnd_use_amt(src_no, t_day_tp)                                            src_lnd_use_amt     ,

                -- Han muc toi da cua tai khoan theo Nhom TK, San pham, Nguon
                vn.fdl_get_acnt_max_amt_by_item(acnt_no, sub_no, t_grp_acnt_tp, grp_acnt_no, t_day_tp)  acnt_grp_acnt_lnd_limit_max,
                vn.fdl_get_acnt_max_amt_by_item(acnt_no, sub_no, t_prd_tp, prd_no, t_day_tp)            acnt_prd_lnd_limit_max     ,
                vn.fdl_get_acnt_max_amt_by_item(acnt_no, sub_no, t_src_tp, src_no, t_day_tp)            acnt_src_lnd_limit_max     ,

                -- Han muc duoc su dung cua tai khoan theo Nhom TK, San pham, Nguon
                vn.fdl_get_acnt_lnd_use_amt(acnt_no, sub_no, t_grp_acnt_tp, grp_acnt_no, t_day_tp)      acnt_grp_acnt_lnd_use_amt,
                vn.fdl_get_acnt_lnd_use_amt(acnt_no, sub_no, t_prd_tp, prd_no, t_day_tp)                acnt_prd_lnd_use_amt     ,
                vn.fdl_get_acnt_lnd_use_amt(acnt_no, sub_no, t_src_tp, src_no, t_day_tp)                acnt_src_lnd_use_amt     ,

                -- Han muc toi da TK theo VCSH
                vn.fdl_get_sec_lnd_info(t_vwdate, '06')                                                 acnt_vcsh_limit_amt,
                vn.fdl_get_mrgn_expt_amt(acnt_no, '%', '3')                                             acnt_lnd_use_amt,

                -- Han muc con lai cua toan bo cac ma ck
                vn.fdl_get_acnt_stk_all_lnd_limit(acnt_no, sub_no)                                      stk_sum_lnd_limit,

                --  Tong han muc cua TK
                o_acnt_limit                                                                            lnd_all_sub_limit,

                -- Han muc toi da cua ma chung khoan theo Ro CK
                CASE
                    WHEN i_stk_cd IS NULL THEN NULL
                    ELSE vn.fdl_get_acnt_stk_bsk_max_amt(acnt_no, sub_no, basket_cd, stk_cd)
                END                                                                                     stk_basket_lnd_limit_max,

                -- Han muc duoc su dung cua ma chung khoan theo Ro CK

                CASE
                    WHEN i_stk_cd IS NULL THEN NULL
                    ELSE vn.fdl_get_acnt_stk_bsk_lnd_use(acnt_no, sub_no, basket_cd, stk_cd)
                END                                                                                     stk_basket_lnd_use_amt,

                -- Han muc room
                CASE
                    WHEN i_stk_cd IS NULL THEN NULL
                    ELSE vn.fdl_get_sec_stk_max_qty(acnt_no, sub_no, basket_cd, stk_cd)
                END                                                                                     stk_basket_lnd_limit_qty_max,

                CASE
                    WHEN i_stk_cd IS NULL THEN NULL
                    ELSE vn.fdl_get_sec_lnd_use_qty(acnt_no, sub_no, basket_cd, stk_cd)
                END                                                                                     stk_basket_lnd_use_qty

            FROM acnt_rel a
        )
        SELECT
            acnt_no,                                        -- 1    So tai khoan
            sub_no,                                         -- 2    Sub
            stk_cd,                                         -- 3    Ma chung khoan
            grp_acnt_no,                                    -- 4    Nhom TK
            prd_no,                                         -- 5    Ma SP
            src_no,                                         -- 6    Ma Nguon
            basket_cd,                                      -- 7    Ma Ro

            grp_acnt_lnd_limit_max,                         -- 8    HM toi da nhom TK
            grp_acnt_lnd_use_amt,                           -- 9    HM duoc su dung con lai nhom TK
            NVL(grp_acnt_lnd_limit_max
                - grp_acnt_lnd_use_amt, 0)
                    AS grp_acnt_lnd_limit_rem,              -- 10   HM toi da con lai nhom TK

            prd_lnd_limit_max,                              -- 11   HM toi da SP
            prd_lnd_use_amt,                                -- 12   HM duoc su dung con lai SP
            NVL(prd_lnd_limit_max
                - prd_lnd_use_amt, 0)
                    AS prd_lnd_limit_rem,                   -- 13   HM toi da con lai SP

            src_lnd_limit_max,                              -- 14   HM toi da Nguon
            src_lnd_use_amt,                                -- 15   HM duoc su dung con lai Nguon
            NVL(src_lnd_limit_max
                - src_lnd_use_amt, 0)
                    AS src_lnd_limit_rem,                   -- 16   HM toi da con lai Nguon

            acnt_grp_acnt_lnd_limit_max,                    -- 17   HM toi da TK theo nhom TK
            acnt_grp_acnt_lnd_use_amt,                      -- 18   HM duoc su dung TK theo nhom TK
            NVL(acnt_grp_acnt_lnd_limit_max
                - acnt_grp_acnt_lnd_use_amt, 0)
                    AS acnt_grp_acnt_lnd_limit_rem,         -- 19   HM con lai TK theo nhom TK

            acnt_prd_lnd_limit_max,                         -- 20   HM toi da TK theo SP
            acnt_prd_lnd_use_amt,                           -- 21   HM duoc su dung TK theo SP
            NVL(acnt_prd_lnd_limit_max
                - acnt_prd_lnd_use_amt, 0)
                    AS acnt_prd_lnd_limit_rem,              -- 22   HM con lai TK theo SP

            acnt_src_lnd_limit_max,                         -- 23   HM toi da TK theo Nguon
            acnt_src_lnd_use_amt,                           -- 24   HM duoc su dung TK theo Nguon
            NVL(acnt_src_lnd_limit_max
                - acnt_src_lnd_use_amt, 0)
                    AS acnt_src_lnd_limit_rem,              -- 25   HM con lai TK theo Nguon

            LEAST(
                NVL(acnt_prd_lnd_limit_max      - acnt_prd_lnd_use_amt,      0),
                NVL(acnt_src_lnd_limit_max      - acnt_src_lnd_use_amt,      0),
                NVL(prd_lnd_limit_max           - prd_lnd_use_amt,           0),
                NVL(src_lnd_limit_max           - src_lnd_use_amt,           0)
                )   lnd_limit_rem,                          -- 26   HM con lai

            stk_basket_lnd_limit_max,                       -- 27   HM toi da ma CK theo Ro CK
            stk_basket_lnd_use_amt,                         -- 28   HM duoc su dung ma CK theo Ro CK
            stk_basket_lnd_limit_max
                - stk_basket_lnd_use_amt
                    AS stk_basket_lnd_limit_rem,            -- 29   HM con lai ma CK theo Ro CK

            stk_basket_lnd_limit_qty_max,                   -- 30   HM room toi da
            stk_basket_lnd_use_qty,                         -- 31   HM room duoc su dung
            stk_basket_lnd_limit_qty_max
                - stk_basket_lnd_use_qty
                    AS stk_basket_lnd_limit_qty_rem,        -- 32   HM room con lai
            t_ssc_lnd_limit_amt,                            -- 33   HM vay Margin con lai theo ma toan cty
            t_ssc_lnd_limit_qty,                            -- 34   HM so luong con lai theo ma toan cty
            acnt_vcsh_limit_amt,                            -- 35   HM 1 tk tren vcsh
            acnt_lnd_use_amt,                               -- 36   HM vay da dung cua tk
            GREATEST(acnt_vcsh_limit_amt - acnt_lnd_use_amt, 0),         -- 37   HM 1 tk tren vcsh con lai
            lnd_all_sub_limit,                              -- 38   HM tong cua tk
            acnt_lnd_use_amt,                               -- 39   HM vay da dung cua tk
            GREATEST(lnd_all_sub_limit - acnt_lnd_use_amt, 0),           -- 40   HM tong cua tk con lai
            stk_sum_lnd_limit,                              -- 41   HM con lai tong cac ma ck
            decode(o_cnt_src_sec, 1, '70',  ''),            -- 42   Phan loai vay nguon trong
            decode(o_cnt_src_out_sec, 1, '80', ''),         -- 43   Phan loai vay nguon ngoai
            o_check                                        -- 44   Bien check
        FROM ret
        ORDER BY
            acnt_no,
            sub_no,
            stk_cd,
            grp_acnt_no,
            prd_no,
            src_no,
            basket_cd
        ;

    RETURN c_cursor;

END;
/

