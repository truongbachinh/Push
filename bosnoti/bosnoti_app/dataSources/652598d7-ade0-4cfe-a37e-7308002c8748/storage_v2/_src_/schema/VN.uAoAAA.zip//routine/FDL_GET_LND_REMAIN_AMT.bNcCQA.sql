create function fdl_get_lnd_remain_amt(
    i_acnt_no   varchar2,
    i_sub_no    varchar2,
    i_lnd_tp    varchar2
)
return number
as
    t_proc_nm       varchar2(50)    := 'fdl_get_lnd_remain_amt';
    t_lnd_rm_amt    number          := 0;
    t_err_msg       varchar2(500)   := '';

    -- output
    o_lnd_rm_amt    number;

begin
    begin
        select round(sum(nvl(lnd_amt, 0) - nvl(lnd_rpy_amt, 0))) lnd_rm_amt
        into t_lnd_rm_amt
        from vn.dlm01m00
        where acnt_no = i_acnt_no
        and sub_no = i_sub_no
        and lnd_tp like i_lnd_tp
        and lnd_amt > lnd_rpy_amt;
    exception
        when no_data_found then
            t_lnd_rm_amt := 0;
        when others then
            t_err_msg := 'Error when getting data for account ' || i_acnt_no || '-' || i_sub_no
                            || '. Error detail: ' || sqlcode || ' - ' || sqlerrm;
            raise_application_error(-20100,t_err_msg);
            vn.pxc_log_write(t_proc_nm, t_err_msg);
    end;

    o_lnd_rm_amt    := nvl(t_lnd_rm_amt, 0);

    return o_lnd_rm_amt;

end; -- fdl_get_lnd_remain_amt
/

