create procedure psr_cal_rgt_sbst_p
( i_proc_dt   in  varchar2,
  i_acnt_no   in  varchar2,   
  i_sub_no    in  varchar2,   
  i_work_mn   in  varchar2,
  i_work_trm  in  varchar2
 ) is

 tn_reuse_rt  number := 0 ;
 tn_rt_sbst_dpo  number := 0 ;
 t_err_msg    varchar2(200) ;
 o_proc_cnt 	number := 0 ;

begin

 vn.pxc_log_write('psr_cal_rgt_sbst_p', ' acnt_no : ' || i_acnt_no  );
 vn.pxc_log_write('psr_cal_rgt_sbst_p', ' sub_no  : ' || i_sub_no  );

 update vn.cwd01m00
    set rgt_sbst = 0
       ,rgt_reuse = 0
  where acnt_no = i_acnt_no
	and sub_no  = i_sub_no;

 for sr1 in (

      select  x.acnt_no                                                                                     acnt_no  ,
			        x.sub_no                                                                                      sub_no   ,                                  
              nvl(sum(x.rgt_sbst),  0 ) * vn.fdl_get_mrgn_grp_acnt_rt( x.acnt_no , x.sub_no,x.acnt_grp_no,'02' , vn.vwdate )  rgt_sbst ,
              nvl(sum(x.reuse_amt), 0 ) * vn.fdl_get_mrgn_grp_acnt_rt( x.acnt_no , x.sub_no,x.acnt_grp_no,'02' , vn.vwdate )  reuse_amt
       from
         ( select a.acnt_no acnt_no ,
				  a.sub_no  sub_no  ,
          vn.faa_acnt_get_grp_no(a.acnt_no,a.sub_no ,'1',vn.vwdate)                        acnt_grp_no ,   
                   Decode( c.rgt_tp , '1' , Decode ( a.inq_trd_no , 0 ,  nvl(a.cons_sbst_qty ,0 ) , 0 ) ,
						   Decode   ( a.INQ_TRD_NO   , 0 , nvl(a.asn_qty  ,0)  , 0 ))
                   * vn.fss_get_td_cls_pri( a.stk_cd)
                   * VN.fdl_get_mrgn_basket_rt(a.acnt_no ,a.sub_no ,null,null, a.stk_cd  ,'06',i_proc_dt   )  rgt_sbst   ,

                  (  Decode(a.FLOTQ_TRD_NO , 0 , nvl(a.flotq_amt,0) , 0 )
                   + Decode(a.RCPT_TRD_NO  , 0 , nvl(a.asn_amt  ,0) , 0 )
                   + Decode(a.INTER_TRD_NO , 0 , nvl(a.inter_amt,0) , 0 ) )
                   * VN.fdl_get_mrgn_basket_rt(a.acnt_no ,a.sub_no ,null,null, a.stk_cd  ,'08',i_proc_dt   )   reuse_amt
             from vn.srr02m00 a ,
                  vn.aaa01m00 b ,
                  vn.srr01m00 c
            where a.rgt_std_dt  = c.rgt_std_dt
              and a.rgt_tp      = c.rgt_tp
              and a.stk_cd      = c.stk_cd
              and a.seq_no      = c.seq_no
              and a.rgt_tp      <> '8'
              and c.rgt_proc_stat >= '3'
              and a.acnt_no      =    b.acnt_no
			  and a.sub_no       =    b.sub_no
			  and a.acnt_no      =    i_acnt_no
			  and a.sub_no       =    i_sub_no
              and b.acnt_stat    =   '1'
              and c.rgt_tp in ( '1','2','3','9')

           union all

           select a.acnt_no acnt_no ,
				  a.sub_no  sub_no  ,
          vn.faa_acnt_get_grp_no(a.acnt_no,a.sub_no ,'1',vn.vwdate)                        acnt_grp_no , 
                  Decode( a.inq_trd_no   , 0  , nvl(a.asn_qty   ,0)  , 0 )
                   * vn.fss_get_td_cls_pri( d.cnvt_stk_cd)
                  * VN.fdl_get_mrgn_basket_rt(a.acnt_no ,a.sub_no ,null,null, a.stk_cd  ,'06',i_proc_dt   )  rgt_sbst     ,

                  Decode( a.FLOTQ_TRD_NO , 0  , nvl(a.flotq_amt ,0)  , 0 )
                   * VN.fdl_get_mrgn_basket_rt(a.acnt_no ,a.sub_no ,null,null, a.stk_cd  ,'08',i_proc_dt   ) reuse_amt
              from vn.srr02m00 a ,
                   vn.aaa01m00 b ,
                   vn.srr01m10 d
             where a.rgt_std_dt =  d.rgt_std_dt
              and  a.rgt_tp     =  '8'
              and  a.stk_cd     =  d.stk_cd
              and  a.acnt_no    =  b.acnt_no
			  and  a.sub_no     =  b.sub_no
			  and  a.acnt_no    =  i_acnt_no
			  and  a.sub_no     =  i_sub_no
              and  b.acnt_stat  = '1'
              and  d.rgt_proc_stat >= '3'
           ) x
     where  rgt_sbst > 0 or reuse_amt > 0
     group by x.acnt_no, x.sub_no ,x.acnt_grp_no
     order by 1

 ) loop

   vn.pxc_log_write('psr_cal_rgt_sbst_p', '[ rgt_reuse : '||trunc( sr1.reuse_amt ) ||' rgt_sbst : ' || Trunc( sr1.rgt_sbst  )  );

   update  vn.cwd01m00
     set   rgt_reuse = trunc( sr1.reuse_amt )
          ,rgt_sbst  = Trunc( sr1.rgt_sbst  )
		      ,work_mn   = i_work_mn
   where   acnt_no   = sr1.acnt_no
	 and   sub_no    = sr1.sub_no;


 end loop ;
 vn.pss_cal_sbst_p(i_proc_dt,i_acnt_no,i_sub_no,i_work_mn,o_proc_cnt);

end  psr_cal_rgt_sbst_p;
/

