create function    fdl_get_pay_cmsn
(
    i_lnd_tp          in     varchar2,        --
    i_lnd_bank_cd     in     varchar2,        --
    i_acnt_no         in     varchar2,        --
    i_sub_no          in     varchar2,        --
    i_lnd_dt          in     varchar2,        --
    i_rpy_dt          in     varchar2,        --
    i_lnd_amt         in     number,          --
    i_rpy_amt         in     number,          --
    i_lnd_cmsn_rt     in     number           --
) return number AS
/*============================================================================*/
-- 1. Process Name : fdl_get_pay_cmsn                                         --
-- 2. Process func : lnd_commission calculation                               --
-- 3. developer    :                                                          --
-- 4. modifier     :                                                          --
-- 5. note         : w_04511 em_lnd_amt, em_lnd_fee_rt double click use       --
/*============================================================================*/

/*!
   \file     fdl_get_pay_cmsn.sql
   \brief    commision calculation

   \section intro Program Information
        - Program Name              : commision calculation
        - Service Name              : dl_04513_p1.pc
        - Related Client Program- Client Program ID : w_04513
        - Related Tables            : dsc08m00
        - Dev. Date                 : 2007/11/08
        - Developer                 : Han.
        - Business Logic Desc.      : commision calculation
        - Latest Modification Date  : 2007/11/08

   \section history Program Modification History
    - 1.0       2007/11/08     Han.    New.

   \section hardcoding Hard-Coding List
    - HC-1      2007/11/08     Han.    [??]

   \section info Additional Reference Comments
    - ??????????

select vn.fdl_get_pay_cmsn('10','8888','055C000002','20080513','20080514',0,10000000, 0.0005) from dual;
*/

    t_apy_dt           VARCHAR2(8) := NULL;
    t_apy_val          NUMBER      := 0;
    t_lnd_prd          NUMBER      := 0;
    t_lnd_cmsn         NUMBER      := 0;

    t_lnd_cmsn_rt      NUMBER      := 0;
    t_lnd_cmsn_term    NUMBER      := 0;
    t_min_lnd_cmsn     NUMBER      := 0;

    t_lnd_dt           VARCHAR2(8) := NULL;
    t_rpy_dt           VARCHAR2(8) := NULL;

    o_lnd_cmsn         NUMBER      := 0;

    t_sqlcode          NUMBER      := 0;
    t_err_msg          VARCHAR2(500);

begin

    o_lnd_cmsn := 0;

/*============================================================================*/
/* ( Calculateion )                                                           */
/*============================================================================*/
    /* Loan date */
    t_lnd_dt    :=  i_lnd_dt;
    t_rpy_dt    :=  i_rpy_dt;


    /*========================================================================*/
    /* ( Get Loan fee ratio )                                                 */
    /*========================================================================*/
    vn.pdl_get_lnd_cmsn_rt
        ( i_lnd_tp       ,
          i_lnd_bank_cd  ,
          i_acnt_no      ,
          i_sub_no       ,
          i_lnd_dt       ,
          i_rpy_dt       ,
          t_lnd_cmsn_rt  ,
          t_lnd_cmsn_term,
          t_min_lnd_cmsn );

    /* For VIP */
    if i_lnd_cmsn_rt <> t_lnd_cmsn_rt and i_lnd_cmsn_rt > 0 then
        t_lnd_cmsn_rt := i_lnd_cmsn_rt;
    end if;

    /*========================================================================*/
    /* ( Get Loan period )                                                    */
    /*========================================================================*/
    t_lnd_prd := greatest(to_date(t_rpy_dt,'yyyymmdd')-to_date(t_lnd_dt,'yyyymmdd') ,0);

    /*========================================================================*/
    /* ( Get Loan fee )                                                       */
    /*========================================================================*/
    if i_lnd_tp = '10' then
        if(t_lnd_prd = 0) then
            t_min_lnd_cmsn := 0;
        end if;

        o_lnd_cmsn := greatest( round(i_rpy_amt * (t_lnd_cmsn_rt / t_lnd_cmsn_term) * t_lnd_prd) , t_min_lnd_cmsn);
    else
        o_lnd_cmsn := round(i_rpy_amt * t_lnd_cmsn_rt * t_lnd_prd / t_lnd_cmsn_term);
    end if;

    return o_lnd_cmsn;

end fdl_get_pay_cmsn;
/

