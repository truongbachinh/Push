create FUNCTION    fdl_get_pia_auto_yn(
    i_acnt_no VARCHAR2,
    i_sub_no  VARCHAR2,
    i_dt  VARCHAR2
)
RETURN VARCHAR2 AS
    t_acnt_grp_no   varchar2(5);
    t_pia_auto_yn   varchar2(1);

    /*
        1. check CSR tu MH 04599 (dlm09m51). Neu co setup thi return
        2. Else (khong dang ky tren 04599) thi return trang thai UTTD cua toan he thong
    */

BEGIN

    BEGIN
       select d1.pia_auto_yn
       into t_pia_auto_yn
        from vn.dlm09m51 d1      
        where d1.active_stat = 'Y'
        and d1.acnt_no = i_acnt_no
        and d1.sub_no = i_sub_no
        and d1.apy_dt = ( select max(apy_dt)
                          from dlm09m51
                          where active_stat = 'Y'
                            and acnt_no = i_acnt_no
                            and sub_no = i_sub_no
                            and apy_dt <= i_dt
          );
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            t_acnt_grp_no := vn.faa_acnt_get_grp_no(i_acnt_no, i_sub_no, '2', i_dt);

            if(t_acnt_grp_no is null or t_acnt_grp_no = '00000')
            then
                t_pia_auto_yn := vn.fxc_col_cd_tp('non_mrgn_auto_pia_yn');
            else 
                t_pia_auto_yn := vn.fxc_col_cd_tp('mrgn_auto_pia_yn');
            end if;

        WHEN OTHERS THEN
            t_pia_auto_yn := 'N';
    END;

    RETURN t_pia_auto_yn;

END fdl_get_pia_auto_yn;
/

