create procedure pss_proc_bank_amt_p
(
  i_proc_dt            in    varchar2
,   i_acnt_no               in      varchar2
,   i_sub_no               in      varchar2
,   i_amt                   in      number
,  i_result_yn            in    varchar2   -- Y , E
,  i_seq                in    number
,  i_bank_cd              in    varchar2
,   i_work_mn               in      varchar2
,   i_work_trm              in      varchar2

) as

tn_trd_seq_no  number := 0 ;
ts_rmrk_cd  varchar2(3) := null ;


BEGIN

  vn.pxc_log_write('pss_proc_bank_amt_p','proc_dt : '|| i_proc_dt );
  vn.pxc_log_write('pss_proc_bank_amt_p','result_yn : '|| i_result_yn || 'seq : ' || i_seq );

  if  i_result_yn ='Y' then

     update VN.SSB07M00
     set
      err_cont = ' '
     where
      usefee_pay_dt = i_proc_dt
      and acnt_no = i_acnt_no
      and sub_no  = i_sub_no
      and rcpt_trd_no = i_seq;

   vn.pxc_log_write('pss_proc_bank_amt_p', 'acnt_no : ' || i_acnt_no ||','|| i_sub_no );
   vn.pxc_log_write('pss_proc_bank_amt_p', 'trd_seq : ' || tn_trd_seq_no);

  else
   --Hoai sua: 20151020: Jira VCSC-1276, VCSC-998: Update TK bank khi thu ko du tien

    /*update VN.SSB07M00
    set
      err_cont = 'Y'
    where
      usefee_pay_dt = i_proc_dt
      and acnt_no = i_acnt_no
      and sub_no  = i_sub_no
      and rcpt_trd_no = i_seq;*/
      update  vn.ssb07m00 a
      set err_cont = 'Y',
      rcpt_trd_no = 0,
      cncl_yn = 'N'
      where substr(MAK_STRT_DT,1,6)||a.acnt_no||a.sub_no||a.rcpt_trd_no||a.usefee||a.work_mn||to_char(a.work_dtm,'yyyymmdd')  in
      (select substr(MRTG_DT,1,6)||t.acnt_no||t.sub_no||t.seq_no||t.adj_amt||t.work_mn||to_char(t.work_dtm,'yyyymmdd') from DSC10M00 t
      where job_tp = '7'
      and t.scrt_err_cd <> '0010'
      and sb_tp = '2')
      and a.acnt_no = i_acnt_no and sub_no  = i_sub_no and rcpt_trd_no = i_seq
      and a.usefee = i_amt and vn.faa_acnt_bank_cd_g(acnt_no, sub_no) = i_bank_cd
     /* and a.work_mn = 'DAILY'*/ and a.rcpt_trd_no <> 0;

      Delete from AAA10M00 a where /*a.trd_dt||*/a.acnt_no||a.sub_no||a.TRD_SEQ_NO||a.ADJ_AMT||a.work_mn||to_char(a.work_dtm,'yyyymmdd')  in
      (select /*t.trd_dt||*/t.acnt_no||t.sub_no||t.seq_no||t.adj_amt||t.work_mn||to_char(t.work_dtm,'yyyymmdd') from DSC10m00 t
      where t.job_tp = '7'
      and t.scrt_err_cd <> '0010'
      and t.trd_dt >= '20151124'
      and t.sb_tp = '2'
      and t.acnt_no||t.sub_no||/*t.seq_no||*/t.adj_amt/*||t.work_mn||to_char(t.work_dtm,'yyyymmdd')*/ in
      (select a.acnt_no||a.sub_no||/*a.rcpt_trd_no||*/a.usefee/*||a.work_mn||to_char(a.work_dtm,'yyyymmdd') */from ssb07m00 a
      where a.cncl_yn = 'N'/* and a.rcpt_trd_no = 0*/))
      and a.rmrk_cd = '247'
      and a.acnt_no = i_acnt_no and a.sub_no  = i_sub_no and a.TRD_SEQ_NO = i_seq
      and a.ADJ_AMT = i_amt and vn.faa_acnt_bank_cd_g(acnt_no, sub_no) = i_bank_cd;



    pxc_log_write('pss_proc_bank_amt_p','err');

  end if ;

end pss_proc_bank_amt_p;
/

