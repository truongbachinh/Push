create function    fdl_get_acnt_rll(
    i_acnt_no              in  varchar2,
    i_sub_no               in  varchar2,
    i_acnt_grp_no          in  varchar2,
    i_stk_cd               in  varchar2,        -- Truyen % khi muon lay han muc tong cua tat ca cac ma CK cua TK
    i_src_no               in  varchar2,        -- Truyen % khi muon lay han muc tong cua tat ca cac ma CK cua TK
    i_prd_no               in  varchar2         -- Truyen % khi muon lay han muc tong cua tat ca cac ma CK cua TK
)
return number
/*!
     \file     fdl_get_acnt_rll.sql
     \brief    fdl_get_acnt_rll
     \section intro Program Information
          - Program Name              :
          - Service Name              :
          - Related Client Program- Client Program ID :
          - Related Tables            :
          - Dev. Date                 : 20210602
          - Developer                 : TienLH
          - Business Logic Desc.      : Han muc co the vay cua tk
          - Modify by                 :
          - Latest Modification Date  :
*/

as
    -- Temp variable
    t_cnt_src_sec           number          := 0;                       -- nguon trong
    t_cnt_src_out_sec       number          := 0;                       -- nguon ngoai

    t_proc_nm               varchar2(50)    := 'fdl_get_acnt_rll';
    t_err_msg               varchar2(500)   := null;

    -- output variable
    o_rll                   number          := 0;

begin

/*
    1. Chính sách riêng hạn mức của tài khoản ( 04606): X
    2. Chính sách chung hạn mức của tài khoản ( 90040): A
    3. Hạn mức của sub tài khoản tính theo nhóm margin ( 04610-1): B
    4. Hạn mức tối đa của 01 sub tài khoản: C
    5. Hạn mức còn lại của sub đang đặt lệnh được tính trong công thức tính sức mua: D
    6. Hạn mức đã sử dụng của sub đang đặt lệnh : E
    7. Tính hạn mức còn lại sub sau khi check hạn mức theo tài khoản:
        B1: Lấy hạn mức X của tài khoản:
            Nếu tồn tại bản ghi còn hiệu lực của tài khoản trong tab 04605-6:  X= giá trị Hạn mức tối đa --> Hạn mức của tài khoản F= X.
            Nếu không tồn tại: --> Hạn mức cùa tài khoản F= A.
        B2: Check nếu F=0 thì Tính hạn mức còn lại của sub = 0 và kết thúc việc tính hạn mức còn lại.
        Nếu F>0 thì check tiếp các bước sau.
        B3: Check sub đang tính hạn mức đó có cài chính sách riêng (csr) không?
            B3.1. Nếu có csr, tính hạn mức tối đa của sub đó  C= min( F, csr)
            B3.2. Nếu không csr, tính hạn mức tối đa của sub đó C = min( F, B)
        B4: Tính tổng hạn mức đã sử dụng của tất các sub thuộc tài khoản: G
        B5: Tính hạn mức còn lại của sub = min( D, min(min(C-E<0,0,C-E),min(F-G<0,0,F-G)))
*/

    vn.pxc_log_write(t_proc_nm, '');
    vn.pxc_log_write(
        t_proc_nm,
        'Start '                || t_proc_nm        || ' for: '
        || 'i_acnt_no = '       || i_acnt_no
        || ', i_sub_no = '      || i_sub_no
        || ', i_acnt_grp_no = ' || i_acnt_grp_no
        || ', i_stk_cd = '      || i_stk_cd
        || ', i_src_no = '      || i_src_no
        || ', i_prd_no = '      || i_prd_no
    );

    -- Kiem tra tai khoan dang duoc gan voi loai nguon nao
    begin
        vn.pdl_src_count(i_acnt_no, i_sub_no, t_cnt_src_sec, t_cnt_src_out_sec);
    exception
        when others then
            t_err_msg := vn.fxc_get_err_msg('V', '2157');
            vn.pxc_log_write(t_proc_nm,
                            ' nguon trong, nguon ngoai error: ' || t_err_msg );
            raise_application_error(-20100,
                                    t_err_msg ||
                                    ' fdl_get_acnt_rll: nguon trong, nguon ngoai' );
    end;

    vn.pxc_log_write(t_proc_nm, 't_cnt_src_sec = ' || t_cnt_src_sec || ', t_cnt_src_out_sec = ' || t_cnt_src_out_sec);

    -- Tinh toan RLL dua tren cac loai han muc thanh phan
    begin
        select
            case
                when t_cnt_src_sec > 0 and t_cnt_src_out_sec = 0 then      -- check nguon cty 70
                    least(acnt_sum_src_limit, acnt_sum_prd_limit, acnt_grp_limit, acnt_cust_limit, acnt_sum_stk_limit, acnt_eqt_limit)
                else
                    least(acnt_sum_src_limit, acnt_sum_prd_limit, acnt_grp_limit, acnt_cust_limit, acnt_sum_stk_limit)
            end rll
        into o_rll
        from (
            select
                vn.fdl_get_acnt_sum_src_lnd_limit(
                    i_acnt_no,
                    i_sub_no,
                    i_src_no,
                    '1'
                )                                       acnt_sum_src_limit,     -- Han muc gia tri con lai cua tai khoan theo tong cac nguon
                vn.fdl_get_acnt_sum_prd_lnd_limit(
                    i_acnt_no,
                    i_sub_no,
                    i_prd_no,
                    '1'
                )                                       acnt_sum_prd_limit,     -- Han muc gia tri con lai cua tai khoan theo tong cac san pham
                vn.fdl_get_acnt_lnd_limit(
                    i_acnt_no,
                    i_sub_no,
                    '08',
                    i_acnt_grp_no,
                    '1'
                )                                       acnt_grp_limit,         -- Han muc con lai cua TK theo Nhom TK
                vn.fdl_get_acnt_cust_lnd_limit(
                    i_acnt_no,
                    i_sub_no
                )                                       acnt_cust_limit,        -- Han muc con lai theo muc tk-sub
                vn.fdl_get_stk_sum_lnd_limit(
                    i_acnt_no,
                    i_sub_no,
                    i_stk_cd
                )                                       acnt_sum_stk_limit,     -- Han muc chung khoan con lai
                vn.fdl_get_acnt_eqt_lnd_limit(
                    i_acnt_no,
          i_sub_no
                )                                       acnt_eqt_limit          -- Han muc con lai so voi 3% Han muc tinh tren VCSH
            from dual
        );
        exception
            when others then
                t_err_msg := vn.fxc_get_err_msg('V', '2157');
                vn.pxc_log_write(t_proc_nm, ' o_rll error: ' || t_err_msg);
                raise_application_error(-20100,
                                        t_err_msg ||
                                        ' fdl_get_acnt_rll: o_rll   acnt_no=' ||
                                        i_acnt_no || '-' || i_sub_no || '-' || i_stk_cd || '-' ||
                                        i_stk_cd || '-' || i_acnt_grp_no || '-' || i_acnt_grp_no);
    end;

    vn.pxc_log_write(t_proc_nm, 'o_rll = ' || o_rll);
    vn.pxc_log_write(t_proc_nm, 'End.');

    return  o_rll;

end fdl_get_acnt_rll;
/

