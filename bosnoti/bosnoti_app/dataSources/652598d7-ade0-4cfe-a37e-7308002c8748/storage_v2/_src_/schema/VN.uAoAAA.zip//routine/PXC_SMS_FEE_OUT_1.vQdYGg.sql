create PROCEDURE    pxc_sms_fee_out_1
(
  i_sec_cd     IN VARCHAR2,
  i_acnt_no    IN VARCHAR2,
  i_sms_grp_cd IN VARCHAR2,
  i_mobile     IN VARCHAR2,
  i_status     IN VARCHAR2,
  i_work_mn    IN VARCHAR2,
  i_work_trm   IN VARCHAR2,
  o_err_msg    OUT NUMBER -- 1: cat duoc tien, 2 khong
) IS

/*Huedt add 20190103*/

  k_rmrk_cd VARCHAR2(3) := '901'; --phi tin nhan
  t_acnt_no VARCHAR2(10);
  t_sub_no VARCHAR2(2);
  t_avail_depo_fee NUMBER := 0; -- so tien co the cat

  t_trd_dt VARCHAR2(20) := ' ';
  t_trd_seq_no NUMBER := 0;
  t_dpo NUMBER := 0;
  t_dpo_prerm NUMBER := 0;
  t_dpo_nowrm NUMBER := 0;
  t_acnt_place VARCHAR2(10) := ' ';
  t_bnhof_tp VARCHAR2(10) := ' ';
  t_proc_bnhof_tp VARCHAR2(10) := ' ';
  t_dpo_fee_sms NUMBER := 0;
  t_date VARCHAR2(8);
  t_month VARCHAR2(6);
  t_row_dt VARCHAR2(100);

  t_usefee NUMBER := 0;


  tn_dpo_prerm        number := 0;
  tn_tot_dpo_prerm      number := 0;
  tn_inout_cnfm_lim      number := 0;

  tn_dpo                   number := 0;
  tn_tot_dpo               number := 0;
  tn_dpo_block             number := 0;
  tn_outq_dpo_bk           number := 0;
  tn_prof_dpo              number := 0;
  tn_reuse_dpo             number := 0;
  tn_sbst_dpo              number := 0;
  tn_sbst_able_block       number := 0;
  tn_sbst_block            number := 0;
  tn_sbst_proof            number := 0;
  tn_gst_dpo               number := 0;
  tn_use_vd                number := 0;
  tn_nonrpy_loan_amt       number := 0;
  tn_mgn_loan_amt          number := 0;
  tn_mgn_lack              number := 0;
  tn_cd_lack               number := 0;
  tn_crd_dpo               number := 0;
  tn_used_alowa_rel        number := 0;
  tn_used_alowa_cd         number := 0;
  tn_used_alowa_vd         number := 0;
  tn_all_prof_rel          number := 0;
  tn_all_prof_cd           number := 0;
  tn_all_prof_vd           number := 0;
  tn_able_block            number := 0;
  tn_tot_out_psbamt        number := 0;

BEGIN

  SELECT vn.fxc_vorderdt_g(trunc(to_date(vn.vwdate, 'yyyymmdd'), 'MM'), -1),
         to_char(SYSDATE, 'mmyyyy'),
         vn.fxc_row_sms(i_acnt_no) t_row_dt
    INTO t_date, t_month, t_row_dt
    FROM dual;

  BEGIN
    /*v?i kh�ch h�ng b�nh thu?ng, status=0 thu 8800
    v?i kh�ch h�ng n? 1 th�ng, status=1 thu 8800+8800
    v?i kh�ch h�ng n? 2 th�ng status =2 thu 8800+ 8800*2
    v?i kh�ch h�ng h?y, status =3 => kh�ng thu, c�i n�y thu b?ng tay*/
    SELECT SUM(b.fee_block)--+ b.fee_block
      INTO t_usefee
      FROM vn.xca01m10 b
     WHERE b.acnt_no LIKE i_acnt_no;
     --group by b.fee_block;
    --   and   b.sms_grp_cd = i_sms_grp_cd
    -- and b.trd_dt in ('102014','112014')---them thang thu,mai mot bo di
    --  and b.trd_dt in ('122014')---them thang thu,mai mot bo di
    -- group by b.fee_block;
  EXCEPTION
    WHEN OTHERS THEN
      --vn.pxc_log_write('pxc_sms_fee_out_1', ' pxc_sms_fee_out_1 ['||sqlcode||']');
      pxc_log_write('pxc_sms_fee_out_1', 'Khong co thong tin tai khoan no tien :' ||
                     '...ACNT_NO:' || i_acnt_no);
      o_err_msg := '2';
      RETURN;
  END;
  BEGIN

    FOR c1 IN (SELECT acnt_no, sub_no, dpo
                 FROM vn.cwd01m00 t
                WHERE acnt_no = i_acnt_no
               -- order by acnt_no||sub_no
               ) LOOP
      BEGIN
        -- Kiem tra so tien co the rut cua KH

        SELECT vn.fcw_avail_cash_depo_fee(i_sec_cd, c1.acnt_no, c1.sub_no)
          INTO t_avail_depo_fee
          FROM dual;
      EXCEPTION
        WHEN OTHERS THEN
          vn.pxc_log_write('pxc_sms_fee_out_1', ' fcw_avail_cash_depo_fee [' ||
                            SQLCODE || ']');
          t_trd_seq_no := 0;
      END;

        BEGIN
            vn.pcw_outamt_psbamt_q
            (  c1.acnt_no
                ,  c1.sub_no
            ,  '9999'
          ,  tn_dpo
          ,  tn_dpo_block
          ,  tn_outq_dpo_bk
          ,  tn_prof_dpo
          ,  tn_reuse_dpo
          ,  tn_sbst_dpo
          ,  tn_sbst_able_block
          ,  tn_sbst_proof
          ,  tn_gst_dpo
          ,  tn_use_vd
          ,  tn_nonrpy_loan_amt
          ,  tn_mgn_loan_amt
          ,  tn_mgn_lack
          ,  tn_cd_lack
          ,  tn_crd_dpo
          ,  tn_used_alowa_rel
          ,  tn_used_alowa_cd
          ,  tn_used_alowa_vd
          ,  tn_all_prof_rel
          ,  tn_all_prof_cd
          ,  tn_all_prof_vd
          ,  tn_able_block
          ,  t_avail_depo_fee
            );
        EXCEPTION
        WHEN  OTHERS         THEN
            vn.pxc_log_write('pxc_sms_fee_out_1', ' fcw_avail_cash_depo_fee [' ||
                            SQLCODE || ']');
          t_trd_seq_no := 0;
        END;  


      vn.pxc_log_write('pxc_sms_fee_out_1', '  Tien Hanh: ' || c1.acnt_no ||
                        '  sub: ' || c1.sub_no ||
                        '  status: ' || i_status ||
                        '  fee: ' || t_usefee ||
                        '   balance:  ' ||
                        t_avail_depo_fee);

      IF (t_avail_depo_fee >= t_usefee AND t_usefee > 0) THEN
        /*Cat tien sub dang chay o cursor C1*/
        BEGIN
          vn.pcw_cash_outamt_p( to_char(SYSDATE, 'yyyymmdd'), c1.acnt_no, c1.sub_no, k_rmrk_cd, t_usefee, '00',
                               --vn.fbm_rmrk_nm_q(i_sec_cd,K_RMRK_CD) || ' ' || substr(t_date,5,2) || '/' || substr(t_date,1,4)||' cua sub '||c1.sub_no,
                               'Fee SMS' || ' ' ||TRIM(t_row_dt) || ' cua sub ' || c1.sub_no, 'Y', '900', i_work_mn, i_work_trm, t_trd_dt, t_trd_seq_no, t_dpo_prerm, t_dpo_nowrm, t_acnt_place, t_bnhof_tp, t_proc_bnhof_tp);
        EXCEPTION
          WHEN OTHERS THEN
            vn.pxc_log_write('pxc_sms_fee_out_1', ' pcw_cash_outamt_p [' ||
                              SQLCODE || ']');
            ROLLBACK;
            t_trd_seq_no := 0;
        END;

      END IF;
      IF t_trd_seq_no > 0 THEN
        pxc_log_write('pxc_sms_fee_out_1', 'TK thu phi thanh cong :' ||
                       '...ACNT_NO:' || i_acnt_no ||
                       '  sub: ' || c1.sub_no);
        EXIT;
      END IF;
    END LOOP; -- Vong lap 1
    /* Neu cat duoc tien th� update trang th�i giam lai 1, thu duocj th� c�c tr?ng th�i 1,2,3 chuy?n qua 'N':kh�ng n?*/
    IF (t_trd_seq_no > 0) THEN
      o_err_msg := '1';
      SELECT acnt_no, sub_no
        INTO t_acnt_no, t_sub_no
        FROM vn.aaa10m00
       WHERE acnt_no = i_acnt_no
         AND rmrk_cd = '901'
         AND trd_dt = t_trd_dt
         AND rownum = '1';

      SELECT dpo_fee_sms, dpo
        INTO t_dpo_fee_sms, t_dpo
        FROM vn.cwd01m00
       WHERE acnt_no = i_acnt_no
         AND sub_no = t_sub_no;

      --update vao bang lich su xca01m10
      BEGIN
        UPDATE vn.xca01m10
           SET sub_no = t_sub_no, fee_yn = 'Y', dpo = t_dpo,
               --   fee_obtained = decode(trd_dt,t_month,t_usefee,fee_block),
               fee_obtained = fee_block, obtained_dtm = to_char(SYSDATE, 'yyyymmdd'), fee_block = '0', block_dtm = NULL, work_mn = i_work_mn, work_dtm = SYSDATE, work_trm = i_work_trm
         WHERE acnt_no = i_acnt_no
              -- and   trd_dt in ('122014')---them thang thu,mai mot bo di
           AND fee_block > '0';

      EXCEPTION
        WHEN OTHERS THEN
          vn.pxc_log_write('pxc_sms_fee_out', ' xca01m10 [' || SQLCODE || ']');
          ROLLBACK;
      END;
      ---update lai tong phi no
      FOR c3 IN (SELECT SUM(fee_block) total_block
                   FROM vn.xca01m10
                  WHERE acnt_no = i_acnt_no) LOOP
        /* Update xca01m07 */
        UPDATE vn.xca01m07
           SET fee_yn = 'Y', fee_obtained = t_usefee, status = '0', block_dtm = NULL, fee_block = c3.total_block, work_mn = i_work_mn, work_trm = i_work_trm, work_dtm = SYSDATE
         WHERE acnt_no = i_acnt_no
           AND sms_grp_cd <> '00';

        UPDATE vn.xca01m10
           SET total_block = c3.total_block
         WHERE acnt_no = i_acnt_no;

        UPDATE vn.cwd01m00
           SET dpo_fee_sms = c3.total_block
         WHERE acnt_no = i_acnt_no
           AND sub_no = '00';
      END LOOP;

      /*Gui SMS cho KH neu thu phi thanh cong*/
      /*Huedt add k gui tn khi thu phi thanh cong*/
     /* BEGIN
        vn.pxc_sms_ins(i_sec_cd, to_char(SYSDATE, 'YYYYMMDD'), i_mobile, '84438181888', '007', '744',
                       -- t_acnt_no||t_sub_no||t_usefee||'   '||t_dpo,
                       t_acnt_no || t_sub_no || lpad(t_row_dt, 50, ' ') ||
                        lpad(t_usefee, 15, ' ') || lpad(t_dpo, 18, ' '), i_work_mn, i_work_trm);
      EXCEPTION
        WHEN OTHERS THEN
          vn.pxc_log_write('pxc_sms_fee_out_1', ' pxc_sms_ins [' || SQLCODE || ']');
          t_trd_seq_no := 0;
      END;
      pxc_log_write('pxc_sms_fee_out_1', 'TK thu phi thanh cong :' ||
                     '...ACNT_NO:' || i_acnt_no ||
                     '  sub: ' || t_sub_no);*/
      /*Het HueDT add k gui tn*/
      --Khong du tien de cat
    ELSE
      o_err_msg := '2';
      pxc_log_write('pxc_sms_fee_out_1', 'TK khong thu duoc tien :' ||
                     '...ACNT_NO:' || i_acnt_no);
    END IF;
  END;

END pxc_sms_fee_out_1;
/

