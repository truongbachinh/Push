create PROCEDURE "PXC_SMS_ADM"  (in_send_dt       IN VARCHAR2,
                                        in_recv_phone_no IN VARCHAR2,
                                        in_send_phone_no IN VARCHAR2,
                                        in_work_tp_a     IN VARCHAR2,
                                        in_work_tp_b     IN VARCHAR2,
                                        in_sms_msg       IN VARCHAR2,
                                        in_work_mn       IN VARCHAR2,
                                        in_work_trm      IN VARCHAR2) IS

  ts_sqlcode          number := 0;
  ts_sms_text       Varchar2(200) := NULL;
  ts_call_back_no VARCHAR2(20)  := '8400000000';
  v_OutputFile    UTL_FILE.FILE_TYPE;
  v_Dir     VARCHAR2(50) := 'LOG_DIR';
  ts_com_nm varchar2(10) := NULL;
BEGIN
        ------------------------------
        -- text message of the order--
        ------------------------------
   select com_nm into ts_com_nm from vn.xcc99m00 where test_yn='R';
   IF in_work_tp_a = '003' THEN
      -- IF in_work_tp_b in ( '101', '901', '102', '902') THEN
      --    vn.pxc_log_write('PXC_SMS_ADM', 'SKIP for https://www.tyhpt.com.vn:8843/jira/browse/VCSC-194');
      --    return;
      -- end if;

      -- A:003 / B:101(matching buying order, lng_tp[V])
      IF in_work_tp_b = '101' THEN
         ts_sms_text :=
               ts_com_nm||' : KQKL CUA QUI KHACH: TK '
            || TRIM (SUBSTR (in_sms_msg, 1, 10) )
            || ' MUA '
            || TRIM (SUBSTR (in_sms_msg, 11, 8) )
            || ' KL '
            || TRIM (SUBSTR (in_sms_msg, 19, 8) )
            || ' GIA '
            || TRIM (SUBSTR (in_sms_msg, 27, 8) )
            || ' KHOP LUC '
            || TRIM (SUBSTR (in_sms_msg, 35, 8) )
            || ' ';
      END IF;
      -- A:003 / B:901(matching buying order, lng_tp[E])
      IF in_work_tp_b = '901' THEN
         ts_sms_text :=
               ts_com_nm||' : MATCHED '
            || TRIM (SUBSTR (in_sms_msg, 1, 10) )
            || ' BUY '
            || TRIM (SUBSTR (in_sms_msg, 11, 8) )
            || ' QUANTITY '
            || TRIM (SUBSTR (in_sms_msg, 19, 8) )
            || ' AT '
            || TRIM (SUBSTR (in_sms_msg, 27, 8) )
            || ' IN '
            || TRIM (SUBSTR (in_sms_msg, 35, 8) )
            || ' ';
      END IF;
      -- A:003 / B:102(matching selling order, lng_tp[V])
      IF in_work_tp_b = '102' THEN
         ts_sms_text :=
               ts_com_nm||' : KQKL CUA QUI KHACH: TK '
            || TRIM (SUBSTR (in_sms_msg, 1, 10) )
            || ' BAN '
            || TRIM (SUBSTR (in_sms_msg, 11, 8) )
            || ' KL '
            || TRIM (SUBSTR (in_sms_msg, 19, 8) )
            || ' GIA '
            || TRIM (SUBSTR (in_sms_msg, 27, 8) )
            || ' KHOP LUC '
            || TRIM (SUBSTR (in_sms_msg, 35, 8) )
            || ' ';
      END IF;
      -- A:003 / B:902(matching selling order, lng_tp[E])
      IF in_work_tp_b = '902' THEN
         ts_sms_text :=
              ts_com_nm||' : MATCHED '
            || TRIM (SUBSTR (in_sms_msg, 1, 10) )
            || ' SELL '
            || TRIM (SUBSTR (in_sms_msg, 11, 8) )
            || ' QUANTITY '
            || TRIM (SUBSTR (in_sms_msg, 19, 8) )
            || ' AT '
            || TRIM (SUBSTR (in_sms_msg, 27, 8) )
            || ' IN '
            || TRIM (SUBSTR (in_sms_msg, 35, 8) )
            || ' ';
      END IF;
      -- A:003 / B:103(NOT ENOUGH Order Slip, lng_tp[V])
      IF in_work_tp_b = '103' THEN
         ts_sms_text :=
              ts_com_nm||' : Xin thong bao so phieu lenh ky truoc con lai cua quy khach la '
            || TRIM (SUBSTR (in_sms_msg, 1, 3) )
            || ', quy khach vui long den '|| ts_com_nm || ' de bo sung phieu lenh moi.';
      END IF;
      -- A:003 / B:903(NOT ENOUGH Order Slip, lng_tp[E])
      IF in_work_tp_b = '903' THEN
         ts_sms_text :=
              ts_com_nm||' would like to inform you that, currently, the amount of your pre - signed order slip is '
            || TRIM (SUBSTR (in_sms_msg, 1, 3) )
            || ', please come to our office for order slip submission.';
      END IF;
      -- A:003 / B:104(Reject advance order Sell, lng_tp[V])
      IF in_work_tp_b = '104' THEN
         --ts_sms_text := 'VCSC xin thong bao lenh dat truoc cua qui khach da bi tu choi, xin quy khach thu lai lan sau.';
         ts_sms_text :=
              ts_com_nm||' : Xin thong bao lenh dat truoc '
            || TRIM (SUBSTR (in_sms_msg, 1, 8) )
            || ', Ban '
            || TRIM (SUBSTR (in_sms_msg, 9, 8) )
            || ', da bi tu choi, xin qui khach thu lai lan sau.';
      END IF;
      -- A:003 / B:904(Reject advance order Sell, lng_tp[E])
      IF in_work_tp_b = '904' THEN
         --ts_sms_text := 'VCSC would like to inform you that your advance order has been rejected, please try again.';
         ts_sms_text :=
               ts_com_nm||' would like to inform you that your advance order has been rejected '
            || TRIM (SUBSTR (in_sms_msg, 1, 8) )
            || ', Sell '
            || TRIM (SUBSTR (in_sms_msg, 9, 8) )
            || ', please try again.';
      END IF;
      -- A:003 / B:105(Reject advance order Buy, lng_tp[V])
      IF in_work_tp_b = '105' THEN
         --ts_sms_text := 'VCSC xin thong bao lenh dat truoc cua qui khach da bi tu choi, xin quy khach thu lai lan sau.';
         ts_sms_text :=
              ts_com_nm||' : Xin thong bao lenh dat truoc '
            || TRIM (SUBSTR (in_sms_msg, 1, 8) )
            || ', Mua '
            || TRIM (SUBSTR (in_sms_msg, 9, 8) )
            || ', da bi tu choi, xin qui khach thu lai lan sau';
      END IF;
      -- A:003 / B:905(Reject advance order Buy, lng_tp[E])
      IF in_work_tp_b = '905' THEN
         --ts_sms_text := 'VCSC would like to inform you that your advance order has been rejected, please try again.';
         ts_sms_text :=
               ts_com_nm||' would like to inform you that your advance order has been rejected '
            || TRIM (SUBSTR (in_sms_msg, 1, 8) )
            || ', Buy '
            || TRIM (SUBSTR (in_sms_msg, 9, 8) )
            || ', please try again.';
      END IF;
   -----------------------------------
   -- text message of the account   --
   -----------------------------------
   ELSE
      IF in_work_tp_a = '001' THEN
         -- A:001 / B:101(changing password for online trading, lng_tp[V])
         IF in_work_tp_b = '101' THEN
            ts_sms_text :=
                ts_com_nm||': Thong bao mat khau dat lenh qua dien thoai moi cua tai khoan quy khach '
               || TRIM (SUBSTR (in_sms_msg, 1, 10) )
               || ' la '
               || TRIM (SUBSTR (in_sms_msg, 11, 13) );
         END IF;
         -- A:001 / B:901(changing password for online trading, lng_tp[E])
         IF in_work_tp_b = '901' THEN
            ts_sms_text :=
              ts_com_nm||': The new password for trading via telephone at '|| ts_com_nm ||' of account number '
               || TRIM (SUBSTR (in_sms_msg, 1, 10) )
               || ' is '
               || TRIM (SUBSTR (in_sms_msg, 11, 13) );
         END IF;
         -- A:001 / B:102(Open account, lng_tp[V])
         IF in_work_tp_b = '102' THEN
            ts_sms_text :=
               ts_com_nm||': Tran trong thong bao tai khoan giao dich moi cua quy khach tai ' || ts_com_nm ||' la: '
               || TRIM (SUBSTR (in_sms_msg, 1, 10) );
         END IF;
         -- A:001 / B:902(Open account: , lng_tp[E])
         IF in_work_tp_b = '902' THEN
            ts_sms_text :=
                  ts_com_nm||': would like to inform your securities trading account number at'|| ts_com_nm ||' is '
               || TRIM (SUBSTR (in_sms_msg, 1, 10) );
         END IF;
         -- A:001 / B:103(Change password on V-Pro, lng_tp[V])
         IF in_work_tp_b = '103' THEN
            ts_sms_text :=
                ts_com_nm||': Xin thong bao mat khau giao dich moi cua quy khach tren V-PRO; V-WEB la: '
               || TRIM (SUBSTR (in_sms_msg, 1, 13) );
         END IF;
         -- A:001 / B:903(Change password on V-Pro, lng_tp[E])
         IF in_work_tp_b = '903' THEN
            ts_sms_text :=
                ts_com_nm||': Please be informed that your new password for V-Pro and V-web is: '
               || TRIM (SUBSTR (in_sms_msg, 1, 13) );
         END IF;
      -- free text message
      ELSE
         IF in_work_tp_a = '999' THEN
            v_OutputFile := UTL_FILE.FOPEN(v_Dir,in_sms_msg,'r');
            UTL_FILE.GET_LINE(v_OutputFile, ts_sms_text);
            UTL_FILE.FCLOSE(v_OutputFile);
         END IF;
      END IF;
   END IF;
   vn.pxc_log_write('PXC_SMS_ADM',' [befor insert ]in_recv_phone_no['||in_recv_phone_no||']  SMS_MSG['|| ts_sms_text ||']');
   BEGIN
    INSERT INTO VN.XCS01M00 T
      (T.SMS_SEQ_NO,
       T.SEND_DT,
       T.RECV_PHONE_NO,
       T.CALL_BACK_NO,
       T.SEND_PHONE_NO,
       T.SEND_ST,
       T.RE_TRY_CNT,
       T.WORK_TP_A,
       T.WORK_TP_B,
       T.SMS_MSG,
       T.WORK_MN,
       T.WORK_DTM,
       T.WORK_TRM)
    VALUES
      (VN.XCS01M00_SEQ.NEXTVAL,
       in_send_dt,
       in_recv_phone_no,
       ts_call_back_no,
       in_send_phone_no,
       '9', --in_send_st
       '3', --retry number
       NVL(in_work_tp_a, '000'),
       NVL(in_work_tp_b, '000'),
       ts_sms_text,
       in_work_mn,
       SYSDATE,
       in_work_trm);

  EXCEPTION
    WHEN OTHERS THEN
      ts_sqlcode := sqlcode;
      RAISE_APPLICATION_ERROR(-20100,
                              'error found base_idx -2 [' || ts_sqlcode || ']');
  END;
   vn.pxc_log_write('PXC_SMS_ADM',' in_recv_phone_no['||in_recv_phone_no||']  SMS_MSG['|| ts_sms_text ||']');
END pxc_sms_adm;
/

