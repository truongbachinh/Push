create function fbm_get_rmrk_nm_e(
  i_lng_tp     in    varchar2,
  i_sec_cd     in    varchar2,
  i_rmrk_cd    in    varchar2
  ) return varchar2   as
/**********************************************************/
/* Get rmrk name                                        */
/**********************************************************/

  t_lng_tp       varchar2(1);

begin

  t_lng_tp := nvl(trim(i_lng_tp),'V');

  for c1 in (
    select  decode(t_lng_tp,'V',rmrk_cd_nm,rmrk_cd_nm_eng) rmrk_nm
    from    vn.bmi02c00
    where   rmrk_cd = i_rmrk_cd
  ) loop

    return nvl(c1.rmrk_nm,'!');

  end loop;

  return '!';

end fbm_get_rmrk_nm_e;
/

