create PROCEDURE pss_inbil_aprv_p
(
 is_proc_dt			in	varchar2,
 is_acnt_no			in	varchar2,
 is_sub_no			in	varchar2,
 is_seq_no			in	varchar2,
 is_std_inq_dt		in	varchar2,                --approving date
 is_apy_dt          in  varchar2,                -- apply date  default is today
 is_work_mn			in	varchar2,
 is_work_trm		in	varchar2,
 is_work_bnh		in	varchar2,
 is_dept_no2		in	varchar2,
 is_trd_amt         in  number,
 is_cmsn            in  number,
 is_sb_tax          in  number,
 is_adj_amt         in  number,
 os_end_yn			out	varchar2,
 os_err_msg			out	varchar2,
 os_inq_dt			out	varchar2
 ) AS

 tn_cnt					number	:= 0;
 tn_loop_cnt			number	:= 0;
 tn_bil_prerm_qty		number	:= 0;
 tn_tot_bil_prerm_qty	number	:= 0;

 tn_qty					number 	:= 0;
 tn_sb_lmt_qty			number 	:= 0;
 tn_mov_lmy_qty			number 	:= 0;
 tn_inq_pri             number 	:= 0;
 tn_trd_seq_no			number 	:= 0;
 tn_tot_trd_seq_no			number 	:= 0;

 tot_cnt				number 	:= 0;

 t_rtn_val              varchar2(1) := '';

 ts_stk_tp				varchar2(2)		:= '';
 ts_step				varchar2(10)	:= '';
 ts_wdate				varchar2(8)		:= '';
 ts_trd_dt				varchar2(8)		:= '';
 ts_stk_cd				varchar2(20)	:= '';
 ts_rmrk_cd				varchar2(3)		:= '';
 ts_buy_dt				varchar2(8)		:= '';
 ts_anth_cd				varchar2(3)		:= '';
 ts_anth_acnt_no		varchar2(20)	:= '';
 ts_cnte			    varchar2(200)	:= '';
 ts_end_yn				varchar2(1)	:= 'N';

 ts_date				varchar2(8)		:= '';

 /* VSD need to aply date  20100723 by jung */
 ts_apy_dt				varchar2(8)		:= '';
 ts_tmp_dt				varchar2(40)		:= '';

 ts_acnt_tp             varchar2(2)     := '';
 ts_trd_tp			    varchar2(2)	    := null;
 ts_rgt_chk             varchar2(2)     := null;

 t_err_txt              varchar2(200);
 t_err_msg              varchar2(500);

 vn_count               number   		:= 0;
 o_cnt                  number   		:= 0;

 -- SMS
 ts_fnc_cd    varchar2(10);
 ts_sms_msg   varchar2(200);
 -- LTHN-248
 tn_rgt_tax_qty       number := 0;
 tn_apy_dt            varchar2(8);
 tn_tax_qty           number := 0;
 tn_tax_sb_lim_qty    number := 0;
 tn_tax_delay_qty     number := 0;
 tn_tax_delay_sb_qty  number := 0;
 tn_min_proc_dt       number := 0;
 tn_max_proc_dt       number := 0;
 tn_max_id            number := 0;
 --
 ERR_RTN				EXCEPTION;
/* ************************************** Log changes ****************************************
02-Jan-2019 vnjvthangnm Gui tin nhan SMS
23-Dec-2020 vnjvthangnm LTHN-248
******************************************************************************************* */
 begin

 os_end_yn := '';
 os_err_msg := '';
 os_inq_dt := '';

-- work_date

 SELECT to_char(vn.wdate(),'ddmmyyyy') , to_char(vn.wdate(),'yyyymmdd')
 INTO   ts_wdate , ts_trd_dt
 FROM DUAL;

 vn.pxc_log_write('pss_inbil_aprv_p','acnt_no '||is_acnt_no ||' is_proc_dt '|| is_proc_dt ||' seq_no '||is_seq_no);

 /*** check closing ***/

 t_rtn_val := 'Y';

 if  is_work_mn  not in ('DAILY','BATCH') then

        vn.pbm_cls_yn_q(  vn.vhdate
                       ,  is_work_bnh
                       ,  vn.faa_acnt_bnh_cd_g( '0',is_acnt_no,is_sub_no)
                       , '1'
                       ,  t_rtn_val
                       ,  t_err_txt
                       );

        if  t_rtn_val  !=  'N' then
            t_err_msg := vn.fxc_get_err_msg('V','2716');
            raise_application_error(-20100,t_err_msg||t_err_txt);
        end if;

 end if;

 ts_step := '1';

 /*Approving date is smaller than is_proc_dt*/
 /*Modified by HUNG 20100817 as SHS request*/
   if /* is_std_inq_dt <  is_proc_dt  or */ is_std_inq_dt > ts_trd_dt  then
	  os_end_yn := 'N';
	  os_err_msg := '2031';
	  RAISE  ERR_RTN;
   end if ;

 ts_step := '2';

 SELECT  trim(stk_cd)
        ,trim(rmrk_cd)
		,trim(trd_tp)
        ,nvl(qty, 0)
        ,nvl(sb_lmt_qty, 0)
        ,nvl(mov_lmy_qty, 0)
        ,nvl(inq_pri, 0)
        ,trim(buy_dt)
        ,trim(anth_cd)
        ,trim(anth_acnt_no)
        ,trim(cnte)
        ,nvl(end_yn, 'N')
        ,apy_dt
        ,nvl(rgt_tax_qty,0)
 INTO    ts_stk_cd
        ,ts_rmrk_cd
		,ts_trd_tp
        ,tn_qty
        ,tn_sb_lmt_qty
        ,tn_mov_lmy_qty
        ,tn_inq_pri
        ,ts_buy_dt
        ,ts_anth_cd
        ,ts_anth_acnt_no
        ,ts_cnte
        ,ts_end_yn
        ,tn_apy_dt
        ,tn_rgt_tax_qty
  FROM  VN.SSB05M00
  WHERE PROC_DT = is_proc_dt
  AND   ACNT_NO = is_acnt_no
  AND   SUB_NO  = is_sub_no
  AND   SEQ_NO = to_number(is_seq_no);

  IF ts_end_yn = 'Y' THEN
    os_end_yn := 'N';
    os_err_msg := '2256';
    RAISE  ERR_RTN;
  END IF;

  IF tn_qty = 0 and tn_sb_lmt_qty = 0 and tn_mov_lmy_qty = 0    THEN
    os_end_yn := 'Y';
    os_err_msg := 'OK';
    RETURN;
  END IF;

  /* apply date is default inq_dt 20100723 by jung */

  pxc_log_write('pss_inbil_aprv_p','std_inq_dt [' || is_std_inq_dt ||'] apply date ['|| is_apy_dt || ']');

  IF is_apy_dt is null  then
	 ts_apy_dt := is_std_inq_dt ;
  ELSE
	 ts_apy_dt := is_apy_dt     ;
  END if ;

  begin
	select to_Date(ts_apy_dt , 'yyyymmdd')
	  into ts_tmp_dt
	  from dual ;
  exception
	 when others then
	   raise_application_error(-20100, 'aplly date format error' );
  end  ;

  if is_std_inq_dt > is_apy_dt  then
     os_end_yn := 'N';
     os_err_msg := '2031';
     RAISE  ERR_RTN;
  end if ;

  /*check change rights */
  select  vn.fsr_chage_rgt_p( ts_stk_cd , ts_trd_dt)
    into  ts_rgt_chk
    from dual;

  if  ts_rgt_chk = 'Y' then
      os_end_yn := 'N';
	  os_err_msg := '2029';
	  RAISE  ERR_RTN;
  end if ;

  ts_step := '3';

  IF  tn_inq_pri = 0    THEN
     tn_inq_pri := vn.fss_get_pd_cls_pri(ts_stk_cd);

    IF  tn_inq_pri = 0  THEN
        tn_inq_pri := vn.fss_get_fac_pri( ts_stk_cd);
    END IF;
  END IF;

  pxc_log_write('pss_inbil_aprv_p','tn_inq_pri-'||tn_inq_pri);

  IF tn_inq_pri <= 0    THEN
     os_end_yn := 'N';
     os_err_msg := '9412';
     RAISE  ERR_RTN;
  END IF;

  IF ts_buy_dt is null  then
     ts_buy_dt := vn.faa_to_yyyymmdd( ts_wdate);
  END IF;

  ts_stk_tp := vn.fss_get_stk_tp( ts_stk_cd);

/***** trd_tp *************************************/

  ts_acnt_tp :=  vn.faa_get_acnt_tp( is_acnt_no , is_sub_no)  ;

  if ts_rmrk_cd in ('603','604') then

	 if ts_acnt_tp    = '1' then  --  custodian
		ts_trd_tp :=  '50' ;
     elsif ts_acnt_tp = '2' then  -- bank_connect
		ts_trd_tp :=  '52' ;
     elsif ts_acnt_tp = '3' then  -- non-custodian
		ts_trd_tp :=  '54' ;
     end if ;

-- ts_trd_tp := '30' ;
  else

     if ts_acnt_tp    = '1' then  --  custodian
        ts_trd_tp :=  '20' ;
     elsif ts_acnt_tp = '2' then  -- bank_connect
        ts_trd_tp :=  '22' ;
     elsif ts_acnt_tp = '3' then  -- non-custodian
        ts_trd_tp :=  '24' ;
     end if ;

--     ts_trd_tp := '20' ;
  end if ;

/*** GET TRD_SEQ_NO   ***/

  ts_step := '5';

  if  is_std_inq_dt =  ts_trd_dt then
    pxc_log_write('pss_inbil_aprv_p','Get trd_seq in  pxc_seq ' );
    vn.pxc_psb_seq_cret_p (is_acnt_no, is_sub_no,  ts_trd_dt, tn_trd_seq_no, tn_tot_trd_seq_no);
  else
    pxc_log_write('pss_inbil_aprv_p','Get trd_seq in  aaa10m00 ' );
     begin
	  select nvl(max(trd_seq_no),0)
	     into tn_trd_seq_no
	     from vn.aaa10m00
	   where acnt_no = is_acnt_no
		 and sub_no = is_sub_no
	     and trd_dt = is_std_inq_dt;
	 exception
	   	when NO_DATA_FOUND then
	      tn_trd_seq_no := 0;
     end;

	 tn_trd_seq_no := tn_trd_seq_no + 1;
  end if ;

  pxc_log_write('pss_inbil_aprv_p','trd_seq_no :' || tn_trd_seq_no );

/*** GET BEFORE DEALING  QTY  ***/

 if  is_std_inq_dt =  ts_trd_dt then

    BEGIN
	  SELECT   nvl(own_qty , 0 )
		INTO   tn_bil_prerm_qty
		FROM   vn.ssb01m00
       WHERE   acnt_no = is_acnt_no
		 AND   SUB_NO  = is_sub_no
		 AND   stk_cd = ts_stk_cd ;
    EXCEPTION
         WHEN  NO_DATA_FOUND    THEN
			tn_bil_prerm_qty := 0;
    END;

    tn_tot_bil_prerm_qty := vn.fss_get_tot_prerm_qty( is_acnt_no, ts_stk_cd);

 else

    BEGIN
      SELECT	nvl(own_qty, 0)
        INTO	tn_bil_prerm_qty
        FROM	vn.ssb01h00
       WHERE	acnt_no = is_acnt_no
		 AND    sub_no  = is_sub_no
         AND	stk_cd = ts_stk_cd
         AND	rgt_std_dt = is_std_inq_dt ;
    EXCEPTION
      WHEN NO_DATA_FOUND	THEN
           tn_bil_prerm_qty := 0;
    END;

    tn_tot_bil_prerm_qty := vn.fss_get_tot_prerm_qty_h( is_acnt_no, ts_stk_cd, is_std_inq_dt);

 end if ;


 pxc_log_write('pss_inbil_aprv_p','tn_bil_prerm_qty :' || tn_bil_prerm_qty );
 pxc_log_write('pss_inbil_aprv_p','ts_trd_tp :' || ts_trd_tp );

  INSERT INTO vn.aaa10m00 ( acnt_no
        				   ,sub_no
        				   ,trd_dt
                           ,tot_trd_seq_no
                           ,trd_seq_no
                           ,trd_tp
                           ,rmrk_cd
                           ,mdm_tp
                           ,trd_mdm_tp		--
                           ,cncl_yn			--
                           ,org_trd_no		--
                           ,trd_amt			--   odd
                           ,cmsn			--   odd
                           ,adj_amt			--   odd
             			   ,sb_tax          --   odd
                           ,dpo_prerm		--
                           ,dpo_nowrm		--
                           ,stk_cd			--
                           ,stk_nm			--
                           ,sb_pri			--
                           ,sb_qty			--
                           ,bil_prerm_qty	--
                           ,bil_nowrm_qty	--
                           ,tot_bil_prerm	--
                           ,tot_bil_nowrm	--
                           ,book_amt		--
                           ,stk_tp			--
                           ,mth_dt			--  odd
                           ,lnd_tp			--
                           ,lnd_dt			--
                           ,lnd_int			--
                           ,agnt_yn			--
                           ,acnt_mng_bnh	--
                           ,work_bnh		--
                           ,work_mn			--
                           ,work_dtm		--
                           ,work_trm		--
                           ,anth_cd
                           ,anth_acnt_no
                           ,agnc_brch
                           ,proc_agnc_brch
                           ,cnte
                           ,cnfm_dt
  )	VALUES	(	          is_acnt_no    		-- acnt_no
                         ,is_sub_no			    -- sub_no
                         ,is_std_inq_dt			-- trd_dt
                         ,tn_tot_trd_seq_no			-- trd_seq_no
                         ,tn_trd_seq_no			-- trd_seq_no
                         ,ts_trd_tp				-- trd_tp
                         ,ts_rmrk_cd			-- rmrk_cd
                         ,'00'					-- mdm_tp
                         ,'99'					-- trd_mdm_tp
                         ,'N'					-- cncl_yn
                         ,0						-- org_trd_no
                         ,is_trd_amt			-- trd_amt
                         ,is_cmsn	    		-- cmsn
                         ,is_adj_amt			-- adj_amt
						 ,is_sb_tax             -- sb_tax
                         ,0						-- dpo_prerm
                         ,0						-- dpo_nowrm
                         ,ts_stk_cd				-- stk_cd
                         ,VN.fss_get_stk_nm( ts_stk_cd)
                         ,tn_inq_pri
                         ,(tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty)
                         ,tn_bil_prerm_qty  	                                        -- before dealing
                         ,tn_bil_prerm_qty + (tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty)  -- after dealing
						 ,tn_tot_bil_prerm_qty
						 ,tn_tot_bil_prerm_qty + (tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty)
                         ,(tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty ) * tn_inq_pri       -- trade unit amt
                         ,ts_stk_tp				-- stk_tp
                         ,ts_buy_dt				-- mth_dt
                         ,null					-- lnd_tp
                         ,null					-- lnd_dt
                         ,null					-- lnd_int
                         ,'N'					-- agnt_yn
                         ,vn.faa_acnt_bnh_cd_g( '0', is_acnt_no, is_sub_no)
                         ,is_work_bnh			-- work_bnh
                         ,is_work_mn				-- work_mn
                         ,sysdate				-- work_dtm
                         ,is_work_trm			-- work_trm
                         ,ts_anth_cd
                         ,ts_anth_acnt_no
                         ,vn.faa_acnt_bnh_cd_g( '3', is_acnt_no, is_sub_no)
                         ,is_dept_no2
                         ,ts_cnte
                         ,ts_trd_dt
          );

   ts_step := '6';

   /* update aaa10m00 and ssb01h00 */

   if  is_std_inq_dt <>  ts_trd_dt then

        select to_date(ts_trd_dt,'yyyymmdd') - to_date(is_std_inq_dt,'yyyymmdd')
          into tot_cnt
          from dual;

        pxc_log_write('pss_inbil_aprv_p','std_inq_dt aaa10m00 cnt:' || is_std_inq_dt || ' ' || tot_cnt);

        for c1 in 0..tot_cnt loop

	      select to_char((to_date(is_std_inq_dt,'yyyymmdd') + tn_loop_cnt),'yyyymmdd')
	        into ts_date
	        from dual;

		  if ts_date > is_std_inq_dt then   /* excepts trd_dt */

			pxc_log_write('pss_inbil_aprv_p',' update trd_dt  :' || ts_date);

		    BEGIN
		     update vn.aaa10m00
		 	    set bil_prerm_qty = bil_prerm_qty + (tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty)
		   	   	   ,bil_nowrm_qty = bil_nowrm_qty + (tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty)
				   ,tot_bil_prerm = tot_bil_prerm + (tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty)
				   ,tot_bil_nowrm = tot_bil_nowrm + (tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty)
		   	  where acnt_no = is_acnt_no
				and sub_no = is_sub_no
		        and stk_cd = ts_stk_cd
		        and (nvl(bil_prerm_qty,0) > 0 or nvl(bil_nowrm_qty,0) > 0)
		        and trd_dt = ts_date     ;

		    pxc_log_write('pss_inbil_aprv_p',' update sqlcode  :' || sqlcode);

            EXCEPTION
			   when OTHERS then
                    ts_step := '6.1';
			        raise_application_error(-20100,'error' );
		    END;

          end if ;

		  if vn.fxc_holi_ck(to_date( ts_date,'yyyymmdd' )) =  '0' then

          if  ts_date < ts_trd_dt then   /* excepts today  */

             pxc_log_write('pss_inbil_aprv_p','rgt_std_dt update :' || ts_date );

             merge into vn.ssb01h00
             using dual
             on (   acnt_no = is_acnt_no
				and sub_no  = is_sub_no
                and stk_cd = ts_stk_cd
                and rgt_std_dt = ts_date)

             when matched then
             update set own_qty = own_qty + (tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty)
                       ,sb_lim_qty = sb_lim_qty + tn_sb_lmt_qty
                       ,mov_lim_qty = mov_lim_qty + tn_mov_lmy_qty
					   ,delay_qty     =  Decode( Sign ( ts_apy_dt - ts_trd_dt ) , 1  , delay_qty     + tn_qty          , delay_qty    )
					   ,delay_sb_qty  =  Decode( Sign ( ts_apy_dt - ts_trd_dt ) , 1  , delay_sb_qty  + tn_sb_lmt_qty   , delay_sb_qty )
					   ,delay_mov_qty =  Decode( Sign ( ts_apy_dt - ts_trd_dt ) , 1  , delay_mov_qty + tn_mov_lmy_qty  , delay_mov_qty)
                       ,book_amt = book_amt + ((tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty) * tn_inq_pri)
                       ,work_mn = is_work_mn
                       ,work_dtm = sysdate
                       ,work_trm = is_work_trm

             when not matched then
             insert ( rgt_std_dt
             		, acnt_no
					, sub_no
             		, stk_cd
             		, own_qty
             		, book_amt
             		, sb_lim_qty
             		, mov_lim_qty
					, delay_qty
					, delay_sb_qty
					, delay_mov_qty
					, work_mn
					, work_dtm
					, work_trm
             		)
             values ( ts_date
             		, is_acnt_no
					, is_sub_no
             		, ts_stk_cd
             		, (tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty)
             		, ((tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty) * tn_inq_pri)
             		, tn_sb_lmt_qty
             		, tn_mov_lmy_qty
					, Decode( Sign ( ts_apy_dt - ts_trd_dt ) , 1  , tn_qty          , 0)
					, Decode( Sign ( ts_apy_dt - ts_trd_dt ) , 1  , tn_sb_lmt_qty   , 0)
					, Decode( Sign ( ts_apy_dt - ts_trd_dt ) , 1  , tn_mov_lmy_qty  , 0)
					, is_work_mn
					, sysdate
					, is_work_trm
             		);

           end if ;

         end if;
		 tn_loop_cnt := tn_loop_cnt + 1 ;
	   end loop;
   end if ;

    /*** updating ssb01m00 ***/

    BEGIN
      SELECT  decode( count(*) , 0 , 0 , 1 )
        INTO  tn_cnt
        FROM  vn.ssb01m00
       WHERE  acnt_no = is_acnt_no
		 AND  sub_no  = is_sub_no
         AND  stk_cd = ts_stk_cd ;
    EXCEPTION
     WHEN OTHERS THEN
          tn_cnt := 0;
    END;


   pxc_log_write('pss_inbil_aprv_p','ss01m00 I/U flag :' || tn_cnt );

   IF tn_cnt > 0	THEN

      UPDATE	vn.ssb01m00
      SET	    own_qty     = own_qty + (tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty)
               ,sb_lim_qty  = sb_lim_qty + tn_sb_lmt_qty
			   ,mov_lim_qty = mov_lim_qty + tn_mov_lmy_qty
               ,book_amt    = book_amt + ((tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty) * tn_inq_pri)
			   ,delay_qty     =  Decode( Sign ( ts_apy_dt - ts_trd_dt ) , 1  , delay_qty     + tn_qty          , delay_qty    )
			   ,delay_sb_qty  =  Decode( Sign ( ts_apy_dt - ts_trd_dt ) , 1  , delay_sb_qty  + tn_sb_lmt_qty   , delay_sb_qty )
		 	   ,delay_mov_qty =  Decode( Sign ( ts_apy_dt - ts_trd_dt ) , 1  , delay_mov_qty + tn_mov_lmy_qty  , delay_mov_qty)
               ,work_mn     = is_work_mn
               ,work_dtm    = sysdate
               ,work_trm    = is_work_trm
      WHERE	    acnt_no     = is_acnt_no
	  AND       sub_no      = is_sub_no
      AND	    stk_cd      = ts_stk_cd;

   ELSE

      INSERT INTO vn.ssb01m00 (	 acnt_no			--
                                ,sub_no				--
                                ,stk_cd				--
                                ,stk_tp
                                ,own_qty			--
                                ,book_amt			--
                                ,bclm_qty			--
                                ,mrtg_lnd_qty		--
                                ,sb_lim_qty
                                ,mov_lim_qty
                                ,outq_req_qty
                                ,lim_req_qty
								,delay_qty
								,delay_sb_qty
								,delay_mov_qty
                                ,work_mn			--
                                ,work_dtm			--
                                ,work_trm			--

      )	VALUES	(	 is_acnt_no			-- acnt_no
                    ,is_sub_no			-- stk_cd
                    ,ts_stk_cd			-- stk_cd
                    ,ts_stk_tp
                    ,(tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty)					-- own_qty
                    ,(tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty) * tn_inq_pri		-- book_amt
                    ,0					-- bclm_qty
                    ,0					-- mrtg_lnd_qty
                    ,tn_sb_lmt_qty
                    ,tn_mov_lmy_qty
                    ,0
                    ,0
					,Decode( Sign ( ts_apy_dt - ts_trd_dt ) , 1  , tn_qty          , 0     )
					,Decode( Sign ( ts_apy_dt - ts_trd_dt ) , 1  , tn_sb_lmt_qty   , 0     )
					,Decode( Sign ( ts_apy_dt - ts_trd_dt ) , 1  , tn_mov_lmy_qty  , 0     )
                    ,is_work_mn			-- work_mn
                    ,sysdate      -- work_dtm
                    ,is_work_trm    -- work_trm

     );

   END IF;

  /* LTHN-248 */
  if tn_rgt_tax_qty > 0 then
    vn.pxc_log_write('pss_inbil_aprv_p', 'detect type of tax quantity');
    vn.pxc_log_write('pss_inbil_aprv_p', 'is_apy_dt:' || is_apy_dt);
    vn.pxc_log_write('pss_inbil_aprv_p', 'tn_qty:' || tn_qty);
    vn.pxc_log_write('pss_inbil_aprv_p', 'tn_sb_lmt_qty:' || tn_sb_lmt_qty);

    /* Do logic cu khi nhap ngay giao dich la ngay hien tai thi doi voi giao dich nhap kho backdate, ck se o dang TDCN ke tu ngay nhap kho
       nen can set ngay giao dich = ngay nhap kho de dam bao logic xu ly khi lich su */
    if is_apy_dt = vwdate or is_apy_dt = '00000000' then
      tn_apy_dt := is_std_inq_dt;
    elsif is_apy_dt > vwdate then
      tn_apy_dt := is_apy_dt;
    end if;

    if is_apy_dt > vwdate and tn_qty > 0 then -- cho tdcn
      tn_tax_delay_qty := tn_rgt_tax_qty;
    end if;
    if (is_apy_dt = '00000000' or is_apy_dt <= vwdate) and tn_qty > 0 then -- tdcn
      tn_tax_qty := tn_rgt_tax_qty;
    end if;

    if is_apy_dt > vwdate and tn_sb_lmt_qty > 0 then -- cho hccn
      tn_tax_delay_sb_qty := tn_rgt_tax_qty;
    end if;
    if (is_apy_dt = '00000000' or is_apy_dt <= vwdate) and tn_sb_lmt_qty > 0 then -- hccn
      tn_tax_sb_lim_qty := tn_rgt_tax_qty;
    end if;
    vn.pxc_log_write('pss_inbil_aprv_p', 'update ssb05m10');
    vn.pxc_log_write('pss_inbil_aprv_p', 'tn_apy_dt: ' || tn_apy_dt);
    vn.pxc_log_write('pss_inbil_aprv_p', 'tn_tax_qty: ' || tn_tax_qty);
    vn.pxc_log_write('pss_inbil_aprv_p', 'tn_tax_delay_qty: ' || tn_tax_delay_qty);
    vn.pxc_log_write('pss_inbil_aprv_p', 'tn_tax_sb_lim_qty: ' || tn_tax_sb_lim_qty);
    vn.pxc_log_write('pss_inbil_aprv_p', 'tn_tax_delay_sb_qty: ' || tn_tax_delay_sb_qty);

    update ssb05m10
    set tax_qty = tax_qty + tn_tax_qty,
        tax_sb_lim_qty = tax_sb_lim_qty + tn_tax_sb_lim_qty,
        tax_delay_qty = tax_delay_qty + tn_tax_delay_qty,
        tax_delay_sb_qty = tax_delay_sb_qty + tn_tax_delay_sb_qty,
        work_mn = is_work_mn,
        work_dtm = sysdate,
        work_trm = is_work_trm
    where acnt_no = is_acnt_no
    and stk_cd = ts_stk_cd;
    if sql%rowcount = 0 then
      vn.pxc_log_write('pss_inbil_aprv_p', 'insert ssb05m10');
      insert into ssb05m10
      ( acnt_no,
        stk_cd,
        tax_qty,
        tax_sb_lim_qty,
        tax_delay_qty,
        tax_delay_sb_qty,
        create_mn,
        create_dtm,
        create_trm)
      values
      ( is_acnt_no,
        ts_stk_cd,
        tn_tax_qty,
        tn_tax_sb_lim_qty,
        tn_tax_delay_qty,
        tn_tax_delay_sb_qty,
        is_work_mn,
        sysdate,
        is_work_trm
        );
    end if;
    /* Backup to history table */
    vn.pxc_log_write('pss_inbil_aprv_p', 'Insert into ssb05h10');
    if is_std_inq_dt = vwdate then
      vn.pss_rgt_tax_history
      ( is_acnt_no,     -- i_acnt_no   ,
        ts_stk_cd,      -- i_stk_cd    ,
        is_std_inq_dt,        -- i_proc_dt   ,
        fbm_rmrk_nm_q(ts_rmrk_cd),           -- i_cnte      ,
        is_work_mn   ,
        is_work_trm
      );
    elsif is_std_inq_dt < vwdate then -- vn_count tn_min_proc_dt tn_max_proc_dt
      select min (proc_dt)
          into tn_min_proc_dt
          from ssb05h10
         where acnt_no = is_acnt_no
          and stk_cd = ts_stk_cd
          and proc_dt > is_std_inq_dt;

      vn.pxc_log_write('pss_inbil_aprv_p', 'tn_min_proc_dt: ' || tn_min_proc_dt);

      select max (proc_dt), max (id)
              into tn_max_proc_dt, tn_max_id
              from ssb05h10
             where acnt_no = is_acnt_no
              and stk_cd = ts_stk_cd
              and proc_dt <= is_std_inq_dt;
          vn.pxc_log_write('pss_inbil_aprv_p', 'tn_max_proc_dt: ' || tn_max_proc_dt);
          vn.pxc_log_write('pss_inbil_aprv_p', 'tn_max_id: ' || tn_max_id);

      if tn_apy_dt = vwdate then
        if tn_min_proc_dt is null then
          insert into ssb05h10
          ( id,
            proc_dt,
            acnt_no,
            stk_cd,
            tax_qty,
            tax_sb_lim_qty,
            tax_delay_qty,
            tax_delay_sb_qty,
            wtax_qty,
            wtax_sb_lim_qty,
            wtax_delay_qty,
            wtax_delay_sb_qty,
            cnte,
            create_mn,
            create_dtm,
            create_trm,
            work_mn,
            work_dtm,
            work_trm,
            backup_mn,
            backup_dtm,
            backup_trm)
          select ssb05h10_seq.nextval,
                is_std_inq_dt,
                acnt_no,
                stk_cd,
                tax_qty - tn_tax_qty,
                tax_sb_lim_qty - tn_tax_sb_lim_qty,
                tax_delay_qty + tn_tax_qty,
                tax_delay_sb_qty + tn_tax_sb_lim_qty,
                wtax_qty,
                wtax_sb_lim_qty,
                wtax_delay_qty,
                wtax_delay_sb_qty,
                'Backdate 0 ' || fbm_rmrk_nm_q(ts_rmrk_cd),
                create_mn,
                create_dtm,
                create_trm,
                work_mn,
                work_dtm,
                work_trm,
                is_work_mn,
                sysdate,
                is_work_trm
            from ssb05m10
          where acnt_no = is_acnt_no
            and stk_cd = ts_stk_cd;

          vn.pss_rgt_tax_history
          ( is_acnt_no,     -- i_acnt_no   ,
            ts_stk_cd,      -- i_stk_cd    ,
            '',        -- i_proc_dt   ,
            'Backdate 1 ' || fbm_rmrk_nm_q(ts_rmrk_cd),           -- i_cnte      ,
            is_work_mn   ,
            is_work_trm
          );
        elsif tn_min_proc_dt is not null then
          /*update ssb05h10
            set tax_delay_qty = tax_delay_qty + tn_tax_qty,
                tax_delay_sb_qty = tax_delay_sb_qty + tn_tax_sb_lim_qty,
                cnte = case when substr(cnte,1,8) = 'Backdate' then cnte else 'Backdate ' || cnte end,
                work_mn = is_work_mn,
                work_dtm = sysdate,
                work_trm = is_work_trm
          where acnt_no = is_acnt_no
            and stk_cd = ts_stk_cd
            and proc_dt >= tn_min_proc_dt
            and proc_dt <> vwdate;

          update ssb05h10
            set tax_qty = tax_qty + tn_tax_qty,
                tax_sb_lim_qty = tax_sb_lim_qty + tn_tax_sb_lim_qty,
                cnte = case when substr(cnte,1,8) = 'Backdate' then cnte else 'Backdate ' || cnte end,
                work_mn = is_work_mn,
                work_dtm = sysdate,
                work_trm = is_work_trm
          where acnt_no = is_acnt_no
            and stk_cd = ts_stk_cd
            and proc_dt = vwdate;*/

          for c1 in (
          select max(id) as id_max, proc_dt, acnt_no, stk_cd
            from ssb05h10
           where acnt_no = is_acnt_no
             and stk_cd = ts_stk_cd
             and proc_dt >= tn_min_proc_dt
           group by proc_dt,acnt_no,stk_cd)
          loop
            insert into ssb05h10
            ( id,
              proc_dt,
              acnt_no,
              stk_cd,
              tax_qty,
              tax_sb_lim_qty,
              tax_delay_qty,
              tax_delay_sb_qty,
              wtax_qty,
              wtax_sb_lim_qty,
              wtax_delay_qty,
              wtax_delay_sb_qty,
              cnte,
              create_mn,
              create_dtm,
              create_trm,
              work_mn,
              work_dtm,
              work_trm,
              backup_mn,
              backup_dtm,
              backup_trm)
            select ssb05h10_seq.nextval,
                  c1.proc_dt,
                  acnt_no,
                  stk_cd,
                  tax_qty,
                  tax_sb_lim_qty,
                  tax_delay_qty + tn_tax_qty,
                  tax_delay_sb_qty + tn_tax_sb_lim_qty,
                  wtax_qty,
                  wtax_sb_lim_qty,
                  wtax_delay_qty,
                  wtax_delay_sb_qty,
                  'Backdate 2 ' || fbm_rmrk_nm_q(ts_rmrk_cd),
                  create_mn,
                  create_dtm,
                  create_trm,
                  work_mn,
                  work_dtm,
                  work_trm,
                  is_work_mn,
                  sysdate,
                  is_work_trm
              from ssb05h10
            where acnt_no = c1.acnt_no
              and stk_cd = c1.stk_cd
              and proc_dt = c1.proc_dt
              and id = c1.id_max;
          end loop;

          select max (proc_dt), max (id)
              into tn_max_proc_dt, tn_max_id
              from ssb05h10
             where acnt_no = is_acnt_no
              and stk_cd = ts_stk_cd
              and proc_dt <= is_std_inq_dt;
          vn.pxc_log_write('pss_inbil_aprv_p', 'tn_max_proc_dt: ' || tn_max_proc_dt);
          vn.pxc_log_write('pss_inbil_aprv_p', 'tn_max_id: ' || tn_max_id);

          if tn_max_proc_dt is null then
            insert into ssb05h10
            ( id,
              proc_dt,
              acnt_no,
              stk_cd,
              tax_qty,
              tax_sb_lim_qty,
              tax_delay_qty,
              tax_delay_sb_qty,
              wtax_qty,
              wtax_sb_lim_qty,
              wtax_delay_qty,
              wtax_delay_sb_qty,
              cnte,
              create_mn,
              create_dtm,
              create_trm,
              backup_mn,
              backup_dtm,
              backup_trm)
            values
            ( ssb05h10_seq.nextval,
              is_std_inq_dt,
              is_acnt_no,
              ts_stk_cd,
              0,
              0,
              tn_tax_qty, -- Cho TDCN
              tn_tax_sb_lim_qty, -- Cho HCCN
              0,
              0,
              0,
              0,
              'Backdate 3 ' || fbm_rmrk_nm_q(ts_rmrk_cd),
              is_work_mn,
              sysdate,
              is_work_trm,
              is_work_mn,
              sysdate,
              is_work_trm
            );
          elsif tn_max_proc_dt is not null then
            vn.pxc_log_write('pss_inbil_aprv_p', 'tn_max_proc_dt is not null, apy_dt = vwdate.');

            insert into ssb05h10
            ( id,
              proc_dt,
              acnt_no,
              stk_cd,
              tax_qty,
              tax_sb_lim_qty,
              tax_delay_qty,
              tax_delay_sb_qty,
              wtax_qty,
              wtax_sb_lim_qty,
              wtax_delay_qty,
              wtax_delay_sb_qty,
              cnte,
              create_mn,
              create_dtm,
              create_trm,
              work_mn,
              work_dtm,
              work_trm,
              backup_mn,
              backup_dtm,
              backup_trm)
            select ssb05h10_seq.nextval,
                  is_std_inq_dt,
                  acnt_no,
                  stk_cd,
                  tax_qty,
                  tax_sb_lim_qty ,
                  tax_delay_qty + tn_tax_qty,
                  tax_delay_sb_qty + tn_tax_sb_lim_qty,
                  wtax_qty,
                  wtax_sb_lim_qty,
                  wtax_delay_qty,
                  wtax_delay_sb_qty,
                  'Backdate 4 ' || fbm_rmrk_nm_q(ts_rmrk_cd),
                  create_mn,
                  create_dtm,
                  create_trm,
                  work_mn,
                  work_dtm,
                  work_trm,
                  is_work_mn,
                  sysdate,
                  is_work_trm
              from ssb05h10
            where acnt_no = is_acnt_no
              and stk_cd = ts_stk_cd
              and proc_dt = tn_max_proc_dt
              and id = tn_max_id;
          end if;

          vn.pss_rgt_tax_history
          ( is_acnt_no,     -- i_acnt_no   ,
            ts_stk_cd,      -- i_stk_cd    ,
            '',        -- i_proc_dt   ,
            'Backdate 5 ' || fbm_rmrk_nm_q(ts_rmrk_cd),           -- i_cnte      ,
            is_work_mn   ,
            is_work_trm
          );
        end if;
      elsif tn_apy_dt > vwdate then
        if tn_min_proc_dt is null then
          vn.pss_rgt_tax_history
          ( is_acnt_no,     -- i_acnt_no   ,
            ts_stk_cd,      -- i_stk_cd    ,
            is_std_inq_dt,        -- i_proc_dt   ,
            'Backdate 6 ' ||fbm_rmrk_nm_q(ts_rmrk_cd),           -- i_cnte      ,
            is_work_mn   ,
            is_work_trm
          );
        elsif tn_min_proc_dt is not null then
          /*update ssb05h10
            set tax_delay_qty = tax_delay_qty + tn_tax_delay_qty,
                tax_delay_sb_qty = tax_delay_sb_qty + tn_tax_delay_sb_qty,
                cnte = case when substr(cnte,1,8) = 'Backdate' then cnte else 'Backdate ' || cnte end,
                work_mn = is_work_mn,
                work_dtm = sysdate,
                work_trm = is_work_trm
          where acnt_no = is_acnt_no
            and stk_cd = ts_stk_cd
            and proc_dt >= tn_min_proc_dt;*/

          for c2 in (
          select max(id) as id_max, proc_dt, acnt_no, stk_cd
            from ssb05h10
           where acnt_no = is_acnt_no
             and stk_cd = ts_stk_cd
             and proc_dt >= tn_min_proc_dt
           group by proc_dt,acnt_no,stk_cd)
          loop
            vn.pxc_log_write('pss_inbil_aprv_p','c2.id_max: ' || c2.id_max);
            insert into ssb05h10
            ( id,
              proc_dt,
              acnt_no,
              stk_cd,
              tax_qty,
              tax_sb_lim_qty,
              tax_delay_qty,
              tax_delay_sb_qty,
              wtax_qty,
              wtax_sb_lim_qty,
              wtax_delay_qty,
              wtax_delay_sb_qty,
              cnte,
              create_mn,
              create_dtm,
              create_trm,
              work_mn,
              work_dtm,
              work_trm,
              backup_mn,
              backup_dtm,
              backup_trm)
            select ssb05h10_seq.nextval,
                  c2.proc_dt,
                  acnt_no,
                  stk_cd,
                  tax_qty,
                  tax_sb_lim_qty,
                  tax_delay_qty + tn_tax_qty,
                  tax_delay_sb_qty + tn_tax_sb_lim_qty,
                  wtax_qty,
                  wtax_sb_lim_qty,
                  wtax_delay_qty,
                  wtax_delay_sb_qty,
                  'Backdate 7 ' || fbm_rmrk_nm_q(ts_rmrk_cd),
                  create_mn,
                  create_dtm,
                  create_trm,
                  work_mn,
                  work_dtm,
                  work_trm,
                  is_work_mn,
                  sysdate,
                  is_work_trm
              from ssb05h10
            where acnt_no = c2.acnt_no
              and stk_cd = c2.stk_cd
              and proc_dt = c2.proc_dt
              and id = c2.id_max;
          end loop;

          if tn_max_proc_dt is null then
            insert into ssb05h10
            ( id,
              proc_dt,
              acnt_no,
              stk_cd,
              tax_qty,
              tax_sb_lim_qty,
              tax_delay_qty,
              tax_delay_sb_qty,
              wtax_qty,
              wtax_sb_lim_qty,
              wtax_delay_qty,
              wtax_delay_sb_qty,
              cnte,
              create_mn,
              create_dtm,
              create_trm,
              backup_mn,
              backup_dtm,
              backup_trm)
            values
            ( ssb05h10_seq.nextval,
              is_std_inq_dt,
              is_acnt_no,
              ts_stk_cd,
              0,
              0,
              tn_tax_delay_qty, -- Cho TDCN
              tn_tax_delay_sb_qty, -- Cho HCCN
              0,
              0,
              0,
              0,
              'Backdate 8 ' || fbm_rmrk_nm_q(ts_rmrk_cd),
              is_work_mn,
              sysdate,
              is_work_trm,
              is_work_mn,
              sysdate,
              is_work_trm
            );
          elsif tn_max_proc_dt is not null then
            insert into ssb05h10
            ( id,
              proc_dt,
              acnt_no,
              stk_cd,
              tax_qty,
              tax_sb_lim_qty,
              tax_delay_qty,
              tax_delay_sb_qty,
              wtax_qty,
              wtax_sb_lim_qty,
              wtax_delay_qty,
              wtax_delay_sb_qty,
              cnte,
              create_mn,
              create_dtm,
              create_trm,
              work_mn,
              work_dtm,
              work_trm,
              backup_mn,
              backup_dtm,
              backup_trm)
            select ssb05h10_seq.nextval,
                  is_std_inq_dt,
                  acnt_no,
                  stk_cd,
                  tax_qty,
                  tax_sb_lim_qty ,
                  tax_delay_qty + tn_tax_delay_qty,
                  tax_delay_sb_qty + tn_tax_delay_sb_qty,
                  wtax_qty,
                  wtax_sb_lim_qty,
                  wtax_delay_qty,
                  wtax_delay_sb_qty,
                  'Backdate 9 ' || fbm_rmrk_nm_q(ts_rmrk_cd),
                  create_mn,
                  create_dtm,
                  create_trm,
                  work_mn,
                  work_dtm,
                  work_trm,
                  is_work_mn,
                  sysdate,
                  is_work_trm
              from ssb05h10
            where acnt_no = is_acnt_no
              and stk_cd = ts_stk_cd
              and proc_dt = tn_max_proc_dt
              and id = tn_max_id;
          end if; /*  */
        end if; /*  */
      elsif tn_apy_dt < vwdate then
        /* Chi co 1 truong hop la tn_apy_dt = is_std_inq_dt */
        if tn_max_proc_dt is null then
          insert into ssb05h10
            ( id,
              proc_dt,
              acnt_no,
              stk_cd,
              tax_qty,
              tax_sb_lim_qty,
              tax_delay_qty,
              tax_delay_sb_qty,
              wtax_qty,
              wtax_sb_lim_qty,
              wtax_delay_qty,
              wtax_delay_sb_qty,
              cnte,
              create_mn,
              create_dtm,
              create_trm,
              backup_mn,
              backup_dtm,
              backup_trm)
            values
            ( ssb05h10_seq.nextval,
              is_std_inq_dt,
              is_acnt_no,
              ts_stk_cd,
              tn_tax_qty, -- TDCN
              tn_tax_sb_lim_qty, -- HCCN
              0, -- Cho TDCN
              0, -- Cho HCCN
              0,
              0,
              0,
              0,
              'Backdate 10 ' || fbm_rmrk_nm_q(ts_rmrk_cd),
              is_work_mn,
              sysdate,
              is_work_trm,
              is_work_mn,
              sysdate,
              is_work_trm
            );
        elsif tn_max_proc_dt is not null then
          insert into ssb05h10
          ( id,
            proc_dt,
            acnt_no,
            stk_cd,
            tax_qty,
            tax_sb_lim_qty,
            tax_delay_qty,
            tax_delay_sb_qty,
            wtax_qty,
            wtax_sb_lim_qty,
            wtax_delay_qty,
            wtax_delay_sb_qty,
            cnte,
            create_mn,
            create_dtm,
            create_trm,
            work_mn,
            work_dtm,
            work_trm,
            backup_mn,
            backup_dtm,
            backup_trm)
          select ssb05h10_seq.nextval,
                is_std_inq_dt,
                acnt_no,
                stk_cd,
                tax_qty + tn_tax_qty,
                tax_sb_lim_qty + tn_tax_sb_lim_qty,
                tax_delay_qty,
                tax_delay_sb_qty,
                wtax_qty,
                wtax_sb_lim_qty,
                wtax_delay_qty,
                wtax_delay_sb_qty,
                'Backdate 11 ' || fbm_rmrk_nm_q(ts_rmrk_cd),
                create_mn,
                create_dtm,
                create_trm,
                work_mn,
                work_dtm,
                work_trm,
                is_work_mn,
                sysdate,
                is_work_trm
            from ssb05h10
          where acnt_no = is_acnt_no
            and stk_cd = ts_stk_cd
            and proc_dt = tn_max_proc_dt
            and id = tn_max_id;
        end if;

        for c3 in (select max(id) as id_max, proc_dt, acnt_no,stk_cd
                    from ssb05h10
                    where acnt_no = is_acnt_no
                      and stk_cd = ts_stk_cd
                      and proc_dt > is_std_inq_dt
                    group by proc_dt, acnt_no,stk_cd)
        loop
          vn.pxc_log_write('pss_inbil_aprv_p','c3.id_max: ' || c3.id_max);
          insert into ssb05h10
          ( id,
            proc_dt,
            acnt_no,
            stk_cd,
            tax_qty,
            tax_sb_lim_qty,
            tax_delay_qty,
            tax_delay_sb_qty,
            wtax_qty,
            wtax_sb_lim_qty,
            wtax_delay_qty,
            wtax_delay_sb_qty,
            cnte,
            create_mn,
            create_dtm,
            create_trm,
            work_mn,
            work_dtm,
            work_trm,
            backup_mn,
            backup_dtm,
            backup_trm)
          select ssb05h10_seq.nextval,
                c3.proc_dt,
                acnt_no,
                stk_cd,
                tax_qty + tn_tax_qty,
                tax_sb_lim_qty + tn_tax_sb_lim_qty,
                tax_delay_qty,
                tax_delay_sb_qty,
                wtax_qty,
                wtax_sb_lim_qty,
                wtax_delay_qty,
                wtax_delay_sb_qty,
                'Backdate 12 ' || fbm_rmrk_nm_q(ts_rmrk_cd),
                create_mn,
                create_dtm,
                create_trm,
                work_mn,
                work_dtm,
                work_trm,
                is_work_mn,
                sysdate,
                is_work_trm
            from ssb05h10
          where acnt_no = c3.acnt_no
            and stk_cd = c3.stk_cd
            and proc_dt = c3.proc_dt
            and id = c3.id_max;
        end loop;
      end if; /*  */
      /* Backup tu ssb05m10 xuong ssb05h10 them 1 lan nua */
      vn.pss_rgt_tax_history
      ( is_acnt_no,     -- i_acnt_no   ,
        ts_stk_cd,      -- i_stk_cd    ,
        '',        -- i_proc_dt   ,
        'Backdate 13 ' ||fbm_rmrk_nm_q(ts_rmrk_cd),           -- i_cnte      ,
        is_work_mn   ,
        is_work_trm
      );
    end if; /* End Backup to history table */
  end if; /* End tn_rgt_tax_qty > 0 */
  /* End LTHN-248 */

/* ssb05m00 */
  ts_step := '7';

  vn.pxc_log_write('pss_inbil_aprv_p','SSB05M00 ');

  UPDATE   VN.SSB05M00
  SET       inq_dt = ts_trd_dt
           ,std_inq_dt = is_std_inq_dt
           ,trd_seq_no = tn_trd_seq_no
           ,cncl_trd_no = 0
       ,apy_dt     = ts_apy_dt
           ,end_yn     = 'Y'
           ,err_msg = 'OK'
           ,work_mn = is_work_mn
           ,work_dtm = sysdate
           ,work_trm = is_work_trm
  WHERE  proc_dt = is_proc_dt
  AND  acnt_no = is_acnt_no
  AND   sub_no  = is_sub_no
  ANd   nvl(end_yn,'N') <> 'Y'
  AND  seq_no = to_number(is_seq_no);
  vn.pxc_log_write('pss_inbil_aprv_p',tn_trd_seq_no);
  vn.pxc_log_write('pss_inbil_aprv_p','pdl_crd_loan_rt_proc_td ');

/*******************************/
/* call evaluation for margin  */
/*******************************/

vn.pdl_crd_loan_rt_proc_td
        (ts_trd_dt
        ,'2' -- stock
        ,is_acnt_no
        ,is_sub_no
        ,tn_trd_seq_no
        ,is_work_mn
        ,is_work_trm
        ,o_cnt
       );

    vn.pxc_log_write('pss_inbil_aprv_p','pdl_crd_loan_rt_proc_td ['|| o_cnt ||']');

 /* skip order table data    */

 os_end_yn := 'Y';
 os_err_msg := 'OK';
 os_inq_dt := ts_wdate;


 if ts_rmrk_cd in ('603','604') then
   os_inq_dt := tn_trd_seq_no ;
 end if  ;

 /* right proc  */

 vn.psr_rgt_std_past_proc(
            is_std_inq_dt,
            ts_stk_cd,
            is_acnt_no,
            is_sub_no,
            tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty,
            '1',
            is_work_mn,
            is_work_trm
            );

  /* Send SMS */
  if ts_rmrk_cd in ('201','202') then
    if ts_rmrk_cd = '201' then -- Luu ky ck
      ts_fnc_cd := 'F02115';
      ts_sms_msg := '||' || is_acnt_no || '||' || is_sub_no || '||' || tn_qty || '||' || ts_stk_cd;
    elsif ts_rmrk_cd = '202' then -- nhan chuyen khoan tu cty khac
      ts_fnc_cd := 'F02105';
      ts_sms_msg := '||' || is_acnt_no || '||' || is_sub_no || '||' || ts_stk_cd || '||' || tn_qty;
    end if;
    --
    vn.pxc_sms_ins(
      null,         --i_send_dt          in varchar2,                         -- can put NULL, get from sysdate
      null,         --i_recv_phone_no    in varchar2,                         -- can put NULL, get from account
      null,         --i_send_phone_no    in varchar2,                         -- can put NULL, get from company
      ts_fnc_cd,    --i_func_cd          in varchar2,                         -- NOT null
      null,         --i_msg_lang         in varchar2,                         -- can put NULL, get from account
      ts_sms_msg,   --i_sms_msg          in varchar2,                         -- NOT null
      is_work_mn,   --i_work_mn          in varchar2,                         -- can put NULL
      is_work_trm,  --i_work_trm         in varchar2,                         -- can put NULL
      is_acnt_no,   --i_acnt_no          in varchar2      default null,       -- can put NULL
      is_sub_no     --i_sub_no           in varchar2      default null        -- can put NULL
    );

  end if; -- end SMS
 RETURN;

 EXCEPTION
 WHEN   ERR_RTN  THEN
   vn.pxc_log_write('pss_inbil_aprv_p','ts_step-'||ts_step);
   raise_application_error(-20100, os_err_msg || ':[pss_inbil_aprv_p ' || ts_step || '] ' || os_err_msg);
   RETURN;

  WHEN  NO_DATA_FOUND  THEN
   vn.pxc_log_write('pss_inbil_aprv_p','ts_step-'||ts_step);
    raise_application_error(-20200, '[pss_inbil_aprv_p ' || ts_step || '] ' || SQLERRM);
    RETURN;

  WHEN  OTHERS  THEN
   vn.pxc_log_write('pss_inbil_aprv_p','ts_step-'||ts_step);
     raise_application_error(-20300, '[pss_inbil_aprv_p ' || ts_step || '] ' || SQLERRM);
     RETURN;

 END pss_inbil_aprv_p ;
/

