create FUNCTION    fdl_get_pia_limit
(
    i_acnt_no        in   varchar2,
    i_sub_no         in   varchar2,
    i_rt_tp          in   varchar2
)   RETURN  NUMBER AS

    o_out_number          number    := 0;

    ts_vwdate             VARCHAR2(08) := NULL;
    t_onl_acnt_limit      NUMBER := 0;
    t_onl_all_limit       NUMBER := 0;
    t_onl_off_all_limit   NUMBER := 0;

    t_onl_acnt_lnd        NUMBER := 0;
    t_onl_all_lnd         NUMBER := 0;
    t_onl_all_lnd_app     NUMBER := 0;
    t_onl_off_all_lnd     NUMBER := 0;

    t_onl_acnt_remain     NUMBER := 0;
    t_onl_all_remain      NUMBER := 0;
    t_onl_off_all_remain  NUMBER := 0;

begin

/*============================================================================*/
/* Valiabl Initialize
/*============================================================================*/
    o_out_number   :=  0;
    t_onl_acnt_limit   :=  0;
    t_onl_acnt_lnd     :=  0;
    t_onl_all_limit   :=  0;
    t_onl_all_lnd     :=  0;
    t_onl_off_all_limit   :=  0;
    t_onl_all_lnd_app     :=  0;
    t_onl_off_all_lnd     :=  0;
    t_onl_acnt_remain     := 0;
    t_onl_all_remain      := 0;
    t_onl_off_all_remain  := 0;
    ts_vwdate             :=  vn.vwdate;

    IF  i_rt_tp  =  '00' THEN -- han muc online

        t_onl_acnt_limit := vn.fdl_get_pia_online_acnt_limit (i_acnt_no,i_sub_no,vn.vwdate());

        FOR C1 IN (
            select  nvl(sum(nvl(lnd_amt,0)),0)  lnd_amt
              from  vn.dlm03m00
             where  lnd_tp          =  '10'
               and  acnt_no         =  i_acnt_no
               and  sub_no          =  i_sub_no
               and  lnd_dt          =  ts_vwdate
               and  lnd_proc_stat   in ('A', 'T')
        ) LOOP
            t_onl_acnt_lnd := nvl(C1.lnd_amt,0);
        END LOOP;

        t_onl_acnt_remain := greatest(t_onl_acnt_limit - t_onl_acnt_lnd, 0);

        select  NVL(onl_all_limit, 0)
          into  t_onl_all_limit
          from  vn.dlm09m50 ;

        FOR C2 IN (
            select  nvl(sum(nvl(lnd_amt,0)),0)  lnd_amt
              from  vn.dlm03m00
             where  lnd_tp          =  '10'
               and  lnd_dt          =  ts_vwdate
               and  lnd_proc_stat   in ('A', 'T')
        ) LOOP
            t_onl_all_lnd := nvl(C2.lnd_amt,0);
        END LOOP;

        t_onl_all_remain := greatest(t_onl_all_limit - t_onl_all_lnd, 0);

        select  NVL(onl_off_all_limt, 0)
          into  t_onl_off_all_limit
          from  vn.dlm09m50 ;

        FOR C3 IN (
            select  nvl(sum(nvl(lnd_amt,0)),0)  lnd_amt
              from  vn.dlm03m00
             where  lnd_tp          =  '10'
               and  lnd_dt          =  ts_vwdate
               and  lnd_proc_stat   in ('A')
        ) LOOP
            t_onl_all_lnd_app := nvl(C3.lnd_amt,0);
        END LOOP;

        FOR C4 IN (
            select  nvl(sum(nvl(lnd_amt,0)),0)  lnd_amt
              from  vn.dlm01m00
             where  lnd_tp          =  '10'
               and  lnd_dt          =  ts_vwdate
        ) LOOP
            t_onl_off_all_lnd := nvl(C4.lnd_amt,0);
        END LOOP;

        t_onl_off_all_remain := greatest(t_onl_off_all_limit - t_onl_all_lnd_app - t_onl_off_all_lnd, 0);

        o_out_number := least(t_onl_acnt_remain, t_onl_all_remain, t_onl_off_all_remain);

        RETURN o_out_number;

    ELSIF  i_rt_tp  =  '01' THEN --o_onl_acnt_limit_rm
        t_onl_acnt_limit := vn.fdl_get_pia_online_acnt_limit (i_acnt_no,i_sub_no,vn.vwdate());

        FOR C1 IN (
            select  nvl(sum(nvl(lnd_amt,0)),0)  lnd_amt
              from  vn.dlm03m00
             where  lnd_tp          =  '10'
               and  acnt_no         =  i_acnt_no
               and  sub_no          =  i_sub_no
               and  lnd_dt          =  ts_vwdate
               and  lnd_proc_stat   in ('A', 'T')
        ) LOOP
            t_onl_acnt_lnd := nvl(C1.lnd_amt,0);
        END LOOP;

        o_out_number := greatest(t_onl_acnt_limit - t_onl_acnt_lnd, 0);

        RETURN o_out_number;

    ELSIF  i_rt_tp  =  '02' THEN --o_onl_all_limit_rm
        select  NVL(onl_all_limit, 0)
          into  t_onl_all_limit
          from  vn.dlm09m50 ;

        FOR C1 IN (
            select  nvl(sum(nvl(lnd_amt,0)),0)  lnd_amt
              from  vn.dlm03m00
             where  lnd_tp          =  '10'
               and  lnd_dt          =  ts_vwdate
               and  lnd_proc_stat   in ('A', 'T')
        ) LOOP
            t_onl_all_lnd := nvl(C1.lnd_amt,0);
        END LOOP;

        o_out_number := greatest(t_onl_all_limit - t_onl_all_lnd, 0);

        RETURN o_out_number;

    ELSIF  i_rt_tp  =  '03' THEN -- han muc offline: o_onl_off_all_limit_rm
        select  NVL(onl_off_all_limt, 0)
          into  t_onl_off_all_limit
          from  vn.dlm09m50 ;

        FOR C1 IN (
            select  nvl(sum(nvl(lnd_amt,0)),0)  lnd_amt
              from  vn.dlm03m00
             where  lnd_tp          =  '10'
               and  lnd_dt          =  ts_vwdate
               and  lnd_proc_stat   in ('A')
        ) LOOP
            t_onl_all_lnd_app := nvl(C1.lnd_amt,0);
        END LOOP;

        FOR C2 IN (
            select  nvl(sum(nvl(lnd_amt,0)),0)  lnd_amt
              from  vn.dlm01m00
             where  lnd_tp          =  '10'
               and  lnd_dt          =  ts_vwdate
        ) LOOP
            t_onl_off_all_lnd := nvl(C2.lnd_amt,0);
        END LOOP;

        o_out_number := greatest(t_onl_off_all_limit - t_onl_all_lnd_app - t_onl_off_all_lnd, 0);

        RETURN o_out_number;

    ELSIF  i_rt_tp  =  '04' THEN --o_onl_acnt_limit_used

        FOR C1 IN (
            select  nvl(sum(nvl(lnd_amt,0)),0)  lnd_amt
              from  vn.dlm03m00
             where  lnd_tp          =  '10'
               and  acnt_no         =  i_acnt_no
               and  sub_no          =  i_sub_no
               and  lnd_dt          =  ts_vwdate
               and  lnd_proc_stat   in ('A', 'T')
        ) LOOP
            t_onl_acnt_lnd := nvl(C1.lnd_amt,0);
        END LOOP;

        o_out_number := greatest(t_onl_acnt_lnd, 0);

        RETURN o_out_number;

    ELSIF  i_rt_tp  =  '05' THEN --o_onl_all_limit_used

        FOR C1 IN (
            select  nvl(sum(nvl(lnd_amt,0)),0)  lnd_amt
              from  vn.dlm03m00
             where  lnd_tp          =  '10'
               and  lnd_dt          =  ts_vwdate
               and  lnd_proc_stat   in ('A', 'T')
        ) LOOP
            t_onl_all_lnd := nvl(C1.lnd_amt,0);
        END LOOP;

        o_out_number := greatest(t_onl_all_lnd, 0);

        RETURN o_out_number;

    ELSIF  i_rt_tp  =  '06' THEN --o_onl_off_all_limit_used

        FOR C1 IN (
            select  nvl(sum(nvl(lnd_amt,0)),0)  lnd_amt
              from  vn.dlm03m00
             where  lnd_tp          =  '10'
               and  lnd_dt          =  ts_vwdate
               and  lnd_proc_stat   in ('A')
        ) LOOP
            t_onl_all_lnd_app := nvl(C1.lnd_amt,0);
        END LOOP;

        FOR C2 IN (
            select  nvl(sum(nvl(lnd_amt,0)),0)  lnd_amt
              from  vn.dlm01m00
             where  lnd_tp          =  '10'
               and  lnd_dt          =  ts_vwdate
        ) LOOP
            t_onl_off_all_lnd := nvl(C2.lnd_amt,0);
        END LOOP;

        o_out_number := greatest(t_onl_all_lnd_app + t_onl_off_all_lnd, 0);

        RETURN o_out_number;

    ELSE
        RETURN 0;
    END IF;

END fdl_get_pia_limit;
/

