create function fbm_check_in_out_bank
(
    i_bank_cd   in   varchar2,
    i_bank_acnt_no   in varchar2,
    i_bank_brch      in varchar2
)
    return          varchar2
as
    o_check_bank    varchar2(100) ;
    t_err_txt       varchar2(100) ;
    o_check_bank1   varchar2(100) ;
    o_check_invaild number := 0 ;
    o_check_bank_cd1 varchar2(10);
     o_check_bank_cd2 varchar2(10);

begin

/*============================================================================*/
/* º¯¼ö ÃÊ±âÈ­                                                                */
/*============================================================================*/


/*============================================================================*/
/* »ç¿ø¸í Á¶È¸                                                                */
/*============================================================================*/

    begin
         select a.BANK_CODE
         into o_check_bank
         from vn.VW_DRCWDM01 a,vn.cww10m00 b
         where a.BANK_ACC_NUM =i_bank_cd
         and a.BANK_CODE = b.bankcode;
    exception
        when  NO_DATA_FOUND  then
               return 'N';
        when  OTHERS         then
            t_err_txt  :=  '¿À·ù-['||to_char(sqlcode)||']';
            raise_application_error (-20100, t_err_txt);
    end;
    if i_bank_brch ='XXXX' then
    begin
         select nvl(b.BANK_CODE,'XXX')
         into o_check_bank1
         from vn.VW_DRCWDAAA b
         where b.BANK_ACC_NUM = i_bank_acnt_no
         and rownum =1;
    exception
        when  NO_DATA_FOUND  then
      return  'N';
        when  OTHERS         then
            t_err_txt  :=  '¿À·ù-['||to_char(sqlcode)||']';
            raise_application_error (-20100, t_err_txt);
    end;

    else
    begin
         select count(*)
         into o_check_invaild
         from vn.cww10m00 b
         where b.BANKCODE =i_bank_brch;
    exception
        when  NO_DATA_FOUND  then
               return 'M';
        when  OTHERS         then
            t_err_txt  :=  '¿À·ù-['||to_char(sqlcode)||']';
            raise_application_error (-20100, t_err_txt);
    end;

    if o_check_invaild = 0 then
    return 'M';
    end if;

    o_check_bank1 := i_bank_brch;
    end if;

if o_check_bank = o_check_bank1 then
return 'Y';
else
  begin
         select bank_cd
         into o_check_bank_cd1
         from vn.cww10m00 b
         where b.BANKCODE =o_check_bank1;
    exception
        when  NO_DATA_FOUND  then
               return 'M';
        when  OTHERS         then
            t_err_txt  :=  '¿À·ù-['||to_char(sqlcode)||']';
            raise_application_error (-20100, t_err_txt);
    end;
    begin
         select bank_cd
         into o_check_bank_cd2
         from vn.cww10m00 b
         where b.BANKCODE =o_check_bank;
    exception
        when  NO_DATA_FOUND  then
               return 'M';
        when  OTHERS         then
            t_err_txt  :=  '¿À·ù-['||to_char(sqlcode)||']';
            raise_application_error (-20100, t_err_txt);
    end;
    if o_check_bank_cd1 = o_check_bank_cd2 then
      return 'Y';
      else return 'N';
      end if;

end if;
end fbm_check_in_out_bank;
/

