create procedure pvsd_recv_dat_prepare(i_dat_cd   in varchar2,
                                                  i_vsd_seq  in varchar2,
                                                  i_recv_dat in varchar2,
                                                  o_mark_tp1 out varchar2,
                                                  o_mark_tp2 out varchar2,
                                                  o_tran_amt out varchar2,
                                                  o_msg_nm   out varchar2) as
  /*
  Create date       : 2017/3/13
  Developer         : long.pham
  Purpose           : Prepare data for inserting into drvsdm01
  */
  t_sec_cd VARCHAR2(3) := vn.fxc_sec_cd('R');
  p_class_value varchar2(10);

begin
  select ' ', ' ', ' ' into o_mark_tp1, o_mark_tp2, o_tran_amt from dual;
  vn.pxc_log_write('pvsd_recv_dat_prepare',
                   'dat_cd: ' || i_dat_cd || ' vsd_seq: ' || i_vsd_seq);
  vn.pvsd_get_msg_nm(i_dat_cd, i_vsd_seq, i_recv_dat, o_msg_nm);
  select vn.fvsd_get_msg_class_value(i_dat_cd,
                                     i_vsd_seq,
                                     i_recv_dat,
                                     '2',
                                     'vsd')
    INTO p_class_value
    FROM DUAL;
  vn.pxc_log_write('pvsd_recv_dat_prepare',
                   'Classification value ' || p_class_value || ' ' ||
                   o_msg_nm);

  if p_class_value = 'OTAM' then
    -- MT598 :12:600
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '2', '', '97A:')
      into o_mark_tp1
      from dual;
  end if;

  if p_class_value = 'CTAM' then
    -- MT598 :12:600
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '2', '', '97A:')
      into o_mark_tp1
      from dual;
  end if;

  if p_class_value = 'COTAM' then
    -- MT598 :12:601
    select substr(vn.fvsd_get_tag(t_sec_cd,
                                  i_recv_dat,
                                  '2',
                                  '',
                                  '70E::ADTX//TA//'),
                  2,
                  10)
      into o_mark_tp1
      from dual;
  end if;

  if p_class_value = 'CCTAM' then
    -- MT598 :12:601
    select substr(vn.fvsd_get_tag(t_sec_cd,
                                  i_recv_dat,
                                  '2',
                                  '',
                                  '70E::ADTX//TA//'),
                  2,
                  10)
      into o_mark_tp1
      from dual;
  end if;

  if p_class_value = 'OTAT' then
    -- MT598 :12:602
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '2', '', '97A:')
      into o_mark_tp1
      from dual;
  end if;

  if p_class_value = 'CTAT' then
    -- MT598 :12:602
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '2', '', '97A:')
      into o_mark_tp1
      from dual;
  end if;

  if p_class_value = 'COTAT' then
    -- MT598 :12:603
    select substr(vn.fvsd_get_tag(t_sec_cd,
                                  i_recv_dat,
                                  '2',
                                  '',
                                  '70E::ADTX//TA//'),
                  2,
                  10)
      into o_mark_tp1
      from dual;
  end if;

  if p_class_value = 'CCTAT' then
    -- MT598 :12:603
    select substr(vn.fvsd_get_tag(t_sec_cd,
                                  i_recv_dat,
                                  '2',
                                  '',
                                  '70E::ADTX//TA//'),
                  2,
                  10)
      into o_mark_tp1
      from dual;
  end if;

  if p_class_value = 'CDMC' then
    --MT910  :72:IM//
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '72:') --acnt
      into o_mark_tp1
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') + 3,
                  decode(instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '32A'),
                               ','),
                         0,
                         length(vn.fvsd_get_tag(t_sec_cd,
                                                i_recv_dat,
                                                '1',
                                                '',
                                                '32A')),
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '32A'),
                               ',')) -
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') - 3)
      into o_tran_amt --amt
      from dual;
  end if;

  if p_class_value = 'RWMC' then
    -- MT598 :77E:CASH
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '77E')
      into o_mark_tp2
      from dual;
  end if;

  if p_class_value = 'CWC' then
    --MT910  :72:IM//
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '72:')
      into o_mark_tp1
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') + 3,
                  decode(instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '32A'),
                               ','),
                         0,
                         length(vn.fvsd_get_tag(t_sec_cd,
                                                i_recv_dat,
                                                '1',
                                                '',
                                                '32A')),
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '32A'),
                               ',')) -
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') - 3)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'RBS' then
    --MT548 13a:LINK/524
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '24B')
      into o_mark_tp2
      from dual;
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '2', '', '13A')
      into o_mark_tp1
      from dual;
  end if;

  if p_class_value = 'CBS' then
    --MT508 93a:FROM//AVAL
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '2', '', '97A:')
      into o_mark_tp1
      from dual;
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '93A')
      into o_mark_tp2
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '36B'),
                  decode(instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'FAMT/'),
                         0,
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'UNIT/'),
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'FAMT/')) + 5)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'CUS' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '2', '', '97A:')
      into o_mark_tp1
      from dual;
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '93A')
      into o_mark_tp2
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '36B'),
                  decode(instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'FAMT/'),
                         0,
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'UNIT/'),
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'FAMT/')) + 5)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'CDMS' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '2', '', '97A:')
      into o_mark_tp1
      from dual;
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '22F')
      into o_mark_tp2
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '36B'),
                  decode(instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'FAMT/'),
                         0,
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'UNIT/'),
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'FAMT/')) + 5)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'CWMS' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '2', '', '97A:')
      into o_mark_tp1
      from dual;
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '22F')
      into o_mark_tp2
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '36B'),
                  decode(instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'FAMT/'),
                         0,
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'UNIT/'),
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'FAMT/')) + 5)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'RMS' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '24B')
      into o_mark_tp2
      from dual;
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '2', '', '13A')
      into o_mark_tp1
      from dual;
  end if;

  if p_class_value = 'NMO' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '77E')
      into o_mark_tp2
      from dual;
  end if;

  if p_class_value = 'TR' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '2', '', '95P:')
      into o_mark_tp1
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '36B'),
                  decode(instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'FAMT/'),
                         0,
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'UNIT/'),
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'FAMT/')) + 5)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'STR' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '77E')
      into o_mark_tp2
      from dual;
  end if;

  if p_class_value = 'WMR' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '2', '', '97A:')
      into o_mark_tp1
      from dual;
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '77E')
      into o_mark_tp2
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '19B'),
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '19B'),
                        'TEXA//') + 6)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'WPL' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '2', '', '97A:')
      into o_mark_tp1
      from dual;
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '77E')
      into o_mark_tp2
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '19B'),
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '19B'),
                        'TEXA//') + 6)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'WOI' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '2', '', '97A:')
      into o_mark_tp1
      from dual;
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '77E')
      into o_mark_tp2
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '36B'),
                  decode(instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'COLL//FAMT/'),
                         0,
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'COLL//UNIT/'),
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'COLL//FAMT/')) + 11)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'WBA' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '2', '', '97A:')
      into o_mark_tp1
      from dual;
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '77E')
      into o_mark_tp2
      from dual;
  end if;

  if p_class_value = 'NPI' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '77E')
      into o_mark_tp2
      from dual;
  end if;

  if p_class_value = 'TCS' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '2', '', '97A:')
      into o_mark_tp1
      from dual;
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '22F')
      into o_mark_tp2
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '36B'),
                  decode(instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'ESTT//FAMT/'),
                         0,
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'ESTT//UNIT/'),
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'ESTT//FAMT/')) + 11)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'TCC' then
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '72:'), 1, 10)
      into o_mark_tp1
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') + 3,
                  decode(instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '32A'),
                               ','),
                         0,
                         length(vn.fvsd_get_tag(t_sec_cd,
                                                i_recv_dat,
                                                '1',
                                                '',
                                                '32A')),
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '32A'),
                               ',')) -
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') - 3)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'GIVE' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '77E')
      into o_mark_tp2
      from dual;
    select /*substr(vn.fvsd_get_tag('068', i_recv_dat, '1', '', '70E'),
                  decode(instr(vn.fvsd_get_tag('068',
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '70E'),
                               'LFUT/'),
                         0,
                         instr(vn.fvsd_get_tag('068',
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '70E'),
                               'SFUT/'),
                         instr(vn.fvsd_get_tag('068',
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '70E'),
                               'LFUT/')) + 5)*/
           'LFUT/' || vn.fvsd_get_tag(t_sec_cd,i_recv_dat,'1','','LFUT') || ', SFUT/' ||
				   vn.fvsd_get_tag(t_sec_cd,i_recv_dat,'1','','SFUT')                    
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'RCS' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '2', '', '97A:')
      into o_mark_tp1
      from dual;
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '22F')
      into o_mark_tp2
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '36B'),
                  decode(instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'ESTT//FAMT/'),
                         0,
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'ESTT//UNIT/'),
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'ESTT//FAMT/')) + 11)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'RCC' then
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '72:'), 1, 10)
      into o_mark_tp1
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') + 3,
                  decode(instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '32A'),
                               ','),
                         0,
                         length(vn.fvsd_get_tag(t_sec_cd,
                                                i_recv_dat,
                                                '1',
                                                '',
                                                '32A')),
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '32A'),
                               ',')) -
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') - 3)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'TAKE' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '2', '', '97A:')
      into o_mark_tp1
      from dual;
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '77E')
      into o_mark_tp2
      from dual;
    select /*substr(vn.fvsd_get_tag('068', i_recv_dat, '1', '', '70E'),
                  decode(instr(vn.fvsd_get_tag('068',
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '70E'),
                               'LFUT/'),
                         0,
                         instr(vn.fvsd_get_tag('068',
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '70E'),
                               'SFUT/'),
                         instr(vn.fvsd_get_tag('068',
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '70E'),
                               'LFUT/')) + 5)*/
           'LFUT/' || vn.fvsd_get_tag(t_sec_cd,i_recv_dat,'1','','LFUT') || ', SFUT/' ||
				   vn.fvsd_get_tag(t_sec_cd,i_recv_dat,'1','','SFUT')                     
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'CCPR' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '2', '', '97A:')
      into o_mark_tp1
      from dual;
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '77E')
      into o_mark_tp2
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '36B'),
                  decode(instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'SETT//FAMT/'),
                         0,
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'SETT//UNIT/'),
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'SETT//FAMT/')) + 11)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'RCPR' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '23G')
      into o_mark_tp2
      from dual;
  end if;

  if p_class_value = 'NVM' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '77E')
      into o_mark_tp2
      from dual;
  end if;

  if p_class_value = 'PDCM' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '72:')
      into o_mark_tp2
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') + 3,
                  decode(instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '32A'),
                               ','),
                         0,
                         length(vn.fvsd_get_tag(t_sec_cd,
                                                i_recv_dat,
                                                '1',
                                                '',
                                                '32A')),
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '32A'),
                               ',')) -
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') - 3)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'CDCM' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '72:')
      into o_mark_tp2
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') + 3,
                  decode(instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '32A'),
                               ','),
                         0,
                         length(vn.fvsd_get_tag(t_sec_cd,
                                                i_recv_dat,
                                                '1',
                                                '',
                                                '32A')),
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '32A'),
                               ',')) -
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') - 3)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'PBCM' then
    /*Th�ng b�o chuy?n ti?n cho TVBT l�i*/
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '72:')
      into o_mark_tp2
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') + 3)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'CBCM' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', ':72')
      into o_mark_tp2
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') + 3)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'MPO' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '77E')
      into o_mark_tp2
      from dual;
  end if;

  if p_class_value = 'CDDM' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '2', '', '97A:')
      into o_mark_tp1
      from dual;
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '22F')
      into o_mark_tp2
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '36B'),
                  decode(instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'FAMT/'),
                         0,
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'UNIT/'),
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'FAMT/')) + 5)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'RDDM' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '25D')
      into o_mark_tp2
      from dual;
  end if;

  if p_class_value = 'BPM' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '72"')
      into o_mark_tp2
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') + 3,
                  decode(instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '32A'),
                               ','),
                         0,
                         length(vn.fvsd_get_tag(t_sec_cd,
                                                i_recv_dat,
                                                '1',
                                                '',
                                                '32A')),
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '32A'),
                               ',')) -
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') - 3)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'DBPM' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '72:')
      into o_mark_tp2
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') + 3,
                  decode(instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '32A'),
                               ','),
                         0,
                         length(vn.fvsd_get_tag(t_sec_cd,
                                                i_recv_dat,
                                                '1',
                                                '',
                                                '32A')),
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '32A'),
                               ',')) -
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') - 3)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'SPM' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '72:')
      into o_mark_tp2
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') + 3,
                  decode(instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '32A'),
                               ','),
                         0,
                         length(vn.fvsd_get_tag(t_sec_cd,
                                                i_recv_dat,
                                                '1',
                                                '',
                                                '32A')),
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '32A'),
                               ',')) -
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') - 3)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'DSPM' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', ':72')
      into o_mark_tp2
      from dual;
  end if;

  if p_class_value = 'DIM' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', ':72')
      into o_mark_tp1
      from dual;
  end if;

  if p_class_value = 'CIM' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', ':72')
      into o_mark_tp1
      from dual;
  end if;

  if p_class_value = 'DCPD' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '72:')
      into o_mark_tp2
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') + 3,
                  decode(instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '32A'),
                               ','),
                         0,
                         length(vn.fvsd_get_tag(t_sec_cd,
                                                i_recv_dat,
                                                '1',
                                                '',
                                                '32A')),
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '32A'),
                               ',')) -
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') - 3)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'CCPD' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '72:')
      into o_mark_tp2
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') + 3,
                  decode(instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '32A'),
                               ','),
                         0,
                         length(vn.fvsd_get_tag(t_sec_cd,
                                                i_recv_dat,
                                                '1',
                                                '',
                                                '32A')),
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '32A'),
                               ',')) -
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') - 3)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'NFS' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '70E')
      into o_mark_tp2
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '36B'),
                  decode(instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'FAMT/'),
                         0,
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'UNIT/'),
                         instr(vn.fvsd_get_tag(t_sec_cd,
                                               i_recv_dat,
                                               '1',
                                               '',
                                               '36B'),
                               'FAMT/')) + 5)
      into o_tran_amt
      from dual;
  end if;

  if p_class_value = 'RI' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '20C')
      into o_mark_tp2
      from dual;
  end if;

  if p_class_value = 'NST' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '77E')
      into o_mark_tp2
      from dual;
  end if;

  if p_class_value = 'NSM' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '77E')
      into o_mark_tp2
      from dual;
  end if;

  if p_class_value = 'PR' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '77E')
      into o_mark_tp2
      from dual;
  end if;

  if p_class_value = 'CR' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '77E')
      into o_mark_tp2
      from dual;
  end if;

  if p_class_value = 'IRM' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '77E')
      into o_mark_tp2
      from dual;
  end if;

  if p_class_value = 'TBR' then
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '77E')
      into o_mark_tp2
      from dual;
  end if;

  if p_class_value = 'WMC' then
    --MT103 23:CRED
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '70:')
      into o_mark_tp1
      from dual;
    select vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '23B:')
      into o_mark_tp2
      from dual;
    select substr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                  instr(vn.fvsd_get_tag(t_sec_cd, i_recv_dat, '1', '', '32A'),
                        'VND') + 3)
      into o_tran_amt
      from dual;
  end if;

  vn.pxc_log_write('pvsd_recv_dat_prepare',
                   o_mark_tp1 || '-' || o_mark_tp2 || '-' || o_tran_amt);
end pvsd_recv_dat_prepare;
/

