create FUNCTION FCW_BANK_MIN_BAL
(
 I_SEC_CD     IN    VARCHAR2,
 I_BANK_CD     IN    VARCHAR2,
 I_ACNT_NO     IN    VARCHAR2,
 I_sub_no     IN    VARCHAR2
 ) RETURN NUMBER AS

O_BANK_MIN_BAL NUMBER;

/* ===========================================
   -- PROGRAM ID     :  FCW_BANK_MIN_BAL_Q
   -- DATE OF PROGRAM   :  29/06/2009
   -- PROGRAMMER     :  KKANG
   -- DESCRIPTION       :
INPUT  :  BANK CODE, ACCOUNT NUMBER
RETURN :  BANK MIN BAL
=========================================== */

BEGIN

  BEGIN
    SELECT   DECODE(A7.BANK_CD, '0003', DECODE(A2.GRP_TP, '2', 1000000, 50000),'0002',DECODE(A2.GRP_TP, '2', 1000000, 50000),0)
    INTO  O_BANK_MIN_BAL
    FROM   AAA01M00 A1, AAA02M00 A2, AAA07M00 A7, CWW01H00 C
    WHERE  A1.ACNT_NO     = A7.ACNT_NO
    and     a1.sub_no       = a7.sub_no
    AND    A1.IDNO      = A2.IDNO
    AND    A1.ACNT_STAT   = '1'
    AND    A1.BANK_CNT_YN   = 'Y'
    AND    A7.USE_YN    = 'Y'
    AND    A1.ACNT_NO    = TRIM(I_ACNT_NO)
    AND    A1.sub_no    = TRIM(I_sub_no )
    AND    A7.BANK_CD    = TRIM(I_BANK_CD)
    AND    A7.BANK_CD    = C.BANK_CD
    AND    C.BANK_KND_TP  = '01'
    AND    VN.WDATE  BETWEEN C.MNG_STRT_DT AND C.MNG_END_DT;

    RETURN O_BANK_MIN_BAL;

    EXCEPTION
      WHEN   NO_DATA_FOUND THEN
    RETURN   -1;
  END;
END;
/

