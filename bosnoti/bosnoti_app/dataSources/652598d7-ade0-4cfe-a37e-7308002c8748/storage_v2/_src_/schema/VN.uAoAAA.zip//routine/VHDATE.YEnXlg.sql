create function vhdate
        return varchar2 as
begin

    return(to_char(hdate(),'yyyymmdd'));

end vhdate;
/

