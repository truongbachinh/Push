create function faa_user_acnt_idno_g
(
	i_user_id       in		varchar2,
  i_acnt_no		in		varchar2,
	i_sub_no   in varchar2
) return varchar2 as

	o_idno	varchar2(20);
	t_cnt		number 		:=	0;

begin

  select count(*)
  into t_cnt
  from vn.aaa01m40 t
  where hts_id = i_user_id
  and to_char(t.cls_dtm,'yyyymmdd') = '30000101' ;

  if t_cnt > 0 then
    begin
      select nvl(max(c.idno),'!')
        into o_idno
       from vn.xca01m00 t, vn.aaa01m40 a , vn.aaa01m00 c
      where id = i_user_id
        and to_char(a.cls_dtm,'yyyymmdd') = '30000101'
        and a.hts_id = t.id
        and a.acnt_no = c.acnt_no
        and a.sub_no  = c.sub_no
        and a.sub_no = '00';

      return o_idno;

    exception
    when	 no_data_found then
      return 	'!';
    end;

  else

    begin
      select nvl(idno,'!')
        into o_idno
       from	vn.aaa01m00
      where	acnt_no 	=	i_acnt_no
        and sub_no   = i_sub_no ;

      return o_idno;

    exception
    when	 no_data_found then
      return 	'!';
    end;

  end if;

end ;
/

