create procedure pss_get_stk_mrgn
( i_sec_cd   in   varchar2,
  i_dt in  varchar2,
  i_stk_mkt_tp in  varchar2
 ) is

/*************************************
Create user: Hien Luong
Create date: 2012/03/01
Purpose: Print report 02013 - 7 (7.B�O C�O DANH M?C CK TH?C HI?N GIAO D?CH K�QU?)
*************************************/

  ts_bef_stk_cd varchar2(20);
  ts_wdate      varchar2(6);
  tn_seq_no     number;
  tn_count      number;
begin
 select to_char(vn.wdate,'yyyymm') Into ts_wdate from dual;

 If ts_wdate = i_dt Then --Neu la thang hien hanh thi thuc thi lai pro
   delete from VN.SSI01H00_MRGN
   where dt = i_dt
     and stk_mkt_tp = i_stk_mkt_tp;
 Else --Neu da co data ko phai thang hien hanh thi ko can chay lai pro
   Select count(*)  Into tn_count
     From VN.SSI01H00_MRGN
    Where dt = i_dt
     and stk_mkt_tp = i_stk_mkt_tp and rownum < 2;

   If tn_count > 0 Then
      Return;
   End If;
 End If;

 ts_bef_stk_cd := '!' ;
 tn_seq_no := 1;

 for c1 in (
   --Dau ky: ngay cuoi cung cua thang truoc van la GD ky quy
    select stk_cd, '1' col_seq from ssi01h00
    where dt = fxc_vorderdt_g(to_date(i_dt||'01','yyyymmdd'), -1)
      and cd_yn = 'Y'
      and stk_mkt_tp = i_stk_mkt_tp
    union all

    --Trong ky: Tu ngay 01 -> cuoi thang (bo GD ky quy: co ky quy dau ky)
    select distinct stk_cd, '2' col_seq from ssi01h00 t
    where substr(dt,1, 6) = i_dt
      and to_char(cd_work_dtm,'yyyymm') = i_dt
      and cd_yn = 'N'
      and stk_mkt_tp = i_stk_mkt_tp
      and exists(select null from ssi01h00 tt
            where tt.dt = fxc_vorderdt_g(to_date(i_dt||'01','yyyymmdd'), -1)
            and tt.cd_yn = 'Y' and t.stk_cd = tt.stk_cd)
    union all

    --Trong ky: Tu ngay 01 -> cuoi thang (bo sung GD ky quy: khong ky quy dau ky hoac bo ky quy trong ky)
    select distinct stk_cd, '3' col_seq from ssi01h00 t
    where substr(dt,1, 6) = i_dt
      and to_char(cd_work_dtm,'yyyymm') = i_dt
      and cd_yn = 'Y'
      and stk_mkt_tp = i_stk_mkt_tp
      and (not exists(select null from ssi01h00 tt
            where tt.dt = fxc_vorderdt_g(to_date(i_dt||'01','yyyymmdd'), -1)
            and tt.cd_yn = 'Y' and t.stk_cd = tt.stk_cd)
         Or exists(select null from ssi01h00 tt
              where substr(dt,1, 6) = i_dt
              and to_char(cd_work_dtm,'yyyymm') = i_dt
              and cd_yn = 'N' and t.stk_cd = tt.stk_cd)
        )
    union all

    --Cuoi ky: ngay cuoi cung cua thang nay van la GD ky quy
    select stk_cd, '4' col_seq from ssi01h00
    where dt = fxc_vorderdt_g(last_day(to_date(i_dt||'01','yyyymmdd')),0)
      and cd_yn = 'Y'
      and stk_mkt_tp = i_stk_mkt_tp

    order by stk_cd, col_seq
  ) loop


  if ts_bef_stk_cd <> c1.stk_cd then
     if c1.col_seq = '1' then --CK ky quy dau ky
       insert into VN.SSI01H00_MRGN (DT, STK_MKT_TP, STK_S_Y, SEQ_NO)
            values (i_dt, i_stk_mkt_tp, c1.stk_cd, tn_seq_no);

     Elsif c1.col_seq = '2' then --CK bo ra khoi DS GD ky quy trong ky
       insert into VN.SSI01H00_MRGN (DT, STK_MKT_TP, STK_I_N, SEQ_NO)
            values (i_dt, i_stk_mkt_tp, c1.stk_cd, tn_seq_no);

     Elsif c1.col_seq = '3' then --CK bo sung GD ky quy trong ky
       insert into VN.SSI01H00_MRGN (DT, STK_MKT_TP, STK_I_Y, SEQ_NO)
            values (i_dt, i_stk_mkt_tp, c1.stk_cd, tn_seq_no);

     Elsif c1.col_seq = '4' then --CK ky quy cuoi ky
       insert into VN.SSI01H00_MRGN (DT, STK_MKT_TP, STK_E_Y, SEQ_NO)
            values (i_dt, i_stk_mkt_tp, c1.stk_cd, tn_seq_no);
     End  If;

     tn_seq_no := tn_seq_no + 1;

  else
     if c1.col_seq = '2' then --CK bo GD ky quy trong ky
       UPDATE VN.SSI01H00_MRGN
          SET STK_I_N = c1.stk_cd
        WHERE DT = i_dt
          AND STK_S_Y = c1.stk_cd;

     Elsif c1.col_seq = '3' then --CK bo sung DS GD ky quy trong ky
       UPDATE VN.SSI01H00_MRGN
          SET STK_I_Y = c1.stk_cd
        WHERE DT = i_dt
          AND STK_I_N = c1.stk_cd;

     Elsif c1.col_seq = '4' then --CK ky quy dau ky
       UPDATE VN.SSI01H00_MRGN
          SET STK_E_Y = c1.stk_cd
        WHERE DT = i_dt
          AND (STK_S_Y = c1.stk_cd OR STK_I_Y = c1.stk_cd);
     End  If;
  end if ;

  ts_bef_stk_cd := c1.stk_cd ;

  end loop ;

  commit;

end  pss_get_stk_mrgn;
/

