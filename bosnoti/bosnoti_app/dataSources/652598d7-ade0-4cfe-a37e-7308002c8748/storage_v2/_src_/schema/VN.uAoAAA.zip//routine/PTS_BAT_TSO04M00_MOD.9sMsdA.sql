create procedure pts_bat_tso04m00_mod (
    i_work_dt       in      varchar2,       -- date(yyyymmdd)
	o_err_code      in      number,         -- error code(0:SUCCESS)
	o_err_msg       in      varchar2,       -- error message
	o_proc_cnt      out     number          -- proc data count
) as

t_err_code      number        := o_err_code;
t_err_msg       varchar2(600) := rtrim(o_err_msg);
t_chk           varchar2(1);
cnt             number;
exp_error       exception;

/*!
    \file     pts_bat_tso04m00_mod
	\brief    tso04m00 update

	\section intro Program Information
		- Program Name              : pts_bat_tso04m00_mod
		- Service Name              :
		- Related Client Program- Client Program ID :
		- Related Tables            : tso04m00
		- Dev. Date                 : 2007/11/27
		- Developer                 : ejlee
		- Business Logic Desc.      :
		- Latest Modification Date  :

	\section history Program Modification History
		- 1.0  2007/11/27

	\section hardcoding Hard-Coding List

	\section info Additional Reference Comments
*/

begin

	t_err_code := 0;
	t_err_msg  := 'SUCCESS';
	t_chk      := 'Y';
	o_proc_cnt := 0;
	cnt        := 0;

	-- 1. �� ��ü��Ϸ��ũ Funüũ

	if t_chk = 'Y' then

        for  c1  in (

		    select  acnt_no           ,
		    		sub_no			  ,
					stk_cd            ,
					td_sell_ord_qty   ,
					td_sell_mth_qty   ,
					td_sell_mth_amt   ,
					td_buy_mth_qty    ,
					td_buy_mth_amt    ,
					pd_sell_mth_qty   ,
					pd_sell_mth_amt   ,
					pd_buy_mth_qty    ,
					pd_buy_mth_amt    ,
					ppd_sell_mth_qty  ,
					ppd_sell_mth_amt  ,
					ppd_buy_mth_qty   ,
					ppd_buy_mth_amt   ,
					pppd_sell_mth_qty ,
					pppd_sell_mth_amt ,
					pppd_buy_mth_qty  ,
					pppd_buy_mth_amt
			  from  vn.tso04m00

             ) loop

			 cnt := cnt + 1;

			 update vn.tso04m00
			 set    pppd_sell_mth_qty = c1.ppd_sell_mth_qty ,
					pppd_sell_mth_amt = c1.ppd_sell_mth_amt ,
					pppd_buy_mth_qty  = c1.ppd_buy_mth_qty  ,
					pppd_buy_mth_amt  = c1.ppd_buy_mth_qty  ,
			        ppd_sell_mth_qty  = c1.pd_sell_mth_qty  ,
					ppd_sell_mth_amt  = c1.pd_sell_mth_amt  ,
					ppd_buy_mth_qty   = c1.pd_buy_mth_qty   ,
					ppd_buy_mth_amt   = c1.pd_buy_mth_qty   ,
					pd_sell_mth_qty   = c1.td_sell_mth_qty  ,
					pd_sell_mth_amt   = c1.td_sell_mth_amt  ,
					pd_buy_mth_qty    = c1.td_buy_mth_qty   ,
					pd_buy_mth_amt    = c1.td_buy_mth_amt   ,
					td_sell_mth_qty   = 0                   ,
					td_sell_mth_amt   = 0                   ,
					td_buy_mth_qty    = 0                   ,
					td_buy_mth_amt    = 0                   ,
					td_sell_ord_qty   = 0
			 where  acnt_no = c1.acnt_no
			   and	sub_no = c1.sub_no
			 and    stk_cd  = c1.stk_cd
             ;
        end loop;
	else
		t_err_code := -1;
	    t_err_msg  := '�� ��ü��̿Ϸ��ϴ� ü��� � ó����ʽÿ�';
		raise_application_error(-20100,'[pts_bat_tso04m00_mod] ' || t_err_msg);
	end if;

	o_proc_cnt := cnt;

	exception when  exp_error then
		t_err_code := sqlcode;
		t_err_msg  := sqlerrm;
		raise_application_error(-20100,'[pts_bat_tso04m00_mod] ' || t_err_msg);

end pts_bat_tso04m00_mod;
/

