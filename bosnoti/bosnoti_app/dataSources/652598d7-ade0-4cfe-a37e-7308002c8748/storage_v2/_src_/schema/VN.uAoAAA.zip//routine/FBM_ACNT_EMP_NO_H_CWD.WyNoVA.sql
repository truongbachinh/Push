create function fbm_acnt_emp_no_h_cwd
(
    i_acnt_no   in   varchar2,
    i_sub_no   in   VARCHAR2,
     i_dt      in   VARCHAR2
)
    return          varchar2
as
    o_emp_no    varchar2(100) ;
    --t_err_txt       varchar2(100)  ; -- error text buffer

begin

/*============================================================================*/
/* º¯¼ö ÃÊ±âÈ­                                                                */
/*============================================================================*/
    o_emp_no  :=  NULL;
    --t_err_txt :=  NULL;


/*============================================================================*/
/* »ç¿ø¹øÈ£ Á¶È¸                                                                */
/*============================================================================*/
    begin
    select  emp_no
    into  o_emp_no
    from  vn.bmi01m00
    where  acnt_no = i_acnt_no
    and     sub_no = i_sub_no
    and    mng_emp_tp = '1'
    and to_date(i_dt,'yyyymmdd')<= cls_dtm
    /*and    cls_dtm <= to_date(i_dt,'yyyymmdd')*/
    AND rownum = 1
    ;
    exception
        when  NO_DATA_FOUND  then
      return  '!';
       /* when  OTHERS         then
            t_err_txt  :=  '¿À·ù-['||to_char(sqlcode)||']';
            raise_application_error (-20100, t_err_txt);*/
    end;

    return  o_emp_no;

end fbm_acnt_emp_no_h_cwd;
/

