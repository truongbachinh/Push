create procedure bos_pro
(
		ls_proc				in		varchar2
) as

      ts_code                 varchar2(4)     := '';

BEGIN

		   /* ���
		    for c1 in (
				select  a.STK_CD       ,
      					a.MAX_PRI    ,
					    a.DN_PRI     ,
 					    a.PD_CLS_PRI  ,
                        a.CLS_PRI       ,
                        a.STD_PRI        ,
                        a.STRT_PRI       ,
                        a.LOW_PRI       ,
                        a.HIGH_PRI      ,
                        a.FAC_PRI       ,
                        a.MTH_PRI       ,
                        a.AVG_PRI
                    from   vn.pro_ha a ,
        				vn.ssi03m00 b

                where   a.stk_cd = b.stk_cd
                  and to_char(a.proc_dt,'yyyymmdd') = vn.vwdate
                  and (     a.MAX_PRI      <> b.MAX_PRI
                   or       a.DN_PRI       <> b.DN_PRI
                      )
              ) loop

                update    vn.ssi03m00
		           set    MAX_PRI       =  c1.max_pri ,
		                  DN_PRI        =  c1.dn_pri
                 where    STK_CD        =  c1.stk_cd ;



           end loop ;
	*/

           /* ȣġ��    */
            for c2 in (

			select             a.stk_Cd        ,
			                   a.MAX_PRI       ,
                               a.DN_PRI        ,
                               a.CLS_PRI       ,
                               a.TOT_TRD_QTY   ,
                               a.TOT_TRD_AMT   ,
                               a.HIGH_PRI      ,
                               a.LOW_PRI       ,
                               a.STRT_PRI      ,
                               a.LST_PRE_PRI   ,
							   a.curt_pri
                         from  vn.pro_ho a ,
                               vn.ssi02m00 b
                        where  a.stk_cd = b.stk_cd
						and    to_char(a.proc_dt,'YYYYMMDD') = vn.vwdate
                        and   (        a.MAX_PRI       <> b.MAX_PRI
					            or     a.DN_PRI        <> b.DN_PRI

                              )
				  ) loop


                   update  vn.ssi02m00
                      set  MAX_PRI       =    c2.MAX_PRI             ,
                           DN_PRI        =    c2.DN_PRI
                     where STK_CD        =    c2.STK_CD   ;



            end loop;


			commit;


end  bos_pro ;
/

