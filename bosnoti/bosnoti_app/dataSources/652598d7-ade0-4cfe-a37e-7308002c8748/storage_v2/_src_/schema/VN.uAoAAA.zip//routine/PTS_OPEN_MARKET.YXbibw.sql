create procedure pts_open_market(
                                            i_sec_id    in    varchar2,
                                            i_mkt_st_hn in    varchar2,
                                            i_mkt_st_hcm  in  varchar2
                                           )as

    li_cnt      number(5) := 0;
begin
/* MO PHONG THONG TIN THI TRUONG*/
--i_mkt_st_hn: 1-OPEN, 2-BREAK TIME, 3-ATC, 4-REALEASE, 5-POST CLOSE, 9-CLOSE



/*-------------------------------*/

    update tso03m00
       set mkt_drv_tp = i_mkt_st_hcm
     where SB_KFX_TP in ('HOSTC');
    --hanoi market update
    IF i_mkt_st_hn = '1' THEN

    --update tso03m00
    UPDATE TSO03M00
    SET MKT_MAIN_STS = '1',
    MKT_DRV_TP = 'LIS_CON_NML'
    where SB_KFX_TP in ('HASTC');
    --UPCOM
    UPDATE TSO03M00
    SET MKT_MAIN_STS = '1',
    MKT_DRV_TP = 'UPC_CON_NML'
    where SB_KFX_TP in ('UPCOM');
    --UPDATE SSI03M00 HNX
    UPDATE SSI03M00
    SET MKT_MAIN_STS = '1',
    MKT_DRV_TP = 'LIS_CON_NML';
    --UPDATE SSI03M10 UPCOM
    UPDATE SSI03M10
    SET MKT_MAIN_STS = '1',
    MKT_DRV_TP = 'UPC_CON_NML';
    END IF;
    --HANOI CLOSE
    IF i_mkt_st_hn = '2' THEN

    --update tso03m00
    UPDATE TSO03M00
    SET MKT_MAIN_STS = '2',
    MKT_DRV_TP = 'LIS_CON_NML'
    where SB_KFX_TP in ('HASTC');
    --UPCOM
    UPDATE TSO03M00
    SET MKT_MAIN_STS = '2',
    MKT_DRV_TP = 'UPC_CON_NML'
    where SB_KFX_TP in ('UPCOM');
    --UPDATE SSI03M00 HNX
    UPDATE SSI03M00
    SET MKT_MAIN_STS = '2',
    MKT_DRV_TP = 'LIS_CON_NML';
    --UPDATE SSI03M10 UPCOM
    UPDATE SSI03M10
    SET MKT_MAIN_STS = '2',
    MKT_DRV_TP = 'UPC_CON_NML';
    END IF;


    --HANOI ATC SESSION
    IF i_mkt_st_hn = '3' THEN
    --update tso03m00
    UPDATE TSO03M00
    SET MKT_MAIN_STS = '1',
    MKT_DRV_TP = 'LIS_AUC_C_NML'
    where SB_KFX_TP in ('HASTC');
    --UPCOM
    UPDATE TSO03M00
    SET MKT_MAIN_STS = '1',
    MKT_DRV_TP = 'UPC_CON_NML'
    where SB_KFX_TP in ('UPCOM');
    --UPDATE SSI03M00 HNX
    UPDATE SSI03M00
    SET MKT_MAIN_STS = '1',
    MKT_DRV_TP = 'LIS_AUC_C_NML';
    --UPDATE SSI03M10 UPCOM
    UPDATE SSI03M10
    SET MKT_MAIN_STS = '1',
    MKT_DRV_TP = 'UPC_CON_NML';
    END IF;


  --HANOI ATC SESSION
    IF i_mkt_st_hn = '6' THEN
    --update tso03m00
    UPDATE TSO03M00
    SET MKT_MAIN_STS = '1',
    MKT_DRV_TP = 'LIS_AUC_C_NML_LOC'
    where SB_KFX_TP in ('HASTC');
    --UPCOM
    UPDATE TSO03M00
    SET MKT_MAIN_STS = '1',
    MKT_DRV_TP = 'UPC_CON_NML'
    where SB_KFX_TP in ('UPCOM');
    --UPDATE SSI03M00 HNX
    UPDATE SSI03M00
    SET MKT_MAIN_STS = '1',
    MKT_DRV_TP = 'LIS_AUC_C_NML_LOC';
    --UPDATE SSI03M10 UPCOM
    UPDATE SSI03M10
    SET MKT_MAIN_STS = '1',
    MKT_DRV_TP = 'UPC_CON_NML';
    END IF;


  --HANOI POST CLOSE
    IF i_mkt_st_hn = '5' THEN
    --update tso03m00
    UPDATE TSO03M00
    SET MKT_MAIN_STS = '1',
    MKT_DRV_TP = 'LIS_PTH_P_NML'
    where SB_KFX_TP in ('HASTC');

    --UPDATE SSI03M00 HNX
    UPDATE SSI03M00
     SET MKT_MAIN_STS = '1',
    MKT_DRV_TP = 'LIS_PTH_P_NML';

  END IF;


  --HANOI CLOSE
    IF i_mkt_st_hn = '9' THEN
    --update tso03m00
    UPDATE TSO03M00
    SET MKT_MAIN_STS = '13'
    where SB_KFX_TP in ('HASTC','UPCOM');

    --UPDATE SSI03M00 HNX
    UPDATE SSI03M00
     SET MKT_MAIN_STS = '13' ;
  --SSI03M10 UPCOM
    UPDATE SSI03M10
     SET MKT_MAIN_STS = '13' ;

  END IF;


    --HANOI RELEASE
    IF i_mkt_st_hn = '4' THEN
    --update tso03m00
    UPDATE TSO03M00
    SET MKT_MAIN_STS = '97',
    MKT_DRV_TP = 'NONE'
    where SB_KFX_TP in ('HASTC');
    --UPCOM
    UPDATE TSO03M00
    SET MKT_MAIN_STS = '97',
    MKT_DRV_TP = 'NONE'
    where SB_KFX_TP in ('UPCOM');
    --UPDATE SSI03M00 HNX
    UPDATE SSI03M00
     SET MKT_MAIN_STS = '97',
    MKT_DRV_TP = 'NONE';
    --UPDATE SSI03M10 UPCOM
    UPDATE SSI03M10
     SET MKT_MAIN_STS = '97',
    MKT_DRV_TP = 'NONE';
    END IF;

end pts_open_market;
/

