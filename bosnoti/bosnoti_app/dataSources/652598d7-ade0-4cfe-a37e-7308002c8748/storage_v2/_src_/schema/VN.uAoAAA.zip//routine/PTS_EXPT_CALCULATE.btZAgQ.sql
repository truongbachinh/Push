create procedure    pts_expt_calculate
(
	i_sec_cd                IN     	VARCHAR2,
	i_acnt_no					IN	    	VARCHAR2,
	i_sub_no						IN	    	VARCHAR2
)
as
/*
	Tu cong thuc: hold amt = qty*price(1 + hold_rt)
	-> qty = hold_amt/(price*(1 + hold_rt))
*/
t_stk_eval_rt			number := 0;
t_mrgn_eval_rt			number := 0;
t_pd_cls_pri			number := 0;
t_expt_sbst_amt      number := 0;
t_expt_org_amt      	number := 0;
t_mth_qty		     	number := 0;

begin

	vn.pxc_log_write('pts_expt_calculate', 'START ...........');
	vn.pxc_log_write('pts_expt_calculate', 'ACNT = [' || i_acnt_no || '] sub_no = [' || i_sub_no || ']');

	SELECT 	vn.fdl_get_mrgn_grp_acnt_rt( i_acnt_no, i_sub_no,vn.faa_acnt_get_grp_no (i_acnt_no, i_sub_no,'2', vn.vwdate),'02', vn.vwdate)
	INTO 		t_mrgn_eval_rt
	FROM 	DUAL;

   if t_mrgn_eval_rt = 0 then
   	vn.pxc_log_write('pts_expt_calculate', 'Account is not margin account');
   	return;
	end if;

	/*nvl(sum(decode(accp_tp, '4', trunc((loan_amt + cash_amt)/(ord_prof_pri*(1 + cash_prof_rt))),
													  		'5', decode(sign(trunc((loan_amt + cash_amt)/(ord_prof_pri*(1 + cash_prof_rt))) - mth_qty), 1, mth_qty,
													  				 		trunc((loan_amt + cash_amt)/(ord_prof_pri*(1 + cash_prof_rt)))
													  				 	  ) , 0
										 	  )
									 ), 0) buy_qty_none_vd*/
	for c1 in (SELECT sum(mth_qty) mth_qty,
							stk_cd
					 FROM VN.TSO01M00
					WHERE acnt_no 	= i_acnt_no
					  AND sub_no	= i_sub_no
					  and  bank_cd =  '9999'
					  AND accp_tp in ('4', '5')
					  --AND SSR_RT > 0
					  AND mth_qty > 0
					  --AND loan_amt + cash_amt > 0
					  AND sell_buy_tp = '2'
				GROUP BY stk_cd)
	loop
		t_pd_cls_pri := vn.fss_get_pd_cls_pri(c1.stk_cd);
		t_stk_eval_rt:= vn.fss_get_match_rate_acnt(trim(c1.stk_cd), 0, trim(i_acnt_no), trim(i_sub_no));

		/*Kiem tra khoi luong khop*/
		t_mth_qty := c1.mth_qty;
		vn.pxc_log_write('pts_expt_calculate', 't_mth_qty = [' || t_mth_qty || ']');

		--Neu la ma CK co trong ro
		if t_stk_eval_rt > 0 then
			vn.pxc_log_write('pts_expt_calculate', 'UPDATE EXPECT SBST acnt_no = [' || i_acnt_no || '], sub_no = [' || i_sub_no || '], stk_cd = ['|| c1.stk_cd ||'], mth_qty = [' || c1.mth_qty || '], t_stk_eval_rt = [' || t_stk_eval_rt || '], t_pd_cls_pri = [' || t_pd_cls_pri || '], ==> expt sbst amt = ['|| c1.mth_qty*t_stk_eval_rt*t_pd_cls_pri || ']');
			t_expt_sbst_amt 	:= t_expt_sbst_amt + c1.mth_qty*t_stk_eval_rt*t_pd_cls_pri;
			t_expt_org_amt		:= t_expt_org_amt + c1.mth_qty*t_pd_cls_pri;
		end if;
	end loop;



	update	vn.tso02m00
		set	EXPT_SBST_AMT		= t_expt_sbst_amt,
            EXPT_SBST_ORG_AMT	= t_expt_org_amt
	where		acnt_no 	= i_acnt_no
	  AND 	sub_no	= i_sub_no
	  AND 	bank_cd 	= '9999';

	vn.pxc_log_write('pts_expt_calculate', 'Total expt_sbst_amt = [' || t_expt_sbst_amt || '], expt_org_amt = [' || t_expt_org_amt || ']');
EXCEPTION
	WHEN OTHERS THEN
		vn.pxc_log_write('pts_expt_calculate', ' pts_expt_calculate update Error: ' || sqlerrm);
		raise_application_error(-20100, 'error: ' || sqlerrm);
end pts_expt_calculate;
/

