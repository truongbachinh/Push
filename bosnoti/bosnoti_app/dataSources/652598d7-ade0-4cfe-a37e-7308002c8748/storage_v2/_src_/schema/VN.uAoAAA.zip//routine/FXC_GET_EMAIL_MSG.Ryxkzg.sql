create FUNCTION    fxc_get_email_msg(
    i_func_tp               IN VARCHAR2,
    i_func_cd               IN VARCHAR2,
    i_msg_lang              IN VARCHAR2,
    i_msg_param             IN VARCHAR2
)
RETURN          CLOB
AS
    -- Declare variable
    t_proc_nm               VARCHAR2(100)   := 'fxc_get_email_msg';
    t_msg_param_cnt         NUMBER;
    t_form_msg_param_cnt    NUMBER;
    t_email_msg             CLOB    := NULL;
    t_form_email            CLOB    := NULL;
    t_in_param              VARCHAR2(4000);
    t_out_param             VARCHAR2(4000);
    i                       NUMBER := 1;
    o_email_msg             CLOB    := NULL;
    t_msg_param             VARCHAR2(4000);

BEGIN
    vn.pxc_log_write(t_proc_nm, '');
    vn.pxc_log_write(t_proc_nm, 'Start pxc_email_ins for: '
                                || 'i_func_tp: '        || i_func_tp
                                || ' i_func_cd: '       || i_func_cd
                                || ' i_msg_lang: '      || i_msg_lang
                                || ' i_msg_param: '     || i_msg_param
                    );

    -- Chap nhan xu ly voi delimeter la \\
    -- Do tren online dang khong the truyen duoc xuong ky tu ||
    t_msg_param := replace(i_msg_param, '\\', '||');
    vn.pxc_log_write(t_proc_nm, 't_msg_param: ' || t_msg_param);

    IF(i_func_tp = '2' OR i_func_cd is null OR i_func_cd = 'F00000') THEN
        t_email_msg := t_msg_param;
    ELSE
        SELECT nvl(regexp_count(t_msg_param, '\|\|', 1, 'i'), 0) msg_param_cnt
        INTO t_msg_param_cnt
        FROM DUAL;

        vn.pxc_log_write(t_proc_nm, 't_msg_param_cnt: ' || t_msg_param_cnt);

        SELECT 
            regexp_count(form_email_msg_clob, '\{\{', 1, 'i') form_msg_param_cnt,
            form_email_msg_clob
        INTO
            t_form_msg_param_cnt,
            t_form_email
        FROM vn.xcs01m03
        WHERE func_cd = i_func_cd
          AND msg_lang = i_msg_lang;

        t_email_msg := t_form_email;

        -- vn.pxc_log_write(t_proc_nm, 't_form_msg_param_cnt: ' || t_form_msg_param_cnt);
        vn.pxc_log_write(t_proc_nm, 'A: ' );
        IF(t_msg_param_cnt <> t_form_msg_param_cnt) THEN
            RETURN NULL;
        ELSE
            IF(t_form_msg_param_cnt > 0) THEN
                FOR i IN 1..t_msg_param_cnt
                LOOP
                    vn.pxc_log_write(t_proc_nm, 'i: ' || i);

                    t_in_param := regexp_substr(t_msg_param, '[^||]+', 1, i);
                    t_out_param := regexp_substr(t_form_email, '\{\{([^}]+)\}\}', 1,i);

                    t_email_msg := replace(t_email_msg, t_out_param, t_in_param);
                    vn.pxc_log_write(t_proc_nm, 'i: ' || i || ', t_in_param ' || t_in_param || ' t_out_param ' || t_out_param);
                    vn.pxc_log_write(t_proc_nm, 'i: ' || i || ', t_email_msg ' || t_email_msg);
                END LOOP;
            END IF;
        END IF;
    END IF;

    vn.pxc_log_write(t_proc_nm, 'o_email_msg ' || t_email_msg);
vn.pxc_log_write(t_proc_nm, 'B: ' );
    o_email_msg := t_email_msg;
vn.pxc_log_write(t_proc_nm, 'C: ' );
    -- vn.pxc_log_write(t_proc_nm, 'o_email_msg ' || o_email_msg);

    RETURN o_email_msg;
END;
/

