create procedure psr_rgt_std_past_proc_upd
 (
  i_proc_dt    in       varchar2,
  i_stk_cd     in       varchar2,
  i_work_mn    in       varchar2,
  i_work_trm   in       varchar2
 ) is

 vs_stk_cd    varchar2(12);
 vs_rgt_tp    varchar2(1) ;
 vn_seq_no    number := 0;
 vn_std_rt    number := 0;
 vn_std_rt2   number := 0;
 vn_stk_rt    number := 0;
 vn_proc_cnt  number := 0;

begin

     vn.pxc_log_write('psr_rgt_std_past_proc_upd', i_proc_dt||' '||i_stk_cd);

  for  c1  in (

       select   stk_cd,
          rgt_tp,
        rgt_std_dt,
        seq_no,
        rgt_proc_stat/*,
        nvl(std_rt,1)     std_rt,
        nvl(std_pay_rt,1) std_rt2,
        decode(rgt_tp,'7', nvl(divi_stk_rt,100)/100, 1) stk_rt*/
       from     vn.srr01m00
       where  rgt_std_dt    =  i_proc_dt
       and  stk_cd         like  i_stk_cd
       and  rgt_proc_stat  <= '3'
       and rgt_tp in ('1', '2', '3')

    ) loop

      if c1.rgt_tp = '1' or c1.rgt_tp = '2' or c1.rgt_tp = '3' then



      vs_rgt_tp  := c1.rgt_tp;
      vs_stk_cd  := c1.stk_cd;
      vn_seq_no  := c1.seq_no;
      --vn_std_rt  := c1.std_rt;
      --vn_std_rt2 := c1.std_rt2;
     -- vn_stk_rt  := c1.stk_rt;

      Delete from vn.srr02m00
       where   rgt_std_dt    = c1.rgt_std_dt
   and     stk_cd        = vs_stk_cd
   and     rgt_tp        = vs_rgt_tp
   and     seq_no        = vn_seq_no;

   update  vn.srr01m00
   set     rgt_proc_stat = '1'
     where   rgt_std_dt    = c1.rgt_std_dt
   and     stk_cd        = vs_stk_cd
   and     rgt_tp        = vs_rgt_tp
   and     seq_no        = vn_seq_no;

    vn.pxc_log_write('psr_rgt_std_past_proc_upd', c1.rgt_tp||c1.stk_cd||c1.rgt_std_dt);

    vn.psr_rgt_std_p( 'I',
        c1.rgt_std_dt,
        c1.stk_cd,
        c1.rgt_tp,
        c1.seq_no,
        i_work_mn,
        i_work_trm,
        vn_proc_cnt
        );

   vn.pxc_log_write('psr_rgt_std_past_proc_upd', c1.rgt_tp||c1.stk_cd||c1.rgt_std_dt);
   vn.psr_rgt_asn_p( 'I',
                    c1.rgt_std_dt,
                    c1.stk_cd,
                    c1.rgt_tp,
                    c1.seq_no,
                    i_work_mn,
                    i_work_trm,
                    vn_proc_cnt
                    );

       end if;

 end loop;

end  psr_rgt_std_past_proc_upd;
/

