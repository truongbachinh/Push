create procedure    psr_sbst_proc_p
  (i_proc_tp   in  varchar2,   -- m : make  c : cancel
  i_rgt_tp    in  varchar2,
  i_rgt_dt    in  varchar2,
  i_stk_cd    in  varchar2,
  i_seq_no    in  varchar2,
  i_acnt_no   in  varchar2,   -- default '%'
  i_sub_no    in  varchar2,   -- default '00'
  i_work_mn   in  varchar2,
  i_work_trm  in  varchar2
 ) is

 t_err_msg    varchar2(200) ;
 td_cnt       number ;

begin

 vn.pxc_log_write('psr_sbst_proc_p', '[ proc_tp : ' || i_proc_tp || ' rgt_tp : ' || i_rgt_tp || ' std_dt : ' || i_rgt_dt || ' stk_cd : ' || i_stk_cd || ' rgt_seq_no : ' || i_seq_no || ' acnt_no : ' || i_acnt_no ||' ]'  );

    for m1 in (  select x.acnt_no         acnt_no     ,
						x.sub_no          sub_no      ,
						sum(x.reuse_amt)  rgt_reuse   ,
						sum(x.rgt_sbst)   rgt_sbst    ,
                        sum(x.change_chk) change_chk
				   from
					  (	select a.acnt_no     acnt_no ,
							   a.sub_no      sub_no  ,
						( nvl(a.flotq_amt,0)   + nvl(a.asn_amt,0) + nvl(a.inter_amt,0) )
							 *  vn.fsr_rgt_cash_rt_acnt( a.stk_cd, a.acnt_no, a.sub_no)  reuse_amt  ,

					      Decode ( a.rgt_tp , '1' , Decode ( a.inq_trd_no , 0 , nvl(a.cons_sbst_qty ,0 ) , 0 ) ,
											  Decode( a.INQ_TRD_NO , 0 , nvl(a.asn_qty  ,0)  , 0 ))
		     		         * vn.fss_get_pd_cls_pri( i_stk_cd) * vn.fsr_rgt_sbst_rt_acnt  ( i_stk_cd , a.acnt_no, a.sub_no)
							 * vn.fdl_get_mrgn_grp_acnt_rt( a.acnt_no, a.sub_no,vn.faa_acnt_get_grp_no (a.acnt_no, a.sub_no,'2', vn.vwdate),'02', vn.vwdate)  rgt_sbst  ,
                             0 change_chk
                          from vn.srr02m00 a ,
						       vn.aaa01m00 b
                         where a.rgt_std_dt = i_rgt_dt
				      	   and a.rgt_tp     = i_rgt_tp
					       and a.stk_cd     = i_stk_cd
					       and a.seq_no     = to_number( i_seq_no )
					       and a.rgt_tp     <> '8'
					       and a.acnt_no    like Trim(i_acnt_no)
						   and a.sub_no     like trim(i_sub_no)
					       and a.acnt_no    = b.acnt_no
						   and a.sub_no     = b.sub_no
					       and b.acnt_stat  = '1'
						   and a.rgt_tp in ('1','2','3', '7', '9')

				         union all

                         select a.acnt_no     acnt_no ,
								a.sub_no      sub_no  ,
                                nvl(a.flotq_amt,0)
						      * vn.fsr_rgt_cash_rt_acnt( a.stk_cd, a.acnt_no, a.sub_no)                      reuse_amt  ,

                           decode ( a.inq_trd_no , 0 ,nvl(a.asn_qty  ,0) , 0 )  * vn.fss_get_pd_cls_pri(d.cnvt_stk_cd)
                                                * vn.fsr_rgt_sbst_rt_acnt ( d.cnvt_stk_cd , a.acnt_no, a.sub_no)
											    * vn.fdl_get_mrgn_grp_acnt_rt( a.acnt_no, a.sub_no,vn.faa_acnt_get_grp_no (a.acnt_no, a.sub_no,'2', vn.vwdate),'02', vn.vwdate)  rgt_sbst   ,
                           1 change_chk
                           from vn.srr02m00 a ,
                                vn.aaa01m00 b ,
								vn.srr01m10 d
                          where a.rgt_std_dt = i_rgt_dt
                            and a.rgt_tp     = i_rgt_tp
                            and a.stk_cd     = i_stk_cd
                            and a.seq_no     = to_number( i_seq_no )
                            and a.rgt_tp     = '8'
                            and a.acnt_no    like Trim(i_acnt_no)
							and a.sub_no     like trim(i_sub_no)
							and a.sub_no     = b.sub_no
                            and a.acnt_no    = b.acnt_no
                            and b.acnt_stat  = '1'
							and a.stk_cd     = d.stk_cd
                        ) x
                 where rgt_sbst > 0 or reuse_amt > 0
				 group by x.acnt_no , x.sub_no
				 order by 1
   ) loop

   vn.pxc_log_write('psr_sbst_proc_p', 'acnt_no : '|| m1.acnt_no || ' rgt_reuse : ' || m1.rgt_reuse || ' sbst : '|| m1.rgt_sbst);

	   if i_proc_tp = 'm' then

		  begin
            update vn.cwd01m00
			   set rgt_reuse = trunc( rgt_reuse +  m1.rgt_reuse )
			   	  ,rgt_sbst  = trunc( rgt_sbst  +  m1.rgt_sbst  )
             where acnt_no = m1.acnt_no
			   and sub_no  = m1.sub_no;
          exception
		       when others then
			        vn.pxc_log_write('psr_sbst_proc_p', m1.acnt_no || ' :  when confirm error ')  ;
			        t_err_msg := vn.fxc_get_err_msg('V','9006');
			        raise_application_error(-20100,t_err_msg);
          end  ;

	    elsif i_proc_tp = 'c'  then   -- c : cancel

          begin
            update vn.cwd01m00
               set rgt_reuse = trunc( greatest ( rgt_reuse -  m1.rgt_reuse , 0 )  )
                  ,rgt_sbst  = trunc( greatest ( rgt_sbst  -  m1.rgt_sbst  , 0 )  )
             where acnt_no = m1.acnt_no
			   and sub_no  = m1.sub_no;
          exception
               when others then
                    vn.pxc_log_write('psr_sbst_proc_p', m1.acnt_no || ' :  when cancel error')  ;
                    t_err_msg := vn.fxc_get_err_msg('V','9006');
                    raise_application_error(-20100,t_err_msg);
          end  ;

        end if ;

		if m1.change_chk > 0 then

			vn.pss_cal_sbst_p( vn.vwdate , m1.acnt_no , i_sub_no , i_work_mn ,td_cnt ) ;

		end if ;

		/* call evaluation for margin  */

        vn.pdl_crd_loan_rt_proc_td
          (  vn.vwdate
            ,'2' -- stock
            ,m1.acnt_no
            ,m1.sub_no
            ,'0'
            ,i_work_mn
            ,'SYSTEM'
            ,td_cnt
           );

        vn.pxc_log_write('pss_unbk_delay_p','pdl_crd_loan_rt_proc_td ['|| td_cnt ||']');


     end loop ;

end  psr_sbst_proc_p;
/

