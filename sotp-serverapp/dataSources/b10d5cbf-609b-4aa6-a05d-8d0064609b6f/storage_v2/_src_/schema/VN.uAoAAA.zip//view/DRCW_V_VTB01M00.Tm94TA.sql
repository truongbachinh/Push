create view DRCW_V_VTB01M00 as
SELECT a.trd_dt, a.seq_no, a.dat_cd, a.tran_no, a.ref_no, a.acc_no,
       a.mark_tp1, a.mark_tp2, a.mark_tp3, a.mark_tp4, a.mark_tp5,
       a.mark_tp6, a.tran_amt, a.recv_dat, a.recv_tp, a.recv_time,
       a.proc_cnt, a.error_code, a.error_desc, a.work_dtm, a.work_mn,
       a.work_trm
  FROM vtb01m00 a
UNION
SELECT b.trd_dt, b.seq_no, b.dat_cd, b.tran_no, b.ref_no, b.acc_no,
       b.mark_tp1, b.mark_tp2, b.mark_tp3, b.mark_tp4, b.mark_tp5,
       b.mark_tp6, b.tran_amt, b.recv_dat, b.recv_tp, b.recv_time,
       b.proc_cnt, b.error_code, b.error_desc, b.work_dtm, b.work_mn,
       b.work_trm
  FROM vtb01h00 b
/

