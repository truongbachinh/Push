create function    fcw_data_chk_q

  return          varchar2
as
    o_cnt    varchar2(2) ;

begin

    o_cnt  :=  'N' ;

   begin

    Select  Decode ( sum(cnt) , 0 , 'N' , 'Y' )
    into o_cnt
    from (
             select count(*)  cnt
               from vn.cwd06m00
              where cncl_yn  = 'N'
                and trd_seq_no = '0'
                and mdm_tp = '00'
          union all
             select count(*) cnt
               from vn.cwd06m10
              where cncl_yn = 'N'
                and trd_seq_no = '0'
                and mdm_tp = '00'
                and to_char(work_dtm, 'yyyymmdd') = to_char(sysdate, 'yyyymmdd')
          union all
             select count(*)  cnt
               from vn.cwd06m00
              where cncl_yn  = 'N'
                and trd_seq_no = '0'
                and rmrk_cd not in ('025','026')
                and mdm_tp <> '00'
                 and to_char(work_dtm,'yyyymmddHH24MISS') <= to_char(sysdate, 'yyyymmdd')||vn.fxc_tp_nm_g('check_time','01')
          union all
             select count(*)  cnt
               from vn.cwd06m10
              where cncl_yn  = 'N'
                and trd_seq_no = '0'
                and rmrk_cd not in ('025','026')
                and mdm_tp <> '00'
                 and to_char(work_dtm,'yyyymmddHH24MISS') <= to_char(sysdate, 'yyyymmdd')||vn.fxc_tp_nm_g('check_time','01')
          union all
             select count(*)  cnt
               from vn.cwd06m00
              where cncl_yn  = 'N'
                and trd_seq_no = '0'
                and rmrk_cd in ('025','026')
                and mdm_tp <> '00'
                 and to_char(work_dtm,'yyyymmddHH24MISS') <= to_char(sysdate, 'yyyymmdd')||vn.fxc_tp_nm_g('check_time','02')
            )
    ;
   exception
  when others then
    return 'Y';
  end  ;

  return  o_cnt;

end fcw_data_chk_q;
/

