create function fbm_get_sub_emp_base_sal(
    i_emp_no            varchar2,
    i_dt                varchar2,
    i_biz_emp_tp        varchar2,
    i_st_sub_lvl        number,
    i_ed_sub_lvl        number
)

return number
/*
    select fbm_get_sub_emp_base_sal(
        'tyhpt01',      -- i_emp_no         varchar2,
        vwdate,         -- i_dt             varchar2,
        '%'             -- i_biz_emp_tp     varchar2,
        2,              -- i_st_sub_lvl        number,
        2               -- i_ed_sub_lvl        number
    ) a
    from dual;
*/
as
pragma autonomous_transaction;

    t_proc_nm           varchar2(500)   := 'fbm_get_sub_emp_base_sal';
    t_tot_base_sal      number          := 0;
    o_tot_base_sal      number          := 0;

begin
    vn.pxc_log_write(t_proc_nm, ' ');
    vn.pxc_log_write(t_proc_nm, 'Start '                    || t_proc_nm        || ' for: '
                                || ' i_emp_no: '            || i_emp_no
                                || ' , i_dt: '              || i_dt
                                || ' , i_biz_emp_tp: '      || i_biz_emp_tp
                    );

    begin
        with emp_list as(
            select hie.sub_no emp_no
            from table (vn.fbm_get_sub_item_hier(
                                    '1',            -- i_tp        
                                    i_emp_no,       -- i_mng_emp_no
                                    i_dt            -- i_dt        
                                )
                            ) hie
            where hie.sub_no <> i_emp_no
            and hie.lvl between i_st_sub_lvl and i_ed_sub_lvl
        )
        select sum(xc1.base_sal)
        into t_tot_base_sal
        from emp_list el

        inner join vn.xca01m01 xm1          -- Bang nhan vien
        on el.emp_no = xm1.emp_no

        inner join vn.xca01c01  xc1           -- Bang chuc vu
        on xm1.posi_cd = xc1.posi_cd
        where xm1.biz_emp_tp like i_biz_emp_tp
        ;
    exception 
        when others then
            vn.pxc_log_write(t_proc_nm, 'exception' || sqlcode || ' -error- ' || sqlerrm);
            t_tot_base_sal := 0;
    end;

    o_tot_base_sal  := nvl(t_tot_base_sal, 0);

    vn.pxc_log_write(t_proc_nm, 'End. o_tot_base_sal: ' || o_tot_base_sal);

    return o_tot_base_sal;
end;
/

