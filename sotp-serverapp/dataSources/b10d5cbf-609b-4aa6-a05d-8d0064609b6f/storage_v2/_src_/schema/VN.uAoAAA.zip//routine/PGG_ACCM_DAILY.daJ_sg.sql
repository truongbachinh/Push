create PROCEDURE PGG_ACCM_DAILY
   (
   I_ACC_CLS_DT    IN      VARCHAR2,       -- 기준일자
   I_BRCH_CD       IN      VARCHAR2,       -- 지점
   I_AGNC_BRCH     IN      VARCHAR2,       -- 대리지점
   I_ACC_ACT_CD    IN      VARCHAR2,       -- 계정코드
   I_DR_EXCH_CNT   IN      NUMBER,
   I_DR_EXCH_AMT   IN      NUMBER,
   I_DR_CASH_CNT   IN      NUMBER,
   I_DR_CASH_AMT   IN      NUMBER,
   I_CR_EXCH_CNT   IN      NUMBER,
   I_CR_EXCH_AMT   IN      NUMBER,
   I_CR_CASH_CNT   IN      NUMBER,
   I_CR_CASH_AMT   IN      NUMBER,
   I_WORK_MN       IN      VARCHAR2        -- 작업자
   ) IS
   -- VARIABLES
   T_EXISTS      NUMBER := 0;    -- DATA EXISTS

BEGIN
   BEGIN
      SELECT  COUNT(*)
      INTO  T_EXISTS
      FROM	VN.GGA08M00 A   -- 회계계정
      WHERE	A.ACC_CLS_DT = I_ACC_CLS_DT
      AND   A.BRCH_CD    = I_BRCH_CD
      AND   A.AGNC_BRCH  = I_AGNC_BRCH
      AND   A.ACC_ACT_CD = I_ACC_ACT_CD
      ;
   END;

   IF T_EXISTS = 0 THEN
      BEGIN
         INSERT INTO VN.GGA08M00 (
                                    ACC_CLS_DT,
                                    BRCH_CD,
                                    AGNC_BRCH,
                                    ACC_ACT_CD,
                                    DR_EXCH_CNT,
                                    DR_EXCH_AMT,
                                    DR_CASH_CNT,
                                    DR_CASH_AMT,
                                    CR_EXCH_CNT,
                                    CR_EXCH_AMT,
                                    CR_CASH_CNT,
                                    CR_CASH_AMT,
                                    WORK_MN,
                                    WORK_DTM
                                 )
         VALUES (
                                    I_ACC_CLS_DT ,
                                    I_BRCH_CD    ,
                                    I_AGNC_BRCH  ,
                                    I_ACC_ACT_CD ,
                                    I_DR_EXCH_CNT,
                                    I_DR_EXCH_AMT,
                                    I_DR_CASH_CNT,
                                    I_DR_CASH_AMT,
                                    I_CR_EXCH_CNT,
                                    I_CR_EXCH_AMT,
                                    I_CR_CASH_CNT,
                                    I_CR_CASH_AMT,
                                    I_WORK_MN    ,
                                    SYSDATE
                  );

      END;

   ELSIF T_EXISTS > 0 THEN
      BEGIN
         UPDATE   VN.GGA08M00 A
         SET      A.DR_EXCH_CNT =  A.DR_EXCH_CNT + I_DR_EXCH_CNT    ,
                  A.DR_EXCH_AMT =  A.DR_EXCH_AMT + I_DR_EXCH_AMT    ,
                  A.DR_CASH_CNT =  A.DR_CASH_CNT + I_DR_CASH_CNT    ,
                  A.DR_CASH_AMT =  A.DR_CASH_AMT + I_DR_CASH_AMT    ,
                  A.CR_EXCH_CNT =  A.CR_EXCH_CNT + I_CR_EXCH_CNT    ,
                  A.CR_EXCH_AMT =  A.CR_EXCH_AMT + I_CR_EXCH_AMT    ,
                  A.CR_CASH_CNT =  A.CR_CASH_CNT + I_CR_CASH_CNT    ,
                  A.CR_CASH_AMT =  A.CR_CASH_AMT + I_CR_CASH_AMT    ,
                  A.WORK_MN     =  I_WORK_MN                        ,
                  A.WORK_DTM    =  SYSDATE
         WHERE    A.ACC_CLS_DT = I_ACC_CLS_DT
         AND      A.BRCH_CD    = I_BRCH_CD
         AND      A.AGNC_BRCH  = I_AGNC_BRCH
         AND      A.ACC_ACT_CD = I_ACC_ACT_CD
         ;
      END;
   END IF;

   EXCEPTION WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20087,'P:'||SUBSTR(SQLERRM, 5, 78));

END PGG_ACCM_DAILY;
/

