create function    fdl_get_mrgn_expt_int_amt
(
	i_acnt_no        in   varchar2,        --
	i_sub_no         in   varchar2
)
    return  number
as

	o_out_number  number := 0;
	t_lnd_rm_int  number := 0;

begin

/*============================================================================*/
/* Calculation                                                                */
/*============================================================================*/

	/* Get the remain margin loan interest and monthly interst */
    t_lnd_rm_int   := 0;

    BEGIN
    SELECT  nvl(sum(nvl(lnd_int,0)) + sum(nvl(dly_int,0)),0)      lnd_rm_int
      INTO  t_lnd_rm_int
      FROM  vn.dlm01m00
     WHERE  lnd_tp         IN  ('70', '80')
       AND  acnt_no         =  i_acnt_no
       AND  sub_no          =  i_sub_no
       AND  lnd_acpt_tp     =  '01'
       AND  lnd_amt > lnd_rpy_amt
    ;
    EXCEPTION
    WHEN OTHERS THEN
        t_lnd_rm_int   := 0;
    END;

	o_out_number := o_out_number +  t_lnd_rm_int;

	t_lnd_rm_int   := 0;
    t_lnd_rm_int   := vn.fdl_get_mon_rm_int('%','70',i_acnt_no,i_sub_no,'%','%','%');

 			vn.pxc_log_write('fdl_get_mrgn_expt_int_amt', 'Check ' || i_acnt_no ||'-'||i_sub_no
			                                       ||' o_out_number = '|| o_out_number
			                                       ||' t_lnd_rm_int = '|| t_lnd_rm_int);

    o_out_number := o_out_number +  t_lnd_rm_int;



    RETURN o_out_number;

end fdl_get_mrgn_expt_int_amt;
/

