create PROCEDURE PTS_BAT_TSO02H00_INS (
    I_WORK_DT       IN      VARCHAR2,       -- DATE(YYYYMMDD)
    I_WORK_MN		IN		VARCHAR2,
    I_WORK_TRM		IN		VARCHAR2,
	 O_PROC_CNT      IN  OUT NUMBER          -- PROC DATA COUNT
) AS

/*!
    \FILE     PTS_BAT_TSO20H00_INS
	\BRIEF    TSO02M00 SELECT, TSO02H00 INSERT

	\SECTION INTRO PROGRAM INFORMATION
		- PROGRAM NAME              : PTS_BAT_TSO02H00_INS
		- SERVICE NAME              :
		- RELATED CLIENT PROGRAM- CLIENT PROGRAM ID :
		- RELATED TABLES            : TSO02M00, TSO02H00
		- DEV. DATE                 : 2008/02/10
		- DEVELOPER                 : SB.LEE
		- BUSINESS LOGIC DESC.      :
		- LATEST MODIFICATION DATE  :

	\SECTION HISTORY PROGRAM MODIFICATION HISTORY
		- 1.0  2008/02/10

	\SECTION HARDCODING HARD-CODING LIST

	\SECTION INFO ADDITIONAL REFERENCE COMMENTS
*/

	t_err_txt				varchar2(200) := Null;

    t_err_msg    varchar2(500);
BEGIN


	delete 	vn.tso02h00
	where	dt = i_work_dt;

	delete vn.xcc99m02;

    FOR  C1  IN (
        SELECT  ACNT_NO            ,
        		SUB_NO			   ,
                BANK_CD            ,
                nvl(REUSE_DPO       ,0) REUSE_DPO       ,
                nvl(EXPT_SBST_AMT       ,0) EXPT_SBST_AMT       ,
                nvl(BANK_TRD_NO       ,0) BANK_TRD_NO       ,
                nvl(TD_CASH_PROF_AMT  ,0) TD_CASH_PROF_AMT  ,
                nvl(TD_CDT_PROF_AMT  ,0) TD_CDT_PROF_AMT  ,
                nvl(TD_CASH_PROF_GST_AMT  ,0) TD_CASH_PROF_GST_AMT  ,
                nvl(TD_MGN_BUY_DIFF_AMT  ,0) TD_MGN_BUY_DIFF_AMT  ,
                nvl(TD_MGN_SELL_DIFF_AMT  ,0) TD_MGN_SELL_DIFF_AMT  ,
                nvl(TD_SELL_MTH_AMT   ,0) TD_SELL_MTH_AMT   ,
                nvl(TD_BUY_MTH_AMT    ,0) TD_BUY_MTH_AMT    ,
                nvl(TD_MGN_BUY_ORG_AMT  ,0) TD_MGN_BUY_ORG_AMT  ,
                nvl(TD_MGN_SELL_ORG_AMT  ,0) TD_MGN_SELL_ORG_AMT  ,
                nvl(PD_BANK_TRD_NO    ,0) PD_BANK_TRD_NO    ,
                nvl(PD_CASH_PROF_AMT  ,0) PD_CASH_PROF_AMT  ,
                nvl(PD_CDT_PROF_AMT  ,0) PD_CDT_PROF_AMT  ,
                nvl(PD_MGN_BUY_DIFF_AMT  ,0) PD_MGN_BUY_DIFF_AMT  ,
                nvl(PD_MGN_SELL_DIFF_AMT  ,0) PD_MGN_SELL_DIFF_AMT  ,
                nvl(PD_CASH_PROF_GST_AMT  ,0) PD_CASH_PROF_GST_AMT  ,
                nvl(PD_SELL_MTH_AMT   ,0) PD_SELL_MTH_AMT   ,
                nvl(PD_BUY_MTH_AMT    ,0) PD_BUY_MTH_AMT    ,
                nvl(PD_MGN_BUY_ORG_AMT  ,0) PD_MGN_BUY_ORG_AMT  ,
                nvl(PD_MGN_SELL_ORG_AMT  ,0) PD_MGN_SELL_ORG_AMT  ,
                nvl(PPD_BANK_TRD_NO   ,0) PPD_BANK_TRD_NO   ,
                nvl(PPD_CASH_PROF_AMT ,0) PPD_CASH_PROF_AMT ,
                nvl(PPD_CDT_PROF_AMT ,0) PPD_CDT_PROF_AMT ,
                nvl(PPD_MGN_BUY_DIFF_AMT  ,0) PPD_MGN_BUY_DIFF_AMT  ,
                nvl(PPD_MGN_SELL_DIFF_AMT  ,0) PPD_MGN_SELL_DIFF_AMT  ,
                nvl(PPD_CASH_PROF_GST_AMT ,0) PPD_CASH_PROF_GST_AMT ,
                nvl(PPD_SELL_MTH_AMT  ,0) PPD_SELL_MTH_AMT  ,
                nvl(PPD_BUY_MTH_AMT   ,0) PPD_BUY_MTH_AMT   ,
                nvl(PPD_MGN_BUY_ORG_AMT  ,0) PPD_MGN_BUY_ORG_AMT  ,
                nvl(PPD_MGN_SELL_ORG_AMT  ,0) PPD_MGN_SELL_ORG_AMT  ,
                nvl(PPPD_BANK_TRD_NO  ,0) PPPD_BANK_TRD_NO  ,
                nvl(PPPD_CASH_PROF_AMT,0) PPPD_CASH_PROF_AMT,
                nvl(PPPD_CDT_PROF_AMT,0) PPPD_CDT_PROF_AMT,
                nvl(PPPD_MGN_BUY_DIFF_AMT  ,0) PPPD_MGN_BUY_DIFF_AMT  ,
                nvl(PPPD_MGN_SELL_DIFF_AMT  ,0) PPPD_MGN_SELL_DIFF_AMT  ,
                nvl(PPPD_CASH_PROF_GST_AMT,0) PPPD_CASH_PROF_GST_AMT,
                nvl(PPPD_SELL_MTH_AMT ,0) PPPD_SELL_MTH_AMT ,
                nvl(PPPD_BUY_MTH_AMT  ,0) PPPD_BUY_MTH_AMT  ,
                nvl(PPPD_MGN_BUY_ORG_AMT  ,0) PPPD_MGN_BUY_ORG_AMT  ,
                nvl(PPPD_MGN_SELL_ORG_AMT  ,0) PPPD_MGN_SELL_ORG_AMT  ,
                nvl(WORK_MN  ,  'SYSTEM') WORK_MN           ,
                nvl(WORK_DTM ,  SYSDATE ) WORK_DTM          ,
                nvl(WORK_TRM ,  'SYSTEM') WORK_TRM
          FROM  VN.TSO02M00
         WHERE  (   TD_CASH_PROF_AMT   > 0 OR TD_CDT_PROF_AMT   > 0 OR TD_SELL_MTH_AMT   > 0 OR TD_BUY_MTH_AMT   > 0 OR TD_CASH_PROF_GST_AMT > 0    OR TD_MGN_BUY_DIFF_AMT   > 0     OR TD_MGN_SELL_DIFF_AMT    > 0    OR TD_MGN_SELL_ORG_AMT   > 0  OR TD_MGN_BUY_ORG_AMT   > 0
                 OR PD_CASH_PROF_AMT   > 0 OR PD_CDT_PROF_AMT   > 0 OR PD_SELL_MTH_AMT   > 0 OR PD_BUY_MTH_AMT   > 0 OR PD_CASH_PROF_GST_AMT > 0    OR PD_MGN_BUY_DIFF_AMT   > 0     OR PD_MGN_SELL_DIFF_AMT    > 0    OR PD_MGN_SELL_ORG_AMT   > 0  OR PD_MGN_BUY_ORG_AMT   > 0
                 OR PPD_CASH_PROF_AMT  > 0 OR PPD_CDT_PROF_AMT  > 0 OR PPD_SELL_MTH_AMT  > 0 OR PPD_BUY_MTH_AMT  > 0 OR PPD_CASH_PROF_GST_AMT > 0   OR PPD_MGN_BUY_DIFF_AMT  > 0     OR PPD_MGN_SELL_DIFF_AMT   > 0    OR PPD_MGN_SELL_ORG_AMT  > 0  OR PPD_MGN_BUY_ORG_AMT  > 0
                 OR PPPD_CASH_PROF_AMT > 0 OR PPPD_CDT_PROF_AMT > 0 OR PPPD_SELL_MTH_AMT > 0 OR PPPD_BUY_MTH_AMT > 0 OR PPPD_CASH_PROF_GST_AMT > 0  OR PPPD_MGN_BUY_DIFF_AMT > 0     OR PPPD_MGN_SELL_DIFF_AMT  > 0    OR PPPD_MGN_SELL_ORG_AMT > 0  OR PPPD_MGN_BUY_ORG_AMT > 0
                 OR REUSE_DPO > 0  OR EXPT_SBST_AMT > 0)
    ) LOOP
		BEGIN
            INSERT INTO VN.TSO02H00 (
                DT                      ,
                ACNT_NO                 ,
                SUB_NO					,
                BANK_CD                 ,
                REUSE_DPO               ,
                EXPT_SBST_AMT			,
                BANK_TRD_NO             ,
                TD_CASH_PROF_AMT        ,
                TD_CDT_PROF_AMT         ,
                TD_CASH_PROF_GST_AMT    ,
                TD_MGN_BUY_DIFF_AMT     ,
                TD_MGN_SELL_DIFF_AMT    ,
                TD_SELL_MTH_AMT         ,
                TD_BUY_MTH_AMT          ,
                TD_MGN_BUY_ORG_AMT      ,
                TD_MGN_SELL_ORG_AMT     ,
                PD_BANK_TRD_NO          ,
                PD_CASH_PROF_AMT        ,
                PD_CDT_PROF_AMT         ,
                PD_CASH_PROF_GST_AMT    ,
                PD_MGN_BUY_DIFF_AMT     ,
                PD_MGN_SELL_DIFF_AMT    ,
                PD_SELL_MTH_AMT         ,
                PD_BUY_MTH_AMT          ,
                PD_MGN_BUY_ORG_AMT      ,
                PD_MGN_SELL_ORG_AMT     ,
                PPD_BANK_TRD_NO         ,
                PPD_CASH_PROF_AMT       ,
                PPD_CDT_PROF_AMT        ,
                PPD_CASH_PROF_GST_AMT   ,
                PPD_MGN_BUY_DIFF_AMT    ,
                PPD_MGN_SELL_DIFF_AMT   ,
                PPD_SELL_MTH_AMT        ,
                PPD_BUY_MTH_AMT         ,
                PPD_MGN_BUY_ORG_AMT     ,
                PPD_MGN_SELL_ORG_AMT    ,
                PPPD_BANK_TRD_NO        ,
                PPPD_CASH_PROF_AMT      ,
                PPPD_CDT_PROF_AMT       ,
                PPPD_CASH_PROF_GST_AMT  ,
                PPPD_MGN_BUY_DIFF_AMT   ,
                PPPD_MGN_SELL_DIFF_AMT  ,
                PPPD_SELL_MTH_AMT       ,
                PPPD_BUY_MTH_AMT        ,
                PPPD_MGN_BUY_ORG_AMT    ,
                PPPD_MGN_SELL_ORG_AMT   ,
                WORK_MN                 ,
                WORK_DTM                ,
                WORK_TRM
            ) VALUES (
                I_WORK_DT                   ,
                C1.ACNT_NO                  ,
                C1.SUB_NO					,
                C1.BANK_CD                  ,
                C1.REUSE_DPO                ,
                C1.EXPT_SBST_AMT			,
                C1.BANK_TRD_NO              ,
                C1.TD_CASH_PROF_AMT         ,
                C1.TD_CDT_PROF_AMT          ,
                C1.TD_CASH_PROF_GST_AMT     ,
                C1.TD_MGN_BUY_DIFF_AMT      ,
                C1.TD_MGN_SELL_DIFF_AMT     ,
                C1.TD_SELL_MTH_AMT          ,
                C1.TD_BUY_MTH_AMT           ,
                C1.TD_MGN_BUY_ORG_AMT       ,
                C1.TD_MGN_SELL_ORG_AMT      ,
                C1.PD_BANK_TRD_NO           ,
                C1.PD_CASH_PROF_AMT         ,
                C1.PD_CDT_PROF_AMT          ,
                C1.PD_CASH_PROF_GST_AMT     ,
                C1.PD_MGN_BUY_DIFF_AMT      ,
                C1.PD_MGN_SELL_DIFF_AMT     ,
                C1.PD_SELL_MTH_AMT          ,
                C1.PD_BUY_MTH_AMT           ,
                C1.PD_MGN_BUY_ORG_AMT       ,
                C1.PD_MGN_SELL_ORG_AMT      ,
                C1.PPD_BANK_TRD_NO          ,
                C1.PPD_CASH_PROF_AMT        ,
                C1.PPD_CDT_PROF_AMT         ,
                C1.PPD_CASH_PROF_GST_AMT    ,
                C1.PPD_MGN_BUY_DIFF_AMT     ,
                C1.PPD_MGN_SELL_DIFF_AMT    ,
                C1.PPD_SELL_MTH_AMT         ,
                C1.PPD_BUY_MTH_AMT          ,
                C1.PPD_MGN_BUY_ORG_AMT      ,
                C1.PPD_MGN_SELL_ORG_AMT     ,
                C1.PPPD_BANK_TRD_NO         ,
                C1.PPPD_CASH_PROF_AMT       ,
                C1.PPPD_CDT_PROF_AMT        ,
                C1.PPPD_CASH_PROF_GST_AMT   ,
                C1.PPPD_MGN_BUY_DIFF_AMT    ,
                C1.PPPD_MGN_SELL_DIFF_AMT   ,
                C1.PPPD_SELL_MTH_AMT        ,
                C1.PPPD_BUY_MTH_AMT         ,
                C1.PPPD_MGN_BUY_ORG_AMT     ,
                C1.PPPD_MGN_SELL_ORG_AMT    ,
                'SYSTEM'                    ,
                SYSDATE                     ,
                'SYSTEM'
            );


		EXCEPTION
        WHEN  OTHERS         THEN
            vn.pxc_log_write('pts_bat_tso02h00_ins','Insert tso02h00 Err-['||sqlcode||']');
            t_err_txt  :=  'Insert tso02h00 Err-'
                   ||  to_char(sqlcode);
			t_err_msg := vn.fxc_get_err_msg('V','2713');
			raise_application_error(-20100,t_err_msg||t_err_txt);
    	END;
    END LOOP;
  --luu du lieu lenh cho swift
  	delete 	vn.tso03h04
	  where	ord_dt = i_work_dt;
	  delete 	vn.tso03h20
	  where	ord_dt = i_work_dt;
	  delete 	vn.tso03h21
	  where	ord_dt = i_work_dt;

	  FOR C2 IN (
	  SELECT BNH_CD,
       SEQ_NO,
       ORD_NO,
       ORG_ORD_NO,
       ACNT_NO,
       SUB_NO,
       STK_CD,
       ORD_QTY,
       ORD_PRI,
       ORD_PROF_PRI,
       BANK_CD,
       CDT_TP,
       SELL_BUY_TP,
       MKT_TRD_TP,
       STK_ORD_TP,
       STK_TP,
       MDM_TP,
       ORD_VETO_CAU,
       PASSWD,
       APPR_STS,
       CRRT_CNCL_TP,
       PRGT_ORD_TP,
       BANK_ACNT_NO,
       WORK_BNH,
       PROC_AGNC_BRCH,
       AGNC_BRCH_CD,
       DEPT_CD,
       IDNO,
       TEL_NO,
       LND_DT,
       MRTG_DT,
       WORK_MN,
       WORK_DTM,
       WORK_TRM
       FROM VN.TSO03M04
	  ) LOOP
	  BEGIN
	  INSERT INTO VN.TSO03H04(
	     ORD_DT,
	     BNH_CD,
       SEQ_NO,
       ORD_NO,
       ORG_ORD_NO,
       ACNT_NO,
       SUB_NO,
       STK_CD,
       ORD_QTY,
       ORD_PRI,
       ORD_PROF_PRI,
       BANK_CD,
       CDT_TP,
       SELL_BUY_TP,
       MKT_TRD_TP,
       STK_ORD_TP,
       STK_TP,
       MDM_TP,
       ORD_VETO_CAU,
       PASSWD,
       APPR_STS,
       CRRT_CNCL_TP,
       PRGT_ORD_TP,
       BANK_ACNT_NO,
       WORK_BNH,
       PROC_AGNC_BRCH,
       AGNC_BRCH_CD,
       DEPT_CD,
       IDNO,
       TEL_NO,
       LND_DT,
       MRTG_DT,
       WORK_MN,
       WORK_DTM,
       WORK_TRM
	  	)
	  	VALUES
	  	(
	  	 I_WORK_DT,
	  	 C2.BNH_CD,
	  	 C2.SEQ_NO,
       C2.ORD_NO,
       C2.ORG_ORD_NO,
       C2.ACNT_NO,
       C2.SUB_NO,
       C2.STK_CD,
       C2.ORD_QTY,
       C2.ORD_PRI,
       C2.ORD_PROF_PRI,
       C2.BANK_CD,
       C2.CDT_TP,
       C2.SELL_BUY_TP,
       C2.MKT_TRD_TP,
       C2.STK_ORD_TP,
       C2.STK_TP,
       C2.MDM_TP,
       C2.ORD_VETO_CAU,
       C2.PASSWD,
       C2.APPR_STS,
       C2.CRRT_CNCL_TP,
       C2.PRGT_ORD_TP,
       C2.BANK_ACNT_NO,
       C2.WORK_BNH,
       C2.PROC_AGNC_BRCH,
       C2.AGNC_BRCH_CD,
       C2.DEPT_CD,
       C2.IDNO,
       C2.TEL_NO,
       C2.LND_DT,
       C2.MRTG_DT,
       C2.WORK_MN,
       C2.WORK_DTM,
       C2.WORK_TRM
	  	);
	  EXCEPTION
        WHEN  OTHERS         THEN
            vn.pxc_log_write('pts_bat_tso02h00_ins','Insert tso03H04 Err-['||sqlcode||']');
            t_err_txt  :=  'Insert tso03H04 Err-'
                   ||  to_char(sqlcode);
			t_err_msg := vn.fxc_get_err_msg('V','2713');
			raise_application_error(-20100,t_err_msg||t_err_txt);
    END;
	  END LOOP;

    FOR C3 IN(
    SELECT ID,
       CORE_REF,
       EARMARK_TYPE,
       INVESTOR_TYPE,
       INVESTOR,
       TICKER,
       CODE,
       CURRENCY,
       AMOUNT,
       SHAREHOLDER_RPT,
       CUSTODIAN,
       ACC_REQ,
       OPT_BANK,
       EARMARK_STATUS,
       SH_RPT_STATUS,
       REJECT_STATUS,
       MSG_STATUS,
       CREATED_ON,
       LAST_UPDATED,
       MSG_REQUEST,
       MSG_RESPONSE,
       PROF_CLS_YN
       FROM VN.TSO03M20
       )LOOP
       BEGIN
       INSERT INTO VN.TSO03H20(
         ORD_DT,
	       ID,
	       CORE_REF,
	       EARMARK_TYPE,
	       INVESTOR_TYPE,
	       INVESTOR,
	       TICKER,
	       CODE,
	       CURRENCY,
	       AMOUNT,
	       SHAREHOLDER_RPT,
	       CUSTODIAN,
	       ACC_REQ,
	       OPT_BANK,
	       EARMARK_STATUS,
	       SH_RPT_STATUS,
	       REJECT_STATUS,
	       MSG_STATUS,
	       CREATED_ON,
	       LAST_UPDATED,
	       MSG_REQUEST,
	       MSG_RESPONSE,
	       PROF_CLS_YN
       	)
       	VALUES(
       	 I_WORK_DT,
       	 C3.ID,
	       C3.CORE_REF,
	       C3.EARMARK_TYPE,
	       C3.INVESTOR_TYPE,
	       C3.INVESTOR,
	       C3.TICKER,
	       C3.CODE,
	       C3.CURRENCY,
	       C3.AMOUNT,
	       C3.SHAREHOLDER_RPT,
	       C3.CUSTODIAN,
	       C3.ACC_REQ,
	       C3.OPT_BANK,
	       C3.EARMARK_STATUS,
	       C3.SH_RPT_STATUS,
	       C3.REJECT_STATUS,
	       C3.MSG_STATUS,
	       C3.CREATED_ON,
	       C3.LAST_UPDATED,
	       C3.MSG_REQUEST,
	       C3.MSG_RESPONSE,
	       C3.PROF_CLS_YN
	       );
	    EXCEPTION
	       WHEN  OTHERS         THEN
            vn.pxc_log_write('pts_bat_tso02h00_ins','Insert tso03H20 Err-['||sqlcode||']');
            t_err_txt  :=  'Insert tso03H20 Err-'
                   ||  to_char(sqlcode);
			 t_err_msg := vn.fxc_get_err_msg('V','2713');
			 raise_application_error(-20100,t_err_msg||t_err_txt);
       END;
       END LOOP;
      FOR C4 IN (
      SELECT ID,
       CORE_REF,
       REF_ID,
       UNEARMARK_STATUS,
       MSG_STATUS,
       LAST_UPDATED,
       CREATED_ON,
       REJECT_STATUS,
       MSG_REQUEST,
       MSG_REPONSE,
       PROF_CLS_YN
      FROM VN.TSO03M21
      )LOOP
      BEGIN
      INSERT INTO VN.TSO03H21
      (
       ORD_DT,
       ID,
       CORE_REF,
       REF_ID,
       UNEARMARK_STATUS,
       MSG_STATUS,
       LAST_UPDATED,
       CREATED_ON,
       REJECT_STATUS,
       MSG_REQUEST,
       MSG_REPONSE,
       PROF_CLS_YN
      )
      VALUES
      (
      	I_WORK_DT,
      	C4.ID,
        C4.CORE_REF,
        C4.REF_ID,
        C4.UNEARMARK_STATUS,
        C4.MSG_STATUS,
        C4.LAST_UPDATED,
        C4.CREATED_ON,
        C4.REJECT_STATUS,
        C4.MSG_REQUEST,
        C4.MSG_REPONSE,
        C4.PROF_CLS_YN
      );
      EXCEPTION
	       WHEN  OTHERS         THEN
            vn.pxc_log_write('pts_bat_tso02h00_ins','Insert tso03H21 Err-['||sqlcode||']');
            t_err_txt  :=  'Insert tso03H21 Err-'
                   ||  to_char(sqlcode);
			 t_err_msg := vn.fxc_get_err_msg('V','2713');
			 raise_application_error(-20100,t_err_msg||t_err_txt);
    	END;
    	END LOOP;
  --delete old data
  delete vn.tso03m04;
  delete vn.tso03m20;
  delete vn.tso03m21;

	--Update lai TK da chuyen qua margin thi ko con bao lanh
	update tso02m00 a
	set TD_CASH_PROF_GST_AMT = 0,
	    PD_CASH_PROF_GST_AMT = 0,
	    PPD_CASH_PROF_GST_AMT = 0,
	    PPPD_CASH_PROF_GST_AMT = 0
	where (acnt_no,sub_no) in (select acnt_no,sub_no from dlm51m00 where acnt_no = a.acnt_no and sub_no = a.sub_no and active_stat = 'Y' AND apy_dt <= vn.vwdate);

	O_PROC_CNT := sql%rowcount;


END PTS_BAT_TSO02H00_INS;
/

