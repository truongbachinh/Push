create function fdl_get_lnd_bank_nm
(
    i_lnd_bank_cd  in   varchar2
)
    return  varchar2
as
	o_lnd_bank_nm	varchar2(100);
begin

/*============================================================================*/
/* Name of the Bank return                                                    */
/*============================================================================*/

	if i_lnd_bank_cd in ('0000') then
		return 'For All Banks';
	else
		for C1 IN (
		    select  lnd_bank_nm
			  from  vn.dlm12m00
			 where  lnd_bank_cd  =  i_lnd_bank_cd
			   and  apy_dt       =  (select  max(apy_dt)
			                           from  vn.dlm12m00
			                          where  lnd_bank_cd  =  i_lnd_bank_cd)
			 order  by apy_dt desc
		) loop
		    o_lnd_bank_nm := C1.lnd_bank_nm;
		    return o_lnd_bank_nm;
		end loop;

	    return '!';
	end if;

end fdl_get_lnd_bank_nm;
/

