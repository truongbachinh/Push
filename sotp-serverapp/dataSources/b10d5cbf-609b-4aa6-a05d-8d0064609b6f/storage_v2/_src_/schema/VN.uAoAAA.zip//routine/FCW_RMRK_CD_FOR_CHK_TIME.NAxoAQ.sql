create function    fcw_rmrk_cd_for_chk_time
(
	i_mdm_tp       in		varchar2,
	i_rmrk_cd_cur  in		varchar2,
    i_rmrk_cd_new  in		varchar2
) return varchar2 as
	o_rmrk_cd	varchar2(5);
/*
NHSV-997: Điều chỉnh remarkcode phù hợp theo setup trên 07327
*/
begin
    if i_rmrk_cd_new is null or length(trim(i_rmrk_cd_new)) <= 0 then
        o_rmrk_cd := i_rmrk_cd_cur;
    else
        if i_mdm_tp = '00' then
            o_rmrk_cd := i_rmrk_cd_new;
        else
            o_rmrk_cd := i_rmrk_cd_cur;
        end if;
    end if;

    return o_rmrk_cd;
end ;
/

