create PROCEDURE    PGG_MANUAL_VOUCHER
   (I_FLAG				IN      VARCHAR2,       -- I:처리,D:취소
    I_SLIP_DT			IN      VARCHAR2,       -- 전표일
    I_PROC_BRCH_CD		IN      VARCHAR2,       -- 처리지점
    I_PROC_AGNC_BRCH	IN      VARCHAR2,       -- 처리대리지점
    I_EXCH_BRCH_CD		IN      VARCHAR2,       -- 이체지점
    I_EXCH_AGNC_BRCH	IN      VARCHAR2,       -- 이체대리지점
    I_RMRK_JOB_TP		IN      VARCHAR2,       -- 적요업무구분('42')
    I_ACC_RMRK_CD		IN      VARCHAR2,       -- 회계적요코드
    I_ACC_ACT_CD		IN      VARCHAR2,       -- 회계계정코드
    I_DEPT_CD			IN      VARCHAR2,       -- 부서코드
    I_CUST_CD			IN      VARCHAR2,       -- 고객코드
    I_DR_AMT_01			IN      NUMBER,       	-- 차변금액01
    I_DR_AMT_02			IN      NUMBER,       	-- 차변금액02
    I_DR_AMT_03			IN      NUMBER,       	-- 차변금액03
    I_CR_AMT_01			IN      NUMBER,       	-- 대변금액01
    I_CR_AMT_02			IN      NUMBER,       	-- 대변금액02
    I_CR_AMT_03			IN      NUMBER,       	-- 대변금액03
    I_WORK_MN			IN      VARCHAR2,		-- 처리자
    I_WORK_TRM			IN      VARCHAR2,       -- IP_ADDRESS
    O_SLIP_NO			OUT     VARCHAR2,
	O_SLIP_SUB_NO		OUT     VARCHAR2,
    O_SLIP_NO1			OUT     VARCHAR2,
	O_SLIP_SUB_NO1		OUT     VARCHAR2,
    O_RTN_TBL			OUT     VARCHAR2,       -- Return Table
	O_RTN_ERR			OUT     VARCHAR2,       -- Return Error Code
	O_RTN_MSG			OUT     VARCHAR2        -- Return Message
	) IS


    -- Constants
    K_ALL_BRCH      VARCHAR2(3) := '000' ;      -- 회사전체
    K_BON_BRCH      VARCHAR2(3) := '901' ;      -- 본점
    K_JI_BRCH		VARCHAR2(3) := '997' ;      -- 지점통칭

    K_211_ACC_CD    VARCHAR2(12) := '211000000000' ;      -- 유형자산
    K_213_ACC_CD    VARCHAR2(12) := '213000000000' ;      -- 무형자산


    -- Variables
    T_CNT							NUMBER := 0;

	T_PROC_BRCH_CD					VN.GGA06M00.BRCH_CD%TYPE;				-- 처리지점
    T_PROC_AGNC_BRCH				VN.GGA06M00.AGNC_BRCH%TYPE;				-- 처리대리지점
	T_EXCH_BRCH_CD					VN.GGA06M00.BRCH_CD%TYPE;				-- 이체지점
    T_EXCH_AGNC_BRCH				VN.GGA06M00.AGNC_BRCH%TYPE;				-- 이체대리지점

    T_HEAD_BRCH_TP					VARCHAR2(1) ;

    T_SEND_SLIP_NO					VN.GGA06M00.SLIP_NO%TYPE;				-- 발신전표번호
    T_RECV_SLIP_NO					VN.GGA06M00.SLIP_NO%TYPE;				-- 수신전표번호

	T_SEND_BRCH_CD					VN.GGA06M00.BRCH_CD%TYPE;				-- 발신지점
    T_SEND_AGNC_BRCH				VN.GGA06M00.AGNC_BRCH%TYPE;				-- 발신대리지점
	T_SEND_CUST_CD					VN.GGA06M00.CUST_CD%TYPE;				-- 발신거래처코드
	T_RECV_BRCH_CD					VN.GGA06M00.BRCH_CD%TYPE;				-- 수신지점
    T_RECV_AGNC_BRCH				VN.GGA06M00.AGNC_BRCH%TYPE;				-- 수신대리지점


    T_GGA06M00_SLIP_DT				VN.GGA06M00.SLIP_DT%TYPE;				-- 전표일자
    T_GGA06M00_BRCH_CD				VN.GGA06M00.BRCH_CD%TYPE;				-- 지점코드
    T_GGA06M00_AGNC_BRCH			VN.GGA06M00.AGNC_BRCH%TYPE;				-- 대리지점
    T_GGA06M00_SLIP_NO				VN.GGA06M00.SLIP_NO%TYPE;				-- 전표번호
    T_GGA06M00_SLIP_SUB_NO			VN.GGA06M00.SLIP_SUB_NO%TYPE;			-- 전표부번호
    T_GGA06M00_RMRK_JOB_TP			VN.GGA06M00.RMRK_JOB_TP%TYPE;			-- 적요업무구분
    T_GGA06M00_SLIP_TP				VN.GGA06M00.SLIP_TP%TYPE;				-- 전표구분
    T_GGA06M00_ACC_RMRK_CD			VN.GGA06M00.ACC_RMRK_CD%TYPE;			-- 회계적요코드
    T_GGA06M00_TRD_CNTE				VN.GGA06M00.TRD_CNTE%TYPE;				-- 거래비고
    T_GGA06M00_DR_CR_TP				VN.GGA06M00.DR_CR_TP%TYPE;				-- 차변대변구분
    T_GGA06M00_ACC_ACT_CD			VN.GGA06M00.ACC_ACT_CD%TYPE;			-- 회계계정코드
    T_GGA06M00_OPR_BNH_CD			VN.GGA06M00.OPR_BNH_CD%TYPE;			-- 상대부점코드
    T_GGA06M00_OPR_AGNC_BRCH		VN.GGA06M00.OPR_AGNC_BRCH%TYPE;			-- 상대대리지점
    T_GGA06M00_SLIP_AMT				VN.GGA06M00.SLIP_AMT%TYPE;				-- 전표금액
    T_GGA06M00_DETL_CNTE			VN.GGA06M00.DETL_CNTE%TYPE;				-- 상세비고
    T_GGA06M00_RECV_SND_TP			VN.GGA06M00.RECV_SND_TP%TYPE;			-- 수신발신구분
    T_GGA06M00_RECV_YN				VN.GGA06M00.RECV_YN%TYPE;				-- 수신여부
    T_GGA06M00_AUTO_TP				VN.GGA06M00.AUTO_TP%TYPE;				-- 자동구분
    T_GGA06M00_SLIP_STAT			VN.GGA06M00.SLIP_STAT%TYPE;				-- 전표상태
    T_GGA06M00_DRAF_MN				VN.GGA06M00.DRAF_MN%TYPE;				-- 기안자
    T_GGA06M00_DRAF_DTM				VN.GGA06M00.DRAF_DTM%TYPE;				-- 기안일시
    T_GGA06M00_CNFM_MN				VN.GGA06M00.CNFM_MN%TYPE;				-- 승인자
    T_GGA06M00_CNFM_DTM				VN.GGA06M00.CNFM_DTM%TYPE;				-- 승인일시
    T_GGA06M00_CUST_CD				VN.GGA06M00.CUST_CD%TYPE;				-- 거래처코드
    T_GGA06M00_SUP_PRI_AMT			VN.GGA06M00.SUP_PRI_AMT%TYPE;			-- 공급가액
    T_GGA06M00_VAT_AMT				VN.GGA06M00.VAT_AMT%TYPE;				-- 부가세액
    T_GGA06M00_EVI_TP				VN.GGA06M00.EVI_TP%TYPE;				-- 증빙구분
    T_GGA06M00_EVI_DT				VN.GGA06M00.EVI_DT%TYPE;				-- 증빙일자
    T_GGA06M00_EVI_NO				VN.GGA06M00.EVI_NO%TYPE;				-- 증빙번호
    T_GGA06M00_TAXB_NO				VN.GGA06M00.TAXB_NO%TYPE;				-- 세무번호
    T_GGA06M00_ORIG_ACNT_NO			VN.GGA06M00.ORIG_ACNT_NO%TYPE;			-- 원천계좌번호
    T_GGA06M00_ORIG_TRD_DT			VN.GGA06M00.ORIG_TRD_DT%TYPE;			-- 원천거래일
    T_GGA06M00_ORIG_TRD_SEQ_NO		VN.GGA06M00.ORIG_TRD_SEQ_NO%TYPE;		-- 원천거래일련번호
    T_GGA06M00_RECV_SND_NO			VN.GGA06M00.RECV_SND_NO%TYPE;			-- 수신발신번호
    T_GGA06M00_WORK_MN				VN.GGA06M00.WORK_MN%TYPE;				-- 처리자
    T_GGA06M00_WORK_DTM				VN.GGA06M00.WORK_DTM%TYPE;				-- 처리일시
    T_GGA06M00_WORK_TRM				VN.GGA06M00.WORK_TRM%TYPE;				-- 처리단말


    T_GGA06M01_RECV_SND_NO			VN.GGA06M01.RECV_SND_NO%TYPE;			-- 수신발신번호
    T_GGA06M01_SLIP_DT				VN.GGA06M01.SLIP_DT%TYPE;				-- 전표일자
    T_GGA06M01_BRCH_CD				VN.GGA06M01.BRCH_CD%TYPE;				-- 지점코드
    T_GGA06M01_AGNC_BRCH			VN.GGA06M01.AGNC_BRCH%TYPE;				-- 대리지점
    T_GGA06M01_SLIP_NO				VN.GGA06M01.SLIP_NO%TYPE;				-- 전표번호
    T_GGA06M01_SLIP_SUB_NO			VN.GGA06M01.SLIP_SUB_NO%TYPE;			-- 전표부번호
    T_GGA06M01_RECV_SLIP_DT			VN.GGA06M01.RECV_SLIP_DT%TYPE;			-- 수신전표일자
    T_GGA06M01_RECV_BNH_CD			VN.GGA06M01.RECV_BNH_CD%TYPE;			-- 수신부점코드
    T_GGA06M01_RECV_AGNC_BRCH		VN.GGA06M01.RECV_AGNC_BRCH%TYPE;		-- 수신대리지점
    T_GGA06M01_RECV_SLIP_NO			VN.GGA06M01.RECV_SLIP_NO%TYPE;			-- 수신전표번호
    T_GGA06M01_RECV_SLIP_SUB_NO		VN.GGA06M01.RECV_SLIP_SUB_NO%TYPE;		-- 수신전표부번호
    T_GGA06M01_RECV_ACC_RMRK_CD		VN.GGA06M01.RECV_ACC_RMRK_CD%TYPE;		-- 수신적요코드
    T_GGA06M01_RECV_ACT_CD			VN.GGA06M01.RECV_ACT_CD%TYPE;			-- 수신계정코드
    T_GGA06M01_RECV_YN				VN.GGA06M01.RECV_YN%TYPE;				-- 수신여부
    T_GGA06M01_CNCL_YN				VN.GGA06M01.CNCL_YN%TYPE;				-- 취소여부
    T_GGA06M01_WORK_MN				VN.GGA06M01.WORK_MN%TYPE;				-- 처리자
    T_GGA06M01_WORK_DTM				VN.GGA06M01.WORK_DTM%TYPE;				-- 처리일시
    T_GGA06M01_WORK_TRM				VN.GGA06M01.WORK_TRM%TYPE;				-- 처리단말


    -- Exceptions Declare
    ERR_I_DR_AMT				EXCEPTION;
    ERR_EXCH_BRCH_CD			EXCEPTION;
    ERR_GGA06M00_INS			EXCEPTION;
    ERR_GGA06M01_INS			EXCEPTION;
    ERR_GGA06M00_UPD			EXCEPTION;
    ERR_GGA06M01_UPD			EXCEPTION;
    ERR_PGG_SLIP_APPROVAL		EXCEPTION;

-- *************************< START OF PROCEDURE >****************************
BEGIN


    -- ******************
    -- * 자동 전표 생성 *
    -- ******************

    -- CHK_1. 처리면서 전표금액 = 0
    IF  I_FLAG  =   'I' AND
    	((NVL(I_DR_AMT_01, 0) + NVL(I_DR_AMT_02, 0) + NVL(I_DR_AMT_03, 0)	=	0)	OR
    	(NVL(I_CR_AMT_01, 0) + NVL(I_CR_AMT_02, 0) + NVL(I_CR_AMT_03, 0)	=	0))	THEN
        RAISE ERR_I_DR_AMT;
    END IF;


    -- CHK_2. 고정자산 이수관 체크
    IF  SUBSTR(I_ACC_RMRK_CD, 1, 3)  =   '425'	AND
    	T_PROC_BRCH_CD	=	T_EXCH_BRCH_CD		THEN
        RAISE ERR_EXCH_BRCH_CD;
    END IF;

	T_PROC_BRCH_CD		:=	I_PROC_BRCH_CD;              --처리지점
    T_PROC_AGNC_BRCH	:=	I_PROC_AGNC_BRCH;            --처리대리지점
	T_EXCH_BRCH_CD		:=	I_EXCH_BRCH_CD;              --이체지점
    T_EXCH_AGNC_BRCH	:=	I_EXCH_AGNC_BRCH;            --이체대리지점

    -- CHK_2. 전표순서 생성자료 조회
    FOR C1 IN
		(	SELECT	ROWNUM						AS	CNT,
					v11.ACC_RMRK_CD				AS	ACC_RMRK_CD,
					v11.RMRK_INOUT_TP			AS	RMRK_INOUT_TP,
					v11.OPR_ACC_RMRK_CD			AS	OPR_ACC_RMRK_CD,
					v11.OPR_BNH_CD				AS	OPR_BNH_CD,
					v11.OPR_AGNC_BRCH			AS	OPR_AGNC_BRCH
			  FROM
					(	SELECT	v21.ACC_RMRK_CD				AS	ACC_RMRK_CD,
								v22.RMRK_INOUT_TP			AS	RMRK_INOUT_TP,
								MAX(v21.OPR_ACC_RMRK_CD)	AS	OPR_ACC_RMRK_CD,
								MAX(v21.OPR_BNH_CD)			AS	OPR_BNH_CD,
								MAX(v21.OPR_AGNC_BRCH)		AS	OPR_AGNC_BRCH,
								'1'							AS	CD_SORT
						  FROM	VN.GGA03C01	v21,
								VN.GGA03C00	v22
						 WHERE	v21.ACC_RMRK_CD		=	v22.ACC_RMRK_CD
						   AND	v21.ACC_RMRK_CD		=	I_ACC_RMRK_CD
					  GROUP BY	v21.ACC_RMRK_CD,
								v22.RMRK_INOUT_TP
					UNION ALL
						SELECT	v22.ACC_RMRK_CD				AS	ACC_RMRK_CD,
								v22.RMRK_INOUT_TP			AS	RMRK_INOUT_TP,
								v22.OPR_ACC_RMRK_CD			AS	OPR_ACC_RMRK_CD,
								v22.OPR_BNH_CD				AS	OPR_BNH_CD,
								v22.OPR_AGNC_BRCH			AS	OPR_AGNC_BRCH,
								'2'							AS	CD_SORT
						  FROM
								(	SELECT	v31.ACC_RMRK_CD				AS	ACC_RMRK_CD,
											MAX(v31.OPR_ACC_RMRK_CD)	AS	OPR_ACC_RMRK_CD
									  FROM	VN.GGA03C01	v31
									 WHERE	v31.ACC_RMRK_CD		=	I_ACC_RMRK_CD
								  GROUP BY	v31.ACC_RMRK_CD
								)			v21,
								(	SELECT	v31.ACC_RMRK_CD				AS	ACC_RMRK_CD,
											v32.RMRK_INOUT_TP			AS	RMRK_INOUT_TP,
											MAX(v31.OPR_ACC_RMRK_CD)	AS	OPR_ACC_RMRK_CD,
											MAX(v31.OPR_BNH_CD)			AS	OPR_BNH_CD,
											MAX(v31.OPR_AGNC_BRCH)		AS	OPR_AGNC_BRCH
									  FROM	VN.GGA03C01	v31,
											VN.GGA03C00	v32
									 WHERE	v31.ACC_RMRK_CD	=	v32.ACC_RMRK_CD
								  GROUP BY	v31.ACC_RMRK_CD,
											v32.RMRK_INOUT_TP
								)			v22
						 WHERE	v21.OPR_ACC_RMRK_CD	=	v22.ACC_RMRK_CD
					UNION ALL
						SELECT	v22.ACC_RMRK_CD				AS	ACC_RMRK_CD,
								v22.RMRK_INOUT_TP			AS	RMRK_INOUT_TP,
								v22.OPR_ACC_RMRK_CD			AS	OPR_ACC_RMRK_CD,
								v22.OPR_BNH_CD				AS	OPR_BNH_CD,
								v22.OPR_AGNC_BRCH			AS	OPR_AGNC_BRCH,
								'3'							AS	CD_SORT
						  FROM
								(	SELECT	v32.ACC_RMRK_CD		AS	ACC_RMRK_CD,
											v32.OPR_ACC_RMRK_CD	AS	OPR_ACC_RMRK_CD
									  FROM
											(	SELECT	v41.ACC_RMRK_CD				AS	ACC_RMRK_CD,
														MAX(v41.OPR_ACC_RMRK_CD)	AS	OPR_ACC_RMRK_CD
												  FROM	VN.GGA03C01	v41
												 WHERE	v41.ACC_RMRK_CD		=	I_ACC_RMRK_CD
											  GROUP BY	v41.ACC_RMRK_CD
											)			v31,
											(	SELECT	v41.ACC_RMRK_CD				AS	ACC_RMRK_CD,
														MAX(v41.OPR_ACC_RMRK_CD)	AS	OPR_ACC_RMRK_CD
												  FROM	VN.GGA03C01	v41
											  GROUP BY	v41.ACC_RMRK_CD
											)			v32
									 WHERE	v31.OPR_ACC_RMRK_CD	=	v32.ACC_RMRK_CD
								)			v21,
								(	SELECT	v31.ACC_RMRK_CD				AS	ACC_RMRK_CD,
											v32.RMRK_INOUT_TP			AS	RMRK_INOUT_TP,
											MAX(v31.OPR_ACC_RMRK_CD)	AS	OPR_ACC_RMRK_CD,
											MAX(v31.OPR_BNH_CD)			AS	OPR_BNH_CD,
											MAX(v31.OPR_AGNC_BRCH)		AS	OPR_AGNC_BRCH
									  FROM	VN.GGA03C01	v31,
											VN.GGA03C00	v32
									 WHERE	v31.ACC_RMRK_CD	=	v32.ACC_RMRK_CD
								  GROUP BY	v31.ACC_RMRK_CD,
											v32.RMRK_INOUT_TP
								)			v22
						 WHERE	v21.OPR_ACC_RMRK_CD	=	v22.ACC_RMRK_CD
					)			v11
		  ORDER BY	v11.CD_SORT

		) LOOP

        --initialize slip no
        --T_GGA06M00_SLIP_NO	:=	'00000';

        -- CHK_3. 전표지정 실계정
		T_GGA06M00_SLIP_DT			:=	I_SLIP_DT;				-- 전표일자
		T_GGA06M00_BRCH_CD			:=	T_PROC_BRCH_CD;			-- 지점코드
		T_GGA06M00_AGNC_BRCH		:=	T_PROC_AGNC_BRCH;		-- 대리지점

		T_GGA06M00_SLIP_NO			:=	VN.FGG_GET_SLIP_NO(T_GGA06M00_BRCH_CD, T_GGA06M00_AGNC_BRCH, T_GGA06M00_SLIP_DT, C1.RMRK_INOUT_TP);  -- 전표번호

        T_GGA06M00_RMRK_JOB_TP		:=	I_RMRK_JOB_TP;			-- 적요업무구분
        T_GGA06M00_SLIP_TP			:=	C1.RMRK_INOUT_TP;		-- 적요입출구분

        T_GGA06M00_ACC_RMRK_CD		:=	C1.ACC_RMRK_CD;		-- 회계적요코드


	    -- CHK_2. 회계적요 정보자료 조회
	    FOR C11 IN
			(	SELECT	TO_CHAR(ROWNUM,'FM000')	AS	SLIP_SUB_NO,
						v11.ACC_RMRK_CD			AS	ACC_RMRK_CD,
						v11.RMRK_TRD_TP			AS	RMRK_TRD_TP,
						v11.RMRK_INOUT_TP		AS	RMRK_INOUT_TP,
						v11.ACC_RMRK_CD_NM		AS	ACC_RMRK_CD_NM,
						v12.DR_CR_TP			AS	DR_CR_TP,
						v12.ACC_ACT_CD			AS	ACC_ACT_CD,
						v12.RECV_SND_TP			AS	RECV_SND_TP,
						v12.OPR_BNH_CD			AS	OPR_BNH_CD,
						v12.OPR_AGNC_BRCH		AS	OPR_AGNC_BRCH,
						v12.OPR_ACC_RMRK_CD		AS	OPR_ACC_RMRK_CD,
						v12.ORIG_AMT_TP			AS	ORIG_AMT_TP
				  FROM	VN.GGA03C00	v11,
						VN.GGA03C01	v12
				 WHERE	v11.ACC_RMRK_CD		=	C1.ACC_RMRK_CD
				   AND	v11.ACC_RMRK_CD		=	v12.ACC_RMRK_CD
			  ORDER BY	v11.ACC_RMRK_CD,
						v12.RMRK_SN

			) LOOP

            -- CHK_3. 전표지정 실계정
			--T_GGA06M00_SLIP_DT			:=	I_SLIP_DT;				-- 전표일자
			--T_GGA06M00_BRCH_CD			:=	T_PROC_BRCH_CD;			-- 지점코드
			--T_GGA06M00_AGNC_BRCH		:=	T_PROC_AGNC_BRCH;		-- 대리지점

			--IF T_GGA06M00_SLIP_NO = '00000' THEN
			--	T_GGA06M00_SLIP_NO			:=	VN.FGG_GET_SLIP_NO(T_PROC_BRCH_CD, T_PROC_AGNC_BRCH, I_SLIP_DT, C11.RMRK_INOUT_TP);  -- 전표번호
			--END IF;
			T_GGA06M00_SLIP_SUB_NO		:=	C11.SLIP_SUB_NO;		-- 전표부번호

            --T_GGA06M00_RMRK_JOB_TP		:=	I_RMRK_JOB_TP;			-- 적요업무구분
            --T_GGA06M00_SLIP_TP			:=	C11.RMRK_INOUT_TP;		-- 적요입출구분
            --T_GGA06M00_ACC_RMRK_CD		:=	C11.ACC_RMRK_CD;		-- 회계적요코드
			T_GGA06M00_TRD_CNTE			:=	C11.ACC_RMRK_CD_NM;		-- 거래비고

			T_GGA06M00_DR_CR_TP			:=	C11.DR_CR_TP;			-- 차대구분

			T_GGA06M00_ACC_ACT_CD		:=	C11.ACC_ACT_CD;			-- 회계계정
			IF C11.ACC_ACT_CD		=	K_211_ACC_CD	THEN
				T_GGA06M00_ACC_ACT_CD	:=	I_ACC_ACT_CD;
			ELSIF C11.ACC_ACT_CD	=	K_213_ACC_CD	THEN
				T_GGA06M00_ACC_ACT_CD	:=	I_ACC_ACT_CD;
			END IF;

			-- 발신전표
			IF  C11.RECV_SND_TP  =   '1' THEN

				-- 지점통칭
				IF  C11.OPR_BNH_CD  =   K_JI_BRCH THEN
					T_GGA06M00_OPR_BNH_CD		:=	T_EXCH_BRCH_CD;			-- 이체지점
					T_GGA06M00_OPR_AGNC_BRCH	:=	T_EXCH_AGNC_BRCH;		-- 이체대리지점
					T_GGA06M00_CUST_CD			:=	'BR00000' ||T_GGA06M00_OPR_BNH_CD;			-- 고객코드
	    		ELSE
					T_GGA06M00_OPR_BNH_CD		:=	C11.OPR_BNH_CD;			-- 이체지점
					T_GGA06M00_OPR_AGNC_BRCH	:=	C11.OPR_AGNC_BRCH;		-- 이체대리지점
					T_GGA06M00_CUST_CD			:=	'HD00000' ||T_GGA06M00_OPR_BNH_CD;			-- 고객코드
	        	END IF;

				T_PROC_BRCH_CD		:=	T_GGA06M00_OPR_BNH_CD;				--처리지점
			    T_PROC_AGNC_BRCH	:=	T_GGA06M00_OPR_AGNC_BRCH;			--처리대리지점

			-- 수신전표
			ELSIF   C11.RECV_SND_TP  =   '2' THEN

				-- 지점통칭
				IF  C11.OPR_BNH_CD  =   K_JI_BRCH THEN
					T_GGA06M00_OPR_BNH_CD		:=	T_PROC_BRCH_CD;			-- 이체지점
					T_GGA06M00_OPR_AGNC_BRCH	:=	T_PROC_AGNC_BRCH;		-- 이체대리지점
					T_GGA06M00_CUST_CD			:=	'BR00000' ||T_GGA06M00_OPR_BNH_CD;			-- 고객코드
		    	ELSE
					T_GGA06M00_OPR_BNH_CD		:=	C11.OPR_BNH_CD;			-- 이체지점
					T_GGA06M00_OPR_AGNC_BRCH	:=	C11.OPR_AGNC_BRCH;		-- 이체대리지점
					T_GGA06M00_CUST_CD			:=	'HD00000' ||T_GGA06M00_OPR_BNH_CD;			-- 고객코드
	        	END IF;


			-- 기타전표
    		ELSE

				T_GGA06M00_OPR_BNH_CD		:=	NULL;		-- 이체지점
				T_GGA06M00_OPR_AGNC_BRCH	:=	NULL;		-- 이체대리지점

				SELECT	v11.HEAD_BRCH_TP
				  INTO	T_HEAD_BRCH_TP
				  FROM	VN.XCC90M00	v11
				 WHERE	v11.BRCH_CD		=	T_GGA06M00_BRCH_CD
				   AND	v11.AGNC_BRCH	=	T_GGA06M00_AGNC_BRCH ;

				IF	C11.ACC_ACT_CD = K_211_ACC_CD	OR	C11.ACC_ACT_CD = K_213_ACC_CD	THEN
					T_GGA06M00_CUST_CD			:=	'KD00000' || I_DEPT_CD;			-- 고객코드
				ELSE
					IF	I_CUST_CD	IS NOT NULL	THEN
						T_GGA06M00_CUST_CD			:=	I_CUST_CD;			-- 고객코드
					ELSE
						IF  T_HEAD_BRCH_TP  =   '0' THEN
							T_GGA06M00_CUST_CD			:=	'HD00000' ||T_GGA06M00_BRCH_CD;			-- 고객코드
				    	ELSE
							T_GGA06M00_CUST_CD			:=	'BR00000' ||T_GGA06M00_BRCH_CD;			-- 고객코드
			        	END IF;
		        	END IF;
	        	END IF;

        	END IF;

			-- 차변금액
			IF  C11.DR_CR_TP  =   '1' THEN
                IF	C11.ORIG_AMT_TP	=	'01'	THEN
					T_GGA06M00_SLIP_AMT			:=	NVL(I_DR_AMT_01, 0);			-- 전표금액
                ELSIF	C11.ORIG_AMT_TP	=	'02'	THEN
					T_GGA06M00_SLIP_AMT			:=	NVL(I_DR_AMT_02, 0);			-- 전표금액
                ELSIF	C11.ORIG_AMT_TP	=	'03'	THEN
					T_GGA06M00_SLIP_AMT			:=	NVL(I_DR_AMT_03, 0);			-- 전표금액
                END IF;
    		ELSE
                IF	C11.ORIG_AMT_TP	=	'01'	THEN
					T_GGA06M00_SLIP_AMT			:=	NVL(I_CR_AMT_01, 0);			-- 전표금액
                ELSIF	C11.ORIG_AMT_TP	=	'02'	THEN
					T_GGA06M00_SLIP_AMT			:=	NVL(I_CR_AMT_02, 0);			-- 전표금액
                ELSIF	C11.ORIG_AMT_TP	=	'03'	THEN
					T_GGA06M00_SLIP_AMT			:=	NVL(I_CR_AMT_03, 0);			-- 전표금액
                END IF;
        	END IF;

			T_GGA06M00_DETL_CNTE		:=	NULL;					-- 상세비고
			T_GGA06M00_RECV_SND_TP		:=	C11.RECV_SND_TP;		-- 수신발신구분
			T_GGA06M00_RECV_YN			:=	NULL;					-- 수신여부
			T_GGA06M00_AUTO_TP			:=	'1';					-- 자동구분(1:자동전표,2:수기전표)
			T_GGA06M00_SLIP_STAT		:=	'1';					-- 전표상태(1:미승인,2:승인,3:반려,4:취소)
			T_GGA06M00_DRAF_MN			:=	I_WORK_MN;				-- 기안자
			T_GGA06M00_DRAF_DTM			:=	SYSDATE;				-- 기안일시
			T_GGA06M00_CNFM_MN			:=	NULL;					-- 승인자
			T_GGA06M00_CNFM_DTM			:=	NULL;					-- 승인일시
			T_GGA06M00_SUP_PRI_AMT		:=	NULL;					-- 공급가액
			T_GGA06M00_VAT_AMT			:=	NULL;					-- 부가세액
			T_GGA06M00_EVI_TP			:=	NULL;					-- 증빙구분
			T_GGA06M00_EVI_DT			:=	NULL;					-- 증빙일자
			T_GGA06M00_EVI_NO			:=	NULL;					-- 증빙번호
			T_GGA06M00_TAXB_NO			:=	NULL;					-- 세무번호
			T_GGA06M00_ORIG_ACNT_NO		:=	NULL;					-- 원천계좌번호
			T_GGA06M00_ORIG_TRD_DT		:=	NULL;					-- 원천거래일
			T_GGA06M00_ORIG_TRD_SEQ_NO	:=	NULL;					-- 원천거래일련번호
			T_GGA06M00_RECV_SND_NO		:=	NULL;					-- 수신발신번호
			T_GGA06M00_WORK_MN			:=	I_WORK_MN;				-- 처리자
			T_GGA06M00_WORK_DTM			:=	SYSDATE;				-- 처리일시
			T_GGA06M00_WORK_TRM			:=	I_WORK_TRM;				-- 처리단말


	        -- CHK_4. 회계전표 Insert
			BEGIN

	            INSERT
	              INTO  VN.GGA06M00(
						SLIP_DT,                --전표일자
						BRCH_CD,                --지점코드
						AGNC_BRCH,              --대리지점
						SLIP_NO,                --전표번호
						SLIP_SUB_NO,            --전표부번호
						RMRK_JOB_TP,            --적요업무구분
						SLIP_TP,                --전표구분
						ACC_RMRK_CD,            --회계적요코드
						TRD_CNTE,               --거래비고
						DR_CR_TP,               --차변대변구분
						ACC_ACT_CD,             --회계계정코드
						OPR_BNH_CD,             --상대부점코드
						OPR_AGNC_BRCH,          --상대대리지점
						SLIP_AMT,               --전표금액
						DETL_CNTE,              --상세비고
						RECV_SND_TP,            --수신발신구분
						RECV_YN,                --수신여부
						AUTO_TP,                --자동구분
						SLIP_STAT,              --전표상태
						DRAF_MN,                --기안자
						DRAF_DTM,               --기안일시
						CNFM_MN,                --승인자
						CNFM_DTM,               --승인일시
						CUST_CD,                --거래처코드
						SUP_PRI_AMT,            --공급가액
						VAT_AMT,                --부가세액
						EVI_TP,                 --증빙구분
						EVI_DT,                 --증빙일자
						EVI_NO,                 --증빙번호
						TAXB_NO,                --세무번호
						ORIG_ACNT_NO,           --원천계좌번호
						ORIG_TRD_DT,            --원천거래일
						ORIG_TRD_SEQ_NO,        --원천거래일련번호
						RECV_SND_NO,            --수신발신번호
						WORK_MN,                --처리자
						WORK_DTM,               --처리일시
						WORK_TRM )              --처리단말
     	       VALUES  (T_GGA06M00_SLIP_DT,
						T_GGA06M00_BRCH_CD,
						T_GGA06M00_AGNC_BRCH,
						T_GGA06M00_SLIP_NO,
						T_GGA06M00_SLIP_SUB_NO,
						T_GGA06M00_RMRK_JOB_TP,
						T_GGA06M00_SLIP_TP,
						T_GGA06M00_ACC_RMRK_CD,
						T_GGA06M00_TRD_CNTE,
						T_GGA06M00_DR_CR_TP,
						T_GGA06M00_ACC_ACT_CD,
						T_GGA06M00_OPR_BNH_CD,
						T_GGA06M00_OPR_AGNC_BRCH,
						T_GGA06M00_SLIP_AMT,
						T_GGA06M00_DETL_CNTE,
						T_GGA06M00_RECV_SND_TP,
						T_GGA06M00_RECV_YN,
						T_GGA06M00_AUTO_TP,
						T_GGA06M00_SLIP_STAT,
						T_GGA06M00_DRAF_MN,
						T_GGA06M00_DRAF_DTM,
						T_GGA06M00_CNFM_MN,
						T_GGA06M00_CNFM_DTM,
						T_GGA06M00_CUST_CD,
						T_GGA06M00_SUP_PRI_AMT,
						T_GGA06M00_VAT_AMT,
						T_GGA06M00_EVI_TP,
						T_GGA06M00_EVI_DT,
						T_GGA06M00_EVI_NO,
						T_GGA06M00_TAXB_NO,
						T_GGA06M00_ORIG_ACNT_NO,
						T_GGA06M00_ORIG_TRD_DT,
						T_GGA06M00_ORIG_TRD_SEQ_NO,
						T_GGA06M00_RECV_SND_NO,
						T_GGA06M00_WORK_MN,
						T_GGA06M00_WORK_DTM,
						T_GGA06M00_WORK_TRM );

		    EXCEPTION WHEN OTHERS THEN
		        RAISE ERR_GGA06M00_INS;
		    END;


			-- 발신전표
			IF  C11.RECV_SND_TP  =   '1' THEN

		        -- CHK_8. 수신발신번호발번
				T_GGA06M01_RECV_SND_NO :=	0;

				SELECT	/*+ INDEX_DESC(v11 GGA06M01_PK) */
						NVL(MAX(v11.RECV_SND_NO), 0) + 1	AS	CHG_SN
				  INTO	T_GGA06M01_RECV_SND_NO
				  FROM	VN.GGA06M01	v11 ;


	            -- CHK_3. 전표지정 실계정
				T_GGA06M01_SLIP_DT			:=	T_GGA06M00_SLIP_DT;			-- 전표일자
				T_GGA06M01_BRCH_CD			:=	T_GGA06M00_BRCH_CD;			-- 발신지점
				T_GGA06M01_AGNC_BRCH		:=	T_GGA06M00_AGNC_BRCH;		-- 발신대리지점
				T_GGA06M01_SLIP_NO			:=	T_GGA06M00_SLIP_NO;			-- 전표번호
				T_GGA06M01_SLIP_SUB_NO		:=	T_GGA06M00_SLIP_SUB_NO;		-- 전표부번호
				T_GGA06M01_RECV_SLIP_DT		:=	T_GGA06M00_SLIP_DT;			-- 수신전표일자
				T_GGA06M01_RECV_BNH_CD		:=	T_GGA06M00_OPR_BNH_CD;		-- 수신부점코드
				T_GGA06M01_RECV_AGNC_BRCH	:=	T_GGA06M00_OPR_AGNC_BRCH;	-- 수신대리지점
				T_GGA06M01_RECV_SLIP_NO		:=	NULL;						-- 수신전표번호
				T_GGA06M01_RECV_SLIP_SUB_NO	:=	NULL;						-- 수신전표부번호
				T_GGA06M01_RECV_ACC_RMRK_CD	:=	C11.OPR_ACC_RMRK_CD;		-- 수신적요코드
				T_GGA06M01_RECV_ACT_CD		:=	NULL;						-- 수신계정코드
				T_GGA06M01_RECV_YN			:=	'N';						-- 수신여부
				T_GGA06M01_CNCL_YN			:=	'N';						-- 취소여부
				T_GGA06M01_WORK_MN			:=	I_WORK_MN;				-- 처리자
				T_GGA06M01_WORK_DTM			:=	SYSDATE;				-- 처리일시
				T_GGA06M01_WORK_TRM			:=	I_WORK_TRM;				-- 처리단말


		        -- CHK_4. 회계수신발신전표 Insert
				BEGIN

		            INSERT
		              INTO  VN.GGA06M01(
							RECV_SND_NO,			-- 수신발신번호
							SLIP_DT,				-- 전표일자
							BRCH_CD,				-- 지점코드
							AGNC_BRCH,				-- 대리지점
							SLIP_NO,				-- 전표번호
							SLIP_SUB_NO,			-- 전표부번호
							RECV_SLIP_DT,			-- 수신전표일자
							RECV_BNH_CD,			-- 수신지점코드
							RECV_AGNC_BRCH,			-- 수신대리지점
							RECV_SLIP_NO,			-- 수신전표번호
							RECV_SLIP_SUB_NO,		-- 수신전표부번호
							RECV_ACC_RMRK_CD,		-- 수신적요코드
							RECV_ACT_CD,			-- 수신계정코드
							RECV_YN,				-- 수신여부
							CNCL_YN,				-- 취소여부
							WORK_MN,				-- 처리자
							WORK_DTM,				-- 처리일시
							WORK_TRM )				-- 처리단말
	     	       VALUES  (T_GGA06M01_RECV_SND_NO,
							T_GGA06M01_SLIP_DT,
							T_GGA06M01_BRCH_CD,
							T_GGA06M01_AGNC_BRCH,
							T_GGA06M01_SLIP_NO,
							T_GGA06M01_SLIP_SUB_NO,
							T_GGA06M01_RECV_SLIP_DT,
							T_GGA06M01_RECV_BNH_CD,
							T_GGA06M01_RECV_AGNC_BRCH,
							T_GGA06M01_RECV_SLIP_NO,
							T_GGA06M01_RECV_SLIP_SUB_NO,
							T_GGA06M01_RECV_ACC_RMRK_CD,
							T_GGA06M01_RECV_ACT_CD,
							T_GGA06M01_RECV_YN,
							T_GGA06M01_CNCL_YN,
							T_GGA06M01_WORK_MN,
							T_GGA06M01_WORK_DTM,
							T_GGA06M01_WORK_TRM );

			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA06M01_INS;
			    END;


		        -- CHK_4. 회계전표 Update
				SELECT	v11.RECV_BNH_CD			AS	BRCH_CD,
						v11.RECV_AGNC_BRCH		AS	AGNC_BRCH
				  INTO	T_RECV_BRCH_CD,
						T_RECV_AGNC_BRCH
				  FROM	VN.GGA06M01	v11
				 WHERE	v11.SLIP_DT		=	T_GGA06M00_SLIP_DT
				   AND	v11.BRCH_CD		=	T_GGA06M00_BRCH_CD
				   AND	v11.AGNC_BRCH	=	T_GGA06M00_AGNC_BRCH
				   AND	v11.SLIP_NO  	=	T_GGA06M00_SLIP_NO
				   AND	v11.SLIP_SUB_NO	=   T_GGA06M00_SLIP_SUB_NO ;

				BEGIN
	                UPDATE  VN.GGA06M00
	                   SET  RECV_SND_NO		=	T_GGA06M01_RECV_SND_NO,
							OPR_BNH_CD		=	T_RECV_BRCH_CD,
							OPR_AGNC_BRCH	=	T_RECV_AGNC_BRCH
					 WHERE	SLIP_DT		=	T_GGA06M00_SLIP_DT
					   AND	BRCH_CD		=	T_GGA06M00_BRCH_CD
					   AND	AGNC_BRCH	=	T_GGA06M00_AGNC_BRCH
					   AND	SLIP_NO  	=	T_GGA06M00_SLIP_NO
					   AND	SLIP_SUB_NO	=   T_GGA06M00_SLIP_SUB_NO ;

			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA06M00_UPD;
			    END;


			-- 수신전표
			ELSIF   C11.RECV_SND_TP  =   '2' THEN

		        -- CHK_4. 회계수신발신전표 Update
				BEGIN
	                UPDATE  VN.GGA06M01
	                   SET  RECV_SLIP_NO		=	T_GGA06M00_SLIP_NO,
							RECV_SLIP_SUB_NO	=	T_GGA06M00_SLIP_SUB_NO,
							RECV_ACT_CD			=	T_GGA06M00_ACC_ACT_CD,
							RECV_YN				=	'Y'
					 WHERE	RECV_SND_NO		=	T_GGA06M01_RECV_SND_NO ;

			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA06M01_UPD;
			    END;


		        -- CHK_4. 회계전표 Update
				SELECT	v11.BRCH_CD			AS	BRCH_CD,
						v11.AGNC_BRCH		AS	AGNC_BRCH
				  INTO	T_SEND_BRCH_CD,
						T_SEND_AGNC_BRCH
				  FROM	VN.GGA06M01	v11
				 WHERE	v11.RECV_SLIP_DT		=	T_GGA06M00_SLIP_DT
				   AND	v11.RECV_BNH_CD			=	T_GGA06M00_BRCH_CD
				   AND	v11.RECV_AGNC_BRCH		=	T_GGA06M00_AGNC_BRCH
				   AND	v11.RECV_SLIP_NO  		=	T_GGA06M00_SLIP_NO
				   AND	v11.RECV_SLIP_SUB_NO	=   T_GGA06M00_SLIP_SUB_NO ;

				-- 지점통칭
				IF  C11.OPR_BNH_CD  =   K_JI_BRCH THEN
					T_SEND_CUST_CD	:=	'BR00000' ||T_SEND_BRCH_CD;
		    	ELSE
					T_SEND_CUST_CD	:=	'HD00000' ||T_SEND_BRCH_CD;
	        	END IF;

				BEGIN
	                UPDATE  VN.GGA06M00
	                   SET  OPR_BNH_CD		=	T_SEND_BRCH_CD,
							OPR_AGNC_BRCH	=	T_SEND_AGNC_BRCH
					 WHERE	SLIP_DT		=	T_GGA06M00_SLIP_DT
					   AND	BRCH_CD		=	T_GGA06M00_BRCH_CD
					   AND	AGNC_BRCH	=	T_GGA06M00_AGNC_BRCH
					   AND	SLIP_NO  	=	T_GGA06M00_SLIP_NO
					   AND	SLIP_SUB_NO	=   T_GGA06M00_SLIP_SUB_NO ;

			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA06M00_UPD;
			    END;

			-- 기타전표
    		--ELSE

				--NULL;

        	END IF;


		END LOOP;   -- C11 End Loop

        -- CHK_5. 전표승인처리
		BEGIN

			VN.PGG_SLIP_APPROVAL(
				'A',						-- 'A' : Approval, 'C' : Approval Cancel, 'R' :Return, 'X' : DisUse
				T_GGA06M00_BRCH_CD,			-- 처리지점
				T_GGA06M00_AGNC_BRCH,		-- 처리대리지점
				T_GGA06M00_SLIP_DT,			-- 전표일자
				T_GGA06M00_SLIP_NO,			-- 전표번호
				I_WORK_MN) ;				-- 처리자

	    EXCEPTION WHEN OTHERS THEN
			RAISE ERR_PGG_SLIP_APPROVAL;
	    END;


		--IF	C1.CNT	=	1	THEN
		IF	I_PROC_BRCH_CD	=	T_GGA06M00_BRCH_CD	THEN
			O_SLIP_NO		:=	T_GGA06M00_SLIP_NO;
			O_SLIP_SUB_NO	:=	'001';
		ELSIF   I_EXCH_BRCH_CD  =   T_GGA06M00_BRCH_CD THEN
			O_SLIP_NO1		:=	T_GGA06M00_SLIP_NO;
			O_SLIP_SUB_NO1	:=	'001';
		END IF;


	END LOOP;   -- C1 End Loop


    O_RTN_TBL  :=  'PGG_AST_RTRN_DEPR0';
    O_RTN_ERR  :=  '0';
    --O_RTN_MSG  :=  '[V0602] 정상적으로 처리되었습니다.';
    O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','0602');
    --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);

EXCEPTION
    WHEN    ERR_I_DR_AMT  THEN
        O_RTN_TBL  :=  'ERR_I_DR_AMT';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2016]자료가 존재하지 않습니다';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016');
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_EXCH_BRCH_CD  THEN
        O_RTN_TBL  :=  'ERR_EXCH_BRCH_CD';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2016]자료가 존재하지 않습니다';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016');
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA06M00_INS  THEN
        O_RTN_TBL  :=  'ERR_GGA06M00_INS';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2627]전표번호 생성중 오류가 발생하였습니다. [' || T_PROC_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2627') || ' [' || T_PROC_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA06M01_INS  THEN
        O_RTN_TBL  :=  'ERR_GGA06M01_INS';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2627]전표번호 생성중 오류가 발생하였습니다. [' || T_PROC_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2627') || ' [' || T_PROC_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA06M00_UPD  THEN
        O_RTN_TBL  :=  'ERR_GGA06M00_UPD';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2627]전표번호 생성중 오류가 발생하였습니다. [' || T_PROC_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2627') || ' [' || T_PROC_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA06M01_UPD  THEN
        O_RTN_TBL  :=  'ERR_GGA06M01_UPD';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2627]전표번호 생성중 오류가 발생하였습니다. [' || T_PROC_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2627') || ' [' || T_PROC_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_PGG_SLIP_APPROVAL  THEN
        O_RTN_TBL  :=  'ERR_PGG_SLIP_APPROVAL';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2016]자료가 존재하지 않습니다';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016');
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    OTHERS  THEN
        O_RTN_TBL  :=  'OTHERS';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        O_RTN_MSG  :=  'ERROR ' || SUBSTR(SQLERRM, 1, 100);
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
END PGG_MANUAL_VOUCHER;
/

