create function    fdl_get_auto_out_yn
(
    i_acnt_no		in		varchar2,
    i_sub_no        in      varchar2,
	i_prd_no		in      varchar2
)
    return  VARCHAR2
as
	o_auto_out_yn			VARCHAR2(1);

begin

/*============================================================================*/
/* Valiabl Initialize                                                         */
/*============================================================================*/
    o_auto_out_yn  :=  vn.fdl_get_prd_acnt_rt(i_acnt_no,i_sub_no,i_prd_no,'16',vn.vwdate()); 

	return o_auto_out_yn;

end fdl_get_auto_out_yn;
/

