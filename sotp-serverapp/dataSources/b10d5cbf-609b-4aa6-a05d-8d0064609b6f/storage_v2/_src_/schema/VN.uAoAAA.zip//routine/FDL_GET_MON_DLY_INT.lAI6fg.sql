create function    fdl_get_mon_dly_int
(
    i_lnd_tp       in   varchar2,        --
    i_acnt_no      in   varchar2,        --
    i_sub_no       in   varchar2,        --
    i_lnd_bank_cd  in   varchar2,        --
    i_lnd_dt       in   varchar2,        --
    i_lst_rpy_dt   in   varchar2,        --
    i_expr_dt      in   varchar2,        --
    i_lnd_rpy_dt   in   varchar2,        --
    i_rpy_amt      in   number           --
)
    return  number
as

    t_lst_rpy_dt            VARCHAR2(8) := null;

    t_lnd_int_cal_std_term	NUMBER := 0;
	t_lnd_int_min_term    	NUMBER := 0;
	t_lnd_int_rt            NUMBER := 0; -- 01:lnd_int ratio
	t_lnd_int_rt_min        NUMBER := 0; -- 02:lnd_int ratio for min duration
	t_lnd_int_amt_min       NUMBER := 0; -- 03:min lnd_int amt
	t_lnd_int_rt_dly        NUMBER := 0; -- 04:lnd_int dly_rt
	t_lnd_fee_rt            NUMBER := 0; -- 11:lnd_fee ratio
	t_lnd_fee_rt_min        NUMBER := 0; -- 12:lnd_fee ratio for min duration
	t_lnd_fee_amt_min       NUMBER := 0; -- 13:min lnd_fee amt
	t_lnd_fee_rt_dly        NUMBER := 0; -- 14:min lnd_fee amt

    t_tot_prd               NUMBER := 0;
    t_lnd_prd               NUMBER := 0;
    t_dly_prd               NUMBER := 0;
    t_lnd_int               NUMBER := 0;
    t_dly_int               NUMBER := 0;

	o_lnd_int               NUMBER;
	o_dly_int               NUMBER;
    t_err_txt               VARCHAR2(80)  ; -- error text buffer

begin
/*
select vn.fdl_get_mon_dly_int('055C000001','0001','20080202','20080201','20080501','20080215',10000000) from dual;
*/

/*============================================================================*/
/* Get apply loan Valiabl                                                     */
/*============================================================================*/
	if i_lnd_tp <> '70' then
		BEGIN
			vn.pdl_get_lnd_apy_val(
			    i_lnd_tp			    ,
			    i_acnt_no    			,
			    i_sub_no    			,
			    i_lnd_bank_cd			,
			    i_lnd_dt				,
			    '1'						,
			    '1'						,
				t_lnd_int_cal_std_term	,
				t_lnd_int_min_term    	,
			    t_lnd_int_rt            ,  -- 01:lnd_int ratio
			    t_lnd_int_rt_min        ,  -- 02:lnd_int ratio for min duration
			    t_lnd_int_amt_min       ,  -- 03:min lnd_int amt
		        t_lnd_int_rt_dly        ,  -- 04:lnd_int dly_rt
			    t_lnd_fee_rt            ,  -- 11:lnd_fee ratio
			    t_lnd_fee_rt_min        ,  -- 12:lnd_fee ratio for min duration
			    t_lnd_fee_amt_min       ,  -- 13:min lnd_fee amt
			    t_lnd_fee_rt_dly        ); -- 14:min lnd_fee amt
		EXCEPTION
	    WHEN others then
	        raise_application_error(-20100,'ERROR1');
	    END;
	else
		t_lnd_int_cal_std_term	:=  1;
		t_lnd_int_min_term		:=  0;
	    t_lnd_int_rt			:=  0;
	    t_lnd_int_rt_min		:=  0;  -- 02:lnd_int ratio for min duration
	    t_lnd_int_amt_min		:=  0;  -- 03:min lnd_int amt
        t_lnd_int_rt_dly		:=  0;

	    t_lnd_fee_rt			:=  0;  -- 11:lnd_fee ratio
	    t_lnd_fee_rt_min		:=  0;  -- 12:lnd_fee ratio for min duration
	    t_lnd_fee_amt_min		:=  0;  -- 13:min lnd_fee amt
	    t_lnd_fee_rt_dly		:=  0;  -- 14:lnd_cmsn dly_rt
	end if;

/*============================================================================*/
/* Calculate period                                                           */
/*============================================================================*/

	t_tot_prd	   :=  to_date(i_lnd_rpy_dt,'yyyymmdd') - to_date(i_lnd_dt,'yyyymmdd');
	t_tot_prd 	   :=  GREATEST(t_tot_prd, 1);
	t_lst_rpy_dt   :=  greatest(i_lnd_dt, i_lst_rpy_dt);

    if i_expr_dt > i_lnd_rpy_dt then
       t_lnd_prd  :=  to_date(i_lnd_rpy_dt,'yyyymmdd') - to_date(t_lst_rpy_dt,'yyyymmdd') + 1;
       t_dly_prd  :=  0;
    else
       if i_expr_dt > t_lst_rpy_dt then
          -- last repay date ~ expire date
          t_lnd_prd  :=  to_date(i_expr_dt   ,'yyyymmdd') - to_date(t_lst_rpy_dt,'yyyymmdd') + 1;
          -- expire date ~ repay date
          t_dly_prd  :=  to_date(i_lnd_rpy_dt,'yyyymmdd') - to_date(i_expr_dt   ,'yyyymmdd');
       else
          -- last repay date ~ repay date
          t_dly_prd  :=  to_date(i_lnd_rpy_dt,'yyyymmdd') - to_date(t_lst_rpy_dt,'yyyymmdd') + 1;
       end if;
    end if;


	if t_lnd_prd > 0 then
		if t_tot_prd < t_lnd_int_min_term then
		   t_lnd_int := i_rpy_amt * t_lnd_int_rt_min;
		else
		   t_lnd_int := i_rpy_amt * t_lnd_int_rt * t_lnd_prd / t_lnd_int_cal_std_term;
		end if;
	end if;


	if t_dly_prd > 0 then
	   t_dly_int := i_rpy_amt * t_lnd_int_rt * t_dly_prd / t_lnd_int_cal_std_term * t_lnd_int_rt_dly;
	end if;

    o_lnd_int := round(t_lnd_int);
    o_dly_int := round(t_dly_int);

    return o_dly_int;

end fdl_get_mon_dly_int;
/

