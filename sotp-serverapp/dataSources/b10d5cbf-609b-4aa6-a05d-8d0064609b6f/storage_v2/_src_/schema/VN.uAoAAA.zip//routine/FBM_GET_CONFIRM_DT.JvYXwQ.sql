create function fbm_get_confirm_dt(
    i_proc_dt   varchar2
)
return varchar2

as
    t_proc_nm                   varchar2(30)    := 'fbm_get_confirm_dt';
    t_vwdate                    varchar2(8)     := vwdate;
    t_err_msg                   varchar2(500)   := ' ';

    t_confirm_dt                varchar2(10);
    t_ord_confirm_dt            varchar2(10);
    --t_ord_confirm_dt            varchar2(10);
    t_next_cls_dt               varchar2(10);
    t_ord_confirm_user_ins      varchar2(10);

    t_ord_confirm_tp            varchar2(1);

    o_ret                       varchar2(10)    := vwdate;
begin

    select col_cd_tp
    into t_ord_confirm_dt
    from xcc01c02
    where col_cd = 'ord_confirm';

    ---t_ord_confirm_tp: '1': Tu ngay dat lenh   '2': Tu ngay cuoi cung cua ky tinh hoa hong  '3': User nhap tay
    select col_cd_tp
    into t_ord_confirm_tp
    from xcc01c02
    where col_cd = 'ord_confirm_tp';

    select col_cd_tp
    into t_ord_confirm_user_ins
    from xcc01c02
    where col_cd = 'ord_confirm_user_ins';

    --Lay ra ngay cuoi cung cua ky tinh hoa hong
    select vn.fbm_get_sales_cls_dt('1', i_proc_dt)
    into t_next_cls_dt
    from dual;

    if t_ord_confirm_tp = '1' then
        t_confirm_dt := fxc_vorderdt_g(to_date(t_vwdate, 'yyyymmdd'), - t_ord_confirm_dt);
    elsif t_ord_confirm_tp = '2' then
        t_confirm_dt := fxc_vorderdt_g(to_date(t_next_cls_dt, 'yyyymmdd'), + t_ord_confirm_dt);
    elsif t_ord_confirm_tp = '3' then
        t_confirm_dt := fxc_vorderdt_g(to_date(t_ord_confirm_user_ins, 'yyyymmdd'), + t_ord_confirm_dt);
    end if;

    return t_confirm_dt;

end fbm_get_confirm_dt;
/

