create PROCEDURE PGG_JOB_RECV_SND_SLIP
/********************
    CREATE RECEIVE VOUCHER (FOR SEND LIST) : 수신전표 생성(자동발신전표에 대한... 또는 수동적요를 사용한 수기전표 수신전표 생성에도 사용함)
********************/
(   I_SLIP_DT                   IN  VARCHAR2        --  VOUCHER DATE
   ,I_BRCH_CD                   IN  VARCHAR2        --  SENDER
   ,I_AGNC_BRCH                 IN  VARCHAR2        --  SENDER
   ,I_SLIP_NO                   IN  VARCHAR2        --  VOUCHER NO (SENDING VOUCHER NO)
   ,I_BANK_CD                   IN  VARCHAR2  		--은행코드 2008-05-27
   ,IO_RECURSIVE_PROC_CNT       IN  OUT NUMBER          --재귀호출 COUNTER
   ,O_PROC_CNT  OUT NUMBER          -- PROC NUMBER
)IS

    T_COUNT NUMBER;
    T_RMRK_TRD_TB   VARCHAR2(3);

    T_EXCH_BRCH_CD    VARCHAR2(3);       --대체지점코드(적요업무구분이 10 인경우만)
    T_EXCH_AGNC_BRCH  VARCHAR2(2);       --대체대리지점(적요업무구분이 10 인경우만)

    T_SLIP_NO       GGA06M00.SLIP_NO%TYPE;
    T_PROC_CNT      NUMBER;


    T_GGA06M00_ROWID    ROWID;
    T_ACC_RMRK_CD   GGA06M00.ACC_RMRK_CD%TYPE;
    T_SLIP_SUB_NO   GGA06M00.SLIP_SUB_NO%TYPE;
    T_ACC_ACT_CD    GGA06M00.ACC_ACT_CD%TYPE;
    T_CUST_CD       GGA06M00.CUST_CD%TYPE;
    T_HEAD_BRCH_TP      XCC90M00.HEAD_BRCH_TP%TYPE; --지점의 본사/지점 구분

/* 20080825-002 START -------------------------- */
/* 20080825-002 SeoHaeSeok 추가 : 이체 출금계좌 가져오기 */

    T_ORIG_ACNT_NO        GGA06M00.ORIG_ACNT_NO%TYPE;         --원천계좌번호
    T_ORIG_TRD_DT         GGA06M00.ORIG_TRD_DT%TYPE;          --원천거래일
    T_ORIG_TRD_SEQ_NO     GGA06M00.ORIG_TRD_SEQ_NO%TYPE;      --원천거래일련번호

    T_CNT           NUMBER := 0;

/* 20080825-002 END -------------------------- */


BEGIN
    -- 재귀호출 COUNTER 20보다 크면 무조건 에러(무한루프 방지)
    IF    IO_RECURSIVE_PROC_CNT  > 20    THEN
        RAISE_APPLICATION_ERROR(-20002,'TOO MANY RECURSIVE CALL OCCURED (20times)!!! Contact IT Dept!!!');
    ELSE
        IO_RECURSIVE_PROC_CNT := IO_RECURSIVE_PROC_CNT + 1;
    END IF;

--dbms_output.put_line('dt=['||i_slip_dt||'],brch_cd=['||i_brch_cd||'],agnc_brch=['||i_agnc_brch||'],slip_no=['||i_slip_no||'],recur_cnt=['||to_char(io_recursive_proc_cnt)||']');

    O_PROC_CNT := 0;

    -- =================================
    --  수발신 내역에서 발신정보 가져 옴
    -- =================================
    T_COUNT := 1;
    FOR C1  IN(
        SELECT   A.SLIP_DT
                ,A.RECV_BNH_CD      --수신지점
                ,A.RECV_AGNC_BRCH   --수신지점(출장소)
                ,A.BRCH_CD          --발신지점
                ,A.AGNC_BRCH        --발신지점(출장소)
                ,B.ORIG_ACNT_NO     --계좌번호
                ,B.ORIG_TRD_DT      --계좌거래일
                ,B.ORIG_TRD_SEQ_NO  --계좌거래번호
                ,B.RMRK_JOB_TP      --적요업무구분 (10:고객거래,20:자기매매,21:자기주식,22:자기채권,23:자기수익증권,24:자기기타,30:업무)
                ,B.SLIP_AMT         --전표금액
                ,B.ACC_RMRK_CD      --회계적요(발신전표 회계적요)
                ,B.WORK_MN          --발신전표처리자
                ,B.WORK_TRM         --발신전표처리단말
                ,C.ABNH_TP          --타점구분(10:자자,20:타자,30:자타,40:본사대체)
                ,A.RECV_ACC_RMRK_CD --수신적요코드
                ,A.RECV_SND_NO      --수발신번호
                ,a.rowid    GGA06M01_ROWID        --발신내역 rowid
                ,b.rowid    GGA06M00_ROWID        --발신전표 rowid
          FROM
                 GGA03C00    C      --적요(발신적요)
                ,GGA06M00    B      --전표(발신전표)
                ,GGA06M01    A      --수발신내역
         WHERE  A.SLIP_DT       =   I_SLIP_DT
           AND  A.BRCH_CD       =   I_BRCH_CD
           AND  A.AGNC_BRCH     =   I_AGNC_BRCH
           AND  A.SLIP_NO       =   I_SLIP_NO
           AND  B.SLIP_DT       =   A.SLIP_DT
           AND  B.BRCH_CD       =   A.BRCH_CD
           AND  B.AGNC_BRCH     =   A.AGNC_BRCH
           AND  B.SLIP_NO       =   A.SLIP_NO
           AND  B.SLIP_SUB_NO   =   A.SLIP_SUB_NO
           AND  C.ACC_RMRK_CD   =   B.ACC_RMRK_CD
           AND  NVL(A.CNCL_YN,'N') <> 'Y'

    )LOOP
            T_COUNT := T_COUNT + 1;

        	T_ORIG_ACNT_NO    := C1.ORIG_ACNT_NO;
        	T_ORIG_TRD_DT     := C1.ORIG_TRD_DT;
        	T_ORIG_TRD_SEQ_NO := C1.ORIG_TRD_SEQ_NO;

--pxc_log_write('pgg_job_recv_snd_slip','  T_COUNT =[<< ' || TO_CHAR(T_COUNT) || ' >>]');

            --수신전표 입력
            --고객거래 이고 자자가 아닌 경우만
            IF C1.RMRK_JOB_TP = '10' AND C1.ABNH_TP <> '10' THEN


/* 20080825-003 START -------------------------- */
/* 20080825-003 SeoHaeSeok 수정 : 이체 출금계좌 관리점 가져오기 */

/* ----------------------------------------------------------
                SELECT   A.ACNT_MNG_BNH
                     --   ,NVL(A.AGNC_BRCH,'00')
                          ,'00'
                  INTO   T_EXCH_BRCH_CD
                        ,T_EXCH_AGNC_BRCH
                  FROM  AAA01M00    A
                 WHERE  A.ACNT_NO = C1.ORIG_ACNT_NO;
-------------------------------------------------------------*/


				IF	C1.RECV_ACC_RMRK_CD	=	'1002540'	THEN

	                T_CNT   := 0 ;

					SELECT	COUNT(*)
					  INTO	T_CNT
					  FROM	VN.AAA01M00 v11
					 WHERE	v11.ACNT_NO	=	(	SELECT	v21.OUTAMT_ACNT_NO
												  FROM	VN.CWD10M00 v21
												 WHERE	v21.OUTAMT_RMRK_CD		=	DECODE(SUBSTR(C1.RECV_ACC_RMRK_CD,3,3), '025', '026', '028')
												   AND	v21.INAMT_ACNT_NO		=	C1.ORIG_ACNT_NO
												   AND	v21.INAMT_TRD_SEQ_NO	=	C1.ORIG_TRD_SEQ_NO );
/* 	20080912-001 : SeoHaeSeok : 계좌간이체후 바로 취소처리시 문제발생 :    AND	v21.CNCL_YN = 'N' */

					IF	T_CNT   <=  0	THEN	-- 처리일이 영업일이 아닐경우

						SELECT	v11.ACNT_MNG_BNH,		-- 계좌관리점
								'00'
						  INTO	T_EXCH_BRCH_CD,         -- 이체 출금이 될 계좌 관리점
								T_EXCH_AGNC_BRCH
						  FROM	VN.AAA01M00 v11
						 WHERE	v11.ACNT_NO	=	(	SELECT	v21.OUTAMT_ACNT_NO
													  FROM	VN.CWD10H00 v21
													 WHERE	v21.STD_DT				=	C1.SLIP_DT
													   AND	v21.OUTAMT_RMRK_CD		=	DECODE(SUBSTR(C1.RECV_ACC_RMRK_CD,3,3), '025', '026', '028')
													   AND	v21.INAMT_ACNT_NO		=	C1.ORIG_ACNT_NO
													   AND	v21.INAMT_TRD_SEQ_NO	=	C1.ORIG_TRD_SEQ_NO );
/* 	20080912-001 : SeoHaeSeok : 계좌간이체후 바로 취소처리시 문제발생 :    AND	v21.CNCL_YN = 'N' */

					ELSE		-- 처리일이 영업일 경우

						SELECT	v11.ACNT_MNG_BNH,		-- 계좌관리점
								'00'
						  INTO	T_EXCH_BRCH_CD,         -- 이체 출금이 될 계좌 관리점
								T_EXCH_AGNC_BRCH
						  FROM	VN.AAA01M00 v11
						 WHERE	v11.ACNT_NO	=	(	SELECT	v21.OUTAMT_ACNT_NO
													  FROM	VN.CWD10M00 v21
													 WHERE	v21.OUTAMT_RMRK_CD		=	DECODE(SUBSTR(C1.RECV_ACC_RMRK_CD,3,3), '025', '026', '028')
													   AND	v21.INAMT_ACNT_NO		=	C1.ORIG_ACNT_NO
													   AND	v21.INAMT_TRD_SEQ_NO	=	C1.ORIG_TRD_SEQ_NO );
/* 	20080912-001 : SeoHaeSeok : 계좌간이체후 바로 취소처리시 문제발생 :    AND	v21.CNCL_YN = 'N' */

					END IF ;

				ELSIF	C1.RECV_ACC_RMRK_CD	=	'1002620'	THEN

	                T_CNT   := 0 ;

					SELECT	COUNT(*)
					  INTO	T_CNT
					  FROM	VN.CWD10M00 v11
					 WHERE	v11.OUTAMT_RMRK_CD		=	SUBSTR(C1.RECV_ACC_RMRK_CD,3,3)
					   AND	v11.INAMT_ACNT_NO		=	C1.ORIG_ACNT_NO
					   AND	v11.INAMT_TRD_SEQ_NO	=	C1.ORIG_TRD_SEQ_NO ;
/* 	20080912-001 : SeoHaeSeok : 계좌간이체후 바로 취소처리시 문제발생 :    AND	v21.CNCL_YN = 'N' */

					IF	T_CNT   <=  0	THEN	-- 처리일이 영업일이 아닐경우

						-- 출금 계좌번호 가져오기
						SELECT	v11.OUTAMT_ACNT_NO,
								v11.OUTAMT_TRD_SEQ_NO
						  INTO	T_ORIG_ACNT_NO,
								T_ORIG_TRD_SEQ_NO
						  FROM	VN.CWD10H00 v11
						 WHERE	v11.STD_DT				=	C1.SLIP_DT
						   AND	v11.OUTAMT_RMRK_CD		=	SUBSTR(C1.RECV_ACC_RMRK_CD,3,3)
						   AND	v11.INAMT_ACNT_NO		=	C1.ORIG_ACNT_NO
						   AND	v11.INAMT_TRD_SEQ_NO	=	C1.ORIG_TRD_SEQ_NO ;
/* 	20080912-001 : SeoHaeSeok : 계좌간이체후 바로 취소처리시 문제발생 :    AND	v21.CNCL_YN = 'N' */

					ELSE		-- 처리일이 영업일 경우

						-- 출금 계좌번호 가져오기
						SELECT	v11.OUTAMT_ACNT_NO,
								v11.OUTAMT_TRD_SEQ_NO
						  INTO	T_ORIG_ACNT_NO,
								T_ORIG_TRD_SEQ_NO
						  FROM	VN.CWD10M00 v11
						 WHERE	v11.OUTAMT_RMRK_CD		=	SUBSTR(C1.RECV_ACC_RMRK_CD,3,3)
						   AND	v11.INAMT_ACNT_NO		=	C1.ORIG_ACNT_NO
						   AND	v11.INAMT_TRD_SEQ_NO	=	C1.ORIG_TRD_SEQ_NO ;
/* 	20080912-001 : SeoHaeSeok : 계좌간이체후 바로 취소처리시 문제발생 :    AND	v21.CNCL_YN = 'N' */

					END IF ;

				ELSE

	                SELECT   A.ACNT_MNG_BNH
	                     --   ,NVL(A.AGNC_BRCH,'00')
	                          ,'00'
	                  INTO   T_EXCH_BRCH_CD
	                        ,T_EXCH_AGNC_BRCH
	                  FROM  AAA01M00    A
	                 WHERE  A.ACNT_NO = C1.ORIG_ACNT_NO;

				END IF ;

/* 20080825-003 END -------------------------- */


            ELSE
                T_EXCH_BRCH_CD    := NULL;                   --대체지점코드(적요업무구분이 10 인경우만)
                T_EXCH_AGNC_BRCH  := NULL;                   --대체대리지점(적요업무구분이 10 인경우만)
            END IF;

--pxc_log_write('pgg_job_recv_snd_slip','  T_EXCH_BRCH_CD      =['|| T_EXCH_BRCH_CD    ||']');
--pxc_log_write('pgg_job_recv_snd_slip','  T_EXCH_AGNC_BRCH    =['|| T_EXCH_AGNC_BRCH  ||']');
--pxc_log_write('pgg_job_recv_snd_slip','  T_ORIG_ACNT_NO      =['|| T_ORIG_ACNT_NO  ||']');
--pxc_log_write('pgg_job_recv_snd_slip','  T_ORIG_TRD_SEQ_NO   =['|| T_ORIG_TRD_SEQ_NO  ||']');
--pxc_log_write('pgg_job_recv_snd_slip','  C1.RECV_BNH_CD         =['||  C1.RECV_BNH_CD      ||']');
--pxc_log_write('pgg_job_recv_snd_slip','  C1.RECV_AGNC_BRCH      =['||  C1.RECV_AGNC_BRCH   ||']');
--pxc_log_write('pgg_job_recv_snd_slip','  C1.ORIG_ACNT_NO        =['||  C1.ORIG_ACNT_NO     ||']');
--pxc_log_write('pgg_job_recv_snd_slip','  C1.ORIG_TRD_DT         =['||  C1.ORIG_TRD_DT      ||']');
--pxc_log_write('pgg_job_recv_snd_slip','  C1.ORIG_TRD_SEQ_NO     =['||  C1.ORIG_TRD_SEQ_NO  ||']');
--pxc_log_write('pgg_job_recv_snd_slip','  C1.BANK_CD     =['||  I_BANK_CD  ||']');

            -- CREATE VOUCHER (RECEIVEING VOUCHER)
            PGG_CREATE_VOUCHER
            (
                 C1.SLIP_DT                       --전표일자
                ,'I'                                   --전표처리구분(I:입력전표, D:취소전표)
                ,C1.RECV_BNH_CD                        --처리지점코드(수신전표지점)
                ,C1.RECV_AGNC_BRCH                     --처리대리지점(수신전표대리지점)
                ,T_ORIG_ACNT_NO                        --계좌번호     C1.ORIG_ACNT_NO
                ,T_ORIG_TRD_DT                         --거래일       C1.ORIG_TRD_DT
                ,T_ORIG_TRD_SEQ_NO                     --거래일련번호 C1.ORIG_TRD_SEQ_NO
                ,NULL                                  --원천거래일련번호(취소거래인경우 원거래번호)
                ,C1.RMRK_JOB_TP                        --적요업무구분
                ,C1.RECV_ACC_RMRK_CD                   --회계적요코드(수신적요코드로 입력)
                ,T_EXCH_BRCH_CD                        --대체지점코드(계좌관리점;적요업무구분이 10 인경우만)
                ,T_EXCH_AGNC_BRCH                      --대체대리지점(계좌관리점;적요업무구분이 10 인경우만)
                ,C1.SLIP_AMT                           --차변금액01
                ,0                                     --차변금액02
                ,0                                     --차변금액03
                ,0                                     --차변금액04
                ,0                                     --차변금액05
                ,0                                     --차변금액06
                ,0                                     --차변금액07
                ,0                                     --차변금액08
                ,0                                     --차변금액09
                ,0                                     --차변금액10
                ,C1.SLIP_AMT                           --대변금액01
                ,0                                     --대변금액02
                ,0                                     --대변금액03
                ,0                                     --대변금액04
                ,0                                     --대변금액05
                ,0                                     --대변금액06
                ,0                                     --대변금액07
                ,0                                     --대변금액08
                ,0                                     --대변금액09
                ,0                                     --대변금액10
                , 'N'                                  --직접회계계정지정여부 2008-01-25 ( D;차변지정, C:대변지정, M:차/대 지정, N or null:지정안함)
                , NULL                            --차변회계계정01  2008-01-25
                , NULL                             --차변회계계정02  2008-01-25
                , NULL                             --차변회계계정03  2008-01-25
                , NULL                             --대변회계계정01  2008-01-25
                , NULL                             --대변회계계정02  2008-01-25
                , NULL                             --대변회계계정03  2008-01-25
                ,I_BANK_CD                            --은행코드 2008-05-27
                ,'SYSTEM'                              --작업자
                ,SYSDATE                               --작업일시
                ,'SYSTEM'                              --작업단말
                ,T_SLIP_NO                             --전표번호 (OUT)
                ,T_PROC_CNT                            -- PROC NUMBER (OUT)
                );


            --수신전표 정보 가져오기
            SELECT   ROWID
                    ,A.ACC_RMRK_CD
                    ,A.SLIP_SUB_NO
                    ,A.ACC_ACT_CD
              INTO   T_GGA06M00_ROWID
                    ,T_ACC_RMRK_CD
                    ,T_SLIP_SUB_NO
                    ,T_ACC_ACT_CD
              FROM  GGA06M00 A
             WHERE  A.SLIP_DT       = I_SLIP_DT
               AND  A.BRCH_CD       = C1.RECV_BNH_CD        --처리지점코드(수신전표지점)
               AND  A.AGNC_BRCH     = C1.RECV_AGNC_BRCH     --처리대리지점(수신전표대리지점)
               AND  A.SLIP_NO       = T_SLIP_NO             --전표번호
               AND  A.RECV_SND_TP   = '2'                   --수발신구분(2:수신)
               AND  A.SLIP_STAT     <> '4';                 --취소되지 않은 것

            --수발신내역에 수신정보 update
          UPDATE GGA06M01
            SET  RECV_SLIP_DT     =  I_SLIP_DT               --수신전표일자
                ,RECV_SLIP_NO     =  T_SLIP_NO               --수신전표번호
                ,RECV_SLIP_SUB_NO =  T_SLIP_SUB_NO           --수신전표부번호
                ,RECV_ACT_CD      =  T_ACC_ACT_CD            --수신계정코드
                ,RECV_YN          =  'Y'                     --수신여부
            WHERE ROWID = C1.GGA06M01_ROWID;


            --수신전표의 거래처(고객코드) 지정
            SELECT  A.HEAD_BRCH_TP          --(0:본사, 1:지점, 2:출장소)
              INTO  T_HEAD_BRCH_TP
              FROM  XCC90M00 A  -- 지점정보
             WHERE  A.BRCH_CD   = C1.BRCH_CD
               AND  A.AGNC_BRCH = '00';

            --본사부서인경우
            IF T_HEAD_BRCH_TP = '0' THEN
                T_CUST_CD := 'HD00000' ||C1.BRCH_CD;   --고객코드는 자신(본사부서)
            --지점인경우
            ELSE
                T_CUST_CD := 'BR00000' ||C1.BRCH_CD;  --고객코드는 자신(지점)
            END IF;


            --수신전표에 수발신번호,고객코드 반영
             UPDATE GGA06M00
                SET RECV_SND_NO     = C1.RECV_SND_NO            --발신번호
                   ,OPR_BNH_CD      = C1.BRCH_CD                --발신지점
                   ,OPR_AGNC_BRCH   = C1.AGNC_BRCH              --발신지점(출장소)
                   ,CUST_CD         = T_CUST_CD
              WHERE ROWID = T_GGA06M00_ROWID;


            --발신전표에 수신여부 update
/* 20080825-004 START -------------------------- */
/* 20080825-004 SeoHaeSeok 수정 : 이체 출금계좌번호 저장 */

/* ----------------------------------------------------------
            UPDATE  GGA06M00
               SET  RECV_YN     = 'Y'           --수신여부
             WHERE  ROWID = C1.GGA06M00_ROWID;
-------------------------------------------------------------*/

            UPDATE  GGA06M00
               SET  RECV_YN     	= 	'Y',           --수신여부
					ORIG_ACNT_NO	=	T_ORIG_ACNT_NO,
					ORIG_TRD_SEQ_NO	=	T_ORIG_TRD_SEQ_NO
             WHERE  ROWID = C1.GGA06M00_ROWID;

/* 20080825-004 END -------------------------- */


            /********************
                생성된 수신전표에서 다시 생성한 수신전표 생성
            ********************/
            PGG_JOB_RECV_SND_SLIP
            (   C1.SLIP_DT             --  VOUCHER DATE
               ,C1.RECV_BNH_CD              --  SENDER
               ,C1.RECV_AGNC_BRCH           --  SENDER
               ,T_SLIP_NO                   --  VOUCHER NO(SENDING)
               ,I_BANK_CD                   --은행코드 2008-05-27
               ,IO_RECURSIVE_PROC_CNT       --  RECURCIVE CALL COUNTER (IN OUT)
               ,T_PROC_CNT                  -- PROC NUMBER(OUT)
            );


        O_PROC_CNT  :=  O_PROC_CNT + 1;
    END LOOP;   -- END OF C1



END PGG_JOB_RECV_SND_SLIP;
/

