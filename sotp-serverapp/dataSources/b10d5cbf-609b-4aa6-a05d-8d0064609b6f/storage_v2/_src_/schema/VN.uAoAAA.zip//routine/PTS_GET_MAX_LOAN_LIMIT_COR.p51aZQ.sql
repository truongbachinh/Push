create procedure    pts_get_max_loan_limit_cor
(
	i_firm_no		  in     varchar2,
   i_acnt_no        in     varchar2,
   i_sub_no         in     varchar2,
   i_ssr			  	  in 		number,
   i_cor				  in		number,
   t_piaa			  in		number,
   o_msg				  out		varchar2,
   o_cor_amt		  out		number
)AS

/*!
   \file     :	pts_get_max_loan_limit_cor.sql
   \Developer: Mickey
   \Date		 : 2012/08/24

   Lay ra gia tri max cua loan de CMR = COR(Ty le vay toi da cho cthuc BP)
	Tu cthuc: CMR = (TA-TL)/TA

		- Uoc tinh vay = Max(Tong gia tri dat lenh mua truoc do - DPO - PIAA, 0)
		-TA sau khi mua = TA truoc khi mua - Tong gia tri dat lenh mua + Gia tri mua moi + Uoc tinh vay moi
		-TL sau khi mua = TL truoc khi mua + Uoc tinh vay moi

		Goi TA l? Tong tai san truoc khi mua
		Goi TL la Tong no truoc khi mua
		==>(TA - X + Uoc tinh vay moi- (TL + Uoc tinh vay moi))/ (TA- X + Uoc tinh vay moi)= COR
		Tuong duong: (TA  - X - TL)/(TA - X + Uoc tinh vay moi) = COR

		-> X = TA*(1-COR) - TL - (Tong gia tri mua truoc do - DPO - PIAA - Uoc tinh vay)	* COR

	Chu y:
	-	Khi d?nh gi? tong t?i san de t?nh CMR v? tong t?i san trong c?ng thuc chan suc mua dua tr?n COR
	thi SSR = 1 doi voi nhung m? CK trong danh muc, SSR = 0 doi voi nhung m? CK ngo?i danh muc.
*/
	t_tot_asset         		NUMBER  := 0;
	t_tot_loan_amt         	NUMBER  := 0;
	t_acnt_lnd_expt_amt		NUMBER  := 0;
	t_cor_amt					NUMBER  := 0;
	t_CWA							NUMBER  := 0;
	t_msg_ta						varchar2(2000);
	t_msg_tl						varchar2(2000);
	t_buy_tot_block			NUMBER  := 0;
BEGIN
	vn.pxc_log_write('pts_get_max_loan_limit_cor', '-------Start-------');
	vn.pxc_log_write('pts_get_max_loan_limit_cor', 'ACNT = [' || i_acnt_no || '] sub_no = [' || i_sub_no || '] SSR = [' || i_ssr ||
																  '] COR = [' || to_char(i_cor) || ']');
   t_tot_asset := 0;
   t_tot_loan_amt := 0;

   --Lay ra so du tien mat co kha nang thanh toan + Tong tien mua chua thanh toan
	 select  NVL(a.td_cash_prof_amt + a.pd_cash_prof_amt  + a.ppd_cash_prof_amt + a.pppd_cash_prof_amt, 0)
		     ,  GREATEST(0,(GREATEST(b.dpo, 0)
					        -  b.dpo_block - b.outq_dpo_bk /* - b.crd_dpo */
					     	- (a.td_cdt_prof_amt  + a.pd_cdt_prof_amt
					     	 + a.ppd_cdt_prof_amt + a.pppd_cdt_prof_amt)
					        )
					     )
		  into  t_buy_tot_block
		     ,  t_CWA
		  from  vn.cwd01m00 b, vn.tso02m00 a
		 where  a.acnt_no = b.acnt_no
		   and  a.sub_no  = b.sub_no
		   and  a.bank_cd = '9999'
		   and  b.acnt_no = i_acnt_no
		   and  b.sub_no  = i_sub_no;

	BEGIN
		SELECT	t_CWA + reuse_dpo + rgt_rusea - pia_loan_nowrm - (sell_cmsn + sell_tax + sell_fee + sell_rgt_tax) - (buy_amt + buy_cmsn)
	             - vn.fdl_get_mrgn_rt_01(i_acnt_no, i_sub_no, '21', vn.vwdate())
			      + GREATEST(stk_evltv + RGT_SBST + MRTG_EVLTV + buy_wait_evltv - sell_wait_evltv,0),

				    coll_loan_nowrm + buy_loan_nowrm  + mrgn_loan_nowrm + mony_loan_nowrm
		         + coll_loan_int  + buy_loan_int    + mrgn_loan_int   + mony_loan_int,

			     'Tien mat[' || t_CWA || '] + Tien ban cho ve full[' || reuse_dpo || '] + Tien quyen cho ve[' || rgt_rusea || '] + max(Gia tri danh gia CK full[' || stk_evltv ||
			     '] + Danh gia quyen CP cho ve[' || RGT_SBST || '] + Danh gia cam co[' || MRTG_EVLTV ||
			     '] + Mua cho ve[' || buy_wait_evltv || '] - Ban cho di[' || sell_wait_evltv || '], 0) - Tien ung truoc[' ||
			     pia_loan_nowrm || '] - Fee ung truoc[' || vn.fdl_get_mrgn_rt_01(i_acnt_no, i_sub_no, '21', vn.vwdate()) ||
			     '] - Fee ban[' || sell_cmsn || '] - Thue ban[' || sell_tax ||
                 '] - Phi chuyen khoan ck[' || sell_fee || '] - Thue co tuc[' || sell_rgt_tax ||
                 '] - Tien mua[' || buy_amt || '] - fee mua[' || buy_cmsn || ']',

		       'Vay cam co[' || coll_loan_nowrm || '] + Vay bao chung[' || buy_loan_nowrm || '] + Vay margin [' || mrgn_loan_nowrm  ||']' ||
		       ' + Vay khong CP[' || mony_loan_nowrm || '] + Lai vay cam co[' || coll_loan_int || '] + Lai vay bao chung[' || buy_loan_int ||
		       ']  + Lai margin[' || mrgn_loan_int || '] + Lai vay khong CP[' || mony_loan_int || ']'
	      INTO  t_tot_asset,
	      		t_tot_loan_amt,
	      		t_msg_ta ,
	 		 		  t_msg_tl
		  FROM  VN.CWD99M00
		 WHERE  acnt_no = i_acnt_no
		   and sub_no 	 = i_sub_no;
	EXCEPTION
	WHEN OTHERS THEN
		vn.pxc_log_write('pts_get_max_loan_limit_cor', ' Select cwd99m00 error: ' || sqlerrm);
		vn.pxc_log_write('pts_get_max_loan_limit_cor', '-------End-------');
	   raise_application_error(-20100, 'error: ' || sqlerrm);
	END;

	t_acnt_lnd_expt_amt := 0;

	BEGIN
		SELECT SUM(lnd_expt_amt)
		 INTO t_acnt_lnd_expt_amt
		 FROM vn.dlm09m10
		WHERE acnt_no = i_acnt_no
		  AND sub_no  = i_sub_no
		  AND lnd_tp IN ('70', '80');
	EXCEPTION
		WHEN OTHERS THEN
		   t_acnt_lnd_expt_amt := 0;
	END;

	--Tong gia tri phat vay= Tong vay dau ngay + uoc tinh phat vay trong ngay
	t_tot_loan_amt := t_tot_loan_amt + t_acnt_lnd_expt_amt;
	--Tai san tang 1 luong = luong uoc tinh phat vay
	t_tot_asset		:= t_tot_asset  + t_acnt_lnd_expt_amt;

	t_msg_ta	:= t_msg_ta || ' + Tong uoc tinh phat vay cuoi ngay[' || t_acnt_lnd_expt_amt || ']';
	t_msg_tl	:= t_msg_tl || ' + Tong uoc tinh phat vay cuoi ngay[' || t_acnt_lnd_expt_amt || ']';
	o_msg 		:= '   Tong Tai san[' || t_tot_asset || '] = ' || t_msg_ta || '/E   Tong no[' || t_tot_loan_amt || '] = ' || t_msg_tl || '/E';

	t_cor_amt 		:= 0;
	if vn.fdl_get_mrgn_rt_01(i_acnt_no, i_sub_no, '25', vn.vwdate()) > i_cor and i_cor > 0 then
		t_cor_amt := t_tot_asset*(1 - i_cor) - t_tot_loan_amt - (t_buy_tot_block - t_piaa - t_CWA - t_acnt_lnd_expt_amt)*i_cor;
		if t_cor_amt < 0 then
			t_cor_amt := 0;
		end if;
		o_msg 	 := o_msg || '===> COR_AMT[' || t_cor_amt || '] = Max((Tong tai san[' || t_tot_asset || ']*(1- COR[' || to_char(i_cor, '0.99') || ']) - Tong no[' || t_tot_loan_amt || '] +  (Tong gia tri mua[' || t_buy_tot_block || '] - CWA[' || t_CWA  || '] - PIAA[' || t_piaa || '] - Uoc tinh vay truoc khi mua[' || t_acnt_lnd_expt_amt || ']) * COR[' || to_char(i_cor, '0.99') || ']), 0)/E';

	else
		o_msg 	 	 := o_msg || '===> COR_AMT = 0 vi CMR[' || to_char(vn.fdl_get_mrgn_rt_01(i_acnt_no, i_sub_no, '25', vn.vwdate()), '0.99') || '] <= COR[' || to_char(i_cor, '0.99') || ']';
	end if;

  if LENGTH(o_msg) >= 1000 then
    o_msg := substr(o_msg,1,999);
  end if;

	o_cor_amt		 := t_cor_amt;

	/*vn.pxc_log_write('pts_get_max_loan_limit_cor', ' t_tot_asset        : [' || to_char(t_tot_asset) || ']');
	vn.pxc_log_write('pts_get_max_loan_limit_cor', ' t_tot_loan_amt     : [' || to_char(t_tot_loan_amt) || ']');
	vn.pxc_log_write('pts_get_max_loan_limit_cor', ' t_acnt_lnd_expt_amt: [' || to_char(t_acnt_lnd_expt_amt) || ']');
	vn.pxc_log_write('pts_get_max_loan_limit_cor', ' >>>>>> t_cor_amt   : [' || to_char(t_cor_amt) || ']');*/
	/*vn.pxc_log_write('pts_get_max_loan_limit_cor', ' o_msg              : [' || o_msg || ']');*/
	vn.pxc_log_write('pts_get_max_loan_limit_cor', '-------End-------');

EXCEPTION
	WHEN OTHERS THEN
		vn.pxc_log_write('pts_get_max_loan_limit_cor', ' pts_get_max_loan_limit_cor Error: ' || sqlerrm);
		vn.pxc_log_write('pts_get_max_loan_limit_cor', '-------End-------');
		raise_application_error(-20100, 'error: ' || sqlerrm);
END pts_get_max_loan_limit_cor;
/

