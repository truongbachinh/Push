create function fdl_get_lnd_rm_amt_order
(
    i_acnt_no        in   varchar2,        --
    i_sub_no         in   varchar2
)
    return  number
as
	o_lnd_rm_amt		number  := 0;


	t_rm_brch_amt		number  := 0;
	t_rm_acnt_amt		number  := 0;
	t_prof_max_amt		number	:= 0;
	t_lnd_use_amt       number  := 0;

	t_prof_levl         VARCHAR2(2)  := NULL;
	t_mng_brch_cd		varchar2(3)  := NULL;
	t_vwdate            varchar2(8)  := NULL;
    t_err_txt			varchar2(80) := NULL; -- error text buffer
    t_err_msg           VARCHAR2(500):= NULL;

begin
    t_vwdate := vn.vwdate;


	/*====================================================================*/
    /* Check branch limit amount                                          */
    /*====================================================================*/
    -- '0':acnt_mng_bnh,'1':acnt_open_bnh,'2':acnt_cls_bnh,'3':agnc_brch
    t_mng_brch_cd := vn.faa_acnt_bnh_cd_g('0', i_acnt_no, i_sub_no);

	begin
	    select  lnd_max_amt - nvl(lnd_use_amt, 0)
	      into  t_rm_brch_amt
	      from  vn.dlm09m00
	     where  brch_cd     = t_mng_brch_cd
	       and  lnd_tp      = '50'
	    ;

	exception
	when others then --
	    t_err_msg := vn.fxc_get_err_msg('V','9006');
	    t_err_msg := t_err_msg||' BRCH_CD = '||t_mng_brch_cd;
	    raise_application_error(-20030,t_err_msg);
	end;

    /*====================================================================*/
    /* Check account limit amount                                         */
    /*====================================================================*/
    begin
        select  nvl(prof_level,'00')
          into  t_prof_levl
          from  vn.aaa01m00
         where  acnt_no  =  i_acnt_no
           and  sub_no   =  i_sub_no
        ;
    exception
    when others then
        t_err_msg := vn.fxc_get_err_msg('V','2006');
        raise_application_error(-20012,t_err_msg||' ACNT_NO='||i_acnt_no||'-'||i_sub_no);
    end;

	/* crd_max_amt : t_prof_max_amt */
	t_prof_max_amt := vn.fds_get_prof_rt_01(t_prof_levl, '01', '5', t_vwdate);

	/* crd_use_amt :t_lnd_use_amt */
	begin
	    select nvl(lnd_use_amt, 0)
	      into t_lnd_use_amt
	      from vn.dlm09m10
	     where acnt_no   =  i_acnt_no
	       and sub_no    =  i_sub_no
	       and lnd_tp    =  '50'
	    ;
	exception
    	 when  NO_DATA_FOUND  then
			t_lnd_use_amt := 0;
		 when others then
		    t_err_msg := vn.fxc_get_err_msg('V','9006');
		    t_err_msg := t_err_msg||' Acnt_No = '||i_acnt_no||'-'||i_sub_no;
		    raise_application_error(-20030, t_err_msg);
	end;

	/* crd_rm_amt */
	t_rm_acnt_amt :=  t_prof_max_amt - t_lnd_use_amt;


	/*====================================================================*/
    /* Return smaller value of the limitation                             */
    /*====================================================================*/
	if t_rm_brch_amt - t_rm_acnt_amt < 0 then
		o_lnd_rm_amt := t_rm_brch_amt;
	else
		o_lnd_rm_amt := t_rm_acnt_amt;
	end if;

	return o_lnd_rm_amt;

end fdl_get_lnd_rm_amt_order;
/

