create procedure pds_stk_setl_proc
(
	i_setl_dt     in     varchar2,        --
	i_mth_dt      in     varchar2,        --
	i_sb_tp       in     varchar2,        --
	i_acnt_no     in     varchar2,        --
	i_sub_no      in     varchar2,        --
	i_stk_cd      in     varchar2,        --
	i_cdt_tp      in     varchar2,        --
	i_work_mn     in     varchar2,        -- user id
	i_work_trm    in     varchar2,
	o_cnt         in out number
) AS

/*!
   \file     pds_stk_setl_proc.sql
   \brief    stock settlement

   \section intro Program Information
        - Program Name              : settle stock
        - Service Name              : ds_04003_p1.pc
        - Related Client Program- Client Program ID : w_04001
        - Related Tables            : dsc01m00, ssb01m00
                                    : aaa01m00, aaa10m00
        - Dev. Date                 : 2007/11/08
        - Developer                 : Han.
        - Business Logic Desc.      : create settle data
        - Latest Modification Date  : 2007/11/08

   \section history Program Modification History
    - 1.0       2007/11/08     Han.    New.

   \section hardcoding Hard-Coding List
    - HC-1      2007/11/08     Han.    [»çÀ¯]

   \section info Additional Reference Comments
    - °áÁ¦Ã³¸®

var o_cnt number;
exec pds_stk_setl_proc('20080117','20080117','%','055C000020','%','00','Test','Test',:o_cnt);
print o_cnt;
*/

    t_setl_dt           varchar2(8) := null;

    t_qty               number      := 0;     --
    t_bil_prerm         number      := 0;     --
    t_bil_nowrm         number      := 0;     --
    t_book_amt          number      := 0;     --
    t_pre_book_amt      number      := 0;     --
    t_outble_qty        number      := 0;     --
    t_sb_pl             number      := 0;     --

    t_trd_seq_no       number       := 0;
    t_tot_seq_no       number       := 0;

    t_trd_tp            varchar2(2) := NULL;
    t_rmrk_cd           varchar2(3) := NULL;

    t_mng_brch_cd       varchar2(3) := null;
    t_agnc_brch         varchar2(2) := null;
    t_setl_tp           varchar2(1) := null;

    t_cnt               number      := 0;
    o_cnt6              number      := 0;

    ts_work_stat_min    VARCHAR2(1);
    ts_work_stat_max    VARCHAR2(1);
    t_acnt_tp    		VARCHAR2(1) := NULL;

    t_err_msg           varchar2(500);
    t_pos               varchar2(100);

begin

    o_cnt := 0;

	t_pos := 'CHK DT1';

    /*========================================================================*/
    /* Input Date CHECK                                                       */
    /*========================================================================*/
    if  vn.fxc_holi_ck(to_date(i_setl_dt,'yyyymmdd')) !=  '0' then
    	if  i_work_mn <> 'DAILY' then
	        t_err_msg := vn.fxc_get_err_msg('V','2422');
	        t_err_msg := t_err_msg||' Date1 = '||i_setl_dt;
	        raise_application_error(-20100,t_err_msg);
		else
			return;
		end if;
    end if;

    if  vn.vwdate  !=  i_setl_dt then
		t_err_msg := vn.fxc_get_err_msg('V','2422');
		raise_application_error(-20100,t_err_msg||' Date2 = '||i_setl_dt);
    end if;

    /*========================================================================*/
    /* Prededing job Check                                                    */
    /*========================================================================*/
	t_pos := 'CHK BAT';
	/*
	if  i_acnt_no = '%' and
	    vn.fxb_daily_stat_chk ('E','0','2300','2300','*') <> 'Y' then
		t_err_msg := vn.fxc_get_err_msg('V','2458');
		t_err_msg := t_err_msg||'[2300],[2300]'||i_setl_dt;
		raise_application_error(-20100,t_err_msg);
	end if;
	*/
    /*========================================================================*/
    /* Set Date                                                               */
    /*========================================================================*/
    t_setl_dt := i_setl_dt;

/*============================================================================*/
/* ( )                                                                        */
/*============================================================================*/
    for C1 in (
        select  a.setl_dt
             ,  a.mth_dt
             ,  a.acnt_no
             ,  a.sub_no
             ,  a.acnt_mng_bnh
             ,  a.agnc_brch
             ,  a.sb_tp
             ,  a.mkt_trd_tp
             ,  a.cdt_tp
             ,  a.stk_cd
             ,  a.mdm_tp
             ,  a.stk_tp
             ,  a.sb_pri
             ,  sum(nvl(a.sb_qty,0))      sb_qty
             ,  sum(nvl(a.sb_amt,0))      sb_amt
             ,  sum(nvl(a.sb_cmsn,0))     sb_cmsn
             ,  sum(nvl(a.sb_tax,0))      sb_tax
             ,  sum(nvl(a.adj_amt,0))     adj_amt
          from  vn.dsc01m00 a
         where  a.setl_dt        =  t_setl_dt
           /*and  a.mth_dt      like  i_mth_dt*/
           and  a.acnt_no     like  i_acnt_no
           and  a.sub_no      like  i_sub_no
           and  a.stk_cd      like  i_stk_cd
	       and  a.sb_tp       like  i_sb_tp
           and  a.cdt_tp      like  i_cdt_tp
           and  a.mkt_trd_tp    in  ('01','03','05','04','06')
           and  a.stk_setl_yn   in  ('N')
         group  by  a.setl_dt, a.acnt_no, a.sub_no, a.mth_dt, a.acnt_mng_bnh, a.agnc_brch
                             , a.sb_tp,   a.mkt_trd_tp,   a.cdt_tp,  a.stk_cd
                             , a.mdm_tp,  a.stk_tp, a.sb_pri
         order  by  a.setl_dt, a.acnt_no, a.sub_no, a.mth_dt, a.acnt_mng_bnh, a.agnc_brch
                             , a.sb_tp,   a.mkt_trd_tp,   a.cdt_tp,  a.stk_cd
                             , a.mdm_tp,  a.stk_tp, a.sb_pri
    ) loop
        o_cnt := o_cnt + 1;

        /*====================================================================*/
        /* Account management branch                                          */
        /*====================================================================*/
        /*
        t_mng_brch_cd := vn.faa_acnt_bnh_cd_g('0',C1.acnt_no);
        t_agnc_brch   := '00';
        */
        begin
            select  nvl(agnc_brch,'00')
                 ,  setl_tp
              into  t_agnc_brch
                 ,  t_setl_tp
              from  vn.aaa01m00
             where  acnt_no      =  C1.acnt_no
               and  sub_no		 =  C1.sub_no
            ;
        exception
        when no_data_found then
			t_err_msg := vn.fxc_get_err_msg('V','2006');
			raise_application_error(-20100,t_err_msg||' ACNT_NO='||C1.acnt_no||'-'||C1.sub_no);
        when others then
	    	t_err_msg := vn.fxc_get_err_msg('V','9002');
	    	raise_application_error(-20011,t_err_msg||' acnt_no='||C1.acnt_no||'-'||C1.sub_no);
        end;

		/*====================================================================*/
		/* Get the Trade sequence number and Total trade sequence number      */
		/*====================================================================*/
		begin
		    vn.pxc_psb_seq_cret_p(C1.acnt_no, C1.sub_no, vn.vwdate, t_trd_seq_no, t_tot_seq_no);
		exception
		when others then
		    t_err_msg := vn.fxc_get_err_msg('V','9414');
		    t_err_msg := t_err_msg||' Acnt_no= '||C1.acnt_no||'-'||C1.sub_no;
		    raise_application_error(-20100,t_err_msg);
		end;

        /*====================================================================*/
        /* stock's balance check                                              */
        /*====================================================================*/
        t_qty               := 0;                    --
        t_bil_prerm         := 0;                    -- pre balance
        t_bil_nowrm         := 0;                    -- now balance
        t_book_amt          := 0;                    --
        t_pre_book_amt      := 0;                    --

        /* 2008.10.28 CTB Account check */
        if  t_setl_tp = '1' then
            for C2 in (
                select *
                  from vn.ssb01m00
                 where acnt_no = C1.acnt_no
                   and sub_no  = C1.sub_no
                   and stk_cd  = C1.stk_cd
            ) loop

              t_qty               := C2.own_qty;
              t_bil_prerm         := C2.own_qty;
              t_book_amt          := C2.book_amt;
              t_pre_book_amt      := C2.book_amt;

            end loop;

            /*================================================================*/
            /* qty update                                                     */
            /*================================================================*/
            /* sell */
            if  C1.sb_tp = '1' then
                if  C1.sb_qty <= t_bil_prerm then

                    t_bil_nowrm  := t_bil_prerm  -  C1.sb_qty;
                else
                    t_bil_nowrm  := 0;
		    		t_err_msg := vn.fxc_get_err_msg('V','2205');
		    		raise_application_error(-20100,t_err_msg||' ACNT_NO='||C1.acnt_no||'-'||C1.sub_no
		    		                                        ||'-'||C1.sb_qty
		    		                                        ||'-'||t_bil_prerm);
                end if;
            else
                t_bil_nowrm      := t_bil_prerm  +  C1.sb_qty;
            end if;

            if  C1.sb_tp = '1' then
                if  C1.sb_qty < t_bil_prerm and t_bil_prerm > 0 then
                    t_book_amt := t_book_amt -
                                  trunc(t_book_amt * C1.sb_qty / t_bil_prerm);
                else
                    t_book_amt := 0;
                end if;

                /*  profit and loss calculate  */
                t_sb_pl := C1.sb_amt - trunc(t_pre_book_amt / t_bil_prerm * C1.sb_qty);

                /*  daily profit and loss create */
                vn.pds_dsc20m00_ins (  t_setl_dt           -- TRD_DT
                                     , C1.acnt_no          -- ACNT_NO
                                     , C1.sub_no
                                     , t_trd_seq_no        -- TRD_SEQ_NO
                                     , C1.stk_cd           -- STK_CD
                                     , C1.sb_pri           -- SB_PRI
                                     , C1.sb_qty           -- SB_QTY
                                     , C1.sb_cmsn          -- SB_CMSN
                                     , C1.sb_tax           -- SB_TAX
                                     , t_sb_pl             -- SB_PL
                                     , t_bil_prerm         -- PRERM_QTY
                                     , t_bil_nowrm         -- NOWRM_QTY
                                     , t_pre_book_amt      -- PRE_BOOK_AMT
                                     , t_book_amt          -- NOW_BOOK_AMT
                                     , 'N'                 -- CNCL_YN
                                     , i_work_mn           -- WORK_MN
                                     , i_work_trm          -- WORK_TRM
                                    );

            else
                if  t_bil_prerm < 0 then
                    if  C1.sb_qty < abs(t_bil_prerm) then
                        t_book_amt := 0;
                    else
                        t_book_amt := (C1.sb_qty - abs(t_bil_prerm)) *
                                                         C1.sb_amt / C1.sb_qty;
                    end if;
                else
                      t_book_amt := t_book_amt + C1.sb_amt;
                end if;

            end if;

            update  vn.ssb01m00
               set  own_qty   =  t_bil_nowrm
                 ,  book_amt  =  t_book_amt
             where acnt_no    =  C1.acnt_no
               and sub_no	  =  C1.sub_no
               and stk_cd     =  C1.stk_cd
            ;

            if  sql%notfound or sql%notfound is null then
                insert into vn.ssb01m00
                 (acnt_no,      sub_no, 	 stk_cd,      stk_tp,
                  own_qty,      book_amt,    bclm_qty,
                  mrtg_lnd_qty, mrtg_buy_qty,
	        	  work_mn,      work_dtm,    work_trm)
                values
                 (C1.acnt_no,   C1.sub_no, 	 C1.stk_cd,   C1.stk_tp,
                  t_bil_nowrm,  t_book_amt,  0,
                  0,            0,
	        	  i_work_mn,    sysdate,     i_work_trm);
            end if;

            /* 2009/10/30 modify */
            if  C1.sb_tp = '1' then
                if  C1.cdt_tp  =  '20'  then
                    /*
                    update  vn.ssb01m00
                       set  mrtg_lnd_qty =  case when mrtg_lnd_qty - C1.sb_qty < 0 then 0
	                                             else mrtg_lnd_qty - C1.sb_qty
                                            end
                     where  acnt_no      =  C1.acnt_no
                       and  stk_cd       =  C1.stk_cd
                    ;
                    */
                    begin
                    vn.pdl_coll_loan_mrtg( t_setl_dt,  C1.acnt_no, C1.sub_no,
                                           '%',        C1.stk_cd,
                                           i_work_mn,  i_work_trm,  t_cnt );
                    exception
                    when others then
                        t_err_msg := vn.fxc_get_err_msg('V','9401');
                        raise_application_error(-20011,t_err_msg||' ACNT_NO='||C1.acnt_no||'-'||C1.sub_no||' TP='||C1.cdt_tp);
                    end;
                end if;
            end if;

            /*    elsif C1.cdt_tp  =  '30'  then*/
            /*
            update  vn.ssb01m00
               set  mrtg_buy_qty =  case when mrtg_buy_qty - C1.sb_qty < 0 then 0
	                                     else mrtg_buy_qty - C1.sb_qty
                                    end
             where  acnt_no      =  C1.acnt_no
               and  stk_cd       =  C1.stk_cd
            ;
            */
            begin
            vn.pdl_buy_loan_mrtg(  t_setl_dt,  C1.acnt_no, C1.sub_no,
                                   '%',        C1.stk_cd,
                                   i_work_mn,  i_work_trm,  t_cnt );
            exception
            when others then
                t_err_msg := vn.fxc_get_err_msg('V','9401');
                raise_application_error(-20011,t_err_msg||' ACNT_NO='||C1.acnt_no||'-'||C1.sub_no||' TP='||C1.cdt_tp);
            end;
        end if;


        /*====================================================================*/
        /* account type (1:Security-Account  2:Bank-Account  3:Non-custodian) */
        /*====================================================================*/
        t_acnt_tp :=  vn.faa_get_acnt_tp(C1.acnt_no, C1.sub_no) ;
        /*====================================================================*/
        /* pds_aaa10m00_ins(°Å·¡³»¿ª) Create                                  */
        /*====================================================================*/
        /* 2008.10.28 CTB Account => [605,606] */
        if  t_setl_tp = '2' then
            if  C1.sb_tp = '1' then
                t_trd_tp          := '55';
                t_rmrk_cd         := '605';
            elsif C1.sb_tp = '2' THEN
                t_trd_tp          := '54';
                t_rmrk_cd         := '606';
            end if;
        else
	        if  t_acnt_tp  = '1' then
	            if  C1.sb_tp = '1' then
                    t_trd_tp      := '51';

	            	if  C1.mkt_trd_tp  in  ('01','03','05','04','06') then
	            		t_rmrk_cd := '601';
	            	else
	            		t_rmrk_cd := '603';
	            	end if;
	            elsif C1.sb_tp = '2' THEN
                    t_trd_tp      := '50';

	            	if  C1.mkt_trd_tp  in  ('01','03','05','04','06') then
	            		t_rmrk_cd := '602';
	            	else
	            		t_rmrk_cd := '604';
	            	end if;
	            end if;
	        elsif  t_acnt_tp  = '2' then
	            if  C1.sb_tp = '1' then
                    t_trd_tp      := '53';

	            	if  C1.mkt_trd_tp  in  ('01','03','05','04','06') then
	            		t_rmrk_cd := '601';
	            	else
	            		t_rmrk_cd := '603';
	            	end if;
	            elsif C1.sb_tp = '2' THEN
                    t_trd_tp      := '52';

	            	if  C1.mkt_trd_tp  in  ('01','03','05','04','06') then
	            		t_rmrk_cd := '602';
	            	else
	            		t_rmrk_cd := '604';
	            	end if;
	            end if;
	        elsif  t_acnt_tp  = '3' then
                if  C1.sb_tp = '1' then
                    t_trd_tp      := '55';
                    t_rmrk_cd     := '605';
                elsif C1.sb_tp = '2' THEN
                    t_trd_tp      := '54';
                    t_rmrk_cd     := '606';
                end if;
	        end if;
	    end if;

        vn.pds_aaa10m00_ins (  C1.acnt_no          -- ACNT_NO
        					 , C1.sub_no
                             , t_setl_dt           -- TRD_DT
                             , t_trd_seq_no        -- TRD_SEQ_NO
                             , t_trd_tp            -- TRD_TP
                             , t_rmrk_cd           -- RMRK_CD
                             , ''                  -- BANK_CD
                             , C1.mdm_tp           -- MDM_TP
                             , C1.mdm_tp           -- TRD_MDM_TP
                             , 'N'                 -- CNCL_YN
                             , 0                   -- ORG_TRD_NO
                             , C1.sb_amt           -- TRD_AMT
                             , C1.sb_cmsn          -- CMSN
                             , C1.sb_tax           -- SB_TAX
                             , C1.adj_amt          -- ADJ_AMT
                             , 0                   -- DPO_PRERM
                             , 0                   -- DPO_NOWRM
                             , C1.stk_cd           -- STK_CD
                             , vn.fss_get_stk_nm(C1.stk_cd)
                                                   -- STK_NM
                             , C1.sb_pri           -- SB_PRI
                             , C1.sb_qty           -- SB_QTY
                             , t_bil_prerm         -- BIL_PRERM_QTY
                             , t_bil_nowrm         -- BIL_NOWRM_QTY
                             , abs(t_pre_book_amt-t_book_amt)
                                                   -- BOOK_AMT
                             /*, t_pre_book_amt      -- PRE_BOOK_AMT
                               , t_aft_book_amt      -- AFT_BOOK_AMT
                               , t_sb_pl             -- SB_PL*/
                             , C1.stk_tp           -- STK_TP
                             , C1.mth_dt           -- MTH_DT
                             , C1.cdt_tp           -- LND_TP
                             , null                -- LND_DT
                             , null                -- LND_BANK_CD
                             , 0                   -- LND_AMT
                             , 0                   -- LND_RPY_AMT
                             , 0                   -- LND_INT
                             , 0                   -- LND_CMSN
                             , 0                   -- LND_INT_DLY
                             , 0                   -- LND_CMSN_DLY
                             , 'N'                 -- AGNT_YN
                             , C1.acnt_mng_bnh     -- ACNT_MNG_BNH
                             , C1.agnc_brch        -- AGNC_BRCH
                             , C1.acnt_mng_bnh     -- WORK_BNH
                             , C1.agnc_brch        -- PROC_AGNC_BRCH
                             , i_work_mn           -- WORK_MN
                             , i_work_trm          -- WORK_TRM
                             , C1.setl_dt
                             , t_tot_seq_no
                            );

        /*====================================================================*/
        /* dsc01m00(°áÁ¦¿¹Á¤³»¿ª) Update                                      */
        /*====================================================================*/
        -- TABLE UPDATE
        UPDATE  vn.dsc01m00
           set  stk_setl_yn   =  'Y'
             ,  stk_setl_dt   =  t_setl_dt
             ,  trd_seq_no    =  t_trd_seq_no
         where  setl_dt       =  C1.setl_dt
           and  mth_dt        =  C1.mth_dt
           and  acnt_no       =  C1.acnt_no
           and  sub_no		  =  C1.sub_no
           and  acnt_mng_bnh  =  C1.acnt_mng_bnh
           and  agnc_brch     =  C1.agnc_brch
           and  sb_tp         =  C1.sb_tp
           and  mkt_trd_tp    =  C1.mkt_trd_tp
           and  cdt_tp        =  C1.cdt_tp
           and  stk_cd        =  C1.stk_cd
           and  mdm_tp        =  C1.mdm_tp
           and  stk_tp        =  C1.stk_tp
           and  sb_pri        =  C1.sb_pri
        ;

        /*====================================================================*/
        /* add stock clear procedure for each accounts                        */
        /* that are processing the stock settlement                           */
        /* 20101224 by hyunjin                                                */
        /*====================================================================*/
        o_cnt6    := 0;

        begin
        vn.pds_prof_stk_clear_setl( i_setl_dt,  C1.acnt_no, C1.sub_no,
                                    '%',         '%',
                                    i_work_mn,  i_work_trm,  o_cnt6 );
        exception
        when others then
            t_err_msg := vn.fxc_get_err_msg('V','3319');
            raise_application_error(-20011,t_err_msg||' ACNT_NO='||C1.acnt_no||'-'||C1.sub_no);
        end;

    end loop;


end pds_stk_setl_proc;
/

