create procedure  pss_stk_remn_cnfm_p
(  i_acnt_no    in   varchar2,
   i_sub_no     in   varchar2,
   i_stk_cd     in   varchar2,
   i_proc_dt    in   varchar2,
   o_proc_tp    out  varchar2
 ) is

 vn_count   number;
 vn_count2  number;
 vn_count3  number;
 vn_count4  number;
 vs_stk_tp  varchar2(2);

begin

 vn.pxc_log_write('pss_stk_remn_cnfm_p', 'start');

 select   vn.fss_get_stk_tp(i_stk_cd)
 into     vs_stk_tp
 from     dual;


 select   count(*)
 into     vn_count
 from     vn.ssb01m00
 where    acnt_no  = i_acnt_no
 and      sub_no   = i_sub_no
 and      stk_cd   = i_stk_cd;

 if  vn_count > 0 then
	 o_proc_tp := '0';
 else

	 insert into vn.ssb01m00 (
	    acnt_no,
		sub_no,
	    stk_cd,
	    own_qty,
	    bclm_qty,
	    mrtg_lnd_qty,
	    work_mn,
	    work_dtm,
	    work_trm,
	    stk_tp
      ) values (
	    i_acnt_no,
		i_sub_no,
	    i_stk_cd,
	    0,
	    0,
	    0,
        'sys',
	    sysdate,
	    'sys',
        vn.fss_get_stk_tp(i_stk_cd)
	  );

     o_proc_tp := '0';

 end if;

end  pss_stk_remn_cnfm_p;
/

