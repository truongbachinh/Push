create function fbm_get_biz_prd_nm(
  i_biz_prd_cd    in  varchar2
  ) return varchar2   as

  t_biz_prd_cd   varchar2(12);

begin

 for c1 in (
     select  nvl(biz_prd_name,'!') biz_prd_name
     from    vn.rms03m00
       where   biz_prd_cd = i_biz_prd_cd
 ) loop

    return c1.biz_prd_name;

 end loop;

return '!';

end fbm_get_biz_prd_nm;
/

