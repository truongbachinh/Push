create procedure psr_rgt_asn_p_test1
 (
  i_proc_tp    in       varchar2,
  i_std_dt     in       varchar2,
  i_stk_cd     in       varchar2,
  i_rgt_tp     in       varchar2,
  i_seq_no     in       number,
  i_work_mn    in       varchar2,
  i_work_trm   in       varchar2,
  o_proc_cnt   in out   number
 ) is

 vs_stk_cd         varchar2(12);
 vs_rgt_tp         varchar2(1) ;
 vn_rgt_asn_rt     number;
 vn_rgt_asn_rt2    number;
 vn_flotq_std_pri  number;
 vn_rgt_iss_pri    number;
 vn_asn_amt        number;
 vn_inter_amt      number;
 vn_asn_qty        number;
 vn_flotq_amt      number;
 vn_seq_no         number;
 vn_cash_rate      number;
 vn_stock_rate     number;
 vn_r_t_tp         varchar2(1);
 vn_round_tp       varchar2(4);
 vn_stk_mkt_tp     varchar2(1);

 vn_tax_asn      number := 0 ;
 vn_tax_flotq    number := 0 ;
 vn_tax_int      number := 0 ;
 vn_tax_stock    number := 0 ;
 vn_od_qty     number := 0 ;
begin

  o_proc_cnt := 0 ;

 if i_proc_tp = 'I' then

     vn.pxc_log_write('psr_rgt_asn_p','stk_cd '||i_stk_cd ||' rgt_tp '|| i_rgt_tp ||' rgt_std_dt '||i_std_dt);

    for  c1  in (

       select   stk_cd,
            rgt_tp,
          rgt_asn_rt,
        rgt_asn_pay_rt,
          flotq_std_pri,
        rgt_iss_pri,
        seq_no ,
        nvl(tax_rate,0 ) cash_rate,
        nvl(tax_rate_2,0) stock_rate ,
          substr(NVL(Trim(round_tp),'t'),1,1)   r_t_tp   ,
        decode(nvl(round_tp, 't1'),'r1','0','r2','-1','r3' ,'-2' , 't1' , '0' ,'t2', '-1','-2')  round_tp,
        vn.fss_get_stk_mkt(stk_cd) stk_mkt_tp
       from     vn.srr01m00
       where    rgt_std_dt    =  i_std_dt
       and      stk_cd      like i_stk_cd
       and      rgt_tp      like i_rgt_tp
       and      seq_no      like i_seq_no
   --  and      rgt_proc_stat = '2'

    ) loop

     vs_rgt_tp        := c1.rgt_tp;
       vs_stk_cd        := c1.stk_cd;
         vn_rgt_asn_rt    := c1.rgt_asn_rt;
         vn_rgt_asn_rt2   := c1.rgt_asn_pay_rt;
     vn_flotq_std_pri := c1.flotq_std_pri;
       vn_rgt_iss_pri   := c1.rgt_iss_pri;
         vn_seq_no        := c1.seq_no;
     vn_cash_rate     := c1.cash_rate;
     vn_stock_rate    := c1.stock_rate ;
     vn_r_t_tp        := c1.r_t_tp;
     vn_round_tp      := to_number(c1.round_tp );
     vn_stk_mkt_tp    := c1.stk_mkt_tp;


    /* default is trunc   */

     if vn_r_t_tp = '0' then
      vn_r_t_tp := 't' ;
         end if ;

     if vn_rgt_asn_rt2 = 0 then
      vn_rgt_asn_rt2 := 1;
     end if;

     vn.pxc_log_write('psr_rgt_asn_p','stk_cd '||i_stk_cd ||' rgt_tp '|| i_rgt_tp ||' rgt_std_dt '||i_std_dt);
     vn.pxc_log_write('psr_rgt_asn_p','cash_rate '||vn_cash_rate||' stock_rate '||vn_stock_rate||' round or trunc '|| vn_r_t_tp || ' round_tp '||vn_round_tp);

         for  c2  in (

           select  acnt_no,
           sub_no,
                   own_qty * (vn_rgt_asn_rt / vn_rgt_asn_rt2)     asn_qty   ,
                   own_qty                                        own_qty   ,
                   nvl(vn.fss_get_fac_pri(stk_cd),0)   fac_pri         ,
                   own_qty * (vn_rgt_asn_rt / vn_rgt_asn_rt2)
                        -  trunc( own_qty * (vn_rgt_asn_rt / vn_rgt_asn_rt2) , vn_round_tp)   flotq_qty,
                   (vn_rgt_iss_pri * own_qty)   own_amt ,
                   (vn_rgt_iss_pri * (vn_rgt_asn_rt/vn_rgt_asn_rt2) * own_qty)   inter_amt ,
           vn.fsr_tax_tp_g(acnt_no, sub_no)  tax_tp,
           (select count(*) from srr02m00
            where rgt_std_dt   = t.rgt_std_dt
              and stk_cd    = t.stk_cd
              and rgt_tp    = t.rgt_tp
              and seq_no    = t.seq_no
              and acnt_no     = t.acnt_no) cnt_sub
           from    vn.srr02m00 t
           where   rgt_std_dt = i_std_dt
           and     stk_cd     = c1.stk_cd
           and     rgt_tp     = c1.rgt_tp
           and     seq_no     = c1.seq_no
          -- and     acnt_no    = '068C602221'
           order by  acnt_no, sub_no

         ) loop

            vn.pxc_log_write('psr_rgt_asn_p','acnt_no ' ||c2.acnt_no||'-'|| c2.sub_no||' asn_qty '||c2.asn_qty);

      vn_asn_qty   := 0;
      vn_od_qty   := 0;

            if vs_rgt_tp = '1' then

        if vn_r_t_tp = 't' then
                   vn_asn_qty   := trunc(c2.asn_qty , vn_round_tp);
                else
                   vn_asn_qty   := round(c2.asn_qty , vn_round_tp);
                end if ;

        if c2.cnt_sub > 1 and c2.sub_no <> '01' then
          select   vn_asn_qty - trunc(vn_asn_qty, decode(vn_stk_mkt_tp,1,-1,2,-2,3,-2,-1)),
              trunc(vn_asn_qty, decode(vn_stk_mkt_tp,1,-1,2,-2,3,-2,-1))
          into   vn_od_qty, vn_asn_qty
          from   dual;
        else
          vn_asn_qty  := vn_asn_qty;
          vn_od_qty  := 0;
        end if;

          vn_asn_amt   := 0 ;
        vn_inter_amt := 0 ;
        vn_flotq_amt := 0 ;

            elsif vs_rgt_tp = '2' then

         vn_tax_stock := 0; --c2.tax_tp * round( c2.asn_qty * (vn_stock_rate / 100 ) ) ;
         vn_tax_flotq := c2.tax_tp * round( c2.tax_tp * (c2.flotq_qty * vn_flotq_std_pri) * (vn_cash_rate / 100 ) ) ;

         vn_asn_qty  :=   c2.asn_qty                      - vn_tax_stock ;
               vn_flotq_amt :=  c2.flotq_qty * vn_flotq_std_pri - vn_tax_flotq ;

               if vn_r_t_tp = 't' then
                  vn_asn_qty   := trunc(vn_asn_qty   , vn_round_tp );
                  vn_flotq_amt := trunc(vn_flotq_amt , vn_round_tp );

               else
          vn_asn_qty   := round(vn_asn_qty   , vn_round_tp);
                  vn_flotq_amt := trunc(vn_flotq_amt , vn_round_tp);
               end if ;

         if c2.cnt_sub > 1 and c2.sub_no <> '01' then
          select   vn_asn_qty - trunc(vn_asn_qty, decode(vn_stk_mkt_tp,1,-1,2,-2,3,-2,-1)),
              trunc(vn_asn_qty, decode(vn_stk_mkt_tp,1,-1,2,-2,3,-2,-1))
          into   vn_od_qty, vn_asn_qty
          from   dual;
        else
          vn_asn_qty  := vn_asn_qty;
          vn_od_qty  := 0;
        end if;

         vn_asn_amt    := 0 ;
         vn_inter_amt  := 0 ;

           elsif vs_rgt_tp = '3' then

        vn_tax_stock  := 0; --round( c2.tax_tp * c2.asn_qty * (vn_stock_rate / 100 ) ) ;
        vn_tax_asn    := round( c2.tax_tp * c2.own_qty * (vn_rgt_iss_pri / 100 * c2.fac_pri) * (vn_cash_rate / 100 ) );
        vn_tax_flotq  := round( c2.tax_tp * (c2.flotq_qty * vn_flotq_std_pri) * (vn_cash_rate / 100 ) )  ;

                vn_asn_qty   :=  c2.asn_qty   - vn_tax_stock ;
                vn_asn_amt   :=  c2.own_qty * (vn_rgt_iss_pri / 100 * c2.fac_pri) - vn_tax_asn ;
                vn_flotq_amt :=  c2.flotq_qty * vn_flotq_std_pri - vn_tax_flotq ;

               if vn_r_t_tp = 't' then
                  vn_asn_qty   := trunc(vn_asn_qty   , vn_round_tp );
                  vn_flotq_amt := trunc(vn_flotq_amt , vn_round_tp );
                  vn_asn_amt   := trunc(vn_asn_amt   , vn_round_tp );

               else
                  vn_asn_qty   := round(vn_asn_qty   , vn_round_tp );
                  vn_flotq_amt := round(vn_flotq_amt , vn_round_tp );
                  vn_asn_amt   := round(vn_asn_amt   , vn_round_tp );

               end if ;

         if c2.cnt_sub > 1 and c2.sub_no <> '01' then
          select   vn_asn_qty - trunc(vn_asn_qty, decode(vn_stk_mkt_tp,1,-1,2,-2,3,-2,-1)),
              trunc(vn_asn_qty, decode(vn_stk_mkt_tp,1,-1,2,-2,3,-2,-1))
          into   vn_od_qty, vn_asn_qty
          from   dual;
        else
          vn_asn_qty  := vn_asn_qty;
          vn_od_qty  := 0;
        end if;

         vn_inter_amt := 0 ;

      elsif vs_rgt_tp = '4' then

        if vn_r_t_tp = 't' then
                   vn_asn_qty   := trunc(c2.asn_qty , vn_round_tp);
                else
                   vn_asn_qty   := round(c2.asn_qty , vn_round_tp);
                end if ;

        if c2.cnt_sub > 1 and c2.sub_no <> '01' then
          select   vn_asn_qty - trunc(vn_asn_qty, decode(vn_stk_mkt_tp,1,-1,2,-2,3,-2,-1)),
              trunc(vn_asn_qty, decode(vn_stk_mkt_tp,1,-1,2,-2,3,-2,-1))
          into   vn_od_qty, vn_asn_qty
          from   dual;
        else
          vn_asn_qty  := vn_asn_qty;
          vn_od_qty  := 0;
        end if;

          vn_asn_amt   := 0 ;
        vn_inter_amt := 0 ;
        vn_flotq_amt := 0 ;

      elsif vs_rgt_tp = '7' then --Trai phieu chuyen doi co phieu

        vn_tax_stock := 0; --c2.tax_tp * trunc( c2.asn_qty * (vn_stock_rate / 100 ) ) ;
        vn_tax_flotq := c2.tax_tp * trunc( c2.tax_tp * (c2.flotq_qty * vn_flotq_std_pri) * (vn_cash_rate / 100 ) ) ;

        vn_asn_qty  :=   c2.asn_qty                      - vn_tax_stock ;
        vn_flotq_amt :=  c2.flotq_qty * vn_flotq_std_pri - vn_tax_flotq ;

        if vn_r_t_tp = 't' then
          vn_asn_qty   := trunc(vn_asn_qty   , vn_round_tp );
          vn_flotq_amt := trunc(vn_flotq_amt , vn_round_tp );

        else
          vn_asn_qty   := round(vn_asn_qty   , vn_round_tp);
          vn_flotq_amt := trunc(vn_flotq_amt , vn_round_tp);
        end if ;

        if c2.cnt_sub > 1 and c2.sub_no <> '01' then
          select   vn_asn_qty - trunc(vn_asn_qty, decode(vn_stk_mkt_tp,1,-1,2,-2,3,-2,-1)),
              trunc(vn_asn_qty, decode(vn_stk_mkt_tp,1,-1,2,-2,3,-2,-1))
          into   vn_od_qty, vn_asn_qty
          from   dual;
        else
          vn_asn_qty  := vn_asn_qty;
          vn_od_qty  := 0;
        end if;

        vn_asn_amt    := 0 ;
        vn_inter_amt  := 0 ;

      elsif vs_rgt_tp = '9'  then
        vn_tax_asn  :=  round (  c2.own_amt   *  (vn_cash_rate / 100 ) ) ;
        vn_tax_int  :=  round ( c2.tax_tp * c2.inter_amt *  (vn_cash_rate / 100 ) ) ;

        if vn_r_t_tp ='t' then
           vn_asn_amt   := trunc ( c2.own_amt   - vn_tax_asn   , vn_round_tp  ) ;
                   vn_inter_amt := trunc ( c2.inter_amt - vn_tax_int   , vn_round_tp  ) ;
                else
           vn_asn_amt   := round ( c2.own_amt   - vn_tax_asn   , vn_round_tp  ) ;
                   vn_inter_amt := round ( c2.inter_amt - vn_tax_int   , vn_round_tp  ) ;
                end if ;

                vn_asn_qty   := 0 ;
          vn_flotq_amt := 0 ;

            else   -- A

         --vn_asn_qty   :=  trunc( c2.asn_qty - (c2.asn_qty * (vn_stock_rate / 100 )) );
          vn_tax_stock   := 0;
          vn_asn_qty    :=   c2.asn_qty - vn_tax_stock ;

        if vn_r_t_tp = 't' then
                   vn_asn_qty   := trunc(vn_asn_qty , vn_round_tp);
                else
                   vn_asn_qty   := round(vn_asn_qty , vn_round_tp);
                end if ;

        if c2.cnt_sub > 1 and c2.sub_no <> '01' then
          select   vn_asn_qty - trunc(vn_asn_qty, decode(vn_stk_mkt_tp,1,-1,2,-2,3,-2,-1)),
              trunc(vn_asn_qty, decode(vn_stk_mkt_tp,1,-1,2,-2,3,-2,-1))
          into   vn_od_qty, vn_asn_qty
          from   dual;
        else
          vn_asn_qty  := vn_asn_qty;
          vn_od_qty  := 0;
        end if;

        vn_asn_amt   := 0 ;
        vn_inter_amt := 0 ;
        vn_flotq_amt := 0 ;
            end if ;

             update  vn.srr02m00
             set     asn_qty      = asn_qty + vn_asn_qty,
                     flotq_amt    = vn_flotq_amt,
                     asn_amt      = vn_asn_amt ,
           inter_amt    = vn_inter_amt ,
           tax_asn      = vn_tax_asn ,
                     tax_flotq    = vn_tax_flotq ,
           tax_int      = vn_tax_int ,
           tax_stock    = vn_tax_stock
             where   rgt_std_dt   = i_std_dt
             and     stk_cd       = vs_stk_cd
             and     rgt_tp       = vs_rgt_tp
             and     seq_no       = vn_seq_no
             and     acnt_no      = c2.acnt_no
       and   sub_no     = c2.sub_no;

       if c2.cnt_sub > 1 then
        update  vn.srr02m00
         set    asn_qty      = asn_qty + vn_od_qty
         where   rgt_std_dt   = i_std_dt
         and     stk_cd       = vs_stk_cd
         and     rgt_tp       = vs_rgt_tp
         and     seq_no       = vn_seq_no
         and     acnt_no      = c2.acnt_no
         and   sub_no     = '01';
        if sql%rowcount = 0 then
          if vn_od_qty > 0 then
            insert into vn.srr02m00 (rgt_std_dt, stk_cd, rgt_tp, seq_no, acnt_no, sub_no, acnt_mng_bnh,
                         asn_qty, work_mn, work_dtm, work_trm)
            values (i_std_dt, vs_stk_cd, vs_rgt_tp, vn_seq_no, c2.acnt_no, '01', vn.faa_acnt_bnh_cd_g('0',c2.acnt_no,'00') ,
                vn_od_qty, i_work_mn, sysdate, i_work_trm);
          end if;
        end if;
       end if;

         o_proc_cnt := o_proc_cnt + 1 ;

         end loop;

         /* make rgt sbst and reuse */

    vn.psr_sbst_proc_p
      (
      'm'          -- make
      , vs_rgt_tp
      , i_std_dt
      , vs_stk_cd
      , vn_seq_no
      , '%'          -- all account
      , '%'
      , i_work_mn
      , i_work_trm
      );

    vn.pxc_log_write('psr_rgt_asn_p', o_proc_cnt);
    vn.pxc_log_write('psr_rgt_asn_p','psr_sbst_proc_p make 1 '|| sqlcode );
    vn.pxc_log_write('psr_rgt_asn_p', vs_stk_cd);
    vn.pxc_log_write('psr_rgt_asn_p', vs_rgt_tp);
    vn.pxc_log_write('psr_rgt_asn_p', vn_seq_no);

    update  vn.srr01m00
    set     rgt_proc_stat = '3'
    where   rgt_std_dt    = i_std_dt
    and     stk_cd        = vs_stk_cd
    and     rgt_tp        = vs_rgt_tp
    and     seq_no        = vn_seq_no;

   end loop;

/* chagre stock processing */

   for  c3  in (

       select   stk_cd,
            '8' rgt_tp,
          cnvt_rt,
        cnvt_pay_rt,
          flotq_std_pri,
        nvl(tax_rate,0 ) cash_rate,
        nvl(tax_rate_2,0) stock_rate ,
          substr(NVL(Trim(round_tp),'t'),1,1)   r_t_tp   ,
        decode(nvl(round_tp, 't1'),'r1','0','r2','-1','r3' ,'-2' , 't1' , '0' ,'t2', '-1','-2')  round_tp,
        vn.fss_get_stk_mkt(stk_cd) stk_mkt_tp
       from     vn.srr01m10
       where    rgt_std_dt  =  i_std_dt
       and      stk_cd      = i_stk_cd
      and      i_rgt_tp     = '8'
     and      rgt_proc_stat = '2'

    ) loop

     vs_rgt_tp        := c3.rgt_tp;
       vs_stk_cd        := c3.stk_cd;
         vn_rgt_asn_rt    := c3.cnvt_rt;
         vn_rgt_asn_rt2   := c3.cnvt_pay_rt;
     vn_flotq_std_pri := c3.flotq_std_pri;
     vn_cash_rate     := c3.cash_rate;
     vn_stock_rate    := c3.stock_rate ;
     vn_r_t_tp        := c3.r_t_tp;
     vn_round_tp      := to_number(c3.round_tp );
    vn_stk_mkt_tp    := c3.stk_mkt_tp;

    /* default is trunc   */

     if vn_r_t_tp = '0' then
      vn_r_t_tp := 't' ;
         end if ;

     if vn_rgt_asn_rt2 = 0 then
      vn_rgt_asn_rt2 := 1;
     end if;

     vn.pxc_log_write('psr_rgt_asn_p','stk_cd '||i_stk_cd ||' rgt_tp '|| i_rgt_tp ||' rgt_std_dt '||i_std_dt);
     vn.pxc_log_write('psr_rgt_asn_p','cash_rate '||vn_cash_rate||' - stock_rate '||vn_stock_rate|| ' -round or trunc '|| vn_r_t_tp || ' round_tp '||vn_round_tp);

         for  c4  in (

           select  acnt_no,
           sub_no,
                   own_qty                                        own_qty ,
                   own_qty * (vn_rgt_asn_rt / vn_rgt_asn_rt2)     asn_qty ,
                   own_qty * (vn_rgt_asn_rt / vn_rgt_asn_rt2)
                        -   own_qty * (vn_rgt_asn_rt / vn_rgt_asn_rt2)   flotq_qty ,
                   vn.fsr_tax_tp_g(acnt_no, sub_no)  tax_tp,
          (select count(*) from srr02m00
              where rgt_std_dt   = t.rgt_std_dt
                and stk_cd    = t.stk_cd
                and rgt_tp      = t.rgt_tp
                and seq_no    = t.seq_no
                and acnt_no     = t.acnt_no) cnt_sub
           from    vn.srr02m00 t
           where   rgt_std_dt = i_std_dt
           and     stk_cd     = c3.stk_cd
           and     rgt_tp     = c3.rgt_tp
           order by  acnt_no, sub_no

         ) loop

            vn.pxc_log_write('psr_rgt_asn_p','acnt_no: '||c4.acnt_no||'-'||c4.sub_no||' - asn_qty '||c4.asn_qty);

      vn_asn_qty   := 0;
      vn_od_qty   := 0;

       vn_tax_stock  := 0 ;--round ( c4.asn_qty   * (vn_stock_rate / 100 ) ) ;
       vn_tax_flotq  := round ( c4.flotq_qty * vn_flotq_std_pri * (vn_cash_rate  / 100 ) ) ;

             vn_asn_qty   :=  c4.asn_qty   - vn_tax_stock ;
             vn_flotq_amt :=  c4.flotq_qty * vn_flotq_std_pri - vn_tax_flotq ;

             if vn_r_t_tp = 't' then
                vn_asn_qty   := trunc(vn_asn_qty   , vn_round_tp );
                vn_flotq_amt := trunc(vn_flotq_amt , vn_round_tp );

             else
                vn_asn_qty   := round(vn_asn_qty   , vn_round_tp );
                vn_flotq_amt := round(vn_flotq_amt , vn_round_tp );
             end if ;

      if c4.cnt_sub > 1 and c4.sub_no <> '01' then
        select   vn_asn_qty - trunc(vn_asn_qty, decode(vn_stk_mkt_tp,1,-1,2,-2,3,-2,-1)),
            trunc(vn_asn_qty, decode(vn_stk_mkt_tp,1,-1,2,-2,3,-2,-1))
        into   vn_od_qty, vn_asn_qty
        from   dual;
      else
        vn_asn_qty  := vn_asn_qty;
        vn_od_qty  := 0;
      end if;

             update  vn.srr02m00
             set     asn_qty      = vn_asn_qty  ,
                     flotq_amt    = vn_flotq_amt,
           tax_asn      = vn_tax_asn  ,
           tax_flotq    = vn_tax_flotq
             where   rgt_std_dt   = i_std_dt
             and     stk_cd       = vs_stk_cd
             and     rgt_tp       = vs_rgt_tp
             and     acnt_no      = c4.acnt_no
       and     sub_no       = c4.sub_no;

       if c4.cnt_sub > 1 then
        update  vn.srr02m00
         set     asn_qty      = asn_qty + vn_od_qty
         where   rgt_std_dt   = i_std_dt
         and     stk_cd       = vs_stk_cd
         and     rgt_tp       = vs_rgt_tp
         and     acnt_no      = c4.acnt_no
         and   sub_no     = '01';
        if sql%rowcount = 0 then
          if vn_od_qty > 0 then
            insert into vn.srr02m00 (rgt_std_dt, stk_cd, rgt_tp, seq_no, acnt_no, sub_no, acnt_mng_bnh,
                         asn_qty, work_mn, work_dtm, work_trm)
            values (i_std_dt, vs_stk_cd, vs_rgt_tp, 0, c4.acnt_no, '01', vn.faa_acnt_bnh_cd_g('0',c4.acnt_no,'00') ,
                vn_od_qty, i_work_mn, sysdate, i_work_trm);
          end if;
        end if;
       end if;

             o_proc_cnt := o_proc_cnt + 1 ;

         end loop;

        /* make rgt sbst and reuse amt */

        vn.psr_sbst_proc_p
        (
          'm'          -- make
         , vs_rgt_tp
         , i_std_dt
         , vs_stk_cd
         , 0
         , '%'          -- all account
     , '%'          -- all sub
         , i_work_mn
         , i_work_trm
        );
        vn.pxc_log_write('psr_rgt_asn_p','psr_sbst_proc_p make 2 '|| sqlcode );

    update  vn.srr01m10
    set     rgt_proc_stat = '3'
    where   rgt_std_dt    = i_std_dt
    and     stk_cd        = vs_stk_cd
    and     rgt_proc_stat = '2';


   end loop;

  else

    for  d1  in (

       select   stk_cd,
            rgt_tp,
          rgt_asn_rt,
          flotq_std_pri,
        seq_no
       from     vn.srr01m00
       where    rgt_std_dt    =  i_std_dt
       and      stk_cd      like i_stk_cd
       and      rgt_tp      like i_rgt_tp
       and      seq_no      like i_seq_no
 --    and      rgt_proc_stat = '3'

    ) loop

         vs_rgt_tp        := d1.rgt_tp;
       vs_stk_cd        := d1.stk_cd;
       vn_seq_no        := d1.seq_no;

     /* cancel rgt sbst and reuse amt */

         vn.psr_sbst_proc_p
           (
             'c'          -- cancel
            , vs_rgt_tp
            , i_std_dt
            , vs_stk_cd
            , vn_seq_no
            , '%'          -- all account
      , '%'
            , i_work_mn
            , i_work_trm
           );

           vn.pxc_log_write('psr_rgt_asn_p','psr_sbst_proc_p cancel 1 '|| sqlcode );



     update  vn.srr02m00
     set     asn_qty      = 0,
         mrtg_asn_qty = 0,
         flotq_amt    = 0,
         asn_amt      = 0
     where   rgt_std_dt   = i_std_dt
     and     stk_cd       = vs_stk_cd
     and     rgt_tp       = vs_rgt_tp
     and     seq_no       = vn_seq_no;

     update  vn.srr01m00
     set     rgt_proc_stat  = '2'
     where   rgt_std_dt     =  i_std_dt
     and     stk_cd         =  vs_stk_cd
     and     rgt_tp         =  vs_rgt_tp
     and     seq_no         =  vn_seq_no;

     o_proc_cnt := o_proc_cnt + 1 ;

  end loop;


  for  d2  in (

       select   stk_cd ,
                '8' rgt_tp
       from     vn.srr01m10
       where    rgt_std_dt    =  i_std_dt
       and      stk_cd        =  i_stk_cd
       and      i_rgt_tp      =  '8'
       and      rgt_proc_stat = '3'

    ) loop

         vs_rgt_tp        := d2.rgt_tp;
       vs_stk_cd        := d2.stk_cd;

         /* cancel rgt sbst and reuse amt */

         vn.psr_sbst_proc_p
         (
          'c'          -- cancel
         , vs_rgt_tp
         , i_std_dt
         , vs_stk_cd
         , 0
         , '%'          -- all account
     , '%'
         , i_work_mn
         , i_work_trm
         );

         vn.pxc_log_write('psr_rgt_asn_p','psr_sbst_proc_p cancel 2 '|| sqlcode );

     update  vn.srr02m00
     set     asn_qty      = 0,
         flotq_amt    = 0
     where   rgt_std_dt   = i_std_dt
     and     stk_cd       = vs_stk_cd
     and     rgt_tp       = vs_rgt_tp;

     update  vn.srr01m10
     set     rgt_proc_stat  = '2'
     where   rgt_std_dt     =  i_std_dt
     and     stk_cd         =  vs_stk_cd ;

     o_proc_cnt := o_proc_cnt + 1 ;

  end loop;

 end if;

end  psr_rgt_asn_p_test1;
/

