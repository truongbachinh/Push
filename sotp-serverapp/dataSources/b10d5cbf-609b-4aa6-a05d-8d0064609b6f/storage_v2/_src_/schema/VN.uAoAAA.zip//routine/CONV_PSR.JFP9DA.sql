create procedure CONV_PSR
(i_acnt_no in varchar2)

 is


begin

  vn.pxc_log_write('CONV_PSR', 'Start');

 /* for c1 in (
      select acnt_no
      from vn.aaa01m00 
      where acnt_no like i_acnt_no 
        and sub_no = '01'
      
      order by acnt_no
  ) loop     */
    
   for c2 in (
        select acnt_no, rgt_std_dt, rgt_tp ,  stk_cd,  seq_no
        from vn.srr02m00 t
        where acnt_no like i_acnt_no
          and sub_no = '00'     
          and fsr_acnt_wait_rgt_conv( acnt_no ,  rgt_std_dt, rgt_tp ,  stk_cd,  seq_no ) = 'Y'  
          and (select count(*) from aaa01m00 tt
                where tt.acnt_no = t.acnt_no
                  and tt.sub_no = '01') > 0 
    ) loop     
      
        update vn.srr02m00
           set sub_no = '01' ,
               work_mn = 'CONV',
               work_dtm = sysdate,
               work_trm = 'SYSTEM'    
         where acnt_no = c2.acnt_no
           and sub_no = '00'
           and rgt_std_dt = c2.rgt_std_dt
           and rgt_tp = c2.rgt_tp
           and stk_cd = c2.stk_cd
           and seq_no = c2.seq_no;
             
        vn.pxc_log_write('CONV_PSR','srr02m00 acnt_no ' || c2.acnt_no||'-'||c2.rgt_std_dt||'-'||c2.rgt_tp||'-'||c2.stk_cd||'-'||c2.seq_no);  
          
        update vn.srr03m00
         set sub_no = '01' ,
             work_mn = 'CONV',
             work_dtm = sysdate,
             work_trm = 'SYSTEM'    
       where acnt_no = c2.acnt_no
         and sub_no  = '00'
         and rgt_std_dt = c2.rgt_std_dt
         and rgt_tp = c2.rgt_tp
         and stk_cd = c2.stk_cd
         and seq_no = c2.seq_no
         and proc_tp = 'N';
           
      vn.pxc_log_write('CONV_PSR','srr03m00 acnt_no ' || c2.acnt_no);  
    end loop;      
    
    vn.pxc_log_write('CONV_PSR', 'Finish');
  return;
end CONV_PSR;
/

