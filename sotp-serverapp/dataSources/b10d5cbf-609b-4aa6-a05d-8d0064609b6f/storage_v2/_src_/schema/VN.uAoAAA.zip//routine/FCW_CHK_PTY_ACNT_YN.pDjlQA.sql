create function fcw_chk_pty_acnt_yn
(
  i_acnt_no in varchar2,
  i_sub_no in varchar2
)
return varchar2
as
o_result varchar2(1) := 'N';
t_cnt number := 0;

begin
  select count(*) cnt
  into t_cnt
  from vn.aaa01m00
  where acnt_no = i_acnt_no
    and sub_no = i_sub_no
    and acnt_tp in ('P','E')
    and acnt_stat = '1'
    and vsd_cfm = '2';

  if t_cnt = 1 then
    o_result := 'Y';
  else
    o_result := 'N';
  end if;

  return o_result;

end fcw_chk_pty_acnt_yn;
/

