create function fcw_gst_dpo_cncl_q(
     i_acnt_no		in    varchar2,
     i_sub_no 		in    varchar2,
     i_trd_seq_no	in    number
  ) return number is

  t_gst_dpo_cncl_amt	number := 0;
  t_sqlcd				number := 0;

begin

    begin

		select
		GST_DPO_PRERM - GST_DPO_NOWRM
		into
		t_gst_dpo_cncl_amt
		from vn.cwd04m00
		where acnt_no = i_acnt_no
		and   sub_no  = i_sub_no
		and   TRD_SEQ_NO = i_trd_seq_no;

    EXCEPTION
		when  no_data_found  then
			return 0;
		WHEN  OTHERS         THEN
	        raise_application_error(-20100,'*fcw_gst_dpo_cncl_q**'|| to_char(t_sqlcd)|| i_acnt_no||'*'||
	                                 i_trd_seq_no);
    end;

    return t_gst_dpo_cncl_amt;

end fcw_gst_dpo_cncl_q;
/

