create PROCEDURE PGG_CREATE_VOUCHER
/********************
    자동 전표 생성(전표insert)
********************/
(                I_SLIP_DT                  IN  VARCHAR2            --전표일자
                ,I_AUTO_SLIP_PROC_TP        IN  VARCHAR2            --전표처리구분(I:입력전표,D:취소전표)
                ,I_PROC_BRCH_CD             IN  VARCHAR2            --지점코드
                ,I_PROC_AGNC_BRCH           IN  VARCHAR2            --대리지점
                ,I_ACNT_NO                  IN  VARCHAR2            --계좌번호
                ,I_TRD_DT                   IN  VARCHAR2            --거래일
                ,I_TRD_SEQ_NO               IN  NUMBER              --거래일련번호
                ,I_ORIG_TRD_SEQ_NO          IN  NUMBER              --원천거래일련번호
                ,I_RMRK_JOB_TP              IN  VARCHAR2            --적요업무구분
                ,I_ACC_RMRK_CD              IN  VARCHAR2            --회계적요코드
                ,I_EXCH_BRCH_CD             IN  VARCHAR2            --대체지점코드(계좌관리점)
                ,I_EXCH_AGNC_BRCH           IN  VARCHAR2            --대체대리지점(계좌관리점)
                ,I_DR_AMT_01                IN  NUMBER             --차변금액01
                ,I_DR_AMT_02                IN  NUMBER             --차변금액02
                ,I_DR_AMT_03                IN  NUMBER             --차변금액03
                ,I_DR_AMT_04                IN  NUMBER             --차변금액04
                ,I_DR_AMT_05                IN  NUMBER             --차변금액05
                ,I_DR_AMT_06                IN  NUMBER             --차변금액06
                ,I_DR_AMT_07                IN  NUMBER             --차변금액07
                ,I_DR_AMT_08                IN  NUMBER             --차변금액08
                ,I_DR_AMT_09                IN  NUMBER             --차변금액09
                ,I_DR_AMT_10                IN  NUMBER             --차변금액10
                ,I_CR_AMT_01                IN  NUMBER             --대변금액01
                ,I_CR_AMT_02                IN  NUMBER             --대변금액02
                ,I_CR_AMT_03                IN  NUMBER             --대변금액03
                ,I_CR_AMT_04                IN  NUMBER             --대변금액04
                ,I_CR_AMT_05                IN  NUMBER             --대변금액05
                ,I_CR_AMT_06                IN  NUMBER             --대변금액06
                ,I_CR_AMT_07                IN  NUMBER             --대변금액07
                ,I_CR_AMT_08                IN  NUMBER             --대변금액08
                ,I_CR_AMT_09                IN  NUMBER             --대변금액09
                ,I_CR_AMT_10                IN  NUMBER             --대변금액10
                ,I_DRCT_ACC_ACT_ASN_YN  IN    VARCHAR2 --직접회계계정지정여부 2008-01-25 ( D;차변지정, C:대변지정, M:차/대 지정, N or null:지정안함)
                ,I_DR_ACC_ACT_01       IN    VARCHAR2   --차변회계계정01  2008-01-25
                ,I_DR_ACC_ACT_02       IN    VARCHAR2   --차변회계계정02  2008-01-25
                ,I_DR_ACC_ACT_03       IN    VARCHAR2   --차변회계계정03  2008-01-25
                ,I_CR_ACC_ACT_01       IN    VARCHAR2   --대변회계계정01  2008-01-25
                ,I_CR_ACC_ACT_02       IN    VARCHAR2   --대변회계계정02  2008-01-25
                ,I_CR_ACC_ACT_03       IN    VARCHAR2   --대변회계계정03  2008-01-25
                ,I_BANK_CD                   IN    VARCHAR2  --은행코드 2008-05-27
                ,I_WORK_MN                  IN  VARCHAR2            --작업자
                ,I_WORK_DTM                 IN  DATE                --작업일시
                ,I_WORK_TRM                 IN  VARCHAR2            --작업단말
                ,O_SLIP_NO                  OUT VARCHAR2           --전표번호
                ,O_PROC_CNT                 OUT NUMBER              --PROC NUMBER
)IS
    T_C2_CNT        NUMBER;         -- COUNTER OF C2
    T_ABNH_TP       VARCHAR2(2);
    T_ACC_RMRK_CD   GGA06M00.ACC_RMRK_CD%TYPE;
    T_SLIP_NO       GGA06M00.SLIP_NO%TYPE;
    T_HEAD_BRCH_TP  XCC90M00.HEAD_BRCH_TP%TYPE;

    T_GGA06M00_SLIP_DT             GGA06M00.SLIP_DT%TYPE;              --전표일자
    T_GGA06M00_BRCH_CD             GGA06M00.BRCH_CD%TYPE;              --지점코드
    T_GGA06M00_AGNC_BRCH           GGA06M00.AGNC_BRCH%TYPE;            --대리지점
    T_GGA06M00_SLIP_NO             GGA06M00.SLIP_NO%TYPE;              --전표번호
    T_GGA06M00_SLIP_SUB_NO         GGA06M00.SLIP_SUB_NO%TYPE;          --전표부번호
    T_GGA06M00_RMRK_JOB_TP         GGA06M00.RMRK_JOB_TP%TYPE;          --적요업무구분
    T_GGA06M00_SLIP_TP             GGA06M00.SLIP_TP%TYPE;              --전표구분
    T_GGA06M00_ACC_RMRK_CD         GGA06M00.ACC_RMRK_CD%TYPE;          --회계적요코드
    T_GGA06M00_TRD_CNTE            GGA06M00.TRD_CNTE%TYPE;             --거래비고
    T_GGA06M00_DR_CR_TP            GGA06M00.DR_CR_TP%TYPE;             --차변대변구분
    T_GGA06M00_ACC_ACT_CD          GGA06M00.ACC_ACT_CD%TYPE;           --회계계정코드
    T_GGA06M00_OPR_BNH_CD          GGA06M00.OPR_BNH_CD%TYPE;           --상대부점코드
    T_GGA06M00_OPR_AGNC_BRCH       GGA06M00.OPR_AGNC_BRCH%TYPE;        --상대대리지점
    T_GGA06M00_SLIP_AMT            GGA06M00.SLIP_AMT%TYPE;             --전표금액
    T_GGA06M00_DETL_CNTE           GGA06M00.DETL_CNTE%TYPE;            --상세비고
    T_GGA06M00_RECV_SND_TP         GGA06M00.RECV_SND_TP%TYPE;          --수신발신구분
    T_GGA06M00_RECV_YN             GGA06M00.RECV_YN%TYPE;              --수신여부
    T_GGA06M00_AUTO_TP             GGA06M00.AUTO_TP%TYPE;              --자동구분
    T_GGA06M00_SLIP_STAT           GGA06M00.SLIP_STAT%TYPE;            --전표상태
    T_GGA06M00_DRAF_MN             GGA06M00.DRAF_MN%TYPE;              --기안자
    T_GGA06M00_DRAF_DTM            GGA06M00.DRAF_DTM%TYPE;             --기안일시
    T_GGA06M00_CNFM_MN             GGA06M00.CNFM_MN%TYPE;              --승인자
    T_GGA06M00_CNFM_DTM            GGA06M00.CNFM_DTM%TYPE;             --승인일시
    T_GGA06M00_CUST_CD             GGA06M00.CUST_CD%TYPE;              --거래처코드
    T_GGA06M00_SUP_PRI_AMT         GGA06M00.SUP_PRI_AMT%TYPE;          --공급가액
    T_GGA06M00_VAT_AMT             GGA06M00.VAT_AMT%TYPE;              --부가세액
    T_GGA06M00_EVI_TP              GGA06M00.EVI_TP%TYPE;               --증빙구분
    T_GGA06M00_EVI_DT              GGA06M00.EVI_DT%TYPE;               --증빙일자
    T_GGA06M00_EVI_NO              GGA06M00.EVI_NO%TYPE;               --증빙번호
    T_GGA06M00_TAXB_NO             GGA06M00.TAXB_NO%TYPE;              --세무번호
    T_GGA06M00_ORIG_ACNT_NO        GGA06M00.ORIG_ACNT_NO%TYPE;         --원천계좌번호
    T_GGA06M00_ORIG_TRD_DT         GGA06M00.ORIG_TRD_DT%TYPE;          --원천거래일
    T_GGA06M00_ORIG_TRD_SEQ_NO     GGA06M00.ORIG_TRD_SEQ_NO%TYPE;      --원천거래일련번호
    T_GGA06M00_RECV_SND_NO         GGA06M00.RECV_SND_NO%TYPE;          --수신발신번호
    T_GGA06M00_WORK_MN             GGA06M00.WORK_MN%TYPE;              --처리자
    T_GGA06M00_WORK_DTM            GGA06M00.WORK_DTM%TYPE;             --처리일시
    T_GGA06M00_WORK_TRM            GGA06M00.WORK_TRM%TYPE;             --처리단말


    T_GGA06M01_RECV_SND_NO         GGA06M01.RECV_SND_NO%TYPE;          --수신발신번호
    T_GGA06M01_SLIP_DT             GGA06M01.SLIP_DT%TYPE;              --전표일자
    T_GGA06M01_BRCH_CD             GGA06M01.BRCH_CD%TYPE;              --지점코드
    T_GGA06M01_AGNC_BRCH           GGA06M01.AGNC_BRCH%TYPE;            --대리지점
    T_GGA06M01_SLIP_NO             GGA06M01.SLIP_NO%TYPE;              --전표번호
    T_GGA06M01_SLIP_SUB_NO         GGA06M01.SLIP_SUB_NO%TYPE;          --전표부번호
    T_GGA06M01_RECV_SLIP_DT        GGA06M01.RECV_SLIP_DT%TYPE;         --수신전표일자
    T_GGA06M01_RECV_BNH_CD         GGA06M01.RECV_BNH_CD%TYPE;          --수신부점코드
    T_GGA06M01_RECV_AGNC_BRCH      GGA06M01.RECV_AGNC_BRCH%TYPE;       --수신대리지점
    T_GGA06M01_RECV_SLIP_NO        GGA06M01.RECV_SLIP_NO%TYPE;         --수신전표번호
    T_GGA06M01_RECV_SLIP_SUB_NO    GGA06M01.RECV_SLIP_SUB_NO%TYPE;     --수신전표부번호
    T_GGA06M01_RECV_ACT_CD         GGA06M01.RECV_ACT_CD%TYPE;          --수신계정코드
    T_GGA06M01_RECV_YN             GGA06M01.RECV_YN%TYPE;              --수신여부
    T_GGA06M01_WORK_MN             GGA06M01.WORK_MN%TYPE;              --처리자
    T_GGA06M01_WORK_DTM            GGA06M01.WORK_DTM%TYPE;             --처리일시
    T_GGA06M01_WORK_TRM            GGA06M01.WORK_TRM%TYPE;             --처리단말
    T_GGA06M01_RECV_ACC_RMRK_CD    GGA06M01.RECV_ACC_RMRK_CD%TYPE;     --수신적요코드

    T_BANK_112_ACC_CD              GGA02C00.ACC_ACT_CD%TYPE;           --은행연계 은행112계정코드

/* 20090330-001 START -------------------------- */
/* 20090330-001 SeoHaeSeok 수정 : 신회계규정집 */
    T_321_ACC_CD              	   GGA02C00.ACC_ACT_CD%TYPE;           --수도결제대기321계정코드
    T_5111_ACC_CD              	   GGA02C00.ACC_ACT_CD%TYPE;           --매수매도수수료5111계정코드
/* 20090330-001 END -------------------------- */


    T_BRCH_UITE_CD    VARCHAR2(3);            --지점통칭코드
    T_HEAD_UITE_CD    VARCHAR2(3);            --본사통칭코드

    T_C2_DR_CNT        NUMBER;         -- COUNTER OF C2 DR
    T_C2_CR_CNT        NUMBER;         -- COUNTER OF C2 CR

    T_SLIP_OCUR_YN    VARCHAR2(1);     -- 실계정여부
 --   T_HEAD_BRCH_TP      XCC90M00.HEAD_BRCH_TP%TYPE; --지점의 본사/지점 구분


BEGIN   -- START OF Main
--pxc_log_write('pgg_create_voucher.','      =[========================================]');
--pxc_log_write('pgg_create_voucher.','      =['|| I_ACC_RMRK_CD||']');
--pxc_log_write('pgg_create_voucher.',' I_SLIP_DT                 =['|| I_SLIP_DT               ||']');
--pxc_log_write('pgg_create_voucher.',' I_AUTO_SLIP_PROC_TP       =['|| I_AUTO_SLIP_PROC_TP     ||']');
--pxc_log_write('pgg_create_voucher.',' I_PROC_BRCH_CD            =['|| I_PROC_BRCH_CD          ||']');
--pxc_log_write('pgg_create_voucher.',' I_PROC_AGNC_BRCH          =['|| I_PROC_AGNC_BRCH        ||']');
--pxc_log_write('pgg_create_voucher.',' I_ACNT_NO                 =['|| I_ACNT_NO               ||']');
--pxc_log_write('pgg_create_voucher.',' I_TRD_DT                  =['|| I_TRD_DT                ||']');
--pxc_log_write('pgg_create_voucher.',' I_TRD_SEQ_NO              =['|| I_TRD_SEQ_NO            ||']');
--pxc_log_write('pgg_create_voucher.',' I_ORIG_TRD_SEQ_NO         =['|| I_ORIG_TRD_SEQ_NO       ||']');
--pxc_log_write('pgg_create_voucher.',' I_RMRK_JOB_TP             =['|| I_RMRK_JOB_TP           ||']');
--pxc_log_write('pgg_create_voucher.',' I_ACC_RMRK_CD             =['|| I_ACC_RMRK_CD           ||']');
--pxc_log_write('pgg_create_voucher.',' I_EXCH_BRCH_CD            =['|| I_EXCH_BRCH_CD          ||']');
--pxc_log_write('pgg_create_voucher.',' I_EXCH_AGNC_BRCH          =['|| I_EXCH_AGNC_BRCH        ||']');
--pxc_log_write('pgg_create_voucher.',' I_DR_AMT_01               =['|| I_DR_AMT_01             ||']');
--pxc_log_write('pgg_create_voucher.',' I_DR_AMT_02               =['|| I_DR_AMT_02             ||']');
--pxc_log_write('pgg_create_voucher.',' I_DR_AMT_03               =['|| I_DR_AMT_03             ||']');
--pxc_log_write('pgg_create_voucher.',' I_DR_AMT_04               =['|| I_DR_AMT_04             ||']');
--pxc_log_write('pgg_create_voucher.',' I_DR_AMT_05               =['|| I_DR_AMT_05             ||']');
--pxc_log_write('pgg_create_voucher.',' I_DR_AMT_06               =['|| I_DR_AMT_06             ||']');
--pxc_log_write('pgg_create_voucher.',' I_DR_AMT_07               =['|| I_DR_AMT_07             ||']');
--pxc_log_write('pgg_create_voucher.',' I_DR_AMT_08               =['|| I_DR_AMT_08             ||']');
--pxc_log_write('pgg_create_voucher.',' I_DR_AMT_09               =['|| I_DR_AMT_09             ||']');
--pxc_log_write('pgg_create_voucher.',' I_DR_AMT_10               =['|| I_DR_AMT_10             ||']');
--pxc_log_write('pgg_create_voucher.',' I_CR_AMT_01               =['|| I_CR_AMT_01             ||']');
--pxc_log_write('pgg_create_voucher.',' I_CR_AMT_02               =['|| I_CR_AMT_02             ||']');
--pxc_log_write('pgg_create_voucher.',' I_CR_AMT_03               =['|| I_CR_AMT_03             ||']');
--pxc_log_write('pgg_create_voucher.',' I_CR_AMT_04               =['|| I_CR_AMT_04             ||']');
--pxc_log_write('pgg_create_voucher.',' I_CR_AMT_05               =['|| I_CR_AMT_05             ||']');
--pxc_log_write('pgg_create_voucher.',' I_CR_AMT_06               =['|| I_CR_AMT_06             ||']');
--pxc_log_write('pgg_create_voucher.',' I_CR_AMT_07               =['|| I_CR_AMT_07             ||']');
--pxc_log_write('pgg_create_voucher.',' I_CR_AMT_08               =['|| I_CR_AMT_08             ||']');
--pxc_log_write('pgg_create_voucher.',' I_CR_AMT_09               =['|| I_CR_AMT_09             ||']');
--pxc_log_write('pgg_create_voucher.',' I_CR_AMT_10               =['|| I_CR_AMT_10             ||']');
--pxc_log_write('pgg_create_voucher.',' I_DRCT_ACC_ACT_ASN_YN     =['|| I_DRCT_ACC_ACT_ASN_YN   ||']');
--pxc_log_write('pgg_create_voucher.',' I_DR_ACC_ACT_01           =['|| I_DR_ACC_ACT_01         ||']');
--pxc_log_write('pgg_create_voucher.',' I_DR_ACC_ACT_02           =['|| I_DR_ACC_ACT_02         ||']');
--pxc_log_write('pgg_create_voucher.',' I_DR_ACC_ACT_03           =['|| I_DR_ACC_ACT_03         ||']');
--pxc_log_write('pgg_create_voucher.',' I_CR_ACC_ACT_01           =['|| I_CR_ACC_ACT_01         ||']');
--pxc_log_write('pgg_create_voucher.',' I_CR_ACC_ACT_02           =['|| I_CR_ACC_ACT_02         ||']');
--pxc_log_write('pgg_create_voucher.',' I_CR_ACC_ACT_03           =['|| I_CR_ACC_ACT_03         ||']');
--pxc_log_write('pgg_create_voucher.',' I_WORK_MN                 =['|| I_WORK_MN               ||']');
--pxc_log_write('pgg_create_voucher.',' I_WORK_DTM                =['|| I_WORK_DTM              ||']');
--pxc_log_write('pgg_create_voucher.',' I_WORK_TRM                =['|| I_WORK_TRM              ||']');
--pxc_log_write('pgg_create_voucher.',' O_SLIP_NO                 =['|| O_SLIP_NO               ||']');
--pxc_log_write('pgg_create_voucher.',' O_PROC_CNT                =['|| O_PROC_CNT              ||']');
--pxc_log_write('pgg_create_voucher.','      =[---------]');



        -- Iniciate counter T_C2_CNT
        T_C2_CNT            :=  1;
        --지점 통칭코드 가져오기
        SELECT  COL_CD_TP
          INTO  T_BRCH_UITE_CD
          FROM  XCC01C01
         WHERE  COL_CD = 'brch_uite_cd';

--        --본사 통칭코드 가져오기
--        SELECT  COL_CD_TP
--          INTO  T_HEAD_UITE_CD
--          FROM  XCC01C01
--         WHERE  COL_CD = 'head_uite_cd';

        T_GGA06M00_ORIG_ACNT_NO     :=  I_ACNT_NO;     --원천계좌번호
        T_GGA06M00_ORIG_TRD_DT      :=  I_TRD_DT;      --원천거래일
        T_GGA06M00_ORIG_TRD_SEQ_NO  :=  I_TRD_SEQ_NO;  --원천거래일련번호


        --initialize slip no
        T_GGA06M00_SLIP_NO := '00000';

        --은행연계 112계정코드 2008-05-27
        T_BANK_112_ACC_CD   :=  '1121Z0000000';
        T_321_ACC_CD        :=  '321000000000';
        T_5111_ACC_CD       :=  '511100000000';

        --회계적요 정보 가져와서 전표입력 한다..
        FOR C2  IN(
            SELECT   A.RMRK_INOUT_TP        --적요입출구분
                    ,A.ACC_RMRK_CD          --적요코드
                    ,B.DR_CR_TP             --차대구분
                    ,B.ACC_ACT_CD           --계정
                    ,B.OPR_BNH_CD           --상대부점코드
                    ,B.OPR_AGNC_BRCH        --상대부점코드(출장소)
                    ,B.RECV_SND_TP          --수발신 구분
                    ,B.ORIG_AMT_TP          --원천금액항목구분
                    ,B.OPR_ACC_RMRK_CD      --상대적요코드
                    ,A.ACC_RMRK_CD_NM       --적요명
                    ,A.RMRK_TRD_TP          --업무적요 2008-05-27
              FROM   GGA03C00    A   --회계적요M
                    ,GGA03C01    B   --회계적요Detail
             WHERE  A.ACC_RMRK_CD   =   I_ACC_RMRK_CD
               AND  B.ACC_RMRK_CD   =   A.ACC_RMRK_CD
        )LOOP

--pxc_log_write('pgg_create_voucher','  T_C2_CNT =[<< ' || TO_CHAR(T_C2_CNT) || ' >>]');

            -- =============
            -- 전표정보 지정
            -- =============

            T_GGA06M00_SLIP_DT      :=  I_SLIP_DT;        --전표일자
            T_GGA06M00_BRCH_CD      :=  I_PROC_BRCH_CD;  --지점코드
            T_GGA06M00_AGNC_BRCH    :=  I_PROC_AGNC_BRCH;--대리지점

           --  check C2.RMRK_INOUT_TP
           IF C2.RMRK_INOUT_TP NOT IN ('1','2', '3','4','5','6','7','8','9','A') THEN
                RAISE_APPLICATION_ERROR(-20003,'Invalid GGA03C00.rmrk_inout_tp ['||C2.RMRK_INOUT_TP||']');
           END IF;

            -- IF slip no is not set the  setting slip no
            IF T_GGA06M00_SLIP_NO = '00000' THEN
                T_GGA06M00_SLIP_NO          :=  FGG_GET_SLIP_NO(I_PROC_BRCH_CD,I_PROC_AGNC_BRCH,I_SLIP_DT, C2.RMRK_INOUT_TP);  --전표번호
            END IF;

--pxc_log_write('pgg_create_voucher','  T_GGA06M00_SLIP_NO =[' || T_GGA06M00_SLIP_NO || ']');


            T_GGA06M00_SLIP_SUB_NO  :=  TO_CHAR(T_C2_CNT,'FM000');--전표부번호
            T_GGA06M00_RMRK_JOB_TP  :=  I_RMRK_JOB_TP;          --적요업무구분
            T_GGA06M00_SLIP_TP      :=  C2.RMRK_INOUT_TP;        --적요입출구분
            T_GGA06M00_ACC_RMRK_CD  :=  C2.ACC_RMRK_CD;          --적요코드
            T_GGA06M00_TRD_CNTE     :=  C2.ACC_RMRK_CD_NM;       --비고
            T_GGA06M00_DR_CR_TP     :=  C2.DR_CR_TP;             --차대구분



            --계정을 직접지정하는 경우
            IF NVL(I_DRCT_ACC_ACT_ASN_YN ,'N') <> 'N' THEN


                    --차변인경우
                    IF T_GGA06M00_DR_CR_TP = '1' THEN
                            IF NVL(I_DRCT_ACC_ACT_ASN_YN ,'N')  IN ( 'D', 'M')  THEN
                                IF          C2.ORIG_AMT_TP  =   '01'     THEN    T_GGA06M00_ACC_ACT_CD   :=   I_DR_ACC_ACT_01;
                                ELSIF   C2.ORIG_AMT_TP  =   '02'    THEN    T_GGA06M00_ACC_ACT_CD   :=   I_DR_ACC_ACT_02;
                                ELSIF   C2.ORIG_AMT_TP  =   '03'    THEN    T_GGA06M00_ACC_ACT_CD   :=   I_DR_ACC_ACT_03;
                                ELSE
                                    RAISE_APPLICATION_ERROR(-20002,'적요상세정보에 금액원천항목의 값이 유효하지 않다(0)');
                                END IF;
                            --대변계정만 지정인경우 차변계정은 적요로부터 가져온다
                           ELSIF NVL(I_DRCT_ACC_ACT_ASN_YN ,'N')  ='C'  THEN
                                T_GGA06M00_ACC_ACT_CD   :=  C2.ACC_ACT_CD;           --계정(적요로 부터 계정)
                           ELSE
                                    RAISE_APPLICATION_ERROR(-20002,'Invalid  DRCT_ACC_ACT_ASN_YN['||I_DRCT_ACC_ACT_ASN_YN||']');
                            END IF;
                    --대변인경우
                    ELSIF T_GGA06M00_DR_CR_TP = '2' THEN
                            IF NVL(I_DRCT_ACC_ACT_ASN_YN ,'N')  IN ( 'C', 'M')  THEN
                                IF          C2.ORIG_AMT_TP  =   '01'     THEN    T_GGA06M00_ACC_ACT_CD   :=   I_CR_ACC_ACT_01;
                                ELSIF   C2.ORIG_AMT_TP  =   '02'    THEN    T_GGA06M00_ACC_ACT_CD   :=   I_CR_ACC_ACT_02;
                                ELSIF   C2.ORIG_AMT_TP  =   '03'    THEN    T_GGA06M00_ACC_ACT_CD   :=   I_CR_ACC_ACT_03;
                                ELSE
                                    RAISE_APPLICATION_ERROR(-20002,'적요상세정보에 금액원천항목의 값이 유효하지 않다(0)');
                                END IF;
                            --차변계정만 지정인경우 대변계정은 적요로부터 가져온다
                           ELSIF NVL(I_DRCT_ACC_ACT_ASN_YN ,'N')  ='D'  THEN
                                T_GGA06M00_ACC_ACT_CD   :=  C2.ACC_ACT_CD;           --계정(적요로 부터 계정)
                            ELSE
                                    RAISE_APPLICATION_ERROR(-20002,'Invalid  DRCT_ACC_ACT_ASN_YN2['||I_DRCT_ACC_ACT_ASN_YN||']');
                            END IF;
                    ELSE
                            RAISE_APPLICATION_ERROR(-20001,'iNVALID DR/CR TP['||T_GGA06M00_DR_CR_TP||']');
                    END IF;

                    --계정을 직접지정했으나 NULL 인경우는 원래 적요에 있는 계정을 사용
                    IF T_GGA06M00_ACC_ACT_CD IS NULL THEN
                        T_GGA06M00_ACC_ACT_CD   :=  C2.ACC_ACT_CD;           --계정(적요로 부터 계정)
                    END IF;

            --계정을 적요로 부터 가져오는 경우
            ELSE
                    T_GGA06M00_ACC_ACT_CD   :=  C2.ACC_ACT_CD;           --계정(적요로 부터 계정)

                    -- 은행대표계좌 계정인경우 은행테이블에서 회계계정코드를 가져옴 2008-05-27
                    IF TRIM(C2.ACC_ACT_CD) = TRIM(T_BANK_112_ACC_CD) THEN

                        --은행테이블에서 은행계좌 회계계정코드를 가져 옴

/* 20080828-001 START -------------------------- */
/* 20080828-001 SeoHaeSeok 수정 : 은행계정:MAX(MNG_END_DT) 인것 가져오기 */

/* ----------------------------------------------------------
                        SELECT  ACC_ACT_CD
                          INTO  T_GGA06M00_ACC_ACT_CD
                          FROM  CWW01H00
                         WHERE  BANK_CD = I_BANK_CD;
-------------------------------------------------------------*/

                        SELECT  ACC_ACT_CD
                          INTO  T_GGA06M00_ACC_ACT_CD
                          FROM  CWW01H00
                         WHERE  BANK_CD = I_BANK_CD
                           AND	MNG_END_DT	=	(	SELECT	MAX(v11.MNG_END_DT)
													  FROM	CWW01H00 v11
													 WHERE	v11.BANK_CD = I_BANK_CD
													   AND	v11.MNG_STRT_DT	<=	TO_DATE(I_SLIP_DT, 'YYYY/MM/DD HH24:MI:SS')
												) ;
                    END IF;
/* 20080828-001 END -------------------------- */


/* 20090330-001 START -------------------------- */
/* 20090330-001 SeoHaeSeok 수정 : 신회계규정집 */

                    IF TRIM(C2.ACC_ACT_CD) = TRIM(T_321_ACC_CD) THEN

						IF	I_BANK_CD = '0003'	THEN
							T_GGA06M00_ACC_ACT_CD	:=	'321100000003';
						ELSIF	I_BANK_CD = '0002'	THEN
							T_GGA06M00_ACC_ACT_CD	:=	'321200000002';
						ELSIF	I_BANK_CD = '0004'	THEN
							T_GGA06M00_ACC_ACT_CD	:=	'321300000004';
						END IF;
                    END IF;

                    IF TRIM(C2.ACC_ACT_CD) = TRIM(T_5111_ACC_CD) THEN

--pxc_log_write('pgg_create_voucher','  T_GGA06M00_ACC_ACT_CD =[<< ' || T_GGA06M00_ACC_ACT_CD || ' >>]');

						IF	I_BANK_CD = '0003'	THEN
							T_GGA06M00_ACC_ACT_CD	:=	'511110000003';
						ELSIF	I_BANK_CD = '0002'	THEN
							T_GGA06M00_ACC_ACT_CD	:=	'511120000002';
						ELSIF	I_BANK_CD = '0004'	THEN
							T_GGA06M00_ACC_ACT_CD	:=	'511130000004';
						END IF;

                    END IF;
/* 20090330-001 END -------------------------- */

            END IF;


--pxc_log_write('pgg_create_voucher','  T_GGA06M00_ACC_ACT_CD =[<< ' || T_GGA06M00_ACC_ACT_CD || ' >>]');


--BEGIN

            --계정이 실계정인지 검사
            SELECT NVL(SLIP_OCUR_YN,'N')
              INTO T_SLIP_OCUR_YN
              FROM GGA02C00
             WHERE ACC_ACT_CD = T_GGA06M00_ACC_ACT_CD;
--EXCEPTION WHEN OTHERS THEN
 --   RAISE_APPLICATION_ERROR(-20001,'SQLCODE=['|| TO_CHAR(SQLCODE) ||'],BANK_ACC=['||T_GGA06M00_ACC_ACT_CD ||'] ,BANK_CD=['|| I_BANK_CD ||']!');
--END;
            IF  T_SLIP_OCUR_YN <> 'Y' THEN
                RAISE_APPLICATION_ERROR(-20001,'['||T_GGA06M00_ACC_ACT_CD ||'] is Not Slip Occur Account !!');
            END IF;



            --상대적요와 거래처(고객코드) 지정
            --발신적요인경우
            IF C2.RECV_SND_TP = '1'  THEN
                    -- 적요상세정보에 상대부점이 지점인경우는 발신이면계좌정보의 계좌관리점을 사용, 수신이면 처리점 사용
                    IF  C2.OPR_BNH_CD = T_BRCH_UITE_CD THEN
                        T_GGA06M00_OPR_BNH_CD   :=  I_EXCH_BRCH_CD;          --상대부점코드
                        T_GGA06M00_OPR_AGNC_BRCH:=  I_EXCH_AGNC_BRCH;        --상대부점코드(출장소)

                        T_GGA06M00_CUST_CD := 'BR00000' ||T_GGA06M00_OPR_BNH_CD;  --고객코드는 상대부점(지점)

                    ELSE
                        T_GGA06M00_OPR_BNH_CD   :=  C2.OPR_BNH_CD;           --상대부점코드
                        T_GGA06M00_OPR_AGNC_BRCH:=  C2.OPR_AGNC_BRCH;        --상대부점코드(출장소)

                        T_GGA06M00_CUST_CD := 'HD00000' ||T_GGA06M00_OPR_BNH_CD;   --고객코드는 상대부점(본사부서)

                    END IF;

            --발신이 아닌경우
            ELSE
                    -- 수신인경우 본 프로시져를 호출한 pgg_job_recv_snd_slip 에서 상대부점(발신부점) 정보를 update 함
                    T_GGA06M00_OPR_BNH_CD   :=  NULL;        --상대부점코드
                    T_GGA06M00_OPR_AGNC_BRCH:=  NULL;        --상대부점코드(출장소)

                    --수/발신 모두 아닌 경우는 거래처는 전표발생부점 자신
                    IF C2.RECV_SND_TP = '9'  THEN

                        SELECT  A.HEAD_BRCH_TP          --(0:본사, 1:지점, 2:출장소)
                          INTO  T_HEAD_BRCH_TP
                          FROM  XCC90M00 A  -- 지점정보
                         WHERE  A.BRCH_CD   = T_GGA06M00_BRCH_CD
                           AND  A.AGNC_BRCH = '00';

                        --본사부서인경우
                        IF T_HEAD_BRCH_TP = '0' THEN
                            T_GGA06M00_CUST_CD := 'HD00000' ||T_GGA06M00_BRCH_CD;   --고객코드는 자신(본사부서)
                        --지점인경우
                        ELSE
                            T_GGA06M00_CUST_CD := 'BR00000' ||T_GGA06M00_BRCH_CD;  --고객코드는 자신(지점)
                        END IF;

                    END IF;

            END IF;





            T_GGA06M00_DETL_CNTE    :=  '';             --상세비고
            T_GGA06M00_RECV_SND_TP  :=  C2.RECV_SND_TP; --수발신 구분
            T_GGA06M00_RECV_YN      :=  NULL;           --수신여부
            T_GGA06M00_AUTO_TP      :=  '1';            --자동구분(1:자동전표,2:수기전표)
            T_GGA06M00_SLIP_STAT    :=  '1';            --전표상태(1:미승인,2:승인,3:반려,4:취소)  -- 뒤에서 '2'로 바꾸는 로직 있음
            T_GGA06M00_DRAF_MN      :=  I_WORK_MN;     --기안자
            T_GGA06M00_DRAF_DTM     :=  I_WORK_DTM;    --기안일시
            T_GGA06M00_CNFM_MN      :=  NULL;           --승인자
            T_GGA06M00_CNFM_DTM     :=  NULL;           --승인일시

            T_GGA06M00_SUP_PRI_AMT  :=  NULL;           --공급가액
            T_GGA06M00_VAT_AMT      :=  NULL;           --부가세액
            T_GGA06M00_EVI_TP       :=  NULL;           --증빙구분
            T_GGA06M00_EVI_DT       :=  NULL;           --증빙일자
            T_GGA06M00_EVI_NO       :=  NULL;           --증빙번호
            T_GGA06M00_TAXB_NO      :=  NULL;           --세무번호
            T_GGA06M00_WORK_MN      :=  I_WORK_MN;      --처리자
            T_GGA06M00_WORK_DTM     :=  SYSDATE;        --처리일시
            T_GGA06M00_WORK_TRM     :=  I_WORK_TRM;     --처리단말
            T_GGA06M00_RECV_SND_NO  :=  NULL;           --수신발신번호

            --금액지정
            IF  C2.DR_CR_TP = '1' THEN  --차변인 경우
                IF      C2.ORIG_AMT_TP  =   '01'    THEN    T_GGA06M00_SLIP_AMT  :=  NVL(I_DR_AMT_01,0);
                ELSIF   C2.ORIG_AMT_TP  =   '02'    THEN    T_GGA06M00_SLIP_AMT  :=  NVL(I_DR_AMT_02,0);
                ELSIF   C2.ORIG_AMT_TP  =   '03'    THEN    T_GGA06M00_SLIP_AMT  :=  NVL(I_DR_AMT_03,0);
                ELSIF   C2.ORIG_AMT_TP  =   '04'    THEN    T_GGA06M00_SLIP_AMT  :=  NVL(I_DR_AMT_04,0);
                ELSIF   C2.ORIG_AMT_TP  =   '05'    THEN    T_GGA06M00_SLIP_AMT  :=  NVL(I_DR_AMT_05,0);
                ELSIF   C2.ORIG_AMT_TP  =   '06'    THEN    T_GGA06M00_SLIP_AMT  :=  NVL(I_DR_AMT_06,0);
                ELSIF   C2.ORIG_AMT_TP  =   '07'    THEN    T_GGA06M00_SLIP_AMT  :=  NVL(I_DR_AMT_07,0);
                ELSIF   C2.ORIG_AMT_TP  =   '08'    THEN    T_GGA06M00_SLIP_AMT  :=  NVL(I_DR_AMT_08,0);
                ELSIF   C2.ORIG_AMT_TP  =   '09'    THEN    T_GGA06M00_SLIP_AMT  :=  NVL(I_DR_AMT_09,0);
                ELSIF   C2.ORIG_AMT_TP  =   '10'    THEN    T_GGA06M00_SLIP_AMT  :=  NVL(I_DR_AMT_10,0);
                ELSE
                    RAISE_APPLICATION_ERROR(-20001,'적요상세정보에 금액원천항목의 값이 유효하지 않다');
                END IF;

            ELSE                        --대변인 경우
                IF      C2.ORIG_AMT_TP  =   '01'    THEN    T_GGA06M00_SLIP_AMT  :=  NVL(I_CR_AMT_01,0);
                ELSIF   C2.ORIG_AMT_TP  =   '02'    THEN    T_GGA06M00_SLIP_AMT  :=  NVL(I_CR_AMT_02,0);
                ELSIF   C2.ORIG_AMT_TP  =   '03'    THEN    T_GGA06M00_SLIP_AMT  :=  NVL(I_CR_AMT_03,0);
                ELSIF   C2.ORIG_AMT_TP  =   '04'    THEN    T_GGA06M00_SLIP_AMT  :=  NVL(I_CR_AMT_04,0);
                ELSIF   C2.ORIG_AMT_TP  =   '05'    THEN    T_GGA06M00_SLIP_AMT  :=  NVL(I_CR_AMT_05,0);
                ELSIF   C2.ORIG_AMT_TP  =   '06'    THEN    T_GGA06M00_SLIP_AMT  :=  NVL(I_CR_AMT_06,0);
                ELSIF   C2.ORIG_AMT_TP  =   '07'    THEN    T_GGA06M00_SLIP_AMT  :=  NVL(I_CR_AMT_07,0);
                ELSIF   C2.ORIG_AMT_TP  =   '08'    THEN    T_GGA06M00_SLIP_AMT  :=  NVL(I_CR_AMT_08,0);
                ELSIF   C2.ORIG_AMT_TP  =   '09'    THEN    T_GGA06M00_SLIP_AMT  :=  NVL(I_CR_AMT_09,0);
                ELSIF   C2.ORIG_AMT_TP  =   '10'    THEN    T_GGA06M00_SLIP_AMT  :=  NVL(I_CR_AMT_10,0);
                ELSE
                    RAISE_APPLICATION_ERROR(-20001,'적요상세정보에 금액원천항목의 값이 유효하지 않다(2)');
                END IF;
            END IF;
            -- =============
            -- GGA06M00(VOUCHER) INSERT
            -- =============

--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_SLIP_DT             =['|| T_GGA06M00_SLIP_DT             ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_BRCH_CD             =['|| T_GGA06M00_BRCH_CD             ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_AGNC_BRCH           =['|| T_GGA06M00_AGNC_BRCH           ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_SLIP_NO             =['|| T_GGA06M00_SLIP_NO             ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_SLIP_SUB_NO         =['|| T_GGA06M00_SLIP_SUB_NO         ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_RMRK_JOB_TP         =['|| T_GGA06M00_RMRK_JOB_TP         ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_SLIP_TP             =['|| T_GGA06M00_SLIP_TP             ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_ACC_RMRK_CD         =['|| T_GGA06M00_ACC_RMRK_CD         ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_TRD_CNTE            =['|| T_GGA06M00_TRD_CNTE            ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_DR_CR_TP            =['|| T_GGA06M00_DR_CR_TP            ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_ACC_ACT_CD          =['|| T_GGA06M00_ACC_ACT_CD          ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_OPR_BNH_CD          =['|| T_GGA06M00_OPR_BNH_CD          ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_OPR_AGNC_BRCH       =['|| T_GGA06M00_OPR_AGNC_BRCH       ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_SLIP_AMT            =['|| T_GGA06M00_SLIP_AMT            ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_DETL_CNTE           =['|| T_GGA06M00_DETL_CNTE           ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_RECV_SND_TP         =['|| T_GGA06M00_RECV_SND_TP         ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_RECV_YN             =['|| T_GGA06M00_RECV_YN             ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_AUTO_TP             =['|| T_GGA06M00_AUTO_TP             ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_SLIP_STAT           =['|| T_GGA06M00_SLIP_STAT           ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_DRAF_MN             =['|| T_GGA06M00_DRAF_MN             ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_DRAF_DTM            =['|| T_GGA06M00_DRAF_DTM            ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_CNFM_MN             =['|| T_GGA06M00_CNFM_MN             ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_CNFM_DTM            =['|| T_GGA06M00_CNFM_DTM            ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_CUST_CD             =['|| T_GGA06M00_CUST_CD             ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_SUP_PRI_AMT         =['|| T_GGA06M00_SUP_PRI_AMT         ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_VAT_AMT             =['|| T_GGA06M00_VAT_AMT             ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_EVI_TP              =['|| T_GGA06M00_EVI_TP              ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_EVI_DT              =['|| T_GGA06M00_EVI_DT              ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_EVI_NO              =['|| T_GGA06M00_EVI_NO              ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_TAXB_NO             =['|| T_GGA06M00_TAXB_NO             ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_ORIG_ACNT_NO        =['|| T_GGA06M00_ORIG_ACNT_NO        ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_ORIG_TRD_DT         =['|| T_GGA06M00_ORIG_TRD_DT         ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_ORIG_TRD_SEQ_NO     =['|| T_GGA06M00_ORIG_TRD_SEQ_NO     ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_RECV_SND_NO         =['|| T_GGA06M00_RECV_SND_NO         ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_WORK_MN             =['|| T_GGA06M00_WORK_MN             ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_WORK_DTM            =['|| T_GGA06M00_WORK_DTM            ||']');
--pxc_log_write('pgg_create_voucher.',' T_GGA06M00_WORK_TRM            =['|| T_GGA06M00_WORK_TRM            ||']');


            INSERT INTO GGA06M00
            (
                 SLIP_DT                --전표일자
                ,BRCH_CD                --지점코드
                ,AGNC_BRCH              --대리지점
                ,SLIP_NO                --전표번호
                ,SLIP_SUB_NO            --전표부번호
                ,RMRK_JOB_TP            --적요업무구분
                ,SLIP_TP                --전표구분
                ,ACC_RMRK_CD            --회계적요코드
                ,TRD_CNTE               --거래비고
                ,DR_CR_TP               --차변대변구분
                ,ACC_ACT_CD             --회계계정코드
                ,OPR_BNH_CD             --상대부점코드
                ,OPR_AGNC_BRCH          --상대대리지점
                ,SLIP_AMT               --전표금액
                ,DETL_CNTE              --상세비고
                ,RECV_SND_TP            --수신발신구분
                ,RECV_YN                --수신여부
                ,AUTO_TP                --자동구분
                ,SLIP_STAT              --전표상태
                ,DRAF_MN                --기안자
                ,DRAF_DTM               --기안일시
                ,CNFM_MN                --승인자
                ,CNFM_DTM               --승인일시
                ,CUST_CD                --거래처코드
                ,SUP_PRI_AMT            --공급가액
                ,VAT_AMT                --부가세액
                ,EVI_TP                 --증빙구분
                ,EVI_DT                 --증빙일자
                ,EVI_NO                 --증빙번호
                ,TAXB_NO                --세무번호
                ,ORIG_ACNT_NO           --원천계좌번호
                ,ORIG_TRD_DT            --원천거래일
                ,ORIG_TRD_SEQ_NO        --원천거래일련번호
                ,RECV_SND_NO            --수신발신번호
                ,WORK_MN                --처리자
                ,WORK_DTM               --처리일시
                ,WORK_TRM               --처리단말
            )
            VALUES
            (
                 T_GGA06M00_SLIP_DT         --전표일자
                ,T_GGA06M00_BRCH_CD         --지점코드
                ,T_GGA06M00_AGNC_BRCH       --대리지점
                ,T_GGA06M00_SLIP_NO         --전표번호
                ,T_GGA06M00_SLIP_SUB_NO     --전표부번호
                ,T_GGA06M00_RMRK_JOB_TP     --적요업무구분
                ,T_GGA06M00_SLIP_TP         --전표구분
                ,T_GGA06M00_ACC_RMRK_CD     --회계적요코드
                ,T_GGA06M00_TRD_CNTE        --거래비고
                ,T_GGA06M00_DR_CR_TP        --차변대변구분
                ,T_GGA06M00_ACC_ACT_CD      --회계계정코드
                ,T_GGA06M00_OPR_BNH_CD      --상대부점코드
                ,T_GGA06M00_OPR_AGNC_BRCH   --상대대리지점
                ,T_GGA06M00_SLIP_AMT        --전표금액
                ,T_GGA06M00_DETL_CNTE       --상세비고
                ,T_GGA06M00_RECV_SND_TP     --수신발신구분
                ,T_GGA06M00_RECV_YN         --수신여부
                ,T_GGA06M00_AUTO_TP         --자동구분
                ,T_GGA06M00_SLIP_STAT       --전표상태
                ,T_GGA06M00_DRAF_MN         --기안자
                ,T_GGA06M00_DRAF_DTM        --기안일시
                ,T_GGA06M00_CNFM_MN         --승인자
                ,T_GGA06M00_CNFM_DTM        --승인일시
                ,T_GGA06M00_CUST_CD         --거래처코드
                ,T_GGA06M00_SUP_PRI_AMT     --공급가액
                ,T_GGA06M00_VAT_AMT         --부가세액
                ,T_GGA06M00_EVI_TP          --증빙구분
                ,T_GGA06M00_EVI_DT          --증빙일자
                ,T_GGA06M00_EVI_NO          --증빙번호
                ,T_GGA06M00_TAXB_NO         --세무번호
                ,T_GGA06M00_ORIG_ACNT_NO    --원천계좌번호
                ,T_GGA06M00_ORIG_TRD_DT     --원천거래일
                ,T_GGA06M00_ORIG_TRD_SEQ_NO --원천거래일련번호
                ,T_GGA06M00_RECV_SND_NO     --수신발신번호
                ,T_GGA06M00_WORK_MN         --처리자
                ,T_GGA06M00_WORK_DTM        --처리일시
                ,T_GGA06M00_WORK_TRM        --처리단말
            );



            -- =============
            --발신적요인경우 발신내역 생성
            -- =============
            IF      C2.RECV_SND_TP  =   '1' THEN

                --수발신번호 채번
                SELECT  NVL(MAX(RECV_SND_NO),0) + 1
                  INTO  T_GGA06M01_RECV_SND_NO
                  FROM  GGA06M01;

                --발신정보 지정
                T_GGA06M01_SLIP_DT          :=  T_GGA06M00_SLIP_DT;         --전표일자
                T_GGA06M01_BRCH_CD          :=  T_GGA06M00_BRCH_CD;         --발신지점
                T_GGA06M01_AGNC_BRCH        :=  T_GGA06M00_AGNC_BRCH;       --발신지점(출장소)
                T_GGA06M01_SLIP_NO          :=  T_GGA06M00_SLIP_NO;         --전표번호
                T_GGA06M01_SLIP_SUB_NO      :=  T_GGA06M00_SLIP_SUB_NO;     --전표부번호
                T_GGA06M01_RECV_SLIP_DT     :=  NULL;                       --수신전표일자(수신전표 처리시 입력)
                T_GGA06M01_RECV_BNH_CD      :=  T_GGA06M00_OPR_BNH_CD;      --수신부점코드
                T_GGA06M01_RECV_AGNC_BRCH   :=  T_GGA06M00_OPR_AGNC_BRCH;   --수신대리지점
                T_GGA06M01_RECV_SLIP_NO     :=  NULL;                       --수신전표번호(수신전표 처리시 입력)
                T_GGA06M01_RECV_SLIP_SUB_NO :=  NULL;                       --수신전표부번호(수신전표 처리시 입력)
                T_GGA06M01_RECV_ACT_CD      :=  NULL;                       --수신계정코드
                T_GGA06M01_RECV_YN          :=  NULL;                       --수신여부(수신전표 처리시 입력)
                T_GGA06M01_WORK_MN          :=  T_GGA06M00_WORK_MN;         --처리자
                T_GGA06M01_WORK_DTM         :=  SYSDATE;                    --처리일시
                T_GGA06M01_WORK_TRM         :=  T_GGA06M00_WORK_TRM;        --처리단말
                T_GGA06M01_RECV_ACC_RMRK_CD := C2.OPR_ACC_RMRK_CD;         --수신적요코드
--pxc_log_write('pgg_create_voucher','T_GGA06M01_RECV_SND_NO      =['||T_GGA06M01_RECV_SND_NO      ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_SLIP_DT          =['||T_GGA06M01_SLIP_DT          ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_BRCH_CD          =['||T_GGA06M01_BRCH_CD          ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_AGNC_BRCH        =['||T_GGA06M01_AGNC_BRCH        ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_SLIP_NO          =['||T_GGA06M01_SLIP_NO          ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_SLIP_SUB_NO      =['||T_GGA06M01_SLIP_SUB_NO      ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_RECV_SLIP_DT     =['||T_GGA06M01_RECV_SLIP_DT     ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_RECV_BNH_CD      =['||T_GGA06M01_RECV_BNH_CD      ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_RECV_AGNC_BRCH   =['||T_GGA06M01_RECV_AGNC_BRCH   ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_RECV_SLIP_NO     =['||T_GGA06M01_RECV_SLIP_NO     ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_RECV_SLIP_SUB_NO =['||T_GGA06M01_RECV_SLIP_SUB_NO ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_RECV_ACT_CD      =['||T_GGA06M01_RECV_ACT_CD      ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_RECV_YN          =['||T_GGA06M01_RECV_YN          ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_RECV_ACC_RMRK_CD =['||T_GGA06M01_RECV_ACC_RMRK_CD ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_WORK_MN          =['||T_GGA06M01_WORK_MN          ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_WORK_DTM         =['||T_GGA06M01_WORK_DTM         ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_WORK_TRM         =['||T_GGA06M01_WORK_TRM         ||']');

                --발신내역 INSERT
                INSERT  INTO    GGA06M01
                (
                     RECV_SND_NO          --수신발신번호
                    ,SLIP_DT              --전표일자
                    ,BRCH_CD              --지점코드
                    ,AGNC_BRCH            --대리지점
                    ,SLIP_NO              --전표번호
                    ,SLIP_SUB_NO          --전표부번호
                    ,RECV_SLIP_DT         --수신전표일자
                    ,RECV_BNH_CD          --수신부점코드
                    ,RECV_AGNC_BRCH       --수신대리지점
                    ,RECV_SLIP_NO         --수신전표번호
                    ,RECV_SLIP_SUB_NO     --수신전표부번호
                    ,RECV_ACT_CD          --수신계정코드
                    ,RECV_YN              --수신여부
                    ,RECV_ACC_RMRK_CD     --수신적요
                    ,WORK_MN              --처리자
                    ,WORK_DTM             --처리일시
                    ,WORK_TRM             --처리단말
                )
                VALUES
                (
                     T_GGA06M01_RECV_SND_NO       --발신번호
                    ,T_GGA06M01_SLIP_DT           --전표일자
                    ,T_GGA06M01_BRCH_CD           --발신지점
                    ,T_GGA06M01_AGNC_BRCH         --발신지점(출장소)
                    ,T_GGA06M01_SLIP_NO           --전표번호
                    ,T_GGA06M01_SLIP_SUB_NO       --전표부번호
                    ,T_GGA06M01_RECV_SLIP_DT      --수신전표일자
                    ,T_GGA06M01_RECV_BNH_CD       --수신부점코드
                    ,T_GGA06M01_RECV_AGNC_BRCH    --수신대리지점
                    ,T_GGA06M01_RECV_SLIP_NO      --수신전표번호
                    ,T_GGA06M01_RECV_SLIP_SUB_NO  --수신전표부번호
                    ,T_GGA06M01_RECV_ACT_CD       --수신계정코드
                    ,T_GGA06M01_RECV_YN           --수신여부
                    ,T_GGA06M01_RECV_ACC_RMRK_CD  --수신적요
                    ,T_GGA06M01_WORK_MN           --처리자
                    ,T_GGA06M01_WORK_DTM          --처리일시
                    ,T_GGA06M01_WORK_TRM          --처리단말
                );



                T_GGA06M00_RECV_SND_NO  :=  T_GGA06M01_RECV_SND_NO;           --수신발신번호


                --발신정보 이므로 전표정보에 수발신 번호 UPDATE
                UPDATE GGA06M00
                   SET RECV_SND_NO = T_GGA06M00_RECV_SND_NO     --수발신번호
                 WHERE SLIP_DT     = T_GGA06M00_SLIP_DT         --전표일자
                   AND BRCH_CD     = T_GGA06M00_BRCH_CD         --지점코드
                   AND AGNC_BRCH   = T_GGA06M00_AGNC_BRCH       --대리지점
                   AND SLIP_NO     = T_GGA06M00_SLIP_NO         --전표번호
                   AND SLIP_SUB_NO = T_GGA06M00_SLIP_SUB_NO;    --전표부번호

            --수신전표 인경우 수신정보 전표에 반영
            ELSIF    C2.RECV_SND_TP  =   '2' THEN

                --수신전표에 발신전표 정보를 UPDATE 해야 하나 발신정보를 구하기 힘듦으로 PGG_JOB_RECV_SND_SLIP.SQL에서 처리함
                NULL;

            END IF; -- END OF 발신/수신



            --C2 COUNTER +1
            T_C2_CNT    :=  T_C2_CNT + 1;

        END LOOP;   -- END OF C2

        --적요가 존재하지 않는다면?
        IF T_C2_CNT = 1 THEN
            RAISE_APPLICATION_ERROR(-20001,'Dinh Khoan ['|| I_ACC_RMRK_CD ||'] is not defined!!!');
        END IF;

        -- =============
        -- 전표승인처리 : GGA08M00(DAILY STATISTICS) APPLY , 전표상태 ==> 승인(2)
        -- 일계반영
        -- =============
        PGG_SLIP_APPROVAL
        (
            'A'                     -- 'A' : Approval, 'C' : Approval Cancel, 'R' :Return, 'X' : DisUse
           ,T_GGA06M00_BRCH_CD      -- PROCESSING BRANCH CODE
           ,T_GGA06M00_AGNC_BRCH    -- PROCESSING BRANCH CODE(AGNC)
           ,T_GGA06M00_SLIP_DT      -- SLIP DATE
           ,T_GGA06M00_SLIP_NO      -- SLIP No.
           ,'SYSTEM'
        );

--pxc_log_write('pgg_create_voucher','  PGG_SLIP_APPROVAL =[<<  >>]');


    -- OUT Variable
    O_SLIP_NO   :=  T_GGA06M00_SLIP_NO;




END PGG_CREATE_VOUCHER;    -- END OF Main
/

