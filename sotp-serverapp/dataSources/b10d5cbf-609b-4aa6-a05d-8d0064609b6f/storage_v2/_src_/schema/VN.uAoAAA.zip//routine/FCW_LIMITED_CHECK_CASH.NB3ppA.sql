create function fcw_limited_check_cash
(
  i_acnt_no in varchar2,
  i_cash    in    number
) return varchar2 as
o_total_cash number;
o_total_cash_free number;
o_cash_trans_limit number;
/* ===========================================
  -- Program ID     :
  -- Date of Program  :   06/04/2018
  -- Programmer    :  hieu.dt
  -- Description     :
      input  :  acnt_no
      return :  Y for deposit or N nondeposit
   =========================================== */
begin

  begin
  select nvl(sum(trd_amt),0)
      into o_total_cash
    from vn.cwd06m00 v
    where v.acnt_no = i_acnt_no
      and v.CNCL_YN='N'
      and v.inout_tp='02'
      and v.MDM_TP <> '00';

    o_total_cash_free:=o_total_cash+i_cash;



  exception
  when   no_data_found then
    return   'Y';
  end;
      begin
      select to_number(COL_CD_TP)
      into o_cash_trans_limit
     from vn.XCC01c01 t
    where col_cd like 'cash_trans_limit_eq';
        exception
      when   no_data_found then
        return   'Y';
      end;

  if o_total_cash_free  > o_cash_trans_limit then
        return 'N';
        else
          return 'Y';
      end if;


end ;
/

