create function fcw_chk_time
(
	i_tp		in		varchar2
) return varchar2 as

	o_val	    number;
	o_check     number;
	o_st_time   number;
	o_end_time  number;

begin

	select to_number(to_char(st_time,'hh24miss'))
	      ,to_number(to_char(end_time,'hh24miss'))
	  into o_st_time
		  ,o_end_time
	  from vn.cwd07m40
	 where cls_dt = '30000101';

	if i_tp = '1' then

	   select to_number(to_char(sysdate, 'hh24miss'))
		 into o_check
		 from dual;

       if( o_check < o_st_time or o_check > o_end_time) then

		 return 'N';

       else

		 return 'Y';

	   end if;

    end if;

return 'Y';

end ;
/

