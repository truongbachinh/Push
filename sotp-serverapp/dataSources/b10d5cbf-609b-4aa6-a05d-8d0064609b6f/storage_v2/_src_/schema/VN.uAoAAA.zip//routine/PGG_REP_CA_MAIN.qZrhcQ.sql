create PROCEDURE    PGG_REP_CA_MAIN
   (I_WORK_TRM      IN      VARCHAR2,       -- IP_ADDRESS
    I_BRCH_CD       IN      VARCHAR2,       -- 지점
    I_AGNC_BRCH     IN      VARCHAR2,       -- 대리지점
    I_CLS_DT        IN      VARCHAR2,       -- 기준일자(시작일)
    I_CLS_DT2       IN      VARCHAR2,       -- 기준일자(종료일)
    I_CLS2_DT       IN      VARCHAR2,       -- 기준일자(시작일)
    I_CLS2_DT2      IN      VARCHAR2,       -- 기준일자(종료일)
    I_FRM_NO        IN      VARCHAR2,       -- 양식번호
    I_FS_TP         IN      VARCHAR2,		-- 10:대차대조표
    I_WORK_MN       IN      VARCHAR2        -- 처리자
	) IS

    -- Variables
    T_PRE_DT    VARCHAR2(8);   -- 전(일,월,기)
    T_CUR_DT    VARCHAR2(8);   -- 전(일,월,기)

BEGIN

    -- 당(일,월,기) 자료 생성
    VN.PGG_REP_CA_SUB(
        I_WORK_TRM,     -- IP_ADDRESS
        I_BRCH_CD,      -- 지점
        I_AGNC_BRCH,    -- 대리지점
        I_CLS_DT,       -- 기준일자
        I_CLS_DT2,      -- 기준일자
        '1',            -- 회기구분(1:당,2:전)
        I_WORK_MN,      -- 처리자
		I_FRM_NO,		-- 양식번호
        I_FS_TP);

    -- 전(일,월,기) 자료 생성
    --T_PRE_DT := VN.FGG_GET_TERMS_DT(VN.FGG_GET_TERMS(I_CLS2_DT), '1') ;
    VN.PGG_REP_CA_SUB(
        I_WORK_TRM,     -- IP_ADDRESS
        I_BRCH_CD,      -- 지점
        I_AGNC_BRCH,    -- 대리지점
        I_CLS2_DT,      -- 기준일자
        I_CLS2_DT2,     -- 기준일자
        '2',            -- 회기구분(1:당,2:전)
        I_WORK_MN,      -- 처리자
		I_FRM_NO,		-- 양식번호
        I_FS_TP);

    -- 누적(일,월,기) 자료 생성
    T_CUR_DT := VN.FGG_GET_TERMS_DT(VN.FGG_GET_TERMS(I_CLS_DT), '1') ;
    VN.PGG_REP_CA_SUB(
        I_WORK_TRM,     -- IP_ADDRESS
        I_BRCH_CD,      -- 지점
        I_AGNC_BRCH,    -- 대리지점
        T_CUR_DT,       -- 기준일자
        I_CLS_DT2,      -- 기준일자
        '3',            -- 회기구분(1:당,2:전)
        I_WORK_MN,      -- 처리자
		I_FRM_NO,		-- 양식번호
        I_FS_TP);

EXCEPTION WHEN OTHERS THEN
  RAISE_APPLICATION_ERROR(-20100,'P:'||SUBSTR(SQLERRM, 5, 78));
END PGG_REP_CA_MAIN;
/

