create function test_number_ret
return number
as

    o_ret number;
begin
    select 10E39 - 1 a
    into o_ret
    from dual;

    return o_ret; 
end;
/

