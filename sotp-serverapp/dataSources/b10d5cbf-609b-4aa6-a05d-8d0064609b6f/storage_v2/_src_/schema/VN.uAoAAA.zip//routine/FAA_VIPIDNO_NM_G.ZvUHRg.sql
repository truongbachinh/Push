create function faa_vipidno_nm_g
(
	i_idno		in		varchar2
) return varchar2 as

	o_vip_nm	varchar2(50);

/* ===========================================
	-- Program ID 		: 	faa_vipidno_nm_g
	-- Date of Program	: 	22/10/2007
	-- Programmer		:	mkkim
	-- Description 		:

   =========================================== */
begin

		if i_idno ='SME' then
			return 'SME';
		end if;


		begin
		select	nvl(cust_nm,'!')
		into	o_vip_nm
		from	vn.aaa90m00
		where vip_idno = i_idno
		and   del_yn ='N';

			return o_vip_nm;

		exception
		when	 no_data_found then
			return 	'!';
		end;


end ;
/

