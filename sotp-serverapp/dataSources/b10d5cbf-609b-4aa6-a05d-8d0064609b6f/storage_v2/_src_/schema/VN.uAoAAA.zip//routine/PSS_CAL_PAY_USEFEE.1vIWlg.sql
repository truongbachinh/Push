create PROCEDURE PSS_CAL_PAY_USEFEE
   (I_ACNT_NO       IN      VARCHAR2,
    I_SUB_NO        IN      VARCHAR2,
    I_MAK_STRT_DT   IN      VARCHAR2,
    I_MAK_END_DT    IN      VARCHAR2,
    I_TOT_DT_CNT    IN      NUMBER,
    I_TOT_QTY       IN      NUMBER,
    I_TOT_AVBL_QTY  IN      NUMBER,
    I_USEFEE        IN      NUMBER,
    I_TR_CD       	IN      VARCHAR2,       -- Screen number
    I_DEPT_NO1    	IN      VARCHAR2,
    I_WORK_MN       IN      VARCHAR2,
    I_WORK_TRM      IN      VARCHAR2,       -- IP_ADDRESS
    O_RTN_TBL       OUT     VARCHAR2,       -- Return Table
    O_RTN_ERR       OUT     VARCHAR2,       -- Return Error Code
    O_RTN_MSG       OUT     VARCHAR2        -- Return Message
	) IS


    t_sec_cd VARCHAR2(3) := vn.fxc_sec_cd('R');
    K_RMRK_CD       VARCHAR2(3) := '247' ; 				-- Remark code
    K_MDM_TP        VARCHAR2(2) := '00' ; 				--
    K_CNFM_YN       VARCHAR2(1) := 'Y' ; 				--


    T_CNT           NUMBER := 0 ;						-- CHECK Count
    T_PROC_CNT      NUMBER := 0 ;						-- Processed count

    O_TRD_SEQ_NO	  NUMBER;
    O1_RTN_TBL      VARCHAR2(100) ;      				-- Return Table
    O1_RTN_ERR      VARCHAR2(100) ;      				-- Return Error Code
    O1_RTN_MSG      VARCHAR2(254) ;      				-- Return Message

    v_avail_depo_fee         number :=0;


    -- Exceptions Declare
    ERR_SSB07M00_UPD    	EXCEPTION ;			--  Payment account saving
    ERR_SSB07M00_INS    	EXCEPTION ;			--  Payment account making
    ERR_SSB07M00_CONT    	EXCEPTION ;			--  Paymnet error contents
    ERR_SSB07M00_TRD    	EXCEPTION ;			-- Payment trading sequence
    ERR_PSS_USEFEE_PAY_P	EXCEPTION ;


-- *************************< START OF PROCEDURE >****************************
BEGIN

  Select count(*)
    Into T_CNT
    From vn.ssb07m00
   Where acnt_no = I_acnt_no
	   And sub_no = I_sub_no
     And mak_strt_dt = I_MAK_STRT_DT
     And cncl_yn = 'N'
	   And rcpt_trd_no = 0;

  If T_CNT > 0 Then

      UPDATE	VN.SSB07M00
        SET	MAK_END_DT		=	I_MAK_END_DT,
            TOT_DT_CNT		=	I_TOT_DT_CNT,
            TOT_QTY			  =	I_TOT_QTY,
            TOT_AVBL_QTY	=	I_TOT_AVBL_QTY,
            APY_INT_RT		=	0,
            USEFEE			  =	I_USEFEE,
            ACNT_MNG_BNH	=	faa_acnt_bnh_cd_g('0',i_acnt_no ,i_sub_no),
            AGNC_BRCH		  =	faa_acnt_bnh_cd_g('3',i_acnt_no ,i_sub_no),
            WORK_MN			  =	I_WORK_MN,
            WORK_DTM		  =	SYSDATE,
            WORK_TRM		  =	I_WORK_TRM
       WHERE	ACNT_NO			=	I_ACNT_NO
         AND  SUB_NO      = I_SUB_NO
         AND  MAK_STRT_DT = I_MAK_STRT_DT
         AND	RCPT_TRD_NO	=	0
         AND	CNCL_TRD_NO	=	0 ;


  Else
      Begin
        INSERT	INTO VN.SSB07M00(
                USEFEE_PAY_DT,
                ACNT_NO,
                SUB_NO,
                MAK_STRT_DT,
                MAK_END_DT,
                TOT_DT_CNT,
                TOT_QTY,
                TOT_AVBL_QTY,
                APY_INT_RT,
                USEFEE,
                ACNT_MNG_BNH,
                AGNC_BRCH,
                RCPT_TRD_NO,
                ERR_CONT,
                CNCL_YN,
                CNCL_TRD_NO,
                WORK_MN,
                WORK_DTM,
                WORK_TRM )
                  VALUES  (
                vn.vwdate,
                I_ACNT_NO,
                I_SUB_NO,
                I_MAK_STRT_DT,
                I_MAK_END_DT,
                I_TOT_DT_CNT,
                I_TOT_QTY,
                I_TOT_AVBL_QTY,
                0,
                I_USEFEE,
                faa_acnt_bnh_cd_g('0',i_acnt_no ,i_sub_no),
                faa_acnt_bnh_cd_g('3',i_acnt_no ,i_sub_no),
                0,
                NULL,
                'N',
                0,
                I_WORK_MN,
                SYSDATE,
                I_WORK_TRM ) ;

        EXCEPTION WHEN OTHERS THEN
            RAISE ERR_SSB07M00_INS ;
        END ;
	 END IF ;

  T_PROC_CNT := T_PROC_CNT + 1 ;

  O_TRD_SEQ_NO	:=	0 ;
  O1_RTN_TBL		:=	NULL ;
  O1_RTN_ERR		:=	NULL ;
  O1_RTN_MSG		:=	NULL ;

  /* 2. Call withdrawal procedure */
  v_avail_depo_fee := vn.fcw_avail_cash_depo_fee(t_sec_cd,I_ACNT_NO,I_SUB_NO);
  if (v_avail_depo_fee >= I_USEFEE and I_USEFEE > 0) then
    VN.PSS_CASH_OUTAMT_P(
                          VN.VWDATE,
                          I_ACNT_NO,
                          I_SUB_NO,
                          K_RMRK_CD,
                          I_USEFEE,
                          K_MDM_TP,
                          I_TR_CD,
                          --K_CNFM_YN,
                          substr(I_MAK_STRT_DT,5,2) || '/' || substr(I_MAK_STRT_DT,1,4),
                          I_DEPT_NO1,
                          I_WORK_MN,
                          I_WORK_TRM,
                          O_TRD_SEQ_NO,
                          O1_RTN_TBL,
                          O1_RTN_ERR,
                          O1_RTN_MSG
    ) ;
  end if;

  IF	TO_NUMBER(O1_RTN_ERR)	<>	0	THEN /* 3. ERROR */

      vn.pxc_log_write('PSS_CAL_PAY_USEFEE', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG|| ']') ;

      BEGIN

      UPDATE	VN.SSB07M00
         SET	RCPT_TRD_NO		=	0,
              ERR_CONT		=	SUBSTR('[' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG || ']', 1, 254)
       WHERE	ACNT_NO			=	I_ACNT_NO
         AND  SUB_NO      = I_SUB_NO
         AND  MAK_STRT_DT = I_MAK_STRT_DT
         AND	RCPT_TRD_NO	=	0
         AND	CNCL_TRD_NO	=	0 ;

      EXCEPTION WHEN OTHERS THEN
          RAISE ERR_SSB07M00_CONT ;
      END ;

  ELSE /* 3. NO ERROR AND Withdrawal trading sequence */
      BEGIN

      UPDATE	VN.SSB07M00
        SET	  RCPT_TRD_NO	=	O_TRD_SEQ_NO,
              ERR_CONT		=	NULL
       WHERE	ACNT_NO			=	I_ACNT_NO
         AND  SUB_NO      = I_SUB_NO
         AND  MAK_STRT_DT = I_MAK_STRT_DT
         AND	RCPT_TRD_NO	=	0
         AND	CNCL_TRD_NO	=	0 ;

      EXCEPTION WHEN OTHERS THEN
          RAISE ERR_SSB07M00_TRD ;
      END ;

  END IF ;

  O_RTN_TBL  :=  'PSS_CAL_PAY_USEFEE' ;
  O_RTN_ERR  :=  '0' ;
  O_RTN_MSG  :=  SUBSTR('PAY_YM:(' || SUBSTR(I_MAK_STRT_DT,1,6) || ') Count:(' || TO_CHAR(T_PROC_CNT) || ') ????? ???????.', 1, 254) ;
	vn.pxc_log_write('PSS_CAL_PAY_USEFEE', ' [' || O_RTN_ERR || '] [' || O_RTN_TBL || '] [' || O_RTN_MSG|| ']') ;


EXCEPTION
    WHEN    ERR_SSB07M00_UPD  THEN
        O_RTN_TBL  :=  'ERR_SSB07M00_UPD' ;
        O_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O_RTN_MSG  :=  SUBSTR('ERROR ' || 'PAY_YM:(' || SUBSTR(I_MAK_STRT_DT,1,6)  || ') ACNT_NO:(' || I_ACNT_NO||'-'||I_SUB_NO || ')', 1, 254) ;
		vn.pxc_log_write('PSS_CAL_PAY_USEFEE', ' [' || O_RTN_ERR || '] [' || O_RTN_TBL || '] [' || O_RTN_MSG|| ']') ;

    WHEN    ERR_SSB07M00_INS  THEN
        O_RTN_TBL  :=  'ERR_SSB07M00_INS' ;
        O_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O_RTN_MSG  :=  SUBSTR('ERROR ' || 'PAY_YM:(' || SUBSTR(I_MAK_STRT_DT,1,6)  || ') ACNT_NO:(' || I_ACNT_NO||'-'||I_SUB_NO || ')', 1, 254) ;
        vn.pxc_log_write('PSS_CAL_PAY_USEFEE', ' [' || O_RTN_ERR || '] [' || O_RTN_TBL || '] [' || O_RTN_MSG|| ']') ;

    WHEN    ERR_SSB07M00_CONT  THEN
        O_RTN_TBL  :=  'ERR_SSB07M00_CONT' ;
        O_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O_RTN_MSG  :=  SUBSTR('ERROR ' || 'PAY_YM:(' || SUBSTR(I_MAK_STRT_DT,1,6)  || ') ACNT_NO:(' || I_ACNT_NO||'-'||I_SUB_NO || ')', 1, 254) ;
		vn.pxc_log_write('PSS_CAL_PAY_USEFEE', ' [' || O_RTN_ERR || '] [' || O_RTN_TBL || '] [' || O_RTN_MSG|| ']') ;

    WHEN    ERR_SSB07M00_TRD  THEN
        O_RTN_TBL  :=  'ERR_SSB07M00_TRD' ;
        O_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O_RTN_MSG  :=  SUBSTR('ERROR ' || 'PAY_YM:(' || SUBSTR(I_MAK_STRT_DT,1,6)  || ') ACNT_NO:(' || I_ACNT_NO||'-'||I_SUB_NO || ')', 1, 254) ;
        vn.pxc_log_write('PSS_CAL_PAY_USEFEE', ' [' || O_RTN_ERR || '] [' || O_RTN_TBL || '] [' || O_RTN_MSG|| ']') ;

    WHEN    OTHERS  THEN
        O_RTN_TBL  :=  'OTHERS [PSS_CAL_PAY_USEFEE]' ;
        O_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O_RTN_MSG  :=  SUBSTR('ERROR ' || SQLERRM, 1, 254) ;
		    vn.pxc_log_write('PSS_CAL_PAY_USEFEE', ' [' || O_RTN_ERR || '] [' || O_RTN_TBL || '] [' || O_RTN_MSG|| ']') ;

END PSS_CAL_PAY_USEFEE ;
/

