create FUNCTION    fdl_get_mrgn_grp_acnt_rt
(
    i_acnt_no        IN   VARCHAR2, 
    i_sub_no         IN   VARCHAR2,
    i_grp_acnt_no    IN   VARCHAR2,
    i_rt_tp          IN   VARCHAR2,
    i_apy_dt         IN   VARCHAR2
)   RETURN  NUMBER AS
/*!
   \file     fdl_get_mrgn_grp_acnt_rt.sql
   \brief    margin information
   \modify   20180604 hoang nguyen
*/

    t_gen_chk       NUMBER          := -1;
    t_priv_chk      NUMBER          := -1;
    t_err_msg       VARCHAR2(500)   := '';
    t_gen_rate      NUMBER          := NULL; 
    t_priv_rate     NUMBER          := NULL; 
    t_col_cd        VARCHAR2(100)   := NULL;
    t_default_rt    NUMBER          := 0;
    o_out_number    NUMBER          := 0; 

BEGIN
/* 
    ******************************************** Cac tham so cua nhom Margin 
    01: mrgn_frce_rt            - ti le force cell                          - FMR Nhom margin (dlm71m01/dlm71m00)
    02: mrgn_eval_rt            - he so danh gia khach hang                 - CER Nhom margin (dlm71m01/dlm71m00)
    03: mrgn_mntn_rt            - ti le duy tri toi thieu cua tai khoan     - MMR Nhom margin (dlm71m01/dlm71m00)
    04: mrgn_call_rt            - ti le call margin                         - LMR Nhom margin (dlm71m01/dlm71m00)
    05: mrgn_with_rt            - ti le rut tien                            - CWR Nhom margin (dlm71m01/dlm71m00)
    06: mrgn_imr_rt             - IMR ti le ky quy ban dau                  - IMR Nhom margin (dlm71m01/dlm71m00)
*/

    /* ********************************************************************************************
        Quy tac lay data
            - 1. Neu i_grp_acnt_no IS NULL  --> return default value
            - 2. Neu ko co CSC tai ngay tra cuu, thi lay CSC cua ngay ap dung gan nhat
                + Neu ko co CSC nao         --> return default value
            - 3. Neu co CSC:
                + Neu co CSR                --> Lay CSR
                + Neu ko co CRS             --> Lay CSC
    **********************************************************************************************/

    IF  (i_rt_tp  in ('01','02','03','04','05','06')) THEN
        -- Lay gia tri mac dinh
        BEGIN
            SELECT DECODE(i_rt_tp,  '01', 'df_mrgn_frce_rt',
                                    '02', 'df_mrgn_eval_rt',
                                    '03', 'df_mrgn_mntn_rt',
                                    '04', 'df_mrgn_call_rt',
                                    '05', 'df_mrgn_with_rt',
                                    '06', 'df_mrgn_imr_rt')
            INTO t_col_cd
            FROM DUAL;

            SELECT 
                TO_NUMBER(col_cd_tp)
            INTO 
                t_default_rt
            FROM vn.xcc01c02
            WHERE col_cd = t_col_cd;

        EXCEPTION WHEN OTHERS THEN 
            t_err_msg := vn.fxc_get_err_msg('V','460000');
            vn.pxc_log_write('pdl_get_mrgn_grp_acnt_rt',     'Loi khi lay gia tri mac dinh cho:'
                                                    || ' i_acnt_no = '      || i_acnt_no || '-' || ' i_sub_no=' || i_sub_no
                                                    || ' i_grp_acnt_no = '  || i_grp_acnt_no || ' i_apy_dt = '  || i_apy_dt
                            );

            raise_application_error(-20100, t_err_msg   || ' pdl_get_mrgn_grp_acnt_rt: Loi khi lay gia tri mac dinh cho:'
                                                    || ' i_acnt_no = '      || i_acnt_no || '-' || ' i_sub_no=' || i_sub_no
                                                    || ' i_grp_acnt_no = '  || i_grp_acnt_no || ' i_apy_dt = '  || i_apy_dt
                                    );
        END;

        -- Kiem tra nhom tk
        IF(i_grp_acnt_no IS NULL) THEN
            SELECT t_default_rt
            INTO o_out_number
            FROM dual;

            RETURN o_out_number;

        ELSE    -- Nhom tk NOT NULL
            -- 1. Lay chinh sach chung
            BEGIN
                t_gen_chk := 1;

                -- Truong hop cac ti le de NULL thi se lay mac dinh
                SELECT DECODE(i_rt_tp,  '01', nvl(mrgn_frce_rt, t_default_rt), -- ti le force cell                     
                                        '02', nvl(mrgn_eval_rt, t_default_rt), -- he so danh gia khach hang             
                                        '03', nvl(mrgn_mntn_rt, t_default_rt), -- ti le duy tri toi thieu cua tai khoan
                                        '04', nvl(mrgn_call_rt, t_default_rt), -- ti le call margin                    
                                        '05', nvl(mrgn_with_rt, t_default_rt), -- ti le rut tien                       
                                        '06', nvl(mrgn_imr_rt , t_default_rt)  -- IMR ti le ky quy ban dau                  
                            ) 
                INTO t_gen_rate
                FROM vn.DLM71M00
                WHERE grp_acnt_no = i_grp_acnt_no
                AND apy_dt <= i_apy_dt
                AND expr_dt >= i_apy_dt
                AND active_stat = 'Y';
            EXCEPTION 
                WHEN NO_DATA_FOUND THEN
                    t_gen_chk := 0;

                    -- Neu ko co CSC tai ngay tra cuu, thi lay setup cua ngay ap dung gan nhat
                    BEGIN
                        -- Truong hop cac ti le de NULL thi se lay mac dinh
                        SELECT DECODE(i_rt_tp,  '01', nvl(mrgn_frce_rt, t_default_rt), -- ti le force cell                     
                                                '02', nvl(mrgn_eval_rt, t_default_rt), -- he so danh gia khach hang             
                                                '03', nvl(mrgn_mntn_rt, t_default_rt), -- ti le duy tri toi thieu cua tai khoan
                                                '04', nvl(mrgn_call_rt, t_default_rt), -- ti le call margin                    
                                                '05', nvl(mrgn_with_rt, t_default_rt), -- ti le rut tien                       
                                                '06', nvl(mrgn_imr_rt , t_default_rt)  -- IMR ti le ky quy ban dau                  
                                    )
                        INTO t_gen_rate
                        FROM vn.DLM71M00
                        WHERE grp_acnt_no = i_grp_acnt_no
                          AND active_stat = 'Y'
                          AND apy_dt = (SELECT MAX(apy_dt)
                                        FROM vn.DLM71M00
                                        WHERE grp_acnt_no = i_grp_acnt_no
                                          AND active_stat = 'Y'
                                          AND apy_dt < i_apy_dt);
                    EXCEPTION 
                        WHEN NO_DATA_FOUND THEN
                            -- Truong hop tai khoan khong thuoc nhom Margin thi cac te le lay mac dinh
                            SELECT t_default_rt
                            INTO t_gen_rate
                            FROM dual;
                    END;

            WHEN OTHERS THEN 
                t_err_msg := vn.fxc_get_err_msg('V','460000');
                vn.pxc_log_write('fdl_get_mrgn_grp_acnt_rt',   'Loi khi lay chinh sach chung cho :'
                                                            || ' i_acnt_no = '  || i_acnt_no || '-' || ' i_sub_no=' || i_sub_no
                                                            || ' i_rt_tp = '    || i_rt_tp
                                );

                raise_application_error(-20100, t_err_msg   || ' fdl_get_mrgn_grp_acnt_rt: Loi khi lay chinh sach chung cho:'
                                                            || ' i_acnt_no = '  || i_acnt_no || '-' || ' i_sub_no=' || i_sub_no
                                                            || ' i_rt_tp = '    || i_rt_tp
                                        );
            END;

            -- 2. Neu co CSC, kiem tra xem co CSR hay khong
            IF(t_gen_chk = 1) THEN
                BEGIN 
                    t_priv_chk := 1;

                    SELECT DECODE(i_rt_tp,  '01',mrgn_frce_rt, -- ti le force cell                     
                                            '02',mrgn_eval_rt, -- he so danh gia khach hang             
                                            '03',mrgn_mntn_rt, -- ti le duy tri toi thieu cua tai khoan
                                            '04',mrgn_call_rt, -- ti le call margin                    
                                            '05',mrgn_with_rt, -- ti le rut tien                       
                                            '06',mrgn_imr_rt   -- IMR ti le ky quy ban dau                  
                                ) 
                    INTO t_priv_rate
                    FROM vn.DLM71M01
                    WHERE acnt_no   =  i_acnt_no
                    AND sub_no      =  i_sub_no
                    AND grp_acnt_no =  i_grp_acnt_no
                    AND apy_dt      <= i_apy_dt
                    AND expr_dt     >= i_apy_dt
                    AND active_stat  = 'Y';
                EXCEPTION 
                    WHEN NO_DATA_FOUND THEN
                        t_priv_chk := 0;

                    WHEN OTHERS THEN
                        t_err_msg := vn.fxc_get_err_msg('V','461000');
                        vn.pxc_log_write('fdl_get_mrgn_grp_acnt_rt',   'Loi khi lay chinh sach rieng cho'
                                                                    || ' i_acnt_no = '  || i_acnt_no || '-' || ' i_sub_no=' || i_sub_no
                                                                    || ' i_rt_tp = '    || i_rt_tp
                                        );

                        raise_application_error(-20100, t_err_msg   || ' fdl_get_mrgn_basket_rt: Loi khi lay chinh sach rieng cho'
                                                                    || ' i_acnt_no = '  || i_acnt_no || '-' || ' i_sub_no=' || i_sub_no
                                                                    || ' i_rt_tp = '    || i_rt_tp
                                                );
                END;
            END IF;

            IF t_priv_chk = 1 AND t_priv_rate IS NOT NULL THEN
                o_out_number := t_priv_rate;
            ELSE
                o_out_number := t_gen_rate;
            END IF;

            RETURN o_out_number;
        END IF; -- END: nhom TK NULL
    ELSE
        t_err_msg := 'Loi tham so i_rt_tp = '|| i_rt_tp || ' truyen vao khong co';
        vn.pxc_log_write('fdl_get_mrgn_grp_acnt_rt', t_err_msg);
        raise_application_error(-20100,t_err_msg);
    END IF;

END fdl_get_mrgn_grp_acnt_rt;
/

