create procedure psr_bat_bank
(
	i_proc_dt		        in		varchar2
,	i_acnt_no		        in		varchar2
,	i_sub_no		        in		varchar2
,	i_bank_cd		        in		varchar2
,	i_acnt_mng_bnh		    in		varchar2
,	i_agnc_brch		        in		varchar2
,	i_amt		            in		number
,   i_tax                   in      number
,	i_rmrk_cd		        in 	    varchar2
,	i_tax_rmrk		        in 	    varchar2
,   i_work_mn               in      varchar2
,   i_work_trm              in      varchar2
,   i_stk_cd                in      varchar2
,   i_rate                  in      number
,   i_std_dt                in      varchar2
,   i_job_tp                in      varchar2
,   o_trd_seq_no           out      number

) as

ts_next_dt   varchar2(8)  := NULL ;
t_tax_trd_seq_no  number := 0 ;
t_err_txt    varchar2(100) := NULL ;
t_err_msg   varchar2(500)  := NULL ;

t_tot_trd_seq_no  number := 0 ;

BEGIN

    if  i_work_mn  in ('DAILY','BATCH')    then
      begin
       select vn.fxc_vorderdt_g(to_date(i_proc_dt,'yyyymmdd'), 1 )
         into ts_next_dt
         from dual ;

      end ;
    else
      ts_next_dt:= i_proc_dt;
    end if;

	vn.pxc_log_write('psr_bat_bank','1');
	vn.pxc_log_write('psr_bat_bank','pay_dt - ' || ts_next_dt);
	vn.pxc_log_write('psr_bat_bank','amt - ' || i_amt);
	vn.pxc_log_write('psr_bat_bank','tax - ' || i_tax);

    begin
		vn.pds_dsc10m00_ins(
				                 ts_next_dt ,
                                 i_job_tp ,
                                 i_bank_cd ,
                                 i_acnt_no ,
                                 i_sub_no ,
								 ts_next_dt ,
								 ts_next_dt ,
								 '1' ,
                                 i_acnt_mng_bnh ,
                                 i_agnc_brch ,
								 '00' ,
								 '00',
							     i_stk_cd ,
								 1 ,   -- seq_no
								 i_amt ,
								 i_amt ,
								 0 ,
								 0 , -- tax
								 '00' , --lnd_tp
								 i_std_dt , --lnd_dt
								 i_std_dt ,
								 '0000' , -- i_lnd_bank_cd
								 0 ,
								 0 ,
								 0 ,
								 0 , -- qty
                                 i_work_mn ,
                                 i_work_trm
            );

       EXCEPTION

        WHEN  OTHERS         THEN
           vn.pxc_log_write('psr_bat_bank','pds_dsc10m00_ins sqlcode : '||' '||sqlcode);
      end ;


	  o_trd_seq_no := 0 ;

      vn.pxc_psb_seq_cret_p  (i_acnt_no, i_sub_no,  i_proc_dt, o_trd_seq_no, t_tot_trd_seq_no);

	   vn.pxc_log_write('psr_bat_bank','3');
	   vn.pxc_log_write('psr_bat_bank', 'trd_seq - ' || o_trd_seq_no);

        BEGIN
        insert  into  vn.aaa10m00
             (
                 acnt_no
                ,sub_no
                ,trd_dt
                ,tot_trd_seq_no
                ,trd_seq_no
                ,trd_tp
                ,rmrk_cd
                ,mdm_tp
                ,cncl_yn
                ,org_trd_no
                ,trd_amt
                ,cmsn
                ,adj_amt
                ,dpo_prerm
                ,dpo_nowrm
                ,acnt_mng_bnh
                ,agnc_brch
                ,work_bnh
                ,proc_agnc_brch
                ,work_mn
                ,work_dtm
                ,work_trm
				,stk_cd
				,rate
             )
        values
             (
                 i_acnt_no
                ,i_sub_no
                ,i_proc_dt
                ,t_tot_trd_seq_no
                ,o_trd_seq_no
                ,'62'
                ,i_rmrk_cd
                ,'00'
                ,'N'
                ,0
                ,i_amt + i_tax
                ,0
                ,i_amt + i_tax
                ,0
                ,0
                ,i_acnt_mng_bnh
                ,i_agnc_brch
                ,i_acnt_mng_bnh
                ,i_agnc_brch
                ,i_work_mn
                ,sysdate
                ,i_work_trm
				,i_stk_cd
				,i_rate
             );
    EXCEPTION
        WHEN  OTHERS         THEN
            t_err_txt  :=  'psr_bat_bank'
                   ||  'insert err (aaa10m00) :'
                   ||  to_char(sqlcode);
            vn.pxc_log_write('pcw_cash_inamt_p','i_acnt_no->'||i_acnt_no);
            vn.pxc_log_write('pcw_cash_inamt_p','i_proc_dt->'||i_proc_dt);
            vn.pxc_log_write('pcw_cash_inamt_p','t_tax_trd_seq_no->'||o_trd_seq_no);
            vn.pxc_log_write('pcw_cash_inamt_p','i_rmrk_cd->'||i_rmrk_cd);
            vn.pxc_log_write('pcw_cash_inamt_p','i_amt->'||i_amt);

            vn.pxc_log_write('psr_bat_bank','4 ->'||t_err_txt);

            t_err_msg := vn.fxc_get_err_msg('V','9405');
            raise_application_error(-20100,t_err_msg||t_err_txt);
    END;


    BEGIN
            vn.psr_gga07m00_ins_p  (
							ts_next_dt,
							'I',
							i_acnt_no,
							i_sub_no,
							o_trd_seq_no,
							0,
							i_rmrk_cd,
							i_amt+ i_tax ,
							i_work_mn,
							i_work_trm,
							i_bank_cd );
    EXCEPTION
        WHEN  OTHERS         THEN
            t_err_txt  :=  'psr_bat_bank'
                   ||  '회계처리-err:'
                   ||  sqlerrm;
         vn.pxc_log_write('psr_bat_bank','5 ->'||t_err_txt);
            t_err_msg := vn.fxc_get_err_msg('V','2731');
            raise_application_error(-20100,t_err_msg||t_err_txt);
    END;

    /* for tax */

   if i_tax > 0 then

	t_tax_trd_seq_no := 0 ;

    vn.pxc_psb_seq_cret_p  (i_acnt_no, i_sub_no,  i_proc_dt, t_tax_trd_seq_no, t_tot_trd_seq_no);

    vn.pxc_log_write('psr_bat_bank', 'trd_seq tax - ' || t_tax_trd_seq_no);

    BEGIN
     insert  into  vn.aaa10m00
         (
                 acnt_no
                ,sub_no
                ,trd_dt
                ,tot_trd_seq_no
                ,trd_seq_no
                ,trd_tp
                ,rmrk_cd
                ,mdm_tp
                ,cncl_yn
                ,org_trd_no
                ,trd_amt
                ,cmsn
                ,adj_amt
                ,dpo_prerm
                ,dpo_nowrm
                ,acnt_mng_bnh
                ,agnc_brch
                ,work_bnh
                ,proc_agnc_brch
                ,work_mn
                ,work_dtm
                ,work_trm
                ,stk_cd
				,rate
        )
      values
        (
                i_acnt_no
               ,i_sub_no
               ,i_proc_dt
               ,t_tot_trd_seq_no
               ,t_tax_trd_seq_no
               ,'63'
               ,i_tax_rmrk
               ,'00'
               ,'N'
               ,0
               ,i_tax
               ,0
               ,i_tax
               ,0
               ,0
               ,i_acnt_mng_bnh
               ,i_agnc_brch
               ,i_acnt_mng_bnh
               ,i_agnc_brch
               ,i_work_mn
               ,sysdate
               ,i_work_trm
               ,i_stk_cd
			   ,i_rate
       );
    EXCEPTION
        WHEN  OTHERS         THEN
            t_err_txt  :=  'psr_bat_bank'
                   ||  'insert err (aaa10m00) :'
                   ||  to_char(sqlcode);
            vn.pxc_log_write('pcw_cash_inamt_p','i_acnt_no->'||i_acnt_no);
            vn.pxc_log_write('pcw_cash_inamt_p','i_sub_no->'||i_sub_no);
            vn.pxc_log_write('pcw_cash_inamt_p','i_proc_dt->'||i_proc_dt);
            vn.pxc_log_write('pcw_cash_inamt_p','t_tax_trd_seq_no->'||t_tax_trd_seq_no);
            vn.pxc_log_write('pcw_cash_inamt_p','i_rmrk_cd->'||i_rmrk_cd);
            vn.pxc_log_write('pcw_cash_inamt_p','i_amt->'||i_amt);

            vn.pxc_log_write('psr_bat_bank','4 ->'||t_err_txt);

            t_err_msg := vn.fxc_get_err_msg('V','9405');
            raise_application_error(-20100,t_err_msg||t_err_txt);
    END;


    BEGIN
       vn.psr_gga07m00_ins_p  (
                         ts_next_dt,
                         'I',
                         i_acnt_no,
                         i_sub_no,
                         t_tax_trd_seq_no,
                         0,
                         i_tax_rmrk,
                         i_tax ,
                         i_work_mn,
                         i_work_trm,
                         i_bank_cd );
    EXCEPTION
        WHEN  OTHERS         THEN
            t_err_txt  :=  'psr_bat_bank'
                   ||  '회계처리-err:'
                   ||  sqlerrm;
         vn.pxc_log_write('psr_bat_bank','5 ->'||t_err_txt);
            t_err_msg := vn.fxc_get_err_msg('V','2731');
            raise_application_error(-20100,t_err_msg||t_err_txt);
    END;

   end if ;

end psr_bat_bank;
/

