create function faa_to_ddmmyyyy
(
	i_dt		in		varchar2
) return varchar2 as

	o_ddmmyyyy	varchar2(8);

/* ===========================================
	-- Program ID 		: 	faa_to_ddmmyyyy
	-- Date of Program	: 	22/10/2007
	-- Programmer		:	mkkim
	-- Description 		:
			input  :  yyyymmdd
			return :  ddmmyyyy
   =========================================== */

begin
		if lengthb(i_dt) = 8 then  --yyyymmdd -> ddmmyyyy
			return	substr(i_dt,7,2)||substr(i_dt,5,2)||substr(i_dt,1,4);
		elsif lengthb(i_dt) = 6 then  --yyyymm   -> mmyyyy
			return	substr(i_dt,5,2)||substr(i_dt,1,4);
		else
			return ' ';
		end if;
end ;
/

