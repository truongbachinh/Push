create PROCEDURE    PGG_ACT_SLIP_APPR
   (I_FLAG				IN      VARCHAR2,       -- I:처리,D:취소
    I_SLIP_DT			IN      VARCHAR2,       -- 전표일
    I_PROC_BRCH_CD		IN      VARCHAR2,       -- 처리지점
    I_PROC_AGNC_BRCH	IN      VARCHAR2,       -- 처리대리지점
    I_EXCH_BRCH_CD		IN      VARCHAR2,       -- 이체지점
    I_EXCH_AGNC_BRCH	IN      VARCHAR2,       -- 이체대리지점
    I_RMRK_JOB_TP		IN      VARCHAR2,       -- 적요업무구분('42')
    I_AST_LKND			IN      VARCHAR2,       -- 자산분류
    I_STAT_GU			IN      VARCHAR2,       -- 고정자산구분
    I_AST_SETL_TP		IN      VARCHAR2,       -- 자산결제구분
    I_ACC_ACT_CD		IN      VARCHAR2,       -- 회계계정코드
    I_DEPT_CD			IN      VARCHAR2,       -- 부서코드
    I_CUST_CD			IN      VARCHAR2,       -- 고객코드
    I_DR_AMT_01			IN      NUMBER,       	-- 차변금액01
    I_DR_AMT_02			IN      NUMBER,       	-- 차변금액02
    I_DR_AMT_03			IN      NUMBER,       	-- 차변금액03
    I_CR_AMT_01			IN      NUMBER,       	-- 대변금액01
    I_CR_AMT_02			IN      NUMBER,       	-- 대변금액02
    I_CR_AMT_03			IN      NUMBER,       	-- 대변금액03
    I_WORK_MN			IN      VARCHAR2,		-- 처리자
    I_WORK_TRM			IN      VARCHAR2,       -- IP_ADDRESS
    O_SLIP_NO			IN OUT  VARCHAR2,       -- 전표번호
    O_SLIP_SUB_NO		IN OUT  VARCHAR2,       -- 전표부번호
    O_SLIP_NO1			IN OUT  VARCHAR2,       -- 전표번호
    O_SLIP_SUB_NO1		IN OUT  VARCHAR2,       -- 전표부번호
    O_RTN_TBL			OUT     VARCHAR2,       -- Return Table
	O_RTN_ERR			OUT     VARCHAR2,       -- Return Error Code
	O_RTN_MSG			OUT     VARCHAR2        -- Return Message
	) IS

    -- Constants

    -- Variables
    T_TERMS         NUMBER := VN.FGG_GET_TERMS(I_SLIP_DT); -- 회계기수
    T_LAST_DAY      VARCHAR2(8) := TO_CHAR(LAST_DAY(TO_DATE(I_SLIP_DT, 'YYYYMMDD')), 'YYYYMMDD') ;   -- 당월마지막일

    T_CNT           NUMBER := 0;
    T_PROC_CNT      NUMBER := 0;

	T_ACC_RMRK_CD		VN.GGA06M00.ACC_RMRK_CD%TYPE;			-- 회계적요코드
    T_RMRK_TRD_TP		VARCHAR2(3) ;
    T_ABNH_TP			VARCHAR2(2) := '10' ;


    O1_RTN_TBL      VARCHAR2(100) ;      				-- Return Table
	O1_RTN_ERR      VARCHAR2(100) ;      				-- Return Error Code
	O1_RTN_MSG      VARCHAR2(254) ;      				-- Return Message


    -- Exceptions Declare
    ERR_GGA11M00_1				EXCEPTION;
    ERR_GGA10M00				EXCEPTION;
    ERR_GGA22M01				EXCEPTION;
    ERR_GGA23M00				EXCEPTION;
    ERR_PGG_MANUAL_VOUCHER		EXCEPTION;
    ERR_PGG_CNCL_VOUCHER		EXCEPTION;

-- *************************< START OF PROCEDURE >****************************
BEGIN

	-- 신규취득
    IF  I_STAT_GU  =   'A' THEN
		NULL;

	-- 자본적지출
    ELSIF   I_STAT_GU  =   'B' THEN
		NULL;

	-- 감가상각
    ELSIF   I_STAT_GU  =   'C' THEN
	    IF  SUBSTR(I_AST_LKND, 1, 1)  =   '1' THEN
	    	IF  I_AST_SETL_TP  =   '1' THEN
				T_RMRK_TRD_TP	:=	'710' ;
		    ELSE
				T_RMRK_TRD_TP	:=	'720' ;
	    	END IF;
	    ELSE
	    	IF  I_AST_SETL_TP  =   '1' THEN
				T_RMRK_TRD_TP	:=	'711' ;
		    ELSE
				T_RMRK_TRD_TP	:=	'721' ;
	    	END IF;
	    END IF;
		T_ABNH_TP	:=	'10' ;

	-- 이수관
    ELSIF   I_STAT_GU  =   'D' THEN
	    IF  SUBSTR(I_AST_LKND, 1, 1)  =   '1' THEN
	    	IF  I_AST_SETL_TP  =   '0' THEN
				T_RMRK_TRD_TP	:=	'510' ;
		    ELSIF   I_AST_SETL_TP  =   '1' THEN
				T_RMRK_TRD_TP	:=	'511' ;
	    	END IF;
	    ELSIF   SUBSTR(I_AST_LKND, 1, 1)	=	'3' THEN
	    	IF  I_AST_SETL_TP  =   '0' THEN
				T_RMRK_TRD_TP	:=	'520' ;
		    ELSIF   I_AST_SETL_TP  =   '1' THEN
				T_RMRK_TRD_TP	:=	'521' ;
	    	END IF;
	    ELSE
	    	IF  I_AST_SETL_TP  =   '0' THEN
				T_RMRK_TRD_TP	:=	'510' ;
		    ELSIF   I_AST_SETL_TP  =   '1' THEN
				T_RMRK_TRD_TP	:=	'511' ;
	    	END IF;
	    END IF;
 		T_ABNH_TP	:=	'20' ;

	-- 이수관
    ELSIF   I_STAT_GU  =   'E' THEN
	    IF  SUBSTR(I_AST_LKND, 1, 1)  =   '1' THEN
			T_RMRK_TRD_TP	:=	'510' ;
	    ELSIF   SUBSTR(I_AST_LKND, 1, 1)	=	'3' THEN
			T_RMRK_TRD_TP	:=	'520' ;
	    ELSE
			T_RMRK_TRD_TP	:=	'510' ;
	    END IF;
 		T_ABNH_TP	:=	'30' ;

	-- 타계정대체입
	ELSIF   I_STAT_GU  =   'F' THEN
	    IF  SUBSTR(I_AST_LKND, 1, 1)  =   '1' THEN
			T_RMRK_TRD_TP	:=	'611' ;
	    ELSIF   SUBSTR(I_AST_LKND, 1, 1)	=	'3' THEN
			T_RMRK_TRD_TP	:=	'611' ;
	    ELSE
			T_RMRK_TRD_TP	:=	'611' ;
	    END IF;
		T_ABNH_TP	:=	'10' ;

	-- 타계정대체출
    ELSIF   I_STAT_GU  =   'G' THEN
	    IF  SUBSTR(I_AST_LKND, 1, 1)  =   '1' THEN
			T_RMRK_TRD_TP	:=	'610' ;
	    ELSIF   SUBSTR(I_AST_LKND, 1, 1)	=	'3' THEN
			T_RMRK_TRD_TP	:=	'610' ;
	    ELSE
			T_RMRK_TRD_TP	:=	'610' ;
	    END IF;
		T_ABNH_TP	:=	'10' ;

	-- 자산매각
    ELSIF   I_STAT_GU  =   'J' THEN
	    IF  SUBSTR(I_AST_LKND, 1, 1)  =   '1' THEN
	    	IF  I_AST_SETL_TP  =   '0' THEN
				T_RMRK_TRD_TP	:=	'310' ;
		    ELSIF   I_AST_SETL_TP  =   '1' THEN
				T_RMRK_TRD_TP	:=	'311' ;
		    ELSIF   I_AST_SETL_TP  =   '2' THEN
				T_RMRK_TRD_TP	:=	'312' ;
		    ELSIF   I_AST_SETL_TP  =   '3' THEN
				T_RMRK_TRD_TP	:=	'313' ;
	    	END IF;
	    ELSIF   SUBSTR(I_AST_LKND, 1, 1)	=	'3' THEN
	    	IF  I_AST_SETL_TP  =   '0' THEN
				T_RMRK_TRD_TP	:=	'320' ;
		    ELSIF   I_AST_SETL_TP  =   '1' THEN
				T_RMRK_TRD_TP	:=	'321' ;
		    ELSIF   I_AST_SETL_TP  =   '2' THEN
				T_RMRK_TRD_TP	:=	'322' ;
		    ELSIF   I_AST_SETL_TP  =   '3' THEN
				T_RMRK_TRD_TP	:=	'323' ;
	    	END IF;
	    ELSE
	    	IF  I_AST_SETL_TP  =   '0' THEN
				T_RMRK_TRD_TP	:=	'310' ;
		    ELSIF   I_AST_SETL_TP  =   '1' THEN
				T_RMRK_TRD_TP	:=	'311' ;
		    ELSIF   I_AST_SETL_TP  =   '2' THEN
				T_RMRK_TRD_TP	:=	'312' ;
		    ELSIF   I_AST_SETL_TP  =   '3' THEN
				T_RMRK_TRD_TP	:=	'313' ;
	    	END IF;
	    END IF;
		T_ABNH_TP	:=	'10' ;

	-- 자산매각부가세
    ELSIF   I_STAT_GU  =   'V' THEN
    	IF  I_AST_SETL_TP  =   '0' THEN
			T_RMRK_TRD_TP	:=	'330' ;
	    ELSIF   I_AST_SETL_TP  =   '1' THEN
			T_RMRK_TRD_TP	:=	'331' ;
	    ELSIF   I_AST_SETL_TP  =   '2' THEN
			T_RMRK_TRD_TP	:=	'332' ;
	    ELSIF   I_AST_SETL_TP  =   '3' THEN
			T_RMRK_TRD_TP	:=	'333' ;
    	END IF;
		T_ABNH_TP	:=	'10' ;

	-- 자산매각이익
    ELSIF   I_STAT_GU  =   'Y' THEN
    	IF  I_AST_SETL_TP  =   '0' THEN
			T_RMRK_TRD_TP	:=	'340' ;
	    ELSIF   I_AST_SETL_TP  =   '1' THEN
			T_RMRK_TRD_TP	:=	'341' ;
	    ELSIF   I_AST_SETL_TP  =   '2' THEN
			T_RMRK_TRD_TP	:=	'342' ;
	    ELSIF   I_AST_SETL_TP  =   '3' THEN
			T_RMRK_TRD_TP	:=	'343' ;
    	END IF;
		T_ABNH_TP	:=	'10' ;

	-- 자산매각손실
    ELSIF   I_STAT_GU  =   'Z' THEN
    	IF  SUBSTR(I_AST_LKND, 1, 1)  =   '1' THEN
			T_RMRK_TRD_TP	:=	'350' ;
	    ELSIF   SUBSTR(I_AST_LKND, 1, 1)  =   '3' THEN
			T_RMRK_TRD_TP	:=	'351' ;
	    ELSE
			T_RMRK_TRD_TP	:=	'350' ;
    	END IF;
		T_ABNH_TP	:=	'10' ;

	-- 자산폐기
    ELSIF   I_STAT_GU  =   'K' THEN
    	IF  SUBSTR(I_AST_LKND, 1, 1)  =   '1' THEN
			T_RMRK_TRD_TP	:=	'410' ;
	    ELSIF   SUBSTR(I_AST_LKND, 1, 1)  =   '3' THEN
			T_RMRK_TRD_TP	:=	'411' ;
	    ELSE
			T_RMRK_TRD_TP	:=	'410' ;
    	END IF;
		T_ABNH_TP	:=	'10' ;

	-- 자산폐기손실
    ELSIF   I_STAT_GU  =   'W' THEN
    	IF  SUBSTR(I_AST_LKND, 1, 1)  =   '1' THEN
			T_RMRK_TRD_TP	:=	'420' ;
	    ELSIF   SUBSTR(I_AST_LKND, 1, 1)  =   '3' THEN
			T_RMRK_TRD_TP	:=	'421' ;
	    ELSE
			T_RMRK_TRD_TP	:=	'420' ;
    	END IF;
		T_ABNH_TP	:=	'10' ;
    END IF;

	T_ACC_RMRK_CD	:=	I_RMRK_JOB_TP || T_RMRK_TRD_TP || T_ABNH_TP ;

    -- *********************
    -- * 전   표   처   리 *
    -- *********************
    IF  I_FLAG  =   'I' THEN

        -- CHK_1. 회계월마감체크(당월)
        T_CNT   := 0 ;
		SELECT	COUNT(*)
		  INTO  T_CNT
		  FROM	VN.GGA11M00
		 WHERE	TERMS		=	T_TERMS
		   AND	CLS_YM		=	SUBSTR(I_SLIP_DT, 1, 6)
		   AND	BRCH_CD		=   I_PROC_BRCH_CD
		   AND	AGNC_BRCH	=	I_PROC_AGNC_BRCH
       	   AND	NVL(ACC_CLS_YN, 'N')	=	'Y' ;

        IF  T_CNT   >=  1   THEN
            RAISE ERR_GGA11M00_1;
        END IF;

        -- CHK_2. 회계일마감체크
        T_CNT   := 0 ;
		SELECT	COUNT(*)
		  INTO  T_CNT
		  FROM	VN.GGA10M00
		 WHERE	ACC_CLS_DT  =	I_SLIP_DT
		   AND	BRCH_CD		=   I_PROC_BRCH_CD
		   AND	AGNC_BRCH	=	I_PROC_AGNC_BRCH
       	   AND	NVL(ACC_CLS_YN, 'N')	=	'Y' ;

        IF  T_CNT   >=  1   THEN
            RAISE ERR_GGA10M00;
        END IF;

		IF  I_STAT_GU  <>   'C' THEN

	        -- CHK_3. 당월감가상각 전표처리체크
	        T_CNT   := 0 ;
			SELECT	COUNT(*)
			  INTO  T_CNT
			  FROM	VN.GGA22M01
			 WHERE	CHG_DT  	=	T_LAST_DAY
			   AND	BRCH_CD		=   I_PROC_BRCH_CD
			   AND	AGNC_BRCH	=	I_PROC_AGNC_BRCH
			   AND	SLIP_NO		IS NOT NULL ;

	        IF  T_CNT   >=  1   THEN
	            RAISE ERR_GGA22M01;
	        END IF;

	        -- CHK_4. 당월감가상각 처리체크
	        T_CNT   := 0 ;
			SELECT	COUNT(*)
			  INTO  T_CNT
			  FROM	VN.GGA23M00
			 WHERE	TERMS		=	T_TERMS
			   AND	DEPR_YM		=	SUBSTR(I_SLIP_DT, 1, 6)
			   AND	BRCH_CD		=   I_PROC_BRCH_CD
			   AND	AGNC_BRCH	=	I_PROC_AGNC_BRCH ;

	        IF  T_CNT   >=  1   THEN
	            RAISE ERR_GGA23M00;
	        END IF;

        END IF;

        -- CHK_4. 회계전표 처리
		BEGIN

			O_SLIP_NO		:=	NULL ;
			O_SLIP_SUB_NO	:=	NULL ;
			O_SLIP_NO1		:=	NULL ;
			O_SLIP_SUB_NO1	:=	NULL ;

			O1_RTN_TBL		:=	NULL ;
			O1_RTN_ERR		:=	NULL ;
			O1_RTN_MSG		:=	NULL ;

			VN.PGG_MANUAL_VOUCHER(
				I_FLAG,						-- I:처리,D:취소
				I_SLIP_DT,					-- 전표일
				I_PROC_BRCH_CD,				-- 처리지점
				I_PROC_AGNC_BRCH,			-- 처리대리지점
				I_EXCH_BRCH_CD,				-- 이체지점
				I_EXCH_AGNC_BRCH,			-- 이체대리지점
				I_RMRK_JOB_TP,				-- 적요업무구분('42')
				T_ACC_RMRK_CD,				-- 회계적요코드
				I_ACC_ACT_CD,				-- 회계계정코드
				I_DEPT_CD,					-- 부서코드
				I_CUST_CD,					-- 고객코드
				I_DR_AMT_01,				-- 차변금액01
				I_DR_AMT_02,				-- 차변금액02
				I_DR_AMT_03,				-- 차변금액03
				I_CR_AMT_01,				-- 대변금액01
				I_CR_AMT_02,				-- 대변금액02
				I_CR_AMT_03,				-- 대변금액03
				I_WORK_MN,					-- 처리자
				I_WORK_TRM,					-- IP_ADDRESS
				O_SLIP_NO,
				O_SLIP_SUB_NO,
				O_SLIP_NO1,
				O_SLIP_SUB_NO1,
				O1_RTN_TBL,
				O1_RTN_ERR,
				O1_RTN_MSG) ;

	    EXCEPTION WHEN OTHERS THEN
			vn.pxc_log_write('pgg_ast_slip_appr','ERR_PGG_MANUAL_VOUCHER');
			RAISE ERR_PGG_MANUAL_VOUCHER;
	    END;


    -- *********************
    -- * 전   표   취   소 *
    -- *********************
    ELSIF   I_FLAG  =   'D' THEN


        -- CHK_1. 회계월마감체크(당월)
        T_CNT   := 0 ;
		SELECT	COUNT(*)
		  INTO  T_CNT
		  FROM	VN.GGA11M00
		 WHERE	TERMS		=	T_TERMS
		   AND	CLS_YM		=	SUBSTR(I_SLIP_DT, 1, 6)
		   AND	BRCH_CD		=   I_PROC_BRCH_CD
		   AND	AGNC_BRCH	=	I_PROC_AGNC_BRCH
       	   AND	NVL(ACC_CLS_YN, 'N')	=	'Y' ;

        IF  T_CNT   >=  1   THEN
            RAISE ERR_GGA11M00_1;
        END IF;

        -- CHK_2. 회계일마감체크
        T_CNT   := 0 ;
		SELECT	COUNT(*)
		  INTO  T_CNT
		  FROM	VN.GGA10M00
		 WHERE	ACC_CLS_DT  =	I_SLIP_DT
		   AND	BRCH_CD		=   I_PROC_BRCH_CD
		   AND	AGNC_BRCH	=	I_PROC_AGNC_BRCH
       	   AND	NVL(ACC_CLS_YN, 'N')	=	'Y' ;

        IF  T_CNT   >=  1   THEN
            RAISE ERR_GGA10M00;
        END IF;

        -- CHK_3. 당월감가상각 전표처리체크
        T_CNT   := 0 ;
		SELECT	COUNT(*)
		  INTO  T_CNT
		  FROM	VN.GGA22M01
		 WHERE	CHG_DT  	=	T_LAST_DAY
		   AND	BRCH_CD		=   I_PROC_BRCH_CD
		   AND	AGNC_BRCH	=	I_PROC_AGNC_BRCH
		   AND	SLIP_NO		IS NOT NULL ;

        IF  T_CNT   <=  0   THEN
            RAISE ERR_GGA22M01;
        END IF;

        -- CHK_4. 당월감가상각 처리체크
        T_CNT   := 0 ;
		SELECT	COUNT(*)
		  INTO  T_CNT
		  FROM	VN.GGA23M00
		 WHERE	TERMS		=	T_TERMS
		   AND	DEPR_YM		=	SUBSTR(I_SLIP_DT, 1, 6)
		   AND	BRCH_CD		=   I_PROC_BRCH_CD
		   AND	AGNC_BRCH	=	I_PROC_AGNC_BRCH ;

        IF  T_CNT   <=  0   THEN
            RAISE ERR_GGA23M00;
        END IF;

        -- CHK_5. 회계전표 취소처리
		BEGIN

			VN.PGG_CNCL_VOUCHER(
				I_SLIP_DT,					-- 전표일
				I_PROC_BRCH_CD,					-- 지점
				I_PROC_AGNC_BRCH,				-- 대리지점
				O_SLIP_NO,
				T_PROC_CNT) ;

	    EXCEPTION WHEN OTHERS THEN
			RAISE ERR_PGG_CNCL_VOUCHER;
	    END;


    END IF;

    O_RTN_TBL  :=  'GGA11M00';
    O_RTN_ERR  :=  '0';
    IF  I_FLAG  =   'I' THEN
        --O_RTN_MSG  :=  '[V0602]회계마감 성공! ==> 정상적으로 처리되었습니다.';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','0602');
    ELSIF   I_FLAG  =   'D' THEN
        --O_RTN_MSG  :=  '[V0603]회계마감 취소 성공! ==> 정상적으로 처리되었습니다.';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','0603');
    END IF;
    --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);

EXCEPTION
    WHEN    ERR_GGA11M00_1  THEN
        O_RTN_TBL  :=  'ERR_GGA11M00_1';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2616]이미 회계 월마감이 완료되었습니다! [' || I_PROC_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2616') || ' [' || I_PROC_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA10M00  THEN
        O_RTN_TBL  :=  'ERR_GGA10M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2623]회계 일마감을 아직 처리하지 않은 팀점이 있습니다 [' || I_PROC_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2623') || ' [' || I_PROC_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA22M01  THEN
        O_RTN_TBL  :=  'ERR_GGA22M01';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2016]자료가 존재하지 않습니다';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016');
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA23M00  THEN
        O_RTN_TBL  :=  'ERR_GGA23M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2016]자료가 존재하지 않습니다';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016');
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_PGG_MANUAL_VOUCHER  THEN
        O_RTN_TBL  :=  'ERR_PGG_MANUAL_VOUCHER';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2016]자료가 존재하지 않습니다';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016');
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_PGG_CNCL_VOUCHER  THEN
        O_RTN_TBL  :=  'ERR_PGG_CNCL_VOUCHER';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2016]자료가 존재하지 않습니다';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016');
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    OTHERS  THEN
        O_RTN_TBL  :=  'OTHERS';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        O_RTN_MSG  :=  'ERROR ' || SUBSTR(SQLERRM, 1, 100);
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
END PGG_ACT_SLIP_APPR;
/

