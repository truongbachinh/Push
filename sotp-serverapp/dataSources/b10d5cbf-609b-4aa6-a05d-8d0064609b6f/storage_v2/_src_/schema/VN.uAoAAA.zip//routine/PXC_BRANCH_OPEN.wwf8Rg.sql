create PROCEDURE pxc_branch_open     (
	i_sec_id                in      varchar2
) is


/*
   \file     pxc_branch_open.sql
   \brief

   \section intro Program Information
        - Program Name              :
        - Service Name              : N/A
        - Related Client Program- Client Program ID : N/A
        - Related Tables            : gcb01m00
        - Dev. Date                 : 2011/03/17
        - Developer                 : Nguyen
        - Business Logic Desc.      :
        - Latest Modification Date  :

   \section history Program Modification History
    - 1.0       2011/03/17

   \section info Additional Reference Comments
*/

--**********************************************************************
--	MAIN PROCEDURE
--**********************************************************************
    t_err_msg    varchar2(500);
    t_err_txt	 varchar2(200);
	vs_date		 varchar2(10);
	vs_brch_cd   varchar2(10);
	vs_job_cls   varchar2(10);
	vs_count     number;
begin

	select vn.vwdate
	into vs_date
	from dual;

	for c1 in(
		select distinct(brch_cd)
		from vn.xcc90m00
	)
	loop
		vs_brch_cd := c1.brch_cd;
		vs_count := 0;

		select 	count(*)
		into 	vs_count
		from vn.gcb01m00
		where cls_dt = vs_date
		and cls_bnh = vs_brch_cd;

		if vs_count = 1 then
			update vn.gcb01m00
			set job_cls = 'N',
				coe_cls = 'N'
			where cls_dt = vs_date
			and cls_bnh = vs_brch_cd;
		else
			insert into vn.gcb01m00
				(cls_dt,
				cls_bnh,
				job_cls,
				coe_cls)
			values
				(vs_date,
				vs_brch_cd,
				'N',
				'N');
		end if;
	end loop;
end pxc_branch_open;
/

