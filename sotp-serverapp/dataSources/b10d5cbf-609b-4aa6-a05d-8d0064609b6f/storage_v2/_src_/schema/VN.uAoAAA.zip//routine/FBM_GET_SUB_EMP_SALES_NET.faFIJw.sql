create function    fbm_get_sub_emp_sales_net(
    i_emp_no            varchar2,   -- Ma nhan vien
    i_dt                varchar2,   -- Ngay tra cuu
    i_mon_dt            varchar2,   -- Thang tinh hoa hong
    i_biz_cmsn_tp       varchar2,   -- Phan loai giao dich
    i_biz_cmsn_knd      varchar2    -- Phan loai hoa hong
)
return number

as
pragma autonomous_transaction;

    t_sales_amt  number;

    o_ret               number;
begin
    select sum(b3.net_amt) sales_amt
    into t_sales_amt
    from vn.bmb30m00 b3
    inner join vn.rms05m00 r5
    on b3.emp_no = r5.emp_no
    where r5.mng_emp_no = i_emp_no
    and b3.mon_dt = i_mon_dt
    ;

    o_ret   := nvl(t_sales_amt, 0);

    return o_ret;

end;
/

