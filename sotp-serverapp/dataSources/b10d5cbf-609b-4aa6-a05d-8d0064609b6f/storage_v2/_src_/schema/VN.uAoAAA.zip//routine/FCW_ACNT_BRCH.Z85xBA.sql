create function fcw_acnt_brch
(
   i_acnt_no          in       varchar2,
   i_sub_no           in       varchar2, 
   i_date             in       varchar2        
) 
return varchar2 as

	  t_cn_cd	   varchar2(3); 
	  t_pgd_cd	 varchar2(2); 
	  t_bnh_cd	 varchar2(5);         
    t_count    number := 0;
    t_row      number := 0;
    t_max_dt   date;
    t_min_dt   date;
    t_query_dt date;
              
begin
     
   select x.acnt_mng_bnh||x.agnc_brch, x.acnt_mng_bnh, x.agnc_brch 
     into t_bnh_cd, t_cn_cd, t_pgd_cd 
     from vn.aaa01m00 x
    where x.acnt_no = i_acnt_no
      and x.sub_no = i_sub_no ;
      
      if i_date >= vn.vhdate then
        t_bnh_cd := t_bnh_cd ;
      else
        select count(*), max(t.chg_dtm) 
          into t_row, t_max_dt
          from aaa01h00 t
         where t.acnt_info_chg_tp in ('05','06')
           and t.acnt_no = i_acnt_no
           and t.sub_no = i_sub_no 
           and to_char(t.chg_dtm, 'yyyymmdd') <= i_date   ;
           
        select count(*), min(t.chg_dtm) 
          into t_count, t_min_dt 
          from aaa01h00 t
         where t.acnt_info_chg_tp in ('05','06')
           and t.acnt_no = i_acnt_no
           and t.sub_no = i_sub_no ;    
           
           if t_row = 0 then
              t_query_dt := t_min_dt;
           else
              t_query_dt := t_max_dt;
           end if;       
           
           if t_count > 0 then     
               
               FOR C1 IN (
                 
                        select  to_char(t.chg_dtm, 'yyyymmdd') chg_date, 
                                t.chg_pre_cont pre_bnh, 
                                t.chg_af_cont af_bnh
                          from aaa01h00 t
                         where t.acnt_info_chg_tp in ('05','06')
                           and t.acnt_no = i_acnt_no
                           and t.sub_no = i_sub_no
                           and t.chg_dtm = t_query_dt                                                 
                      order by to_char(t.chg_dtm, 'yyyymmdd')

                ) LOOP
                       
                if i_date > C1.CHG_DATE then
                  
                  t_bnh_cd := trim(substr(C1.af_bnh,1, instr(C1.af_bnh,'.')-1 )) ;
                  
                  if length(t_bnh_cd) = 2 then
                    t_bnh_cd := t_cn_cd || t_bnh_cd ;
                  elsif length(t_bnh_cd) = 3 then
                    t_bnh_cd := t_bnh_cd || t_pgd_cd;
                  elsif length(t_bnh_cd) = 5 then
                    t_bnh_cd := t_bnh_cd ;
                  end if;       
                             
                  RETURN t_bnh_cd ;
                  
                else
                  
                  t_bnh_cd := trim(substr(C1.pre_bnh,1, instr(C1.pre_bnh,'.')-1 )) ;
                  
                  if length(t_bnh_cd) = 2 then
                    t_bnh_cd := t_cn_cd || t_bnh_cd ;
                  elsif length(t_bnh_cd) = 3 then
                    t_bnh_cd := t_bnh_cd || t_pgd_cd;
                  elsif length(t_bnh_cd) = 5 then
                    t_bnh_cd := t_bnh_cd ;
                  end if; 
                  
                  RETURN t_bnh_cd ;
                  
                end if;
                
              END LOOP;                              

           else
              RETURN t_bnh_cd ;          
           end if;
           
      end if ;
   vn.pxc_log_write('fcw_acnt_brch','i_acnt_no  '|| i_acnt_no  );
   vn.pxc_log_write('fcw_acnt_brch','i_sub_no  '|| i_sub_no  );
   vn.pxc_log_write('fcw_acnt_brch','i_date  '|| i_date  );   
   vn.pxc_log_write('fcw_acnt_brch','t_bnh_cd  '|| t_bnh_cd  );
         
   RETURN t_bnh_cd;

end fcw_acnt_brch;
/

