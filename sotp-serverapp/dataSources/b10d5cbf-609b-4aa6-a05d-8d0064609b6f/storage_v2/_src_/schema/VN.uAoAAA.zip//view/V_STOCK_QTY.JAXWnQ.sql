create view V_STOCK_QTY as
select vn.vwdate dt,
       acnt_no,
       sub_no,
       stk_cd,
       vn.faa_acnt_tp_g('068',acnt_no, sub_no) Loai_KH, --P: TVLK, C: KH trong nuoc, F: KH nuoc ngoai, Con lai la To chuc khac
       own_qty CK_LuuKy,
       decode(vn.fss_except_sbst_q( stk_cd), 'Y', 0, own_qty) CK_GiaoDich,
       decode(vn.fss_except_sbst_q( stk_cd), 'Y', own_qty, 0) CK_TamNgung_GiaoDich,
       mrtg_lnd_qty CK_CamCo,
       mov_lim_qty SL_TamGiu,
       vn.fts_get_mth_qty_g(acnt_no, sub_no,'%', stk_cd , '1' , 'N' , vn.vwdate)  CK_ChoThanhToan,
       outq_req_qty CK_PhongToa_ChoRut,
       delay_qty    CK_ChoGiaoDich,
       vn.fss_get_stk_mkt(stk_cd) San_GiaoDich--1:HOSE, 2:HNX, 3:OTC, 4:UPcom
   from vn.ssb01m00
union all
select rgt_std_dt dt,
       acnt_no,
       sub_no,
       stk_cd,
       vn.faa_acnt_tp_g('068', acnt_no, sub_no) Loai_KH, --P: TVLK, C: KH trong nuoc, F: KH nuoc ngoai, Con lai la To chuc khac
       own_qty CK_LuuKy,
       decode(vn.fss_except_sbst_q(stk_cd), 'Y', 0, own_qty) CK_GiaoDich,
       decode(vn.fss_except_sbst_q(stk_cd), 'Y', own_qty, 0) CK_TamNgung_GiaoDich,
       mrtg_lnd_qty CK_CamCo,
       mov_lim_qty SL_TamGiu,
       vn.fts_get_mth_qty_g(acnt_no, sub_no,'%', stk_cd , '1' , 'N' , vn.vwdate)  CK_ChoThanhToan,
       outq_req_qty CK_PhongToa_ChoRut,
       delay_qty    CK_ChoGiaoDich,
       vn.fss_get_stk_mkt(stk_cd) San_GiaoDich--1:HOSE, 2:HNX, 3:OTC, 4:UPcom
   from vn.ssb01h00
/

