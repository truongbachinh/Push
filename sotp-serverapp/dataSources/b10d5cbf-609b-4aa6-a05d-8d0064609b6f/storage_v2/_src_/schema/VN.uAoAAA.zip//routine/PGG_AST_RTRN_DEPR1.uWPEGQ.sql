create PROCEDURE    PGG_AST_RTRN_DEPR1
   (I_FLAG       	IN      VARCHAR2,       -- I:생성,D:취소
    I_BRCH_CD       IN      VARCHAR2,       -- 지점
    I_AGNC_BRCH     IN      VARCHAR2,       -- 대리지점
    I_TERMS       	IN      NUMBER,       	-- 회계기수
    I_YYMM       	IN      VARCHAR2,       -- 상각년월
    I_LAST_DAY      IN      VARCHAR2,       -- 처리일
    I_WORK_MN       IN      VARCHAR2,		-- 처리자
    I_WORK_TRM      IN      VARCHAR2,       -- IP_ADDRESS
    O_RTN_TBL       OUT     VARCHAR2,       -- Return Table
	O_RTN_ERR       OUT     VARCHAR2,       -- Return Error Code
	O_RTN_MSG       OUT     VARCHAR2        -- Return Message
	) IS

    -- Constants
    K_SLIP_MAXDT    VARCHAR2(8) := '20080401' ; 	-- 처리시작일
    K_JOB_TP		VARCHAR2(2) := '42' ;
    K_STAT_GU		VARCHAR2(1) := 'C' ;
    K_STAT_GU1		VARCHAR2(1) := 'S' ;
    K_AST_SETL_TP	VARCHAR2(1) := '1' ;
    K_ACC_ACT_CD	VARCHAR2(12) := '' ;
    K_CUST_CD		VARCHAR2(15) := '' ;

    -- Variables
	T_AST_NO				VN.GGA22M00.AST_NO%TYPE;				-- 자산번호
	T_DEPR_AMT				VN.GGA23M01.DEPR_AMT_01%TYPE;			-- 월상각금액

	T_BPRD_DEPR_CUM			VN.GGA23M01.BPRD_DEPR_CUM%TYPE;			-- 전기상각누계액
	T_TPRD_DEPR_CUM			VN.GGA23M01.TPRD_DEPR_CUM%TYPE;			-- 당기상각누계액
	T_NDEPR_REMN			VN.GGA23M01.NDEPR_REMN%TYPE;			-- 미상각잔액
    T_NUM					NUMBER := (MONTHS_BETWEEN(TO_DATE(I_YYMM || '01', 'YYYYMMDD'), TO_DATE(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 'YYYYMMDD')) + 1);	-- 현재회차

    T_CHG_SN				NUMBER := 0;							-- 변동순번
    T_CHG_STAT         		VARCHAR2(1) := 'C' ;

    O1_RTN_TBL      VARCHAR2(100) ;      				-- Return Table
	O1_RTN_ERR      VARCHAR2(100) ;      				-- Return Error Code
	O1_RTN_MSG      VARCHAR2(254) ;      				-- Return Message

    O_SLIP_NO      VARCHAR2(5) ;
	O_SLIP_SUB_NO  VARCHAR2(3) ;
    O_SLIP_NO1     VARCHAR2(5) ;
	O_SLIP_SUB_NO1 VARCHAR2(3) ;


    -- Exceptions Declare
    ERR_FGG_AST_RTRN_DEPR		EXCEPTION;
    ERR_GGA23M00_INS			EXCEPTION;
    ERR_GGA23M01_UPD			EXCEPTION;
    ERR_GGA22M00_UPD			EXCEPTION;
    ERR_GGA22M01_INS			EXCEPTION;
    ERR_PGG_ACT_SLIP_APPR		EXCEPTION;

-- *************************< START OF PROCEDURE >****************************
BEGIN

    -- ************************
    -- * 월 감 가 상 각 처 리 *
    -- ************************
    IF  I_FLAG  =   'I' THEN

	    -- CHK_1. 일반자산 월상각액 생성자료 조회
	    FOR C1 IN
			(	SELECT	v11.AST_NO					AS	AST_NO,
						v11.BRCH_CD					AS	BRCH_CD,
						v11.AGNC_BRCH				AS	AGNC_BRCH,
						v11.DEPT_CD					AS	DEPT_CD,
						v11.DEPR_METH				AS	DEPR_METH,
						NVL(v11.USE_YY_CNT, 0)		AS	USE_YY_CNT,
						NVL(v11.DLM_AMT, 0)			AS	DLM_AMT,
						NVL(v11.DEPR_RT, 0.0)		AS	DEPR_RT,
						NVL(v11.GET_AMT, 0)			AS	GET_AMT,
						NVL(v11.BPRD_DEPR_CUM, 0)	AS	BPRD_DEPR_CUM,
						v11.GET_DT					AS	GET_DT,
						TO_CHAR(ADD_MONTHS(LAST_DAY(TO_DATE(SUBSTR(v11.GET_DT, 1, 6) || '01', 'YYYY/MM/DD')), (NVL(v11.USE_YY_CNT, 0) * 12)), 'YYYYMM')	AS	DEPR_END_YM,
						v11.DISP_DT					AS	DISP_DT,
						v11.AST_STAT				AS	AST_STAT,
						v11.AST_STAT_DT				AS	AST_STAT_DT
				  FROM
						(	SELECT	v21.AST_NO					AS	AST_NO,
									v21.DEPR_METH				AS	DEPR_METH,
									NVL(v21.USE_YY_CNT, 0)		AS	USE_YY_CNT,
									NVL(v21.DLM_AMT, 0)			AS	DLM_AMT,
									NVL(v21.DEPR_RT, 0.0)		AS	DEPR_RT,
									NVL(v21.GET_AMT, 0)			AS	GET_AMT,
									(	SELECT	NVL(v31.BPRD_DEPR_CUM, 0) + NVL(v31.TPRD_DEPR_CUM, 0)	AS	BPRD_DEPR_CUM
										  FROM	VN.GGA23M01	v31
										 WHERE	v31.TERMS	=	(I_TERMS - 1)
										   AND	v31.DEPR_YY	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS - 1, '1'), 1, 4)
										   AND	v31.AST_NO	=	v21.AST_NO
									)							AS	BPRD_DEPR_CUM,
									v21.GET_DT					AS	GET_DT,
									v21.DEPR_END_DT				AS	DEPR_END_DT,
									v21.DISP_DT					AS	DISP_DT,
									(	SELECT	v31.BRCH_CD		AS	BRCH_CD
										  FROM	VN.GGA22M02	v31
										 WHERE	v31.AST_NO		=	v21.AST_NO
										   AND	v31.CHG_END_DT	=	(	SELECT	MAX(v41.CHG_END_DT)
																		  FROM	VN.GGA22M02	v41
																		 WHERE	v41.AST_NO		=	v21.AST_NO
																		   AND	TO_DATE(I_LAST_DAY, 'YYYY/MM/DD')	BETWEEN	TRUNC(v41.CHG_STAT_DT)	AND	TRUNC(v41.CHG_END_DT)
																	)
									)							AS	BRCH_CD,
									(	SELECT	v21.AGNC_BRCH	AS	AGNC_BRCH
										  FROM	VN.GGA22M02	v31
										 WHERE	v31.AST_NO		=	v21.AST_NO
										   AND	v31.CHG_END_DT	=	(	SELECT	MAX(v41.CHG_END_DT)
																		  FROM	VN.GGA22M02	v41
																		 WHERE	v41.AST_NO		=	v21.AST_NO
																		   AND	TO_DATE(I_LAST_DAY, 'YYYY/MM/DD')	BETWEEN	TRUNC(v41.CHG_STAT_DT)	AND	TRUNC(v41.CHG_END_DT)
																	)
									)							AS	AGNC_BRCH,
									(	SELECT	v31.DEPT_CD		AS	DEPT_CD
										  FROM	VN.GGA22M02	v31
										 WHERE	v31.AST_NO		=	v21.AST_NO
										   AND	v31.CHG_END_DT	=	(	SELECT	MAX(v41.CHG_END_DT)
																		  FROM	VN.GGA22M02	v41
																		 WHERE	v41.AST_NO		=	v21.AST_NO
																		   AND	TO_DATE(I_LAST_DAY, 'YYYY/MM/DD')	BETWEEN	TRUNC(v41.CHG_STAT_DT)	AND	TRUNC(v41.CHG_END_DT)
																	)
									)							AS	DEPT_CD,
									(	SELECT	v31.CHG_STAT			AS	CHG_STAT
										  FROM	VN.GGA22M01	v31
										 WHERE	v31.AST_NO									=	v21.AST_NO
										   AND	v31.CHG_DT||TRIM(TO_CHAR(v31.CHG_SN,'000'))	=	(	SELECT	MAX(v41.CHG_DT||TRIM(TO_CHAR(v41.CHG_SN,'000')))
																									  FROM	VN.GGA22M01	v41
																									 WHERE	v41.AST_NO		=	v21.AST_NO
																									   AND	v41.CHG_DT		<=	I_LAST_DAY
																								)
									)							AS	AST_STAT,
									(	SELECT	v31.CHG_DT		AS	CHG_DT
										  FROM	VN.GGA22M01	v31
										 WHERE	v31.AST_NO									=	v21.AST_NO
										   AND	v31.CHG_DT||TRIM(TO_CHAR(v31.CHG_SN,'000'))	=	(	SELECT	MAX(v41.CHG_DT||TRIM(TO_CHAR(v41.CHG_SN,'000')))
																									  FROM	VN.GGA22M01	v41
																									 WHERE	v41.AST_NO		=	v21.AST_NO
																									   AND	v41.CHG_DT		<=	I_LAST_DAY
																								)
									)							AS	AST_STAT_DT
							  FROM	VN.GGA22M00	v21
							 WHERE	v21.DEPR_METH		IN	('1', '2')							/* 상각방법(1:정액,2:정율) */
							   AND	SUBSTR(v21.GET_DT, 1, 6)	<	SUBSTR(I_LAST_DAY, 1, 6)	/* 취득일자 <= 상각일 */
							   AND	(v21.DEPR_END_DT	IS NULL
							    OR	v21.DEPR_END_DT		<=	I_LAST_DAY)						/* 상각완료일자 <= 상각일 */
							   AND	(v21.DISP_DT		IS NULL
							    OR	v21.DISP_DT			<=	SUBSTR(I_YYMM, 1, 6) || '01')	/* 처분일자 <= 상각일(01) */
						)			v11
				 WHERE	v11.BRCH_CD			=	I_BRCH_CD
				   AND	v11.AGNC_BRCH		=	I_AGNC_BRCH
				   AND	v11.AST_STAT		IN	('A', 'B', 'C', 'E', 'F', 'I', 'M')		/* A:신규취득,B:자본적지출,C:당기상각,E:자산수관,F:타계정대체입,I:자산분리B,M:자산병합B */
				   AND	(v11.AST_STAT_DT	IS NULL
				    OR	v11.AST_STAT_DT		<=	I_LAST_DAY)								/* 자산상태일자 <= 상각일 */
			  ORDER BY	v11.AST_NO,
						v11.BRCH_CD,
						v11.AGNC_BRCH,
						v11.DEPT_CD
	        ) LOOP

			T_AST_NO := C1.AST_NO ;

			T_BPRD_DEPR_CUM :=	0;
			T_TPRD_DEPR_CUM :=	0;
			T_NDEPR_REMN 	:=	0;

	        -- CHK_5. 일반자산 전월까지 당기상각누계액 구하기
			SELECT	NVL(SUM(v11.TM_DEPR_AMT), 0)	AS	TPRD_DEPR_CUM
			  INTO	T_TPRD_DEPR_CUM
			  FROM	VN.GGA23M00	v11
			 WHERE	v11.TERMS  		=	I_TERMS
			   AND	v11.DEPR_YM		>=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 6)
			   AND	v11.DEPR_YM		<	I_YYMM
			   AND	v11.AST_NO		=   C1.AST_NO ;

			-- 전월까지상각누계액
			T_BPRD_DEPR_CUM :=	C1.BPRD_DEPR_CUM + T_TPRD_DEPR_CUM;

	        -- CHK_2. 월상각액 구하기
			BEGIN
				T_DEPR_AMT	:=	VN.FGG_AST_RTRN_DEPR(
									'1',						-- 월상각금액
									I_TERMS,					-- 회계기수
									I_YYMM,						-- 처리월
									I_LAST_DAY,					-- 처리일
									C1.DEPR_METH,				-- 상각방법
									C1.DEPR_RT,					-- 상각율
									C1.GET_DT,					-- 취득일자
									C1.USE_YY_CNT,				-- 사용년수
									C1.DLM_AMT,					-- 잔존가액
									C1.GET_AMT,					-- 취득금액
									C1.BPRD_DEPR_CUM,			-- 전기상각누계액
									T_TPRD_DEPR_CUM) ;			-- 당기상각누계액

		    EXCEPTION WHEN OTHERS THEN
		        RAISE ERR_FGG_AST_RTRN_DEPR;
		    END;

			-- 당기당월까지상각누계액
			T_TPRD_DEPR_CUM :=	T_TPRD_DEPR_CUM + T_DEPR_AMT;
			-- 미상각잔액
			T_NDEPR_REMN 	:=	NVL(C1.GET_AMT, 0) - ( NVL(C1.BPRD_DEPR_CUM, 0) + T_TPRD_DEPR_CUM ) ;


			--CHK_3. 월상각액이 0 보다 클경우
--	        IF  T_DEPR_AMT   >  0   THEN

		        -- CHK_4. 일반자산 월상각액 처리 Insert
				BEGIN
			        INSERT
			          INTO  VN.GGA23M00(
							TERMS,
							DEPR_YM,
							AST_NO,
							BRCH_CD,
							AGNC_BRCH,
							DEPT_CD,
							TM_DEPR_AMT,
							USE_YN,
							WORK_MN,
							WORK_DTM,
							WORK_TRM,
							MDFY_MN,
							MDFY_DTM,
							MDFY_TRM )
		 	       VALUES  (I_TERMS,
							I_YYMM,
							C1.AST_NO,
							I_BRCH_CD,
							I_AGNC_BRCH,
							C1.DEPT_CD,
							T_DEPR_AMT,
							'Y',
							I_WORK_MN,
							SYSDATE,
							I_WORK_TRM,
							I_WORK_MN,
							SYSDATE,
							I_WORK_TRM );

			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA23M00_INS;
			    END;


		        -- CHK_6. 일반자산 년상각 처리 Update
				IF	T_NUM	=	1	THEN

					BEGIN
		                UPDATE  VN.GGA23M01
		                   SET  DEPR_AMT_01		=	T_DEPR_AMT,
								TPRD_DEPR_CUM	=	T_TPRD_DEPR_CUM,
								NDEPR_REMN		=	T_NDEPR_REMN,
								MDFY_MN  		=   I_WORK_MN,
		                        MDFY_DTM  		=   SYSDATE,
		                        MDFY_TRM  		=   I_WORK_TRM
						 WHERE	TERMS  		=	I_TERMS
						   AND	DEPR_YY  	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
						   AND	AST_NO		=   C1.AST_NO ;

				    EXCEPTION WHEN OTHERS THEN
				        RAISE ERR_GGA23M01_UPD;
				    END;

			    ELSIF   T_NUM  =   2 THEN

					BEGIN
		                UPDATE  VN.GGA23M01
		                   SET  DEPR_AMT_02		=	T_DEPR_AMT,
								TPRD_DEPR_CUM	=	T_TPRD_DEPR_CUM,
								NDEPR_REMN		=	T_NDEPR_REMN,
								MDFY_MN  		=   I_WORK_MN,
		                        MDFY_DTM  		=   SYSDATE,
		                        MDFY_TRM  		=   I_WORK_TRM
						 WHERE	TERMS  		=	I_TERMS
						   AND	DEPR_YY  	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
						   AND	AST_NO		=   C1.AST_NO ;

				    EXCEPTION WHEN OTHERS THEN
				        RAISE ERR_GGA23M01_UPD;
				    END;

			    ELSIF   T_NUM  =   3 THEN

					BEGIN
		                UPDATE  VN.GGA23M01
		                   SET  DEPR_AMT_03		=	T_DEPR_AMT,
								TPRD_DEPR_CUM	=	T_TPRD_DEPR_CUM,
								NDEPR_REMN		=	T_NDEPR_REMN,
								MDFY_MN  		=   I_WORK_MN,
		                        MDFY_DTM  		=   SYSDATE,
		                        MDFY_TRM  		=   I_WORK_TRM
						 WHERE	TERMS  		=	I_TERMS
						   AND	DEPR_YY  	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
						   AND	AST_NO		=   C1.AST_NO ;

				    EXCEPTION WHEN OTHERS THEN
				        RAISE ERR_GGA23M01_UPD;
				    END;

			    ELSIF   T_NUM  =   4 THEN

					BEGIN
		                UPDATE  VN.GGA23M01
		                   SET  DEPR_AMT_04		=	T_DEPR_AMT,
								TPRD_DEPR_CUM	=	T_TPRD_DEPR_CUM,
								NDEPR_REMN		=	T_NDEPR_REMN,
								MDFY_MN  		=   I_WORK_MN,
		                        MDFY_DTM  		=   SYSDATE,
		                        MDFY_TRM  		=   I_WORK_TRM
						 WHERE	TERMS  		=	I_TERMS
						   AND	DEPR_YY  	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
						   AND	AST_NO		=   C1.AST_NO ;

				    EXCEPTION WHEN OTHERS THEN
				        RAISE ERR_GGA23M01_UPD;
				    END;

			    ELSIF   T_NUM  =   5 THEN

					BEGIN
		                UPDATE  VN.GGA23M01
		                   SET  DEPR_AMT_05		=	T_DEPR_AMT,
								TPRD_DEPR_CUM	=	T_TPRD_DEPR_CUM,
								NDEPR_REMN		=	T_NDEPR_REMN,
								MDFY_MN  		=   I_WORK_MN,
		                        MDFY_DTM  		=   SYSDATE,
		                        MDFY_TRM  		=   I_WORK_TRM
						 WHERE	TERMS  		=	I_TERMS
						   AND	DEPR_YY  	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
						   AND	AST_NO		=   C1.AST_NO ;

				    EXCEPTION WHEN OTHERS THEN
				        RAISE ERR_GGA23M01_UPD;
				    END;

			    ELSIF   T_NUM  =   6 THEN

					BEGIN
		                UPDATE  VN.GGA23M01
		                   SET  DEPR_AMT_06		=	T_DEPR_AMT,
								TPRD_DEPR_CUM	=	T_TPRD_DEPR_CUM,
								NDEPR_REMN		=	T_NDEPR_REMN,
								MDFY_MN  		=   I_WORK_MN,
		                        MDFY_DTM  		=   SYSDATE,
		                        MDFY_TRM  		=   I_WORK_TRM
						 WHERE	TERMS  		=	I_TERMS
						   AND	DEPR_YY  	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
						   AND	AST_NO		=   C1.AST_NO ;

				    EXCEPTION WHEN OTHERS THEN
				        RAISE ERR_GGA23M01_UPD;
				    END;

			    ELSIF   T_NUM  =   7 THEN

					BEGIN
		                UPDATE  VN.GGA23M01
		                   SET  DEPR_AMT_07		=	T_DEPR_AMT,
								TPRD_DEPR_CUM	=	T_TPRD_DEPR_CUM,
								NDEPR_REMN		=	T_NDEPR_REMN,
								MDFY_MN  		=   I_WORK_MN,
		                        MDFY_DTM  		=   SYSDATE,
		                        MDFY_TRM  		=   I_WORK_TRM
						 WHERE	TERMS  		=	I_TERMS
						   AND	DEPR_YY  	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
						   AND	AST_NO		=   C1.AST_NO ;

				    EXCEPTION WHEN OTHERS THEN
				        RAISE ERR_GGA23M01_UPD;
				    END;

			    ELSIF   T_NUM  =   8 THEN

					BEGIN
		                UPDATE  VN.GGA23M01
		                   SET  DEPR_AMT_08		=	T_DEPR_AMT,
								TPRD_DEPR_CUM	=	T_TPRD_DEPR_CUM,
								NDEPR_REMN		=	T_NDEPR_REMN,
								MDFY_MN  		=   I_WORK_MN,
		                        MDFY_DTM  		=   SYSDATE,
		                        MDFY_TRM  		=   I_WORK_TRM
						 WHERE	TERMS  		=	I_TERMS
						   AND	DEPR_YY  	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
						   AND	AST_NO		=   C1.AST_NO ;

				    EXCEPTION WHEN OTHERS THEN
				        RAISE ERR_GGA23M01_UPD;
				    END;

			    ELSIF   T_NUM  =   9 THEN

					BEGIN
		                UPDATE  VN.GGA23M01
		                   SET  DEPR_AMT_09		=	T_DEPR_AMT,
								TPRD_DEPR_CUM	=	T_TPRD_DEPR_CUM,
								NDEPR_REMN		=	T_NDEPR_REMN,
								MDFY_MN  		=   I_WORK_MN,
		                        MDFY_DTM  		=   SYSDATE,
		                        MDFY_TRM  		=   I_WORK_TRM
						 WHERE	TERMS  		=	I_TERMS
						   AND	DEPR_YY  	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
						   AND	AST_NO		=   C1.AST_NO ;

				    EXCEPTION WHEN OTHERS THEN
				        RAISE ERR_GGA23M01_UPD;
				    END;

			    ELSIF   T_NUM  =   10 THEN

					BEGIN
		                UPDATE  VN.GGA23M01
		                   SET  DEPR_AMT_10		=	T_DEPR_AMT,
								TPRD_DEPR_CUM	=	T_TPRD_DEPR_CUM,
								NDEPR_REMN		=	T_NDEPR_REMN,
								MDFY_MN  		=   I_WORK_MN,
		                        MDFY_DTM  		=   SYSDATE,
		                        MDFY_TRM  		=   I_WORK_TRM
						 WHERE	TERMS  		=	I_TERMS
						   AND	DEPR_YY  	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
						   AND	AST_NO		=   C1.AST_NO ;

				    EXCEPTION WHEN OTHERS THEN
				        RAISE ERR_GGA23M01_UPD;
				    END;

			    ELSIF   T_NUM  =   11 THEN

					BEGIN
		                UPDATE  VN.GGA23M01
		                   SET  DEPR_AMT_11		=	T_DEPR_AMT,
								TPRD_DEPR_CUM	=	T_TPRD_DEPR_CUM,
								NDEPR_REMN		=	T_NDEPR_REMN,
								MDFY_MN  		=   I_WORK_MN,
		                        MDFY_DTM  		=   SYSDATE,
		                        MDFY_TRM  		=   I_WORK_TRM
						 WHERE	TERMS  		=	I_TERMS
						   AND	DEPR_YY  	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
						   AND	AST_NO		=   C1.AST_NO ;

				    EXCEPTION WHEN OTHERS THEN
				        RAISE ERR_GGA23M01_UPD;
				    END;

			    ELSIF   T_NUM  =   12 THEN

					BEGIN
		                UPDATE  VN.GGA23M01
		                   SET  DEPR_AMT_12		=	T_DEPR_AMT,
								TPRD_DEPR_CUM	=	T_TPRD_DEPR_CUM,
								NDEPR_REMN		=	T_NDEPR_REMN,
								MDFY_MN  		=   I_WORK_MN,
		                        MDFY_DTM  		=   SYSDATE,
		                        MDFY_TRM  		=   I_WORK_TRM
						 WHERE	TERMS  		=	I_TERMS
						   AND	DEPR_YY  	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
						   AND	AST_NO		=   C1.AST_NO ;

				    EXCEPTION WHEN OTHERS THEN
				        RAISE ERR_GGA23M01_UPD;
				    END;

				END IF;


			    -- CHK_7. 고정자산 MASTER Update
				IF	C1.DEPR_END_YM	=	I_YYMM	THEN

					T_CHG_STAT := 'S' ;

					BEGIN
		                UPDATE  VN.GGA22M00
		                   SET  DEPR_CUM		=	( NVL(C1.BPRD_DEPR_CUM, 0) + T_TPRD_DEPR_CUM ),
								DEPR_END_YM		=	C1.DEPR_END_YM,
								AST_STAT		=	T_CHG_STAT,
								AST_STAT_DT		=	I_LAST_DAY,
								DEPR_END_DT		=	I_LAST_DAY,
								MDFY_MN  		=   I_WORK_MN,
		                        MDFY_DTM  		=   SYSDATE,
		                        MDFY_TRM  		=   I_WORK_TRM
						 WHERE	AST_NO		=   C1.AST_NO ;

				    EXCEPTION WHEN OTHERS THEN
				        RAISE ERR_GGA22M00_UPD;
				    END;

				ELSE

					T_CHG_STAT := 'C' ;

					BEGIN
		                UPDATE  VN.GGA22M00
		                   SET  DEPR_CUM		=	( NVL(C1.BPRD_DEPR_CUM, 0) + T_TPRD_DEPR_CUM ),
								DEPR_END_YM		=	C1.DEPR_END_YM,
								AST_STAT		=	T_CHG_STAT,
								AST_STAT_DT		=	I_LAST_DAY,
								MDFY_MN  		=   I_WORK_MN,
		                        MDFY_DTM  		=   SYSDATE,
		                        MDFY_TRM  		=   I_WORK_TRM
						 WHERE	AST_NO		=   C1.AST_NO ;

				    EXCEPTION WHEN OTHERS THEN
				        RAISE ERR_GGA22M00_UPD;
				    END;

				END IF;


		        -- CHK_8. 변동순번발번
				T_CHG_SN :=	0;

				SELECT	/*+ INDEX_DESC(v11 GGA22M01_PK) */
						NVL(MAX(v11.CHG_SN), 0) + 1	AS	CHG_SN
				  INTO	T_CHG_SN
				  FROM	VN.GGA22M01	v11
				 WHERE	v11.AST_NO		=	C1.AST_NO
				   AND	v11.CHG_DT		=	I_LAST_DAY ;


		        -- CHK_9. 고정자산 DETAIL Insert
				BEGIN
					INSERT
					  INTO	VN.GGA22M01 (
							AST_NO,
							CHG_DT,
							CHG_SN,
							CHG_STAT,
							BRCH_CD,
							AGNC_BRCH,
							DEPT_CD,
							VOLA_AMT,
							ALWC_AMT,
							SLIP_DT,
							SLIP_BRCH_CD,
							SLIP_AGNC_BRCH,
							SLIP_NO,
							SLIP_SUB_NO,
							USE_YN,
							WORK_MN,
							WORK_DTM,
							WORK_TRM,
							MDFY_MN,
							MDFY_DTM,
							MDFY_TRM )
					VALUES	(C1.AST_NO,
							I_LAST_DAY,
							T_CHG_SN,
							T_CHG_STAT,
							I_BRCH_CD,
							I_AGNC_BRCH,
							C1.DEPT_CD,
							0,
							T_DEPR_AMT,
							I_LAST_DAY,
							I_BRCH_CD,
							I_AGNC_BRCH,
							NULL,
							NULL,
							'Y',
							I_WORK_MN,
							SYSDATE,
							I_WORK_TRM,
							I_WORK_MN,
							SYSDATE,
							I_WORK_TRM );

			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA22M01_INS;
			    END;


--	        END IF;


	    END LOOP;   -- C1 End Loop


	    -- CHK_10. 일반자산 월상각 전표처리 조회
	    FOR C3 IN
			(	SELECT	v11.TERMS						AS	TERMS,
						v11.DEPR_YM						AS	DEPR_YM,
						v11.BRCH_CD						AS	BRCH_CD,
						v11.AGNC_BRCH					AS	AGNC_BRCH,
						v11.DEPT_CD						AS	DEPT_CD,
						v12.AST_LKND					AS	AST_LKND,
						NVL(SUM(v11.TM_DEPR_AMT), 0)	AS	TM_DEPR_AMT,
						MAX(v11.SLIP_NO)				AS	SLIP_NO,
						MAX(v11.SLIP_SUB_NO)			AS	SLIP_SUB_NO
				  FROM
						(	SELECT	v21.TERMS					AS	TERMS,
									v21.DEPR_YM					AS	DEPR_YM,
									v21.BRCH_CD					AS	BRCH_CD,
									v21.AGNC_BRCH				AS	AGNC_BRCH,
									v21.DEPT_CD					AS	DEPT_CD,
									v21.AST_NO					AS	AST_NO,
									NVL(v21.TM_DEPR_AMT, 0)		AS	TM_DEPR_AMT,
									v22.SLIP_NO					AS	SLIP_NO,
									v22.SLIP_SUB_NO				AS	SLIP_SUB_NO
							  FROM	VN.GGA23M00	v21,
									(	SELECT	v31.AST_NO			AS	AST_NO,
												v31.SLIP_NO			AS	SLIP_NO,
												v31.SLIP_SUB_NO		AS	SLIP_SUB_NO
										  FROM	VN.GGA22M01	v31
										 WHERE	v31.CHG_DT		=	I_LAST_DAY
										   AND	v31.CHG_STAT	IN	(K_STAT_GU, K_STAT_GU1)
										   AND	v31.USE_YN		=	'Y'
										   AND	v31.CNCL_DT		IS NULL
									)			v22
							 WHERE	v21.TERMS		=	VN.FGG_GET_TERMS(I_LAST_DAY)
							   AND	v21.DEPR_YM		=	I_YYMM
							   AND	v21.BRCH_CD		=	I_BRCH_CD
							   AND	v21.AGNC_BRCH	=	I_AGNC_BRCH
							   AND	v21.AST_NO		=	v22.AST_NO(+)
						  ORDER BY	v21.TERMS,
									v21.DEPR_YM,
									v21.BRCH_CD,
									v21.AGNC_BRCH,
									v21.DEPT_CD,
									v21.AST_NO
						)			v11,
						VN.GGA22M00	v12
				 WHERE	v11.AST_NO		=	v12.AST_NO
			  GROUP BY	v11.TERMS,
						v11.DEPR_YM,
						v11.BRCH_CD,
						v11.AGNC_BRCH,
						v11.DEPT_CD,
						v12.AST_LKND
	        ) LOOP

    		IF  SUBSTR(C3.DEPT_CD, 1, 1)	=	'1'	THEN
				K_AST_SETL_TP := '1' ;
			ELSE
				K_AST_SETL_TP := '2' ;
    		END IF;

			O1_RTN_TBL	:=	NULL ;
			O1_RTN_ERR	:=	'0' ;
			O1_RTN_MSG	:=	NULL ;

			O_SLIP_NO		:=	NULL ;
			O_SLIP_SUB_NO	:=	NULL ;
			O_SLIP_NO1		:=	NULL ;
			O_SLIP_SUB_NO1	:=	NULL ;

			/* CHK_10. 감가상각 전표처리 Procedure Call */
			VN.PGG_ACT_SLIP_APPR(
				'I',						-- I:생성,D:취소
				I_LAST_DAY,					-- 전표일
				I_BRCH_CD,					-- 처리지점
				I_AGNC_BRCH,				-- 처리대리지점
				I_BRCH_CD,					-- 이체지점
				I_AGNC_BRCH,				-- 이체대리지점
				K_JOB_TP,					-- 적요업무구분('42')
				C3.AST_LKND,				-- 자산분류
				K_STAT_GU,					-- 고정자산구분
				K_AST_SETL_TP,				-- 부서구분
				K_ACC_ACT_CD,				-- 회계계정코드
				C3.DEPT_CD,					-- 부서코드
				K_CUST_CD,					-- 고객코드
				C3.TM_DEPR_AMT,				-- 차변금액01
				0,							-- 차변금액02
				0,							-- 차변금액03
				C3.TM_DEPR_AMT,				-- 대변금액01
				0,							-- 대변금액02
				0,							-- 대변금액03
				I_WORK_MN,					-- 처리자
				I_WORK_TRM,					-- IP_ADDRESS
				O_SLIP_NO,					-- 전표번호
				O_SLIP_SUB_NO,				-- 전표부번호
				O_SLIP_NO1,					-- 전표번호
				O_SLIP_SUB_NO1,				-- 전표부번호
				O1_RTN_TBL,
				O1_RTN_ERR,
				O1_RTN_MSG) ;

			vn.pxc_log_write('pgg_ast_rtrn_dept1','0: ' || C3.AST_LKND || ':' || O_SLIP_NO);

			IF  TO_NUMBER(O1_RTN_ERR)   <>   0  THEN
				vn.pxc_log_write('pgg_ast_rtrn_dept1','1: ' || C3.AST_LKND);
				RAISE ERR_PGG_ACT_SLIP_APPR;
		    END IF;


		    -- CHK_10. 고정자산 DETAIL Update
		    FOR C31 IN
				(	SELECT	v11.AST_NO		AS	AST_NO,
							v11.CHG_SN		AS	CHG_SN
					  FROM	VN.GGA22M01	v11
					 WHERE	SUBSTR(v11.AST_NO, 1, 2)	=	C3.AST_LKND
					   AND	v11.SLIP_DT					=	I_LAST_DAY
					   AND	v11.SLIP_BRCH_CD			=	I_BRCH_CD
					   AND	v11.SLIP_AGNC_BRCH			=	I_AGNC_BRCH
					   AND	v11.CHG_STAT				IN	(K_STAT_GU, K_STAT_GU1)
				  ORDER BY	v11.AST_NO,
							v11.CHG_SN
		        ) LOOP

		        -- CHK_9. 고정자산 DETAIL Update
	            UPDATE  VN.GGA22M01
	               SET  SLIP_NO			=	O_SLIP_NO,
						SLIP_SUB_NO		=	O_SLIP_SUB_NO
				 WHERE	AST_NO		=	C31.AST_NO
				   AND	CHG_DT		=	I_LAST_DAY
				   AND	CHG_SN		=	C31.CHG_SN ;

		    END LOOP;   -- C31 End Loop

	    END LOOP;   -- C3 End Loop


    -- ************************
    -- * 월 감 가 상 각 취 소 *
    -- ************************
    ELSIF   I_FLAG  =   'D' THEN

	    -- CHK_10. 일반자산 월상각 전표처리 조회
	    FOR C4 IN
			(	SELECT	v11.TERMS						AS	TERMS,
						v11.DEPR_YM						AS	DEPR_YM,
						v11.BRCH_CD						AS	BRCH_CD,
						v11.AGNC_BRCH					AS	AGNC_BRCH,
						v11.DEPT_CD						AS	DEPT_CD,
						v12.AST_LKND					AS	AST_LKND,
						NVL(SUM(v11.TM_DEPR_AMT), 0)	AS	TM_DEPR_AMT,
						MAX(v11.SLIP_NO)				AS	SLIP_NO,
						MAX(v11.SLIP_SUB_NO)			AS	SLIP_SUB_NO
				  FROM
						(	SELECT	v21.TERMS					AS	TERMS,
									v21.DEPR_YM					AS	DEPR_YM,
									v21.BRCH_CD					AS	BRCH_CD,
									v21.AGNC_BRCH				AS	AGNC_BRCH,
									v21.DEPT_CD					AS	DEPT_CD,
									v21.AST_NO					AS	AST_NO,
									NVL(v21.TM_DEPR_AMT, 0)		AS	TM_DEPR_AMT,
									v22.SLIP_NO					AS	SLIP_NO,
									v22.SLIP_SUB_NO				AS	SLIP_SUB_NO
							  FROM	VN.GGA23M00	v21,
									(	SELECT	v31.AST_NO			AS	AST_NO,
												v31.SLIP_NO			AS	SLIP_NO,
												v31.SLIP_SUB_NO		AS	SLIP_SUB_NO
										  FROM	VN.GGA22M01	v31
										 WHERE	v31.CHG_DT		=	I_LAST_DAY
										   AND	v31.CHG_STAT	IN	(K_STAT_GU, K_STAT_GU1)
										   AND	v31.USE_YN		=	'Y'
										   AND	v31.CNCL_DT		IS NULL
									)			v22
							 WHERE	v21.TERMS		=	VN.FGG_GET_TERMS(I_LAST_DAY)
							   AND	v21.DEPR_YM		=	I_YYMM
							   AND	v21.BRCH_CD		=	I_BRCH_CD
							   AND	v21.AGNC_BRCH	=	I_AGNC_BRCH
							   AND	v21.AST_NO		=	v22.AST_NO(+)
						  ORDER BY	v21.TERMS,
									v21.DEPR_YM,
									v21.BRCH_CD,
									v21.AGNC_BRCH,
									v21.DEPT_CD,
									v21.AST_NO
						)			v11,
						VN.GGA22M00	v12
				 WHERE	v11.AST_NO		=	v12.AST_NO
			  GROUP BY	v11.TERMS,
						v11.DEPR_YM,
						v11.BRCH_CD,
						v11.AGNC_BRCH,
						v11.DEPT_CD,
						v12.AST_LKND
	        ) LOOP

    		IF  C4.DEPT_CD IN ('000', '100', '200', '300') THEN
				K_AST_SETL_TP := '1' ;
			ELSE
				K_AST_SETL_TP := '2' ;
    		END IF;

			O1_RTN_TBL	:=	NULL ;
			O1_RTN_ERR	:=	'0' ;
			O1_RTN_MSG	:=	NULL ;

		--	O_SLIP_NO		:=	NULL ;
		--	O_SLIP_SUB_NO	:=	NULL ;
			O_SLIP_NO1		:=	NULL ;
			O_SLIP_SUB_NO1	:=	NULL ;

			/* CHK_10. 감가상각 전표처리 Procedure Call */
			VN.PGG_ACT_SLIP_APPR(
				'D',						-- I:생성,D:취소
				I_LAST_DAY,					-- 전표일
				I_BRCH_CD,					-- 처리지점
				I_AGNC_BRCH,				-- 처리대리지점
				I_BRCH_CD,					-- 이체지점
				I_AGNC_BRCH,				-- 이체대리지점
				K_JOB_TP,					-- 적요업무구분('42')
				C4.AST_LKND,				-- 자산분류
				K_STAT_GU,					-- 고정자산구분
				K_AST_SETL_TP,				-- 자산결제구분
				K_ACC_ACT_CD,				-- 회계계정코드
				C4.DEPT_CD,					-- 부서코드
				K_CUST_CD,					-- 고객코드
				C4.TM_DEPR_AMT,				-- 차변금액01
				0,							-- 차변금액02
				0,							-- 차변금액03
				C4.TM_DEPR_AMT,				-- 대변금액01
				0,							-- 대변금액02
				0,							-- 대변금액03
				I_WORK_MN,					-- 처리자
				I_WORK_TRM,					-- IP_ADDRESS
				C4.SLIP_NO,					-- 전표번호
				c4.SLIP_SUB_NO,				-- 전표부번호
				O_SLIP_NO1,					-- 전표번호
				O_SLIP_SUB_NO1,				-- 전표부번호
				O1_RTN_TBL,
				O1_RTN_ERR,
				O1_RTN_MSG) ;

			vn.pxc_log_write('pgg_ast_rtrn_dept1','0: ' || C4.AST_LKND || ':' || O_SLIP_NO);

			IF  TO_NUMBER(O1_RTN_ERR)   <>   0  THEN
				vn.pxc_log_write('pgg_ast_rtrn_dept1','1: ' || C4.AST_LKND);
				RAISE ERR_PGG_ACT_SLIP_APPR;
		    END IF;

	    END LOOP;   -- C4 End Loop


	    -- CHK_1. 일반자산 월상각액 생성자료 조회
	    FOR C2 IN
			(	SELECT	v11.AST_NO					AS	AST_NO,
						NVL(v12.GET_AMT, 0)			AS	GET_AMT,
						NVL(v11.BPRD_DEPR_CUM, 0)	AS	BPRD_DEPR_CUM,
						TO_CHAR(ADD_MONTHS(LAST_DAY(TO_DATE(SUBSTR(v12.GET_DT, 1, 6) || '01', 'YYYY/MM/DD')), (NVL(v12.USE_YY_CNT, 0) * 12)), 'YYYYMM')	AS	DEPR_END_YM,
						v11.AST_STAT				AS	AST_STAT,
						v11.AST_STAT_DT				AS	AST_STAT_DT
				  FROM
						(	SELECT	v21.AST_NO			AS	AST_NO,
									(	SELECT	NVL(v31.BPRD_DEPR_CUM, 0) + NVL(v31.TPRD_DEPR_CUM, 0)	AS	BPRD_DEPR_CUM
										  FROM	VN.GGA23M01	v31
										 WHERE	v31.TERMS	=	(I_TERMS - 1)
										   AND	v31.DEPR_YY	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS - 1, '1'), 1, 4)
										   AND	v31.AST_NO	=	v21.AST_NO
									)							AS	BPRD_DEPR_CUM,
									(	SELECT	v31.CHG_STAT			AS	CHG_STAT
										  FROM	VN.GGA22M01	v31
										 WHERE	v31.AST_NO									=	v21.AST_NO
										   AND	v31.CHG_DT||TRIM(TO_CHAR(v31.CHG_SN,'000'))	=	(	SELECT	MAX(v41.CHG_DT||TRIM(TO_CHAR(v41.CHG_SN,'000')))
																									  FROM	VN.GGA22M01	v41
																									 WHERE	v41.AST_NO		=	v21.AST_NO
																									   AND	v41.CHG_DT		<=	I_LAST_DAY
																									   AND	v41.CHG_STAT	NOT IN	('C', 'S')
																								)
									)							AS	AST_STAT,
									(	SELECT	v31.CHG_DT		AS	CHG_DT
										  FROM	VN.GGA22M01	v31
										 WHERE	v31.AST_NO									=	v21.AST_NO
										   AND	v31.CHG_DT||TRIM(TO_CHAR(v31.CHG_SN,'000'))	=	(	SELECT	MAX(v41.CHG_DT||TRIM(TO_CHAR(v41.CHG_SN,'000')))
																									  FROM	VN.GGA22M01	v41
																									 WHERE	v41.AST_NO		=	v21.AST_NO
																									   AND	v41.CHG_DT		<=	I_LAST_DAY
																									   AND	v41.CHG_STAT	NOT IN	('C', 'S')
																								)
									)							AS	AST_STAT_DT
							  FROM	VN.GGA23M00	v21
							 WHERE	v21.TERMS		=	I_TERMS
							   AND	v21.DEPR_YM		=	I_YYMM
							   AND	v21.BRCH_CD		=	I_BRCH_CD
							   AND	v21.AGNC_BRCH	=	I_AGNC_BRCH
						)			v11,
						VN.GGA22M00	v12
				 WHERE	v11.AST_NO		=	v12.AST_NO
			  ORDER BY	v11.AST_NO
	        ) LOOP

			T_AST_NO := C2.AST_NO ;
			T_DEPR_AMT := 0;

	        -- CHK_2. 일반자산 월상각액 Delete
	        DELETE
	          FROM  VN.GGA23M00
			 WHERE	TERMS		=	I_TERMS
			   AND	DEPR_YM		=	I_YYMM
			   AND	AST_NO		=	C2.AST_NO ;


			T_BPRD_DEPR_CUM :=	0;
			T_TPRD_DEPR_CUM :=	0;
			T_NDEPR_REMN 	:=	0;

	        -- CHK_3. 일반자산 전월까지 당기상각누계액 구하기
			SELECT	NVL(SUM(v11.TM_DEPR_AMT), 0)	AS	TPRD_DEPR_CUM
			  INTO	T_TPRD_DEPR_CUM
			  FROM	VN.GGA23M00	v11
			 WHERE	v11.TERMS  		=	I_TERMS
			   AND	v11.DEPR_YM		>=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 6)
			   AND	v11.DEPR_YM		<	I_YYMM
			   AND	v11.AST_NO		=   C2.AST_NO ;

			-- 당기상각누계액
			T_TPRD_DEPR_CUM :=	T_TPRD_DEPR_CUM + T_DEPR_AMT;
			-- 미상각잔액
			T_NDEPR_REMN 	:=	NVL(C2.GET_AMT, 0) - ( NVL(C2.BPRD_DEPR_CUM, 0) + T_TPRD_DEPR_CUM ) ;


	        -- CHK_4. 일반자산 년상각 처리 Update
			IF	T_NUM	=	1	THEN

				BEGIN
	                UPDATE  VN.GGA23M01
	                   SET  DEPR_AMT_01		=	T_DEPR_AMT,
							TPRD_DEPR_CUM	=	T_TPRD_DEPR_CUM,
							NDEPR_REMN		=	T_NDEPR_REMN,
							MDFY_MN  		=   I_WORK_MN,
	                        MDFY_DTM  		=   SYSDATE,
	                        MDFY_TRM  		=   I_WORK_TRM
					 WHERE	TERMS  		=	I_TERMS
					   AND	DEPR_YY  	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
					   AND	AST_NO		=   C2.AST_NO ;

			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA23M01_UPD;
			    END;

		    ELSIF   T_NUM  =   2 THEN

				BEGIN
	                UPDATE  VN.GGA23M01
	                   SET  DEPR_AMT_02		=	T_DEPR_AMT,
							TPRD_DEPR_CUM	=	T_TPRD_DEPR_CUM,
							NDEPR_REMN		=	T_NDEPR_REMN,
							MDFY_MN  		=   I_WORK_MN,
	                        MDFY_DTM  		=   SYSDATE,
	                        MDFY_TRM  		=   I_WORK_TRM
					 WHERE	TERMS  		=	I_TERMS
					   AND	DEPR_YY  	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
					   AND	AST_NO		=   C2.AST_NO ;

			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA23M01_UPD;
			    END;

		    ELSIF   T_NUM  =   3 THEN

				BEGIN
	                UPDATE  VN.GGA23M01
	                   SET  DEPR_AMT_03		=	T_DEPR_AMT,
							TPRD_DEPR_CUM	=	T_TPRD_DEPR_CUM,
							NDEPR_REMN		=	T_NDEPR_REMN,
							MDFY_MN  		=   I_WORK_MN,
	                        MDFY_DTM  		=   SYSDATE,
	                        MDFY_TRM  		=   I_WORK_TRM
					 WHERE	TERMS  		=	I_TERMS
					   AND	DEPR_YY  	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
					   AND	AST_NO		=   C2.AST_NO ;

			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA23M01_UPD;
			    END;

		    ELSIF   T_NUM  =   4 THEN

				BEGIN
	                UPDATE  VN.GGA23M01
	                   SET  DEPR_AMT_04		=	T_DEPR_AMT,
							TPRD_DEPR_CUM	=	T_TPRD_DEPR_CUM,
							NDEPR_REMN		=	T_NDEPR_REMN,
							MDFY_MN  		=   I_WORK_MN,
	                        MDFY_DTM  		=   SYSDATE,
	                        MDFY_TRM  		=   I_WORK_TRM
					 WHERE	TERMS  		=	I_TERMS
					   AND	DEPR_YY  	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
					   AND	AST_NO		=   C2.AST_NO ;

			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA23M01_UPD;
			    END;

		    ELSIF   T_NUM  =   5 THEN

				BEGIN
	                UPDATE  VN.GGA23M01
	                   SET  DEPR_AMT_05		=	T_DEPR_AMT,
							TPRD_DEPR_CUM	=	T_TPRD_DEPR_CUM,
							NDEPR_REMN		=	T_NDEPR_REMN,
							MDFY_MN  		=   I_WORK_MN,
	                        MDFY_DTM  		=   SYSDATE,
	                        MDFY_TRM  		=   I_WORK_TRM
					 WHERE	TERMS  		=	I_TERMS
					   AND	DEPR_YY  	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
					   AND	AST_NO		=   C2.AST_NO ;

			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA23M01_UPD;
			    END;

		    ELSIF   T_NUM  =   6 THEN

				BEGIN
	                UPDATE  VN.GGA23M01
	                   SET  DEPR_AMT_06		=	T_DEPR_AMT,
							TPRD_DEPR_CUM	=	T_TPRD_DEPR_CUM,
							NDEPR_REMN		=	T_NDEPR_REMN,
							MDFY_MN  		=   I_WORK_MN,
	                        MDFY_DTM  		=   SYSDATE,
	                        MDFY_TRM  		=   I_WORK_TRM
					 WHERE	TERMS  		=	I_TERMS
					   AND	DEPR_YY  	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
					   AND	AST_NO		=   C2.AST_NO ;

			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA23M01_UPD;
			    END;

		    ELSIF   T_NUM  =   7 THEN

				BEGIN
	                UPDATE  VN.GGA23M01
	                   SET  DEPR_AMT_07		=	T_DEPR_AMT,
							TPRD_DEPR_CUM	=	T_TPRD_DEPR_CUM,
							NDEPR_REMN		=	T_NDEPR_REMN,
							MDFY_MN  		=   I_WORK_MN,
	                        MDFY_DTM  		=   SYSDATE,
	                        MDFY_TRM  		=   I_WORK_TRM
					 WHERE	TERMS  		=	I_TERMS
					   AND	DEPR_YY  	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
					   AND	AST_NO		=   C2.AST_NO ;

			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA23M01_UPD;
			    END;

		    ELSIF   T_NUM  =   8 THEN

				BEGIN
	                UPDATE  VN.GGA23M01
	                   SET  DEPR_AMT_08		=	T_DEPR_AMT,
							TPRD_DEPR_CUM	=	T_TPRD_DEPR_CUM,
							NDEPR_REMN		=	T_NDEPR_REMN,
							MDFY_MN  		=   I_WORK_MN,
	                        MDFY_DTM  		=   SYSDATE,
	                        MDFY_TRM  		=   I_WORK_TRM
					 WHERE	TERMS  		=	I_TERMS
					   AND	DEPR_YY  	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
					   AND	AST_NO		=   C2.AST_NO ;

			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA23M01_UPD;
			    END;

		    ELSIF   T_NUM  =   9 THEN

				BEGIN
	                UPDATE  VN.GGA23M01
	                   SET  DEPR_AMT_09		=	T_DEPR_AMT,
							TPRD_DEPR_CUM	=	T_TPRD_DEPR_CUM,
							NDEPR_REMN		=	T_NDEPR_REMN,
							MDFY_MN  		=   I_WORK_MN,
	                        MDFY_DTM  		=   SYSDATE,
	                        MDFY_TRM  		=   I_WORK_TRM
					 WHERE	TERMS  		=	I_TERMS
					   AND	DEPR_YY  	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
					   AND	AST_NO		=   C2.AST_NO ;

			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA23M01_UPD;
			    END;

		    ELSIF   T_NUM  =   10 THEN

				BEGIN
	                UPDATE  VN.GGA23M01
	                   SET  DEPR_AMT_10		=	T_DEPR_AMT,
							TPRD_DEPR_CUM	=	T_TPRD_DEPR_CUM,
							NDEPR_REMN		=	T_NDEPR_REMN,
							MDFY_MN  		=   I_WORK_MN,
	                        MDFY_DTM  		=   SYSDATE,
	                        MDFY_TRM  		=   I_WORK_TRM
					 WHERE	TERMS  		=	I_TERMS
					   AND	DEPR_YY  	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
					   AND	AST_NO		=   C2.AST_NO ;

			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA23M01_UPD;
			    END;

		    ELSIF   T_NUM  =   11 THEN

				BEGIN
	                UPDATE  VN.GGA23M01
	                   SET  DEPR_AMT_11		=	T_DEPR_AMT,
							TPRD_DEPR_CUM	=	T_TPRD_DEPR_CUM,
							NDEPR_REMN		=	T_NDEPR_REMN,
							MDFY_MN  		=   I_WORK_MN,
	                        MDFY_DTM  		=   SYSDATE,
	                        MDFY_TRM  		=   I_WORK_TRM
					 WHERE	TERMS  		=	I_TERMS
					   AND	DEPR_YY  	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
					   AND	AST_NO		=   C2.AST_NO ;

			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA23M01_UPD;
			    END;

		    ELSIF   T_NUM  =   12 THEN

				BEGIN
	                UPDATE  VN.GGA23M01
	                   SET  DEPR_AMT_12		=	T_DEPR_AMT,
							TPRD_DEPR_CUM	=	T_TPRD_DEPR_CUM,
							NDEPR_REMN		=	T_NDEPR_REMN,
							MDFY_MN  		=   I_WORK_MN,
	                        MDFY_DTM  		=   SYSDATE,
	                        MDFY_TRM  		=   I_WORK_TRM
					 WHERE	TERMS  		=	I_TERMS
					   AND	DEPR_YY  	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
					   AND	AST_NO		=   C2.AST_NO ;

			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA23M01_UPD;
			    END;

			END IF;


		    -- CHK_5. 고정자산 MASTER Update
			IF	C2.DEPR_END_YM	=	I_YYMM	THEN

				T_CHG_STAT := 'S' ;

				BEGIN
	                UPDATE  VN.GGA22M00
	                   SET  DEPR_CUM		=	( NVL(C2.BPRD_DEPR_CUM, 0) + T_TPRD_DEPR_CUM ),
							DEPR_END_YM		=	C2.DEPR_END_YM,
							AST_STAT		=	C2.AST_STAT,
							AST_STAT_DT		=	C2.AST_STAT_DT,
							DEPR_END_DT		=	NULL,
							MDFY_MN  		=   I_WORK_MN,
	                        MDFY_DTM  		=   SYSDATE,
	                        MDFY_TRM  		=   I_WORK_TRM
					 WHERE	AST_NO		=   C2.AST_NO ;

			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA22M00_UPD;
			    END;

			ELSE

				T_CHG_STAT := 'C' ;

				BEGIN
	                UPDATE  VN.GGA22M00
	                   SET  DEPR_CUM		=	( NVL(C2.BPRD_DEPR_CUM, 0) + T_TPRD_DEPR_CUM ),
							DEPR_END_YM		=	C2.DEPR_END_YM,
							AST_STAT		=	C2.AST_STAT,
							AST_STAT_DT		=	C2.AST_STAT_DT,
							MDFY_MN  		=   I_WORK_MN,
	                        MDFY_DTM  		=   SYSDATE,
	                        MDFY_TRM  		=   I_WORK_TRM
					 WHERE	AST_NO		=   C2.AST_NO ;

			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA22M00_UPD;
			    END;

			END IF;


	        -- CHK_2. 고정자산 DETAIL Delete
	        DELETE
	          FROM  VN.GGA22M01
			 WHERE	AST_NO		=	C2.AST_NO
			   AND	CHG_DT		=	I_LAST_DAY
			   AND	CHG_STAT	=   T_CHG_STAT ;


	    END LOOP;   -- C2 End Loop


	END IF;


    O_RTN_TBL  :=  'PGG_AST_RTRN_DEPR1';
    O_RTN_ERR  :=  '0';
    --O_RTN_MSG  :=  '[V0602] 정상적으로 처리되었습니다.';
    O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','0602');
    --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);

EXCEPTION
    WHEN    ERR_FGG_AST_RTRN_DEPR  THEN
        O_RTN_TBL  :=  'ERR_FGG_AST_RTRN_DEPR';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2016]자료가 존재하지 않습니다';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016');
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA23M00_INS  THEN
        O_RTN_TBL  :=  'ERR_GGA23M00_INS';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2627]전표번호 생성중 오류가 발생하였습니다. [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2627') || ' [' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA23M01_UPD  THEN
        O_RTN_TBL  :=  'ERR_GGA23M01_UPD';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2627]전표번호 생성중 오류가 발생하였습니다. [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2627') || ' [' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA22M00_UPD  THEN
        O_RTN_TBL  :=  'ERR_GGA22M00_UPD';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2627]전표번호 생성중 오류가 발생하였습니다. [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2627') || ' [' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA22M01_INS  THEN
        O_RTN_TBL  :=  'ERR_GGA22M01_INS';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2627]전표번호 생성중 오류가 발생하였습니다. [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2627') || ' [' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_PGG_ACT_SLIP_APPR  THEN
        O_RTN_TBL  :=  'ERR_PGG_ACT_SLIP_APPR';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2016]자료가 존재하지 않습니다';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016');
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    OTHERS  THEN
        O_RTN_TBL  :=  'OTHERS';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        O_RTN_MSG  :=  'ERROR ' || SUBSTR(SQLERRM, 1, 100);
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
END PGG_AST_RTRN_DEPR1;
/

