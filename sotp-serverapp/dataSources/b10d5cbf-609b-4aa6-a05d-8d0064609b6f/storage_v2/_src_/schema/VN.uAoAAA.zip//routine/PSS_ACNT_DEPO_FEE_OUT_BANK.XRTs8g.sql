create procedure    pss_acnt_depo_fee_out_bank(i_sec_cd   in varchar2,
                                                       i_acnt_no  in varchar2,
                                                       i_sub_no   in varchar2,
                                                       i_bank_bal in number,
                                                       i_work_mn  in varchar2,
                                                       i_work_trm in varchar2) is

  K_RMRK_CD        VARCHAR2(3) := '247';
  vn_curt_bank_bal number;
  td_adj_amt       number;

  O_TRD_SEQ_NO NUMBER;
  O1_RTN_TBL   VARCHAR2(100); -- Return Table
  O1_RTN_ERR   VARCHAR2(100); -- Return Error Code
  O1_RTN_MSG   VARCHAR2(254); -- Return Message
  vn_limit_fee number := 0;
  vn_total_fee number := 0;
  vn_commit    number := 0;
  vn_count     number := 0;
  vn_commit2   number := 0;
begin
  /* Hoai them 20150702: Jira 988*/
  select vn.fss_get_depo_limit_amt(i_sec_cd, '10', '00')
    into vn_limit_fee
    from dual;

  vn.pxc_log_write('pss_acnt_depo_fee_out_bank',
                   '[' || sysdate || '-' || i_acnt_no || '-' || i_sub_no || ']');
  /*if (vn.fxb_daily_stat_chk ('B','0','2200','2200','*') <> 'Y' or
     vn.fxb_daily_stat_chk ('B','0','2300','2300','*') <> 'Y' or
     vn.fxb_daily_stat_chk ('B','0','2400','2400','*') <> 'Y' or
     vn.fxb_daily_stat_chk ('B','0','2410','2410','*') <> 'Y' or
     vn.fxb_daily_stat_chk ('B','0','2450','2450','*') <> 'Y')
  then
   vn.pxc_log_write('pss_acnt_depo_fee_out_dt', 'Not finished Previous BATCH');
     return;
  end if;
  */

  /*VCSC-1774: Check them các mon phi LK còn dang hold trên 04003*/
  vn_curt_bank_bal := i_bank_bal;

  select nvl(sum(adj_amt), 0)
    into td_adj_amt
    from vn.dsc10m00
   where acnt_no = i_acnt_no
     and sub_no = i_sub_no
     and job_tp = '7'
     and cncl_yn = 'N'
     and send_stat = 'Q'
     and RECV_STAT = 'N'
     and trd_dt = vn.vwdate;

  vn_curt_bank_bal := i_bank_bal - td_adj_amt;

  for c1 in (select acnt_no,
                    sub_no,
                    usefee,
                    usefee_pay_dt,
                    seq_no,
                    mak_strt_dt
               from vn.ssb07m00
              where acnt_no = i_acnt_no
                and sub_no like i_sub_no
                and rcpt_trd_no = 0
                and cncl_yn = 'N'
                and (vn.faa_acnt_bank_cd_g(acnt_no, sub_no) = '0003' or
                    vn.faa_acnt_bank_cd_g(acnt_no, sub_no) = '0002')
                and usefee <= vn_curt_bank_bal
                and usefee > vn_limit_fee
              order by acnt_no || mak_strt_dt || sub_no) loop

    begin
      /*  t_avail_depo_fee := vn.fcw_avail_cash_depo_fee(i_sec_cd,I_ACNT_NO,I_SUB_NO);
      */
      vn.pxc_log_write('pss_acnt_depo_fee_out_bank',
                       ' acnt_no ' || c1.acnt_no || '-' || c1.sub_no ||
                       ' bank bal ' || i_bank_bal || ' depo fee ' ||
                       c1.usefee);

      vn_count     := 0;
      vn_total_fee := vn_total_fee + c1.usefee;

      if (vn_curt_bank_bal >= vn_total_fee) then
        /* withdraw depo fee after unblock */

        VN.PSS_CASH_OUTAMT_P(VN.VWDATE,
                             c1.ACNT_NO,
                             c1.SUB_NO,
                             K_RMRK_CD,
                             c1.usefee,
                             '00',
                             ' ',
                             --K_CNFM_YN,
                             'tháng ' || substr(c1.mak_strt_dt, 5, 2) || '/' ||
                             substr(c1.mak_strt_dt, 1, 4),
                             ' ',
                             I_WORK_MN,
                             I_WORK_TRM,
                             O_TRD_SEQ_NO,
                             O1_RTN_TBL,
                             O1_RTN_ERR,
                             O1_RTN_MSG);

        IF TO_NUMBER(O1_RTN_ERR) <> 0 THEN
          /* 3. ERROR */
          vn_total_fee := vn_total_fee - c1.usefee;
          vn.pxc_log_write('pss_acnt_depo_fee_out_bank',
                           ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL ||
                           '] [' || O1_RTN_MSG || ']');
          --raise_application_error(-20100,'PSS_CASH_OUTAMT_P '||sqlerrm);
        end if;

        /* Update ssb07m00 */
        if (O_TRD_SEQ_NO > 0) then

          update vn.ssb07m00
             set rcpt_trd_no = O_TRD_SEQ_NO
                 --                  ,tot_blk_fee  = 0
                ,
                 work_mn  = i_work_mn,
                 work_trm = i_work_trm,
                 work_dtm = sysdate
           where usefee_pay_dt = c1.usefee_pay_dt
             and mak_strt_dt = c1.mak_strt_dt
             and acnt_no = c1.acnt_no
             and sub_no = c1.sub_no
             and seq_no = c1.seq_no;
          /*vn_total_fee := vn_total_fee + c1.usefee;*/
          vn_count := 1;
        end if;
      else
        commit;
        return;
      end if;

      /*if vn_count = 0 then
        vn_total_fee := vn_total_fee - c1.usefee;
      end if;*/

      vn_commit  := vn_commit + 1;
      vn_commit2 := vn_commit2 + 1;
      vn.pxc_log_write('pss_acnt_depo_fee_out_bank',
                       'vn_commit' || to_char(vn_commit));
      vn.pxc_log_write('pss_acnt_depo_fee_out_bank',
                       'vn_commit2' || to_char(vn_commit2));

      if vn_commit >= 500 then
        vn.pxc_log_write('pss_acnt_depo_fee_out_bank',
                         'I will commit now!');
        vn_commit := 0;
        commit;
      end if;
    end;
  end loop;

  commit;
  return;
end pss_acnt_depo_fee_out_bank;
/

