create procedure psr_del_rgt_acnt_p
 (i_sec_cd     in       varchar2,
  i_rgt_std_dt in       varchar2,
  i_stk_cd     in       varchar2,
  i_rgt_tp     in       varchar2,
  i_seq_no     in       number,
  i_acnt_no    in       varchar2,
  i_sub_no     in       varchar2,
  i_proc_dt    in   	varchar2,
  i_proc_seq   in   	number,
  i_work_mn    in       varchar2,
  i_work_trm   in       varchar2
 ) is

	vn_own_qty			number := 0;
	vn_cons_sbst_qty	number := 0;
	vn_asn_qty			number := 0;
	vn_asn_amt			number := 0;
	vn_flotq_amt		number := 0;
	vn_inter_amt		number := 0;
	vn_tax_asn			number := 0;
	vn_tax_flotq		number := 0;
	vn_tax_int			number := 0;
	vn_rgt_iss_pri  	number := 0;
begin

     vn.pxc_log_write('psr_del_rgt_acnt_p', 'acnt_no: '||i_acnt_no||'-'||i_sub_no);
	 vn.pxc_log_write('psr_del_rgt_acnt_p', 'rgt_std_dt'||i_rgt_std_dt||'- stk_cd '||i_stk_cd||'- rgt_tp: ' ||i_rgt_tp||'- rgt_seq: '||i_seq_no||'-');
	 vn.pxc_log_write('psr_del_rgt_acnt_p', 'proc_dt'||i_proc_dt||'- proc_seq '||i_proc_seq);

	select 	nvl(rgt_own_qty,0)  ,
			nvl(cons_sbst_qty,0),
			nvl(asn_qty,0)  	,
			nvl(asn_amt,0)     	,
			nvl(flotq_amt,0)  	,
			nvl(inter_amt,0)    ,
			nvl(tax_asn,0)     	,
			nvl(tax_flotq,0)  	,
			nvl(tax_int,0)
	Into 	vn_own_qty,
			vn_cons_sbst_qty,
			vn_asn_qty,
			vn_asn_amt,
			vn_flotq_amt,
			vn_inter_amt,
			vn_tax_asn,
			vn_tax_flotq,
			vn_tax_int
	from 	vn.srr02m10
	where 	rgt_std_dt 	= i_rgt_std_dt
	and 	stk_cd     	= i_stk_cd
	and		rgt_tp 		= i_rgt_tp
	and		seq_no		= i_seq_no
	and		acnt_no		= i_acnt_no
	and		sub_no		= i_sub_no
	and		proc_dt		= i_proc_dt
	and		proc_Seq	= i_proc_seq
	and		proc_tp		<> 'X';

	if i_rgt_tp in ('1','4','5') then
		select 	rgt_iss_pri
		into 	vn_rgt_iss_pri
		from 	vn.srr01m00
		where 	rgt_std_dt 	= i_rgt_std_dt
		and 	stk_cd     	= i_stk_cd
		and		rgt_tp 		= i_rgt_tp
		and		seq_no		= i_seq_no;
	else
		vn_rgt_iss_pri := 0;
	end if;

	update 	vn.srr02m00
	Set		own_stk_qty = own_stk_qty - vn_own_qty,
			own_qty		= own_qty - vn_own_qty,
			asn_qty		= asn_qty - vn_asn_qty,
			asn_amt		= asn_amt - vn_asn_amt,
			flotq_amt	= flotq_amt - vn_flotq_amt,
			inter_amt	= inter_amt - vn_inter_amt,
			tax_asn		= tax_asn - vn_tax_asn,
			tax_flotq	= tax_flotq - vn_tax_flotq,
			tax_int		= tax_int - vn_tax_int,
			cons_sbst_qty = cons_sbst_qty - vn_cons_sbst_qty,
			cons_sbst_amt = cons_sbst_amt - (vn_cons_sbst_qty*vn_rgt_iss_pri),
			trans_tp	= '0',
			work_mn		= i_work_mn,
			work_dtm	= sysdate,
			work_trm	= i_work_trm
	Where	rgt_std_dt	= i_rgt_std_dt
	and		stk_cd		= i_stk_cd
	and 	rgt_tp		= i_rgt_tp
	and		seq_no		= i_seq_no
	and		acnt_no		= i_acnt_no
	and		sub_no		= i_sub_no;

	update 	vn.srr02m10
	Set		proc_tp 	= 'X',
			work_mn		= i_work_mn,
			work_dtm	= sysdate,
			work_trm	= i_work_trm
	Where	rgt_std_dt	= i_rgt_std_dt
	and		stk_cd		= i_stk_cd
	and 	rgt_tp		= i_rgt_tp
	and		seq_no		= i_seq_no
	and		acnt_no		= i_acnt_no
	and		sub_no		= i_sub_no
	and		proc_dt		= i_proc_dt
	and		proc_seq	= i_proc_seq
	and		proc_tp		<> 'X';

	delete from vn.srr02m00
	where  rgt_std_dt	= i_rgt_std_dt
	and		stk_cd		= i_stk_cd
	and 	rgt_tp		= i_rgt_tp
	and		seq_no		= i_seq_no
	and		acnt_no		= i_acnt_no
	and		sub_no		= i_sub_no
	and   	own_qty   	= 0
	and   	own_stk_qty = 0;

end  psr_del_rgt_acnt_p;
/

