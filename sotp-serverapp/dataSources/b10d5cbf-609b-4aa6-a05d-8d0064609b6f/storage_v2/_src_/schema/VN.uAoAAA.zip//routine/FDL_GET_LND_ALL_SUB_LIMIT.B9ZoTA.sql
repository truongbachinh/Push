create PROCEDURE fdl_get_lnd_all_sub_limit
(
   i_acnt_no      in    VARCHAR2
  ,o_acnt_limit   out   NUMBER
  ,o_check      out   VARCHAR2
)
AS
  /*!
     \file     fdl_get_lnd_all_sub_limit.sql
     \brief    fdl_get_lnd_all_sub_limit
     \section intro Program Information
          - Program Name              :
          - Service Name              :
          - Related Client Program- Client Program ID :
          - Related Tables            : dlm20m06, xcc01c02
          - Dev. Date                 : 2021/06/24
          - Developer                 : TienLH.
          - Business Logic Desc.      : fdl_get_lnd_all_sub_limit
      - Modify by                 :
          - Latest Modification Date  :
   */
  t_cust_max_amt NUMBER := 0;
  t_all_src_max_limit   NUMBER := 0;

  t_vwdate varchar2(8) := vn.vwdate;
  t_err_msg VARCHAR2(500);

BEGIN

  o_acnt_limit := 0;
  o_check := 'Y';

  BEGIN
        SELECT MIN(nvl(cust_max_amt, 0))
        INTO t_cust_max_amt         /*X*/
        FROM vn.dlm20m06 t
        WHERE  t.apy_dt <= t_vwdate
            AND t.expr_dt >= t_vwdate
            AND ACTIVE_STAT='Y'
            AND t.acnt_no LIKE i_acnt_no;
    EXCEPTION
    WHEN OTHERS THEN
        t_err_msg := vn.fxc_get_err_msg('V', '46053');
        vn.pxc_log_write('pdl_get_acnt_max_limit',
                        ' Tong han muc cua tai khoan error: ' || t_err_msg || ' ACNT_NO=' || i_acnt_no);
        raise_application_error(-20100,
                                t_err_msg ||
                                ' pdl_get_acnt_max_limit: ACNT_NO_STK_i_tp=' || i_acnt_no);
    END;

    IF t_cust_max_amt IS NOT NULL THEN
        o_acnt_limit := t_cust_max_amt;
    ELSE
        BEGIN
            SELECT TO_NUMBER(nvl(col_cd_tp, 0))
            INTO t_all_src_max_limit        /*A*/
            FROM vn.xcc01c02 a
            WHERE  a.col_cd LIKE 'all_src_max_limit'
                AND a.param_tp LIKE '401';
        EXCEPTION
            WHEN no_data_found THEN
        t_all_src_max_limit := 0;
        o_check := 'N';
            WHEN OTHERS THEN
            t_err_msg := vn.fxc_get_err_msg('V', '46054');
            vn.pxc_log_write('pdl_get_acnt_max_limit',
                                ' Select xcc01c02 error: ' || t_err_msg ||
                                ' col_cd= all_src_max_limit' );
        END;
        o_acnt_limit := nvl(t_all_src_max_limit, 0);
    END IF;

END fdl_get_lnd_all_sub_limit;
/

