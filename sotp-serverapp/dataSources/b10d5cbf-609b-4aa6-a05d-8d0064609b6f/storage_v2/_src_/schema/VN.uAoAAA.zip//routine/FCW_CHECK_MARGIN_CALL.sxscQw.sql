create function    fcw_check_margin_call
(
   i_acnt_no          in       varchar2 
) 
return varchar2 as

    t_cmr    number := 0;
    t_call   number := 0;

begin

       FOR C1 IN (
                  select t.sub_no sub_no
                    from vn.cwd01m00 t
                   where acnt_no = i_acnt_no
                     and sub_no <> '00'
                order by t.sub_no
        ) LOOP

            SELECT	vn.fdl_get_mrgn_rt_01(i_acnt_no, c1.sub_no, '25' , vn.vwdate),
					vn.fdl_get_mrgn_grp_acnt_rt( i_acnt_no, c1.sub_no,vn.faa_acnt_get_grp_no (i_acnt_no, c1.sub_no,'2', vn.vwdate),'04', vn.vwdate)
            INTO		t_cmr, t_call		
            FROM		dual ;    

            if t_call > t_cmr then
               return 'Y';  
            end if;

        END LOOP;        

        RETURN 'N';

end fcw_check_margin_call;
/

