create function fcw_get_fst_dt
(
    i_dt   in   varchar2        -- yyyymmdd
)
    return          varchar2
as
    o_result	    varchar2(1)  ;
    t_befor_dt       varchar2(10)  ;

begin

	BEGIN
	   select to_char(dt_dt,'yyyymm')
         into t_befor_dt
         from vn.xcc10m00
         where base_idx = '-1'  ;
    EXCEPTION
        when  OTHERS         then
            vn.pxc_log_write('fcw_get_fst_dt','xcc10m00 before date is not exist -'||  i_dt );
            raise_application_error (-20100, 'error');
    END;

            vn.pxc_log_write('fcw_get_fst_dt','i_dt -'|| trim(substr(i_dt,1,6)) );
            vn.pxc_log_write('fcw_get_fst_dt','t_befor_dt -'||  t_befor_dt );

	BEGIN
       select 'Y'
         into  o_result
         from  dual
        where  trim(t_befor_dt) <> trim(substr(i_dt,1,6)) ;
    EXCEPTION
		when  OTHERS         then
             o_result := 'N' ;
	END;

    return  o_result;

end fcw_get_fst_dt;
/

