create PROCEDURE pss_stk_dt_remn_proc_p (i_proc_dt IN varchar2,
                                                       i_work_mn IN varchar2,
                                                       i_work_trm IN varchar2,
                                                       o_proc_cnt OUT number
)
IS
   /***************************************************************************/
   /* Right standard work                                                     */
   /* 2007-10-22                                                              */
   /* 2021-09-08  vnjvthangnm NHSV-1622                                       */
   /***************************************************************************/
   --vn_count   number;
   --vn_count2  number;
   --vs_stk_tp  varchar2(2);
   t_pd_cls_pri      NUMBER;
   t_pd_cls_pri_bk   NUMBER;
   t_last_cls_pri    NUMBER; /* NHSV-1622 */
   t_prev_dt         VARCHAR2(8); /* NHSV-1622 */

   v_hnx_idx         NUMBER := 0;
   v_upc_idx         NUMBER := 0;
   v_hnx_qty         NUMBER := 0;
   v_hnx_amt         NUMBER := 0;
   v_upc_qty         NUMBER := 0;
   v_upc_amt         NUMBER := 0;
BEGIN
   vn.pxc_log_write ('pss_stk_dt_remn_proc_p', 'start');

   o_proc_cnt        := 0;
   t_pd_cls_pri      := 0;
   t_pd_cls_pri_bk   := 0;

   t_prev_dt := to_char(fxc_orderdt_g(to_date(i_proc_dt,'YYYYMMDD'),-1),'YYYYMMDD');

   DELETE FROM vn.ssi01h00_pd;

   DELETE FROM vn.ssi01h00 t
    WHERE t.dt = i_proc_dt;

   DELETE FROM vn.ssi07h00 t
    WHERE t.dt = i_proc_dt;

   /*DELETE FROM vn.ssi08h00 t
    WHERE t.dt = i_proc_dt;*/

   DELETE FROM vn.SSI05M00 t
    WHERE t.dt = i_proc_dt;

   --delete from vn.ssi01h00_pd;
   DELETE FROM vn.ssb01h00
    WHERE rgt_std_dt = i_proc_dt;
    --HuongLT add for NHSV-1092
    Update vn.ssi08h00 t
    set active_stat='X'
    where t.dt= i_proc_dt
    and   t.active_stat='W';

   FOR c1
   IN (SELECT acnt_no,
              sub_no,
              stk_cd,
              stk_tp,
              own_qty,
              book_amt,
              bclm_qty,
              mrtg_lnd_qty,
              mrtg_buy_qty,
              NVL (sb_lim_qty, 0) sb_lim_qty,
              NVL (mov_lim_qty, 0) mov_lim_qty,
              NVL (lim_req_qty, 0) lim_req_qty,
              NVL (outq_req_qty, 0) outq_req_qty,
              NVL (delay_qty, 0) delay_qty,
              NVL (delay_sb_qty, 0) delay_sb_qty,
              NVL (delay_mov_qty, 0) delay_mov_qty,
              NVL (delay_reg_qty, 0) delay_reg_qty,
              NVL (delay_req_sb_qty,0) delay_req_sb_qty,
              NVL (sbst_dpo, 0) sbst_dpo,
              NVL (sbst_able_block, 0) sbst_able_block,
              NVL (sbst_unit_amt, 0) sbst_unit_amt,
              --  nvl(rgt_qty, 0)  rgt_qty,
              NVL (blk_qty, 0) blk_qty,
              NVL (dpo_qty, 0) dpo_qty,
              NVL (out_blk_qty, 0) out_blk_qty,
              NVL (out_dpo_qty, 0) out_dpo_qty,
              NVL (out_unblk_qty, 0) out_unblk_qty,
              NVL (out_delvr_qty, 0) out_delvr_qty,
              NVL(waiting_exec_qty,0) waiting_exec_qty -- Huedt add CW
         FROM vn.ssb01m00
        WHERE own_qty > 0)
   LOOP
      o_proc_cnt   := o_proc_cnt + 1;

      INSERT INTO vn.ssb01h00
            (
                rgt_std_dt,
                acnt_no,
                sub_no,
                stk_cd,
                own_qty,
                book_amt,
                bclm_qty,
                mrtg_lnd_qty,
                mrtg_buy_qty,
                sb_lim_qty,
                mov_lim_qty,
                lim_req_qty,
                outq_req_qty,
                delay_qty,
                delay_sb_qty,
                delay_mov_qty,
                delay_reg_qty,
                delay_req_sb_qty,
                sbst_dpo,
                sbst_able_block,
                sbst_unit_amt,
                blk_qty,
                dpo_qty,
                out_blk_qty,
                out_dpo_qty,
                out_unblk_qty,
                out_delvr_qty,
                work_mn,
                work_dtm,
                work_trm,
                waiting_exec_qty -- Huedt add CW
            )
      VALUES (
                i_proc_dt,
                c1.acnt_no,
                c1.sub_no,
                c1.stk_cd,
                c1.own_qty,
                c1.book_amt,
                c1.bclm_qty,
                c1.mrtg_lnd_qty,
                c1.mrtg_buy_qty,
                c1.sb_lim_qty,
                c1.mov_lim_qty,
                c1.lim_req_qty,
                c1.outq_req_qty,
                c1.delay_qty,
                c1.delay_sb_qty,
                c1.delay_mov_qty,
                c1.delay_reg_qty,
                c1.delay_req_sb_qty,
                c1.sbst_dpo,
                c1.sbst_able_block,
                c1.sbst_unit_amt,
                c1.blk_qty,
                c1.dpo_qty,
                c1.out_blk_qty,
                c1.out_dpo_qty,
                c1.out_unblk_qty,
                c1.out_delvr_qty,
                i_work_mn,
                SYSDATE,
                i_work_trm,
                c1.waiting_exec_qty -- Huedt add CW
             );
   END LOOP;

   /* insert creadit qty */

   FOR c6
   IN (SELECT acnt_no acnt_no,
              sub_no sub_no,
              stk_cd stk_cd,
              SUM (GREATEST (NVL (mrtg_lnd_qty, 0) - NVL (mrtg_rpy_qty, 0), 0)
              )
                 cd_qty
         FROM vn.dlm01m00
        WHERE lnd_tp = '50' AND setl_dt <= vn.vwdate
              AND GREATEST (NVL (mrtg_lnd_qty, 0) - NVL (mrtg_rpy_qty, 0), 0) >
                    0
       GROUP BY acnt_no, sub_no, stk_cd)
   LOOP
      MERGE INTO vn.ssb01h00
USING DUAL
   ON (    acnt_no = c6.acnt_no
       AND sub_no = c6.sub_no
       AND stk_cd = c6.stk_cd
       AND rgt_std_dt = i_proc_dt)
      WHEN MATCHED
      THEN
         UPDATE SET cd_qty   = c6.cd_qty
      WHEN NOT MATCHED
      THEN
         INSERT (rgt_std_dt,
                 acnt_no,
                 sub_no,
                 stk_cd,
                 own_qty,
                 cd_qty,
                 work_mn,
                 work_dtm,
                 work_trm)
         VALUES (
                   i_proc_dt,
                   c6.acnt_no,
                   c6.sub_no,
                   c6.stk_cd,
                   0,
                   c6.cd_qty,
                   i_work_mn,
                   SYSDATE,
                   i_work_trm
                );
   END LOOP;

   /* ssi01h00 process  */

   DELETE FROM vn.ssi01h00
    WHERE dt = vn.fxc_nxt_vhdt (TO_DATE (i_proc_dt, 'yyyymmdd'), 1);

   FOR c2
   IN (SELECT b.stk_mkt_tp mkt_tp,
              a.stk_id stk_id,
              a.stk_cd stk_cd,
              a.max_pri max_pri,
              a.cls_pri cls_pri,
              a.dn_pri dn_pri,
              a.high_pri high_pri,
              a.low_pri low_pri,
              a.strt_pri strt_pri,
              a.fac_pri fac_pri,
              a.stk_tp stk_tp,
              b.list_stk_qty list_stk_qty,
              NVL (b.cd_yn, 'N') cd_yn,
              b.active_stat active_stat, /*Huedt add ti le ro uy ban*/
              b.cd_bp_rate cd_bp_rate,
              b.cd_bp_rate_af cd_bp_rate_af,
              b.cd_rate cd_rate,
              b.cd_rate_af cd_rate_af,
              b.delay_bp_rate delay_bp_rate,
              b.delay_bp_rate_af delay_bp_rate_af,
              b.delay_rate delay_rate,
              b.delay_rate_af delay_rate_af,
              b.rgt_bp_rate rgt_bp_rate,
              b.rgt_bp_rate_af rgt_bp_rate_af,
              b.rgt_rate rgt_rate,
              b.rgt_rate_af rgt_rate_af,
              b.cdr_bp cdr_bp,
              b.cdr_bp_af cdr_bp_af,
              b.cdr cdr,
              b.cdr_af cdr_af,
              b.lnd_limit_qty lnd_limit_qty,
              b.lnd_limit_qty_af lnd_limit_qty_af,
              b.lnd_limit_amt lnd_limit_amt,
              b.lnd_limit_amt_af lnd_limit_amt_af,
              b.lnd_lmt_pri lnd_lmt_pri,
              b.lnd_lmt_pri_af lnd_lmt_pri_af,
              b.create_mn,
              b.create_trm,
              b.create_dtm,
              b.active_mn,
              b.active_trm,
              b.active_dtm,/*Het Huedt add ti le ro uy ban*/
              b.cd_work_mn cd_work_mn,
              b.cd_work_dtm cd_work_dtm,
              /*CW Start*/
              b.cw_tp,
              b.cw_und_tp,
              b.cw_und_symb,
              b.cw_exec_tp,
              b.cw_last_trd_dt,
              b.cw_exer_rate,
              b.cw_exer_price,
              b.cw_multi,
              b.cw_matur_dt,
              b.cw_settl_price,
              b.cw_settl_meth,
              b.cw_issuer_nm
               /*CW end*/
         FROM vn.ssi02m00 a, vn.ssi01m00 b
        WHERE a.stk_cd = b.stk_cd AND b.stk_mkt_tp = '1')
   LOOP
      INSERT INTO vn.ssi01h00
            (
                dt,
                stk_mkt_tp,
                stk_cd,
                id_cd,
                cls_pri,
                max_pri,
                dn_pri,
                list_stk_qty,
                high_pri,
                low_pri,
                stk_tp,
                strt_pri,
                cd_yn,
                cd_work_mn,
                cd_work_dtm,
                active_stat, /*Huedt add ti le ro uy ban*/
                cd_bp_rate,
                cd_bp_rate_af,
                cd_rate,
                cd_rate_af,
                delay_bp_rate,
                delay_bp_rate_af,
                delay_rate,
                delay_rate_af,
                rgt_bp_rate,
                rgt_bp_rate_af,
                rgt_rate,
                rgt_rate_af,
                cdr_bp,
                cdr_bp_af,
                cdr,
                cdr_af,
                lnd_limit_qty,
                lnd_limit_qty_af,
                lnd_limit_amt,
                lnd_limit_amt_af,
                lnd_lmt_pri,
                lnd_lmt_pri_af,
                create_mn,
                create_trm,
                create_dtm,
                active_mn,
                active_trm,
                active_dtm,/*Het Huedt add ti le ro uy ban*/
                work_mn,
                work_dtm,
                work_trm,
                /*CW Start*/
                cw_tp,
                cw_und_tp,
                cw_und_symb,
                cw_exec_tp,
                cw_last_trd_dt,
                cw_exer_rate,
                cw_exer_price,
                cw_multi,
                cw_matur_dt,
                cw_settl_price,
                cw_settl_meth ,
                cw_issuer_nm /*cw end*/
            )
      VALUES (
                i_proc_dt,
                c2.mkt_tp,
                c2.stk_cd,
                c2.stk_id,
                c2.cls_pri,
                c2.max_pri,
                c2.dn_pri,
                c2.list_stk_qty,
                c2.high_pri,
                c2.low_pri,
                c2.stk_tp,
                c2.strt_pri,
                c2.cd_yn,
                c2.cd_work_mn,
                c2.cd_work_dtm,
                c2.active_stat, /*Huedt add ti le ro uy ban*/
                c2.cd_bp_rate,
                c2.cd_bp_rate_af,
                c2.cd_rate,
                c2.cd_rate_af,
                c2.delay_bp_rate,
                c2.delay_bp_rate_af,
                c2.delay_rate,
                c2.delay_rate_af,
                c2.rgt_bp_rate,
                c2.rgt_bp_rate_af,
                c2.rgt_rate,
                c2.rgt_rate_af,
                c2.cdr_bp,
                c2.cdr_bp_af,
                c2.cdr,
                c2.cdr_af,
                c2.lnd_limit_qty,
                c2.lnd_limit_qty_af,
                c2.lnd_limit_amt,
                c2.lnd_limit_amt_af,
                c2.lnd_lmt_pri,
                c2.lnd_lmt_pri_af,
                c2.create_mn,
                c2.create_trm,
                c2.create_dtm,
                c2.active_mn,
                c2.active_trm,
                c2.active_dtm,/*Het Huedt add ti le ro uy ban*/
                'BATCH',
                SYSDATE,
                'BATCH',
                /*CW START*/
                c2.cw_tp,
                c2.cw_und_tp,
                c2.cw_und_symb,
                c2.cw_exec_tp,
                c2.cw_last_trd_dt,
                c2.cw_exer_rate,
                c2.cw_exer_price,
                c2.cw_multi,
                c2.cw_matur_dt,
                c2.cw_settl_price,
                c2.cw_settl_meth,
                c2.cw_issuer_nm  /*CW end*/
             );


      /*    update  vn.ssi02m00
        set     pd_cls_pri = cls_pri
        where   stk_cd     = c2.stk_cd;*/
      -- Hoai che: 20161228

      -- NHSV-1622
      t_last_cls_pri := 0;
      IF c2.cls_pri <= 0 THEN
         begin
            select nvl(cls_pri, 0) into t_last_cls_pri
            from ssi01h00
            where dt = t_prev_dt
            and stk_cd = c2.stk_cd;
         exception
            when no_data_found then
               t_last_cls_pri := 0;
         end;

         t_pd_cls_pri := t_last_cls_pri;
      ELSE
         t_pd_cls_pri   := c2.cls_pri;
      END IF;

      if t_pd_cls_pri <> c2.cls_pri then
         update ssi01h00
            set cls_pri = t_pd_cls_pri
          where dt = i_proc_dt
            and stk_cd = c2.stk_cd;
      end if;
      --

      t_pd_cls_pri_bk   := t_pd_cls_pri;

      --VCSC-1962: Lam tron hang tram xuong hang don vi
      SELECT GREATEST ( vn.fss_REFPRI_pd_cls_pri_non_lmt (i_proc_dt,
                                                                c2.stk_cd,
                                                                t_pd_cls_pri_bk
                              ),0
                       )
        INTO t_pd_cls_pri_bk
        FROM DUAL;

      /*SELECT GREATEST (ROUND (vn.fss_REFPRI_pd_cls_pri (i_proc_dt,
                                                        c2.stk_cd,
                                                        t_pd_cls_pri
                              ),
                              0
                       ),
                       0
             )
        INTO t_pd_cls_pri
        FROM DUAL;  Huonglt comment do thay khong dung lam gi */                                              --VCSC-1823

      UPDATE vn.ssi02m00
         SET pd_cls_pri    = t_pd_cls_pri_bk,
             cls_pri       = t_pd_cls_pri_bk
       WHERE stk_cd = c2.stk_cd;

      INSERT INTO vn.ssi01h00_pd
            (
                stk_cd,
                cls_pri,
                work_mn,
                work_dtm,
                work_trm,
                cls_pri_bk
            )
      VALUES (
                c2.stk_cd,
                t_pd_cls_pri_bk,
                'BATCH',
                SYSDATE,
                'BATCH',
                t_pd_cls_pri_bk
             );
   END LOOP;


   FOR c3
   IN (SELECT b.stk_mkt_tp mkt_tp,
              a.stk_cd stk_cd,
              a.stk_id stk_id,
              a.max_pri max_pri,
              a.dn_pri dn_pri,
              a.list_stk_qty list_stk_qty,
              a.high_pri high_pri,
              a.low_pri low_pri,
              a.strt_pri strt_pri,
              a.cls_pri cls_pri,
              a.stk_tp stk_tp,
              a.avg_pri avg_pri,
              a.fac_pri fac_pri,
              NVL (b.cd_yn, 'N') cd_yn,
              b.cd_work_mn cd_work_mn,
              b.cd_work_dtm cd_work_dtm,
              b.active_stat  active_stat, /*Huedt add ti le ro uy ban*/
              b.cd_bp_rate  cd_bp_rate,
              b.cd_bp_rate_af  cd_bp_rate_af,
              b.cd_rate  cd_rate,
              b.cd_rate_af  cd_rate_af,
              b.delay_bp_rate  delay_bp_rate,
              b.delay_bp_rate_af  delay_bp_rate_af,
              b.delay_rate  delay_rate,
              b.delay_rate_af  delay_rate_af,
              b.rgt_bp_rate  rgt_bp_rate,
              b.rgt_bp_rate_af  rgt_bp_rate_af,
              b.rgt_rate  rgt_rate,
              b.rgt_rate_af  rgt_rate_af,
              b.cdr_bp  cdr_bp,
              b.cdr_bp_af  cdr_bp_af,
              b.cdr  cdr,
              b.cdr_af  cdr_af,
              b.lnd_limit_qty lnd_limit_qty,
              b.lnd_limit_qty_af  lnd_limit_qty_af,
              b.lnd_limit_amt  lnd_limit_amt,
              b.lnd_limit_amt_af  lnd_limit_amt_af,
              b.lnd_lmt_pri  lnd_lmt_pri,
              b.lnd_lmt_pri_af  lnd_lmt_pri_af,
              b.create_mn,
              b.create_trm,
              b.create_dtm,
              b.active_mn,
              b.active_trm,
              b.active_dtm/*Het Huedt add ti le ro uy ban*/
         FROM vn.ssi03m00 a, vn.ssi01m00 b
        WHERE a.stk_cd = b.stk_cd AND b.stk_mkt_tp = '2')
   LOOP
      INSERT INTO vn.ssi01h00
            (
                dt,
                stk_mkt_tp,
                stk_cd,
                id_cd,
                cls_pri,
                max_pri,
                dn_pri,
                list_stk_qty,
                high_pri,
                low_pri,
                stk_tp,
                strt_pri,
                cd_yn,
                cd_work_mn,
                cd_work_dtm,
                active_stat, /*Huedt add ti le ro uy ban*/
                cd_bp_rate,
                cd_bp_rate_af,
                cd_rate,
                cd_rate_af,
                delay_bp_rate,
                delay_bp_rate_af,
                delay_rate,
                delay_rate_af,
                rgt_bp_rate,
                rgt_bp_rate_af,
                rgt_rate,
                rgt_rate_af,
                cdr_bp,
                cdr_bp_af,
                cdr,
                cdr_af,
                lnd_limit_qty,
                lnd_limit_qty_af,
                lnd_limit_amt,
                lnd_limit_amt_af,
                lnd_lmt_pri,
                lnd_lmt_pri_af,
                create_mn,
                create_trm,
                create_dtm,
                active_mn,
                active_trm,
                active_dtm,/*Het Huedt add ti le ro uy ban*/
                work_mn,
                work_dtm,
                work_trm,
                avg_pri
            )
      VALUES (
                i_proc_dt,
                c3.mkt_tp,
                c3.stk_cd,
                c3.stk_id,
                c3.cls_pri,
                c3.max_pri,
                c3.dn_pri,
                c3.list_stk_qty,
                c3.high_pri,
                c3.low_pri,
                c3.stk_tp,
                c3.strt_pri,
                c3.cd_yn,
                c3.cd_work_mn,
                c3.cd_work_dtm,
                c3.active_stat, /*Huedt add ti le ro uy ban*/
                c3.cd_bp_rate,
                c3.cd_bp_rate_af,
                c3.cd_rate,
                c3.cd_rate_af,
                c3.delay_bp_rate,
                c3.delay_bp_rate_af,
                c3.delay_rate,
                c3.delay_rate_af,
                c3.rgt_bp_rate,
                c3.rgt_bp_rate_af,
                c3.rgt_rate,
                c3.rgt_rate_af,
                c3.cdr_bp,
                c3.cdr_bp_af,
                c3.cdr,
                c3.cdr_af,
                c3.lnd_limit_qty,
                c3.lnd_limit_qty_af,
                c3.lnd_limit_amt,
                c3.lnd_limit_amt_af,
                c3.lnd_lmt_pri,
                c3.lnd_lmt_pri_af,
                c3.create_mn,
                c3.create_trm,
                c3.create_dtm,
                c3.active_mn,
                c3.active_trm,
                c3.active_dtm,/*Het Huedt add ti le ro uy ban*/
                'BATCH',
                SYSDATE,
                'BATCH',
                c3.avg_pri
             );
      /* if c3.avg_pri <= 0 then
       t_pd_cls_pri := c3.fac_pri;
      else
         t_pd_cls_pri := c3.avg_pri;
      end if; */

      -- NHSV-1622
      t_last_cls_pri := 0;
      IF c3.cls_pri <= 0 THEN
         begin
            select nvl(cls_pri, 0) into t_last_cls_pri
            from ssi01h00
            where dt = t_prev_dt
            and stk_cd = c3.stk_cd;
         exception
            when no_data_found then
               t_last_cls_pri := 0;
         end;

         t_pd_cls_pri := t_last_cls_pri;
      ELSE
         t_pd_cls_pri   := c3.cls_pri;
      END IF;

      if t_pd_cls_pri <> c3.cls_pri then
         update ssi01h00
            set cls_pri = t_pd_cls_pri
          where dt = i_proc_dt
            and stk_cd = c3.stk_cd;
      end if;
      --

      t_pd_cls_pri_bk   := t_pd_cls_pri;

      --VCSC-1962: Lam tron hang tram xuong hang don vi
      SELECT GREATEST  (vn.fss_REFPRI_pd_cls_pri_non_lmt (i_proc_dt,
                                                                c3.stk_cd,
                                                                t_pd_cls_pri_bk
                              ),
                              0
                       )
        INTO t_pd_cls_pri_bk
        FROM DUAL;

      /*SELECT GREATEST (ROUND (vn.fss_REFPRI_pd_cls_pri (i_proc_dt,
                                                        c3.stk_cd,
                                                        t_pd_cls_pri
                              ),
                              0
                       ),
                       0
             )
        INTO t_pd_cls_pri
        FROM DUAL; Huonglt comment do thay khong dung lam gi*/                                                --VCSC-1823

      UPDATE vn.ssi03m00
         SET pd_cls_pri    = t_pd_cls_pri_bk,
             mth_pri       = t_pd_cls_pri_bk
       WHERE stk_cd = c3.stk_cd;

      INSERT INTO vn.ssi01h00_pd
            (
                stk_cd,
                cls_pri,
                work_mn,
                work_dtm,
                work_trm,
                cls_pri_bk
            )
      VALUES (
                c3.stk_cd,
                t_pd_cls_pri_bk,
                'BATCH',
                SYSDATE,
                'BATCH',
                t_pd_cls_pri_bk
             );
   END LOOP;

   /*  update cancel list by jung */

   UPDATE vn.ssi03m00
      SET STK_TRD_STAT    = '4'
    WHERE LIST_DETL_TP = '2' AND STK_TRD_STAT <> '4';

    FOR c4
   IN (SELECT b.stk_mkt_tp mkt_tp,
              a.stk_cd stk_cd,
              a.stk_id stk_id,
              0 max_pri,
              0 dn_pri,
              a.list_stk_qty list_stk_qty,
              a.high_pri high_pri,
              a.low_pri low_pri,
              a.strt_pri strt_pri,
              a.cls_pri cls_pri,
              a.fac_pri fac_pri,
              a.stk_tp stk_tp,
              NVL (b.cd_yn, 'N') cd_yn,
              b.cd_work_mn cd_work_mn,
              b.cd_work_dtm cd_work_dtm,
              b.active_stat active_stat, /*Huedt add ti le ro uy ban*/
              b.cd_bp_rate cd_bp_rate,
              b.cd_bp_rate_af cd_bp_rate_af,
              b.cd_rate cd_rate,
              b.cd_rate_af cd_rate_af,
              b.delay_bp_rate delay_bp_rate,
              b.delay_bp_rate_af delay_bp_rate_af,
              b.delay_rate delay_rate,
              b.delay_rate_af delay_rate_af,
              b.rgt_bp_rate rgt_bp_rate,
              b.rgt_bp_rate_af rgt_bp_rate_af,
              b.rgt_rate rgt_rate,
              b.rgt_rate_af rgt_rate_af,
              b.cdr_bp cdr_bp,
              b.cdr_bp_af cdr_bp_af,
              b.cdr cdr,
              b.cdr_af cdr_af,
              b.lnd_limit_qty lnd_limit_qty,
              b.lnd_limit_qty_af lnd_limit_qty_af,
              b.lnd_limit_amt lnd_limit_amt,
              b.lnd_limit_amt_af lnd_limit_amt_af,
              b.lnd_lmt_pri lnd_lmt_pri,
              b.lnd_lmt_pri_af lnd_lmt_pri_af,
              b.create_mn,
              b.create_trm,
              b.create_dtm,
              b.active_mn,
              b.active_trm,
              b.active_dtm/*Het Huedt add ti le ro uy ban*/
         FROM vn.ssi04m00 a, vn.ssi01m00 b
        WHERE a.stk_cd = b.stk_cd AND b.stk_mkt_tp = '3')
   LOOP
      INSERT INTO vn.ssi01h00
            (
                dt,
                stk_mkt_tp,
                stk_cd,
                id_cd,
                cls_pri,
                max_pri,
                dn_pri,
                list_stk_qty,
                high_pri,
                low_pri,
                stk_tp,
                strt_pri,
                cd_yn,
                cd_work_mn,
                cd_work_dtm,
                active_stat, /*Huedt add ti le ro uy ban*/
                cd_bp_rate,
                cd_bp_rate_af,
                cd_rate,
                cd_rate_af,
                delay_bp_rate,
                delay_bp_rate_af,
                delay_rate,
                delay_rate_af,
                rgt_bp_rate,
                rgt_bp_rate_af,
                rgt_rate,
                rgt_rate_af,
                cdr_bp,
                cdr_bp_af,
                cdr,
                cdr_af,
                lnd_limit_qty,
                lnd_limit_qty_af,
                lnd_limit_amt,
                lnd_limit_amt_af,
                lnd_lmt_pri,
                lnd_lmt_pri_af,
                create_mn,
                create_trm,
                create_dtm,
                active_mn,
                active_trm,
                active_dtm,/*Het Huedt add ti le ro uy ban*/
                work_mn,
                work_dtm,
                work_trm
            )
      VALUES (
                i_proc_dt,
                c4.mkt_tp,
                c4.stk_cd,
                c4.stk_id,
                c4.cls_pri,
                c4.max_pri,
                c4.dn_pri,
                c4.list_stk_qty,
                c4.high_pri,
                c4.low_pri,
                c4.stk_tp,
                c4.strt_pri,
                c4.cd_yn,
                c4.cd_work_mn,
                c4.cd_work_dtm,
                c4.active_stat, /*Huedt add ti le ro uy ban*/
                c4.cd_bp_rate,
                c4.cd_bp_rate_af,
                c4.cd_rate,
                c4.cd_rate_af,
                c4.delay_bp_rate,
                c4.delay_bp_rate_af,
                c4.delay_rate,
                c4.delay_rate_af,
                c4.rgt_bp_rate,
                c4.rgt_bp_rate_af,
                c4.rgt_rate,
                c4.rgt_rate_af,
                c4.cdr_bp,
                c4.cdr_bp_af,
                c4.cdr,
                c4.cdr_af,
                c4.lnd_limit_qty,
                c4.lnd_limit_qty_af,
                c4.lnd_limit_amt,
                c4.lnd_limit_amt_af,
                c4.lnd_lmt_pri,
                c4.lnd_lmt_pri_af,
                c4.create_mn,
                c4.create_trm,
                c4.create_dtm,
                c4.active_mn,
                c4.active_trm,
                c4.active_dtm,/*Het Huedt add ti le ro uy ban*/
                'BATCH',
                SYSDATE,
                'BATCH'
             );

      -- NHSV-1622
      t_last_cls_pri := 0;
      IF c4.cls_pri <= 0 THEN
         begin
            select nvl(cls_pri, 0) into t_last_cls_pri
            from ssi01h00
            where dt = t_prev_dt
            and stk_cd = c4.stk_cd;
         exception
            when no_data_found then
               t_last_cls_pri := 0;
         end;

         t_pd_cls_pri := t_last_cls_pri;
      ELSE
         t_pd_cls_pri   := c4.cls_pri;
      END IF;

      if t_pd_cls_pri <> c4.cls_pri then
         update ssi01h00
            set cls_pri = t_pd_cls_pri
          where dt = i_proc_dt
            and stk_cd = c4.stk_cd;
      end if;
      --

      t_pd_cls_pri_bk   := t_pd_cls_pri;

      --VCSC-1962: Lam tron hang tram xuong hang don vi
      SELECT GREATEST (vn.fss_REFPRI_pd_cls_pri_non_lmt (i_proc_dt,
                                                                c4.stk_cd,
                                                                t_pd_cls_pri_bk
                              ),
                              0
                       )
        INTO t_pd_cls_pri_bk
        FROM DUAL;

     /*SELECT GREATEST (ROUND (vn.fss_REFPRI_pd_cls_pri (i_proc_dt,
                                                        c4.stk_cd,
                                                        t_pd_cls_pri
                              ),
                              0
                       ),
                       0
             )
        INTO t_pd_cls_pri
        FROM DUAL; Huonglt comment do thay khong dung lam gi*/                                                --VCSC-1823

      INSERT INTO vn.ssi01h00_pd
            (
                stk_cd,
                cls_pri,
                work_mn,
                work_dtm,
                work_trm,
                cls_pri_bk
            )
      VALUES (
                c4.stk_cd,
                t_pd_cls_pri_bk,
                'BATCH',
                SYSDATE,
                'BATCH',
                t_pd_cls_pri_bk
             );
   END LOOP;

    FOR c5
   IN (SELECT b.stk_mkt_tp mkt_tp,
              a.stk_cd stk_cd,
              a.stk_id stk_id,
              a.max_pri max_pri,
              a.dn_pri dn_pri,
              a.list_stk_qty list_stk_qty,
              a.high_pri high_pri,
              a.low_pri low_pri,
              a.strt_pri strt_pri,
              a.cls_pri cls_pri,
              a.fac_pri fac_pri,
              a.stk_tp stk_tp,
              a.avg_pri avg_pri,
              NVL (b.cd_yn, 'N') cd_yn,
              b.cd_work_mn cd_work_mn,
              b.cd_work_dtm cd_work_dtm,
              b.active_stat active_stat, /*Huedt add ti le ro uy ban*/
              b.cd_bp_rate cd_bp_rate,
              b.cd_bp_rate_af cd_bp_rate_af,
              b.cd_rate cd_rate,
              b.cd_rate_af cd_rate_af,
              b.delay_bp_rate delay_bp_rate,
              b.delay_bp_rate_af delay_bp_rate_af,
              b.delay_rate delay_rate,
              b.delay_rate_af delay_rate_af,
              b.rgt_bp_rate rgt_bp_rate,
              b.rgt_bp_rate_af rgt_bp_rate_af,
              b.rgt_rate rgt_rate,
              b.rgt_rate_af rgt_rate_af,
              b.cdr_bp cdr_bp,
              b.cdr_bp_af cdr_bp_af,
              b.cdr cdr,
              b.cdr_af cdr_af,
              b.lnd_limit_qty lnd_limit_qty,
              b.lnd_limit_qty_af lnd_limit_qty_af,
              b.lnd_limit_amt lnd_limit_amt,
              b.lnd_limit_amt_af lnd_limit_amt_af,
              b.lnd_lmt_pri lnd_lmt_pri,
              b.lnd_lmt_pri_af lnd_lmt_pri_af,
              b.create_mn,
              b.create_trm,
              b.create_dtm,
              b.active_mn,
              b.active_trm,
              b.active_dtm/*Het Huedt add ti le ro uy ban*/
         FROM vn.ssi03m10 a, vn.ssi01m00 b
        WHERE a.stk_cd = b.stk_cd AND b.stk_mkt_tp = '4')
   LOOP
      INSERT INTO vn.ssi01h00
            (
                dt,
                stk_mkt_tp,
                stk_cd,
                id_cd,
                cls_pri,
                max_pri,
                dn_pri,
                list_stk_qty,
                high_pri,
                low_pri,
                stk_tp,
                strt_pri,
                cd_yn,
                cd_work_mn,
                cd_work_dtm,
                active_stat, /*Huedt add ti le ro uy ban*/
                cd_bp_rate,
                cd_bp_rate_af,
                cd_rate,
                cd_rate_af,
                delay_bp_rate,
                delay_bp_rate_af,
                delay_rate,
                delay_rate_af,
                rgt_bp_rate,
                rgt_bp_rate_af,
                rgt_rate,
                rgt_rate_af,
                cdr_bp,
                cdr_bp_af,
                cdr,
                cdr_af,
                lnd_limit_qty,
                lnd_limit_qty_af,
                lnd_limit_amt,
                lnd_limit_amt_af,
                lnd_lmt_pri,
                lnd_lmt_pri_af,
                create_mn,
                create_trm,
                create_dtm,
                active_mn,
                active_trm,
                active_dtm,/*Het Huedt add ti le ro uy ban*/
                work_mn,
                work_dtm,
                work_trm,
                avg_pri
            )
      VALUES (
                i_proc_dt,
                c5.mkt_tp,
                c5.stk_cd,
                c5.stk_id,
                c5.cls_pri,
                c5.max_pri,
                c5.dn_pri,
                c5.list_stk_qty,
                c5.high_pri,
                c5.low_pri,
                c5.stk_tp,
                c5.strt_pri,
                c5.cd_yn,
                c5.cd_work_mn,
                c5.cd_work_dtm,
                c5.active_stat, /*Huedt add ti le ro uy ban*/
                c5.cd_bp_rate,
                c5.cd_bp_rate_af,
                c5.cd_rate,
                c5.cd_rate_af,
                c5.delay_bp_rate,
                c5.delay_bp_rate_af,
                c5.delay_rate,
                c5.delay_rate_af,
                c5.rgt_bp_rate,
                c5.rgt_bp_rate_af,
                c5.rgt_rate,
                c5.rgt_rate_af,
                c5.cdr_bp,
                c5.cdr_bp_af,
                c5.cdr,
                c5.cdr_af,
                c5.lnd_limit_qty,
                c5.lnd_limit_qty_af,
                c5.lnd_limit_amt,
                c5.lnd_limit_amt_af,
                c5.lnd_lmt_pri,
                c5.lnd_lmt_pri_af,
                c5.create_mn,
                c5.create_trm,
                c5.create_dtm,
                c5.active_mn,
                c5.active_trm,
                c5.active_dtm,/*Het Huedt add ti le ro uy ban*/
                'BATCH',
                SYSDATE,
                'BATCH',
                c5.avg_pri
             );

      -- NHSV-1622
      t_last_cls_pri := 0;
      IF c5.avg_pri <= 0 THEN
         begin
            select nvl(avg_pri, 0) into t_last_cls_pri
            from ssi01h00
            where dt = t_prev_dt
            and stk_cd = c5.stk_cd;
         exception
            when no_data_found then
               t_last_cls_pri := 0;
         end;

         t_pd_cls_pri := t_last_cls_pri;
      ELSE
         t_pd_cls_pri   := round(c5.avg_pri,-2);
      END IF;

      if t_pd_cls_pri <> round(c5.avg_pri,-2) then
         update ssi01h00
            set avg_pri = t_pd_cls_pri
          where dt = i_proc_dt
            and stk_cd = c5.stk_cd;
      end if;
      --

      t_pd_cls_pri_bk   := t_pd_cls_pri;

      --VCSC-1962: Lam tron hang tram xuong hang don vi
      SELECT GREATEST (vn.fss_REFPRI_pd_cls_pri_non_lmt (i_proc_dt,
                                                                c5.stk_cd,
                                                                t_pd_cls_pri_bk
                              ),
                              0
                       )
        INTO t_pd_cls_pri_bk
        FROM DUAL;

      /*SELECT GREATEST (ROUND (vn.fss_REFPRI_pd_cls_pri (i_proc_dt,
                                                        c5.stk_cd,
                                                        t_pd_cls_pri
                              ),
                              0
                       ),
                       0
             )
        INTO t_pd_cls_pri
        FROM DUAL;  Huonglt comment do thay khong dung lam gi*/                                               --VCSC-1823

      UPDATE vn.ssi03m10
         SET pd_cls_pri    = t_pd_cls_pri_bk,
             mth_pri       = t_pd_cls_pri_bk,
             avg_pri       = round(c5.avg_pri,-2)
       WHERE stk_cd = c5.stk_cd;

      INSERT INTO vn.ssi01h00_pd
            (
                stk_cd,
                cls_pri,
                work_mn,
                work_dtm,
                work_trm,
                cls_pri_bk
            )
      VALUES (
                c5.stk_cd,
                t_pd_cls_pri_bk,
                'BATCH',
                SYSDATE,
                'BATCH',
                t_pd_cls_pri_bk
             );
   END LOOP;



   /*HL - 20180623 HueDT add ti le ro cty*/
    FOR c7
   IN (SELECT basket_cd,
              stk_cd,
              active_stat, /*Huedt add ti le ro cong ty */
                cd_bp_rate,
                cd_bp_rate_af,
                cd_rate,
                cd_rate_af,
                delay_bp_rate,
                delay_bp_rate_af,
                delay_rate,
                delay_rate_af,
                rgt_bp_rate,
                rgt_bp_rate_af,
                rgt_rate,
                rgt_rate_af,
                cdr_bp,
                cdr_bp_af,
                cdr,
                cdr_af,
                lnd_limit_qty,
                lnd_limit_qty_af,
                lnd_limit_amt,
                lnd_limit_amt_af,
                lnd_lmt_pri,
                lnd_lmt_pri_af,
            create_mn,
          create_trm,
          create_dtm,
          active_mn,
          active_trm,
          active_dtm/*Het Huedt add ti le ro cong ty */,
          bk_active
         FROM vn.ssi08m00)
   LOOP
      INSERT INTO vn.ssi08h00
            (
                dt,
                basket_cd,
                stk_cd,
                active_stat, /*Huedt add ti le ro cong ty*/
                cd_bp_rate,
                cd_bp_rate_af,
                cd_rate,
                cd_rate_af,
                delay_bp_rate,
                delay_bp_rate_af,
                delay_rate,
                delay_rate_af,
                rgt_bp_rate,
                rgt_bp_rate_af,
                rgt_rate,
                rgt_rate_af,
                cdr_bp,
                cdr_bp_af,
                cdr,
                cdr_af,
                lnd_limit_qty,
                lnd_limit_qty_af,
                lnd_limit_amt,
                lnd_limit_amt_af,
                lnd_lmt_pri,
                lnd_lmt_pri_af,
                create_mn,
                create_trm,
                create_dtm,
                active_mn,
                active_trm,
                active_dtm,/*Het Huedt add ti le ro cong ty*/
                work_mn,
                work_dtm,
                work_trm,
                bk_active
            )
      VALUES (
                i_proc_dt,
                c7.basket_cd,
                c7.stk_cd,
                c7.active_stat, /*Huedt add ti le ro cong ty*/
                c7.cd_bp_rate,
                c7.cd_bp_rate_af,
                c7.cd_rate,
                c7.cd_rate_af,
                c7.delay_bp_rate,
                c7.delay_bp_rate_af,
                c7.delay_rate,
                c7.delay_rate_af,
                c7.rgt_bp_rate,
                c7.rgt_bp_rate_af,
                c7.rgt_rate,
                c7.rgt_rate_af,
                c7.cdr_bp,
                c7.cdr_bp_af,
                c7.cdr,
                c7.cdr_af,
                c7.lnd_limit_qty,
                c7.lnd_limit_qty_af,
                c7.lnd_limit_amt,
                c7.lnd_limit_amt_af,
                c7.lnd_lmt_pri,
                c7.lnd_lmt_pri_af,
                c7.create_mn,
                c7.create_trm,
                c7.create_dtm,
                c7.active_mn,
                c7.active_trm,
                c7.active_dtm,/*Het Huedt add ti le ro cong ty*/
                'BATCH',
                SYSDATE,
                'BATCH',
                c7.bk_active
             );
   END LOOP;
   /*  update cancel list by jung */

   UPDATE vn.ssi03m10
      SET STK_TRD_STAT    = '4'
    WHERE LIST_DETL_TP = '2' AND STK_TRD_STAT <> '4';

    UPDATE vn.ssi01m00
    SET cd_bp_rate      = DECODE (TRIM (cd_bp_rate_af), NULL, cd_bp_rate, cd_bp_rate_af),
        cd_bp_rate_af   = NULL,
        cd_rate         = DECODE (TRIM (cd_rate_af), NULL, cd_rate, cd_rate_af),
        cd_rate_af      = NULL,
        delay_bp_rate   = DECODE (TRIM (delay_bp_rate_af), NULL, delay_bp_rate, delay_bp_rate_af),
        delay_bp_rate_af= NULL,
        delay_rate      = DECODE (TRIM (delay_rate_af), NULL, delay_rate, delay_rate_af),
        delay_rate_af   = NULL,
        rgt_bp_rate     = DECODE (TRIM (rgt_bp_rate_af), NULL, rgt_bp_rate, rgt_bp_rate_af),
        rgt_bp_rate_af  = NULL,
        rgt_rate        = DECODE (TRIM (rgt_rate_af), NULL, rgt_rate, rgt_rate_af),
        rgt_rate_af     = NULL,
        cdr_bp          = DECODE (TRIM (cdr_bp_af), NULL, cdr_bp, cdr_bp_af),
        cdr_bp_af       = NULL,
        cdr             = DECODE (TRIM (cdr_af), NULL, cdr, cdr_af),
        cdr_af          = NULL,
        lnd_lmt_pri     = lnd_lmt_pri_af,
        lnd_lmt_pri_af  = NULL,
        create_mn       = DECODE (TRIM (cd_work_mn), NULL, create_mn, cd_work_mn),
        cd_work_mn      = NULL,
        create_dtm      = DECODE (TRIM (cd_work_dtm), NULL, create_dtm, cd_work_dtm),
        cd_work_dtm     = NULL,
        create_trm      = DECODE (TRIM (work_trm), NULL, create_trm, work_trm),
        work_trm      = NULL
    WHERE  active_stat = 'Y';

    UPDATE vn.ssi08m00
    SET active_stat='Y'  WHERE active_stat in ('A','I');

    UPDATE vn.ssi08m00
    SET cd_bp_rate      = DECODE (TRIM (cd_bp_rate_af), NULL, cd_bp_rate, cd_bp_rate_af),
        cd_bp_rate_af   = NULL,
        cd_rate         = DECODE (TRIM (cd_rate_af), NULL, cd_rate, cd_rate_af),
        cd_rate_af      = NULL,
        delay_bp_rate   = DECODE (TRIM (delay_bp_rate_af), NULL, delay_bp_rate, delay_bp_rate_af),
        delay_bp_rate_af= NULL,
        delay_rate      = DECODE (TRIM (delay_rate_af), NULL, delay_rate, delay_rate_af),
        delay_rate_af   = NULL,
        rgt_bp_rate     = DECODE (TRIM (rgt_bp_rate_af), NULL, rgt_bp_rate, rgt_bp_rate_af),
        rgt_bp_rate_af  = NULL,
        rgt_rate        = DECODE (TRIM (rgt_rate_af), NULL, rgt_rate, rgt_rate_af),
        rgt_rate_af     = NULL,
        cdr_bp          = DECODE (TRIM (cdr_bp_af), NULL, cdr_bp, cdr_bp_af),
        cdr_bp_af       = NULL,
        cdr             = DECODE (TRIM (cdr_af), NULL, cdr, cdr_af),
        cdr_af          = NULL,
        lnd_lmt_pri     = DECODE (TRIM (lnd_lmt_pri_af), '9999999999', NULL, NULL,lnd_lmt_pri, lnd_lmt_pri_af),
        lnd_lmt_pri_af  = NULL,
        create_mn       = DECODE (TRIM (work_mn), NULL, create_mn, work_mn),
        work_mn         = NULL,
        create_dtm      = DECODE (TRIM (work_dtm), NULL, create_dtm, work_dtm),
        work_dtm        = NULL,
        create_trm      = DECODE (TRIM (work_trm), NULL, create_trm, work_trm),
        work_trm        = NULL
    WHERE  active_stat = 'Y';


   DELETE FROM vn.ssi08m00
    WHERE active_stat = 'D';

   /*  update  vn.ssi03m00
     set    pd_cls_pri = cls_pri;

     update  vn.ssi03m10
     set    pd_cls_pri = avg_pri;*/
   -- Hoai che: 20161228
   BEGIN
      SELECT stk_idx
        INTO v_hnx_idx
        FROM vn.ssi05m20
       WHERE trd_dt = i_proc_dt AND idx_cd = 'HNXIndex';

      SELECT stk_idx
        INTO v_upc_idx
        FROM vn.ssi05m20
       WHERE trd_dt = i_proc_dt AND idx_cd = 'HNXUpcomIndex';

      SELECT NVL (SUM (tot_trd_qty), 0), NVL (SUM (tot_trd_amt), 0)
        INTO v_hnx_qty, v_hnx_amt
        FROM vn.ssi03m00;

      SELECT NVL (SUM (tot_trd_qty), 0), NVL (SUM (tot_trd_amt), 0)
        INTO v_upc_qty, v_upc_amt
        FROM vn.ssi03m10;

      INSERT INTO vn.ssi05m00
            (
                dt,
                stk_mkt_tp,
                stk_tp,
                stk_idx,
                tot_trd_qty,
                tot_trd_amt,
                work_mn,
                work_dtm,
                work_trm
            )
      VALUES (
                i_proc_dt,
                '2',
                '00',
                v_hnx_idx,
                v_hnx_qty,
                v_hnx_amt,
                'DAILY',
                SYSDATE,
                'SYSTEM'
             );

      INSERT INTO vn.ssi05m00
            (
                dt,
                stk_mkt_tp,
                stk_tp,
                stk_idx,
                tot_trd_qty,
                tot_trd_amt,
                work_mn,
                work_dtm,
                work_trm
            )
      VALUES (
                i_proc_dt,
                '4',
                '00',
                v_upc_idx,
                v_upc_qty,
                v_upc_amt,
                'DAILY',
                SYSDATE,
                'SYSTEM'
             );
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         NULL;
   END;

   /* Update  vn.ssi05m00
   Set    tot_trd_qty = (select sum(tot_trd_qty) from ssi03m00),
       tot_trd_amt = (select sum(tot_trd_amt) from ssi03m00)
   Where  dt       = i_proc_dt
     and  stk_mkt_tp  = '2';

   Update  vn.ssi05m00
   Set    tot_trd_qty = (select sum(tot_trd_qty) from ssi03m10),
       tot_trd_amt = (select sum(tot_trd_amt) from ssi03m10)
   Where  dt       = i_proc_dt
     and  stk_mkt_tp  = '4';   */

   /* ----- Batch so du dang giao dich phai sinh */
   pdr_stk_dt_remn_proc_p (i_proc_dt, i_work_mn, i_work_trm, o_proc_cnt);
/* ----- Batch dong bo gia tri CK ky quy phai sinh */
--Xem lai thu tu chay danh gia
--pdr_subst_amt_rcv_p(i_proc_dt, '%', '80',i_work_mn, i_work_trm, o_proc_cnt);

/*Huedt add batch thuc hien chung quyen khi toi ngay dao han*/
  /*vn.pss_cw_matu_dt(i_proc_dt,i_work_mn,i_work_trm,o_proc_cnt);*/


END pss_stk_dt_remn_proc_p;
/

