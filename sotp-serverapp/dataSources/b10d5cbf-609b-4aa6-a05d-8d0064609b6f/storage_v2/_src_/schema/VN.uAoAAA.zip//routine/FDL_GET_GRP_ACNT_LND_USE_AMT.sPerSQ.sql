create function    fdl_get_grp_acnt_lnd_use_amt
    (i_grp_acnt_no varchar2,
     i_day_tp varchar2) 
return number
as

  t_grp_acnt_lnd_amt number := 0;

-- Neu i_day_tp = '1'- Su dung trong ngay: Co cong them so luong du kien vay (extp) vao so da dung
-- Neu i_day_tp ='2' - Cuoi ngay: Khong cong them so luong du kien vay (extp) vao so da dung
begin
    /*
        Used(G): Tong gia tri han muc da dung cua nhom TK G
            = Sum(gia tri vay, gia tri du kien vay) theo san pham P tu bang dlm09m10    
    */

    begin
        select sum(nvl(lnd_use_amt,0)) + sum(decode(i_day_tp, '1', nvl(lnd_expt_amt,0), 0))
         into t_grp_acnt_lnd_amt
        from vn.dlm09m10
        where lnd_tp in ('70', '80')
        and grp_acnt_no =i_grp_acnt_no;
    exception
          when others then
              t_grp_acnt_lnd_amt := 0;
    end;

    return nvl(t_grp_acnt_lnd_amt, 0);

end fdl_get_grp_acnt_lnd_use_amt;
/

