create procedure pss_acnt_depo_fee_out_dt
( i_sec_cd     in   varchar2,
  i_acnt_no    in   varchar2,
  i_sub_no     in   varchar2,
  i_work_mn    in   varchar2,
  i_work_trm   in   varchar2
) is

 -- Variables
 t_err_txt           varchar2(200) := null ;
 t_err_msg           varchar2(200) := null ;

K_RMRK_CD                VARCHAR2(3) := '247';

t_avail_depo_fee         number :=0;

t_trd_dt                varchar2(20) := ' ';
--t_trd_seq_no            number := 0;
t_dpo_prerm             number := 0;
t_dpo_nowrm             number := 0;
t_acnt_place            varchar2(10) := ' ';
t_bnhof_tp              varchar2(10) := ' ';
t_proc_bnhof_tp         varchar2(10) := ' ';
t_mak_strt_dt           varchar2(10);
t_depo_cal_freq         varchar2(1);
t_depo_with_freq        varchar2(1);
vn_tot_out_blk_fee      number := 0;
o_dpo                   number := 0;
vn_cnte                 varchar2(200);

O_TRD_SEQ_NO    NUMBER;
O1_RTN_TBL      VARCHAR2(100) ;              -- Return Table
O1_RTN_ERR      VARCHAR2(100) ;              -- Return Error Code
O1_RTN_MSG      VARCHAR2(254) ;              -- Return Message
vn_limit_fee      VARCHAR2(254) ;
vn_commit               number := 0;
begin

/* Get cal frequence and withdraw frequence */
select col_cd_tp into t_depo_cal_freq
  from vn.xcc01c02
 where col_cd = 'depo_cal_freq';

select col_cd_tp into t_depo_with_freq
  from vn.xcc01c02
 where col_cd = 'depo_with_freq';

t_mak_strt_dt := case when i_work_mn in ('DAILY', 'SYSTEM') and t_depo_cal_freq = 'D' and t_depo_with_freq = 'M'
                        then substr(vwdate,1,6)
                      else '!'
                 end;

vn.pxc_log_write('pss_acnt_depo_fee_out_dt','t_mak_strt_dt: ' || t_mak_strt_dt );

 for c1 in (
  select acnt_no
      ,sub_no
      ,dpo
      ,dpo_fee_bk
      ,vn.faa_acnt_bank_cd_g(acnt_no, sub_no) as bank_cd
    from vn.cwd01m00 t
    where acnt_no like i_acnt_no
    and sub_no like i_sub_no
    and dpo_fee_bk > 0
    and vn.faa_acnt_bank_cd_g(acnt_no, sub_no) = '!'
    order by acnt_no||sub_no
  ) loop

  begin

  vn.pxc_log_write('pss_acnt_depo_fee_out_dt', '['||sysdate||'-'||i_acnt_no||'-'||i_sub_no||']');
  if (vn.fxb_daily_stat_chk ('B','0','2200','2200','*') <> 'Y' or
     vn.fxb_daily_stat_chk ('B','0','2300','2300','*') <> 'Y' or
     vn.fxb_daily_stat_chk ('B','0','2400','2400','*') <> 'Y' or
     vn.fxb_daily_stat_chk ('B','0','2410','2410','*') <> 'Y' or
     vn.fxb_daily_stat_chk ('B','0','2450','2450','*') <> 'Y')
  then
   vn.pxc_log_write('pss_acnt_depo_fee_out_dt', 'Not finished Previous BATCH');
     return;
  end if;

  for c2 in (
      select acnt_no
         ,sub_no
         ,usefee
         ,usefee_pay_dt
         ,seq_no
         ,mak_strt_dt
         ,mak_end_dt
      from vn.ssb07m00
      where acnt_no = c1.acnt_no
      and sub_no like trim(c1.sub_no)
      and rcpt_trd_no = 0
      and cncl_yn = 'N'
      --and substr(mak_strt_dt,1,6) <> t_mak_strt_dt -- tam thoi remove de test thu PLK cho thang 9/2020
      order by acnt_no||mak_strt_dt||sub_no
    ) loop

  begin
  /* Get note exactly */
  if c2.mak_strt_dt = c2.mak_end_dt then
    vn_cnte := to_char(to_date(c2.mak_strt_dt,'YYYYMMDD'),'DD/MM/YYYY');
  elsif c2.mak_strt_dt = to_char(trunc(to_date(c2.mak_strt_dt,'YYYYMMDD'),'MM'),'YYYYMMDD')
      and c2.mak_end_dt = to_char(last_day(to_date(c2.mak_end_dt,'YYYYMMDD')),'YYYYMMDD') then
    vn_cnte := to_char(to_date(c2.mak_strt_dt,'YYYYMMDD'),'MM/YYYY');
  else
    vn_cnte := to_char(to_date(c2.mak_strt_dt,'YYYYMMDD'),'DD/MM/YYYY')
              || ' - ' || to_char(to_date(c2.mak_end_dt,'YYYYMMDD'),'DD/MM/YYYY');
  end if;

    VN.PSS_CASH_OUTAMT_P(
                    VN.VWDATE,
                    c2.ACNT_NO,
                    c2.SUB_NO,
                    K_RMRK_CD,
                    c2.usefee,
                    '00',
                    ' ',
                    --K_CNFM_YN,
                    vn_cnte, --'thang ' ||substr(c2.mak_strt_dt,5,2) || '/' || substr(c2.mak_strt_dt,1,4),
                    ' ',
                    I_WORK_MN,
                    I_WORK_TRM,
                    O_TRD_SEQ_NO,
                    O1_RTN_TBL,
                    O1_RTN_ERR,
                    O1_RTN_MSG);

    IF  TO_NUMBER(O1_RTN_ERR)  <>  0  THEN /* 3. ERROR */
      vn.pxc_log_write('pss_acnt_depo_fee_out_dt', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG|| ']') ;
      --raise_application_error(-20100,'PSS_CASH_OUTAMT_P '||sqlerrm);
    end if;

        /* Update ssb07m00 */
        if (O_TRD_SEQ_NO > 0) then

            update  vn.ssb07m00
            set    rcpt_trd_no  = O_TRD_SEQ_NO
                  ,work_mn = i_work_mn
                  ,work_trm = i_work_trm
                  ,work_dtm = sysdate
            where   usefee_pay_dt  = c2.usefee_pay_dt
            and    mak_strt_dt     = c2.mak_strt_dt
            and     acnt_no        = c2.acnt_no
            and     sub_no         = c2.sub_no
            and     seq_no         = c2.seq_no;

        /* Unblock depo fee*/
        begin
                 vn.pcw_waitting_bk_ubk_p
                           ('04'
                           ,vn.vwdate
                           ,c2.acnt_no
                           ,c2.sub_no
                           ,c2.usefee
                           ,'00'
                           ,i_work_mn
                           ,i_work_trm
                           ,vn_tot_out_blk_fee
                           );
          exception
                 when others then
                 vn.pxc_log_write('pcw_waitting_bk_ubk_p 03', '['||sqlcode||']');
         end;
         end if;

        vn_commit := vn_commit + 1;
        vn.pxc_log_write('pss_acnt_depo_fee_out_dt','vn_commit'||to_char(vn_commit) );
        if vn_commit >= 500 then
            vn.pxc_log_write('pss_acnt_depo_fee_out_dt', 'I will commit now!');
            vn_commit := 0;
            commit;
        end if;

    end;
  end loop;

   end;
  end loop;
  commit;
  return;
end pss_acnt_depo_fee_out_dt;
/

