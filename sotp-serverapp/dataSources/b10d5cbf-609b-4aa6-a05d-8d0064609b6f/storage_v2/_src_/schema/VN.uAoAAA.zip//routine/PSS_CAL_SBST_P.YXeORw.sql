create PROCEDURE pss_cal_sbst_p(                                           i_proc_dt  IN VARCHAR2,
                                           i_acnt_no  IN VARCHAR2,
                                           i_sub_no   IN VARCHAR2,
                                           i_work_mn  IN VARCHAR2,
                                           o_proc_cnt OUT NUMBER) IS
  /***************************************************************************/
  /* calculate of reuse                                                      */
  /* 2010-02-22                                                              */
  /***************************************************************************/

  tn_tot_qty           NUMBER := 0; --so luong ck tu do chuyen nhuong kha dung
  tn_able_qty          NUMBER := 0;  --so luong chung khoan con co the phong toa
  tn_cd_unit           NUMBER := 0;  --gia ck so huu tdcn sau danh gia
  tn_tot_qty_delay     NUMBER := 0;  --so luong ck cho giao dich TDCN kha dung
  tn_able_qty_delay    NUMBER := 0;
  tn_cd_unit_delay     NUMBER := 0;  --gia ck TDCN cho giao dich sau danh gia
  tn_rate              number := 0;  --ti le dam bao ck giao dich tu do chuyen nhuong*/
  tn_rate_delay        number := 0;  --ti le dam bao ck cho giao dich tu do chuyen nhuong
  tn_cer               NUMBER := 0; --he so danh gia khach hang*/
  tn_pri               NUMBER := 0; --gia chung khoan lay min cua gia cho vay toi da va gia tham chieu
  tn_acnt_grp_no       VARCHAR2(5); --nhom tai khoan giao dich cua tai khoan
  tn_bef_acnt_no       VARCHAR2(10);
  tn_bef_sub_no        VARCHAR2(10);


    o_cd_bp_rate       NUMBER :=0 ;
    o_cd_rate          NUMBER :=0 ;
    o_delay_bp_rate    NUMBER :=0 ;
    o_delay_rate       NUMBER :=0 ;
    o_rgt_bp_rate      NUMBER :=0 ;
    o_rgt_rate         NUMBER :=0 ;
    o_cdr_bp           NUMBER :=0 ;
    o_cdr              NUMBER :=0 ;
    o_vd_rt            NUMBER :=0 ;
    o_lnd_lmt_pri      NUMBER :=0 ;
    o_lnd_limit_qty    NUMBER :=0 ;
    o_lnd_limit_amt    NUMBER :=0 ;

BEGIN

  vn.pxc_log_write('pss_cal_sbst_p', '------------------------');
  vn.pxc_log_write('pss_cal_sbst_p',
                   'start: ' || i_acnt_no || i_sub_no || ' i_work_mn:' ||
                   i_work_mn);

  o_proc_cnt := 0;

  UPDATE vn.cwd01m00
     SET sbst_dpo = 0, sbst_able_block = 0
   WHERE acnt_no LIKE TRIM(i_acnt_no)
     AND sub_no LIKE TRIM(i_sub_no);

  UPDATE vn.ssb01m00
     SET sbst_unit_amt = 0, sbst_dpo = 0, sbst_able_block = 0
   WHERE acnt_no LIKE TRIM(i_acnt_no)
     AND sub_no LIKE TRIM(i_sub_no);

  tn_bef_acnt_no := '!';
  tn_bef_sub_no  := '!';

  FOR c1 IN (SELECT acnt_no, sub_no, stk_cd
               FROM vn.ssb01m00
              WHERE acnt_no LIKE TRIM(i_acnt_no)
                AND sub_no LIKE TRIM(i_sub_no)
                AND own_qty > 0
              ORDER BY acnt_no) LOOP

    IF tn_bef_acnt_no <> c1.acnt_no OR tn_bef_sub_no <> c1.sub_no THEN

      tn_bef_acnt_no := c1.acnt_no;
      tn_bef_sub_no  := c1.sub_no;
      tn_acnt_grp_no := vn.faa_acnt_get_grp_no(tn_bef_acnt_no
                                              ,tn_bef_sub_no
                                              ,'2'
                                              ,vn.vwdate);

      tn_cer := VN.fdl_get_mrgn_grp_acnt_rt(
                                            tn_bef_acnt_no ,
                                            tn_bef_sub_no  ,
                                            tn_acnt_grp_no ,
                                            '02'           ,
                                            vn.vwdate       );


    END IF;

    vn.pxc_log_write('pss_cal_sbst_p',
                     'tn_bef_acnt_no: ' || tn_bef_acnt_no || ' tn_cer:' ||
                     tn_cer);

/* ================================================= */
    o_cd_bp_rate    :=0 ;
    o_cd_rate       :=0 ;
    o_delay_bp_rate :=0 ;
    o_delay_rate    :=0 ;
    o_rgt_bp_rate   :=0 ;
    o_rgt_rate      :=0 ;
    o_cdr_bp        :=0 ;
    o_cdr           :=0 ;
    o_vd_rt         :=0 ;
    o_lnd_lmt_pri   :=0 ;
    o_lnd_limit_qty :=0 ;
    o_lnd_limit_amt :=0 ;

    vn.pdl_get_mrgn_basket_rt(
        c1.acnt_no      ,
        c1.sub_no       ,
        NULL            ,
        NULL            ,
        c1.stk_cd       ,
        i_proc_dt       ,
        o_cd_bp_rate    ,
        tn_rate       ,
        o_delay_bp_rate ,
        tn_rate_delay    ,
        o_rgt_bp_rate   ,
        o_rgt_rate      ,
        o_cdr_bp        ,
        o_cdr           ,
        o_vd_rt         ,
        o_lnd_lmt_pri   ,
        o_lnd_limit_qty ,
        o_lnd_limit_amt 
    );
/* ================================================= */                     

    tn_pri := vn.fss_get_stk_pri(c1.stk_cd,c1.acnt_no,c1.sub_no,i_work_mn);

    tn_cd_unit        := tn_pri * tn_rate * tn_cer;

    tn_cd_unit_delay  := tn_pri  * tn_rate_delay * tn_cer;

    tn_tot_qty        := vn.fss_get_tot_cd_qty(c1.acnt_no,
                                               c1.sub_no,
                                               c1.stk_cd,
                                               '02');

    tn_tot_qty_delay  := vn.fss_get_tot_cd_qty(c1.acnt_no,
                                               c1.sub_no,
                                               c1.stk_cd,
                                               '01');

    tn_able_qty := vn.fss_get_cd_able_qty(c1.acnt_no, c1.sub_no, c1.stk_cd);
     vn.pxc_log_write('pss_cal_sbst_p',
                     'c1.acnt_no:' || c1.acnt_no || ' c1.stk_cd:' ||
                     c1.stk_cd || ' cd_pri:' || tn_pri);
    vn.pxc_log_write('pss_cal_sbst_p',
                     'c1.acnt_no:' || c1.acnt_no || ' c1.stk_cd:' ||
                     c1.stk_cd || ' cd_unit:' || tn_cd_unit);
    vn.pxc_log_write('pss_cal_sbst_p',
                     'c1.acnt_no:' || c1.acnt_no || ' c1.stk_cd:' ||
                     c1.stk_cd || ' tn_rate:' || tn_rate);
     vn.pxc_log_write('pss_cal_sbst_p',
                     'c1.acnt_no:' || c1.acnt_no || ' c1.stk_cd:' ||
                     c1.stk_cd || ' tn_rate_delay:' || tn_rate_delay);                 
    vn.pxc_log_write('pss_cal_sbst_p',
                     'c1.acnt_no:' || c1.acnt_no || ' c1.stk_cd:' ||
                     c1.stk_cd || ' tot_qty:' || tn_tot_qty);
    vn.pxc_log_write('pss_cal_sbst_p',
                     'tn_tot_qty:' || tn_tot_qty || ' tn_able_qty:' ||
                     tn_able_qty);

    BEGIN
      UPDATE vn.ssb01m00
         SET sbst_unit_amt   = tn_cd_unit,--gia ck giao dich TDCN sau danh gia
             sbst_dpo        = trunc((tn_tot_qty * (tn_cd_unit)+ tn_tot_qty_delay * tn_cd_unit_delay), 0),--gia tri dam bao CK SH
             sbst_able_block = trunc((tn_tot_qty * (tn_cd_unit)+ tn_tot_qty_delay * tn_cd_unit_delay), 0)--gia tri dam bao ck so huu con co the phong toa
       WHERE acnt_no = c1.acnt_no
         AND stk_cd = c1.stk_cd
         AND sub_no = c1.sub_no;
    EXCEPTION
      WHEN OTHERS THEN
        vn.pxc_log_write('pss_cal_sbst_p', 'sqlcode 1 : ' || SQLCODE);
        raise_application_error(-20100, 'SSB01M00 update error');
    END;

  END LOOP;

  vn.pxc_log_write('pss_cal_sbst_p', 'i_acnt_no:' || i_acnt_no || i_sub_no);

  BEGIN
    UPDATE vn.cwd01m00 a
       SET (a.sbst_dpo, a.sbst_able_block) =
           (SELECT nvl(SUM(b.sbst_dpo), 0), nvl(SUM(b.sbst_able_block), 0)
              FROM vn.ssb01m00 b
             WHERE b.acnt_no = a.acnt_no
               AND b.sub_no = a.sub_no
               AND a.acnt_no LIKE i_acnt_no
               AND a.sub_no LIKE i_sub_no)
     WHERE EXISTS (SELECT b.acnt_no, b.sub_no
              FROM vn.ssb01m00 b
             WHERE b.acnt_no = a.acnt_no
               AND b.sub_no = a.sub_no
               AND a.acnt_no LIKE i_acnt_no
               AND a.sub_no LIKE i_sub_no);

  EXCEPTION
    WHEN OTHERS THEN
      vn.pxc_log_write('pss_cal_sbst_p', 'sqlcode 2 : ' || SQLCODE);
      raise_application_error(-20100, 'cwd01m00 update error');
  END;

  o_proc_cnt := o_proc_cnt + SQL%ROWCOUNT;

  vn.pxc_log_write('pss_cal_sbst_p', 'step 2 : ' || to_char(o_proc_cnt));

END pss_cal_sbst_p;
/

