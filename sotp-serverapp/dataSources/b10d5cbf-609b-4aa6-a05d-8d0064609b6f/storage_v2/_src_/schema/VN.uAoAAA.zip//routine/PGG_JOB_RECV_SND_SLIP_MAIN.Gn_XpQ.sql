create PROCEDURE PGG_JOB_RECV_SND_SLIP_MAIN
  /********************
      CREATE RECEIVE VOUCHER (FOR SEND LIST) : 수신전표 생성(수기발신전표에 대한)
  ********************/
  (   I_WORK_TP                   IN  VARCHAR2        -- 'A' : Approval, 'C' : Approval Cancel, 'R' :Return, 'X' : DisUse
     ,I_SLIP_DT                   IN  VARCHAR2        --  VOUCHER DATE
     ,I_BRCH_CD                   IN  VARCHAR2        --  SENDER
     ,I_AGNC_BRCH                 IN  VARCHAR2        --  SENDER
     ,I_SLIP_NO                   IN  VARCHAR2        --  VOUCHER NO (SENDING VOUCHER NO)
  )
  IS
    T_RECURSIVE_PROC_CNT  NUMBER  := 0;
    T_PROC_CNT            NUMBER  ;

    T_GGA06M01_RECV_SND_NO         GGA06M01.RECV_SND_NO%TYPE;          --수신발신번호
    T_GGA06M01_SLIP_DT             GGA06M01.SLIP_DT%TYPE;              --전표일자
    T_GGA06M01_BRCH_CD             GGA06M01.BRCH_CD%TYPE;              --지점코드
    T_GGA06M01_AGNC_BRCH           GGA06M01.AGNC_BRCH%TYPE;            --대리지점
    T_GGA06M01_SLIP_NO             GGA06M01.SLIP_NO%TYPE;              --전표번호
    T_GGA06M01_SLIP_SUB_NO         GGA06M01.SLIP_SUB_NO%TYPE;          --전표부번호
    T_GGA06M01_RECV_SLIP_DT        GGA06M01.RECV_SLIP_DT%TYPE;         --수신전표일자
    T_GGA06M01_RECV_BNH_CD         GGA06M01.RECV_BNH_CD%TYPE;          --수신부점코드
    T_GGA06M01_RECV_AGNC_BRCH      GGA06M01.RECV_AGNC_BRCH%TYPE;       --수신대리지점
    T_GGA06M01_RECV_SLIP_NO        GGA06M01.RECV_SLIP_NO%TYPE;         --수신전표번호
    T_GGA06M01_RECV_SLIP_SUB_NO    GGA06M01.RECV_SLIP_SUB_NO%TYPE;     --수신전표부번호
    T_GGA06M01_RECV_ACT_CD         GGA06M01.RECV_ACT_CD%TYPE;          --수신계정코드
    T_GGA06M01_RECV_YN             GGA06M01.RECV_YN%TYPE;              --수신여부
    T_GGA06M01_WORK_MN             GGA06M01.WORK_MN%TYPE;              --처리자
    T_GGA06M01_WORK_DTM            GGA06M01.WORK_DTM%TYPE;             --처리일시
    T_GGA06M01_WORK_TRM            GGA06M01.WORK_TRM%TYPE;             --처리단말
    T_GGA06M01_RECV_ACC_RMRK_CD    GGA06M01.RECV_ACC_RMRK_CD%TYPE;     --수신적요코드


BEGIN
  IF I_WORK_TP = 'A' THEN -- 수발신 전표는 최소 승인만 가능, 취소나 폐기시에는 역전표 입력함.
      FOR C1 IN
          (
          SELECT  NVL(RECV_SND_TP,'0') RECV_SND_TP, SLIP_SUB_NO
                 ,ACC_RMRK_CD                       -- 2008-03-06   추가 (수기전표라도 적요를 통하여 수발신전표가 입력되는 경우)
                 ,OPR_BNH_CD
                 ,OPR_AGNC_BRCH
                 ,WORK_MN
                 ,WORK_TRM
                 ,CNFM_MN
          FROM    VN.GGA06M00
          WHERE   SLIP_DT = I_SLIP_DT
          AND     BRCH_CD = I_BRCH_CD
          AND     AGNC_BRCH = I_AGNC_BRCH
          AND     SLIP_NO = I_SLIP_NO
          ) LOOP

          IF C1.RECV_SND_TP = '1' THEN

                --발신전표가 적요에 의해 발생된 전표가 아닌경우 수신전표 생성
                IF  C1.ACC_RMRK_CD IS NULL THEN

--pxc_log_write('pgg_job_recv_snd_slip_main',' PGG_JOB_RECV_SND_SLIP2' );

                     VN.PGG_JOB_RECV_SND_SLIP2(
                                              I_SLIP_DT       ,    --  VOUCHER DATE
                                              I_BRCH_CD       ,    --  SENDER
                                              I_AGNC_BRCH     ,    --  SENDER
                                              I_SLIP_NO       ,    --  VOUCHER NO (SENDING VOUCHER NO)
                                              C1.SLIP_SUB_NO       --  VOUCHER NO (SENDING VOUCHER NO)
                                              );
                --발신전표가 적요에 의해 발생된 전표인 경우 수신전표 생성
                ELSE
--pxc_log_write('pgg_job_recv_snd_slip_main',' PGG_JOB_RECV_SND_SLIP' );

                    --수발신번호 채번
                    SELECT  NVL(MAX(RECV_SND_NO),0) + 1
                      INTO  T_GGA06M01_RECV_SND_NO
                      FROM  GGA06M01;

                    --발신정보 지정
                    T_GGA06M01_SLIP_DT          :=  I_SLIP_DT;         --전표일자
                    T_GGA06M01_BRCH_CD          :=  I_BRCH_CD;         --발신지점
                    T_GGA06M01_AGNC_BRCH        :=  I_AGNC_BRCH;       --발신지점(출장소)
                    T_GGA06M01_SLIP_NO          :=  I_SLIP_NO;         --전표번호
                    T_GGA06M01_SLIP_SUB_NO      :=  C1.SLIP_SUB_NO;     --전표부번호
                    T_GGA06M01_RECV_SLIP_DT     :=  NULL;                       --수신전표일자(수신전표 처리시 입력)
                    T_GGA06M01_RECV_BNH_CD      :=  C1.OPR_BNH_CD;      --수신부점코드
                    T_GGA06M01_RECV_AGNC_BRCH   :=  C1.OPR_AGNC_BRCH;   --수신대리지점
                    T_GGA06M01_RECV_SLIP_NO     :=  NULL;                       --수신전표번호(수신전표 처리시 입력)
                    T_GGA06M01_RECV_SLIP_SUB_NO :=  NULL;                       --수신전표부번호(수신전표 처리시 입력)
                    T_GGA06M01_RECV_ACT_CD      :=  NULL;                       --수신계정코드
                    T_GGA06M01_RECV_YN          :=  NULL;                       --수신여부(수신전표 처리시 입력)
                    T_GGA06M01_WORK_MN          :=  C1.CNFM_MN;         --처리자
                    T_GGA06M01_WORK_DTM         :=  SYSDATE;                    --처리일시
                    T_GGA06M01_WORK_TRM         :=  C1.WORK_TRM;        --처리단말


                    --현재 발신적요에 대한 상대적요 구하기
                    SELECT  OPR_ACC_RMRK_CD
                      INTO  T_GGA06M01_RECV_ACC_RMRK_CD
                      FROM  GGA03C00 A
                           ,GGA03C01 B
                     WHERE  A.ACC_RMRK_CD = B.ACC_RMRK_CD
                       AND  A.ACC_RMRK_CD = C1.ACC_RMRK_CD
                       AND  B.RECV_SND_TP = '1';

--pxc_log_write('pgg_create_voucher.','T_GGA06M01_RECV_SND_NO      =['||T_GGA06M01_RECV_SND_NO      ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_SLIP_DT          =['||T_GGA06M01_SLIP_DT          ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_BRCH_CD          =['||T_GGA06M01_BRCH_CD          ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_AGNC_BRCH        =['||T_GGA06M01_AGNC_BRCH        ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_SLIP_NO          =['||T_GGA06M01_SLIP_NO          ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_SLIP_SUB_NO      =['||T_GGA06M01_SLIP_SUB_NO      ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_RECV_SLIP_DT     =['||T_GGA06M01_RECV_SLIP_DT     ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_RECV_BNH_CD      =['||T_GGA06M01_RECV_BNH_CD      ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_RECV_AGNC_BRCH   =['||T_GGA06M01_RECV_AGNC_BRCH   ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_RECV_SLIP_NO     =['||T_GGA06M01_RECV_SLIP_NO     ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_RECV_SLIP_SUB_NO =['||T_GGA06M01_RECV_SLIP_SUB_NO ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_RECV_ACT_CD      =['||T_GGA06M01_RECV_ACT_CD      ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_RECV_YN          =['||T_GGA06M01_RECV_YN          ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_RECV_ACC_RMRK_CD =['||T_GGA06M01_RECV_ACC_RMRK_CD ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_WORK_MN          =['||T_GGA06M01_WORK_MN          ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_WORK_DTM         =['||T_GGA06M01_WORK_DTM         ||']');
--pxc_log_write('pgg_create_voucher.','T_GGA06M01_WORK_TRM         =['||T_GGA06M01_WORK_TRM         ||']');

                    --발신내역 INSERT
                    INSERT  INTO    GGA06M01
                    (
                         RECV_SND_NO          --수신발신번호
                        ,SLIP_DT              --전표일자
                        ,BRCH_CD              --지점코드
                        ,AGNC_BRCH            --대리지점
                        ,SLIP_NO              --전표번호
                        ,SLIP_SUB_NO          --전표부번호
                        ,RECV_SLIP_DT         --수신전표일자
                        ,RECV_BNH_CD          --수신부점코드
                        ,RECV_AGNC_BRCH       --수신대리지점
                        ,RECV_SLIP_NO         --수신전표번호
                        ,RECV_SLIP_SUB_NO     --수신전표부번호
                        ,RECV_ACT_CD          --수신계정코드
                        ,RECV_YN              --수신여부
                        ,RECV_ACC_RMRK_CD     --수신적요
                        ,WORK_MN              --처리자
                        ,WORK_DTM             --처리일시
                        ,WORK_TRM             --처리단말
                    )
                    VALUES
                    (
                         T_GGA06M01_RECV_SND_NO       --발신번호
                        ,T_GGA06M01_SLIP_DT           --전표일자
                        ,T_GGA06M01_BRCH_CD           --발신지점
                        ,T_GGA06M01_AGNC_BRCH         --발신지점(출장소)
                        ,T_GGA06M01_SLIP_NO           --전표번호
                        ,T_GGA06M01_SLIP_SUB_NO       --전표부번호
                        ,T_GGA06M01_RECV_SLIP_DT      --수신전표일자
                        ,T_GGA06M01_RECV_BNH_CD       --수신부점코드
                        ,T_GGA06M01_RECV_AGNC_BRCH    --수신대리지점
                        ,T_GGA06M01_RECV_SLIP_NO      --수신전표번호
                        ,T_GGA06M01_RECV_SLIP_SUB_NO  --수신전표부번호
                        ,T_GGA06M01_RECV_ACT_CD       --수신계정코드
                        ,T_GGA06M01_RECV_YN           --수신여부
                        ,T_GGA06M01_RECV_ACC_RMRK_CD  --수신적요
                        ,T_GGA06M01_WORK_MN           --처리자
                        ,T_GGA06M01_WORK_DTM          --처리일시
                        ,T_GGA06M01_WORK_TRM          --처리단말
                    );

                    --발신정보 이므로 전표정보에 수발신 번호 UPDATE
                    UPDATE GGA06M00
                       SET RECV_SND_NO = T_GGA06M01_RECV_SND_NO     --수발신번호
                     WHERE SLIP_DT     = T_GGA06M01_SLIP_DT         --전표일자
                       AND BRCH_CD     = T_GGA06M01_BRCH_CD         --지점코드
                       AND AGNC_BRCH   = T_GGA06M01_AGNC_BRCH       --대리지점
                       AND SLIP_NO     = T_GGA06M01_SLIP_NO         --전표번호
                       AND SLIP_SUB_NO = T_GGA06M01_SLIP_SUB_NO;    --전표부번호

                --  =============================================================================

                    VN.PGG_JOB_RECV_SND_SLIP
                        /********************
                            CREATE RECEIVE VOUCHER (FOR SEND LIST) : 수신전표 생성(자동발신전표에 대한)
                        ********************/
                        (   I_SLIP_DT                 --  VOUCHER DATE
                           ,I_BRCH_CD                 --  SENDER
                           ,I_AGNC_BRCH               --  SENDER
                           ,I_SLIP_NO                 --  VOUCHER NO (SENDING VOUCHER NO)
                           ,'0000'					  -- 은행코드 2008-05-27
                           ,T_RECURSIVE_PROC_CNT      --재귀호출 COUNTER (INOUT)
                           ,T_PROC_CNT                -- PROC NUMBER (OUT)
                        );
                END IF;

          END IF;

          END LOOP;
  END IF;

--EXCEPTION WHEN OTHERS THEN
--  RAISE_APPLICATION_ERROR(-20100,'P:' || SUBSTR(SQLERRM, 5, 78));

END PGG_JOB_RECV_SND_SLIP_MAIN;
/

