create procedure pts_get_get_shortsell(
  i_sec_cd    in  varchar2
  )   as

  t_qty       number := 0;
  t_cnt       number := 0;
begin

 vn.pxc_log_write('pts_get_get_shortsell',  ' Start ....'  );

for i in (
           Select sum(nmth_qty + mth_qty) sum_ord_qty, stk_cd, acnt_no/*, sub_no*/ 
           from tso01m00
          where sell_buy_tp = '1'
           --and ord_time <= '09:15:00'
--           and crrt_cncl_tp not in != '4'
           group by stk_cd, acnt_no--, sub_no
         )loop

      Select TD_SELL_ORD_QTY + TD_SELL_MTH_QTY
      into t_qty
      from tso04m00
      where acnt_no = i.acnt_no
--        and sub_no = i.sub_no
        and stk_cd = i.stk_cd;

       if i.sum_ord_qty  > fss_get_able_qty_sell(i.acnt_no, '00', i.stk_cd) + fss_get_able_qty_sell(i.acnt_no, '01', i.stk_cd) + fss_get_able_qty_sell(i.acnt_no, '02', i.stk_cd) + fss_get_able_qty_sell(i.acnt_no, '03', i.stk_cd) + t_qty then
         t_cnt := t_cnt + 1;
         vn.pxc_log_write('pts_get_get_shortsell',  'SHORT SELL ACNT_NO = ' || i.acnt_no || ', sub_no ' /*|| i.sub_no*/ || ' stk_cd ' || i.stk_cd);
       end if;
end loop;

if t_cnt > 0 then
   vn.pxc_log_write('pts_get_get_shortsell', 'Shortsell order total: ' || t_cnt || ' account');
else
   vn.pxc_log_write('pts_get_get_shortsell', 'No shortsell order');
end if;
end pts_get_get_shortsell;
/

