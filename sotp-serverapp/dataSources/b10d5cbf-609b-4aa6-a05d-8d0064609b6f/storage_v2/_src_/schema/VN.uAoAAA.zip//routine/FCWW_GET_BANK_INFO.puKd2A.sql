create function fcww_get_bank_info(i_bank_cd in varchar2)
  return varchar2 as
  o_ret varchar2(200);
begin
  o_ret := '';
  begin
    select lpad(trim(c.user_pswd), 100, ' ') || -- as user_pswd
           lpad(trim(c.user_id), 30, ' ') || -- user_id
           lpad(trim(c.scrt_cd), 30, ' ') || --scrt_cd
           lpad(substr(nvl(c.scrt_cd, '     '), 1, 5) ||
                substr(vn.vwdate, 3, 6) ||
                lpad(vn.CWW02M00_SEQ.nextval, 6, '0'),
                30,
                ' ') --ref_no
      into o_ret
      from vn.cww01h00 c
     where c.bank_cd = trim(i_bank_cd)
       and c.bank_knd_tp = '01'
       and vn.wdate between c.mng_strt_dt and c.mng_end_dt;
  exception
    when no_data_found then
      o_ret := '!';
  end;
  return o_ret;
end;
/

