create FUNCTION fdl_get_mrgn_int
(
  i_acnt_no         IN VARCHAR2, --
  i_sub_no          IN VARCHAR2, --
  i_prd_no          IN VARCHAR2, -- 
  i_int_tp          IN NUMBER, -- 1:int 2:dly_int 3:all
  i_lnd_dt          IN VARCHAR2, --
  i_rpy_dt          IN VARCHAR2, --
  i_expr_dt         IN VARCHAR2, --
  i_last_rpy_dt     IN VARCHAR2, --
  i_int_rpy_tp      IN NUMBER, -- 1:khong tinh lai ngay tra, 2. tinh luon lai ngay tra
  i_rpy_mthd_tp     IN NUMBER, -- 1:cash 2:sell(1.tinh lai tren so tien hoan tra, 2.tinh lai dua tren so du goc con lai)
  i_int_calc_apy_tp IN NUMBER, -- 1:lai tinh; 2: lai dong
  i_rpy_amt         IN NUMBER,   -- so tien hoan tra 
  i_remn_amt        IN NUMBER,   -- so tien vay con lai
  i_day_min         IN NUMBER,   -- so ngay tinh lai toi thieu (neu la -1 thi la dung de tinh lai cho ngay ke tiep)
  i_int_waive_day_tp IN NUMBER,  -- Phan loai ngay mien lai: 1-Ngay theo lich (khong tinh ngay nghi); 2-Ngay lam viec (tinh ngay nghi)
  i_int_waive_days  IN NUMBER,   -- So ngay mien lai	
  i_lnd_int_cal_std_dt IN NUMBER,-- So ngay tieu chuan tinh lai
  i_dly_int_yn      IN NUMBER  -- Co tinh lai qua han cua lai hay ko
) RETURN NUMBER AS

  /*!
       \file     fdl_get_mrgn_int.sql
       \brief    margin interest calculation

       \section intro Program Information
            - Program Name              : margin interest calculation
            - Service Name              :
            - Related Client Program- Client Program ID : w_04513
            - Related Tables            : dlm12m10
            - Dev. Date                 : 2010/11/03
            - Developer                 : Oh.
            - Business Logic Desc.      : margin interest calculation
            - Latest Modification Date  : 2010/11/03


    */

  t_first_int_dt varchar2(8);
  t_tot_prd     NUMBER := 0;
  t_lnd_prd     NUMBER := 0;
  t_dly_prd     NUMBER := 0;
  t_lnd_int     NUMBER := 0;
  t_lnd_int_dly NUMBER := 0;

  t_int_calc_apy_tp NUMBER := 0;
  t_lnd_int_cnt      NUMBER := 0;
  t_lnd_int_rt           NUMBER := 0; -- 01:lnd_int ratio  
  t_lnd_int_rt_dly       NUMBER := 0; -- 04:lnd_int dly_rt
  t_lnd_int_prd  NUMBER := 0;
  t_lnd_int_amt_min      NUMBER := 0; -- 03:min lnd_int amt

  t_pre_apy_dt VARCHAR2(08) := NULL;

  o_lnd_int NUMBER := 0;

  t_cost_of_cap NUMBER := 0;  
  t_lnd_int_cal_std_dt number;
BEGIN
  if i_lnd_int_cal_std_dt = 0 then 
	t_lnd_int_cal_std_dt :=1;
  else
	t_lnd_int_cal_std_dt :=i_lnd_int_cal_std_dt;
  end if;

  /*B0. Chuan bi du lieu: cac tham so, cac ti le lai trong khoang thoi gian vay, .... */
  o_lnd_int := 0;

  if i_int_waive_day_tp =2 then /* tinh theo lich lam viec, co tinh ngay nghi */
     t_first_int_dt := vn.fxc_vorderdt_g(to_date(i_lnd_dt,'yyyymmdd'), i_int_waive_days);
  else /* khong tinh ngay nghi, chi tinh truc tiep theo lich */
     t_first_int_dt := to_char(to_date(i_lnd_dt, 'yyyymmdd')+ i_int_waive_days , 'yyyymmdd');
  end if;

  /*============================================================================*/
  /* Get apply loan Valiabl                                                     */
  /*============================================================================*/
  vn.pxc_log_write('fdl_get_mrgn_int'
          ,'Start fdl_get_mrgn_int  : ' || ' ACNT =' ||
           i_acnt_no || '-' || i_sub_no);

  t_lnd_int_amt_min := 0; -- So tien toi thieu co the dung sau nay, hien tai coi nhu ko setup

/* Check xem co tinh lai ngay tra ko */
  IF i_int_rpy_tp = 1 THEN
    t_tot_prd := to_date(i_rpy_dt, 'yyyymmdd') -
           to_date(i_lnd_dt, 'yyyymmdd');
  ELSE
    t_tot_prd := to_date(i_rpy_dt, 'yyyymmdd') -
           to_date(i_lnd_dt, 'yyyymmdd') + 1;
  END IF;

  /* check the total interest period */
  t_lnd_int_prd := to_date(i_rpy_dt, 'yyyymmdd') -
           to_date(i_last_rpy_dt, 'yyyymmdd');

  SELECT COUNT(*)
    INTO t_lnd_int_cnt
  FROM (
    SELECT apy_dt
    FROM vn.dlm30m00
     WHERE prd_no = i_prd_no
     AND apy_dt > i_last_rpy_dt
     AND apy_dt <= i_rpy_dt
	 AND active_stat = 'Y'
    UNION
    SELECT apy_dt
    from vn.DLM30M01
    where acnt_no  =  i_acnt_no
     and  sub_no   =  i_sub_no
     and  prd_no   =  i_prd_no
	 and  apy_dt > i_last_rpy_dt
     and  apy_dt <= i_rpy_dt	 
	 and  active_stat = 'Y'
	UNION
	SELECT to_char(to_date(expr_dt,'yyyymmdd')+1,'yyyymmdd') apy_dt
	from vn.DLM30M01
	where acnt_no  =  i_acnt_no
	  and sub_no   =  i_sub_no
	  and prd_no   =  i_prd_no 
	  AND expr_dt > i_last_rpy_dt
	  AND expr_dt < i_rpy_dt
	  AND apy_dt > i_last_rpy_dt
	  AND apy_dt < i_rpy_dt
	  AND active_stat = 'Y'	 
    ) ;

  t_pre_apy_dt := i_last_rpy_dt;

  IF t_lnd_int_cnt = 0 THEN /*lai tinh*/
    t_int_calc_apy_tp := 1;
  ELSE /*neu co nhieu khung tinh lai thi lay phuong thuc tinh lai theo tham so dau vao*/
    t_int_calc_apy_tp := i_int_calc_apy_tp;
  END IF;

/* t_int_calc_apy_tp = 1 - lai tinh: lay cac ty le lai ap dung cho ngay vay
     nguoc lai - lai dong: lay cac ty le lai ap dung cho cac giai doan */
  /* CASE 1 : using fixed interest ratio */  
  IF t_int_calc_apy_tp = 1 THEN
    t_lnd_int_rt 		:= VN.fdl_get_mrgn_rt_01(i_acnt_no, i_sub_no, '08', i_lnd_dt); 
	t_lnd_int_rt_dly 	:= VN.fdl_get_mrgn_rt_01(i_acnt_no, i_sub_no, '09', i_lnd_dt); 	

	--B1. Tinh so ngay vay trong han, so ngay vay qua han:
    IF i_expr_dt >= i_rpy_dt THEN 
		/* 1. Ngay tra chua qua han */
      t_lnd_prd := to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_last_rpy_dt, 'yyyymmdd');
	  t_dly_prd := 0;
    ELSE 
      IF i_last_rpy_dt>= i_expr_dt THEN 
			/* 2. Ngay tra qua han, ngay tra cuoi cung qua han */
          /*==============================================*/
          /* loan period :                                */
          /* dely prriod : repay date ~ last repay date   */
          /*==============================================*/
          t_lnd_prd := 0;
          t_dly_prd := to_date(i_rpy_dt, 'yyyymmdd') -
                 to_date(i_last_rpy_dt, 'yyyymmdd');
      ELSE
		 /* 3. Ngay tra qua han, ngay tra cuoi cung trong han */
        /*==============================================*/
        /* loan period : expire date ~ land date        */
        /* dely prriod : repay date ~ expire date       */
        /*==============================================*/
        t_lnd_prd := to_date(i_expr_dt, 'yyyymmdd') -
               to_date(i_last_rpy_dt, 'yyyymmdd');
        t_dly_prd := to_date(i_rpy_dt, 'yyyymmdd') -
               to_date(i_expr_dt, 'yyyymmdd');
      END IF;

    END IF;

    /* B2. Tinh lai so ngay vay trong han khi xem xet den so ngay tinh lai toi thieu voi 2 truong hop sau:
	- Neu phuoLaing thuc thu no la "Uu tien thu lai", thi tinh lai toi thieu chi tinh khi tat toan hoac tinh lai lan dau tien
	- Neu phuong thuc thu no la "Lai, goc tuong duong", thi phai tinh lai toi thieu o tat cac cac lan tra no
	- */

	/* - neu tong so ngay tinh lai (trong han+qua han)< so ngay tinh lai toi thieu thi so ngay trong han = so ngay tinh lai toi thieu - so ngay tinh lai qua han 
	*/
    if i_day_min <> -1 then /* Khong tinh lai toi thieu khi tinh lai cho ngay vay ke tiep */
		if i_rpy_mthd_tp =1 and  --1.uu tien thu lai
		   t_first_int_dt = i_last_rpy_dt and  /* tinh lai toi thieu chi tinh khi tat toan hoac tinh lai lan dau tien voi uu tien thu lai*/
	       t_lnd_prd + t_dly_prd < i_day_min then

			t_lnd_prd := i_day_min - t_dly_prd ;
        else
			if i_rpy_mthd_tp =2 and --2.lai, goc tuong duong
				t_lnd_prd + t_dly_prd < i_day_min  then
				t_lnd_prd := i_day_min - t_dly_prd;
			end if;
		end if;
    end if;

	/*B3. Tinh lai trong han */

    IF t_lnd_prd > 0 THEN
	  /*B3.1 Neu tong ngay vay > so ngay vay toi thieu, thi so tien lai trong han = so tien tra (hoac so tien vay con lai) * ti le lai trong han * so ngay vay trong han / so ngay tinh lai tieu chuan
	  */	  
        IF i_rpy_mthd_tp = 1 THEN
          t_lnd_int := greatest(i_rpy_amt * t_lnd_int_rt *
                      t_lnd_prd /
                      t_lnd_int_cal_std_dt
                     ,t_lnd_int_amt_min);
        ELSE
          t_lnd_int := greatest(i_remn_amt * t_lnd_int_rt *
                      t_lnd_prd /
                      t_lnd_int_cal_std_dt
                     ,t_lnd_int_amt_min);
        END IF;
    END IF;

	/*B4. Tinh lai qua han */

    IF t_dly_prd > 0 THEN
      /* B4.1 Neu ko tinh lai qua han cua lai, lai qua han = so tien tra (hoac so tien no con lai) * ti le lai qua han * so ngay qua han/ so ngay tinh lai tieu chuan*/
      IF i_dly_int_yn = 0 then
        IF i_rpy_mthd_tp = 1 THEN
          t_lnd_int_dly := i_rpy_amt * t_lnd_int_rt_dly * t_dly_prd /
                   t_lnd_int_cal_std_dt;
        ELSE
          t_lnd_int_dly := i_remn_amt * t_lnd_int_rt_dly * t_dly_prd /
                   t_lnd_int_cal_std_dt;
        END IF;
      /* B4.2 Neu CO tinh lai qua han cua lai, lai qua han = { so tien tra (hoac so tien no con lai) + so tien lai trong han } * ti le lai qua han * so ngay qua han/ so ngay tinh lai tieu chuan*/
      ELSE
        IF i_rpy_mthd_tp = 1 THEN
          t_lnd_int_dly := (i_rpy_amt + t_lnd_int) * t_lnd_int_rt_dly * t_dly_prd /
                   t_lnd_int_cal_std_dt;
        ELSE
          t_lnd_int_dly := (i_remn_amt + t_lnd_int) * t_lnd_int_rt_dly * t_dly_prd /
                   t_lnd_int_cal_std_dt;
        END IF;
      END IF;
    END IF;
    vn.pxc_log_write('fdl_get_mrgn_int'
            ,'interest fix : ' || ' t_pre_apy_dt =' ||
             t_pre_apy_dt || ' t_lnd_int_rt =' || t_lnd_int_rt ||
             ' t_lnd_int_rt_dly =' || t_lnd_int_rt_dly ||
             ' t_lnd_int =' || t_lnd_int || ' t_lnd_int_dly =' ||
             t_lnd_int_dly || ' t_lnd_prd =' || t_lnd_prd ||
             ' t_dly_prd =' || t_dly_prd);

    /* CASE 2 : using moveable interest ratio */
  ELSE
    FOR C1 IN (       
                SELECT apy_dt 
                FROM ( 
                  SELECT apy_dt
                       FROM vn.dlm30m00
                  WHERE prd_no = i_prd_no
                        AND apy_dt > i_last_rpy_dt
                        AND apy_dt < i_rpy_dt
						AND active_stat = 'Y'						
                  UNION
                  SELECT apy_dt
                  from vn.DLM30M01
                  where acnt_no  =  i_acnt_no
                   and  sub_no   =  i_sub_no
                   and  prd_no   =  i_prd_no   
                   AND apy_dt > i_last_rpy_dt
                   AND apy_dt < i_rpy_dt
				   AND active_stat = 'Y'						                   
                  union 
                  SELECT to_char(to_date(expr_dt,'yyyymmdd')+1,'yyyymmdd') apy_dt
                  from vn.DLM30M01
                  where acnt_no  =  i_acnt_no
                   and  sub_no   =  i_sub_no
                   and  prd_no   =  i_prd_no 
                   AND expr_dt > i_last_rpy_dt
                   AND expr_dt < i_rpy_dt /* vong cuoi tinh rieng ben ngoai Loop de tinh lai toi thieu */
                   AND apy_dt > i_last_rpy_dt
                   AND apy_dt < i_rpy_dt
				   AND active_stat = 'Y'
                  ) 
                 order by apy_dt
            ) 
    LOOP
	/* Thu hien lap lai ti le lai trong han, qua han, so ngay trong han, qua han cua MOI KY TINH LAI */
	/*B1. Tinh ti le, so ngay vay trong han, qua han */
		t_lnd_int_rt 		:= VN.fdl_get_mrgn_rt_01(i_acnt_no, i_sub_no, '08', t_pre_apy_dt); 
		t_lnd_int_rt_dly 	:= VN.fdl_get_mrgn_rt_01(i_acnt_no, i_sub_no, '09', t_pre_apy_dt); 	   

      t_lnd_prd := 0;
      t_dly_prd := 0;
      IF i_expr_dt > C1.apy_dt THEN
	    /* 1. Ngay tra chua qua han */
        t_dly_prd := 0;
        t_lnd_prd := to_date(C1.apy_dt, 'yyyymmdd') - to_date(t_pre_apy_dt, 'yyyymmdd');
      elsif i_expr_dt < t_pre_apy_dt THEN
	    /* 2. Ngay tra qua han, ngay tra cuoi cung qua han */
        t_lnd_prd := 0;
        t_dly_prd := to_date(C1.apy_dt, 'yyyymmdd') - to_date(t_pre_apy_dt, 'yyyymmdd');
      else
	    /* 3. Ngay tra CHUA qua han, ngay tra cuoi cung qua han */
        t_lnd_prd := to_date(i_expr_dt, 'yyyymmdd') - to_date(t_pre_apy_dt, 'yyyymmdd')+1; 
        t_dly_prd := to_date(C1.apy_dt, 'yyyymmdd') - to_date(i_expr_dt, 'yyyymmdd')-1; 
      END IF;


      /* Luu y: voi cach lai tinh, so ngay tinh lai toi thieu se chi tinh o khung cuoi cung (ngoai vong lap loop)*/

	/*B2. Tinh so tien lai trong han */	  
      IF t_lnd_prd > 0 THEN
         IF i_rpy_mthd_tp = 1 THEN
            t_lnd_int := t_lnd_int +
                   round(greatest(i_rpy_amt *
                          t_lnd_int_rt *
                          t_lnd_prd /
                          t_lnd_int_cal_std_dt
                           ,t_lnd_int_amt_min));
          ELSE
            t_lnd_int := t_lnd_int +
                   round(greatest(i_remn_amt *
                          t_lnd_int_rt *
                          t_lnd_prd /
                          t_lnd_int_cal_std_dt
                           ,t_lnd_int_amt_min));
          END IF;
      END IF;

	/*B3. Tinh so tien lai QUA han */	  
      IF t_dly_prd > 0 THEN        
        IF i_dly_int_yn = 0 then
		  /* B3.1 Neu KO tinh lai qua han cua lai */
          IF i_rpy_mthd_tp = 1 THEN
            t_lnd_int_dly := t_lnd_int_dly +
                     i_rpy_amt * t_lnd_int_rt_dly *
                         t_dly_prd /
                         t_lnd_int_cal_std_dt;
          ELSE
            t_lnd_int_dly := t_lnd_int_dly +
                     i_remn_amt * t_lnd_int_rt_dly *
                         t_dly_prd /
                         t_lnd_int_cal_std_dt;
          END IF;
         ELSE
		   /* B3.2 Neu CO tinh lai qua han cua lai */
           IF i_rpy_mthd_tp = 1 THEN
            t_lnd_int_dly := t_lnd_int_dly +
                     (i_rpy_amt + t_lnd_int) * t_lnd_int_rt_dly *
                         t_dly_prd /
                         t_lnd_int_cal_std_dt;
            ELSE
              t_lnd_int_dly := t_lnd_int_dly +
                       (i_remn_amt  + t_lnd_int) * t_lnd_int_rt_dly *
                           t_dly_prd /
                           t_lnd_int_cal_std_dt;
            END IF;
          END IF;
      END IF;

      vn.pxc_log_write('fdl_get_mrgn_int'
              ,'interest  : ' || ' t_pre_apy_dt =' ||
               t_pre_apy_dt || ' t_lnd_int_rt =' ||
               t_lnd_int_rt || ' t_lnd_int_rt_dly =' ||
               t_lnd_int_rt_dly || ' t_lnd_int =' ||
               t_lnd_int || ' t_lnd_int_dly =' ||
               t_lnd_int_dly || ' t_lnd_prd =' || t_lnd_prd ||
               ' t_dly_prd =' || t_dly_prd);
      t_pre_apy_dt      := C1.apy_dt;

    END LOOP;

    t_lnd_prd := 0;
    t_dly_prd := 0;

    /* Tinh lai trong han, qua han khung cuoi cung */
	/*B1. Tinh ti le, so ngay vay trong han, qua han */
    t_lnd_int_rt 		:= VN.fdl_get_mrgn_rt_01(i_acnt_no, i_sub_no, '08', t_pre_apy_dt); 
	t_lnd_int_rt_dly 	:= VN.fdl_get_mrgn_rt_01(i_acnt_no, i_sub_no, '09', t_pre_apy_dt); 		

    IF i_expr_dt > i_rpy_dt THEN
	/* 1. Ngay tra chua qua han */
      t_dly_prd := 0;
      t_lnd_prd := to_date(i_rpy_dt, 'yyyymmdd') -
             to_date(t_pre_apy_dt, 'yyyymmdd');
    ELSE
      IF i_expr_dt > t_pre_apy_dt THEN
	   /* 2. Ngay tra CHUA qua han, ngay tra cuoi cung qua han */
        t_lnd_prd := to_date(i_expr_dt, 'yyyymmdd') -
               to_date(t_pre_apy_dt, 'yyyymmdd') + 1; 
        t_dly_prd := to_date(i_rpy_dt, 'yyyymmdd') -
               to_date(i_expr_dt, 'yyyymmdd') - 1; 
      ELSE
	  /* 3. Ngay tra qua han, ngay tra cuoi cung qua han */
        t_lnd_prd := 0;
        t_dly_prd := to_date(i_rpy_dt, 'yyyymmdd') -
               to_date(t_pre_apy_dt, 'yyyymmdd');
      END IF;
    END IF;

	/*B2. Tinh so ngay vay trong han khi xem xet so ngay vay toi thieu */
    /* so sanh voi so ngay tinh lai toi thieu*/
      -- Neu tong so ngay vay tinh lai (so ngay vay thuc - tru di so ngay mien lai) nho hon so ngay tra lai toi thieu
      -- thi so ngay vay se tinh bang so ngay tra lai toi thieu tru di so ngay da tra lai
    /*  end*/	

    if i_day_min <> -1 then  /* Khong tinh lai toi thieu khi tinh lai cho ngay vay ke tiep */
		if i_rpy_mthd_tp =1 and i_last_rpy_dt = t_first_int_dt and i_rpy_dt - t_first_int_dt <i_day_min then
			t_lnd_prd := i_day_min - (t_pre_apy_dt - t_first_int_dt) ;
		else
		  if i_rpy_mthd_tp =2 and i_rpy_dt - t_first_int_dt <i_day_min then
			t_lnd_prd := i_day_min - (t_pre_apy_dt - t_first_int_dt) ;
		  end if;
		end if;
	end if;
	/*B3. Tinh so tien lai trong han */	
    IF t_lnd_prd > 0 THEN
		IF i_rpy_mthd_tp = 1 THEN
		  t_lnd_int := t_lnd_int +
				 round(greatest(i_rpy_amt * t_lnd_int_rt *
						t_lnd_prd /
						t_lnd_int_cal_std_dt
						 ,t_lnd_int_amt_min));
		ELSE
		  t_lnd_int := t_lnd_int +
				 round(greatest(i_remn_amt * t_lnd_int_rt *
						t_lnd_prd /
						t_lnd_int_cal_std_dt
						 ,t_lnd_int_amt_min));
		END IF;
    END IF;

	/*B4. Tinh so tien lai QUA han */	
    IF t_dly_prd > 0 THEN
      /* B4.1 Neu ko tinh lai qua han cua lai */
      IF i_dly_int_yn = 0 then
        IF i_rpy_mthd_tp = 1 THEN
          t_lnd_int_dly := t_lnd_int_dly +
                   i_rpy_amt * t_lnd_int_rt_dly *
                       t_dly_prd / t_lnd_int_cal_std_dt;
        ELSE
          t_lnd_int_dly := t_lnd_int_dly +
                   i_remn_amt * t_lnd_int_rt_dly *
                       t_dly_prd / t_lnd_int_cal_std_dt;
        END IF;
      /* B4.2 Neu Co tinh lai qua han cua lai */
      ElSE
        IF i_rpy_mthd_tp = 1 THEN
          t_lnd_int_dly := t_lnd_int_dly +
                   (i_rpy_amt + t_lnd_int) * t_lnd_int_rt_dly *
                       t_dly_prd / t_lnd_int_cal_std_dt;
        ELSE
          t_lnd_int_dly := t_lnd_int_dly +
                   (i_remn_amt + t_lnd_int) * t_lnd_int_rt_dly *
                       t_dly_prd / t_lnd_int_cal_std_dt;
        END IF;
      END IF;
    END IF;

    vn.pxc_log_write('fdl_get_mrgn_int'
            ,'interest last  : ' || ' t_pre_apy_dt =' ||
             t_pre_apy_dt || ' t_lnd_int_rt =' || t_lnd_int_rt ||
             ' t_lnd_int_rt_dly =' || t_lnd_int_rt_dly ||
             ' t_lnd_int =' || t_lnd_int || ' t_lnd_int_dly =' ||
             t_lnd_int_dly || ' t_lnd_prd =' || t_lnd_prd ||
             ' t_dly_prd =' || t_dly_prd);
  END IF;

  /*==================================================*/
  /* interest type : 1.interest with round function 2.delay with round function interest 3.total with round function*/
  /* interest type : 4.interest without round function 5.delay without round function interest other total*/
  /* interest type : 6.cost of cap*/
  /*==================================================*/
    t_cost_of_cap := t_lnd_int_prd * i_remn_amt * VN.fdl_get_mrgn_rt_01(i_acnt_no, i_sub_no, '34', t_pre_apy_dt);
    if  i_int_tp = 1 then
        o_lnd_int := round(t_lnd_int);
    elsif i_int_tp = 2 then
        o_lnd_int := round(t_lnd_int_dly);
    elsif i_int_tp = 3 then
      o_lnd_int := t_lnd_int + t_lnd_int_dly;
    elsif i_int_tp = 4 then
      o_lnd_int := t_lnd_int;
    elsif i_int_tp = 5 then
      o_lnd_int := t_lnd_int_dly;
    elsif i_int_tp = 6 then
      o_lnd_int := CEIL(t_cost_of_cap); 
    else
        o_lnd_int := t_lnd_int + t_lnd_int_dly;
    end if;

    return o_lnd_int;
  vn.pxc_log_write('fdl_get_mrgn_int'
          ,'End fdl_get_mrgn_int  : ' || ' ACNT =' || i_acnt_no || '-' ||
           i_sub_no);
END fdl_get_mrgn_int;
/

