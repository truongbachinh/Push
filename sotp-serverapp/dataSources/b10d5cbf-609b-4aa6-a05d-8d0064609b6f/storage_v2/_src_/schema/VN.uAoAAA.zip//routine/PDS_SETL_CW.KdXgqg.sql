create PROCEDURE    pds_setl_cw
(
    i_pgm_gb        IN      VARCHAR2,   -- 1: dpo    2: tax   3: stock
    i_setl_dt       IN      VARCHAR2,
    i_acnt_no       IN      VARCHAR2,
    i_sub_no        IN      VARCHAR2,
    i_cw_cd         IN      VARCHAR2,
    i_setl_tp       IN      VARCHAR2,
    i_work_mn       IN      VARCHAR2,
    i_work_trm      IN      VARCHAR2
) AS

/* ************************************************************************************************
  Author:         hphan
  Created Date:   29-Jan-2018
  Description:    This procedure is used to implement cw dpo settlement.

  Sample call:
    exec pds_setl_cw('1','20180131','061C600088','01','VIC','1','system','1.1.1.1');

  MODIFICATION DETAILS:
  -------------------------------------------------------------------------------------------------
  Modified Date   Modified By       Modification Details
  -------------------------------------------------------------------------------------------------
  29-Jan-2018     hphan             Initial creation

**************************************************************************************************/

    t_rtn               VARCHAR2(1)  ;
    t_vwdate            VARCHAR2(8)  := NULL;
    t_setl_tp           VARCHAR2(2)  ;
    t_sec_cd            VARCHAR(10)  := vn.fxc_sec_cd('R');

    t_err_msg           VARCHAR2(500);
    t_pgm_id            VARCHAR2(4)  ; /* Batch control PGM_ID */

    o_cnt1              NUMBER       := 0;
    o_err_cnt1          NUMBER       := 0;
    o_cnt_row           NUMBER       := 0;
    o_sum_vm            NUMBER       := 0;

    o_cnt_setl          NUMBER       := 0;
    o_err_setl          NUMBER       := 0;

BEGIN

    t_vwdate := TO_CHAR(vn.hdate, 'YYYYMMDD');

    IF(vn.fxc_holi_ck(TO_DATE(t_vwdate, 'YYYYMMDD')) != '0') THEN
        RETURN;
    END IF;

    vn.pxc_log_write('pds_setl_cw', 'pds_setl_cw START: '
                                    || 'pgm_gb = '      || i_pgm_gb
                                    || ' setl_dt = '    || i_setl_dt);

    -- Match job_id
    IF (i_pgm_gb = '1') THEN
        t_pgm_id    := 6020;
    ELSIF (i_pgm_gb = '2') THEN
        t_pgm_id    := 6030;
    ELSIF (i_pgm_gb = '3') THEN
        t_pgm_id    := 6040;
    END IF;

    -- Get cw_cd and setl_tp from input string
    SELECT 
        CASE 
            WHEN i_setl_tp = '%'
                THEN i_setl_tp
            ELSE
                TRIM(SUBSTR(i_setl_tp, 1, INSTR(i_setl_tp, '-') - 1))
        END
    INTO t_setl_tp
    FROM DUAL;

    IF(i_pgm_gb = '1') THEN     /* DPO settlement */
        vn.pxc_log_write('pds_setl_cw', 'Start dpo settlement');

        -- Update batch status
        pds_batch_stat_udt('S', '1', 0, t_pgm_id, t_rtn);
        -- -- COMMIT;

        BEGIN
            -- Process dpo settlement
            vn.pds_dpo_setl_cw( i_setl_dt,     i_acnt_no,    i_sub_no,  t_setl_tp,
                                i_work_mn,     i_work_trm,   o_cnt1,    o_err_cnt1);
            EXCEPTION WHEN OTHERS THEN
                -- ROLLBACK;
                -- Update batch status
                o_err_setl := o_err_setl + o_err_cnt1;
                pds_batch_stat_udt('E', '3', o_err_setl, t_pgm_id, t_rtn);
                -- COMMIT;

                -- Log
                t_err_msg := 'Error CW dpo settlement - ' || sqlcode || ' - ' || sqlerrm;
                vn.pxc_log_write('pds_setl_cw', t_err_msg);
                -- COMMIT;

                RAISE_APPLICATION_ERROR(-20010, t_err_msg);
        END;
        -- COMMIT;

        o_cnt_setl := o_cnt_setl + o_cnt1; 
        o_cnt_row := 0;

        SELECT vn.fds_setl_chk_cw(t_vwdate, '1')
        INTO o_cnt_row
        FROM dual;

        IF(o_cnt_row = 0) THEN
            pds_batch_stat_udt('E', '2', o_cnt_setl, t_pgm_id, t_rtn);
            -- COMMIT;
        ELSE
            pds_batch_stat_udt('E', '1', o_cnt_setl, t_pgm_id, t_rtn);
            -- COMMIT;
        END IF;

        vn.pxc_log_write('pds_setl_cw', 'End dpo settlement');
    END IF;

    IF(i_pgm_gb = '2') THEN  /* TAX settlement */
        vn.pxc_log_write('pds_setl_cw', 'Start tax settlement');

        -- Update batch status
        pds_batch_stat_udt('S', '1', 0, t_pgm_id, t_rtn);
        -- COMMIT;

        BEGIN
            -- Process tax settlement
            vn.pds_tax_setl_cw( i_setl_dt,     i_acnt_no,    i_sub_no,      t_setl_tp,
                                i_work_mn,     i_work_trm,   o_cnt1,        o_err_cnt1);
            EXCEPTION WHEN OTHERS THEN
                -- ROLLBACK;
                -- Update batch status
                o_err_setl := o_err_setl + o_err_cnt1;
                pds_batch_stat_udt('E', '3', o_err_setl, t_pgm_id, t_rtn);
                -- COMMIT;

                -- Log
                t_err_msg := 'Error CW tax settlement - ' || sqlcode || ' - ' || sqlerrm;
                vn.pxc_log_write('pds_setl_cw', t_err_msg);
                -- COMMIT;

                RAISE_APPLICATION_ERROR(-20010, t_err_msg);
        END;
        -- COMMIT;

        o_cnt_setl := o_cnt_setl + o_cnt1; 
        o_cnt_row := 0;

        SELECT vn.fds_setl_chk_cw(t_vwdate, '2')
        INTO o_cnt_row
        FROM dual;

        IF(o_cnt_row = 0) THEN
            pds_batch_stat_udt('E', '2', o_cnt_setl, t_pgm_id, t_rtn);
            -- COMMIT;
        ELSE
            pds_batch_stat_udt('E', '1', o_cnt_setl, t_pgm_id, t_rtn);
            -- COMMIT;
        END IF;

        vn.pxc_log_write('pds_setl_cw', 'End tax settlement');
    END IF;

    IF(i_pgm_gb = '3') THEN /* Stock settlement */
        vn.pxc_log_write('pds_setl_cw', 'Start stock settlement');

        -- Update batch status
        pds_batch_stat_udt('S', '1', 0, t_pgm_id, t_rtn);
        -- COMMIT;

        BEGIN
            vn.pds_stk_setl_cw( i_setl_dt,     i_acnt_no,     i_sub_no,      i_cw_cd,       t_setl_tp,
                                i_work_mn,     i_work_trm,    o_cnt1,        o_err_cnt1);
            EXCEPTION WHEN OTHERS THEN
                -- ROLLBACK;
                -- Update batch status
                o_err_setl := o_err_setl + o_err_cnt1;
                pds_batch_stat_udt('E', '3', o_err_setl, t_pgm_id, t_rtn);
                -- COMMIT;

                -- Log
                t_err_msg := 'Error CW stock settlement - ' || sqlcode || ' - ' || sqlerrm;
                vn.pxc_log_write('pds_setl_cw', t_err_msg);
                -- COMMIT;

                RAISE_APPLICATION_ERROR(-20010, t_err_msg);
        END;
        -- COMMIT;

        o_cnt_setl := o_cnt_setl + o_cnt1; 
        o_cnt_row := 0;

        SELECT vn.fds_setl_chk_cw(t_vwdate, '3')
        INTO o_cnt_row
        FROM dual;

        IF(o_cnt_row = 0) THEN
            pds_batch_stat_udt('E', '2', o_cnt_setl, t_pgm_id, t_rtn);
            -- COMMIT;
        ELSE
            pds_batch_stat_udt('E', '1', o_cnt_setl, t_pgm_id, t_rtn);
            -- COMMIT;
        END IF;

        vn.pxc_log_write('pds_setl_cw', 'End stock settlement');
    END IF;

    vn.pxc_log_write('pds_setl_cw', 'pds_setl_cw END: '
                                    || 'pgm_gb = '      || i_pgm_gb
                                    || ' setl_dt = '    || i_setl_dt);

END pds_setl_cw;
/

