create PROCEDURE pss_outbil_p
(
	is_trd_dt			in		varchar2,			--
	is_work_bnh			in		varchar2,			--
	is_detl_trd_tp		in		varchar2,			--
	is_acnt_no			in		varchar2,			--
	is_sub_no			in		varchar2,			--
	is_stk_cd			in		varchar2,			--
	is_stk_nm			in		varchar2,			--
	is_sb_qty			in		varchar2,			--
	is_anth_cd			in		varchar2,			--
	is_anth_acnt_no		in		varchar2,			--
	is_cnte				in		varchar2,			-- 		==================> ???
	is_rmrk_cd			in		varchar2,			--
--	is_mstkey			in		varchar2,			-- 			==================> ???		2007.12.19 remove
	is_work_mn			in		varchar2,			--
	is_work_trm			in		varchar2,			--
	is_dept_no2			in		varchar2,

	os_trd_seq_no		out		varchar2,				--
	os_bil_prerm_qty	out		varchar2,				--
	os_bil_nowrm_qty	out		varchar2				--

) AS

   	ts_buy_dt				varchar2(8)		:= '';

   	tn_trd_seq_no			number	:= 0;			--
   	tn_tot_trd_seq_no			number	:= 0;			--

	tn_bil_prerm_qty		number	:= 0;			--
	tn_tot_bil_prerm_qty	number	:= 0;			--
	tn_tot_bil_nowrm_qty	number	:= 0;			--

	tn_sb_pri				number	:= 0;			--
	tn_sb_qty				number	:= 0;			--
	tn_qty					number	:= 0;
	tn_tmp_qty				number	:= 0;
	tn_own_qty				number	:= 0;

	ts_stk_tp				varchar2(2)		:= '';
	ts_step					varchar2(10)	:= '';
	ts_msg					varchar2(100)	:= '';
	ts_code					varchar2(4)		:= '';

	ts_acnt_tp              varchar2(2)     := '';
	ts_trd_tp               varchar2(4)     := '';

    t_rtn_val               varchar2(1)     := '';
    t_err_txt               varchar2(200);
    t_err_msg               varchar2(500);
    o_cnt                   number  := 0;           --
    vn_bank_cd              varchar2(4); -- NHSV-839

	ERR_RTN					EXCEPTION;
/* *********************************** Log changes ***********************************
05-Dec-2018 vnjvthangnm NHSV-839
*********************************************************************************** */
BEGIN

    IF	is_sb_qty = 0	THEN
    	os_trd_seq_no := NULL;
    	os_bil_prerm_qty := NULL;
    	os_bil_nowrm_qty := NULL;

    	Return;
    END IF;

    /*** check closing ***/

    t_rtn_val := 'Y';

    if  is_work_mn  not in ('DAILY','BATCH') then

        vn.pbm_cls_yn_q(  vn.vhdate
                       ,  vn.fbm_emp_bnh_q(     is_work_mn)
                       ,  vn.faa_acnt_bnh_cd_g( '0',is_acnt_no, is_sub_no)
                       , '1'
                       ,  t_rtn_val
                       ,  t_err_txt
                       );

        if  t_rtn_val  !=  'N' then
            t_err_msg := vn.fxc_get_err_msg('V','2716');
            raise_application_error(-20100,t_err_msg||t_err_txt);
        end if;

    end if;

    /* Get bank code */
    select bank_cd
    into vn_bank_cd
    from aaa01m00
    where acnt_no = trim(is_acnt_no)
    and sub_no = trim(is_sub_no)
    and acnt_stat = '1'; -- active status

    --
   	ts_step := '1';
   	vn.pxc_psb_seq_cret_p (is_acnt_no, is_sub_no, is_trd_dt, tn_trd_seq_no, tn_tot_trd_seq_no);   	-- vn.pxc_log_write('pss_outbil_p', '@@@@@@@@');

    --
    ts_step := '3';
    SELECT	trunc(nvl(book_amt, 0)/nvl(own_qty, 0)), nvl(own_qty, 0), stk_tp
      INTO	tn_sb_pri, tn_bil_prerm_qty, ts_stk_tp
      FROM	vn.ssb01m00
     WHERE	acnt_no = is_acnt_no
	   AND  sub_no  = is_sub_no
       AND	stk_cd = is_stk_cd;

    --
    tn_sb_qty := to_number(is_sb_qty);
    IF	tn_bil_prerm_qty < tn_sb_qty	THEN
    	ts_code := '2205';
        ts_msg := '2205';
        RAISE ERR_RTN;
    END IF;

	--

 /***** trd_tp *************************************/

   ts_acnt_tp :=  vn.faa_get_acnt_tp( is_acnt_no , is_sub_no) ;

   if ts_acnt_tp    = '1' then  --  custodian
      ts_trd_tp :=  '21' ;
   elsif ts_acnt_tp = '2' then  -- bank_connect
      ts_trd_tp :=  '23' ;
   elsif ts_acnt_tp = '3' then  -- non-custodian
      ts_trd_tp :=  '25' ;
   end if ;

   ts_step := '4';

   tn_tot_bil_prerm_qty := vn.fss_get_tot_prerm_qty( is_acnt_no, is_stk_cd);
   tn_tot_bil_nowrm_qty := tn_tot_bil_prerm_qty - tn_sb_qty;

	INSERT INTO vn.aaa10m00 ( 	 acnt_no			--
								,sub_no				--
								,trd_dt				--
								,tot_trd_seq_no			--
								,trd_seq_no			--
								,trd_tp				--
								,rmrk_cd			--
								,mdm_tp				--
								,trd_mdm_tp			--
								,cncl_yn			--
								,org_trd_no			--
								,trd_amt			--
								,cmsn				--
								,adj_amt			--
								,dpo_prerm			--
								,dpo_nowrm			--
								,stk_cd				--
								,stk_nm				--
								,sb_pri				--
								,sb_qty				--
								,bil_prerm_qty		--
								,bil_nowrm_qty		--
								,tot_bil_prerm		--
								,tot_bil_nowrm		--
								,book_amt			--
								,stk_tp				--
								,mth_dt				--
								,lnd_tp				--
								,lnd_dt				--
								,lnd_int			--
								,agnt_yn			--
								,acnt_mng_bnh		--
								,work_bnh			--
								,work_mn			--
								,work_dtm			--
								,work_trm			--
								,anth_cd
								,anth_acnt_no
								,agnc_brch
								,proc_agnc_brch
								,cnte
                ,bank_cd      -- NHSV-839
				)	VALUES	(	 is_acnt_no				-- acnt_no
								,is_sub_no				-- trd_dt
								,is_trd_dt				-- trd_dt
								,tn_tot_trd_seq_no			-- trd_seq_no
								,tn_trd_seq_no			-- trd_seq_no
								,ts_trd_tp				-- trd_tp
								,decode(is_detl_trd_tp, '1', '222', '2', '223', '3', '221', '4', '229', '5', is_rmrk_cd)				-- rmrk_cd
								,'00'					-- mdm_tp
								,'99'					-- trd_mdm_tp
								,'N'					-- cncl_yn
								,0						-- org_trd_no
								,0						-- trd_amt
								,0						-- cmsn
								,0						-- adj_amt
								,0						-- dpo_prerm
								,0						-- dpo_nowrm
								,is_stk_cd				-- stk_cd
								,is_stk_nm				-- stk_nm
								,tn_sb_pri				-- sb_pri
								,tn_sb_qty				-- sb_qty
								,tn_bil_prerm_qty		-- bil_prerm_qty
								,tn_bil_prerm_qty - tn_sb_qty			-- bil_nowrm_qty
								,tn_tot_bil_nowrm_qty		            -- bil_prerm_qty
								,tn_tot_bil_nowrm_qty - tn_sb_qty		-- bil_prerm_qty
								,tn_sb_qty * tn_sb_pri						-- book_amt
								,ts_stk_tp				-- stk_tp
								,null					-- mth_dt
								,null					-- lnd_tp
								,null                   -- lnd_dt
								,null                   -- lnd_int
								,'N'					-- agnt_yn
								,faa_acnt_bnh_cd_g('0', is_acnt_no,is_sub_no)					-- acnt_mng_bnh
								,is_work_bnh			-- work_bnh
								,is_work_mn				-- work_mn
								,sysdate				-- work_dtm
								,is_work_trm			-- work_trm
								,is_anth_cd
								,is_anth_acnt_no
								,faa_acnt_bnh_cd_g( '3', is_acnt_no, is_sub_no)
								,is_dept_no2
								,is_cnte
                ,vn_bank_cd   -- NHSV-839
							);

	--
	ts_step := '5';
	UPDATE	vn.ssb01m00
	   SET	own_qty =  own_qty - tn_sb_qty
	   	   ,book_amt = decode( own_qty - tn_sb_qty , 0 , 0 ,
	   	                         book_amt - (tn_sb_qty * tn_sb_pri) )
	   	   ,work_mn = is_work_mn
	   	   ,work_dtm = sysdate
	   	   ,work_trm = is_work_trm
	 WHERE	acnt_no = is_acnt_no
	   AND  sub_no  = is_sub_no
	   AND	stk_cd = is_stk_cd;

    /*******************************/
    /* call evaluation for margin  */
    /*******************************/

    vn.pdl_crd_loan_rt_proc_td
       ( is_trd_dt
        ,'2' -- stock
        ,is_acnt_no
		,is_sub_no
        ,tn_trd_seq_no
        ,is_work_mn
        ,is_work_trm
        ,o_cnt
       );

    vn.pxc_log_write('pss_outbil_p','pdl_crd_loan_rt_proc_td ['|| o_cnt ||']');

	/* out parametres */
	ts_step := '9';
	os_trd_seq_no 		:= to_char(tn_trd_seq_no);								--
	os_bil_prerm_qty	:= to_char(tn_bil_prerm_qty);							--
	os_bil_nowrm_qty	:= to_char(tn_bil_prerm_qty - tn_sb_qty);				--

	RETURN;

	EXCEPTION
			WHEN 	ERR_RTN	THEN
			     	raise_application_error(-20100, ts_code || ':[pss_outbil_p ' || ts_step || '] ' || ts_msg);
					RETURN;

			WHEN	NO_DATA_FOUND	THEN
					raise_application_error(-20200, '[pss_outbil_p ' || ts_step || '] ' || SQLERRM);
					RETURN;

			WHEN	OTHERS	THEN
					raise_application_error(-20300, '[pss_outbil_p ' || ts_step || '] ' || SQLERRM);
			        RETURN;

END pss_outbil_p;
/

