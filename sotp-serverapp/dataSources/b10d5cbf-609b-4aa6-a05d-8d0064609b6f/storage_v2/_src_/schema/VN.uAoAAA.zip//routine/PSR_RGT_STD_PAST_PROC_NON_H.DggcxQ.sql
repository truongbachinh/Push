create procedure psr_rgt_std_past_proc_non_h
 (
  i_proc_dt    in       varchar2,
  i_stk_cd     in       varchar2,
  i_work_mn    in       varchar2,
  i_work_trm   in       varchar2
 ) is

 vs_stk_cd    varchar2(12);
 vs_rgt_tp    varchar2(1) ;
 vn_seq_no    number := 0;
 vn_std_rt    number := 0;
 vn_std_rt2   number := 0;
 vn_stk_rt    number := 0;
 vn_proc_cnt  number := 0;
 --vn_i_qty1     number := 0;
 --vn_i_qty2     number := 0;

begin

     vn.pxc_log_write('psr_rgt_std_past_proc_non_edit', i_proc_dt||' '||i_stk_cd);

  for  c1  in (

       select   stk_cd,
          rgt_tp,
        rgt_std_dt,
        seq_no,
        rgt_proc_stat,
        nvl(std_rt,1)     std_rt,
        nvl(std_pay_rt,1) std_rt2,
        decode(rgt_tp,'7', nvl(divi_stk_rt,100)/100, 1) stk_rt
       from     vn.srr01m00
       where    vn.fxc_vorderdt_g(to_date(rgt_std_dt, 'yyyymmdd'), -2)    =  vn.fxc_vorderdt_g(to_date(i_proc_dt, 'yyyymmdd'), +1)
       and      stk_cd         like  i_stk_cd
       and      rgt_proc_stat  = '1'

    ) loop

      if c1.rgt_tp = '1' or c1.rgt_tp = '2' or c1.rgt_tp = '3' then

      vs_rgt_tp  := c1.rgt_tp;
      vs_stk_cd  := c1.stk_cd;
      vn_seq_no  := c1.seq_no;
      vn_std_rt  := c1.std_rt;
      vn_std_rt2 := c1.std_rt2;
      vn_stk_rt  := c1.stk_rt;

      if vn_std_rt = 0 then
       vn_std_rt := 1;
      end if;

      vn.pxc_log_write('psr_rgt_std_p', c1.rgt_tp);

       for  c2  in (
         select aa.acnt_no, aa.sub_no, aa.stk_cd, sum(aa.own_qty) own_qty, sum(aa.mrtg_lnd_qty) mrtg_lnd_qty , aa.mng_bnh 
         from
         (select  a.acnt_no acnt_no,
         a.sub_no  sub_no,
         a.stk_cd stk_cd,
         trunc( ( a.own_qty + a.cd_qty + vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'2','0',i_proc_dt) + vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'2','1',i_proc_dt) 
         + vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'2','2',i_proc_dt) + vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'2','3',i_proc_dt) 
         - vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'1','0',i_proc_dt)- vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'1','1',i_proc_dt)
         - vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'1','2',i_proc_dt)- vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'1','3',i_proc_dt))  
         * (vn_std_rt2 / vn_std_rt) ) * vn_stk_rt  own_qty,
         a.mrtg_lnd_qty   mrtg_lnd_qty ,
         b.acnt_mng_bnh   mng_bnh
         from    vn.ssb01h00 a ,
         vn.aaa01m00 b,
         vn.tso04h00 c
         
         where   a.rgt_std_dt = i_proc_dt
         and     a.stk_cd     = vs_stk_cd
        /* and     (a.own_qty + nvl(a.cd_qty,0)+ vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'2','1',i_proc_dt) - vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'1','1',i_proc_dt))   > 0
        */ and ( a.own_qty + a.cd_qty + vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'2','0',i_proc_dt) + vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'2','1',i_proc_dt) 
         + vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'2','2',i_proc_dt) + vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'2','3',i_proc_dt) 
         - vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'1','0',i_proc_dt)- vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'1','1',i_proc_dt)
         - vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'1','2',i_proc_dt)- vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'1','3',i_proc_dt)) >0  
         and     a.acnt_no = b.acnt_no
         and     a.sub_no  = b.sub_no
         and     b.acnt_stat = '1'
         and a.rgt_std_dt = c.dt(+)
         and a.acnt_no = c.acnt_no(+)
         and a.sub_no = c.sub_no(+)
         and a.stk_cd = c.stk_cd(+)
         
         union
         select   a.acnt_no acnt_no,
         a.sub_no  sub_no,
         a.stk_cd stk_cd,
         trunc( ( vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'2','0',i_proc_dt) + vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'2','1',i_proc_dt) 
         + vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'2','2',i_proc_dt) + vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'2','3',i_proc_dt) 
         - vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'1','0',i_proc_dt)- vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'1','1',i_proc_dt)
         - vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'1','2',i_proc_dt)- vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'1','3',i_proc_dt))  
         * (vn_std_rt2 / vn_std_rt) ) * vn_stk_rt  own_qty,
         0   mrtg_lnd_qty ,
         b.acnt_mng_bnh   mng_bnh
         from    vn.tso04h00 a ,
         vn.aaa01m00 b
         where   a.dt = i_proc_dt
         and     a.stk_cd     = vs_stk_cd
         and ( vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'2','0',i_proc_dt) + vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'2','1',i_proc_dt) 
         + vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'2','2',i_proc_dt) + vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'2','3',i_proc_dt) 
         - vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'1','0',i_proc_dt)- vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'1','1',i_proc_dt)
         - vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'1','2',i_proc_dt)- vn.fts_get_mth_day_qty_g_h(a.acnt_no,a.sub_no,'%',vs_stk_cd,'1','3',i_proc_dt)) >0  
         and     a.acnt_no = b.acnt_no
         and     a.sub_no  = b.sub_no
         and     b.acnt_stat = '1'
         and	not exists(select null from vn.ssb01h00 c 
							where c.acnt_no = a.acnt_no 
							and c.sub_no = a.sub_no 
							and c.stk_cd = a.stk_cd
							and c.rgt_std_dt = a.dt))aa
         group by aa.acnt_no, aa.sub_no, aa.stk_cd, aa.mng_bnh

         ) loop

        vn.pxc_log_write('psr_rgt_std_p', c2.acnt_no||c2.sub_no);
        vn.pxc_log_write('psr_rgt_std_p', c2.own_qty);

        insert into  vn.srr02m00
         ( rgt_std_dt    ,
           acnt_no       ,
           sub_no        ,
           stk_cd        ,
           rgt_tp        ,
           seq_no        ,
           acnt_mng_bnh  ,
           own_stk_qty   ,
           own_qty       ,
           asn_qty       ,
           asn_amt       ,
           flotq_amt     ,
           mrtg_lnd_qty  ,
           mrtg_asn_qty  ,
           inq_trd_no    ,
           rcpt_trd_no   ,
           outq_trd_no   ,
           outamt_trd_no ,
           flotq_trd_no  ,
           inter_trd_no   ,
           cons_sbst_qty ,
           cons_sbst_amt ,
           conv_yn     ,
           work_mn       ,
           work_dtm      ,
           work_trm
             ) values  (
           c1.rgt_std_dt      ,
           c2.acnt_no     ,
           c2.sub_no      ,
           vs_stk_cd      ,
           vs_rgt_tp      ,
           vn_seq_no      ,
           c2.mng_bnh     ,
           c2.own_qty     ,
           c2.own_qty     ,
           0              ,
           0              ,
           0              ,
           c2.mrtg_lnd_qty,
           0              ,
           0              ,
           0              ,
           0              ,
           0              ,
           0              ,
           0              ,
           0              ,
           0              ,
           decode(vs_rgt_tp,'7','N',''),
             i_work_mn      ,
           sysdate        ,
           i_work_trm
             ) ;

    end loop;

   update  vn.srr01m00
   set     rgt_proc_stat = '2'
     where   rgt_std_dt    = c1.rgt_std_dt
   and     stk_cd        = vs_stk_cd
   and     rgt_tp        = vs_rgt_tp
   and     seq_no        = vn_seq_no;


   vn.psr_rgt_asn_p( 'I',
                    c1.rgt_std_dt,
                    c1.stk_cd,
                    c1.rgt_tp,
                    c1.seq_no,
                    i_work_mn,
                    i_work_trm,
                    vn_proc_cnt
                    );

       end if;

 end loop;

end  psr_rgt_std_past_proc_non_h;
/

