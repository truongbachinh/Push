create procedure    pxc_batch_sms_staff
(
    i_sec_cd            in        varchar2,
    i_status_batch      in        varchar2
) is
    sms_msg             varchar2(200)  := '' ;
    t_temp              varchar2(10)   := ' ';
    send_phone_no       varchar2(20)   := '0000000000';
    work_tp_a           varchar2(3)    := '999';
    work_tp_b           varchar2(10)   := '999';
    work_mn             varchar2(10)   := 'SMS_STAFF';
    work_trm            varchar2(10)   := 'SYS';
    t_err_txt           varchar2(200)  := Null;

    t_fr_id             varchar2(4)    := null;
    t_to_id             varchar2(4)    := null;

    t_err_msg           varchar2(500);
begin
    vn.pxc_log_write('pxc_batch_sms_staff','i_sec_cd -['||i_sec_cd||']');

    select vn.fxc_holi_ck(vn.wdate)
    into t_temp
    from dual;

    if t_temp = '0' then
        vn.pxc_log_write('pxc_batch_sms_staff', 'The working day is OK');
    else
        vn.pxc_log_write('pxc_batch_sms_staff', 'Today is not working day');
        raise_application_error (-20100, 'Today is not working day');
    end if;

    select min(pgm_id), max(pgm_id) 
    into t_fr_id, t_to_id
    from xbd01m00;

    if vn.fxb_daily_stat_chk ('J','1',t_fr_id, t_to_id,'*') <> 'Y' then
        sms_msg :=  i_sec_cd || ' - BatchJob chua ket thuc. De nghi check lai voi nhan vien nghiep vu!!!';
    else
        vn.pxc_log_write('pxc_batch_sms_staff', 'Batch job done');
        sms_msg :=  i_sec_cd || ' - BatchJob da ket thuc binh thuong! Have a good night ^.^';
    end if;

    for c1 in (
        -- send sms for TYHPT staff
        select rtrim(decode(substr(trim(mobile),1, 1), '0', '84'||substr(trim(mobile),2),  '84'||trim(mobile))) mobile
        from xca99m99
        where jv_cd in (
                    select cbv from xca99m98
                    where day_o_w in to_char(sysdate, 'D'))

        union
        -- send sms for Security company staff
        select decode(substr(trim(HP),1, 1), '0', '84'||substr(trim(HP),2),  '84'|| trim(HP)) mobile
        from xca01m01 a, xca01m00 b
        where a.monitor = 'Y'
        and a.hp is not null
        and a.emp_no = b.id
        and to_char(b.cls_dtm, 'yyyymmdd') = '30000101'
        )
    loop
        begin
            -- insert to sms table for each phone number
            vn.pxc_sms_ins (
                to_char(sysdate, 'yyyymmdd'),       -- i_send_dt          in varchar2,                 
                c1.mobile,                          -- i_recv_phone_no    in varchar2,                 
                send_phone_no,                      -- i_send_phone_no    in varchar2,                 
                '9990',                             -- i_func_cd          in varchar2,                 
                'V',                                -- i_msg_lang         in varchar2,                 
                sms_msg,                            -- i_sms_msg          in varchar2,                 
                work_mn,                            -- i_work_mn          in varchar2,                 
                work_trm,                           -- i_work_trm         in varchar2,                 
                null,                               -- i_acnt_no          in varchar2      default null
                null,                               -- i_sub_no           in varchar2      default null
                '2'                                 -- i_func_tp          in varchar2
            );

        exception
            when others then
                vn.pxc_log_write('pxc_batch_sms_staff','err c1-['||sqlcode||']');
                t_err_txt  :=  'when call pxc_sms_ins' ||  to_char(sqlcode);
                t_err_msg := vn.fxc_get_err_msg('V','2713');
                raise_application_error(-20100,t_err_msg||t_err_txt);
        end;
    end loop;

end pxc_batch_sms_staff;
/

