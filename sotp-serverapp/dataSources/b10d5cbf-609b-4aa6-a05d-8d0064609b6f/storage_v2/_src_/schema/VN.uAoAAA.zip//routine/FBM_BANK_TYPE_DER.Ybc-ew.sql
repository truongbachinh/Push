create function fbm_bank_type_der
(
    i_BANK_TYPE   in   varchar2
)
    return          varchar2
as
    o_rmrk_nm    varchar2(100) ;
    o_use_yn        varchar2(1)   ;
    t_err_txt       varchar2(100) ; -- error text buffer
    o_check_rmrk_cd NUMBER ;

begin

/*============================================================================*/
/* º¯¼ö ÃÊ±âÈ­                                                                */
/*============================================================================*/
    o_rmrk_nm  :=  NULL;
    o_use_yn  :=  NULL;
    o_check_rmrk_cd := 0;

/*============================================================================*/
/* »ç¿ø¸í Á¶È¸                                                                */
/*============================================================================*/

    begin
        select BANK_TYPE||'.'||nvl(BANK_TYPE_NM, ' '),
--               nvl(use_yn, ' ')
--        select 'Test-'||nvl(rmrk_cd, ' '),
               nvl(use_yn, ' ')
      into o_rmrk_nm,
           o_use_yn
          from vn.bmi02D00
         where BANK_TYPE  = i_BANK_TYPE;
    exception
        when  NO_DATA_FOUND  then
      return  'XXXXX';
        when  OTHERS         then
            t_err_txt  :=  '¿À·ù-['||to_char(sqlcode)||']';
            raise_application_error (-20100, t_err_txt);
    end;

    if o_use_yn = 'N' then
      return  'XXXXX';
    else
      return  o_rmrk_nm;
    end if;
end fbm_bank_type_der;
/

