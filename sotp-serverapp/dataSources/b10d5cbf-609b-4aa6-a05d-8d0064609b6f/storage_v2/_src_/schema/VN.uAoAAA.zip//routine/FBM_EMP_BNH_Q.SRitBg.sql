create function fbm_emp_bnh_q
(
    i_emp_no   in   varchar2        -- ������
)
    return          varchar2
as
    o_emp_bnh		varchar2(100) ;
    t_err_txt       varchar2(100)  ; -- error text buffer

begin

/*============================================================================*/
/* ���� ���                                                                */
/*============================================================================*/
    o_emp_bnh  :=  NULL;

/*============================================================================*/
/* �Ҽ���� ��ȸ                                                              */
/*============================================================================*/
    begin
      	select nvl(brch_cd, ' ')
		  into o_emp_bnh
          from vn.xca01m01
         where emp_no	= i_emp_no;
    exception
        when  NO_DATA_FOUND  then
			return  '!';
        when  OTHERS         then
            t_err_txt  :=  '����-['||to_char(sqlcode)||']';
            raise_application_error (-20100, t_err_txt);
    end;

    return  o_emp_bnh;

end fbm_emp_bnh_q;
/

