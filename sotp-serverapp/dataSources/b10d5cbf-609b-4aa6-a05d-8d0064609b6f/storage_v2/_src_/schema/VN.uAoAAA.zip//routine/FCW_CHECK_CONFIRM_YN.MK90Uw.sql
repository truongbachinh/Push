create function FCW_CHECK_CONFIRM_YN
(
  i_sec_cd    in      varchar2,
  i_SEQ_NO      in      varchar2,
  i_acnt_no    in    varchar2,
  i_sub_no     in    varchar2
) return varchar2 as

  o_staff_free varchar2(1);
  ti_count  number;

begin
  begin
      select COUNT(*)
      into  ti_count
      from vn.CWD11M00 a
      where a.SEQ_NO = i_SEQ_NO
      AND ACNT_NO=i_acnt_no
      AND SUB_NO=i_sub_no
      and SENDED_STAT='5';
   exception
    when  no_data_found then  -- user is customer, or emp_no is not free emp_no
        return 'N';
    end;
    IF ti_count > 0 then
      return 'Y';
      else
        return 'N';
    end if;


end;
/

