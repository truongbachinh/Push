create procedure pts_tso02m00_mrgn_ref
(
	i_firm_no		  in     varchar2,
   i_acnt_no        in     varchar2,
   i_sub_no         in     varchar2
)AS

/*!
   \file     :	pts_tso02m00_mrgn_ref.sql
   \Developer: Mickey
   \Date		 : 2012/10/10

   	Khi Broker thay doi ro chung khoan moi cho KH can phai tinh toan lai cac gia tri TSO02M00:
   		- Mua cho ve, ban cho di
   		- Danh gia ck mua khop trong ngay
  		Viec lam nay chi duoc thuc hien truoc khi chay batchjob
*/
t_temp					varchar2(10);
t_pd_mth_dt				varchar2(8);
t_ppd_mth_dt			varchar2(8);
t_pppd_mth_dt			varchar2(8);
t_cer_rt					NUMBER := 0;
t_buy_sbst_rt			NUMBER := 0;
t_sell_sbst_rt			NUMBER := 0;
t_sbst_rate				NUMBER := 0;
td_cls_pri				NUMBER := 0;
t_mrgn_levl       VARCHAR2(10);

BEGIN
	vn.pxc_log_write('pts_tso02m00_mrgn_ref', '-------Start-------');
	vn.pxc_log_write('pts_tso02m00_mrgn_ref', 'ACNT = [' || i_acnt_no || '] sub_no = [' || i_sub_no || ']');

	t_pd_mth_dt   := vn.fxc_vorderdt_g(vn.wdate(), -1);
	t_ppd_mth_dt  := vn.fxc_vorderdt_g(vn.wdate(), -2);
	t_pppd_mth_dt := vn.fxc_vorderdt_g(vn.wdate(), -3);
	t_cer_rt	  := vn.fdl_get_mrgn_grp_acnt_rt( i_acnt_no, i_sub_no,vn.faa_acnt_get_grp_no (i_acnt_no, i_sub_no,'2', vn.vwdate),'02', vn.vwdate);

	vn.pxc_log_write('pts_tso02m00_mrgn_ref', 't_cer_rt = [' || to_char(t_cer_rt, '0.99') || '], t_pd_mth_dt = [' || t_pd_mth_dt || '], t_ppd_mth_dt = [' || t_ppd_mth_dt || '], t_pppd_mth_dt = [' || t_pppd_mth_dt || ']');

	if t_cer_rt = 0 then
		vn.pxc_log_write('pts_tso02m00_mrgn_ref', ' Account is not margin account ==> Quit job');
		vn.pxc_log_write('pts_tso02m00_mrgn_ref', '-------End-------');
		return;
	end if;

  BEGIN
        SELECT  vn.faa_acnt_get_grp_no(i_acnt_no, i_sub_no,'2',vn.vwdate)
          INTO  t_mrgn_levl
          FROM  dual
        ;
      EXCEPTION WHEN OTHERS THEN
        t_mrgn_levl      := '00';
      END;

	--Lock tso02m00 table
	SELECT  acnt_no
	  INTO  t_temp
	  FROM  VN.TSO02M00
	 where  acnt_no  =  i_acnt_no
	   and  sub_no   =  i_sub_no
	   and  bank_cd  =  '9999' FOR UPDATE;

	--Clear toan bo data danh gia: mua cho ve, ban cho di, danh gia ck mua khop trong ngay de tinh lai
	UPDATE 	vn.tso02m00
	   set   EXPT_SBST_AMT				= 0
	   	, 	EXPT_SBST_ORG_AMT			= 0

	   	,	TD_MGN_SELL_DIFF_AMT 	= 0
	   	,	TD_MGN_BUY_DIFF_AMT  	= 0
	   	,	TD_MGN_SELL_ORG_AMT  	= 0
	   	,	TD_MGN_BUY_ORG_AMT  		= 0

	   	,	PD_MGN_SELL_DIFF_AMT 	= 0
	   	,	PD_MGN_BUY_DIFF_AMT  	= 0
	   	,	PD_MGN_SELL_ORG_AMT  	= 0
	   	,	PD_MGN_BUY_ORG_AMT  		= 0

	   	,	PPD_MGN_SELL_DIFF_AMT 	= 0
	   	,	PPD_MGN_BUY_DIFF_AMT  	= 0
	      ,  PPD_MGN_SELL_ORG_AMT  	= 0
	      ,  PPD_MGN_BUY_ORG_AMT   	= 0

	   	,	PPPD_MGN_SELL_DIFF_AMT 	= 0
	   	,	PPPD_MGN_BUY_DIFF_AMT 	= 0
	   	, 	PPPD_MGN_SELL_ORG_AMT  	= 0
	     	, 	PPPD_MGN_BUY_ORG_AMT   	= 0
	 where  acnt_no  =  i_acnt_no
	   and  sub_no   =  i_sub_no
	   and  bank_cd  =  '9999';

	--Tinh lai toan bo expt amt cho tai khoan
	if i_firm_no in ('068') then
		vn.pxc_log_write('pts_tso02m00_mrgn_ref', 'Call pts_expt_calculate canculate EXPT AMT: start ...');
		pts_expt_calculate(i_firm_no, i_acnt_no, i_sub_no);
		vn.pxc_log_write('pts_tso02m00_mrgn_ref', 'Call pts_expt_calculate: done');
	end if;

	--Tinh lai: mua cho ve, ban cho di trong ngay T0
	vn.pxc_log_write('pts_tso02m00_mrgn_ref', 'Calculate buy and sell wait T0: start ...');
	for C1 in (	SELECT  acnt_no
							, sub_no
							, bank_cd
							, stk_cd
	                  , sum(decode(sell_buy_tp,'1', nvl(mth_qty, 0), 0)) sell_qty
	                  , sum(decode(sell_buy_tp,'2', nvl(mth_qty, 0), 0)) buy_qty
					  FROM  VN.TSO01M00
					 where  acnt_no  =  i_acnt_no
					   and  sub_no   =  i_sub_no
					   and  bank_cd  =  '9999'
					   and  mth_amt > 0
					   and  del_yn = 'N'
                	and  mkt_trd_tp     in  ('01','03','05')
                	and  cdt_tp         in  ('00')
              group  by acnt_no, sub_no, bank_cd, stk_cd
				 ) loop
		td_cls_pri 		:= vn.fss_get_pd_cls_pri( C1.stk_cd);
		t_buy_sbst_rt  := vn.fss_get_match_rate_acnt( C1.stk_cd, 0, C1.acnt_no, C1.sub_no);
		t_sell_sbst_rt := vn.fdl_get_mrgn_basket_rt (c1.acnt_no, c1.sub_no,t_mrgn_levl,faa_acnt_get_basket_cd(c1.acnt_no,c1.sub_no,t_mrgn_levl,vn.vwdate),c1.stk_cd,'01',vn.vwdate);
		t_sbst_rate    := vn.fdl_get_mrgn_basket_rt (c1.acnt_no, c1.sub_no,t_mrgn_levl,faa_acnt_get_basket_cd(c1.acnt_no,c1.sub_no,t_mrgn_levl,vn.vwdate),c1.stk_cd,'01',vn.vwdate);
		if t_sbst_rate = 0 then
		   t_sbst_rate := 0;
		else
		   t_sbst_rate := 1;
		end if;

      update  vn.tso02m00
         set  TD_MGN_SELL_DIFF_AMT =  TD_MGN_SELL_DIFF_AMT + ROUND((C1.sell_qty * td_cls_pri) * t_sell_sbst_rt * t_cer_rt)
           ,  TD_MGN_BUY_DIFF_AMT  =  TD_MGN_BUY_DIFF_AMT  + ROUND((C1.buy_qty  * td_cls_pri) * t_buy_sbst_rt  * t_cer_rt)
           ,  TD_MGN_SELL_ORG_AMT  =  TD_MGN_SELL_ORG_AMT  + ROUND((C1.sell_qty * td_cls_pri * t_sbst_rate))
           ,  TD_MGN_BUY_ORG_AMT   =  TD_MGN_BUY_ORG_AMT   + ROUND((C1.buy_qty  * td_cls_pri * t_sbst_rate))
		 where  acnt_no  =  C1.acnt_no
		   and  sub_no   =  C1.sub_no
		   and  bank_cd  =  C1.bank_cd;
	end loop;

	vn.pxc_log_write('pts_tso02m00_mrgn_ref', 'Calculate buy and sell wait T0: done');

	--Tinh lai: mua cho ve, ban cho di trong ngay T-1, T-2, T-3
	vn.pxc_log_write('pts_tso02m00_mrgn_ref', 'Calculate buy and sell wait: T-1, T-2, T-3: start ...');
	for C2 in (
              select  x.mth_dt      mth_dt
                   ,  x.acnt_no     acnt_no
                   ,  x.sub_no      sub_no
                   ,  x.bank_cd     bank_cd
                   ,  x.stk_cd      stk_cd
                   ,  x.sell_qty    sell_qty
                   ,  x.buy_qty     buy_qty
                   ,  vn.fss_get_pd_cls_pri( x.stk_cd) td_cls_pri
                from (
                      select  mth_dt
                           ,  acnt_no
                           ,  sub_no
                           ,  bank_cd
                           ,  stk_cd
                           ,  sum(decode(sb_tp,'1',decode(stk_setl_yn, 'Y', 0, nvl(sb_qty, 0)), 0)) sell_qty
                           ,  sum(decode(sb_tp,'2',decode(stk_setl_yn, 'Y', 0, nvl(sb_qty, 0)), 0)) buy_qty
                        from  vn.dsc01m00
                       where  acnt_no         =  i_acnt_no
                         and  sub_no			 =  i_sub_no
                         and  bank_cd         =  '9999'
                         and  mth_dt    between  t_pppd_mth_dt  and  t_pd_mth_dt
                         and  mkt_trd_tp     in  ('01','03','05')
                         and  cdt_tp         in  ('00')
                       group  by  mth_dt, acnt_no, sub_no, bank_cd, stk_cd
                       order  by  mth_dt, acnt_no, sub_no, bank_cd, stk_cd
                    ) x
          ) loop

		t_sell_sbst_rt :=  vn.fdl_get_mrgn_basket_rt (c2.acnt_no, c2.sub_no,t_mrgn_levl,faa_acnt_get_basket_cd(c2.acnt_no,c2.sub_no,t_mrgn_levl,vn.vwdate),c2.stk_cd,'01',vn.vwdate);
		t_sbst_rate    :=  vn.fdl_get_mrgn_basket_rt (c2.acnt_no, c2.sub_no,t_mrgn_levl,faa_acnt_get_basket_cd(c2.acnt_no,c2.sub_no,t_mrgn_levl,vn.vwdate),c2.stk_cd,'01',vn.vwdate);
		if t_sbst_rate = 0 then
		   t_sbst_rate := 0;
		else
		   t_sbst_rate := 1;
		end if;

		if  C2.mth_dt  =  t_pppd_mth_dt  then
      	t_buy_sbst_rt := vn.fss_get_match_rate_acnt( C2.stk_cd, 3, C2.acnt_no, C2.sub_no);

			update  vn.tso02m00
			   set  PPPD_MGN_SELL_DIFF_AMT =  PPPD_MGN_SELL_DIFF_AMT + ROUND((C2.sell_qty * C2.td_cls_pri) * t_sell_sbst_rt * t_cer_rt)
			     ,  PPPD_MGN_BUY_DIFF_AMT  =  PPPD_MGN_BUY_DIFF_AMT  + ROUND((C2.buy_qty  * C2.td_cls_pri) * t_buy_sbst_rt  * t_cer_rt)
			     ,  PPPD_MGN_SELL_ORG_AMT  =  PPPD_MGN_SELL_ORG_AMT  + ROUND((C2.sell_qty * C2.td_cls_pri * t_sbst_rate))
			     ,  PPPD_MGN_BUY_ORG_AMT   =  PPPD_MGN_BUY_ORG_AMT   + ROUND((C2.buy_qty  * C2.td_cls_pri * t_sbst_rate))
			 where  acnt_no  =  C2.acnt_no
			   and  sub_no   =  C2.sub_no
			   and  bank_cd  =  C2.bank_cd;

		elsif  C2.mth_dt  =  t_ppd_mth_dt  then
			t_buy_sbst_rt := vn.fss_get_match_rate_acnt( C2.stk_cd, 2, C2.acnt_no, C2.sub_no);

			update  vn.tso02m00
			   set  PPD_MGN_SELL_DIFF_AMT =  PPD_MGN_SELL_DIFF_AMT + ROUND((C2.sell_qty * C2.td_cls_pri) * t_sell_sbst_rt * t_cer_rt)
			     ,  PPD_MGN_BUY_DIFF_AMT  =  PPD_MGN_BUY_DIFF_AMT  + ROUND((C2.buy_qty  * C2.td_cls_pri) * t_buy_sbst_rt  * t_cer_rt)
			     ,  PPD_MGN_SELL_ORG_AMT  =  PPD_MGN_SELL_ORG_AMT  + ROUND((C2.sell_qty * C2.td_cls_pri * t_sbst_rate))
			     ,  PPD_MGN_BUY_ORG_AMT   =  PPD_MGN_BUY_ORG_AMT   + ROUND((C2.buy_qty  * C2.td_cls_pri * t_sbst_rate))
			 where  acnt_no  =  C2.acnt_no
			   and  sub_no   =  C2.sub_no
			   and  bank_cd  =  C2.bank_cd;

		elsif  C2.mth_dt  =  t_pd_mth_dt  then
	      t_buy_sbst_rt := vn.fss_get_match_rate_acnt( C2.stk_cd, 1, C2.acnt_no, C2.sub_no);

	      update  vn.tso02m00
	         set  PD_MGN_SELL_DIFF_AMT =  PD_MGN_SELL_DIFF_AMT + ROUND((C2.sell_qty * C2.td_cls_pri) * t_sell_sbst_rt * t_cer_rt)
	           ,  PD_MGN_BUY_DIFF_AMT  =  PD_MGN_BUY_DIFF_AMT  + ROUND((C2.buy_qty  * C2.td_cls_pri) * t_buy_sbst_rt  * t_cer_rt)
	           ,  PD_MGN_SELL_ORG_AMT  =  PD_MGN_SELL_ORG_AMT  + ROUND((C2.sell_qty * C2.td_cls_pri * t_sbst_rate))
	           ,  PD_MGN_BUY_ORG_AMT  =  PD_MGN_BUY_ORG_AMT   + ROUND((C2.buy_qty  * C2.td_cls_pri * t_sbst_rate))
			 where  acnt_no  =  C2.acnt_no
			   and  sub_no   =  C2.sub_no
			   and  bank_cd  =  C2.bank_cd;
		else
			vn.pxc_log_write('pts_tso02m00_mrgn_ref', ' pts_tso02m00_mrgn_ref mth_dt is not matched: ' || sqlerrm);
			vn.pxc_log_write('pts_tso02m00_mrgn_ref', '-------End-------');
			raise_application_error(-20100, 'error: ' || sqlerrm);
		end if;
	end loop; /* LOOP END - C2 */

	vn.pxc_log_write('pts_tso02m00_mrgn_ref', 'Calculate buy and sell wait: T-1, T-2, T-3: done');

	vn.pxc_log_write('pts_tso02m00_mrgn_ref', '-------End-------');
EXCEPTION
	WHEN OTHERS THEN
		vn.pxc_log_write('pts_tso02m00_mrgn_ref', ' pts_tso02m00_mrgn_ref Error: ' || sqlerrm);
		vn.pxc_log_write('pts_tso02m00_mrgn_ref', '-------End-------');
		raise_application_error(-20100, 'error: ' || sqlerrm);
END pts_tso02m00_mrgn_ref;
/

