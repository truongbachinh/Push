create procedure    pds_setl_cr_pre_cmsn
(
    i_dt             in     varchar2,        --
    i_acnt_no        in     varchar2,        -- acnt_no
    i_sub_no		 in		varchar2,
    i_work_mn        in     varchar2,        -- user id
    i_work_trm       in     varchar2
) AS

/*!
   \file     pds_setl_cr_pre_cmsn.sql
   \brief    previous settlement creation

   \section intro Program Information
        - Program Name              : create previous settle data
        - Service Name              : dl_004511_q1.pc
        - Related Client Program- Client Program ID : w_04511
        - Related Tables            : tso01m00, dsc01m10, aaa01m00
        - Dev. Date                 : 2007/11/08
        - Developer                 : Han.
        - Business Logic Desc.      : previous settle data creation
        - Latest Modification Date  : 2007/11/08

   \section history Program Modification History
    - 1.0    2010/07/19     hjcho   add odd-lot upcom
    - 1.0       2007/11/08     Han.    New.

   \section hardcoding Hard-Coding List
    - HC-1      2007/11/08     Han.    [??]

   \section info Additional Reference Comments
    - ???? ?????? ??

exec pds_setl_cr_pre_cmsn('045','20100302','045C000007','Test','Test');

*/

    t_setl_dt          varchar2(8) := null;
    t_setl_big_dt      varchar2(8) := null;
    t_dt               varchar2(8) := null;

    t_mth_amt          NUMBER      := 0;
    t_cmsn_rt          NUMBER      := 0;
    t_cmsn             NUMBER      := 0;
    t_adj_amt          NUMBER      := 0;
    t_sb_tax_rt        NUMBER      := 0;
    t_sb_tax           NUMBER      := 0;
    t_setl_frct_seq_no NUMBER      := 0;
    t_cmsn_amt         NUMBER      := 0;
    t_cmsn_setl_yn     VARCHAR2(1) := 'N';
    t_calc_tax_yn      VARCHAR2(1)  := 'Y';

    t_cdt_prof_rt      NUMBER      := 0;
    t_sbst_prof_rt     NUMBER      := 0;
    t_crd_amt          NUMBER      := 0;
    t_cdt_prof_amt     NUMBER      := 0;
    t_sbst_prof_amt    NUMBER      := 0;

    t_setl_knd_tp      VARCHAR2(2) := NULL;
    t_cmsn_tp          VARCHAR2(2) := NULL;
    t_prof_levl        VARCHAR2(2) := NULL;
    t_grp_tp           VARCHAR2(1) := null;
    t_frgn_tp          VARCHAR2(1) := null;
    t_tax_clct_tp      VARCHAR2(1) := NULL;
    t_tax1             VARCHAR2(3) := null;
    t_acnt_mng_bnh     varchar2(3) := null;
    t_agnc_brch        varchar2(2) := null;

    t_acnt_no          VARCHAR2(10);
    t_sub_no       VARCHAR2(2);
    t_corp_acnt_no     VARCHAR2(10);

    ts_cnt_tp          varchar2(3) := null;
    t_setl_bank_cd     VARCHAR2(4) := null;
    t_lnd_bank_cd      VARCHAR2(4) := null;

    t4_stk_mkt_tp      VARCHAR2(1) := null;
    t4_stk_cd          VARCHAR2(20):= null;
    t4_sb_tp           VARCHAR2(1) := null;
    t4_cmsn_tp         VARCHAR2(2) := null;
    t4_stk_tp          VARCHAR2(2) := null;
    t4_mkt_trd_tp      VARCHAR2(2) := null;
    t4_setl_knd_tp     VARCHAR2(2) := null;
    t4_cmsn_mdm_tp     VARCHAR2(2) := null;

    t6_fee              NUMBER := 0;
    t6_total_fee        NUMBER := 0;
    t6_available_fee    NUMBER := 0;
    t6_final_fee        NUMBER := 0;
    t6_fee_rt           NUMBER := 0;
    t6_fee_rt_01        NUMBER := 0;
    t6_fee_rt_02        NUMBER := 0;
    t6_fee_mn           NUMBER := 0;
    t6_sb_fee           NUMBER := 0;
    t6_count_fee        NUMBER := 0;
    t6_setl_tp          VARCHAR2(1) := NULL;

    -- Variable for calculating right tax
    t_rgt_tax_cnt       NUMBER := 0;

    ts_work_stat_min   VARCHAR2(1);
    ts_work_stat_max   VARCHAR2(1);

    t_pgm_id           varchar2(4) := '2000'; /* Batch control PGM_ID */
    t_msg              varchar2(10);
    t_err_msg          varchar2(500);

begin

    /*========================================================================*/
    /* Prededing job Check                                                    */
    /*========================================================================

    /*========================================================================*/
    /* Set Date                                                               */
    /*========================================================================*/
    t_dt      := i_dt;

    t_setl_dt     := vn.fxc_vorderdt_g(to_date(t_dt,'yyyymmdd'), 2);
    /* 20150209 bond is T1 */
    t_setl_big_dt := vn.fxc_vorderdt_g(to_date(t_dt,'yyyymmdd'), 1);

    delete  vn.dsc01m10
     where  acnt_no  =  i_acnt_no
       AND  sub_no   =  i_sub_no
    ;

/*============================================================================*/
/* ( )                                                                        */
/*============================================================================*/

    /*========================================================================*/
    /* odd stock SETL_FRCT_SEQ_NO Create                                      */
    /*========================================================================*/
    for C1 in (
        select  t_dt                    stk_ord_dt
             ,  a.bnh_cd                --
             ,  a.ord_no                --
             ,  a.acnt_no               --
             ,  a.sub_no
             ,  a.stk_cd                --
             ,  a.ord_qty               --
             ,  a.ord_pri               --
             ,  a.ord_knd               --
             ,  a.sell_buy_tp           --
             ,  a.mkt_trd_tp            --
             ,  a.stk_ord_tp            --
             ,  a.crrt_cncl_tp          --
             ,  a.stk_tp                --
             ,  a.mdm_tp                --
             ,  vn.fds_get_cmsn_mdm_tp(a.mdm_tp) cmsn_mdm_tp
             ,  a.ord_time              --
             ,  a.ord_veto_cau          --
             ,  a.ord_accp_time         --
             ,  a.org_ord_no            --
             ,  a.first_org_ord_no      --
             ,  a.cncl_qty              --
             ,  a.crrt_qty              --
             ,  a.cncl_cnfm_qty         --
             ,  a.crrt_cnfm_qty         --
             ,  a.org_ord_pri           --
             ,  a.cash_prof_rt          --
             ,  a.frgn_tp               --
             ,  a.sms_yn                --
             ,  a.work_bnh              --
             ,  a.kfx_accp_no           --
             ,  a.sesn_tp               --
             ,  a.agnc_brch_cd          --
             ,  a.bank_cd               --
             ,  a.cdt_tp                --
             ,  a.lnd_dt                --
             ,  a.mrtg_dt               --
             ,  b.ord_mth_no            --
             ,  b.mth_qty               --
             ,  b.mth_pri               --
             ,  b.mth_time              --
             ,  nvl(b.rgt_tax_qty, 0)       sb_rgt_tax_qty
             ,  nvl(b.rgt_tax_calc_yn, 'N') rgt_tax_calc_yn
          from  vn.tso01m00 a, vn.tso01m10 b
         where  a.acnt_no         =  i_acnt_no
           and  a.sub_no          =  i_sub_no
           and  a.mkt_trd_tp     in ('02','04','06')
           and  a.mth_amt         >  0
           and  a.bnh_cd          =  b.bnh_cd
           and  a.ord_no          =  b.ord_no
           and  a.acnt_no         =  b.acnt_no
           and  a.sub_no          =  b.sub_no
           and  (
                   a.stk_ord_tp = '06' 
                or nvl(a.del_yn,'N') = 'N'
           )
           and  (
                  a.stk_ord_tp = '06' 
               or nvl(b.del_yn,'N') = 'N'
           )
         order  by  a.bnh_cd, a.acnt_no, a.sub_no, b.ord_no, b.mth_time
    ) loop

        t_cdt_prof_rt   := 0;
        t_sbst_prof_rt  := 0;
        t_crd_amt       := 0;
        t_cdt_prof_amt  := 0;
        t_sbst_prof_amt := 0;

        t_mth_amt := 0;
        t_cmsn    := 0;

        t_mth_amt := C1.mth_qty * C1.mth_pri;

        /*====================================================================*/
        /* customer account SETL_FRCT_SEQ_NO Create                           */
        /*====================================================================*/
        /* t_setl_frct_seq_no := fcz_auto_num('SS',t_dt);  */
        begin
            select  nvl(max(setl_frct_seq_no),0)+1
              into  t_setl_frct_seq_no
              from  vn.dsc01m10
             where  setl_dt  =  t_setl_dt
               and  acnt_no  =  C1.acnt_no
               and  sub_no   =  C1.sub_no
            ;
        exception
        when others then
            t_err_msg := vn.fxc_get_err_msg('V','9406');
            raise_application_error(-20011,t_err_msg||' ACNT_NO='||C1.acnt_no||'-'||C1.sub_no);
        end;

        begin
            select  nvl(vn.faa_get_acnt_grp_rt_tp(acnt_no,sub_no,'01',vn.vwdate),'01')
                 ,  nvl(prof_level,'00')
                 ,  nvl(acnt_mng_bnh,'000')
                 ,  nvl(agnc_brch,'00')
              into  t_cmsn_tp
                 ,  t_prof_levl
                 ,  t_acnt_mng_bnh
                 ,  t_agnc_brch
              from  vn.aaa01m00
             where  acnt_no  =  C1.acnt_no
               and  sub_no   =  C1.sub_no
            ;
        exception
        when no_data_found then
            t_err_msg := vn.fxc_get_err_msg('V','2006');
            raise_application_error(-20100,t_err_msg||' ACNT_NO='||C1.acnt_no||'-'||C1.sub_no);
        when others then
            t_err_msg := vn.fxc_get_err_msg('V','2006');
            raise_application_error(-20012,t_err_msg||' ACNT_NO='||C1.acnt_no||'-'||C1.sub_no);
        end;

        t_tax_clct_tp := '1';

        /* setl_knd_tp setting ( 01:Normal 02:Odd-lot 03:Big-lot ) */
        if  C1.stk_ord_tp in ('06') and C1.Mkt_Trd_Tp in ('02') then
            t_setl_knd_tp := '03';
        else
            if  C1.mkt_trd_tp in ('01','03','05','04','06') then
                t_setl_knd_tp := '01';
            elsif C1.mkt_trd_tp in ('02') then
                t_setl_knd_tp := '02';
            else
                t_err_msg := vn.fxc_get_err_msg('V','2439');
                raise_application_error(-20100,t_err_msg||' MKT_TRD_TP='||C1.mkt_trd_tp);
            end if;
        end if;

        if  C1.cdt_tp in ('00') then
            t_setl_bank_cd := C1.bank_cd;
            t_lnd_bank_cd  := null;
        elsif  C1.cdt_tp in ('20','30','50') then
            if  C1.sell_buy_tp  =  '1'  then
                begin
                    select  lnd_bank_cd
                         ,  setl_bank_cd
                      into  t_lnd_bank_cd
                         ,  t_setl_bank_cd
                      from  vn.dlm01m00
                     where  lnd_tp       =  C1.cdt_tp
                       and  acnt_no      =  C1.acnt_no
                       and  sub_no     =  C1.sub_no
                       and  lnd_dt       =  C1.lnd_dt
                       and  mth_dt       =  C1.mrtg_dt
                       and  lnd_bank_cd  =  C1.bank_cd
                       and  stk_cd       =  C1.stk_cd
                    ;
                exception
                when others then
                    t_err_msg := vn.fxc_get_err_msg('V','2006');
                    raise_application_error(-20012,t_err_msg||' ACNT_NO='||C1.acnt_no||'-'||C1.sub_no);
                end;
            end if;

            begin
                vn.paa_bank_yn_p(C1.acnt_no, C1.sub_no, ts_cnt_tp);
            exception
            when others then
                t_err_msg := vn.fxc_get_err_msg('V','9009');
                raise_application_error(-20100,t_err_msg||' Acnt_no - '||C1.acnt_no||'-'||C1.sub_no);
            end;

            /*============================================================*/
            /* Calculate prof rate                                        */
            /*============================================================*/
            if  C1.cdt_tp   =  '20'   then
                if  C1.bank_cd  =  '9999' then
                    /* Security Account */
                    if  ts_cnt_tp  <>  'Y01'  then
                        t_setl_bank_cd :=  '9999';
                    end if;
                /* special case : xxxx Bank */
                elsif  C1.bank_cd  =  'xxxx' then
                    t_setl_bank_cd :=  vn.faa_acnt_bank_cd_g(C1.acnt_no,C1.sub_no);
                end if;
            elsif  C1.cdt_tp   =  '30'   then
                if  C1.bank_cd  =  '9999' then
                    /* Security Account */
                    if  ts_cnt_tp  <>  'Y01'  then
                        t_setl_bank_cd :=  '9999';
                    end if;
                end if;
            elsif  C1.cdt_tp   =  '50'   then
                /*No use in VCSC*/
                t_crd_amt        := 0;
                t_cdt_prof_amt   := 0;
                t_sbst_prof_amt  := 0;
                t_setl_bank_cd   := '9999';
                /*
                vn.pds_get_prof_rt ( C1.acnt_no, C1.sub_no, C1.stk_cd
                                   , t_prof_levl, '01'
                                   , C1.stk_tp,   C1.mkt_trd_tp
                                   , C1.stk_ord_dt
                                   , t_cdt_prof_rt
                                   , t_sbst_prof_rt );

                if  C1.sell_buy_tp  =  '2'  then
                    t_setl_bank_cd := C1.bank_cd;
                    t_lnd_bank_cd  := '9999';

                    t_crd_amt        := trunc(t_mth_amt * (1 - t_cdt_prof_rt));
                    t_cdt_prof_amt   := trunc(t_mth_amt * t_cdt_prof_rt);
                    t_sbst_prof_amt  := trunc(t_mth_amt * t_sbst_prof_rt);
                else
                    if  C1.bank_cd  =  '9999' then
                        if  ts_cnt_tp  <>  'Y01'  then
                            t_setl_bank_cd :=  '9999';
                        end if;
                    end if;
                end if;
                */
            end if;
        else
                t_err_msg := vn.fxc_get_err_msg('V','2333');
                raise_application_error(-20100,t_err_msg||' CDT_TP='||C1.cdt_tp);
        end if;

        insert into vn.dsc01m10 (
            SETL_DT        , ACNT_NO        , SUB_NO       , SETL_FRCT_SEQ_NO   ,
            BANK_CD        , ACNT_MNG_BNH   , AGNC_BRCH          ,
            AGNC_BRCH_CD   , SETL_KND_TP    , MKT_TRD_TP         ,
            SB_TP          , MDM_TP         , CMSN_MDM_TP        ,
            STK_TP         , STK_CD         ,
            SB_PRI         , SB_QTY         , SB_AMT             ,
            CMSN_TP        , TAX_CLCT_TP    , APY_CMSN_RT        ,
            SB_CMSN        , SB_TAX         ,
            ADJ_AMT        , ADJ_YN         ,
            CRD_AMT        , CDT_PROF_AMT   , SBST_PROF_AMT      ,
            MTH_DT         , DPO_SETL_DT    , CMSN_SETL_DT       ,
            TAX_SETL_DT    , STK_SETL_DT    ,
            BRCH_CD        , ORD_NO         ,
            ORG_ORD_NO     , FIRST_ORG_ORD_NO, KFX_ACCP_NO       ,
            DPO_SETL_YN    , STK_SETL_YN    , CMSN_SETL_YN       ,
            TAX_SETL_YN    , STK_SETL_FEE_YN, TRD_SEQ_NO     ,
            MRGN_SETL_YN   ,
            CDT_TP         , LND_BANK_CD    ,
            LND_DT         , MRTG_DT        ,
            BNH_CD         , ORD_MTH_NO,
            SB_RGT_TAX_QTY , RGT_TAX_CALC_YN,
            WORK_MN        , WORK_DTM       , WORK_TRM
        )
        values (
            t_setl_dt      , C1.acnt_no     , C1.sub_no       , t_setl_frct_seq_no ,
            t_setl_bank_cd , t_acnt_mng_bnh , t_agnc_brch        ,
            C1.agnc_brch_cd, t_setl_knd_tp  , C1.mkt_trd_tp      ,
            C1.sell_buy_tp , C1.mdm_tp      , C1.cmsn_mdm_tp     ,
            C1.stk_tp      , C1.stk_cd      ,
            C1.mth_pri     , C1.mth_qty     , t_mth_amt          ,
            t_cmsn_tp      , t_tax_clct_tp  , t_cmsn_rt          ,
            t_cmsn         , 0              ,
            t_adj_amt      , 'N'            ,
            t_crd_amt      , t_cdt_prof_amt , t_sbst_prof_amt    ,
            i_dt           , i_dt           ,  i_dt              ,
            i_dt           , i_dt           ,
            C1.bnh_cd      , C1.ord_no      ,
            C1.org_ord_no  , C1.first_org_ord_no, C1.kfx_accp_no ,
            'N'            , 'N'            , 'N'                ,
            'N'            , 'N'            , 0              ,
            'Y'            ,
            C1.cdt_tp      , t_lnd_bank_cd  ,
            C1.lnd_dt      , C1.mrtg_dt     ,
            C1.bnh_cd      , C1.ord_mth_no  ,
            c1.sb_rgt_tax_qty, c1.rgt_tax_calc_yn,
            i_work_mn      , sysdate        , i_work_trm
        );

    end loop;

    /*========================================================================*/
    /* stock SETL_FRCT_SEQ_NO Create                                          */
    /*========================================================================*/
    for C2 in (
        select  t_dt                    stk_ord_dt
             ,  a.bnh_cd                --
             ,  a.ord_no                --
             ,  a.acnt_no               --
             ,  a.sub_no
             ,  a.stk_cd                --
             ,  a.ord_qty               --
             ,  a.ord_pri               --
             ,  a.ord_knd               --
             ,  a.sell_buy_tp           --
             ,  a.mkt_trd_tp            --
             ,  a.stk_ord_tp            --
             ,  a.crrt_cncl_tp          --
             ,  a.stk_tp                --
             ,  a.mdm_tp                --
             ,  vn.fds_get_cmsn_mdm_tp(a.mdm_tp) cmsn_mdm_tp
             ,  a.ord_time              --
             ,  a.ord_veto_cau          --
             ,  a.ord_accp_time         --
             ,  a.org_ord_no            --
             ,  a.first_org_ord_no      --
             ,  a.cncl_qty              --
             ,  a.crrt_qty              --
             ,  a.cncl_cnfm_qty         --
             ,  a.crrt_cnfm_qty         --
             ,  a.org_ord_pri           --
             ,  a.cash_prof_rt          --
             ,  a.frgn_tp               --
             ,  a.sms_yn                --
             ,  a.work_bnh              --
             ,  a.kfx_accp_no           --
             ,  a.sesn_tp               --
             ,  a.agnc_brch_cd          --
             ,  a.bank_cd               --
             ,  a.cdt_tp                --
             ,  a.lnd_dt                --
             ,  a.mrtg_dt               --
             ,  b.ord_mth_no            --
             ,  b.mth_qty               --
             ,  b.mth_pri               --
             ,  b.mth_time              --
             ,  nvl(b.rgt_tax_qty, 0)       sb_rgt_tax_qty
             ,  nvl(b.rgt_tax_calc_yn, 'N') rgt_tax_calc_yn
          from  vn.tso01m00 a, vn.tso01m10 b
         where  a.acnt_no         =  i_acnt_no
           and  a.sub_no      =  i_sub_no
           and  a.mkt_trd_tp     in ('01','03','05')
           and  a.mth_amt         >  0
           and  a.bnh_cd          =  b.bnh_cd
           and  a.ord_no          =  b.ord_no
           and  a.acnt_no         =  b.acnt_no
           and  a.sub_no      =  b.sub_no
           and  (
                   a.stk_ord_tp = '06' 
                or nvl(a.del_yn,'N') = 'N'
           )
           and  (
                  a.stk_ord_tp = '06' 
               or nvl(b.del_yn,'N') = 'N'
           )
         order  by  a.bnh_cd, a.acnt_no, a.sub_no, b.ord_no, b.mth_time
    ) loop

        t_cdt_prof_rt   := 0;
        t_sbst_prof_rt  := 0;
        t_crd_amt       := 0;
        t_cdt_prof_amt  := 0;
        t_sbst_prof_amt := 0;

        t_mth_amt := 0;
        t_cmsn    := 0;

        t_mth_amt := C2.mth_qty * C2.mth_pri;

        /*====================================================================*/
        /* SETL_FRCT_SEQ_NO Create                                            */
        /*====================================================================*/
        /* t_setl_frct_seq_no := fcz_auto_num('SS',t_dt);  */
        if  C2.stk_tp  in  ('20') then
            begin
                select  nvl(max(setl_frct_seq_no),0)+1
                  into  t_setl_frct_seq_no
                  from  vn.dsc01m10
                 where  setl_dt  =  t_setl_big_dt
                   and  acnt_no  =  C2.acnt_no
                   and  sub_no   =  C2.sub_no
                ;
            exception when others then
                t_err_msg := vn.fxc_get_err_msg('V','9406');
                raise_application_error(-20021,t_err_msg||' ACNT_NO='||C2.acnt_no||'-'||C2.sub_no);
            end;
        else
            begin
                select  nvl(max(setl_frct_seq_no),0)+1
                  into  t_setl_frct_seq_no
                  from  vn.dsc01m10
                 where  setl_dt  =  t_setl_dt
                   and  acnt_no  =  C2.acnt_no
                   and  sub_no   =  C2.sub_no
                ;
            exception when others then
                t_err_msg := vn.fxc_get_err_msg('V','9406');
                raise_application_error(-20021,t_err_msg||' ACNT_NO='||C2.acnt_no||'-'||C2.sub_no);
            end;
        end if;


        begin
            select  nvl(vn.faa_get_acnt_grp_rt_tp(acnt_no,sub_no,'01',vn.vwdate),'01')
                 ,  nvl(prof_level,'00')
                 ,  nvl(acnt_mng_bnh,'000')
                 ,  nvl(agnc_brch,'00')
              into  t_cmsn_tp
                 ,  t_prof_levl
                 ,  t_acnt_mng_bnh
                 ,  t_agnc_brch
              from  vn.aaa01m00
             where  acnt_no  =  C2.acnt_no
               and  sub_no   =  C2.sub_no
            ;
        exception
        when no_data_found then
            t_err_msg := vn.fxc_get_err_msg('V','2006');
            raise_application_error(-20100,t_err_msg||' ACNT_NO='||C2.acnt_no||'-'||C2.sub_no);
        when others then
            t_err_msg := vn.fxc_get_err_msg('V','2006');
            raise_application_error(-20022,t_err_msg||' ACNT_NO='||C2.acnt_no||'-'||C2.sub_no);
        end;

        t_tax_clct_tp := '1';

        /* setl_knd_tp setting ( 01:Normal 02:Odd-lot 03:Big-lot ) */
        if  C2.stk_ord_tp in ('06') then
            t_setl_knd_tp := '03';
        else
            if  C2.mkt_trd_tp in ('01','03','05') then
                t_setl_knd_tp := '01';
            elsif C2.mkt_trd_tp in ('02','04','06') then
                t_setl_knd_tp := '02';
            else
                t_err_msg := vn.fxc_get_err_msg('V','2439');
                raise_application_error(-20100,t_err_msg||' MKT_TRD_TP='||C2.mkt_trd_tp);
            end if;
        end if;

        if  C2.cdt_tp in ('00') then
            t_setl_bank_cd := C2.bank_cd;
            t_lnd_bank_cd  := null;
        elsif  C2.cdt_tp in ('20','30','50') then
            if  C2.sell_buy_tp  =  '1'  then
                begin
                    select  lnd_bank_cd
                         ,  setl_bank_cd
                      into  t_lnd_bank_cd
                         ,  t_setl_bank_cd
                      from  vn.dlm01m00
                     where  lnd_tp       =  C2.cdt_tp
                       and  acnt_no      =  C2.acnt_no
                       and  sub_no       =  C2.sub_no
                       and  lnd_dt       =  C2.lnd_dt
                       and  mth_dt       =  C2.mrtg_dt
                       and  lnd_bank_cd  =  C2.bank_cd
                       and  stk_cd       =  C2.stk_cd
                    ;
                exception
                when others then
                    t_err_msg := vn.fxc_get_err_msg('V','2006');
                    raise_application_error(-20012,t_err_msg||' ACNT_NO='||C2.acnt_no||'-'||C2.sub_no);
                end;
            end if;

            begin
                vn.paa_bank_yn_p(C2.acnt_no, C2.sub_no, ts_cnt_tp);
            exception
            when others then
                t_err_msg := vn.fxc_get_err_msg('V','9009');
                raise_application_error(-20100,t_err_msg||' Acnt_no - '||C2.acnt_no||'-'||C2.sub_no);
            end;

            /*============================================================*/
            /* Calculate prof rate                                        */
            /*============================================================*/
            if  C2.cdt_tp   =  '20'   then
                if  C2.bank_cd  =  '9999' then
                    /* Security Account */
                    if  ts_cnt_tp  <>  'Y01'  then
                        t_setl_bank_cd :=  '9999';
                    end if;
                /* special case : xxxx Bank */
                elsif  C2.bank_cd  =  'xxxx' then
                    t_setl_bank_cd :=  vn.faa_acnt_bank_cd_g(C2.acnt_no,C2.sub_no);
                end if;
            elsif  C2.cdt_tp   =  '30'   then
                if  C2.bank_cd  =  '9999' then
                    /* Security Account */
                    if  ts_cnt_tp  <>  'Y01'  then
                        t_setl_bank_cd :=  '9999';
                    end if;
                end if;
            elsif  C2.cdt_tp   =  '50'   then
                /*No use in VCSC*/
        t_crd_amt        := 0;
                t_cdt_prof_amt   := 0;
                t_sbst_prof_amt  := 0;
                t_setl_bank_cd   := '9999';
        /*
                vn.pds_get_prof_rt ( C1.acnt_no, C1.sub_no, C1.stk_cd
                                   , t_prof_levl, '01'
                                   , C1.stk_tp,   C1.mkt_trd_tp
                                   , C1.stk_ord_dt
                                   , t_cdt_prof_rt
                                   , t_sbst_prof_rt );

                if  C1.sell_buy_tp  =  '2'  then
                    t_setl_bank_cd := C1.bank_cd;
                    t_lnd_bank_cd  := '9999';

                    t_crd_amt        := trunc(t_mth_amt * (1 - t_cdt_prof_rt));
                    t_cdt_prof_amt   := trunc(t_mth_amt * t_cdt_prof_rt);
                    t_sbst_prof_amt  := trunc(t_mth_amt * t_sbst_prof_rt);
                else
                    if  C1.bank_cd  =  '9999' then
                        if  ts_cnt_tp  <>  'Y01'  then
                            t_setl_bank_cd :=  '9999';
                        end if;
                    end if;
                end if;
                */
            end if;
        else
                t_err_msg := vn.fxc_get_err_msg('V','2333');
                raise_application_error(-20100,t_err_msg||' CDT_TP='||C2.cdt_tp);
        end if;

        /* big-order settle-date : T+1 */
        if  C2.stk_tp  in  ('20') then
            insert into vn.dsc01m10 (
                SETL_DT        , ACNT_NO        , SUB_NO       , SETL_FRCT_SEQ_NO   ,
                BANK_CD        , ACNT_MNG_BNH   , AGNC_BRCH          ,
                AGNC_BRCH_CD   , SETL_KND_TP    , MKT_TRD_TP         ,
                SB_TP          , MDM_TP         , CMSN_MDM_TP        ,
                STK_TP         , STK_CD         ,
                SB_PRI         , SB_QTY         , SB_AMT             ,
                CMSN_TP        , TAX_CLCT_TP    , APY_CMSN_RT        ,
                SB_CMSN        , SB_TAX         ,
                ADJ_AMT        , ADJ_YN         ,
                CRD_AMT        , CDT_PROF_AMT   , SBST_PROF_AMT      ,
                MTH_DT         , DPO_SETL_DT    , CMSN_SETL_DT       ,
                TAX_SETL_DT    , STK_SETL_DT    ,
                BRCH_CD        , ORD_NO         ,
                ORG_ORD_NO     , FIRST_ORG_ORD_NO, KFX_ACCP_NO       ,
                DPO_SETL_YN    , STK_SETL_YN    , CMSN_SETL_YN       ,
                TAX_SETL_YN    , STK_SETL_FEE_YN, TRD_SEQ_NO     ,
                MRGN_SETL_YN   ,
                CDT_TP         , LND_BANK_CD    ,
                LND_DT         , MRTG_DT        ,
                BNH_CD         , ORD_MTH_NO,
                SB_RGT_TAX_QTY , RGT_TAX_CALC_YN,
                WORK_MN        , WORK_DTM       , WORK_TRM
            )
            values (
                t_setl_big_dt  , C2.acnt_no     , C2.sub_no       , t_setl_frct_seq_no ,
                t_setl_bank_cd , t_acnt_mng_bnh , t_agnc_brch        ,
                C2.agnc_brch_cd, t_setl_knd_tp  , C2.mkt_trd_tp      ,
                C2.sell_buy_tp , C2.mdm_tp      , C2.cmsn_mdm_tp     ,
                C2.stk_tp      , C2.stk_cd      ,
                C2.mth_pri     , C2.mth_qty     , t_mth_amt          ,
                t_cmsn_tp      , t_tax_clct_tp  , t_cmsn_rt          ,
                t_cmsn         , 0              ,
                t_adj_amt      , 'N'            ,
                t_crd_amt      , t_cdt_prof_amt , t_sbst_prof_amt    ,
                i_dt           , i_dt           , i_dt               ,
                i_dt           , i_dt           ,
                C2.bnh_cd      , C2.ord_no      ,
                C2.org_ord_no  , C2.first_org_ord_no, C2.kfx_accp_no ,
                'N'            , 'N'            , 'N'                ,
                'N'            , 'N'            , 0              ,
                DECODE(C2.sell_buy_tp,'1','N','Y'),
                C2.cdt_tp      , t_lnd_bank_cd  ,
                C2.lnd_dt      , C2.mrtg_dt     ,
                C2.bnh_cd      , C2.ord_mth_no  ,
                C2.sb_rgt_tax_qty, C2.rgt_tax_calc_yn,
                i_work_mn      , sysdate        , i_work_trm
            );
        else
            insert into vn.dsc01m10 (
                SETL_DT        , ACNT_NO        , SUB_NO       , SETL_FRCT_SEQ_NO   ,
                BANK_CD        , ACNT_MNG_BNH   , AGNC_BRCH          ,
                AGNC_BRCH_CD   , SETL_KND_TP    , MKT_TRD_TP         ,
                SB_TP          , MDM_TP         , CMSN_MDM_TP        ,
                STK_TP         , STK_CD         ,
                SB_PRI         , SB_QTY         , SB_AMT             ,
                CMSN_TP        , TAX_CLCT_TP    , APY_CMSN_RT        ,
                SB_CMSN        , SB_TAX         ,
                ADJ_AMT        , ADJ_YN         ,
                CRD_AMT        , CDT_PROF_AMT   , SBST_PROF_AMT      ,
                MTH_DT         , DPO_SETL_DT    , CMSN_SETL_DT       ,
                TAX_SETL_DT    , STK_SETL_DT    ,
                BRCH_CD        , ORD_NO         ,
                ORG_ORD_NO     , FIRST_ORG_ORD_NO, KFX_ACCP_NO       ,
                DPO_SETL_YN    , STK_SETL_YN    , CMSN_SETL_YN       ,
                TAX_SETL_YN    , STK_SETL_FEE_YN, TRD_SEQ_NO     ,
                MRGN_SETL_YN   ,
                CDT_TP         , LND_BANK_CD    ,
                LND_DT         , MRTG_DT        ,
                BNH_CD         , ORD_MTH_NO,
                SB_RGT_TAX_QTY , RGT_TAX_CALC_YN,
                WORK_MN        , WORK_DTM       , WORK_TRM
            )
            values (
                t_setl_dt      , C2.acnt_no     , C2.sub_no       , t_setl_frct_seq_no ,
                t_setl_bank_cd , t_acnt_mng_bnh , t_agnc_brch        ,
                C2.agnc_brch_cd, t_setl_knd_tp  , C2.mkt_trd_tp      ,
                C2.sell_buy_tp , C2.mdm_tp      , C2.cmsn_mdm_tp     ,
                C2.stk_tp      , C2.stk_cd      ,
                C2.mth_pri     , C2.mth_qty     , t_mth_amt          ,
                t_cmsn_tp      , t_tax_clct_tp  , t_cmsn_rt          ,
                t_cmsn         , 0              ,
                t_adj_amt      , 'N'            ,
                t_crd_amt      , t_cdt_prof_amt , t_sbst_prof_amt    ,
                i_dt           , i_dt           , i_dt               ,
                i_dt           , i_dt           ,
                C2.bnh_cd      , C2.ord_no      ,
                C2.org_ord_no  , C2.first_org_ord_no, C2.kfx_accp_no ,
                'N'            , 'N'            , 'N'                ,
                'N'            , 'N'            , 0              ,
                DECODE(C2.sell_buy_tp,'1','N','Y'),
                C2.cdt_tp      , t_lnd_bank_cd  ,
                C2.lnd_dt      , C2.mrtg_dt     ,
                C2.bnh_cd      , C2.ord_mth_no  ,
                C2.sb_rgt_tax_qty, C2.rgt_tax_calc_yn,
                i_work_mn      , sysdate        , i_work_trm
            );
        end if;

    end loop;

    /*============================================================================*/
    /* ( Calculateion Fee)                                                        */
    /*============================================================================*/
    for C3 in (
        select  mth_dt
             ,  acnt_no                         --
             ,  sub_no                         --
             ,  brch_cd                         --
             ,  ord_no                          --
             ,  nvl(sum(sb_amt),0)  sb_amt_sum  --
          from  vn.dsc01m10
         where  mth_dt      =  i_dt
           and  acnt_no     =  i_acnt_no
           and  sub_no     =  i_sub_no
         group  by  mth_dt, acnt_no, sub_no, brch_cd, ord_no
         order  by  mth_dt, acnt_no, sub_no, brch_cd, ord_no
    ) loop

        t_cmsn_rt  := 0;
        t_cmsn_amt := 0;

        /* The commission rate of Company's account is '0' */
        if vn.fcw_chk_pty_acnt_yn(C3.acnt_no, C3.sub_no) = 'Y' then
            t_cmsn_setl_yn := 'Y';
        else
            t_cmsn_setl_yn  := 'N';
            t4_stk_cd       := null;
            t4_sb_tp        := null;
            t4_cmsn_tp      := null;
            t4_stk_tp       := null;
            t4_setl_knd_tp  := null;
            t4_cmsn_mdm_tp  := null;

            for c4 in (
                select  stk_cd
                     ,  sb_tp
                     ,  cmsn_tp
                     ,  stk_tp
                     ,  mkt_trd_tp
                     ,  setl_knd_tp
                     ,  cmsn_mdm_tp
                  from  vn.dsc01m10
                 where  mth_dt   =  C3.mth_dt
                   and  acnt_no  =  C3.acnt_no
                   and  sub_no   =  C3.sub_no
                   and  brch_cd  =  C3.brch_cd
                   and  ord_no   =  C3.ord_no
                   and  rownum   =  1
            ) loop
                t4_stk_cd      :=  C4.stk_cd;
                t4_sb_tp       :=  C4.sb_tp;
                t4_cmsn_tp     :=  C4.cmsn_tp;
                t4_stk_tp      :=  C4.stk_tp;
                t4_mkt_trd_tp  :=  C4.mkt_trd_tp;
                t4_setl_knd_tp :=  C4.setl_knd_tp;
                t4_cmsn_mdm_tp :=  C4.cmsn_mdm_tp;
                t4_stk_mkt_tp  :=  vn.fss_get_stk_mkt(C4.stk_cd);
            end loop;

            vn.pds_get_cmsn_rt (C3.acnt_no     ,  C3.sub_no       ,
                                t4_stk_cd      ,  t4_sb_tp        ,
                                t4_cmsn_tp     ,  t4_stk_tp       ,
                                t4_mkt_trd_tp  ,  /* => mkt_trd_tp */
                                t4_cmsn_mdm_tp ,  t4_setl_knd_tp  ,
                                '00'           ,  /* => stk_ord_tp */
                                C3.mth_dt      ,  C3.sb_amt_sum  ,
                                t_cmsn_rt      ,  t_cmsn_amt     );

        end if;

        --  commission UPDATE
        /* ??? ??? */
        if  t4_setl_knd_tp  =  '02'  then
            t_cmsn_rt  :=  0;
        end if;

        update  vn.dsc01m10
           set  apy_cmsn_rt  =  t_cmsn_rt
             ,  sb_cmsn      =  trunc(sb_amt * t_cmsn_rt,0)
             ,  adj_amt      =  decode(sb_tp, '1' , sb_amt - trunc(sb_amt * t_cmsn_rt,0)
                                                  , sb_amt + trunc(sb_amt * t_cmsn_rt,0)
                                       )
             ,  adj_yn       =  'Y'
             ,  cmsn_setl_yn =  t_cmsn_setl_yn
         where  mth_dt       =  C3.mth_dt
           and  acnt_no      =  C3.acnt_no
           and  sub_no       =  C3.sub_no
           and  ord_no       =  C3.ord_no
        ;

    end loop;

    /*============================================================================*/
    /* ( Calculation tax)                                                        */
    /*============================================================================*/
    for C5 in (
        select  setl_dt               setl_dt           --
             ,  mth_dt                mth_dt            --
             ,  acnt_no               acnt_no           --
             ,  sub_no          sub_no
             ,  setl_frct_seq_no      setl_frct_seq_no  --
             ,  sb_tp                 sb_tp             --
             ,  setl_knd_tp           setl_knd_tp       --
             ,  nvl(sb_qty,0)         sb_qty            --
             ,  nvl(sb_amt,0)         sb_amt            --
             ,  nvl(sb_cmsn,0)        sb_cmsn           --
             ,  nvl(sb_tax,0)         sb_tax            --
             ,  nvl(adj_amt,0)        adj_amt           --
             ,  nvl(tax_clct_tp,'1')  tax_clct_tp           --
          from  vn.dsc01m10
         where  mth_dt      =  i_dt
           and  acnt_no     =  i_acnt_no
           and  sub_no    =  i_sub_no
           and  sb_tp       =  '1'
         order  by  setl_dt, acnt_no, sub_no, setl_frct_seq_no
    ) loop

        t_acnt_no  := C5.acnt_no;
        t_sub_no   := C5.sub_no;

        t_sb_tax_rt  := 0;
        t_sb_tax     := 0;

        /* t_grp_tp  (1:individual accout 2:corporation account) */
        /* t_frgn_tp (1:native accout     2:foreigner)           */
        t_grp_tp := vn.faa_acnt_grp_tp_g(t_acnt_no,t_sub_no);
        t_frgn_tp := vn.faa_acnt_frgn_tp_g(t_acnt_no,t_sub_no);

        /* -- get calc_tax_yn from aaa01m00 --*/
        select NVL(calc_tax_yn,'Y') into t_calc_tax_yn
          from vn.aaa01m00
        where acnt_no = t_acnt_no
          and sub_no  = t_sub_no;

        /* The tax rate                       */
        /* calculate deal tax when selling .. */
        if  t_grp_tp = '1'  then

            if  C5.tax_clct_tp = '1'  then
                t_tax1 := 'ICT';

                t_sb_tax_rt   := vn.fds_get_apy_rt(t_tax1, C5.mth_dt);
                t_sb_tax      := round(C5.sb_amt
                               * vn.fds_get_apy_rt(t_tax1, C5.mth_dt));

                /* t_sb_tax      := 0;*/
                /*
                if  C5.setl_knd_tp  =  '02'  then
                    t_sb_tax_rt  :=  0;
                    t_sb_tax     :=  0;
                end if;
                */

                if C5.acnt_no = 'CTBFCA2233' then
                    t_sb_tax := 0;
                end if;
               /*-- Dang tai khoan khong tinh thue --*/
                if t_calc_tax_yn = 'N' then
                    t_sb_tax := 0;
                end if;

                /* tax UPDATE */
                /* round vnd  */
                update  vn.dsc01m10
                   set  sb_tax            =  t_sb_tax
                     ,  adj_amt           =  adj_amt - t_sb_tax
                 where  setl_dt           =  C5.setl_dt
                   and  acnt_no           =  C5.acnt_no
                   and  sub_no        =  C5.sub_no
                   and  setl_frct_seq_no  =  C5.setl_frct_seq_no
                ;

            end if;
        elsif  t_grp_tp  = '2'  then
           if  t_frgn_tp = '2'  then
                t_tax1 := 'FDT';

                t_sb_tax_rt   := vn.fds_get_apy_rt(t_tax1, C5.mth_dt);
                t_sb_tax      := round(C5.sb_amt
                               * vn.fds_get_apy_rt(t_tax1, C5.mth_dt));

                /*
                if  C5.setl_knd_tp  =  '02'  then
                    t_sb_tax_rt  :=  0;
                    t_sb_tax     :=  0;
                end if;
                */

                if C5.acnt_no = 'CTBFCA2233' then
                    t_sb_tax := 0;
                end if;
               /*-- Dang tai khoan khong tinh thue --*/
                if t_calc_tax_yn = 'N' then
                    t_sb_tax := 0;
                end if;

                /* tax UPDATE */
                /* round vnd  */
                update  vn.dsc01m10
                   set  sb_tax            =  t_sb_tax
                     ,  adj_amt           =  adj_amt - t_sb_tax
                 where  setl_dt           =  C5.setl_dt
                   and  acnt_no           =  C5.acnt_no
                   and  sub_no            =  C5.sub_no
                   and  setl_frct_seq_no  =  C5.setl_frct_seq_no
                ;
            end if;
        else
            t_sb_tax_rt  := 0;
            t_sb_tax     := 0;
        end if;

    end loop;

    /*============================================================================*/
    /* ( Calculation stock fee)                                                        */
    /*============================================================================*/
    t6_fee_rt_02 := 0;
    t6_fee_rt    := 0;
    t6_fee_mn    := 0;
    t6_fee_rt_02 := vn.fds_get_apy_rt('SSF', i_dt); -- ti le phi tung max
    t6_fee_mn    := vn.fds_get_apy_rt('SSM', i_dt); -- phi max

    FOR C6 IN (
        SELECT ROWID arowid,
              stk_cd,
              setl_dt setl_dt,
              mth_dt mth_dt,
              acnt_no acnt_no,
              sub_no sub_no,
              setl_frct_seq_no setl_frct_seq_no,
              sb_tp sb_tp,
              setl_knd_tp setl_knd_tp,
              nvl(sb_qty, 0) sb_qty,
              nvl(sb_amt, 0) sb_amt,
              nvl(sb_cmsn, 0) sb_cmsn,
              nvl(sb_tax, 0) sb_tax,
              nvl(adj_amt, 0) adj_amt,
              nvl(tax_clct_tp, '1') tax_clct_tp,
              row_number() over(partition by mth_dt, acnt_no, sub_no, sb_tp, stk_cd order by mth_dt, acnt_no, sub_no, sb_tp, stk_cd,setl_frct_seq_no) rnk
         FROM vn.dsc01m10
        WHERE mth_dt = i_dt
          AND acnt_no LIKE i_acnt_no
          AND sub_no LIKE i_sub_no
          AND sb_tp = '1'
        ORDER BY mth_dt,
                 setl_dt,
                 stk_cd,
                 acnt_no,
                 sub_no,
                 setl_frct_seq_no,
                 rnk
    )LOOP

        BEGIN
            SELECT setl_tp
              INTO t6_setl_tp
              FROM vn.aaa01m00
             WHERE acnt_no = C6.acnt_no
               AND sub_no = C6.sub_no;
        EXCEPTION
            WHEN no_data_found THEN
                t_err_msg := vn.fxc_get_err_msg('V', '2006');
                raise_application_error(-20100
                                       ,t_err_msg || ' ACNT_NO=' ||
                                        C6.acnt_no || '-' || C6.sub_no);
            WHEN OTHERS THEN
                t_err_msg := vn.fxc_get_err_msg('V', '9002');
                raise_application_error(-20011
                                       ,t_err_msg || ' acnt_no=' ||
                                        C6.acnt_no || '-' || C6.sub_no);
        END;

        IF C6.sb_tp = '1' AND t6_setl_tp = '1' THEN
            t6_fee       := 0;
            t6_fee_rt    := t6_fee_rt_02;
            t6_fee_rt_01 := 0;

            /* round */
            t6_fee := trunc(C6.sb_qty * t6_fee_rt, 0);
            IF C6.rnk = 1 THEN
                t6_final_fee := 0;
                t6_total_fee := 0;
                t6_available_fee := 0;
            END IF;

            t6_available_fee := greatest(t6_fee_mn - t6_total_fee, 0);
            t6_total_fee := t6_total_fee + t6_fee;

            t6_final_fee := LEAST(t6_available_fee, t6_fee);

			/*NHSV-1127*/
			if vn.fcw_chk_pty_acnt_yn(C6.acnt_no, C6.sub_no) = 'Y' then
				t6_final_fee := 0;
				t6_fee_rt := 0;
			end if;
            /* UPDATE    */
            UPDATE vn.dsc01m10
               SET sb_fee     = t6_final_fee,
                   adj_amt    = adj_amt - t6_final_fee,
                   apy_fee_rt = t6_fee_rt,
                   stk_setl_fee_yn = 'N'
             WHERE setl_dt = C6.setl_dt
               AND acnt_no = C6.acnt_no
               AND sub_no = C6.sub_no
               AND setl_frct_seq_no = C6.setl_frct_seq_no;

        END IF;

    END LOOP;

    /*============================================================================*/
    /* (Right tax calculation)                                                    */
    /*============================================================================*/
    BEGIN
        vn.pds_pre_calc_rgt_tax(
            i_dt,
            i_acnt_no,
            i_sub_no,
            '%',            -- stk_cd
            i_work_mn,
            i_work_trm,
            t_rgt_tax_cnt
        );
    EXCEPTION
        WHEN OTHERS THEN
            t_err_msg := vn.fxc_get_err_msg('V', '9812');
            raise_application_error(-20011, t_err_msg);
    END;

end pds_setl_cr_pre_cmsn;
/

