create procedure pts_acnt_prof_g
(
	i_acnt_no                   IN     VARCHAR2,
	i_sub_no					IN	   VARCHAR2,
	i_bank_cd                   IN     VARCHAR2,
    o_tot_prof_rel_amt          IN OUT NUMBER,
    o_tot_all_prof_rel_amt      IN OUT NUMBER,
    o_tot_prof_cdt_amt          IN OUT NUMBER,
    o_tot_all_prof_cdt_amt      IN OUT NUMBER,
    o_tot_prof_vit_amt          IN OUT NUMBER,
    o_tot_all_prof_vit_amt      IN OUT NUMBER,
    o_tot_all_reuse_dpo         IN OUT NUMBER,
    o_tot_all_sbst_diff_amt     IN OUT NUMBER,
    o_tot_ts_sbst_diff_amt      IN OUT NUMBER,
    o_tot_ts_expt_sbst_amt      IN OUT NUMBER,
    P_ErrCode              IN OUT NUMBER,
    P_ErrMsg               IN OUT VARCHAR2
) as

    t_acnt_no   VARCHAR2(10) := NULL;
    t_sub_no	VARCHAR2(2)	 := NULL;
    t_bank_cd   VARCHAR2(4) := NULL;
begin
    o_tot_prof_rel_amt          := 0;
    o_tot_prof_vit_amt          := 0;
    o_tot_all_prof_vit_amt      := 0;
    o_tot_all_prof_rel_amt        := 0;
    o_tot_prof_cdt_amt          := 0;
    o_tot_all_prof_cdt_amt      := 0;
    o_tot_all_reuse_dpo         := 0;
    o_tot_all_sbst_diff_amt     := 0;
    o_tot_ts_sbst_diff_amt      := 0;
    o_tot_ts_expt_sbst_amt		:= 0;
    P_ErrCode                   := 0;
    P_ErrMsg                    := ' ';

  vn.pxc_log_write('pts_acnt_prof_g',' i_acnt_no['||i_acnt_no||'] i_sub_no['|| i_sub_no || '] i_bank_cd['|| i_bank_cd ||']');

    t_bank_cd := i_bank_cd;


    begin
        select acnt_no,
        	   sub_no
        into t_acnt_no, t_sub_no
        from tso02m00
        where acnt_no = i_acnt_no
            and sub_no like trim ( i_sub_no )
            and bank_cd like t_bank_cd
            and rownum = 1
        ;
        EXCEPTION
        when  NO_DATA_FOUND  then
        		    P_ErrCode	 := 1403;
        		    P_ErrMsg  :=  'error - ' ||  to_char(sqlcode) ;
                when  OTHERS  then
                    P_ErrCode	 := sqlcode;
                    P_ErrMsg  :=  'error - ' ||  to_char(sqlcode) ;
                    raise_application_error (-20100, P_ErrMsg);

    end;
    begin
    	SELECT  SUM(GREATEST(TD_CASH_PROF_AMT  + PD_CASH_PROF_AMT  + PPD_CASH_PROF_AMT  + PPPD_CASH_PROF_AMT , 0)),
    	        SUM(GREATEST(TD_CASH_PROF_GST_AMT  + PD_CASH_PROF_GST_AMT  + PPD_CASH_PROF_GST_AMT  + PPPD_CASH_PROF_GST_AMT , 0)),
    	        SUM(GREATEST(TD_CDT_PROF_AMT  + PD_CDT_PROF_AMT  + PPD_CDT_PROF_AMT  + PPPD_CDT_PROF_AMT , 0)),
    	        SUM(GREATEST(EXPT_SBST_AMT , 0))
          INTO  o_tot_prof_rel_amt,
                o_tot_prof_vit_amt,
                o_tot_prof_cdt_amt,
                o_tot_ts_expt_sbst_amt
          FROM VN.TSO02M00
          WHERE acnt_no = i_acnt_no
            and	sub_no like trim ( i_sub_no )
            and bank_cd like t_bank_cd

            ;

        EXCEPTION
               when  NO_DATA_FOUND  then
        		    P_ErrCode	 := 1403;
        		    P_ErrMsg  :=  'error - ' ||  to_char(sqlcode) ;
                when  OTHERS  then
                    P_ErrCode	 := sqlcode;
                    P_ErrMsg  :=  'error - ' ||  to_char(sqlcode) ;
                raise_application_error (-20100, P_ErrMsg);

    end;

    begin
    	SELECT  SUM(GREATEST(TD_CASH_PROF_AMT  + PD_CASH_PROF_AMT  + PPD_CASH_PROF_AMT  + PPPD_CASH_PROF_AMT , 0)),
    	        SUM(GREATEST(TD_CASH_PROF_GST_AMT  + PD_CASH_PROF_GST_AMT  + PPD_CASH_PROF_GST_AMT + PPPD_CASH_PROF_GST_AMT, 0)),
    	        SUM(GREATEST(TD_CDT_PROF_AMT  + PD_CDT_PROF_AMT  + PPD_CDT_PROF_AMT  + PPPD_CDT_PROF_AMT , 0)),
    	        SUM(GREATEST(REUSE_DPO , 0)),
    	        SUM(TD_MGN_BUY_DIFF_AMT  + PD_MGN_BUY_DIFF_AMT  + PPD_MGN_BUY_DIFF_AMT  + PPPD_MGN_BUY_DIFF_AMT ) - SUM(TD_MGN_SELL_DIFF_AMT  + PD_MGN_SELL_DIFF_AMT  + PPD_MGN_SELL_DIFF_AMT  + PPPD_MGN_SELL_DIFF_AMT ),
    	        SUM(PD_MGN_BUY_DIFF_AMT  + PPD_MGN_BUY_DIFF_AMT  + PPPD_MGN_BUY_DIFF_AMT ) - SUM(TD_MGN_SELL_DIFF_AMT  + PD_MGN_SELL_DIFF_AMT  + PPD_MGN_SELL_DIFF_AMT  + PPPD_MGN_SELL_DIFF_AMT )
    	  INTO  o_tot_all_prof_rel_amt,
                o_tot_all_prof_vit_amt,
                o_tot_all_prof_cdt_amt,
                o_tot_all_reuse_dpo,
                o_tot_all_sbst_diff_amt,
                o_tot_ts_sbst_diff_amt
          FROM VN.TSO02M00
          WHERE acnt_no = i_acnt_no
            AND	sub_no like trim ( i_sub_no )
            ;

        EXCEPTION
               when  NO_DATA_FOUND  then
        		    P_ErrCode	 := 1403;
        		    P_ErrMsg  :=  'error - ' ||  to_char(sqlcode) ;
                when  OTHERS  then
                    P_ErrCode	 := sqlcode;
                    P_ErrMsg  :=  'error - ' ||  to_char(sqlcode) ;
                    raise_application_error (-20100, P_ErrMsg);

    end;

end pts_acnt_prof_g;
/

