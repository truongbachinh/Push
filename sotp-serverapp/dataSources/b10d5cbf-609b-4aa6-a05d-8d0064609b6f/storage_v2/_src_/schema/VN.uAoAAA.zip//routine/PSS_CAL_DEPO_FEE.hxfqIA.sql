create procedure pss_cal_depo_fee(i_sec_cd   in varchar2,
                                             i_proc_dt  in varchar2,
                                             i_acnt_no  in varchar2,
                                             i_sub_no   in varchar2,
                                             i_stk_cd   in varchar2,
                                             i_from_dt  in varchar2,
                                             i_to_dt    in varchar2,
                                             i_work_mn  in varchar2,
                                             i_work_trm in varchar2,
                                             o_proc_cnt out number) is

  vn_count            number := 0;
  vn_tot_out_blk_fee  number := 0;
  vn_total_fee_blk    number := 0;
  vn_mak_strt_dt      varchar2(8);
  vn_mak_end_dt       varchar2(8); -- EESF04
  vn_lastworkingday   date;
  vn_lastworkingday_chr varchar2(8); -- NHSV-1254
  vn_with_freq        varchar2(1); -- EESF04
  vn_cal_freq         varchar2(1); -- EESF04
  vn_from_dt_2        varchar2(8); -- EESF04
  vn_to_dt_2          varchar2(8); -- EESF04
  vn_firstday         varchar2(8); -- EESF04
  vn_dayafterprevious varchar2(8); -- EESF04
  /* *********************** Log changes *************************
  09-May-2018 vnjvthangnm Initilization
  30-Jul-2018 vnjvhuedt update
  03-Oct-2018 vnjvthangnm NH79, NH80
  15-Nov-2018 vnjvthangnm EESF04 Bo sung tham so tinh,thu PLK
  03-Sep-2020 vnjvthangnm NHSV-1254
  ************************************************************* */

begin
  o_proc_cnt := 0;
  /* insert ssb07m10 */
  vn.pxc_log_write('pss_cal_depo_fee',
                   'start' || '[' || i_proc_dt || ',' || i_acnt_no || ',' ||
                   i_sub_no || ',' || i_stk_cd || ',' || i_from_dt || ',' ||
                   i_to_dt || ']');

  /* Get last day of month */
  select last_day(to_date(i_from_dt, 'YYYYMMDD'))
    into vn_lastworkingday
    from dual;

  /* Get the last working day of this month */
  while vn.fxc_holi_ck(vn_lastworkingday) <> 0 loop
    vn_lastworkingday := vn_lastworkingday - 1;
  end loop;

  vn_lastworkingday_chr := to_char(vn_lastworkingday, 'YYYYMMDD');

    /* Set ngay lam viec cuoi thang la 20200925  de test */
  --vn_lastworkingday_chr := '20200925';
  --

  vn.pxc_log_write('pss_cal_depo_fee',
                   'The last working day of this month is: ' || '[' ||
                   vn_lastworkingday_chr || ']');

  /* Get withdraw frequence */
  select col_cd_tp
    into vn_with_freq
    from vn.xcc01c02
   where col_cd = 'depo_with_freq';

  /* Get calculation frequence */
  select col_cd_tp
    into vn_cal_freq
    from vn.xcc01c02
   where col_cd = 'depo_cal_freq';

  /* Get exactly end date */
  if i_proc_dt < vn_lastworkingday_chr then
    if i_from_dt = i_to_dt then
      vn_to_dt_2 := i_to_dt;
    else
      vn_to_dt_2 := vn.vwdate;
    end if;
  else
    vn_to_dt_2 := to_char(last_day(to_date(i_from_dt, 'YYYYMMDD')),
                          'YYYYMMDD');
  end if;

  /* Get the Day after Previous working day, First day of the month */
  select to_char(vn.fxc_vorderdt_g(to_date(i_from_dt, 'YYYYMMDD'), -1) + 1),
         to_char(trunc(to_date(i_from_dt, 'YYYYMMDD'), 'MM'), 'YYYYMMDD')
    into vn_dayafterprevious, vn_firstday
    from dual;

  /* When calculate fee daily and the day before calculate day is holiday*/
  if vn_cal_freq = 'D' and i_work_mn in ('DAILY', 'SYSTEM') then
    if i_from_dt = vn_lastworkingday_chr then
      vn_from_dt_2 := to_char(trunc(vn_lastworkingday, 'MM'), 'YYYYMMDD');
    elsif i_from_dt = i_to_dt then
      if vn_dayafterprevious < vn_firstday then
        vn_from_dt_2 := vn_firstday;
      elsif vn_dayafterprevious < i_from_dt then
        vn_from_dt_2 := vn_dayafterprevious;
      else
        vn_from_dt_2 := i_from_dt;
      end if;
    else
      vn_from_dt_2 := i_from_dt;
    end if;
  else
    vn_from_dt_2 := i_from_dt;
  end if;

  vn.pxc_log_write('pss_cal_depo_fee',
                   'vn_from_dt_2: ' || vn_from_dt_2 || ', vn_to_dt_2: ' ||
                   vn_to_dt_2);

  --  if trunc(sysdate) = trunc(vn_lastworkingday) then
  --    vn_mak_strt_dt := case when i_work_mn in ('DAILY', 'SYSTEM') and vn_with_freq = 'D'
  --                              then '30000101'
  --                           else
  --                              '%'
  --                      end;
  --  else
  --    vn_mak_strt_dt := '30000101';
  --  end if;

  vn_mak_strt_dt := case
                      when vn_with_freq = 'D' and
                           i_work_mn in ('DAILY', 'SYSTEM') and
                           i_proc_dt <> vn_lastworkingday_chr then
                       '30000101'
                      when vn_with_freq = 'M' and
                           i_work_mn in ('DAILY', 'SYSTEM') and
                           i_proc_dt <> vn_lastworkingday_chr then
                       '30000101'
                      else
                       '%'
                    end;

  vn.pxc_log_write('pss_cal_depo_fee',
                   'vn_mak_strt_dt: ' || vn_mak_strt_dt);

  for c1 in (with ignore_list as
                (select stk_cd from ssi01m99)
               select a.acnt_no,
                      a.sub_no,
                      a.stk_cd,
                      a.dt,
                      sum(a.own_qty) tot_qty,
                      vn.fss_get_stk_tp(a.stk_cd) int_rt_tp,
                      (to_date(trim(vn_to_dt_2), 'YYYYMMDD') -
                      to_date(trim(vn_from_dt_2), 'YYYYMMDD')) + 1 tot_dt_cnt
                 from (

                       select to_char(vn.wdate, 'YYYYMMDD') dt,
                               a.acnt_no,
                               a.sub_no,
                               a.stk_cd,
                               a.own_qty own_qty --* ((to_date(trim(i_to_dt), 'yyyymmdd') - vn.wdate) + 1) own_qty
                         from vn.ssb01m00 a
                        where to_char(vn.wdate, 'YYYYMMDD') between
                              vn_from_dt_2 and vn_to_dt_2
                       --and  a.own_qty > 0

                       union all
                       select b.dt,
                               a.acnt_no,
                               a.sub_no,
                               a.stk_cd,
                               nvl(a.own_qty, 0) own_qty
                         from vn.ssb01m00 a,
                               (select to_char(dt_dt, 'YYYYMMDD') dt
                                  from vn.xcc20m00
                                 where to_char(dt_dt, 'YYYYMMDD') >=
                                       vn.fxc_vorderdt_g(to_date(vn_from_dt_2,
                                                                 'YYYYMMDD'),
                                                         -1)
                                   and to_char(dt_dt, 'YYYYMMDD') <= vn_to_dt_2
                                   and holi_tp in (1, 2, 3)
                                   and to_char(dt_dt, 'YYYYMM') =
                                       substr(vn_from_dt_2, 1, 6)) b
                        where vn.vwdate =
                              vn.fxc_vorderdt_g(to_date(b.dt, 'YYYYMMDD'), -1)
                       --and nvl(a.own_qty,0) > 0

                       union all

                       select a.rgt_std_dt dt,
                               a.acnt_no,
                               a.sub_no,
                               a.stk_cd,
                               a.own_qty + a.cd_qty own_qty
                         from vn.ssb01h00 a
                        where a.rgt_std_dt >= vn_from_dt_2
                          and a.rgt_std_dt <= vn_to_dt_2
                       --and    a.own_qty + a.cd_qty > 0

                       union all

                       select b.dt,
                               a.acnt_no,
                               a.sub_no,
                               a.stk_cd,
                               a.own_qty + a.cd_qty own_qty
                         from vn.ssb01h00 a,
                               (select to_char(dt_dt, 'YYYYMMDD') dt
                                  from vn.xcc20m00
                                 where to_char(dt_dt, 'YYYYMMDD') >=
                                       vn.fxc_vorderdt_g(to_date(vn_from_dt_2,
                                                                 'YYYYMMDD'),
                                                         -1)
                                   and to_char(dt_dt, 'YYYYMMDD') <= vn_to_dt_2
                                   and holi_tp in (1, 2, 3)
                                   and to_char(dt_dt, 'YYYYMM') =
                                       substr(vn_from_dt_2, 1, 6)) b
                        where rgt_std_dt =
                              vn.fxc_vorderdt_g(to_date(b.dt, 'YYYYMMDD'), -1)
                       -- and  a.own_qty + a.cd_qty > 0
                       ) a,
                      vn.aaa01m00 b,
                      (select * -- NHSV-1254
                         from (select usefee_pay_dt,
                                      acnt_no,
                                      sub_no,
                                      mak_strt_dt,
                                      mak_end_dt,
                                      max(mak_end_dt) over(partition by acnt_no, sub_no) as max_end_dt
                                 from ssb07m00
                                where rcpt_trd_no > 0
                                  and cncl_yn = 'N'
                                  and acnt_no like i_acnt_no
                                  and sub_no like i_sub_no
                                  and mak_strt_dt <= vn_to_dt_2
                                  and mak_end_dt >= vn_from_dt_2)
                        where mak_end_dt = max_end_dt) c,
                      ignore_list il
                where a.acnt_no = b.acnt_no
                  and a.sub_no = b.sub_no
                  and nvl(acnt_stat, '!') = '1'
                  and nvl(b.fee_bk, 'N') = 'Y'
                  and a.acnt_no like i_acnt_no
                  and a.sub_no like i_sub_no
                  --and a.acnt_no in ('039C003268','039C003000') /* For testing purpose */
                  and a.stk_cd like i_stk_cd
                  and a.stk_cd = il.stk_cd(+)
                  and il.stk_cd is null
                     --and a.stk_cd not in ('MCV', 'DVD') /*Huedt add for jira NHSV 762 */
                  and a.acnt_no = c.acnt_no(+)
                  and a.sub_no = c.sub_no(+)
                  and a.dt > nvl(c.mak_end_dt, '19000101')
                group by a.acnt_no, a.sub_no, a.stk_cd, dt
                --order by a.acnt_no desc, a.sub_no, a.stk_cd /* For testing purpose */
               /*having sum(own_qty) > 0*/
             ) loop

    /* Already paid the PIT Dont Create new data */
    --    select count(*)
    --      into vn_count
    --      from vn.ssb07m00
    --     where acnt_no = c1.acnt_no
    --       and sub_no = c1.sub_no
    --       and substr(mak_strt_dt,1,6) = substr(c1.dt,1,6)
    --       and mak_strt_dt like vn_mak_strt_dt
    --       and rcpt_trd_no > 0
    --       and cncl_yn = 'N';
    /* Reset vn_from_dt_2 ve ngay dau thang */ -- NHSV-1254
    vn_from_dt_2 := vn_firstday;
    --
    /* Get exactly start date */
    select to_char(max(mak_end_dt) + 1)
      into vn_mak_end_dt
      from vn.ssb07m00
     where cncl_yn = 'N'
       and rcpt_trd_no > 0
       and acnt_no = c1.acnt_no
       and sub_no = c1.sub_no
       and substr(mak_strt_dt, 1, 6) = substr(c1.dt, 1, 6);

    if vn_mak_end_dt >= vn_from_dt_2 then
      vn_from_dt_2 := vn_mak_end_dt;
      --    else
      --      vn_from_dt_2 := i_from_dt;
    end if;

    if vn_mak_end_dt is null then
      if vn_cal_freq = 'D' and i_work_mn in ('DAILY', 'SYSTEM') and i_from_dt = vn_lastworkingday_chr then -- NHSV-1254
        vn_from_dt_2 := vn_firstday;
      else
        vn_from_dt_2 := i_from_dt;
      end if;
    end if;
    /* End get exactly start date */
    --    if (vn_count = 0) then
    vn.pxc_log_write('pss_cal_depo_fee',
                     'c1.dt: ' || c1.dt || ', vn_from_dt_2: ' ||
                     vn_from_dt_2);
    delete vn.ssb07m10
     where acnt_no = c1.acnt_no
       and sub_no = c1.sub_no
          --and substr(mak_strt_dt,1,6) = substr(c1.dt,1,6)
          --and mak_strt_dt like vn_mak_strt_dt
       and stk_cd = c1.stk_cd
       and rgt_std_dt = c1.dt;

    vn.pxc_log_write('pss_cal_depo_fee',
                     'insert ssb07m10 with: ' || i_proc_dt || '-' ||
                     c1.acnt_no || '-' || c1.sub_no || '-' || c1.stk_cd || '-' ||
                     c1.dt);
    insert into vn.ssb07m10
      (usefee_pay_dt,
       acnt_no,
       sub_no,
       stk_cd,
       rgt_std_dt,
       mak_strt_dt,
       mak_end_dt,
       tot_dt_cnt,
       tot_qty,
       int_rt_tp,
       work_mn,
       work_dtm,
       work_trm,
       int_rt,
       use_fee)
    values
      (i_proc_dt,
       c1.acnt_no,
       c1.sub_no,
       c1.stk_cd,
       c1.dt,
       vn_from_dt_2,
       vn_to_dt_2,
       c1.tot_dt_cnt,
       c1.tot_qty,
       c1.int_rt_tp,
       i_work_mn,
       sysdate,
       i_work_trm,
       vn.fss_get_depo_fee_rate(i_sec_cd,
                                c1.acnt_no,
                                c1.sub_no,
                                faa_get_acnt_grp_rt_tp(c1.acnt_no, -- account group
                                                       c1.sub_no,
                                                       '02', -- PLK
                                                       c1.dt),
                                fss_get_stk_tp(c1.stk_cd), -- stock type
                                c1.dt), -- int_rt
       round(c1.tot_qty * vn.fss_get_depo_fee_rate(i_sec_cd,
                                                   c1.acnt_no,
                                                   c1.sub_no,
                                                   faa_get_acnt_grp_rt_tp(c1.acnt_no, -- account group
                                                                          c1.sub_no,
                                                                          '02', -- PLK
                                                                          c1.dt),
                                                   fss_get_stk_tp(c1.stk_cd), -- stock type
                                                   c1.dt) / 30,
             2) -- usefee
       );
    vn.pxc_log_write('pss_cal_depo_fee',
                     'Finish insert ssb07m10 with: ' || c1.acnt_no || '-' ||
                     c1.sub_no || '-' || c1.stk_cd);
    --    end if;
  end loop;

  /* insert ssb07m00 */
  vn.pxc_log_write('pss_cal_depo_fee', 'start c2');
  for c2 in (select a.usefee_pay_dt,
                    a.acnt_no,
                    a.sub_no,
                    a.mak_strt_dt,
                    a.mak_end_dt,
                    a.tot_dt_cnt,
                    sum(a.tot_qty) tot_qty,
                    ceil(sum(a.usefee)) use_fee,
                    b.acnt_mng_bnh,
                    b.agnc_brch
               from (select usefee_pay_dt,
                            acnt_no,
                            sub_no,
                            mak_strt_dt,
                            mak_end_dt,
                            tot_dt_cnt,
                            sum(tot_qty) as tot_qty,
                            ceil(sum(nvl(use_fee, 0))) as usefee
                       from ssb07m10
                      where acnt_no like i_acnt_no
                        and sub_no like i_sub_no
                        and usefee_pay_dt = i_proc_dt
                        and mak_strt_dt >= vn_from_dt_2 /*  */
                        and mak_end_dt <= vn_to_dt_2 /*  */
                      group by acnt_no,
                               sub_no,
                               usefee_pay_dt,
                               mak_strt_dt,
                               mak_end_dt,
                               tot_dt_cnt,
                               int_rt_tp) a,
                    vn.aaa01m00 b
              where a.acnt_no = b.acnt_no
                and a.sub_no = b.sub_no
                and b.acnt_stat = '1'
                --and a.usefee_pay_dt = i_proc_dt
                --and a.mak_strt_dt >= vn_from_dt_2 /*  */
                --and a.mak_end_dt <= vn_to_dt_2 /*  */
              group by a.acnt_no,
                       a.sub_no,
                       a.usefee_pay_dt,
                       a.mak_strt_dt,
                       a.mak_end_dt,
                       a.tot_dt_cnt,
                       b.acnt_mng_bnh,
                       b.agnc_brch) loop

    /* Already paid the PIT Dont Create new data */
    --    select count(*)
    --      into vn_count
    --      from vn.ssb07m00
    --     where acnt_no = c2.acnt_no
    --       and sub_no = c2.sub_no
    --       and substr(mak_strt_dt,1,6) = substr(c2.mak_strt_dt,1,6)
    --       --and mak_strt_dt like vn_mak_strt_dt
    --       and rcpt_trd_no = 0
    --       and cncl_yn = 'N';
    --vn.pxc_log_write('pss_cal_depo_fee', 'vn_count: ' || vn_count);
    --    if (vn_count = 0) then

    /* If today is calculated via 02015, donot re-calculate by batch job */
    vn.pxc_log_write('pss_cal_depo_fee',
                     'c2.mak_strt_dt: ' || c2.mak_strt_dt);
    --vn.pxc_log_write('pss_cal_depo_fee', 'Flag 1.');
    select nvl(max(mak_end_dt), '19000101')
      into vn_mak_end_dt
      from vn.ssb07m00
     where acnt_no = c2.acnt_no
       and sub_no = c2.sub_no
       and substr(mak_strt_dt, 1, 6) = substr(c2.mak_strt_dt, 1, 6)
       and rcpt_trd_no = 0
       and cncl_yn = 'N';
    vn.pxc_log_write('pss_cal_depo_fee',
                     'vn_mak_end_dt: ' || vn_mak_end_dt || ', i_proc_dt: ' ||
                     i_proc_dt);
    if vn_mak_end_dt >= i_proc_dt and i_work_mn in ('DAILY', 'SYSTEM') and
       i_proc_dt <> vn_lastworkingday_chr then
      vn.pxc_log_write('pss_cal_depo_fee',
                       'Skip calculate depo fee for account: ' ||
                       c2.acnt_no || '-' || c2.sub_no || ' date: ' ||
                       i_proc_dt);
      vn.pxc_log_write('pss_cal_depo_fee', 'Flag 2.');
      goto cur_day_calculated;
    end if;
    --vn.pxc_log_write('pss_cal_depo_fee', 'Flag 3.');
    --
    /* Reset vn_from_dt_2 ve ngay dau thang */
    vn_from_dt_2 := vn_firstday;
    --
    /* Get exactly start date */
    select to_char(nvl(max(mak_end_dt) + 1,
                       to_char(trunc(to_date(i_from_dt, 'YYYYMMDD'), 'MM'),
                               'YYYYMMDD')))
      into vn_mak_end_dt
      from vn.ssb07m00
     where cncl_yn = 'N'
       and rcpt_trd_no > 0
       and acnt_no = c2.acnt_no
       and sub_no = c2.sub_no
       and substr(mak_strt_dt, 1, 6) = substr(c2.mak_strt_dt, 1, 6);

    vn.pxc_log_write('pss_cal_depo_fee', 'acnt_no: ' || c2.acnt_no || '-' || c2.sub_no ||
                     ', vn_mak_end_dt: ' || vn_mak_end_dt || ', i_from_dt: ' ||
                     i_from_dt);

    if vn_mak_end_dt >= i_from_dt then
      vn_from_dt_2 := vn_mak_end_dt;
      --    elsif vn_mak_end_dt < i_from_dt then
      --      vn_from_dt_2 := i_from_dt;
    end if;

    if vn_mak_end_dt = vn_firstday then -- NHSV-1254
      vn_from_dt_2 := vn_firstday;
    end if;

    if vn_mak_end_dt is null then -- NHSV-1254
      if vn_cal_freq = 'D' and i_work_mn in ('DAILY', 'SYSTEM') and i_from_dt = vn_lastworkingday_chr then
        vn_from_dt_2 := vn_firstday;
      else
        vn_from_dt_2 := i_from_dt;
      end if;
    end if;

    vn.pxc_log_write('pss_cal_depo_fee', 'acnt_no: ' || c2.acnt_no || '-' || c2.sub_no || ', vn_mak_end_dt: ' || vn_mak_end_dt || ', vn_from_dt_2: ' || vn_from_dt_2 || ', vn_to_dt_2: ' || vn_to_dt_2);
    vn.pxc_log_write('pss_cal_depo_fee', 'c2.mak_strt_dt: ' || c2.mak_strt_dt || ', c2.mak_end_dt: ' || c2.mak_end_dt);
    --vn.pxc_log_write('pss_cal_depo_fee', 'Flag 4.');
    select count(*)
      into vn_count
      from vn.ssb07m00
     where acnt_no = c2.acnt_no
       and sub_no = c2.sub_no
       and ((substr(mak_strt_dt, 1, 6) = substr(c2.mak_strt_dt, 1, 6) and
           i_work_mn in ('DAILY', 'SYSTEM') and
           mak_strt_dt like vn_mak_strt_dt) or
           (mak_end_dt between vn_from_dt_2 and vn_to_dt_2 and
           i_work_mn not in ('DAILY', 'SYSTEM')))
       and mak_end_dt between vn_from_dt_2 and vn_to_dt_2
       and mak_strt_dt like vn_mak_strt_dt
       and rcpt_trd_no = 0
       and cncl_yn = 'N';

    vn.pxc_log_write('pss_cal_depo_fee', '1.vn_count: ' || vn_count);
    /* Update to X */
    if (vn_count > 0) then
      select sum(usefee)
        into vn_total_fee_blk
        from vn.ssb07m00
       where acnt_no = c2.acnt_no
         and sub_no = c2.sub_no
         and ((substr(mak_strt_dt, 1, 6) = substr(c2.mak_strt_dt, 1, 6) and
             i_work_mn in ('DAILY', 'SYSTEM') and
             mak_strt_dt like vn_mak_strt_dt) or
             (mak_end_dt between vn_from_dt_2 and vn_to_dt_2 and
             i_work_mn not in ('DAILY', 'SYSTEM')))
            --and mak_end_dt between vn_from_dt_2 and vn_to_dt_2
            --and mak_strt_dt like vn_mak_strt_dt
         and rcpt_trd_no = 0
         and cncl_yn = 'N';

      vn.pxc_log_write('pss_cal_depo_fee',
                       'vn_total_fee_blk: ' || vn_total_fee_blk);
      vn.pxc_log_write('pss_cal_depo_fee',
                       'i_work_mn: ' || i_work_mn || ', vn_mak_strt_dt: ' ||
                       vn_mak_strt_dt || ', vn_from_dt_2: ' || vn_from_dt_2 ||
                       ', vn_to_dt_2:' || vn_to_dt_2 || ', c2.acnt_no: ' ||
                       c2.acnt_no || ', c2.sub_no: ' || c2.sub_no ||
                       ', c2.mak_strt_dt:' || c2.mak_strt_dt);

      update vn.ssb07m00
         set cncl_yn = 'X'
       where cncl_yn = 'N'
         and ((substr(mak_strt_dt, 1, 6) = substr(c2.mak_strt_dt, 1, 6) and
             i_work_mn in ('DAILY', 'SYSTEM') and
             mak_strt_dt like vn_mak_strt_dt) or
             (mak_end_dt between vn_from_dt_2 and vn_to_dt_2 and
             i_work_mn not in ('DAILY', 'SYSTEM')))
         and mak_end_dt between vn_from_dt_2 and vn_to_dt_2
         and mak_strt_dt like vn_mak_strt_dt
         and rcpt_trd_no = 0
         and acnt_no = c2.acnt_no
         and sub_no = c2.sub_no;
      vn.pxc_log_write('pss_cal_depo_fee',
                       'Update ' || SQL%ROWCOUNT || ' records for account ' ||
                       c2.acnt_no || '-' || c2.sub_no);
      /* unblock old fee */
      if (vn_total_fee_blk > 0) then
        begin
          vn.pcw_waitting_bk_ubk_p('04',
                                   vn.vwdate,
                                   c2.acnt_no,
                                   c2.sub_no,
                                   vn_total_fee_blk,
                                   '00',
                                   i_work_mn,
                                   i_work_trm,
                                   vn_tot_out_blk_fee);
        exception
          when others then
            vn.pxc_log_write('pcw_waitting_bk_ubk_p 03',
                             '[' || sqlcode || ']');
        end;
      end if;
    end if;

    /* get seq */
    select count(*)
      into vn_count
      from vn.ssb07m00
     where acnt_no = c2.acnt_no
       and sub_no = c2.sub_no
       and substr(mak_strt_dt, 1, 6) = substr(c2.mak_strt_dt, 1, 6)
       and usefee_pay_dt = i_proc_dt;

    vn.pxc_log_write('pss_cal_depo_fee',
                     'vn_count before insert ssb07m00: ' || vn_count);
    vn.pxc_log_write('pss_cal_depo_fee', 'insert into ssb07m00');
    if c2.use_fee > 0 then
      insert into vn.ssb07m00
        (usefee_pay_dt,
         acnt_no,
         sub_no,
         mak_strt_dt,
         mak_end_dt,
         tot_dt_cnt,
         tot_qty,
         tot_avbl_qty,
         apy_int_rt,
         usefee,
         acnt_mng_bnh,
         agnc_brch,
         rcpt_trd_no,
         err_cont,
         cncl_yn,
         cncl_trd_no,
         work_mn,
         work_dtm,
         work_trm,
         seq_no)
      values
        (c2.usefee_pay_dt,
         c2.acnt_no,
         c2.sub_no,
         c2.mak_strt_dt,
         c2.mak_end_dt,
         c2.tot_dt_cnt,
         c2.tot_qty,
         c2.tot_qty / 10,
         0,
         ceil(c2.use_fee),
         c2.acnt_mng_bnh,
         c2.agnc_brch,
         0,
         0,
         'N',
         0,
         i_work_mn,
         sysdate,
         i_work_trm,
         vn_count + 1);

      begin
        vn.pcw_waitting_bk_ubk_p('03',
                                 vn.vwdate,
                                 c2.acnt_no,
                                 c2.sub_no,
                                 c2.use_fee,
                                 '00',
                                 i_work_mn,
                                 i_work_trm,
                                 vn_tot_out_blk_fee);
      exception
        when others then
          vn.pxc_log_write('pcw_waitting_bk_ubk_p 03',
                           '[' || sqlcode || ']');
      end;
    end if;
    <<cur_day_calculated>>
    null;
    --    end if;
  end loop;

  vn.pxc_log_write('pss_cal_depo_fee', 'finish');

  return;
end pss_cal_depo_fee;
/

