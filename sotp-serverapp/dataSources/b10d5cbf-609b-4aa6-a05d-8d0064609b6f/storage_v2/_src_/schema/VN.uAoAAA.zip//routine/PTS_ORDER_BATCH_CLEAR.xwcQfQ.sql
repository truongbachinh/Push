create PROCEDURE    pts_order_batch_clear
(
   i_work_dt       in      varchar2,       -- date(yyyymmdd)
   o_proc_cnt      out     number          -- proc data count

)as
t_wdate         varchar2(8);
t_sdate         varchar2(8);
t_err_code      number;
t_err_msg       varchar2(600);
t_chk           varchar2(1);
t_cnt             number;
rtn               number;
exp_error       exception;
t_tso01m11_cnt  number:=0;
t_tso05m10_cnt      number:=0;
t_tso05m20_cnt      number:=0;
t_tso02m10_cnt      number:=0;
t_tso03m10_cnt      number:=0;
t_tso02h10_cnt      number:=0;

/*!
    \file     pts_order_batch_clear
  \brief    Initialize all system resource

  \section intro Program Information
    - Program Name              : pts_order_batch_clear
    - Service Name              :
    - Related Client Program- Client Program ID :
    - Related Tables            : tso01xx,xih03xx
    - Dev. Date                 : 2013/07/31
    - Developer                 : vnjvhoan
    - Business Logic Desc.      :
    - Latest Modification Date  :

  \section history Program Modification History
    - 1.0   2013/07/31

  \section hardcoding Hard-Coding List

  \section info Additional Reference Comments
*/

begin
  t_err_code := 0;
  t_err_msg  := 'SUCCESS';
  t_chk      := 'Y';
  o_proc_cnt := 0;
  t_cnt        := 0;

  if   t_chk = 'N' then
     t_err_code := -1;
     t_err_msg  := '¿¿ ¿¿ü¿¿¿¿¿¿¿¿ ü¿¿¿ ¿ ó¿¿¿¿¿ÿ¿';
     raise_application_error(-20100,'[pts_order_batch_clear] ' || t_err_msg);
  else
  begin
  PTS_VWDATE_G(t_sdate,t_wdate,rtn);
  if(rtn < 0) then
   raise_application_error(-20100,'[pts_order_batch_clear] ' ||'Today is not working day');
  end if;
  exception
  when others then
     t_err_code:=sqlcode;
     t_err_msg:=sqlerrm;
     raise_application_error(-20100,'[pts_order_batch_clear] ' ||t_err_msg);
  end;

   --Start pts_bat_tso01m11_trunc

   BEGIN
   select count(*) into t_tso01m11_cnt from tso01m11;
   if t_tso01m11_cnt > 0 then
            vn.pts_bat_tso01m11_trunc(t_wdate,
                          t_err_code,
                          t_err_msg,
                          t_cnt);
   end if;
   exception
   when others then
   t_err_code:=sqlcode;
   t_err_msg:=sqlerrm;
   raise_application_error(-20100,'[pts_order_batch_clear][pts_bat_tso01m11_trunc] ' ||t_err_msg);

   END;

   --Start pts_bat_tso05m10_trunc
   BEGIN
      select count(*) into t_tso05m10_cnt  from tso05m10;
      if t_tso05m10_cnt > 0 then
            vn.pts_bat_tso05m10_trunc(t_wdate,
                          t_err_code,
                          t_err_msg,
                          t_cnt);
     end if;
   exception
   when others then
   t_err_code:=sqlcode;
   t_err_msg:=sqlerrm;
   raise_application_error(-20100,'[pts_order_batch_clear][pts_bat_tso05m10_trunc] ' ||t_err_msg);

   END;

   --Start pts_bat_tso05m20_trunc

   BEGIN
     select count(*) into t_tso05m20_cnt from tso05m20;
    if t_tso05m20_cnt > 0 then
            vn.pts_bat_tso05m20_trunc(  t_wdate,
                          t_err_code,
                          t_err_msg,
                          t_cnt);
    end if;
   exception
   when others then
   t_err_code:=sqlcode;
   t_err_msg:=sqlerrm;
   raise_application_error(-20100,'[pts_order_batch_clear][pts_bat_tso05m20_trunc] ' ||t_err_msg);

   END;

   --Start pts_bat_xih_trunc
   BEGIN
            vn.pts_bat_xih_trunc(  t_wdate,
                        t_err_code,
                        t_err_msg);
   exception
   when others then
   t_err_code:=sqlcode;
   t_err_msg:=sqlerrm;
   raise_application_error(-20100,'[pts_order_batch_clear][pts_bat_xih_trunc] ' ||t_err_msg);

   END;
   -- Start pts_bat_tso02h10_ins
   BEGIN
   select count(*) into t_tso02h10_cnt from tso02h10;
   if t_tso02h10_cnt> 0 then
   vn.pts_bat_tso02h10_ins(t_wdate,
                      t_err_code,
                      t_err_msg,
                      t_cnt);
   end if;
   exception
   when others then
   t_err_code:=sqlcode;
   t_err_msg:=sqlerrm;
   raise_application_error(-20100,'[pts_order_batch_clear][pts_bat_tso02h10_ins]'||t_err_msg);

    END;
    -- Start pts_bat_tso02m10_trunc

   BEGIN
     select count(*) into t_tso02m10_cnt from tso02m10;
     if t_tso02m10_cnt > 0 then
        vn.pts_bat_tso02m10_trunc(t_wdate,
                      t_err_code,
                      t_err_msg,
                      t_cnt);
    end if;
   exception
   when others then
   t_err_code:=sqlcode;
   t_err_msg:=sqlerrm;
   raise_application_error(-20100,'[pts_order_batch_clear][pts_bat_tso02m10_trunc] ' ||t_err_msg);

   END;

   --Start pts_bat_tso03m00_mod
  BEGIN
            vn.pts_bat_tso03m00_mod(t_wdate,
                          t_err_code,
                          t_err_msg);
   exception
   when others then
   t_err_code:=sqlcode;
   t_err_msg:=sqlerrm;
   raise_application_error(-20100,'[pts_order_batch_clear][pts_bat_tso03m00_mod] ' ||t_err_msg);

  END;

  -- Start pts_bat_tso03m10_update: Refresh avaliabe place order each market

  BEGIN
    select count(*) into t_tso03m10_cnt from tso03m10;
    if t_tso03m10_cnt > 0 then
      vn.pts_bat_tso03m10_update(t_wdate,
                    t_err_code,
                    t_err_msg,
                    t_cnt);
   end if;
   exception
   when others then
   t_err_code:=sqlcode;
   t_err_msg:=sqlerrm;
   raise_application_error(-20100,'[pts_order_batch_clear][pts_bat_tso03m10_update] ' ||t_err_msg);

  END;

  o_proc_cnt:=sql%rowcount;

end if;

BEGIN
vn.pxc_batch_sms_staff(vn.fxc_sec_cd('R'), '1');
END;
end pts_order_batch_clear;
/

