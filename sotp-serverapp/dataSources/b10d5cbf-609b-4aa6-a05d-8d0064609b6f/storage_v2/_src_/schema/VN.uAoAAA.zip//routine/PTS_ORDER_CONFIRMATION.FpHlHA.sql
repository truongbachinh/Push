create procedure pts_order_confirmation
(
    i_proc_dt         in     varchar2,
    i_work_mn         in     varchar2
)
is

    t_date                  varchar2(8)     := Null;
    t_vwdate                varchar2(8)     := Null;
    t_ord_cnfmm_tp          varchar2(1)     := Null;
    t_lst_wrk_dt            varchar2(8)     := Null;
    t_lst_upd_dt            varchar2(8)     := Null;

    t_err_yn                varchar2(1)     := 'N';
    t_sms_msg               varchar2(1000)  := NULL;

    t_proc_tp               VARCHAR2(5)     := 'A3001';     -- proc_tp cho Update trang thai xac nhan lenh
    t_work_tp               VARCHAR2(10)    := '999';

begin

    vn.Pxc_Log_Write('pts_order_confirmation',
                   '=======START pts_order_confirmation at: ' ||
                   TO_CHAR(SYSDATE, 'dd/mm/yyyy hh24:mi:ss') ||
                   '==========');

    t_vwdate := vn.vwdate();
    Begin
    ---t_ord_cnfmm_tp: '1': Tu ngay dat lenh   '2': Tu ngay cuoi cung cua ky tinh hoa hong  '3': User nhap tay
        select col_cd_tp
        into t_ord_cnfmm_tp
        from xcc01c02
        where col_cd = 'ord_cnfmm_tp';

        select vn.fbm_get_cnfm_dt(i_proc_dt)
        into t_date
        from dual;

/*         --Lay ra ngay lam viec gan nhat
        select vn.fxc_vorderdt_g(i_proc_dt, -1)
        into t_lst_wrk_dt
        from dual; */

        -- Lay ngay chưa update trang thai xac nhan lenh gan nhat
        select Min(stk_ord_dt)
        into t_lst_upd_dt
        from tso01h00
        where ord_sign = 'N'
        and acnt_no <> upper(work_mn)
        and mdm_tp <> '01'
        and work_mn NOT IN ('HNX','SYSTEM','AUTO','HOSE');

    exception
        when others then
            t_err_yn := 'Y';
    end;

    vn.Pxc_Log_Write('pts_order_confirmation', 't_date: ' || t_date
                                            || 't_ord_cnfmm_tp: ' || t_ord_cnfmm_tp
                                            || 't_lst_wrk_dt: '   || t_lst_wrk_dt
    );
    Begin
        if t_ord_cnfmm_tp = '1' then

            update vn.tso01h00
            set ord_sign = 'Y',
                sign_mn = i_work_mn
            where ord_sign = 'N'
            and stk_ord_dt < t_date
            and stk_ord_dt >= t_lst_upd_dt
            and work_mn in ('HNX','SYSTEM','AUTO','HOSE');

            update vn.tso01h00
            set ord_sign = 'D'
            where ord_sign = 'N'
            and stk_ord_dt < t_date
            and stk_ord_dt >= t_lst_upd_dt
            and acnt_no <> upper(work_mn)
            and mdm_tp <> '01'
            and work_mn NOT IN ('HNX','SYSTEM','AUTO','HOSE');
        elsif t_ord_cnfmm_tp = '2' then

            update vn.tso01h00
            set ord_sign = 'Y',
                sign_mn = i_work_mn
            where ord_sign = 'N'
            and stk_ord_dt <= t_date
            and stk_ord_dt >= t_lst_upd_dt
            and work_mn in ('HNX','SYSTEM','AUTO','HOSE');

            update vn.tso01h00
            set ord_sign = 'D'
            where ord_sign = 'N'
            and stk_ord_dt <= t_date
            and stk_ord_dt >= t_lst_upd_dt
            and vn.fbm_get_cnfm_dt(stk_ord_dt) < t_vwdate
            and acnt_no <> upper(work_mn)
            and mdm_tp <> '01'
            and work_mn NOT IN ('HNX','SYSTEM','AUTO','HOSE');
        elsif t_ord_cnfmm_tp = '3' then

            update vn.tso01h00
            set ord_sign = 'Y',
                sign_mn = i_work_mn
            where ord_sign = 'N'
            and stk_ord_dt <= t_date
            and stk_ord_dt >= t_lst_upd_dt
            and work_mn in ('HNX','SYSTEM','AUTO','HOSE');

            update vn.tso01h00
            set ord_sign = 'D'
            where ord_sign = 'N'
            and stk_ord_dt <= t_date
            and stk_ord_dt >= t_lst_upd_dt
            and vn.fbm_get_cnfm_dt(stk_ord_dt) < t_vwdate
            and acnt_no <> upper(work_mn)
            and mdm_tp <> '01'
            and work_mn NOT IN ('HNX','SYSTEM','AUTO','HOSE');
        end if;
    exception
    when others then
        vn.pxc_log_write('pts_order_confirmation', 'update error.');
        t_err_yn := 'Y';
    end;

    IF t_err_yn = 'Y' THEN
        -- Send email when job error
        t_sms_msg := 'Xay ra loi khi thuc hien update trang thai xac nhan lenh';
        vn.pxc_sms_by_proc_tp(
            t_vwdate,
            t_proc_tp,
            t_work_tp,
            t_work_tp,
            t_sms_msg,
            i_work_mn,
            'SYSTEM'
        );
    END IF;

    vn.Pxc_Log_Write('pts_order_confirmation',
                   '=======END pts_order_confirmation at: ' ||
                   TO_CHAR(SYSDATE, 'dd/mm/yyyy hh24:mi:ss') ||
                   '==========');
    --commit;
end pts_order_confirmation;
/

