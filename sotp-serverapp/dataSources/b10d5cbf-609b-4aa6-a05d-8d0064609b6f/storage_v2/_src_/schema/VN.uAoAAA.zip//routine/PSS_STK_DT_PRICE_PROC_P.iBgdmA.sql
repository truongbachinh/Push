create procedure pss_stk_dt_price_proc_p
( i_proc_dt    in   varchar2,
  i_work_mn    in   varchar2,
  i_work_trm   in   varchar2,
  o_proc_cnt   out  number
 ) is
/***************************************************************************/
/* Right standard work                                                     */
/* 2007-10-22                                                              */
/***************************************************************************/

 t_pd_cls_pri number;
 t_pd_cls_pri_bk number;

 v_hnx_idx  number :=0;
 v_upc_idx  number :=0;
 v_hnx_qty  number :=0;
 v_hnx_amt  number :=0;
 v_upc_qty  number :=0;
 v_upc_amt  number :=0;

begin

 vn.pxc_log_write('pss_stk_dt_price_proc_p', 'start');

 o_proc_cnt  := 0;
 t_pd_cls_pri := 0;
 t_pd_cls_pri_bk := 0;

 delete from vn.SSI01H00_DR;

 for c2 in (

   select    b.stk_mkt_tp      mkt_tp  ,
         a.stk_id          stk_id  ,
             a.stk_cd          stk_cd  ,
         a.max_pri         max_pri ,
         a.cls_pri         cls_pri ,
         a.dn_pri          dn_pri  ,
         a.high_pri        high_pri,
         a.low_pri         low_pri ,
         a.strt_pri        strt_pri,
         a.fac_pri         fac_pri,
         a.stk_tp          stk_tp  ,
         b.list_stk_qty    list_stk_qty ,
         nvl(b.cd_yn,'N')  cd_yn   ,
         b.cd_rate         cd_rate ,
         b.cd_work_mn      cd_work_mn ,
         b.cd_work_dtm     cd_work_dtm ,
         b.rgt_rate        rgt_rate    ,
         b.td_rate         td_rate     ,
         b.pd_rate         pd_rate     ,
         b.ppd_rate        ppd_rate    ,
         b.pppd_rate       pppd_rate   ,
               b.cdr             cdr
        from   vn.ssi02m00 a,
         vn.ssi01m00 b
    where  a.stk_cd  = b.stk_cd
    and    b.stk_mkt_tp = '1'

   ) loop

  if c2.cls_pri <= 0 then
     t_pd_cls_pri := c2.fac_pri;
    else
     t_pd_cls_pri := c2.cls_pri ;
    end if;

  t_pd_cls_pri_bk := t_pd_cls_pri;

  --VCSC-1962: Lam tron hang tram xuong hang don vi
  select greatest( round(vn.fss_REFPRI_pd_cls_pri_non_lmt(i_proc_dt, c2.stk_cd, t_pd_cls_pri_bk), 0), 0) into t_pd_cls_pri_bk from dual;
  select greatest( round(vn.fss_REFPRI_pd_cls_pri(i_proc_dt, c2.stk_cd, t_pd_cls_pri), 0), 0) into t_pd_cls_pri from dual; --VCSC-1823

  insert into vn.SSI01H00_DR
  ( stk_cd,
    cls_pri,
    work_mn,
    work_dtm,
    work_trm,
    cls_pri_bk
    )
  values
  ( c2.stk_cd,
    t_pd_cls_pri,
    'BATCH',
    sysdate,
    'BATCH',
    t_pd_cls_pri_bk
    );

  end loop;


  for c3 in (

    select b.stk_mkt_tp      mkt_tp ,
       a.stk_cd          stk_cd ,
       a.stk_id          stk_id ,
       a.max_pri         max_pri,
       a.dn_pri          dn_pri ,
       a.list_stk_qty    list_stk_qty,
       a.high_pri        high_pri,
       a.low_pri         low_pri ,
       a.strt_pri        strt_pri,
       a.cls_pri         cls_pri ,
       a.stk_tp          stk_tp  ,
       a.avg_pri         avg_pri ,
       a.fac_pri         fac_pri ,
       nvl(b.cd_yn,'N')  cd_yn   ,
       b.cd_work_mn      cd_work_mn ,
       b.cd_work_dtm     cd_work_dtm ,
             b.cd_rate         cd_rate  ,
       b.rgt_rate        rgt_rate ,
       b.td_rate         td_rate  ,
       b.pd_rate         pd_rate  ,
       b.ppd_rate        ppd_rate  ,
       b.pppd_rate       pppd_rate ,
             b.cdr             cdr
       from  vn.ssi03m00 a,
       vn.ssi01m00 b
     where a.stk_cd     = b.stk_cd
     and   b.stk_mkt_tp = '2'

   ) loop

   if c3.cls_pri <= 0 then
    t_pd_cls_pri := c3.fac_pri;
   else
      t_pd_cls_pri := c3.cls_pri;
   end if;

   t_pd_cls_pri_bk := t_pd_cls_pri;
  --VCSC-1962: Lam tron hang tram xuong hang don vi
  select greatest( round(vn.fss_REFPRI_pd_cls_pri_non_lmt(i_proc_dt, c3.stk_cd, t_pd_cls_pri_bk), 0), 0) into t_pd_cls_pri_bk from dual;
  select greatest( round(vn.fss_REFPRI_pd_cls_pri(i_proc_dt, c3.stk_cd, t_pd_cls_pri), 0), 0) into t_pd_cls_pri from dual; --VCSC-1823

   insert into vn.SSI01H00_DR
   ( stk_cd,
   cls_pri,
   work_mn,
   work_dtm,
   work_trm,
   cls_pri_bk
   )
   values
   ( c3.stk_cd,
   t_pd_cls_pri,
   'BATCH',
   sysdate,
   'BATCH',
   t_pd_cls_pri_bk
   );

   end loop;

  /*  update cancel list by jung */

  for c4 in (

    select b.stk_mkt_tp      mkt_tp ,
       a.stk_cd          stk_cd,
       a.stk_id          stk_id,
       0                 max_pri,
       0                 dn_pri,
       a.list_stk_qty    list_stk_qty,
       a.high_pri        high_pri,
       a.low_pri         low_pri,
       a.strt_pri        strt_pri,
       a.cls_pri         cls_pri,
       a.fac_pri         fac_pri,
       a.stk_tp          stk_tp ,
             nvl(b.cd_yn,'N')  cd_yn  ,
       b.cd_work_mn      cd_work_mn ,
       b.cd_work_dtm     cd_work_dtm ,
       b.cd_rate         cd_rate  ,
       b.rgt_rate        rgt_rate ,
       b.td_rate         td_rate ,
       b.pd_rate         pd_rate ,
       b.ppd_rate        ppd_rate ,
       b.pppd_rate       pppd_rate ,
             b.cdr             cdr
       from  vn.ssi04m00 a,
       vn.ssi01m00 b
     where a.stk_cd     = b.stk_cd
     and   b.stk_mkt_tp = '3'

   ) loop

  if c4.cls_pri  > 0 then
    t_pd_cls_pri := c4.cls_pri;
    else
     t_pd_cls_pri := c4.fac_pri;
    end if;

  t_pd_cls_pri_bk := t_pd_cls_pri;
  --VCSC-1962: Lam tron hang tram xuong hang don vi
  select greatest( round(vn.fss_REFPRI_pd_cls_pri_non_lmt(i_proc_dt, c4.stk_cd, t_pd_cls_pri_bk), 0), 0) into t_pd_cls_pri_bk from dual;
  select greatest( round(vn.fss_REFPRI_pd_cls_pri(i_proc_dt, c4.stk_cd, t_pd_cls_pri), 0), 0) into t_pd_cls_pri from dual; --VCSC-1823

  insert into vn.SSI01H00_DR
  ( stk_cd,
    cls_pri,
    work_mn,
    work_dtm,
    work_trm,
    cls_pri_bk
    )
  values
  ( c4.stk_cd,
    t_pd_cls_pri,
    'BATCH',
    sysdate,
    'BATCH',
    t_pd_cls_pri_bk
    );

 end loop;

 for c5 in (

      select b.stk_mkt_tp      mkt_tp,
       a.stk_cd          stk_cd,
             a.stk_id          stk_id,
             a.max_pri         max_pri,
             a.dn_pri          dn_pri,
             a.list_stk_qty    list_stk_qty,
             a.high_pri        high_pri,
             a.low_pri         low_pri,
             a.strt_pri        strt_pri,
             a.cls_pri         cls_pri,
             a.fac_pri         fac_pri,
             a.stk_tp          stk_tp ,
       a.avg_pri avg_pri ,
       nvl(b.cd_yn,'N')  cd_yn  ,
       b.cd_work_mn      cd_work_mn,
       b.cd_work_dtm     cd_work_dtm ,
       b.cd_rate         cd_rate  ,
       b.rgt_rate        rgt_rate  ,
       b.td_rate         td_rate  ,
       b.pd_rate         pd_rate  ,
       b.ppd_rate        ppd_rate  ,
       b.pppd_rate       pppd_rate ,
             b.cdr             cdr
       from  vn.ssi03m10 a,
       vn.ssi01m00 b
       where a.stk_cd     = b.stk_cd
       and   b.stk_mkt_tp = '4'

   ) loop

  if c5.avg_pri > 0 then
      t_pd_cls_pri := c5.avg_pri;
    else
     t_pd_cls_pri := c5.fac_pri;
    end if;

  t_pd_cls_pri_bk := t_pd_cls_pri;
   --VCSC-1962: Lam tron hang tram xuong hang don vi
  select greatest( round(vn.fss_REFPRI_pd_cls_pri_non_lmt(i_proc_dt, c5.stk_cd, t_pd_cls_pri_bk), 0), 0) into t_pd_cls_pri_bk from dual;
  select greatest( round(vn.fss_REFPRI_pd_cls_pri(i_proc_dt, c5.stk_cd, t_pd_cls_pri), 0), 0) into t_pd_cls_pri from dual; --VCSC-1823

  insert into vn.SSI01H00_DR
  ( stk_cd,
    cls_pri,
    work_mn,
    work_dtm,
    work_trm,
    cls_pri_bk
    )
  values
  ( c5.stk_cd,
    t_pd_cls_pri,
    'BATCH',
    sysdate,
    'BATCH',
    t_pd_cls_pri_bk
    );

   end loop;

end  pss_stk_dt_price_proc_p;
/

