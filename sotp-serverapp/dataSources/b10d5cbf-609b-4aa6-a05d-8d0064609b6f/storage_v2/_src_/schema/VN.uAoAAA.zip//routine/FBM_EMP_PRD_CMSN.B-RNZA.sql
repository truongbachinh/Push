create function fbm_emp_prd_cmsn(
       i_user_id           in       varchar2,
       i_emp_no            in       varchar2,
       i_date              in       varchar2,
       i_biz_cmsn_tp       in       varchar2,
       i_brch_cd           in       varchar2,
       i_dept_no           in       varchar2,
       i_biz_emp_tp        in       varchar2
)
       return sys_refcursor
as
      o_cursor sys_refcursor;
begin
      open o_cursor for
           select * from
           (
                  with prd as (
                      select a.biz_prd_cd, a.biz_cmsn_knd, a.active_stat, a.biz_cmsn_grp_cd, a.net_fee_yn, a.system_cutoff_rt
                      from rms03m01 a
                      join (select max(c.id) as cid from rms03m01 c where c.apy_dt <= i_date group by c.biz_prd_cd, c.biz_cmsn_knd) q
                      on a.id = q.cid
                      where a.apy_dt <= i_date
                      and a.active_stat = 'Y'
                  ),
                  quota_dept as (
                      select a.emp_no, b.biz_prd_cd, c.biz_cmsn_knd, d.biz_cmsn_tp, e.quota
                      from xca01m01 a
                      join rms04m00 b
                        on a.emp_no = b.emp_no
                        and vn.vwdate() between b.apy_dt and b.expr_dt
                        and b.active_stat = 'Y'
                      join rms03m01 c
                        on b.biz_prd_cd = c.biz_prd_cd
                        and vn.vwdate() > c.apy_dt
                        and c.biz_cmsn_knd = 3
                      join rms03m00 d
                        on b.biz_prd_cd = d.biz_prd_cd
                      join rms02m00 e
                           on e.biz_cmsn_tp = d.biz_cmsn_tp
                           and a.dept_cd = e.dept_posi_cd
                           and e.quota_tp = '2'
                  )
                  select distinct a.emp_no,a.emp_nm, b.posi_cd, b.posi_cd_nm, nvl(b.base_sal, '0') ,
                                  decode(m.brch_cd || '.' || m.agnc_brch || '. ' || m.brch_cd_nm, '.. ', '!',m.brch_cd || '.' || m.agnc_brch || '. ' || m.brch_cd_nm) as brch,
                                  decode(n.dept_cd || '. ' || n.dept_cd_nm, '. ', '!',n.dept_cd || '. ' || n.dept_cd_nm) as dept,
                                  nvl(c.quota, '0') as quota_dept, nvl(d.quota, '0') as quota_emp,
                                  decode(f.biz_cmsn_tp, '1', '1. Giá trị giao dịch', '2', '2. Phí giao dịch', '3', '3. Lãi margin','4', '4. Phí ứng trước') as Nt,
                                  nvl(f.biz_prd_cd, '!'),
                                  nvl(g.biz_cmsn_grp_cd, '!') as t1, nvl(g.system_cutoff_rt, '0') as t2, nvl(g.net_fee_yn, '!') as t3,
                                  nvl(h.biz_cmsn_grp_cd, '!') as t4, nvl(h.system_cutoff_rt, '0') as t5, nvl(h.net_fee_yn, '!') as t6,
                                  nvl(i.biz_cmsn_grp_cd, '!') as t7, nvl(i.system_cutoff_rt, '0') as t8, nvl(i.net_fee_yn, '!') as t9,
                                  nvl(j.biz_cmsn_grp_cd, '!') as t11, nvl(j.system_cutoff_rt, '0') as t12, nvl(j.net_fee_yn, '!') as t13,
                                  nvl(k.biz_cmsn_grp_cd, '!') as t14, nvl(k.system_cutoff_rt, '0') as t15, nvl(k.net_fee_yn, '!') as t16,
                                  nvl(l.biz_cmsn_grp_cd, '!') as t17, nvl(l.system_cutoff_rt, '0') as t18, nvl(l.net_fee_yn, '!') as t19,
                                  nvl(m.brch_cd, '!') as brch_cd, nvl(n.dept_cd, '!') as dept_cd,
                                  nvl(f.biz_cmsn_tp, '!') as biz_cmsn_tp, nvl(a.biz_emp_tp, '!') as biz_emp_tp
                  from xca01m01 a
                  left join xca01c01 b
                       on a.posi_cd = b.posi_cd
                       and a.biz_emp_tp in ('2', '3')
                  join xcc90m00 m
                       on a.brch_cd = m.brch_cd
                       and a.agnc_brch = m.agnc_brch
                     --  and a.agnc_brch = '00'
                  join xcc90m01 n
                       on a.dept_cd = n.dept_cd
                  left join quota_dept c
                       on a.emp_no = c.emp_no
                  left join rms02m00 d
                       on a.posi_cd = d.dept_posi_cd
                       and d.quota_tp = '1'
                  join (select max(c.id) as cid from rms02m00 c where c.apy_dt < vn.vwdate() and c.active_stat = 'Y' group by c.dept_posi_cd) p
                       on d.id = p.cid
                  left join rms04m00 e
                       on a.emp_no = e.emp_no
                       and i_date between e.apy_dt and e.expr_dt
                       and e.active_stat = 'Y'
                  left join rms03m00 f
                        on e.biz_prd_cd = f.biz_prd_cd
                  left join prd g
                       on f.biz_prd_cd = g.biz_prd_cd
                       and g.biz_cmsn_knd = '1'
                  left join prd h
                       on f.biz_prd_cd = h.biz_prd_cd
                       and h.biz_cmsn_knd = '2'
                  left join prd i
                       on f.biz_prd_cd = i.biz_prd_cd
                       and i.biz_cmsn_knd = '3'
                  left join prd j
                       on f.biz_prd_cd = j.biz_prd_cd
                       and j.biz_cmsn_knd = '4'
                  left join prd k
                       on f.biz_prd_cd = k.biz_prd_cd
                       and k.biz_cmsn_knd = '5'
                  left join prd l
                       on f.biz_prd_cd = l.biz_prd_cd
                       and j.biz_cmsn_knd = '6'
                  order by brch, dept
           ) emp
           where emp.brch_cd like i_brch_cd
           and emp.dept_cd in (select sub_no
                                  from (
                                         select sub_no
                                         from table  (vn.fbm_get_sub_item_hier(
                                                      '3',            -- i_tp             varchar2(15),
                                                      i_dept_no,       -- i_mng_emp_no     varchar2(15),
                                                      vwdate          -- i_dt             varchar2(8)
                                                      )
                                                  )
                                  ))
           and emp.biz_cmsn_tp like i_biz_cmsn_tp
           and emp.emp_no like i_emp_no
           and emp.biz_emp_tp like i_biz_emp_tp
           and emp.biz_emp_tp in ('2', '3')
           and vn.fxc_check_emp_emp_rgt(i_user_id, emp.emp_no , vn.vwdate()) = 'Y';
     return o_cursor;
end;
/

