create PROCEDURE PVSD_MT598_OPEN_CLOSE(i_sec_cd  IN VARCHAR2,
                                                  i_tp      IN VARCHAR2,
                                                  i_biz_cd  IN VARCHAR2,
                                                  i_acnt_no IN VARCHAR2
                                                  )
/*************************************************
  i_tp:
    1: Mo tai khoan giao dich chung khoan PS cua NDT
    2: Dong tai khoan giao dich chung khoan PS cua NDT
  i_biz_cd:
    600: TK
  i_acnt_no:
    acnt_no vd 068C555004
  *************************************************/
 AS
  p_frgn_tp       varchar2(1); --1:dominic 2:foreign
  p_acnt_tp       VARCHAR2(10); --DOMIND/FORIND/DOMCORP/FORCORP
  p_idno          VARCHAR2(20);
  p_trading_cd    varchar2(20);
  p_idno_tp       VARCHAR2(5); --IDNO/VSDT/CORP/OTHR/FIIN/ARNU/GOVT
  p_curr_cd       VARCHAR2(3); --SELECT * FROM AAA03C20
  p_cust_nm       VARCHAR2(250);
  p_addr          VARCHAR2(1000);
  p_idno_iss_dt   VARCHAR2(10);
  p_idno_iss_orga VARCHAR2(1000); -- / thay bang ?_?
  p_frgn_iss_dt   varchar2(10);
  p_frgn_iss_orga varchar2(1000);
  p_email         VARCHAR2(50); -- @ thay bang (at)
  p_tel           VARCHAR2(20);
  p_netted           VARCHAR2(4);
  p_trade_acnt_no varchar2(10); -- add column for saving trading acnt_no
  p_msg_nm        varchar2(200);
  v_send_dat      VARCHAR2(4000);
  v_idno          varchar2(30);
  v_trading_cd    varchar2(30);
  v_addr          VARCHAR2(1000);
  v_idno_iss_orga VARCHAR2(1000);
  v_email         varchar2(50);
  v_seq      NUMBER := 0;
BEGIN
  vn.pxc_log_write('PVSD_MT598_OPEN_CLOSE', 'Type: ' || i_tp || ' - ACNT: ' || i_acnt_no);
  Begin
    SELECT a.cust_nm,
           vn.faa_acnt_frgn_tp_g(i_acnt_no,'00'),
           a.idno,
           faa_to_yyyymmdd(faa_acnt_iss_dt_orga_g(i_sec_cd,'1',i_acnt_no,'00')),/*dt*/
           faa_acnt_iss_dt_orga_g(i_sec_cd,'2',i_acnt_no,'00'),/*orga*/
           nvl(frgn_trd_cd,' '),
           nvl(frgn_iss_dt,' '),
           nvl(frgn_iss_orga,' '),           
           decode(b.idno_tp,'1','IDNO','2','VSDT','3','CORP','4','OTHR','5','FIIN','6','ARNU','7','GOVT'),
           faa_acnt_no_tp_g(i_acnt_no, '00', '2'),/*DOMIND,FORIND,DOMCORP,FORCORP*/
           faa_curr_cd_g(faa_ctry_cd_g('2', a.idno)),
           faa_acnt_net_g(i_acnt_no, '2'),
           faa_acnt_contact_addr_g(i_acnt_no, '00'),
           faa_acnt_contact_tel_g(i_acnt_no, '00'),
           faa_acnt_email_g(i_sec_cd, i_acnt_no, '00')
      INTO p_cust_nm,
           p_frgn_tp,
           p_idno,
           p_idno_iss_dt,
           p_idno_iss_orga,
           p_trading_cd,
           p_frgn_iss_dt,
           p_frgn_iss_orga,
           p_idno_tp,
           p_acnt_tp,
           p_curr_cd,
           p_netted,
           p_addr,
           p_tel,
           p_email
      FROM vn.aaa01m00 a,
           vn.aaa02m00 b
     WHERE a.idno = b.idno
     AND   a.acnt_no = i_acnt_no
     AND   a.sub_no = '00';
     EXCEPTION
        WHEN OTHERS THEN
          vn.pxc_log_write('PVSD_MT598_OPEN_CLOSE'
                  ,'ERROR i_acnt_no: ' || i_acnt_no);
  End;
  
  Begin
    select nvl(acnt_tat,' ') 
    into    p_trade_acnt_no
    from vn.draaam00 
    where acnt_no = i_acnt_no
    and sub_no = '80';
    EXCEPTION
        WHEN OTHERS THEN
          vn.pxc_log_write('PVSD_MT598_OPEN_CLOSE'
                  ,'ERROR TAT i_acnt_no: ' || i_acnt_no);
    End;
  BEGIN
        vn.pcom_nextseq('vsd01m00_seq', v_seq);
      EXCEPTION
        WHEN OTHERS THEN
          vn.pxc_log_write('PVSD_MT598_OPEN_CLOSE'
                  ,' Loi pcom_nextseq: ' || SQLCODE);
          /*seq_no is unique*/
          raise_application_error(-20100
                       ,SQLCODE || ': ' || SQLERRM);
  END;
  vn.pxc_log_write('PVSD_MT598_OPEN_CLOSE', 'nextseq: ' || v_seq);
  v_idno          := replace(p_idno, '/', '?_?');
  v_trading_cd    := replace(p_trading_cd, '/', '?_?');
  v_addr          := replace(p_addr, '/', '?_?');
  v_idno_iss_orga := replace(p_idno_iss_orga, '/', '?_?');
  v_email         := replace(p_email, '@', '(at)');
  IF i_tp = '1' THEN
    select ':20:' || v_seq || chr(13) || ':12:' || '600' ||
                  chr(13) || ':77E:TAM' || chr(13) || ':16R:GENL' ||
                  chr(13) || ':23G:NEWM' || chr(13) || ':22H::ACCT//AOPN' ||
                  chr(13) || ':98A::PREP//' || to_char(SYSDATE, 'yyyymmdd') ||
                  chr(13) || ':16S:GENL' || chr(13) || ':16R:REGDET' ||
                  chr(13) || ':97A::SAFE//' || i_acnt_no || chr(13) ||
                  ':95Q::INVE//' || p_cust_nm || chr(13) ||
                  ':95S::ALTE/VISD/' || p_idno_tp || '/' || p_curr_cd || '/' ||
                  decode(p_frgn_tp, '1', v_idno, '2', v_trading_cd, ' ') || chr(13) || 
                  ':98A::ISSU//' || decode(p_frgn_tp, '1', p_idno_iss_dt, '2', p_frgn_iss_dt, ' ') ||
                  chr(13) || ':94G::ISSU//' || decode(p_frgn_tp, '1', v_idno_iss_orga, '2', p_frgn_iss_orga, ' ') || chr(13) ||
                  ':94G::EMAI//' || v_email || chr(13) || ':94G::PHON//' ||
                  p_tel || chr(13) || ':94G::ADDR//' || v_addr || chr(13) ||
                  ':70E::ADTX//TA//'|| i_acnt_no || chr(13) || 'NETT//' || p_netted ||
                  chr(13) || 'TYPE//' || p_acnt_tp || chr(13) || ':16S:REGDET'
    into v_send_dat from dual              ;
    vn.pvsd_get_msg_nm('598', v_seq, v_send_dat, p_msg_nm);
    Begin              
      INSERT INTO VN.DRVSDM00
        (REG_DT, SEQ_NO, BIZ_CD, DAT_TP, DAT_CD, SND_DAT, SND_TP, WORK_DTM, MSG_NM, MARK_TP)
      VALUES
        (to_char(SYSDATE, 'yyyymmdd'),
         v_seq,
         i_biz_cd,
         i_tp,
         '598',
         v_send_dat,
         '1',
         SYSDATE,
         p_msg_nm,
         i_acnt_no);
     EXCEPTION
        WHEN OTHERS THEN
          vn.pxc_log_write('PVSD_MT598_OPEN_CLOSE','ERROR insert DRVSDM00');
     End;    
  ELSIF i_tp = '2' THEN
    v_send_dat := ':20:' || v_seq || chr(13) || ':12:' || '600' ||
                  chr(13) || ':77E:TAM' || chr(13) || ':16R:GENL' ||
                  chr(13) || ':23G:NEWM' || chr(13) || ':22H::ACCT//ACLS' ||
                  chr(13) || ':98A::PREP//' || to_char(SYSDATE, 'yyyymmdd') ||
                  chr(13) || ':16S:GENL' || chr(13) || ':16R:REGDET' ||
                  chr(13) || ':97A::SAFE//' || i_acnt_no || chr(13) ||
                  ':95Q::INVE//' || p_cust_nm || chr(13) ||
                  ':95S::ALTE/VISD/' || p_idno_tp || '/' || p_curr_cd || '/' ||
                  v_idno || chr(13) || ':98A::ISSU//' || p_idno_iss_dt ||
                  chr(13) || ':94G::ISSU//' || v_IDNO_ISS_ORGA || chr(13) ||
                  ':94G::EMAI//' || v_EMAIL || chr(13) || ':94G::PHON//' ||
                  p_tel || chr(13) || ':94G::ADDR//' || v_ADDR || chr(13) ||
                  ':70E::ADTX//TA//'|| i_acnt_no || chr(13) || 'NETT//' || p_netted ||
                  chr(13) || 'TYPE//' || p_acnt_tp || chr(13) || ':16S:REGDET';
    vn.pvsd_get_msg_nm('598', v_seq, v_send_dat, p_msg_nm);              
    INSERT INTO VN.DRVSDM00
      (REG_DT, SEQ_NO, BIZ_CD, DAT_TP, DAT_CD, SND_DAT, SND_TP, WORK_DTM, MSG_NM)
    VALUES
      (to_char(SYSDATE, 'yyyymmdd'),
       v_seq,
       i_biz_cd,
       i_tp,
       '598',
       v_send_dat,
       '1',
       SYSDATE,
       p_msg_nm);
       -- danh cho tk TAT
  ELSIF i_tp = '3' THEN
    v_send_dat := ':20:' || v_seq || chr(13) || ':12:' || '602' ||
                  chr(13) || ':77E:TAT' || chr(13) || ':16R:GENL' ||
                  chr(13) || ':23G:NEWM' || chr(13) || ':22H::ACCT//AOPN' ||
                  chr(13) || ':98A::PREP//' || to_char(SYSDATE, 'yyyymmdd') ||
                  chr(13) || ':16S:GENL' || chr(13) || ':16R:REGDET' ||
                  chr(13) || ':97A::SAFE//' || i_acnt_no || chr(13) ||
                  ':95Q::INVE//' || p_cust_nm || chr(13) ||
                  ':95S::ALTE/VISD/' || p_idno_tp || '/' || p_curr_cd || '/' ||
                  v_idno || chr(13) || ':98A::ISSU//' || p_idno_iss_dt ||
                  chr(13) || ':94G::ISSU//' || v_idno_iss_orga || chr(13) ||
                  ':94G::EMAI//' || v_email || chr(13) || ':94G::PHON//' ||
                  p_tel || chr(13) || ':94G::ADDR//' || v_addr || chr(13) ||
                  ':70E::ADTX//TA//'|| p_trade_acnt_no || chr(13) || 'NETT//' || p_netted ||
                  chr(13) || 'TYPE//' || p_acnt_tp || chr(13) || ':16S:REGDET';
    vn.pvsd_get_msg_nm('598', v_seq, v_send_dat, p_msg_nm);              
    INSERT INTO VN.DRVSDM00
      (REG_DT, SEQ_NO, BIZ_CD, DAT_TP, DAT_CD, SND_DAT, SND_TP, WORK_DTM, MSG_NM, MARK_TP)
    VALUES
      (to_char(SYSDATE, 'yyyymmdd'),
       v_seq,
       i_biz_cd,
       i_tp,
       '598',
       v_send_dat,
       '1',
       SYSDATE,
       p_msg_nm,
       i_acnt_no);
  END IF;
END PVSD_MT598_OPEN_CLOSE;
/

