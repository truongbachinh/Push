create procedure    pss_get_sbst_prof_q
(
    i_acnt_no               in        varchar2   -- account no
,   i_sub_no                in        varchar2   -- sub_no no
,   i_bank_cd               in        varchar2   -- bank_cd (invest customer  : 9999 )

,   o_prof_sbst             out       number     --
)
AS

/*
   \file     pss_get_sbst_prof_q

   Notice : this amt is can't not use same time             by jung

   \section intro Program Information
        - Program Name              : get block amount
        - Service Name              : N/A
        - Related Client Program- Client Program ID :
        - Related Tables            : all  table
        - Dev. Date                 : 2010 /06/ 24
        - Developer                 : JUNG
        - Business Logic Desc.      : Get order block amount  for  sbst
        - Latest Modification Date  :

   \section history Program Modification History

   \section hardcoding Hard-Coding List
    - HC-1

   \section info Additional Reference Comments

*/

    t_err_txt           varchar2(500) ;  -- error text buffer

    t_err_msg           varchar2(500);
    t_err_code          varchar2(5);
    ts_lnd_tp           varchar2(10);

    t_nonrpy_loan_amt   number := 0 ;
	t_lack_amt          number := 0 ;

    t_max_dpo           number := 0 ;
    t_sbst_mth          number := 0 ;
    t_lack_sbst         number := 0 ;
    t_max_reuse         number := 0 ;

    t_reuse             number := 0 ;
    t_sbst_diff         number := 0 ;  -- total sbst dpo or mathed ( buy - sell )
    t_temp              number := 0 ;

	t_used_alowa_rel    number := 0 ;
	t_used_alowa_cd     number := 0 ;
	t_used_alowa_vd     number := 0 ;

    t_used_all_rel      number := 0 ;
    t_used_all_cd       number := 0 ;
    t_used_all_vd       number := 0 ;

	t_tot_prof          number := 0 ;
	t_tot_block         number := 0 ;

	t_mrgn_expt_amt     number := 0 ;
	t_crd_dpo           number := 0 ;

	t_vrt_sbst          number := 0 ;


begin

	o_prof_sbst   :=  0   ;


    vn.pxc_log_write('pss_get_sbst_prof_q','i_acnt_no [ '||i_acnt_no ||' ] [ ' || i_bank_cd ||']');
    vn.pxc_log_write('pss_get_sbst_prof_q','i_sub_no [ '||i_sub_no ||' ] [ ' || i_bank_cd ||']');

/*============================================================================*/
/* 현금사용금액취득 CALL                                              */
/*============================================================================*/

   ts_lnd_tp := '%' ;

   /* VCSC -256 don't limited non - reply loan */

   if vn.faa_reply_tp_g(  i_acnt_no, i_sub_no ) = 'Y'  then

      t_nonrpy_loan_amt := vn.fdl_get_nonrpy_amt( ts_lnd_tp, i_acnt_no, i_sub_no, i_bank_cd) ;

   else

      t_nonrpy_loan_amt := 0 ;

   end if  ;

   vn.pxc_log_write('pss_get_sbst_prof_q','nonrpy_loan_amt-'|| t_nonrpy_loan_amt);
   t_lack_amt := Greatest ( vn.fdl_get_mrgn_rt_01( i_acnt_no , i_sub_no,  '11' , vn.vwdate ) , vn.fdl_get_mrgn_rt_01( i_acnt_no , i_sub_no, '12' , vn.vwdate ) )  ; /* shortage amount of evaluation */

   vn.pxc_log_write('pss_get_sbst_prof_q','shortage amount of evaluation ['|| t_lack_amt ||']');

   BEGIN
    vn.pts_acnt_prof_g(i_acnt_no             ,
					   i_sub_no              ,
                       i_bank_cd             ,
                       t_used_alowa_rel      ,  -- dpo amt
                       t_used_all_rel        ,  -- total dpo amt
                       t_used_alowa_cd       ,  -- creadit amt
                       t_used_all_cd         ,  -- total creadit amt
                       t_used_alowa_vd       ,  -- VD amt
                       t_used_all_vd         ,  -- total vd amt
					   t_reuse               ,  --
					   t_sbst_diff          ,  -- before settle
					   t_temp                ,
					   t_temp                ,
                       t_err_code            ,
                       t_err_txt);
   EXCEPTION
   WHEN  OTHERS         THEN
            vn.pxc_log_write('pss_get_sbst_prof_q','pts_acnt_prof_g -'||'err');
            t_err_msg := vn.fxc_get_err_msg('V',t_err_code);
            raise_application_error(-20100,t_err_msg||' '||t_err_txt);
   END;

   vn.pxc_log_write('pss_get_sbst_prof_q','dpo_prof          [ '|| t_used_alowa_rel      || ' ]' );
   vn.pxc_log_write('pss_get_sbst_prof_q','cd_prof           [ '|| t_used_alowa_cd       || ' ]' );
   vn.pxc_log_write('pss_get_sbst_prof_q','vd_prof           [ '|| t_used_all_vd         || ' ]' );
   vn.pxc_log_write('pss_get_sbst_prof_q','t_reuse           [ '|| t_reuse               || ' ]' );
   vn.pxc_log_write('pss_get_sbst_prof_q','t_sbst_tso02      [ '|| t_sbst_diff           || ' ]' );

   t_tot_prof      :=  t_used_alowa_rel  +  t_used_all_vd  ;

   /*
	  Get expected margin loan + already issued margin loan
	  If there is no margin loan, Margin deposit(10M) doesn't need to be blocked.
	  else Margin deposit(10M) need to block
   */
   t_mrgn_expt_amt :=  vn.fdl_get_mrgn_expt_amt( i_acnt_no, i_sub_no, '3');

   select nvl(crd_dpo, 0)
	 into t_crd_dpo
	 from vn.cwd01m00
    where acnt_no = i_acnt_no
	  and sub_no  = i_sub_no;

   if t_mrgn_expt_amt = 0 or i_sub_no = '00' then
	  t_crd_dpo := 0;
   end if;

   vn.pxc_log_write('pss_get_sbst_prof_q','total_prof [ '|| t_tot_prof || ' ]' );

   BEGIN
     select  nvl(dpo   , 0)
             - nvl(dpo_block , 0)  - nvl(outq_dpo_bk , 0)  - Greatest ( t_nonrpy_loan_amt  , 0 )
		     - t_crd_dpo  - nvl(t_used_all_cd , 0 )
           , nvl(rgt_sbst   , 0 ) + t_sbst_diff
		   , nvl(sbst_proof , 0 ) + t_lack_amt
         , Greatest ( nvl(rgt_reuse , 0 ) + t_reuse - vn.fdl_get_mrgn_rt_01( i_acnt_no , i_sub_no, '07' , vn.vwdate) , 0 ) --pia
       into  t_max_dpo
		   , t_sbst_mth
           , t_lack_sbst
           , t_max_reuse
       from vn.cwd01m00
      where acnt_no = i_acnt_no
		and sub_no  = i_sub_no;
   EXCEPTION
   WHEN  OTHERS         THEN
      t_err_txt  :=    'cwd01m00  err:'
                   ||  to_char(sqlcode);
            t_err_msg := vn.fxc_get_err_msg('V','2704');
            raise_application_error(-20100,t_err_msg||t_err_txt);
   END;

   vn.pxc_log_write('pss_get_sbst_prof_q','rgt+mth sbst [ '|| t_sbst_mth  || ' ]' );

   t_tot_block := t_tot_prof + t_lack_sbst
				  + vn.fdl_get_mrgn_rt_01( i_acnt_no , i_sub_no, '14' , vn.vwdate)
				  + vn.fdl_get_mrgn_rt_01( i_acnt_no , i_sub_no, '10' , vn.vwdate)
				  + vn.fdl_get_mrgn_rt_01( i_acnt_no , i_sub_no, '19' , vn.vwdate)
				  + vn.fdl_get_buy_diff_amt(i_acnt_no, i_sub_no,  '%', '1') ;

   /* 10 : Margin loan amount ,
	  14 : Money loan
	  19 : fee                */

   vn.pxc_log_write('pss_get_sbst_prof_q','tot_block   [ '|| t_tot_block || ' ]' );
   vn.pxc_log_write('pss_get_sbst_prof_q','able_dpo    [ '|| t_max_dpo   || ' ]' );
   vn.pxc_log_write('pss_get_sbst_prof_q','able_reuse  [ '|| t_max_reuse || ' ]' );
   vn.pxc_log_write('pss_get_sbst_prof_q','lack_sbst   [ '|| t_lack_sbst || ' ]' );

   o_prof_sbst :=  Greatest(  t_tot_block - t_sbst_mth - t_max_dpo  -  t_max_reuse , 0 ) ;

   vn.pxc_log_write('pss_get_sbst_prof_q','prof_sbst  [ '|| o_prof_sbst || ' ]' );

end pss_get_sbst_prof_q;
/

