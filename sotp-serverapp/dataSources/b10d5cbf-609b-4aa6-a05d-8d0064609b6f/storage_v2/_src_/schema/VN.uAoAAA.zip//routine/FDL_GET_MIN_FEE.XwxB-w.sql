create FUNCTION fdl_get_min_fee
(
	i_lnd_bank_cd  in 		varchar2,
    i_lnd_dt       in 		varchar2
) return number is

    t_min_fee      number := 0 ;

begin

    begin
	    select  nvl(lnd_apy_val,0) lnd_apy_val
          into  t_min_fee
          from  vn.dlm12m10
         where  lnd_tp       =  '10'
           and  lnd_bank_cd  =  i_lnd_bank_cd
           and  cpt_rpy_tp   =  '1'
           and  int_rpy_tp   =  '1'
           and  lnd_apy_val_tp = '13'
           and  (apy_dt)
                in (select  max(apy_dt)
                      from  vn.dlm12m10
                     where  lnd_tp       =  '10'
                       and  lnd_bank_cd  =  i_lnd_bank_cd
                       and  cpt_rpy_tp   =  '1'
                       and  int_rpy_tp   =  '1'
                       and  apy_dt      <=  i_lnd_dt
                       and  lnd_apy_val_tp = '13');

    EXCEPTION
         WHEN   OTHERS THEN
		 return 0 ;
    END;

    return t_min_fee ;

end fdl_get_min_fee;
/

