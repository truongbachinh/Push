create function fbm_get_biz_cmsn_amt(
    i_biz_cmsn_grp_cd           varchar2,
    i_emp_exp_tp                varchar2,
    i_dt                        varchar2,
    i_trd_amt_for_cmsn_rt       number,
    i_trd_amt_for_cmsn_amt      number
    
)
/*
    select fbm_get_biz_cmsn_amt(
        'HHMGC1_TPT',       -- i_biz_cmsn_grp_cd       varchar2,
        '0',                -- i_emp_exp_tp            varchar2,
        vwdate,             -- i_dt                    varchar2,
        1234567890          -- i_trd_amt               number
    ) cmsn_amt
    from dual;
*/
return number

as
    t_biz_cmsn_grp_id       number;
    t_cmsn_cal_tp           varchar2(1);
    t_cmsn_val_tp           varchar2(1);
    t_max_apy_dt            varchar2(8);
    t_emp_exp_tp            varchar2(2);

    t_proc_nm               varchar2(30)    := 'fbm_get_biz_cmsn_amt';
    t_vwdate                varchar2(8)     := vwdate;
    t_err_msg               varchar2(500)   := ' ';

    t_cmsn_amt              number;
    o_cmsn_amt              number;

begin
    begin
        select cmsn_cal_tp, cmsn_val_tp
        into t_cmsn_cal_tp, t_cmsn_val_tp
        from (
            select cmsn_cal_tp, cmsn_val_tp
            from vn.rms01m00
            where biz_cmsn_grp_cd = i_biz_cmsn_grp_cd
            -- and emp_exp_tp in ('0', i_emp_exp_tp)
            -- order by emp_exp_tp desc
        )
        where rownum = 1
        ;

        /* Quy uoc khi setup: Neu muon them moi, hoac thay doi ti le setup, can phai thay doi lai toan bo cac range value */
        select max(apy_dt) max_apy_dt
        into t_max_apy_dt
        from vn.rms01m01
        where biz_cmsn_grp_cd = i_biz_cmsn_grp_cd
        and apy_dt <= i_dt
        and active_stat = 'Y'
        group by biz_cmsn_grp_cd;

        select emp_exp_tp
        into t_emp_exp_tp
        from (
            select emp_exp_tp
            from vn.rms01m01
            where biz_cmsn_grp_cd = i_biz_cmsn_grp_cd
            and apy_dt <= i_dt
            and active_stat = 'Y'
            and apy_dt = t_max_apy_dt
            and emp_exp_tp in ('0', i_emp_exp_tp)
            order by emp_exp_tp desc
        )
        where rownum = 1
        ;

        if(t_cmsn_cal_tp = '1') then     -- luy tien tung phan
            with biz_cmsn_amt as(
                select
                    case
                        when t_cmsn_val_tp = '1' then           -- Fix value
                            r.cmsn_val
                        else                                    -- Rate
                            case when i_trd_amt_for_cmsn_rt > r.max_amt
                                then (r.max_amt - r.min_amt + 1) * r.cmsn_val
                            else
                                (i_trd_amt_for_cmsn_amt - r.min_amt + 1) * r.cmsn_val
                            end
                    end     cmsn_amt
                from vn.rms01m01 r
                where i_trd_amt_for_cmsn_rt >= r.min_amt
                and r.apy_dt = t_max_apy_dt
                and r.active_stat = 'Y'
                and r.emp_exp_tp = t_emp_exp_tp
            )
            select sum(cmsn_amt) tot_cmsn_amt
            into t_cmsn_amt
            from biz_cmsn_amt
            ;

        else                                -- Luy tien toan phan
            select
                case
                    when t_cmsn_val_tp = '1' then           -- Fix value
                        r.cmsn_val
                    else                                    -- Rate
                        i_trd_amt_for_cmsn_amt * r.cmsn_val
                end     cmsn_amt
            into t_cmsn_amt
            from vn.rms01m01 r
            where r.biz_cmsn_grp_cd = i_biz_cmsn_grp_cd
            and r.apy_dt = t_max_apy_dt
            and i_trd_amt_for_cmsn_rt between r.min_amt and r.max_amt
            and r.active_stat = 'Y'
            and r.emp_exp_tp = t_emp_exp_tp
            /*
            and r.max_amt = (select max(max_amt) max_amt
                            from rms01m01
                            where biz_cmsn_grp_cd = i_biz_cmsn_grp_cd
                            and apy_dt = t_max_apy_dt)
            */
            ;
        end if;
    exception
        when no_data_found then
            t_cmsn_amt := 0;
        when others then
            t_err_msg  := 'Error when getting data for:' 
                            || ' i_biz_cmsn_grp_cd: '   || i_biz_cmsn_grp_cd
                            || ' i_dt: '                || i_dt
                            || ' i_emp_exp_tp: '        || i_emp_exp_tp
                            || '. '
                            || sqlcode || ' - ' || sqlerrm;
            vn.pxc_log_write(t_proc_nm, t_err_msg);
            raise_application_error(-20100,t_err_msg);

    end;

    o_cmsn_amt  := round(t_cmsn_amt);

    return o_cmsn_amt;
end;
/

