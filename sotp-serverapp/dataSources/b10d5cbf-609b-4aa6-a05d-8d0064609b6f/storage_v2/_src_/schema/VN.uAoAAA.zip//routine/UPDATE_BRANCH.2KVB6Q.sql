create procedure    update_branch (i_branch varchar2, i_bank_acnt_no varchar2) 
as 
    t_branch varchar2(8);
begin


    select nvl(branch,'0') into t_branch
    from vn.aaa09m00
    where bank_acnt_no = i_bank_acnt_no ;

    if t_branch = '0' then
        update vn.aaa09m00
        set branch = i_branch 
        where bank_acnt_no = i_bank_acnt_no ;
    end if;
    exception when others then
        null;
end;
/

