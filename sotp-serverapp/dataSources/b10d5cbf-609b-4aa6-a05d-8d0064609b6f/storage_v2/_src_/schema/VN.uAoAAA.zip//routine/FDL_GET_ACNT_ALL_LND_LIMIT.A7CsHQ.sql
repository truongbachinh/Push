create function    fdl_get_acnt_all_lnd_limit 
	(i_acnt_no varchar2,
	 i_sub_no varchar2,
	 i_src_no varchar2,
	 i_prd_no varchar2,
	 i_grp_acnt_no varchar2,
	 i_day_tp  VARCHAR2
	) return number
as
  /*!
     \file     fdl_get_stk_sum_lnd_limit.sql
     \brief    fdl_get_stk_sum_lnd_limit
     \section intro Program Information
          - Program Name              : 
          - Service Name              :
          - Related Client Program- Client Program ID :
          - Related Tables            : dlm51m00, dlm90m00, dlm00m01
          - Dev. Date                 : 2018/05/21
          - Developer                 : GiangLH.
          - Business Logic Desc.      : fdl_get_stk_sum_lnd_limit
          - Latest Modification Date  : 2018/05/21
   */
  t_src_lnd_limit number;
  t_prd_lnd_limit number;
  t_grp_acnt_lnd_limit number;
-- Neu i_day_tp = '1'- Su dung trong ngay: Co cong them so luong du kien vay (extp) vao so da dung
-- Neu i_day_tp ='2' - Cuoi ngay: Khong cong them so luong du kien vay (extp) vao so da dung
begin
	/*
	=> Cong thuc HM cho TK A theo nguon S, san pham P, nhom TK G la
	RLL(A,S,P,G) = Min[RLL(S,A),RLL(P,A),RLL(G,A)]
	*/

    t_src_lnd_limit := vn.fdl_get_acnt_lnd_limit (i_acnt_no, i_sub_no, '03', i_src_no, i_day_tp); --Nguon
    t_prd_lnd_limit := vn.fdl_get_acnt_lnd_limit (i_acnt_no, i_sub_no, '02', i_prd_no, i_day_tp); --SP
    t_grp_acnt_lnd_limit := vn.fdl_get_acnt_lnd_limit (i_acnt_no, i_sub_no, '08', i_grp_acnt_no, i_day_tp); --Nhom TK Margin

    return  LEAST(t_src_lnd_limit, t_prd_lnd_limit, t_grp_acnt_lnd_limit);

end fdl_get_acnt_all_lnd_limit;
/

