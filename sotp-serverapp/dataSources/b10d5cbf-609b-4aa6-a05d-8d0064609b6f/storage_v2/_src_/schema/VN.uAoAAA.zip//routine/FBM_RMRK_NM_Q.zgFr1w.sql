create function fbm_rmrk_nm_q
(
    i_rmrk_cd   in   varchar2
)
    return          varchar2
as
    o_rmrk_nm    varchar2(100) ;
    o_use_yn        varchar2(1)   ;
    t_err_txt       varchar2(100) ; -- error text buffer

begin

/*============================================================================*/
/* º¯¼ö ÃÊ±âÈ­                                                                */
/*============================================================================*/
    o_rmrk_nm  :=  NULL;
    o_use_yn  :=  NULL;

/*============================================================================*/
/* »ç¿ø¸í Á¶È¸                                                                */
/*============================================================================*/
    begin
        select nvl(rmrk_cd_nm, ' '),
--               nvl(use_yn, ' ')
--        select 'Test-'||nvl(rmrk_cd, ' '),
               nvl(use_yn, ' ')
      into o_rmrk_nm,
           o_use_yn
          from vn.bmi02c00
         where rmrk_cd  = i_rmrk_cd;
    exception
        when  NO_DATA_FOUND  then
      return  'XXXXX';
        when  OTHERS         then
            t_err_txt  :=  'Loi'||to_char(sqlcode)||']';
            raise_application_error (-20100, t_err_txt);
    end;

    if o_use_yn = 'N' then
      return  'XXXXX';
    else
      return  o_rmrk_nm;
    end if;

end fbm_rmrk_nm_q;
/

