create procedure pts_bat_tso01h00_ins (
    i_work_dt       in      varchar2,       -- date(yyyymmdd)
	o_err_code      in      number,         -- error code(0:SUCCESS)
	o_err_msg       in      varchar2,       -- error message
	o_proc_cnt      out     number          -- proc data count
) as

t_err_code      number        := o_err_code;
t_err_msg       varchar2(600) := rtrim(o_err_msg);
t_chk           varchar2(1);
cnt             number;
exp_error       exception;

/*!
    \file     pts_bat_tso10h00_ins
	\brief    tso01m00 select, tso01h00 insert
	  
	\section intro Program Information
		- Program Name              : pts_bat_tso01h00_ins
		- Service Name              :
		- Related Client Program- Client Program ID :
		- Related Tables            : tso01m00, tso01h00
		- Dev. Date                 : 2007/11/27
		- Developer                 : ejlee
		- Business Logic Desc.      :
		- Latest Modification Date  :
	
	\section history Program Modification History
		- 1.0  2007/11/27
																				
	\section hardcoding Hard-Coding List
																				   
	\section info Additional Reference Comments
*/

begin

	t_err_code := 0;
	t_err_msg  := 'SUCCESS';
	t_chk      := 'Y';
    o_proc_cnt := 0;
	cnt        := 0;

	-- 1. ?? ???? ?? ?? Fun??
	if t_chk = 'N' then
		t_err_code := -1;
	    t_err_msg  := '?? ???? ??????. ?? ?? ? ??????.!';
		raise_application_error(-20100,'[pts_bat_tso01h00_ins] ' || t_err_msg);
	else
		select 	count(*) 
		into	cnt
		from	tso01m00;
		
		if cnt > 0 then
			delete 	tso01h00
			where	stk_ord_dt = i_work_dt;
	        for  c1  in (
			    select  bnh_cd                  ,
					    ord_no                  ,
					    acnt_no                 ,
					    sub_no					,
					    stk_cd                  ,
					    ord_qty                 ,
					    ord_pri                 ,
					    ord_knd                 ,
					    sell_buy_tp             ,
					    mkt_trd_tp              ,
					    stk_ord_tp              ,
					    crrt_cncl_tp            ,
					    stk_tp                  ,
					    mdm_tp                  ,
					    prgt_ord_tp             ,
					    ord_time                ,
					    ord_veto_cau            ,
					    ord_accp_time           ,
					    org_ord_no              ,
					    first_org_ord_no        ,
					    cncl_qty                ,
					    crrt_qty                ,
					    cncl_cnfm_qty           ,
					    crrt_cnfm_qty           ,
					    mth_qty                 ,
					    mth_amt                 ,
					    nmth_qty                ,
					    org_ord_pri             ,
					    ord_prof_pri            ,
					    cash_prof_rt            ,
					    frgn_tp                 ,
					    sms_yn                  ,
						sms_proc_yn             ,
					    work_bnh                ,
					    kfx_accp_no             ,
					    kfx_cnfm_no             ,
					    if_seq_no               ,
					    dat_cd                  ,
					    sesn_tp                 ,
					    accp_tp                 ,
						org_ord_acnt_no         ,
						org_ord_sub_no			,
					    agnt_idno               ,
						acnt_mng_mn             ,
						proc_agnc_brch          ,
						agnc_brch_cd			,
						dept_cd					,
						ord_seq_no              ,
						brk_no                  ,
						opr_cmp_cd				,
						opr_acnt_no				,
						opr_sub_no				,
						prof_cls_yn				,
					    work_mn                 ,
					    work_dtm                ,
					    work_trm                ,
					    del_yn                  ,
					    emer_yn                 ,
					    org_emer_yn             ,
					    firm_id                 ,
					    bank_cd                 ,
					    bank_acnt_no            ,
					    cdt_tp                  ,
					    lnd_dt                  ,
					    mrtg_dt                 ,
					    mcd_tp                  ,
					    rpst_acnt_no            ,
					    ssr_rt                  ,
					    cer_rt                  ,
					    crr_rt                  ,
					    acnt_agnc_cd			,
					    bank_cnct_tp			,
					    oms_ord_no				,
						bank_sts				, /*bank on_off*/
						ord_no_stl				, /*ord_stop*/
						ord_stl_dt				, /*ord_stop*/
						ord_stl_tp 				  /*ord_stop*/
						,CERT_YN    				/*TT 134 add on 20181226*/
						,MAC_ADDR 	  				/*TT 134 add on 20181226*/		
            ,force_sell_yn
            ,ord_sign
            ,sign_mn
            ,sign_dtm
            ,sign_mdm
				  from  vn.tso01m00
	             ) loop
	
	             cnt := cnt + 1;
	
				 insert into vn.tso01h00
				 (      stk_ord_dt              ,
						bnh_cd                  ,
					    ord_no                  ,
					    acnt_no                 ,
					    sub_no					,
					    stk_cd                  ,
					    ord_qty                 ,
					    ord_pri                 ,
					    ord_knd                 ,
					    sell_buy_tp             ,
					    mkt_trd_tp              ,
					    stk_ord_tp              ,
					    crrt_cncl_tp            ,
					    stk_tp                  ,
					    mdm_tp                  ,
					    prgt_ord_tp             ,
					    ord_time                ,
					    ord_veto_cau            ,
					    ord_accp_time           ,
					    org_ord_no              ,
					    first_org_ord_no        ,
					    cncl_qty                ,
					    crrt_qty                ,
					    cncl_cnfm_qty           ,
					    crrt_cnfm_qty           ,
					    mth_qty                 ,
					    mth_amt                 ,
					    nmth_qty                ,
					    org_ord_pri             ,
					    ord_prof_pri            ,
					    cash_prof_rt            ,
					    frgn_tp                 ,
					    sms_yn                  ,
						sms_proc_yn             ,
					    work_bnh                ,
					    kfx_accp_no             ,
					    kfx_cnfm_no             ,
					    sesn_tp                 ,
					    accp_tp                 ,
						org_ord_acnt_no         ,
						org_ord_sub_no			,
					    agnt_idno               ,
						acnt_mng_mn             ,
						proc_agnc_brch          ,
						agnc_brch_cd			,
						dept_cd					,
						ord_seq_no              ,
						brk_no                  ,
						opr_cmp_cd				,
						opr_acnt_no				,
						opr_sub_no				,
						prof_cls_yn				,
					    work_mn                 ,
					    work_dtm                ,
					    work_trm                ,
					    del_yn                  ,
					    emer_yn                 ,
					    org_emer_yn             ,
					    firm_id                 ,
					    bank_cd                 ,
					    bank_acnt_no            ,
					    cdt_tp                  ,
					    lnd_dt                  ,
					    mrtg_dt                 ,
					    mcd_tp                  ,
					    rpst_acnt_no            ,
					    ssr_rt                  ,
					    cer_rt                  ,
					    crr_rt                  ,
					    acnt_agnc_cd			,
					    bank_cnct_tp			,
					    oms_ord_no				, 
						bank_sts				, /*bank_on_off*/
						ord_no_stl				, /*ord_stop*/
						ord_stl_dt				, /*ord_stop*/
						ord_stl_tp 				  /*ord_stop*/
						,cert_yn    				/*TT 134 add on 20181226*/
						,mac_addr 	  				/*TT 134 add on 20181226*/
					  ,force_sell_yn  
            ,ord_sign
            ,sign_mn
            ,sign_dtm
            ,sign_mdm
	            ) values (
				        i_work_dt               ,
						c1.bnh_cd               ,
					    c1.ord_no               ,
					    c1.acnt_no              ,
					    c1.sub_no				,
					    c1.stk_cd               ,
					    c1.ord_qty              ,
					    c1.ord_pri              ,
					    c1.ord_knd              ,
					    c1.sell_buy_tp          ,
					    c1.mkt_trd_tp           ,
					    c1.stk_ord_tp           ,
					    c1.crrt_cncl_tp         ,
					    c1.stk_tp               ,
					    c1.mdm_tp               ,
					    c1.prgt_ord_tp          ,
					    c1.ord_time             ,
					    c1.ord_veto_cau         ,
					    c1.ord_accp_time        ,
					    c1.org_ord_no           ,
					    c1.first_org_ord_no     ,
					    c1.cncl_qty             ,
					    c1.crrt_qty             ,
					    c1.cncl_cnfm_qty        ,
					    c1.crrt_cnfm_qty        ,
					    c1.mth_qty              ,
					    c1.mth_amt              ,
					    c1.nmth_qty             ,
					    c1.org_ord_pri          ,
					    c1.ord_prof_pri         ,
					    c1.cash_prof_rt         ,
					    c1.frgn_tp              ,
					    c1.sms_yn               ,
						c1.sms_proc_yn          ,
					    c1.work_bnh             ,
					    c1.kfx_accp_no          ,
					    c1.kfx_cnfm_no          ,
					    c1.sesn_tp              ,
					    c1.accp_tp              ,
						c1.org_ord_acnt_no      ,
						c1.org_ord_sub_no		,
					    c1.agnt_idno            ,
						c1.acnt_mng_mn          ,
						c1.proc_agnc_brch       ,
						c1.agnc_brch_cd			,
						c1.dept_cd				,
						c1.ord_seq_no           ,
						c1.brk_no               ,
						c1.opr_cmp_cd			,
						c1.opr_acnt_no			,
						c1.opr_sub_no			,
						c1.prof_cls_yn			,
					    c1.work_mn              ,
					    c1.work_dtm             ,
					    c1.work_trm             ,
					    c1.del_yn               ,
					    c1.emer_yn              ,
					    c1.org_emer_yn          ,
					    c1.firm_id              ,
                        c1.bank_cd              ,
                        c1.bank_acnt_no         ,
                        c1.cdt_tp               ,
                        c1.lnd_dt               ,
                        c1.mrtg_dt              ,
                        c1.mcd_tp               ,
                        c1.rpst_acnt_no         ,
                        c1.ssr_rt               ,
					    c1.cer_rt               ,
					    c1.crr_rt               ,
					    c1.acnt_agnc_cd			,
					    c1.bank_cnct_tp			,
					    c1.oms_ord_no			,
						c1.bank_sts				,	/*bank_on_off*/
						c1.ord_no_stl			,   /*ord_stop*/
						c1.ord_stl_dt			,   /*ord_stop*/
						c1.ord_stl_tp				/*ord_stop*/
						,c1.cert_yn    				/*TT 134 add on 20181226*/
						,c1.mac_addr 	  				/*TT 134 add on 20181226*/
	          ,c1.force_sell_yn  
            ,c1.ord_sign
            ,c1.sign_mn
            ,c1.sign_dtm
            ,c1.sign_mdm);
	
	        end loop;
    	end if;
    end if;

	o_proc_cnt := cnt;

	exception when  exp_error then
		t_err_code := sqlcode;
		t_err_msg  := sqlerrm;
		raise_application_error(-20100,'[pts_bat_tso01h00_ins] ' || t_err_msg);

end pts_bat_tso01h00_ins;
/

