create PROCEDURE pss_stk_bk_dmr_cty (i_proc_dt IN varchar2,
                                                       i_work_mn IN varchar2,
                                                       i_work_trm IN varchar2,
                                                       o_proc_cnt OUT number
)
IS
   /***************************************************************************/
   /* Dev: HueDT                                                              */
   /* 2019-02-19                                                              */
   /* Back up danh muc ro trang thai cho duyet xoa                            */
   /***************************************************************************/
BEGIN
vn.pxc_log_write('pss_stk_bk_dmr_cty','start');
vn.pxc_log_write('pss_stk_bk_dmr_cty','i_proc_dt: ' || i_proc_dt);
 o_proc_cnt  := 0;

    FOR c1
   IN (SELECT basket_cd,
              stk_cd,
              active_stat,
                cd_bp_rate,
                cd_bp_rate_af,
                cd_rate,
                cd_rate_af,
                delay_bp_rate,
                delay_bp_rate_af,
                delay_rate,
                delay_rate_af,
                rgt_bp_rate,
                rgt_bp_rate_af,
                rgt_rate,
                rgt_rate_af,
                cdr_bp,
                cdr_bp_af,
                cdr,
                cdr_af,
                lnd_limit_qty,
                lnd_limit_qty_af,
                lnd_limit_amt,
                lnd_limit_amt_af,
                lnd_lmt_pri,
                lnd_lmt_pri_af,
                create_mn,
                create_trm,
                create_dtm,
                active_mn,
                active_trm,
                active_dtm,
                bk_active
         FROM vn.ssi08m00 WHERE active_stat = 'W' )
   LOOP
     vn.pxc_log_write('pss_stk_bk_dmr_cty','basket_cd: ' || c1.basket_cd || ', stk_cd:' || c1.stk_cd || ', active_stat:' ||c1.active_stat || ', bk_active: ' || c1.bk_active);
      INSERT INTO vn.ssi08h00
            (
                dt,
                basket_cd,
                stk_cd,
                active_stat,
                cd_bp_rate,
                cd_bp_rate_af,
                cd_rate,
                cd_rate_af,
                delay_bp_rate,
                delay_bp_rate_af,
                delay_rate,
                delay_rate_af,
                rgt_bp_rate,
                rgt_bp_rate_af,
                rgt_rate,
                rgt_rate_af,
                cdr_bp,
                cdr_bp_af,
                cdr,
                cdr_af,
                lnd_limit_qty,
                lnd_limit_qty_af,
                lnd_limit_amt,
                lnd_limit_amt_af,
                lnd_lmt_pri,
                lnd_lmt_pri_af,
                create_mn,
                create_trm,
                create_dtm,
                active_mn,
                active_trm,
                active_dtm,
                work_mn,
                work_dtm,
                work_trm,
                bk_active
            )
      VALUES (
                i_proc_dt,
                c1.basket_cd,
                c1.stk_cd,
                c1.active_stat,
                c1.cd_bp_rate,
                c1.cd_bp_rate_af,
                c1.cd_rate,
                c1.cd_rate_af,
                c1.delay_bp_rate,
                c1.delay_bp_rate_af,
                c1.delay_rate,
                c1.delay_rate_af,
                c1.rgt_bp_rate,
                c1.rgt_bp_rate_af,
                c1.rgt_rate,
                c1.rgt_rate_af,
                c1.cdr_bp,
                c1.cdr_bp_af,
                c1.cdr,
                c1.cdr_af,
                c1.lnd_limit_qty,
                c1.lnd_limit_qty_af,
                c1.lnd_limit_amt,
                c1.lnd_limit_amt_af,
                c1.lnd_lmt_pri,
                c1.lnd_lmt_pri_af,
                c1.create_mn,
                c1.create_trm,
                c1.create_dtm,
                c1.active_mn,
                c1.active_trm,
                c1.active_dtm,
                'BOS',
                SYSDATE,
                'BOS',
                c1.bk_active
             );
   END LOOP;
vn.pxc_log_write('pss_stk_bk_dmr_cty','end');
END pss_stk_bk_dmr_cty;
/

