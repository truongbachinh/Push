create function    fdl_get_lnd_tp(
i_code in varchar2,
i_tp in varchar2 /* 1: Nguon; 2: San pham;*/
)
  return varchar2 as

  o_lnd_tp varchar2(15);

begin

	begin
        select lnd_tp into o_lnd_tp
        from vn.dlm00m01
        where item_tp ='03'  
          and item_cd = decode (i_tp, '1', i_code , -- nguon
                                      '2', vn.fdl_get_src_no(i_code) -- san pham
                                )
          and active_stat ='Y';

	  exception
	  when others then
		return null;
	  end;

	  return o_lnd_tp;

end;
/

