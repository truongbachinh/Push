create PROCEDURE PGG_CNCL_VOUCHER
/********************
    전표 취소 처리
********************/
(                I_SLIP_DT                  IN  VARCHAR2            --전표일자
                ,I_PROC_BRCH_CD             IN  VARCHAR2            --지점코드
                ,I_PROC_AGNC_BRCH           IN  VARCHAR2            --대리지점
                ,I_SLIP_NO                  IN  VARCHAR2            --전표번호
                ,O_PROC_CNT                 OUT NUMBER              --PROC NUMBER
)IS

    T_SLIP_DT           GGA06M01.SLIP_DT%TYPE;
    T_PROC_BRCH_CD      GGA06M01.BRCH_CD%TYPE;
    T_PROC_AGNC_BRCH    GGA06M01.AGNC_BRCH%TYPE;
    T_SLIP_NO           GGA06M01.SLIP_NO%TYPE;

    T_NO_MORE_TO_CNCL   VARCHAR2(1);
    T_GGA06M01_ROWID    ROWID;
    T_PROC_TP           VARCHAR2(1);
    T_AUTO_TP           VARCHAR2(1);

BEGIN


    --처리건수 초기화
    O_PROC_CNT  :=  0;

    T_SLIP_DT           :=I_SLIP_DT  ;
    T_PROC_BRCH_CD      :=I_PROC_BRCH_CD  ;
    T_PROC_AGNC_BRCH    :=I_PROC_AGNC_BRCH;
    T_SLIP_NO           :=I_SLIP_NO       ;


    T_NO_MORE_TO_CNCL   := 'N';


    -- 취소할 전표 자동/수동 구분 구하기
/* 20080825-005 START -------------------------- */
/* 20080825-005 SeoHaeSeok 수정 : 자동/수동 구분 구하기 */

/* ----------------------------------------------------------
    SELECT  A.AUTO_TP
      INTO  T_AUTO_TP
      FROM  GGA06M00 A
     WHERE  A.SLIP_DT       =   T_SLIP_DT
       AND  A.BRCH_CD       =   T_PROC_BRCH_CD
       AND  A.AGNC_BRCH     =   T_PROC_AGNC_BRCH
       AND  A.SLIP_NO       =   T_SLIP_NO
       AND  A.SLIP_SUB_NO   =   '001';
-------------------------------------------------------------*/

    SELECT  A.AUTO_TP
      INTO  T_AUTO_TP
      FROM  GGA06M00 A
     WHERE  A.SLIP_DT       =   T_SLIP_DT
       AND  A.BRCH_CD       =   T_PROC_BRCH_CD
       AND  A.AGNC_BRCH     =   T_PROC_AGNC_BRCH
       AND  A.SLIP_NO       =   T_SLIP_NO
       AND  ROWNUM			<=	1;

/* 20080825-005 END -------------------------- */


    LOOP


        --수기전표이면  맨처음전표는 승인취소(C)이고  2번째 부터는(수신전표이므로) 전표폐기(X) 임.
        --자동전표는 무조건 전표폐기(X) 임
        IF  T_AUTO_TP = '2' AND O_PROC_CNT = 0 THEN
            T_PROC_TP   :=  'C';
        ELSE
            T_PROC_TP   :=  'X';
        END IF;
pxc_log_write('PGG_CNCL_VOUCHER','T_AUTO_TP=['|| T_AUTO_TP||'],O_PROC_CNT=['|| to_char(O_PROC_CNT) ||'],T_PROC_TP=['||T_PROC_TP||']' );

        -- @@@ 이미 취소된 전표인지 체크

        -- =============
        -- 전표승인처리 : GGA08M00(DAILY STATISTICS) APPLY , 전표상태 ==> (4) 취소
        -- 일계반영
        -- =============
        PGG_SLIP_APPROVAL
        (
            T_PROC_TP           -- 'A' : Approval, 'C' : Approval Cancel, 'R' :Return, 'X' : DisUse
           ,T_PROC_BRCH_CD      -- PROCESSING BRANCH CODE
           ,T_PROC_AGNC_BRCH    -- PROCESSING BRANCH CODE(AGNC)
           ,T_SLIP_DT           -- SLIP DATE
           ,T_SLIP_NO           -- SLIP No.
           ,'SYSTEM'
        );


        -- 처리전표를 발신전표로 하는 수신전표가 존재하면 수신전표도 취소한다.
        BEGIN
            SELECT   A.RECV_SLIP_DT
                    ,A.RECV_BNH_CD
                    ,A.RECV_AGNC_BRCH
                    ,A.RECV_SLIP_NO
                    ,A.ROWID
              INTO   T_SLIP_DT
                    ,T_PROC_BRCH_CD
                    ,T_PROC_AGNC_BRCH
                    ,T_SLIP_NO
                    ,T_GGA06M01_ROWID
              FROM  GGA06M01 A
             WHERE  A.SLIP_DT   =   T_SLIP_DT
               AND  A.BRCH_CD   =   T_PROC_BRCH_CD
               AND  A.AGNC_BRCH =   T_PROC_AGNC_BRCH
               AND  A.SLIP_NO   =   T_SLIP_NO
               AND  NVL(A.CNCL_YN,'N') <> 'Y';
        -- 더이상 발신-수신 관계가 없을 때...
        EXCEPTION WHEN NO_DATA_FOUND THEN
            T_NO_MORE_TO_CNCL   :=  'Y';        --더이상 취소할 것이 없음
        END;

        --수발신내역 취소 처리
        UPDATE  GGA06M01
           SET  CNCL_YN = 'Y'
         WHERE  ROWID   =   T_GGA06M01_ROWID;


        EXIT    WHEN    T_NO_MORE_TO_CNCL   =  'Y';

        -- OUT Variable
        O_PROC_CNT   :=  O_PROC_CNT + 1;

    END LOOP;


END PGG_CNCL_VOUCHER;
/

