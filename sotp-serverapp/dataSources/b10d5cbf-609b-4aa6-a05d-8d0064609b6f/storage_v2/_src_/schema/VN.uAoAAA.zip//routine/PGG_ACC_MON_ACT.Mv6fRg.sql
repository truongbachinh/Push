create PROCEDURE    PGG_ACC_MON_ACT
   (I_FR_DT         IN      VARCHAR2,       -- 시작일자
    I_TO_DT         IN      VARCHAR2,       -- 종료일자
    I_BRCH_CD       IN      VARCHAR2,       -- 지점
    I_AGNC_BRCH     IN      VARCHAR2,       -- 대리지점
    I_WORK_MN       IN      VARCHAR2,		-- 처리자
    I_WORK_TRM      IN      VARCHAR2,       -- IP_ADDRESS
    O1_RTN_TBL      OUT     VARCHAR2,       -- Return Table
	O1_RTN_ERR      OUT     VARCHAR2,       -- Return Error Code
	O1_RTN_MSG      OUT     VARCHAR2        -- Return Message
	) IS

    -- Constants

    -- Variables

    -- Exceptions Declare
    ERR_GGA08M01_INS    EXCEPTION;

-- *************************< START OF PROCEDURE >****************************
BEGIN


    -- *********************
    -- * 계   정   집   계 *
    -- *********************

    -- U_1. 회계상대계정집계 기존자료 삭제
    DELETE
      FROM  VN.GGA08M01
	 WHERE	ACC_CLS_DT	>=	I_FR_DT
	   AND	ACC_CLS_DT	<=	I_TO_DT
	   AND	BRCH_CD		=   I_BRCH_CD
	   AND	AGNC_BRCH	=	I_AGNC_BRCH ;


    -- U_2. 회계상대계정 집계 자료조회
    FOR C1 IN
    	(	SELECT	v21.SLIP_DT						AS	SLIP_DT,
					v21.BRCH_CD						AS	BRCH_CD,
					v21.AGNC_BRCH					AS	AGNC_BRCH,
					v21.ACC_ACT_CD_DR				AS	ACC_ACT_CD_DR,
					v21.ACC_ACT_CD_CR				AS	ACC_ACT_CD_CR,
					SUM(NVL(v21.SLIP_AMT_DR, 0))	AS	SLIP_AMT_DR,
					SUM(NVL(v21.SLIP_AMT_CR, 0))	AS	SLIP_AMT_CR
			  FROM
					(	SELECT	v31.SLIP_DT						AS	SLIP_DT,
								v31.BRCH_CD						AS	BRCH_CD,
								v31.AGNC_BRCH					AS	AGNC_BRCH,
								v31.SLIP_NO						AS	SLIP_NO,
								v31.SLIP_SQ						AS	SLIP_SQ,
								CASE
									WHEN	SUM(NVL(v31.CNT_CR, 0))	>	1	THEN
											(	SELECT	v41.ACC_ACT_CD	AS	ACC_ACT_CD_DR
												  FROM	VN.GGA06M00	v41
												 WHERE	v41.SLIP_DT		=	v31.SLIP_DT
												   AND	v41.BRCH_CD		=	v31.BRCH_CD
												   AND	v41.AGNC_BRCH	=	v31.AGNC_BRCH
												   AND	v41.SLIP_NO		=	v31.SLIP_NO
												   AND	v41.DR_CR_TP	=	'1'
												   AND	ROWNUM			<=	1
											)
									ELSE	MAX(v31.ACC_ACT_CD_DR)
								END								AS	ACC_ACT_CD_DR,
								CASE
									WHEN	SUM(NVL(v31.CNT_CR, 0))	>	1	THEN
											SUM(NVL(v31.SLIP_AMT_CR, 0))
									ELSE	SUM(NVL(v31.SLIP_AMT_DR, 0))
								END								AS	SLIP_AMT_DR,
								CASE
									WHEN	SUM(NVL(v31.CNT_DR, 0))	>	1	THEN
											(	SELECT	v41.ACC_ACT_CD	AS	ACC_ACT_CD_CR
												  FROM	VN.GGA06M00	v41
												 WHERE	v41.SLIP_DT		=	v31.SLIP_DT
												   AND	v41.BRCH_CD		=	v31.BRCH_CD
												   AND	v41.AGNC_BRCH	=	v31.AGNC_BRCH
												   AND	v41.SLIP_NO		=	v31.SLIP_NO
												   AND	v41.DR_CR_TP	=	'2'
												   AND	ROWNUM			<=	1
											)
									ELSE	MAX(v31.ACC_ACT_CD_CR)
								END								AS	ACC_ACT_CD_CR,
								CASE
									WHEN	SUM(NVL(v31.CNT_DR, 0))	>	1	THEN
											SUM(NVL(v31.SLIP_AMT_DR, 0))
									ELSE	SUM(NVL(v31.SLIP_AMT_CR, 0))
								END								AS	SLIP_AMT_CR
						  FROM
								(	SELECT	v41.SLIP_DT							AS	SLIP_DT,
											v41.BRCH_CD							AS	BRCH_CD,
											v41.AGNC_BRCH						AS	AGNC_BRCH,
											v41.SLIP_NO							AS	SLIP_NO,
											LPAD(LTRIM(v41.SLIP_SQ), 2, '0')	AS	SLIP_SQ,
											(	SELECT	COUNT(*)	AS	CNT_DR
												  FROM	VN.GGA06M00	v51
												 WHERE	v51.SLIP_DT		=	v41.SLIP_DT
												   AND	v51.BRCH_CD		=	v41.BRCH_CD
												   AND	v51.AGNC_BRCH	=	v41.AGNC_BRCH
												   AND	v51.SLIP_NO		=	v41.SLIP_NO
												   AND	v51.DR_CR_TP	=	'1'
											)									AS	CNT_DR,
											v41.ACC_ACT_CD_DR					AS	ACC_ACT_CD_DR,
											NVL(v41.SLIP_AMT_DR, 0)				AS	SLIP_AMT_DR,
											0									AS	CNT_CR,
											NULL								AS	ACC_ACT_CD_CR,
											0									AS	SLIP_AMT_CR
									  FROM
											(	SELECT	v51.SLIP_DT							AS	SLIP_DT,
														v51.BRCH_CD							AS	BRCH_CD,
														v51.AGNC_BRCH						AS	AGNC_BRCH,
														v51.SLIP_NO							AS	SLIP_NO,
														v51.SLIP_SQ - MIN(v52.SLIP_SQ) + 1	AS	SLIP_SQ,
														MAX(v51.ACC_ACT_CD_DR)				AS	ACC_ACT_CD_DR,
														NVL(v51.SLIP_AMT_DR, 0)				AS	SLIP_AMT_DR
												  FROM
														(	SELECT	v61.SLIP_DT					AS	SLIP_DT,
																	v61.BRCH_CD					AS	BRCH_CD,
																	v61.AGNC_BRCH				AS	AGNC_BRCH,
																	v61.SLIP_NO					AS	SLIP_NO,
																	ROWNUM						AS	SLIP_SQ,
																	v61.ACC_ACT_CD_DR			AS	ACC_ACT_CD_DR,
																	NVL(v61.SLIP_AMT_DR, 0)		AS	SLIP_AMT_DR
															  FROM
																	(	SELECT	v71.SLIP_DT				AS	SLIP_DT,
																				v71.BRCH_CD				AS	BRCH_CD,
																				v71.AGNC_BRCH			AS	AGNC_BRCH,
																				v71.SLIP_NO				AS	SLIP_NO,
																				v71.ACC_ACT_CD			AS	ACC_ACT_CD_DR,
																				NVL(v71.SLIP_AMT, 0)	AS	SLIP_AMT_DR
																		  FROM	VN.GGA06M00	v71
																		 WHERE	v71.SLIP_DT		>=	I_FR_DT
																		   AND	v71.SLIP_DT		<=	I_TO_DT
																		   AND	v71.BRCH_CD		=	I_BRCH_CD
																		   AND	v71.AGNC_BRCH	=	I_AGNC_BRCH
																		   AND	v71.SLIP_STAT	=	'2'
																		   AND	v71.DR_CR_TP	=	'1'
																		   AND	NVL(v71.SLIP_AMT, 0)	<>	0
																	  ORDER BY	v71.SLIP_DT,
																				v71.BRCH_CD,
																				v71.AGNC_BRCH,
																				v71.SLIP_NO,
																				v71.ACC_ACT_CD
																	)			v61
														)			v51,
														(	SELECT	v61.SLIP_DT					AS	SLIP_DT,
																	v61.BRCH_CD					AS	BRCH_CD,
																	v61.AGNC_BRCH				AS	AGNC_BRCH,
																	v61.SLIP_NO					AS	SLIP_NO,
																	ROWNUM						AS	SLIP_SQ,
																	v61.ACC_ACT_CD_DR			AS	ACC_ACT_CD_DR,
																	NVL(v61.SLIP_AMT_DR, 0)		AS	SLIP_AMT_DR
															  FROM
																	(	SELECT	v71.SLIP_DT				AS	SLIP_DT,
																				v71.BRCH_CD				AS	BRCH_CD,
																				v71.AGNC_BRCH			AS	AGNC_BRCH,
																				v71.SLIP_NO				AS	SLIP_NO,
																				v71.ACC_ACT_CD			AS	ACC_ACT_CD_DR,
																				NVL(v71.SLIP_AMT, 0)	AS	SLIP_AMT_DR
																		  FROM	VN.GGA06M00	v71
																		 WHERE	v71.SLIP_DT		>=	I_FR_DT
																		   AND	v71.SLIP_DT		<=	I_TO_DT
																		   AND	v71.BRCH_CD		=	I_BRCH_CD
																		   AND	v71.AGNC_BRCH	=	I_AGNC_BRCH
																		   AND	v71.SLIP_STAT	=	'2'
																		   AND	v71.DR_CR_TP	=	'1'
																		   AND	NVL(v71.SLIP_AMT, 0)	<>	0
																	  ORDER BY	v71.SLIP_DT,
																				v71.BRCH_CD,
																				v71.AGNC_BRCH,
																				v71.SLIP_NO,
																				v71.ACC_ACT_CD
																	)			v61
														)			v52
												 WHERE	v51.SLIP_DT		=	v52.SLIP_DT
												   AND	v51.BRCH_CD		=	v52.BRCH_CD
												   AND	v51.AGNC_BRCH	=	v52.AGNC_BRCH
												   AND	v51.SLIP_NO		=	v52.SLIP_NO
											  GROUP BY	v51.SLIP_DT,
														v51.BRCH_CD,
														v51.AGNC_BRCH,
														v51.SLIP_NO,
														v51.SLIP_SQ,
														NVL(v51.SLIP_AMT_DR, 0)
											)			v41
								UNION ALL
									SELECT	v41.SLIP_DT							AS	SLIP_DT,
											v41.BRCH_CD							AS	BRCH_CD,
											v41.AGNC_BRCH						AS	AGNC_BRCH,
											v41.SLIP_NO							AS	SLIP_NO,
											LPAD(LTRIM(v41.SLIP_SQ), 2, '0')	AS	SLIP_SQ,
											0									AS	CNT_DR,
											NULL								AS	ACC_ACT_CD_DR,
											0									AS	SLIP_AMT_DR,
											(	SELECT	COUNT(*)	AS	CNT_CR
												  FROM	VN.GGA06M00	v51
												 WHERE	v51.SLIP_DT		=	v41.SLIP_DT
												   AND	v51.BRCH_CD		=	v41.BRCH_CD
												   AND	v51.AGNC_BRCH	=	v41.AGNC_BRCH
												   AND	v51.SLIP_NO		=	v41.SLIP_NO
												   AND	v51.DR_CR_TP	=	'2'
											)									AS	CNT_CR,
											v41.ACC_ACT_CD_CR					AS	ACC_ACT_CD_CR,
											NVL(v41.SLIP_AMT_CR, 0)				AS	SLIP_AMT_CR
									  FROM
											(	SELECT	v51.SLIP_DT							AS	SLIP_DT,
														v51.BRCH_CD							AS	BRCH_CD,
														v51.AGNC_BRCH						AS	AGNC_BRCH,
														v51.SLIP_NO							AS	SLIP_NO,
														v51.SLIP_SQ - MIN(v52.SLIP_SQ) + 1	AS	SLIP_SQ,
														MAX(v51.ACC_ACT_CD_CR)				AS	ACC_ACT_CD_CR,
														NVL(v51.SLIP_AMT_CR, 0)				AS	SLIP_AMT_CR
												  FROM
														(	SELECT	v61.SLIP_DT					AS	SLIP_DT,
																	v61.BRCH_CD					AS	BRCH_CD,
																	v61.AGNC_BRCH				AS	AGNC_BRCH,
																	v61.SLIP_NO					AS	SLIP_NO,
																	ROWNUM						AS	SLIP_SQ,
																	v61.ACC_ACT_CD_CR			AS	ACC_ACT_CD_CR,
																	NVL(v61.SLIP_AMT_CR, 0)		AS	SLIP_AMT_CR
															  FROM
																	(	SELECT	v71.SLIP_DT				AS	SLIP_DT,
																				v71.BRCH_CD				AS	BRCH_CD,
																				v71.AGNC_BRCH			AS	AGNC_BRCH,
																				v71.SLIP_NO				AS	SLIP_NO,
																				v71.ACC_ACT_CD			AS	ACC_ACT_CD_CR,
																				NVL(v71.SLIP_AMT, 0)	AS	SLIP_AMT_CR
																		  FROM	VN.GGA06M00	v71
																		 WHERE	v71.SLIP_DT		>=	I_FR_DT
																		   AND	v71.SLIP_DT		<=	I_TO_DT
																		   AND	v71.BRCH_CD		=	I_BRCH_CD
																		   AND	v71.AGNC_BRCH	=	I_AGNC_BRCH
																		   AND	v71.SLIP_STAT	=	'2'
																		   AND	v71.DR_CR_TP	=	'2'
																		   AND	NVL(v71.SLIP_AMT, 0)	<>	0
																	  ORDER BY	v71.SLIP_DT,
																				v71.BRCH_CD,
																				v71.AGNC_BRCH,
																				v71.SLIP_NO,
																				v71.ACC_ACT_CD
																	)			v61
														)			v51,
														(	SELECT	v61.SLIP_DT					AS	SLIP_DT,
																	v61.BRCH_CD					AS	BRCH_CD,
																	v61.AGNC_BRCH				AS	AGNC_BRCH,
																	v61.SLIP_NO					AS	SLIP_NO,
																	ROWNUM						AS	SLIP_SQ,
																	v61.ACC_ACT_CD_CR			AS	ACC_ACT_CD_CR,
																	NVL(v61.SLIP_AMT_CR, 0)		AS	SLIP_AMT_CR
															  FROM
																	(	SELECT	v71.SLIP_DT				AS	SLIP_DT,
																				v71.BRCH_CD				AS	BRCH_CD,
																				v71.AGNC_BRCH			AS	AGNC_BRCH,
																				v71.SLIP_NO				AS	SLIP_NO,
																				v71.ACC_ACT_CD			AS	ACC_ACT_CD_CR,
																				NVL(v71.SLIP_AMT, 0)	AS	SLIP_AMT_CR
																		  FROM	VN.GGA06M00	v71
																		 WHERE	v71.SLIP_DT		>=	I_FR_DT
																		   AND	v71.SLIP_DT		<=	I_TO_DT
																		   AND	v71.BRCH_CD		=	I_BRCH_CD
																		   AND	v71.AGNC_BRCH	=	I_AGNC_BRCH
																		   AND	v71.SLIP_STAT	=	'2'
																		   AND	v71.DR_CR_TP	=	'2'
																		   AND	NVL(v71.SLIP_AMT, 0)	<>	0
																	  ORDER BY	v71.SLIP_DT,
																				v71.BRCH_CD,
																				v71.AGNC_BRCH,
																				v71.SLIP_NO,
																				v71.ACC_ACT_CD
																	)			v61
														)			v52
												 WHERE	v51.SLIP_DT		=	v52.SLIP_DT
												   AND	v51.BRCH_CD		=	v52.BRCH_CD
												   AND	v51.AGNC_BRCH	=	v52.AGNC_BRCH
												   AND	v51.SLIP_NO		=	v52.SLIP_NO
											  GROUP BY	v51.SLIP_DT,
														v51.BRCH_CD,
														v51.AGNC_BRCH,
														v51.SLIP_NO,
														v51.SLIP_SQ,
														NVL(v51.SLIP_AMT_CR, 0)
											)			v41
								)			v31
					  GROUP BY	v31.SLIP_DT,
								v31.BRCH_CD,
								v31.AGNC_BRCH,
								v31.SLIP_NO,
								v31.SLIP_SQ
					)			v21
		  GROUP BY	v21.SLIP_DT,
					v21.BRCH_CD,
					v21.AGNC_BRCH,
					v21.ACC_ACT_CD_DR,
					v21.ACC_ACT_CD_CR
        ) LOOP

    	-- U_3. 회계상대계정 집계 자료생성
        BEGIN
            INSERT
              INTO  VN.GGA08M01(
                    ACC_CLS_DT,
                    BRCH_CD,
                    AGNC_BRCH,
                    ACC_ACT_CD_DR,
                    ACC_ACT_CD_CR,
                    DR_ACCM_AMT,
                    CR_ACCM_AMT,
                    WORK_MN,
                    WORK_DTM,
                    WORK_TRM )
            VALUES  (C1.SLIP_DT,
                    I_BRCH_CD,
                    I_AGNC_BRCH,
                    C1.ACC_ACT_CD_DR,
                    C1.ACC_ACT_CD_CR,
                    C1.SLIP_AMT_DR,
                    C1.SLIP_AMT_CR,
                    I_WORK_MN,
                    SYSDATE,
                    I_WORK_TRM );
        EXCEPTION WHEN OTHERS THEN
            RAISE ERR_GGA08M01_INS;
        END;

    END LOOP;   -- C1 End Loop


    O1_RTN_TBL  :=  'GGA08M01';
    O1_RTN_ERR  :=  '0';
    --O1_RTN_MSG  :=  '[V0602]회계마감 성공! ==> 정상적으로 처리되었습니다.';
    O1_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','0602');
    --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);

EXCEPTION
    WHEN    ERR_GGA08M01_INS  THEN
        O1_RTN_TBL  :=  'GGA08M01';
        O1_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O1_RTN_MSG  :=  '[V2628]회계 월마감을 처리할 수 없습니다. [' || I_BRCH_CD || ']';
        O1_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2628') || ' [' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O1_RTN_MSG);
    WHEN    OTHERS  THEN
        O1_RTN_TBL  :=  'OTHERS';
        O1_RTN_ERR  :=  TO_CHAR(SQLCODE);
        O1_RTN_MSG  :=  'ERROR ' || SUBSTR(SQLERRM, 1, 100);
        --RAISE_APPLICATION_ERROR(-20100, O1_RTN_MSG);
END PGG_ACC_MON_ACT;
/

