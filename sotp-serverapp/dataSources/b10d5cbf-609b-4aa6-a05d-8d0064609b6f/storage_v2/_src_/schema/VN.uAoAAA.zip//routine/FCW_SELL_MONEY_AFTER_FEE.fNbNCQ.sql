create function    fcw_sell_money_after_fee
(
    i_acnt_no        in   varchar2,
    i_sub_no         in   varchar2
) return number is

    ts_work_stat   varchar2(1);
    td_adj_amt     number := 0;

    t_pppre_mth_dt     varchar2(08)  := null;  --
    t_ppre_mth_dt      varchar2(08)  := null;  --
    t_pre_mth_dt       varchar2(08)  := null;  --
    t_vwdate           varchar2(08)  := null;  --

    o_resuilt           number;
/*
    Lay gia tri tien ban cho ve sau khi da tru di phi va thue ban
*/
begin
    t_vwdate   :=  vn.vwdate;
    t_pppre_mth_dt := vn.fxc_vorderdt_g(to_date(t_vwdate,'yyyymmdd'), -3);
    t_ppre_mth_dt  := vn.fxc_vorderdt_g(to_date(t_vwdate,'yyyymmdd'), -2);
    t_pre_mth_dt   := vn.fxc_vorderdt_g(to_date(t_vwdate,'yyyymmdd'), -1);

    BEGIN
        SELECT NVL(WORK_STAT,'1')
          INTO ts_work_stat
          FROM vn.xbd01m00
         WHERE PGM_ID = '2000'
        ;
    EXCEPTION
    WHEN OTHERS THEN
        ts_work_stat := '1';
    END;

    /*-- Lay gia tri tien ban cho ve sau khi da tru di phi va thue ban--*/
    IF ts_work_stat = '2' THEN
        select  sum(adj_amt) into td_adj_amt
           from  vn.dsc01m00
          where  acnt_no      =  i_acnt_no
            and  sub_no       =  i_sub_no
            and  bank_cd   like  '%'
            and  sb_tp        =  '1'
            and  dpo_setl_yn  =  'N';
    ELSE
        begin
            /*-- tinh du lieu phi va thue chinh xac cho tai khoan nay -> chay du dinh thanh toan truoc - du lieu duoc day vao table tam: dsc01m10 --*/
            vn.pds_setl_cr_pre_cmsn(t_vwdate , i_acnt_no, i_sub_no, 'Get_not_pia_yet', 'Get_not_pia_yet');
            commit;
        exception when others then
          vn.pxc_log_write('pdl_get_not_pia_amt_yet','Error when calling pds_setl_cr_pre_cmsn, but ignore and continue');
        end;

        Select Sum(adj_amt) into td_adj_amt
          From (
             select  sum(adj_amt)  adj_amt
                 from  vn.dsc01m00
                where  mth_dt       >=  t_pppre_mth_dt
                  and  mth_dt       <  t_vwdate
                  and  acnt_no      =  i_acnt_no
                  and  sub_no       =  i_sub_no
                  and  bank_cd   like  '%'
                  and  sb_tp        =  '1'
                  and  dpo_setl_yn  =  'N'
               union all
               select  sum(adj_amt) adj_amt
                 from  vn.dsc01m10
                where  mth_dt       =  t_vwdate
                  and  acnt_no      =  i_acnt_no
                  and  sub_no       =  i_sub_no
                  and  bank_cd   like  '%'
                  and  sb_tp        =  '1'
                  and  dpo_setl_yn  =  'N'
             );
    END IF;
    if td_adj_amt is null or td_adj_amt = 0 then
       o_resuilt := 0;
    else
        o_resuilt := td_adj_amt;
    end if;


    return o_resuilt;

end fcw_sell_money_after_fee;
/

