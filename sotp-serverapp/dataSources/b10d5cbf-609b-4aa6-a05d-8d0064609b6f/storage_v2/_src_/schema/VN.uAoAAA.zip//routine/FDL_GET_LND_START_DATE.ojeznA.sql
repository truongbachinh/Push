create FUNCTION fdl_get_lnd_start_date(
    i_lnd_tp                IN      VARCHAR2,
    i_acnt_no               IN      VARCHAR2,
    i_sub_no                IN      VARCHAR2,
    i_prd_no                IN      VARCHAR2,
    i_lnd_dt                IN      VARCHAR2,
    i_stk_cd                IN      VARCHAR2,
    i_lnd_bank_cd           IN      VARCHAR2,
    i_qry_dt                IN      VARCHAR2
)
RETURN VARCHAR2
AS
    t_proc_nm               VARCHAR2(50)    := 'fdl_get_lnd_start_date';
    t_err_msg               VARCHAR2(400)   := '';

    t_src_no                VARCHAR2(15)    := NULL;
    t_int_waive_day_tp      NUMBER          := 0;           -- Phan loai ngay mien lai:     1:Ngay theo lich;   2:Ngay lam viec
    t_int_waive_days        NUMBER          := 0;           -- So ngay mien lai
    t_last_rpy_dt           VARCHAR2(8)     := NULL;
    t_first_int_dt          VARCHAR2(8)     := NULL;
    t_rpy_mthd_tp           NUMBER          := 0;           -- 1:Uu tien thu lai truoc      2:Lai goc tuong duong (1.tinh lai dua tren so du goc con lai    2. tinh lai tren so tien hoan tra)
    t_start_dt              VARCHAR2(8)     := i_lnd_dt;

    o_ret                   VARCHAR2(8);

begin

    vn.pxc_log_write(t_proc_nm, 'Start: '
                                   || ' i_acnt_no = '   || i_acnt_no
                                   || ', i_sub_no = '   || i_sub_no
                                   || ', i_prd_no = '   || i_prd_no
                                   || ', i_lnd_dt = '   || i_lnd_dt
                                   || ', i_qry_dt = '   || i_qry_dt
                        );

    -- Lay cac setup tu san pham
    BEGIN
        t_int_waive_day_tp := vn.fdl_get_prd_acnt_rt(
                                    i_acnt_no,      -- i_acnt_no    IN   VARCHAR2,
                                    i_sub_no,       -- i_sub_no     IN   VARCHAR2,
                                    i_prd_no,       -- i_prd_no     IN   VARCHAR2,
                                    '11',           -- i_rt_tp      IN   VARCHAR2,
                                    i_lnd_dt        -- i_apy_dt     IN   VARCHAR2
                                );

        t_int_waive_days := vn.fdl_get_prd_acnt_rt(
                                    i_acnt_no,      -- i_acnt_no    IN   VARCHAR2,
                                    i_sub_no,       -- i_sub_no     IN   VARCHAR2,
                                    i_prd_no,       -- i_prd_no     IN   VARCHAR2,
                                    '10',           -- i_rt_tp      IN   VARCHAR2,
                                    i_lnd_dt        -- i_apy_dt     IN   VARCHAR2
                                );

    EXCEPTION WHEN OTHERS THEN
        t_err_msg := vn.fxc_get_err_msg('V','461000');
        vn.pxc_log_write(t_proc_nm, 'Loi khi lay thong tin setup san pham cho: '
                                           || ' i_acnt_no = '   || i_acnt_no
                                           || ', i_sub_no = '   || i_sub_no
                                           || ', i_prd_no = '   || i_prd_no
                                           || ', i_lnd_dt = '   || i_lnd_dt
                        );

        raise_application_error(-20100, t_err_msg || t_proc_nm ||': Loi khi lay thong tin setup san pham cho: '
                                                  || ' i_acnt_no = '   || i_acnt_no
                                                  || ', i_sub_no = '   || i_sub_no
                                                  || ', i_prd_no = '   || i_prd_no
                                                  || ', i_lnd_dt = '   || i_lnd_dt
                                );
    END;

    -- Lay cac setup tu nguon
    t_src_no                := vn.fdl_get_src_no(i_prd_no);

    BEGIN
        SELECT int_pay_tp             -- Phuong thuc thu no
        INTO t_rpy_mthd_tp
        FROM vn.dlm20m00
        WHERE src_no        = t_src_no
          AND apy_dt       <= i_lnd_dt
          AND expr_dt      >= i_lnd_dt
          AND active_stat   = 'Y';
    EXCEPTION WHEN OTHERS THEN
        t_err_msg := vn.fxc_get_err_msg('V','460300');
        vn.pxc_log_write(t_proc_nm,   'Loi khi lay chinh sach chung thuoc tinh nguon cho:'
                                             || ' i_acnt_no = '   || i_acnt_no
                                             || ', i_sub_no = '   || i_sub_no
                                             || ', t_src_no = '   || t_src_no
                                             || ', i_lnd_dt = '   || i_lnd_dt
                        );

        raise_application_error(-20100, t_err_msg
                                        || t_proc_nm || ': Loi khi lay chinh sach chung thuoc tinh nguon cho:'
                                        || ' i_acnt_no = '   || i_acnt_no
                                        || ', i_sub_no = '   || i_sub_no
                                        || ', t_src_no = '   || t_src_no
                                        || ', i_lnd_dt = '   || i_lnd_dt
                                );
    END;

    -- Lay ngay bat dau tinh lai = ngay vay + so ngay mien lai
    IF t_int_waive_day_tp = 2 THEN          -- Tinh theo lich lam viec, co tinh ngay nghi
        t_first_int_dt  := vn.fxc_vorderdt_g(TO_DATE(i_lnd_dt,'YYYYMMDD'), t_int_waive_days);
    ELSE                                    -- Ko tinh ngay nghi
        t_first_int_dt  := TO_CHAR(TO_DATE(i_lnd_dt, 'YYYYMMDD') + t_int_waive_days , 'YYYYMMDD');
    END IF;

    /*
    1. Doi voi phuong thuc Uu tien thu lai truoc:
        - Lai duoc tinh tu ngay hoan tra gan nhat
    2. Doi voi phuong thuc Lai goc tuong duong
        - Lai duoc tinh tu ngay phat vay + mien lai
    */
    IF(t_rpy_mthd_tp = 1) THEN
        BEGIN
            IF(i_qry_dt < vn.vwdate) THEN
                begin
                    SELECT
                        last_rpy_dt
                    INTO
                        t_last_rpy_dt
                    FROM vn.dlm01h00
                    WHERE lnd_tp        = i_lnd_tp
                    AND acnt_no       = i_acnt_no
                    AND sub_no        = i_sub_no
                    AND prd_no        = i_prd_no
                    AND lnd_dt        = i_lnd_dt
                    AND stk_cd        = i_stk_cd
                    AND lnd_bank_cd   = i_lnd_bank_cd
                    AND dt            = i_qry_dt
                    ;
                exception
                    when no_data_found then
                        SELECT
                            last_rpy_dt
                        INTO
                            t_last_rpy_dt
                        FROM vn.dlm01m00
                        WHERE lnd_tp        = i_lnd_tp
                        AND acnt_no       = i_acnt_no
                        AND sub_no        = i_sub_no
                        AND prd_no        = i_prd_no
                        AND lnd_dt        = i_lnd_dt
                        AND stk_cd        = i_stk_cd
                        AND lnd_bank_cd   = i_lnd_bank_cd
                        ;
                end;
            ELSE
                SELECT
                    last_rpy_dt
                INTO
                    t_last_rpy_dt
                FROM vn.dlm01m00
                WHERE lnd_tp        = i_lnd_tp
                  AND acnt_no       = i_acnt_no
                  AND sub_no        = i_sub_no
                  AND prd_no        = i_prd_no
                  AND lnd_dt        = i_lnd_dt
                  AND stk_cd        = i_stk_cd
                  AND lnd_bank_cd   = i_lnd_bank_cd
                  ;
            END IF;
        EXCEPTION
            WHEN OTHERS THEN
                vn.pxc_log_write(t_proc_nm,   'Loi khi lay ngay hoan tra cuoi cung:'
                                                    || ' i_acnt_no = '   || i_acnt_no
                                                    || ', i_sub_no = '   || i_sub_no
                                                    || ', t_src_no = '   || t_src_no
                                                    || ', i_lnd_dt = '   || i_lnd_dt
                                                    || '. Error: '          || sqlcode || ' - '     || sqlerrm
                                );

                raise_application_error(-20100, t_err_msg
                                                || t_proc_nm || ': Loi khi lay ngay hoan tra cuoi cung:'
                                                || ' i_acnt_no = '   || i_acnt_no
                                                || ', i_sub_no = '   || i_sub_no
                                                || ', t_src_no = '   || t_src_no
                                                || ', i_lnd_dt = '   || i_lnd_dt
                                                || '. Error: '          || sqlcode || ' - '     || sqlerrm
                                        );
        END;
        t_start_dt      := GREATEST(t_last_rpy_dt, t_first_int_dt);
    ELSE
        t_start_dt      := t_first_int_dt;
    END IF;

    o_ret   := t_start_dt;

    RETURN o_ret;
END;
/

