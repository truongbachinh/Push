create function fbm_acnt_mng_bnh_q
(
    i_acnt_no		in   varchar2,        -- ����ȣ
    i_sub_no 		in   varchar2,        -- ����ȣ
    i_return_cnt	in   number
)
    return          varchar2
as
    o_acnt_mng_bnh	varchar2(10) ;
    t_err_txt       varchar2(100)  ; -- error text buffer

begin

/*============================================================================*/
/* ���� ���                                                                */
/*============================================================================*/
    o_acnt_mng_bnh  :=  NULL;

/*============================================================================*/
/* �Էº��� üũ                                                              */
/*============================================================================*/
	if i_return_cnt not in (3, 5) then
        t_err_txt  :=  '�Է°�����';
        raise_application_error (-20100, t_err_txt);
    end if;

/*============================================================================*/
/* ��������ȸ                                                                 */
/*============================================================================*/
    begin
      	select nvl(acnt_mng_bnh, '!')
		  into o_acnt_mng_bnh
          from vn.aaa01m00
         where acnt_no	= i_acnt_no
		   and sub_no = i_sub_no
		   and acnt_stat = '1';
    exception
        when  NO_DATA_FOUND  then
			return  '!';
        when  OTHERS         then
            t_err_txt  :=  '����-['||to_char(sqlcode)||']';
            raise_application_error (-20100, t_err_txt);
    end;

	if i_return_cnt = 3 then
    	return  o_acnt_mng_bnh;
    end if;

	if i_return_cnt = 5 then
    	return  o_acnt_mng_bnh||'00';
    end if;

end fbm_acnt_mng_bnh_q;
/

