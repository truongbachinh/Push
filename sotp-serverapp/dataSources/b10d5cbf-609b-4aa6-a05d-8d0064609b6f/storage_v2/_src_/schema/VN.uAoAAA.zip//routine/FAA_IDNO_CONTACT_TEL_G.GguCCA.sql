create function faa_idno_contact_tel_g
(
	i_idno		in		varchar2
) return varchar2 as

	o_val	varchar2(30);

/*!
   \file     faa_idno_contact_tel_g.sql
   \brief    contact telephone number return

   \section intro Program Information
        - Program Name              :  contact telephone number return
        - Service Name              :
        - Related Client Program- Client Program ID :
        - Related Tables            : aaa01m00 ,aaa02m10
        - Dev. Date                 : 2007/11/08
        - Developer                 : mkkim
        - Business Logic Desc.      :
                	input  : idno
					output :  telephone number return
        - Latest Modification Date  :

   \section history Program Modification History
    - 1.0  2007/11/08

   \section hardcoding Hard-Coding List

   \section info Additional Reference Comments

		if contact type's telephone is not exits, then mobile->office->home

*/
begin

	for c1 in (

		select	decode(b.conct_tel_tp,'1',nvl(b.home_tel,'!')
									 ,'2',nvl(b.office_tel,'!')
									 ,'3',nvl(b.mobile,'!')
								 	 ,'!') 	tel,
				nvl(b.home_tel,'!') 		home_tel,
				nvl(b.office_tel,'!') 		office_tel,
				nvl(b.mobile,'!') 			mobile

		from	vn.aaa02m10 b
		where	b.idno 	=	i_idno )loop

		if c1.tel <>'!' then
			return c1.tel ;
		elsif c1.mobile <> '!' then
			return c1.mobile;
		elsif c1.office_tel <> '!' then
			return c1.office_tel;
		elsif c1.home_tel <> '!' then
			return c1.home_tel;
		else
			return '!';
		end if;
	end loop;


		return '!';


end ;
/

