create procedure pts_loan_cash_unhold(i_sec_cd  in varchar2,
                                                 i_acnt_no in varchar2,
                                                 i_sub_no  in varchar2,
                                                 i_trd_amt in number)  -- co the bo
                                                 as
  /*
   Gia su:
      + B la tong hold lenh mua
      + VDU là bao lanh da dung
      + T la tong tai mua ung voi tong l?nh mua B
      + TV la tong tai san mua bang bao lanh
   Goi ti le gia ti bao lanh tren tong gia tri mua la:
      x = VDU/B
      Khi do: TV/T = x
      => VDU = B.x
      => TV = T.x
   ==> Neu ko mua voi bao lanh thi:
      A' = A - T.x
      L' = L - B.x
   Neu ko mua bang bao lanh thi CMR >= IMR
      => (A'-L')/A' = IMR
      Giai Phuong trinh ta co:
      x = (A - A * IMR - L)/(T - B - T * IMR ) (1)
      => VDU = x.B (2)
  */

  -- Declare variable:

  t_vd_amt     number := 0;
  o_errmsg          varchar2(1000) := '';
  t_proc_nm         varchar2(200) := 'pts_loan_cash_unhold ';
  t_acnt_get_grp_no varchar2(5) := null;
  t_tot_asset       number := 0;
  t_tot_loan        number := 0;
  t_imr             number := 0;
  t_gst_dpo         number := 0;
  t_tot_order_block number := 0;
  t_asset_T         number := 0;
  t_vd_rt           number := 0;
begin
  vn.pxc_log_write(t_proc_nm, '');
  vn.pxc_log_write(t_proc_nm,
                   'START pts_loan_cash_unhold:' || ' i_sec_cd = ' ||
                   i_sec_cd || '    , i_acnt_no = ' || i_acnt_no ||
                   ', i_sub_no = ' || i_sub_no || '    , i_trd_amt = ' ||
                   i_trd_amt);

  begin
    select nvl(t.td_cash_prof_amt, 0), a.gst_dpo
      into t_tot_order_block, t_gst_dpo
      from vn.tso02m00 t, cwd01m00 a
     where t.acnt_no = i_acnt_no
       and t.sub_no = i_sub_no
       and a.acnt_no = t.acnt_no
       and a.sub_no = t.sub_no;
  exception
    when others then
      o_errmsg := t_proc_nm || ' tso02m00  err:' || to_char(sqlcode) || ' ' ||
                  i_acnt_no || '-' || i_sub_no;
      raise_application_error(-20100, o_errmsg);
  end;

/*  if t_tot_order_block = 0 then
      update vn.tso02m00 t
        set t.td_cash_prof_gst_amt = 0
      where t.acnt_no = i_acnt_no
        and t.sub_no = i_sub_no
        and t.sub_no <> '00';
      Return;
  end if;
*/
  t_acnt_get_grp_no := vn.faa_acnt_get_grp_no(i_acnt_no,
                                              i_sub_no,
                                              '2',
                                              vn.vwdate);
  if t_gst_dpo = 0 or t_acnt_get_grp_no is null then
    Return;
  end if;
  t_imr := vn.fdl_get_mrgn_grp_acnt_rt(i_acnt_no,
                                       i_sub_no,
                                       t_acnt_get_grp_no,
                                       '06',
                                       vn.vwdate);
  /*  Tính tài s?n CK mua ngày T */
  Begin
    select sum(asset)
      into t_asset_T
      from (select acnt_no,
                   sub_no,
                   stk_cd,
                   sum(qty) *
                   vn.fdl_get_mrgn_basket_rt(acnt_no,
                                             sub_no,
                                             t_acnt_get_grp_no,
                                             '',
                                             stk_cd,
                                             '01',
                                             vn.vwdate) *
                   vn.fss_get_stk_pri(stk_cd, acnt_no, sub_no, 'Day') *
                   vn.fdl_get_mrgn_grp_acnt_rt(acnt_no,
                                               sub_no,
                                               t_acnt_get_grp_no,
                                               '02',
                                               vn.vwdate) asset
              from (
                    -- mua cho ve da khop
                    SELECT t.acnt_no,
                            t.sub_no,
                            t.stk_cd,
                            SUM(nvl(t.td_buy_mth_qty, 0))  qty
                      FROM vn.tso04m00 t
                     WHERE 1 = 1
                       and t.acnt_no = i_acnt_no
                       and t.sub_no = i_sub_no
                     GROUP BY t.acnt_no, t.sub_no, t.stk_cd
                    -- mua cho ve chua khop trong ngay: TSO01m00
                    UNION ALL
                    SELECT t.acnt_no,
                            t.sub_no,
                            t.stk_cd,
                            SUM(nvl(nmth_qty,0)) qty
                      FROM vn.tso01m00 t
                     WHERE accp_tp <> 'X'
                       and t.acnt_no = i_acnt_no
                       and t.sub_no = i_sub_no
                       AND del_yn = 'N'
                       AND sell_buy_tp = '2'
                     GROUP BY t.acnt_no, t.sub_no, t.stk_cd)
             group by acnt_no, sub_no, stk_cd);
  exception
    when others then
    vn.pxc_log_write(t_proc_nm, 'Loi khi xu ly tinh toan bao lanh da dung');
    Return;
  end;
  begin
    select vn.fts_get_acnt_mrgn_info(i_acnt_no,
                                     i_sub_no,
                                     vn.fdl_get_mrgn_grp_acnt_rt(i_acnt_no,
                                                                 i_sub_no,
                                                                 t_acnt_get_grp_no,
                                                                 '02',
                                                                 vn.vwdate),
                                     '02',
                                     vn.vwdate(),
                                     'day'), -- thuc no
           vn.fts_get_acnt_mrgn_info(i_acnt_no,
                                     i_sub_no,
                                     vn.fdl_get_mrgn_grp_acnt_rt(i_acnt_no,
                                                                 i_sub_no,
                                                                 t_acnt_get_grp_no,
                                                                 '02',
                                                                 vn.vwdate),
                                     '01',
                                     vn.vwdate(),
                                     'day') -- tong tai san

      into t_tot_loan, t_tot_asset
      from vn.cwd99m00 t
     where t.acnt_no = i_acnt_no
       and t.sub_no = i_sub_no;
  exception
    when others then
      vn.pxc_log_write(t_proc_nm, 'Loi khi xu ly tinh toan bao lanh da dung');
      Return;
  end;
  /* Tim x theo cong thuc (1) tren */
  if t_asset_T = 0 and t_tot_order_block = 0 then
    t_vd_rt := 0;
  else
    t_vd_rt  := (t_tot_asset - t_tot_asset * t_imr - t_tot_loan) /
              (t_asset_T - t_tot_order_block - t_asset_T * t_imr);
  end if;
  /* Kh? âm */
  t_vd_rt  := Greatest(t_vd_rt, 0);
  /* Tim VDU theo cong thuc (2) tren */
  t_vd_amt := CEIL(t_vd_rt * t_tot_order_block);
  t_vd_amt := Least(t_vd_amt, t_gst_dpo);
  vn.pxc_log_write(t_proc_nm,
                   '4. So BL bi hold lai: ' || '    , t_vd_amt = ' ||
                   t_vd_amt);
  update vn.tso02m00 t
     set t.td_cash_prof_gst_amt = t_vd_amt
   where t.acnt_no = i_acnt_no
     and t.sub_no = i_sub_no;

  vn.pxc_log_write(t_proc_nm, 'END pts_loan_cash_unhold');
end pts_loan_cash_unhold;

/

