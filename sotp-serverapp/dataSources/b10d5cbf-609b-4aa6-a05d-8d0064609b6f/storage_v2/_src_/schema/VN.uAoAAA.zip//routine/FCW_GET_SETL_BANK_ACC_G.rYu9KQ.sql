create function    fcw_get_setl_bank_acc_g
(
  is_tp     in    varchar2,
  is_bank_cd      in      varchar2,
  is_acnt_no    in    varchar2,
  is_sub_no   in    varchar2
) return varchar2 as

  o_acc_no  varchar2(30);

  t_err_txt       varchar2(100)  ;
  ts_acnt_type     varchar2(1) ;


begin


  if is_bank_cd = '0003' then   -- BIDV

        BEGIN
            select acnt_tp
            into ts_acnt_type
            from vn.aaa01m00
            where acnt_no = is_acnt_no
            and sub_no  = is_sub_no ;
        EXCEPTION
        WHEN  OTHERS         THEN
            t_err_txt  :=  'error - ['||to_char(sqlcode)||']';
            raise_application_error (-20100, t_err_txt);
        END;


        /*if is_tp = '1' then*/    -- SETL
        BEGIN
            select Decode( ts_acnt_type , 'F' , bank_tp_f_acnt_no
                                        , 'P' , bank_tp_p_acnt_no
                                            , bank_tp_c_acnt_no )
            into o_acc_no
            from vn.cww01h00
            where bank_cd =  '0003'
            and to_char(mng_end_dt,'yyyymmdd') = '30000101' ;
        EXCEPTION
        WHEN  OTHERS         THEN
            t_err_txt  :=  'error - [ Not Define tp ]';
            raise_application_error (-20100, t_err_txt);
        END;
        /*elsif is_tp in ( '2' ) then  -- loan

            select BANK_TP_4_ACNT_NO
            into  o_acc_no
            from vn.cww01h00
            where bank_cd = '0003'
            and to_char(mng_end_dt,'yyyymmdd') = '30000101' ;


        elsif is_tp  in ('3','4','6','7')  then -- rights

            select bank_2_acnt_no
            into o_acc_no
            from vn.cww01h00
            where bank_cd =  '0003'
                and to_char(mng_end_dt,'yyyymmdd') = '30000101' ;

        elsif is_tp in ('5') then  --

            o_acc_no := '11910000104696';

        else

            t_err_txt  :=  'error - [ Not Define tp ]';
            raise_application_error (-20100, t_err_txt);

      end if ;*/

    elsif is_bank_cd = '0004' then   -- DAB

            if  is_tp = '1' then
                select bank_scrt_acnt_no
                into o_acc_no
                from vn.cww01h00
                where bank_cd =  '0004'
                and to_char(mng_end_dt,'yyyymmdd') = '30000101' ;

            else
                select bank_2_acnt_no
                into o_acc_no
                from vn.cww01h00
                where bank_cd = '0004'
                and to_char(mng_end_dt,'yyyymmdd') = '30000101' ;
            end if  ;

    else

        BEGIN
            select bank_scrt_acnt_no
            into o_acc_no
            from vn.cww01h00
            where bank_cd = is_bank_cd
            and to_char(mng_end_dt,'yyyymmdd') = '30000101' ;
        EXCEPTION
        WHEN OTHERS         THEN
            t_err_txt  :=  'error - ['||to_char(sqlcode)||']';
            raise_application_error (-20100, t_err_txt);
        END;

    end if ;

    return o_acc_no ;

end ;
/

