create PROCEDURE drv_pcw_cash_acnt_trns_p
(
  i_trd_dt                in        varchar2
,   i_outamt_acnt_no        in        varchar2
,   i_out_sub_no            in        varchar2
,   i_inamt_acnt_no         in        varchar2
,   i_in_sub_no             in        varchar2
,   i_cash                  in        number
,   i_mdm_tp                in        varchar2
,   i_tr_cd                 in        varchar2
,   i_cnfm_yn               in        varchar2
,   i_dept_no_3             in        varchar2
,  i_cnte                  in        varchar2
,   i_work_mn               in        varchar2
,   i_work_trm              in        varchar2
,   i_bank_acnt_no          in        varchar2
,   i_seq                   in        varchar2
,   o_trd_dt                out       varchar2

,   o_out_trd_seq_no            out       number
,   o_out_dpo_prerm             out       number
,   o_out_dpo_nowrm             out       number
,   o_out_acnt_place            out       varchar2
,   o_out_bnhof_tp              out       varchar2
,   o_out_proc_bnhof_tp         out       varchar2

,   o_in_trd_seq_no            out       number
,   o_in_dpo_prerm             out       number
,   o_in_dpo_nowrm             out       number
,   o_in_acnt_place            out       varchar2
,   o_in_bnhof_tp              out       varchar2
,   o_in_proc_bnhof_tp         out       varchar2
,   i_acc_cd_bank_num          in        varchar2 default ' '

)
AS

/*
   \file     drv_pcw_cash_acnt_trns_p.sql
   \brief

   \section intro Program Information
        - Program Name              :
        - Service Name              : N/A
        - Related Client Program- Client Program ID : Client 07307
        - Related Tables            : cwd10m00
        - Dev. Date                 : 2009/11/03
        - Developer                 : JUNG
        - Business Logic Desc.      :
        - Latest Modification Date  :

   \section history Program Modification History
    - 1.0       2007/11/30     ???    ????

   \section hardcoding Hard-Coding List
    - HC-1

   \section info Additional Reference Comments
    - ???? ??
*/

  t_proc_nm                         varchar2(100) ;
    t_err_txt                         varchar2(200);
    t_err_cd                          number;
    t_rtn_val                         char(1);
    t_work_dtm                        date;

  o_out_trd_dt                   varchar2(20);
  o_in_trd_dt                    varchar2(20);

    t_amt                             number;

    t_proc_brch                       varchar2(3);

    t_std_dt                          varchar2(08) ;

    t_tr_cd             varchar2(20);

  ts_acnt_stat             varchar2(20);
  ts_acnt_mng_bnh             varchar2(20);
  ts_agnc_brch             varchar2(20);
  ts_proc_bnhof_tp           varchar2(20) := ' ';

    ts_chyes          varchar2(1);

  tn_dpo            number := 0;
  tn_dpo_prerm        number := 0;
  tn_gst_dpo                  number := 0;
  tn_out_cnfm_lim      number := 0;

  tn_in_cnfm_lim      number := 0;

  tn_nonrpy_loan_amt          number := 0;
  tn_used_alowa               number := 0;
  tn_tot_out_psbamt           number := 0;

  t_ATDPST_found_yn      varchar2(1);

  t_trd_dt                varchar2(20) := ' ';
  t_trd_seq_no            number := 0;
  t_dpo_prerm             number := 0;
  t_dpo_nowrm             number := 0;
  t_acnt_place            varchar2(10) := ' ';
  t_bnhof_tp              varchar2(10) := ' ';
  t_proc_bnhof_tp         varchar2(10) := ' ';
  t_payrec_bidv_bank_acnt varchar2(30) := ' ';

    t_proc_brch_cd               varchar2(20) := Null;
    t_proc_agnc_brch             varchar2(20) := Null;
    t_mdm_bnh               varchar2(3);
    t_anct_mng_bnh          varchar2(3);

    t_err_msg    varchar2(500);
    t_seq_no     number := 0 ;

    t_acnt_no          varchar2(20) := null;
    t_gga_yn           varchar2(1) := null;  /* Same accounts : N, different accounts : Y */
    /* check so tien kha dung*/
    t_out_acc_drr_num    varchar2(100) := ' ';
    t_in_acc_drr_num    varchar2(100) := ' ';
    t_check_bank_acnt_no  varchar2(20) := ' ';

  tn_tot_dpo                  number := 0;
  tn_dpo_block             number := 0;
  tn_outq_dpo_bk           number := 0;
  tn_prof_dpo              number := 0;
  tn_reuse_dpo             number := 0;
  tn_sbst_dpo              number := 0;
  tn_sbst_able_block       number := 0;
  tn_sbst_block            number := 0;
  tn_sbst_proof            number := 0;
  tn_use_vd                number := 0;
  tn_mgn_loan_amt          number := 0;
  tn_mgn_lack              number := 0;
  tn_cd_lack               number := 0;
  tn_crd_dpo               number := 0;
  tn_used_alowa_rel        number := 0;
  tn_used_alowa_cd         number := 0;
  tn_used_alowa_vd         number := 0;
  tn_all_prof_rel          number := 0;
  tn_all_prof_cd           number := 0;
  tn_all_prof_vd           number := 0;
  tn_able_block            number := 0;
  t_loan_check             number := 0;
  t_payment_cwd06m00_seq            number := 0;
  t_receive_cwd06m00_seq            number := 0;
  t_fee_tax          NUMBER := 0;


BEGIN

/*============================================================================*/
/* ???? ???                                                            */
/*============================================================================*/

    t_proc_nm        :=  '?????:';
    t_work_dtm       :=  SYSDATE;
  t_ATDPST_found_yn           :=  'N';

    SELECT  vn.vhdate() INTO  t_std_dt       FROM  dual;

  t_tr_cd          := i_tr_cd;

  t_rtn_val := 'Y';

    vn.pxc_log_write('drv_pcw_cash_acnt_trns_p','out_acc : [' || i_outamt_acnt_no ||'] in_acc ['|| i_inamt_acnt_no || ']' );
    vn.pxc_log_write('drv_pcw_cash_acnt_trns_p','i_mdm_tp: ' || i_mdm_tp);
    vn.pxc_log_write('drv_pcw_cash_acnt_trns_p','i_cnfm_yn: ' || i_cnfm_yn);




    vn.pxc_log_write('drv_pcw_cash_acnt_trns_p',  'i_outamt_acnt_no ' ||i_outamt_acnt_no);
    vn.pxc_log_write('drv_pcw_cash_acnt_trns_p',  'i_out_sub_no ' ||i_out_sub_no);
    vn.pxc_log_write('drv_pcw_cash_acnt_trns_p',  'i_inamt_acnt_no ' ||i_inamt_acnt_no);
    vn.pxc_log_write('drv_pcw_cash_acnt_trns_p',  'i_inamt_acnt_no ' ||i_in_sub_no);
    vn.pxc_log_write('drv_pcw_cash_acnt_trns_p',  'i_cash ' ||i_cash);
    vn.pxc_log_write('drv_pcw_cash_acnt_trns_p',  'i_mdm_tp ' ||i_mdm_tp);
    vn.pxc_log_write('drv_pcw_cash_acnt_trns_p',  'i_tr_cd ' ||i_tr_cd);
    vn.pxc_log_write('drv_pcw_cash_acnt_trns_p',  'i_cnfm_yn ' ||i_cnfm_yn);
    vn.pxc_log_write('drv_pcw_cash_acnt_trns_p',  'i_dept_no_3 ' ||i_dept_no_3);
    vn.pxc_log_write('drv_pcw_cash_acnt_trns_p',  'i_cnte ' ||i_cnte);
    vn.pxc_log_write('drv_pcw_cash_acnt_trns_p',  'i_work_mn ' ||i_work_mn);
    vn.pxc_log_write('drv_pcw_cash_acnt_trns_p',  'i_work_trm ' ||i_work_trm);



/*============================================================================*/
/* ??????                                                               */
/*============================================================================*/

    if  i_cash  is  null  or  i_cash  <  0
    then
        t_err_txt  :=  t_proc_nm  ||  'input amt is error';
    t_err_msg := vn.fxc_get_err_msg('V','2707');
    raise_application_error(-20100,t_err_msg||t_err_txt);
    end if;


    if  i_trd_dt  IS  NULL
    then
        t_err_txt  :=  t_proc_nm  ||  'trd_dt is error';
    t_err_msg := vn.fxc_get_err_msg('V','2701');
    raise_application_error(-20100,t_err_msg||t_err_txt);
    end if;


/*============================================================================*/
/* INITIALIZE                                                                 */
/*============================================================================*/

  o_trd_dt             := vn.vwdate ;
    o_out_trd_seq_no     := '0';
    o_out_dpo_prerm      := '0';
    o_out_dpo_nowrm      := '0';
    o_out_acnt_place     := 'de';
    o_out_bnhof_tp       := 'de';
    o_out_proc_bnhof_tp  := 'de';
    o_in_trd_seq_no      := '0';
    o_in_dpo_prerm       := '0';
    o_in_dpo_nowrm       := '0';
    o_in_acnt_place      := 'def';
    o_in_bnhof_tp        := 'def';
    o_in_proc_bnhof_tp   := 'def';

    /* closing check */

  select decode(i_mdm_tp, '00', vn.fbm_emp_bnh_q( i_work_mn)
              , vn.faa_acnt_bnh_cd_g(  '0',i_outamt_acnt_no, i_out_sub_no))
      into t_mdm_bnh
    from dual;

    if  i_work_mn  not in ('DAILY','BATCH')
    then

        vn.pbm_cls_yn_q(  vn.vhdate
                       ,  t_mdm_bnh
                       ,  vn.faa_acnt_bnh_cd_g( '0',i_outamt_acnt_no, i_out_sub_no)
                       , '1'
                       ,  t_rtn_val
                       ,  t_err_txt
                       );

        if  t_rtn_val  !=  'N'
        then

           vn.pxc_log_write('drv_pcw_cash_acnt_trns_p','t_rtn_val-'||t_rtn_val);
           vn.pxc_log_write('drv_pcw_cash_acnt_trns_p','payment worker account : '|| vn.fbm_emp_bnh_q( i_work_mn) ||' '|| vn.faa_acnt_bnh_cd_g('0',i_outamt_acnt_no, i_out_sub_no) );

            t_err_msg := vn.fxc_get_err_msg('V','2716');
            raise_application_error(-20100,t_err_msg||t_err_txt);
        end if;

    end if;
    if i_out_sub_no <> '80' then
     BEGIN
         vn.pcw_outamt_psbamt_q
    (   i_outamt_acnt_no
        ,i_out_sub_no
        ,  '9999'
      ,  tn_dpo
      ,  tn_dpo_block
      ,  tn_outq_dpo_bk
      ,  tn_prof_dpo
      ,  tn_reuse_dpo
      ,  tn_sbst_dpo
      ,  tn_sbst_able_block
      ,  tn_sbst_proof
      ,  tn_gst_dpo
      ,  tn_use_vd
      ,  tn_nonrpy_loan_amt
      ,  tn_mgn_loan_amt
      ,  tn_mgn_lack
      ,  tn_cd_lack
      ,  tn_crd_dpo
      ,  tn_used_alowa_rel
      ,  tn_used_alowa_cd
      ,  tn_used_alowa_vd
      ,  tn_all_prof_rel
      ,  tn_all_prof_cd
      ,  tn_all_prof_vd
      ,  tn_able_block
      ,  tn_tot_out_psbamt
        );
      EXCEPTION
      WHEN  OTHERS         THEN
        vn.pxc_log_write('pcw_cash_acnt_trns_p','t_err_txt-'||sqlerrm);
          t_err_txt  :=  t_proc_nm
                 ||  'pcw_outamt_psbamt_q Error :'
                 ||  to_char(sqlcode);
        t_err_msg := vn.fxc_get_err_msg('V','2733');
        raise_application_error(-20100,t_err_msg||t_err_txt);
      END;

    else
    /*check tien kha dung jira 1169*/
   BEGIN
        vn.drv_pcw_outamt_psbamt_q(
        i_outamt_acnt_no         ,
        i_out_sub_no         ,
        '9999'              ,
        tn_dpo              ,
        tn_dpo_block        ,
        tn_outq_dpo_bk      ,
        tn_tot_out_psbamt   );
      EXCEPTION
      WHEN  OTHERS         THEN
        vn.pxc_log_write('pcw_cash_acnt_trns_p','t_err_txt-'||sqlerrm);
          t_err_txt  :=  t_proc_nm
                 ||  'pcw_outamt_psbamt_q Error :'
                 ||  to_char(sqlcode);
        t_err_msg := vn.fxc_get_err_msg('V','2733');
        raise_application_error(-20100,t_err_msg||t_err_txt);
      END;
     BEGIN
      select vn.fdr_get_unsetl_data (i_outamt_acnt_no,i_out_sub_no)
          into t_fee_tax
    from dual;
       EXCEPTION
       WHEN  OTHERS         THEN
          t_err_txt  :=  t_proc_nm
                       ||  ' fdr_get_unsetl_data  err:'
                       ||  to_char(sqlcode)
               ||' ' || i_outamt_acnt_no;
                t_err_msg := vn.fxc_get_err_msg('V','2704');
                raise_application_error(-20100,t_err_msg||t_err_txt);
       END;
       tn_tot_out_psbamt :=greatest(tn_tot_out_psbamt - t_fee_tax,0);
end if;
if i_cash > tn_tot_out_psbamt then
    t_err_msg := vn.fxc_get_err_msg('V','2726');
    raise_application_error(-20100,t_err_msg||t_err_txt);
    end if;
/* limite check */


   if i_cnfm_yn = 'N'  then

        select count(*) + 1
          into t_seq_no
          from vn.cwd06m00
         where INOUT_TP  = '02'
         and rmrk_cd = '026'
         and acnt_no = i_outamt_acnt_no;
 if i_out_sub_no ='80' then
    select vn.fdr_acnt_bank_tp_y_n(i_outamt_acnt_no,i_out_sub_no)
                 into t_check_bank_acnt_no from dual;
 if t_check_bank_acnt_no ='Y' then
 begin
             select BANK_ACC_NUM
              into t_out_acc_drr_num
                from DRCWDM01
                where CLS_DTM ='30000101'
                and BANK_TYPE ='CSG'
                 and rownum = 1;
                 exception
               when   no_data_found then
                 t_out_acc_drr_num := '!';
                 end;
 else
 begin
 select BANK_ACC_NUM
              into t_out_acc_drr_num
                from DRCWDM10
                where CLS_DTM ='30000101'
                and BANK_TYPE ='CSC'
                and acnt_no = i_outamt_acnt_no
                 and rownum = 1;
                 exception
               when   no_data_found then
                 t_out_acc_drr_num := '!';
                 end;
 end if;
 else
  select vn.fdr_acnt_bank_tp_y_n(i_inamt_acnt_no,i_in_sub_no)
                 into t_check_bank_acnt_no from dual;
                 if t_check_bank_acnt_no ='Y' then
 begin
             select BANK_ACC_NUM
              into t_in_acc_drr_num
                from DRCWDM01
                where CLS_DTM ='30000101'
                and BANK_TYPE ='CSG'
                 and rownum = 1;
                 exception
               when   no_data_found then
                 t_in_acc_drr_num := '!';
                 end;
 else
 begin
 select BANK_ACC_NUM
              into t_in_acc_drr_num
                from DRCWDM10
                where CLS_DTM ='30000101'
                and BANK_TYPE ='CSC'
                and acnt_no = i_inamt_acnt_no
                 and rownum = 1;
                 exception
               when   no_data_found then
                 t_in_acc_drr_num := '!';
                 end;
 end if;
 end if;
     /* insert payment acc */
      BEGIN


      vn.drv_pcw_inout_cnfm_ins_p(i_outamt_acnt_no
                  , i_out_sub_no
                  , '02'
                  , '026'
                  , i_cash
                  , i_work_mn
                  , i_work_trm
                  , t_out_acc_drr_num
                  , i_cnte
                  , t_seq_no
                  , i_mdm_tp
                  , NULL
                  , NULL
                  , i_bank_acnt_no
                  , 'N'
                  ,t_payment_cwd06m00_seq
                  );



      EXCEPTION
          WHEN  OTHERS         THEN
              t_err_txt  :=  t_proc_nm
                         ||  'pcw_inout_cnfm_p_err payment_acc :'
                         ||  to_char(sqlcode);
              vn.pxc_log_write('drv_pcw_cash_acnt_trns_p','t_err_txt-'||t_err_txt);
              t_err_msg := vn.fxc_get_err_msg('V','2732');
              raise_application_error(-20100,t_err_msg||t_err_txt);
      END;

    /* insert receive acc */
      BEGIN
        vn.drv_pcw_inout_cnfm_ins_p(i_inamt_acnt_no
                  , i_in_sub_no
                  , '01'
                  , '025'
                  , i_cash
                  , i_work_mn
                  , i_work_trm
                  , t_in_acc_drr_num
                  , i_cnte
                  , t_seq_no
                  , i_mdm_tp
                  , NULL
                  , NULL
                  , i_bank_acnt_no
                  , 'N'
                  ,t_receive_cwd06m00_seq
                  );

      EXCEPTION
          WHEN  OTHERS         THEN
             t_err_txt  :=  t_proc_nm
                         ||  'pcw_inout_cnfm_p_err receive :'
                         ||  to_char(sqlcode);
              vn.pxc_log_write('drv_pcw_cash_acnt_trns_p','t_err_txt-'||t_err_txt);
              t_err_msg := vn.fxc_get_err_msg('V','2732');
              raise_application_error(-20100,t_err_msg||t_err_txt);
      END ;

      BEGIN
      insert  into  vn.DRCWDM09
             (
                 seq_no
                ,outamt_acnt_no
                ,outamt_sub_no
                ,outamt_trd_seq_no
                ,outamt_rmrk_cd
                ,trd_amt
                ,inamt_acnt_no
                ,inamt_sub_no
                ,inamt_trd_seq_no
                ,cncl_yn
                ,cnte
                ,mdm_tp
                ,work_mn
                ,work_dtm
                ,work_trm
             )
        values
             (
                 vn.DRCWDM09_SEQ.nextval
                ,i_outamt_acnt_no
                ,i_out_sub_no
                ,t_payment_cwd06m00_seq
                ,'026'
                ,i_cash
                ,i_inamt_acnt_no
                ,i_in_sub_no
                ,t_receive_cwd06m00_seq
                ,'N'
                ,i_cnte
                ,i_mdm_tp
                ,i_work_mn
                ,sysdate
                ,i_work_trm
             );
    EXCEPTION
        WHEN  OTHERS         THEN
            t_err_txt  :=  t_proc_nm
                   ||  'insert cwd10m00 err _ 2 '
                   ||  to_char(sqlcode);
            t_err_msg := vn.fxc_get_err_msg('V','2702');
            raise_application_error(-20100,t_err_msg||t_err_txt);
    END;
      return ;

   end if ;   /* confirm  = 'N'  */


   if i_outamt_acnt_no = i_inamt_acnt_no then

    t_gga_yn := 'N';

   else
    t_gga_yn := 'Y';
   end if;
if i_out_sub_no ='80' then
    select vn.fdr_acnt_bank_tp_y_n(i_outamt_acnt_no,i_out_sub_no)
                 into t_check_bank_acnt_no from dual;
 if t_check_bank_acnt_no ='Y' then
 begin
             select BANK_ACC_NUM
              into t_out_acc_drr_num
                from DRCWDM01
                where CLS_DTM ='30000101'
                and BANK_TYPE ='CSG'
                 and rownum = 1;
                 exception
               when   no_data_found then
                 t_out_acc_drr_num := '!';
                 end;
 else
 begin
 select BANK_ACC_NUM
              into t_out_acc_drr_num
                from DRCWDM10
                where CLS_DTM ='30000101'
                and BANK_TYPE ='CSC'
                and acnt_no = i_outamt_acnt_no
                 and rownum = 1;
                 exception
               when   no_data_found then
                 t_out_acc_drr_num := '!';
                 end;
 end if;
 else
  select vn.fdr_acnt_bank_tp_y_n(i_inamt_acnt_no,i_in_sub_no)
                 into t_check_bank_acnt_no from dual;
                 if t_check_bank_acnt_no ='Y' then
 begin
             select BANK_ACC_NUM
              into t_in_acc_drr_num
                from DRCWDM01
                where CLS_DTM ='30000101'
                and BANK_TYPE ='CSG'
                 and rownum = 1;
                 exception
               when   no_data_found then
                 t_in_acc_drr_num := '!';
                 end;
 else
 begin
 select BANK_ACC_NUM
              into t_in_acc_drr_num
                from DRCWDM10
                where CLS_DTM ='30000101'
                and BANK_TYPE ='CSC'
                and acnt_no = i_inamt_acnt_no
                 and rownum = 1;
                 exception
               when   no_data_found then
                 t_in_acc_drr_num := '!';
                 end;
 end if;
 end if;

   BEGIN
    vn.drv_pcw_cash_inamt_15712_p
        (
        i_trd_dt
        ,   i_outamt_acnt_no
    ,   i_out_sub_no
        ,   '026'
        ,   i_cash
        ,   i_mdm_tp
        ,   i_tr_cd
        ,   'Y'
        ,   i_dept_no_3
        ,   t_out_acc_drr_num
        ,   i_cnte
    ,   t_gga_yn
        ,   i_work_mn
        ,   i_work_trm
        ,   i_bank_acnt_no
        ,   o_out_trd_dt
        ,   o_out_trd_seq_no
        ,   o_out_dpo_prerm
        ,   o_out_dpo_nowrm
        ,   o_out_acnt_place
        ,   o_out_bnhof_tp
        ,   o_out_proc_bnhof_tp
        );
   EXCEPTION
       WHEN  OTHERS         THEN
            t_err_txt  :=  t_proc_nm
                      ||  'payment err '
                      ||  to_char(sqlcode);
            t_err_msg := vn.fxc_get_err_msg('V','2712');
            raise_application_error(-20100,t_err_msg||t_err_txt);
      END;

   vn.pxc_log_write('drv_pcw_cash_acnt_trns_p','out_trd_seq_no ['||o_out_trd_seq_no||']');

   BEGIN
        vn.drv_pcw_cash_inamt_15711_p
        (
        i_trd_dt
        ,   i_inamt_acnt_no
    ,   i_in_sub_no
        ,   '025'
        ,   i_cash
        ,   i_mdm_tp
        ,   '0'
        ,   'Y'
        ,   i_dept_no_3
        ,   t_in_acc_drr_num
        ,   i_cnte
    ,   t_gga_yn
        ,   i_work_mn
        ,   i_work_trm
        ,   i_bank_acnt_no
        ,   o_in_trd_dt
        ,   o_in_trd_seq_no
        ,   o_in_dpo_prerm
        ,   o_in_dpo_nowrm
        ,   o_in_acnt_place
        ,   o_in_bnhof_tp
        ,   o_in_proc_bnhof_tp
        );
    EXCEPTION
    WHEN  OTHERS         THEN
        t_err_txt  :=  t_proc_nm
               ||  'pcw_cash_inamt_07301_p:'
               ||  to_char(sqlcode);
        t_err_msg := vn.fxc_get_err_msg('V','2711');
        raise_application_error(-20100,t_err_msg||t_err_txt);
    END;

    vn.pxc_log_write('drv_pcw_cash_acnt_trns_p','o_in_trd_seq_no ['|| o_in_trd_seq_no ||']');
BEGIN
   update DRCWDM09
   set OUTAMT_TRD_SEQ_NO = o_out_trd_seq_no
       ,INAMT_TRD_SEQ_NO = o_in_trd_seq_no
       where OUTAMT_TRD_SEQ_NO = i_seq;
       EXCEPTION
        WHEN  OTHERS         THEN
            t_err_txt  :=  t_proc_nm
                   ||  'update DRCWDM09 err _ 2 '
                   ||  to_char(sqlcode);
            t_err_msg := vn.fxc_get_err_msg('V','2702');
            raise_application_error(-20100,t_err_msg||t_err_txt);
    END;

  vn.pxc_log_write('drv_pcw_cash_acnt_trns_p','t_seq_no ['|| t_seq_no ||']');
end  drv_pcw_cash_acnt_trns_p;
/

