create procedure temp_pds_prof_lnd_clear
    ( i_dt          in     varchar2,        --
      i_lnd_tp      in     varchar2,        --
      i_acnt_no     in     varchar2,        --
      i_lnd_bank_cd in     varchar2,        --
      i_stk_cd      in     varchar2,        --
      i_work_mn     in     varchar2,        -- user id
      i_work_trm    in     varchar2,
      o_cnt         in out number
    ) AS

/*!
   \file     temp_pds_prof_lnd_clear.sql
   \brief    clear

   \section intro Program Information
        - Program Name              : clear
        - Service Name              : N/A
        - Related Client Program- Client Program ID : N/A
        - Related Tables            : tso04m00, dsc01m00
        - Dev. Date                 : 2007/11/08
        - Developer                 : Han.
        - Business Logic Desc.      : clear
        - Latest Modification Date  : 2007/11/08

   \section history Program Modification History
    - 1.0       2007/11/08     Han.    New.

   \section hardcoding Hard-Coding List
    - HC-1      2007/11/08     Han.    [��]

   \section info Additional Reference Comments
    - ���ű�����

var o_cnt number;
exec temp_pds_prof_lnd_clear('20100507','%','%','%','%','DAILY','DAILY',:o_cnt);
print o_cnt;
*/

    t_dt                varchar2(8) := null;
    t_td_setl_dt        varchar2(8) := null;
    t_pd_setl_dt        varchar2(8) := null;
    t_ppd_setl_dt       varchar2(8) := null;

    t_lnd_rm_amt        NUMBER      := 0;
    t_pd_sell_mth_qty   NUMBER      := 0;
    t_ppd_sell_mth_qty  NUMBER      := 0;
    t_pppd_sell_mth_qty NUMBER      := 0;

    o_cnt2             NUMBER       := 0;
    o_cnt3             NUMBER       := 0;

    ts_work_stat_min    VARCHAR2(1);
    ts_work_stat_max    VARCHAR2(1);

    t_err_msg           varchar2(500);

begin

	o_cnt  := 0;
	o_cnt2 := 0;
	o_cnt3 := 0;

    /*========================================================================*/
    /* Input Date CHECK                                                       */
    /*========================================================================*/

    if  vn.fxc_holi_ck(to_date(i_dt,'yyyymmdd')) !=  '0' then
    	if  i_work_mn <> 'DAILY' then
	        t_err_msg := vn.fxc_get_err_msg('V','2422');
	        t_err_msg := t_err_msg||' Date = '||i_dt;
	        raise_application_error(-20100,t_err_msg);
		else
			return;
		end if;
	end if;
/*
	if  vn.vwdate  !=  i_dt then
		t_err_msg := vn.fxc_get_err_msg('V','2422');
		raise_application_error(-20001,t_err_msg||' Date = '||i_dt);
	end if;
*/
    /*========================================================================*/
    /* Prededing job Check                                                    */
    /*========================================================================*/
/*
	if  i_acnt_no = '%' and
	    vn.fxb_daily_stat_chk ('E','0','2500','2500','*') <> 'Y' then
		t_err_msg := vn.fxc_get_err_msg('V','2458');
		t_err_msg := t_err_msg||'[2500],[2500]'||i_dt;
		raise_application_error(-20100,t_err_msg);
	end if;

	if  i_acnt_no = '%' and
	    vn.fxb_daily_stat_chk ('E','0','2650','2650','*') <> 'Y' then
		t_err_msg := vn.fxc_get_err_msg('V','2458');
		t_err_msg := t_err_msg||'[2650],[2650]'||i_dt;
		raise_application_error(-20100,t_err_msg);
	end if;
*/
    /*========================================================================*/
    /* Date Check                                                             */
    /*========================================================================*/
    t_dt          := i_dt;
    t_td_setl_dt  := vn.fxc_vorderdt_g(to_date(t_dt,'yyyymmdd'), 3);
    t_pd_setl_dt  := vn.fxc_vorderdt_g(to_date(t_dt,'yyyymmdd'), 2);
    t_ppd_setl_dt := vn.fxc_vorderdt_g(to_date(t_dt,'yyyymmdd'), 1);

/*============================================================================*/
/* ( )                                                                        */
/*============================================================================*/
    begin
    vn.temp_pdl_coll_loan_mrtg( i_dt,       i_acnt_no,
                           '%',        i_stk_cd,
                           i_work_mn,  i_work_trm,  o_cnt2 );
    exception
    when others then
        t_err_msg := vn.fxc_get_err_msg('V','9401');
        raise_application_error(-20011,t_err_msg||' ACNT_NO='||i_acnt_no||' TP=20');
    end;

    begin
    vn.temp_pdl_buy_loan_mrtg(  i_dt,       i_acnt_no,
                           '%',        i_stk_cd,
                           i_work_mn,  i_work_trm,  o_cnt3 );
    exception
    when others then
        t_err_msg := vn.fxc_get_err_msg('V','9401');
        raise_application_error(-20011,t_err_msg||' ACNT_NO='||i_acnt_no||' TP=30');
    end;
    /*========================================================================*/
    /* clear                                                                  */
    /*========================================================================*/
	for C1 in (
	    select  *
	      from  vn.dlm01m00
	     where  lnd_tp       like  i_lnd_tp
	       and  acnt_no      like  i_acnt_no
	       and  lnd_bank_cd  like  i_lnd_bank_cd
	       and  stk_cd       like  i_stk_cd
	       and  lnd_acpt_tp     =  '01'
	       and  (td_sell_ord_qty   >  0  or
	             td_sell_mth_qty   >  0  or
	             pd_sell_mth_qty   >  0  or
	             ppd_sell_mth_qty  >  0  or
	             pppd_sell_mth_qty >  0  )
	     order  by  lnd_tp, acnt_no, lnd_bank_cd, stk_cd
	) loop

	    /* prof Clear */
	    update  vn.dlm01m00
	       set  PPPD_SELL_MTH_QTY  =  PPD_SELL_MTH_QTY
	         ,  PPD_SELL_MTH_QTY   =  PD_SELL_MTH_QTY
	         ,  PD_SELL_MTH_QTY    =  TD_SELL_MTH_QTY
	         ,  TD_SELL_MTH_QTY    =  0
	         ,  TD_SELL_ORD_QTY    =  0
	         ,  PPPD_SELL_MTH_AMT  =  PPD_SELL_MTH_AMT
	         ,  PPD_SELL_MTH_AMT   =  PD_SELL_MTH_AMT
	         ,  PD_SELL_MTH_AMT    =  TD_SELL_MTH_AMT
	         ,  TD_SELL_MTH_AMT    =  0
	         ,  TD_SELL_ORD_AMT    =  0
	     where  lnd_tp          =  C1.lnd_tp
	       and  acnt_no         =  C1.acnt_no
	       and  lnd_dt          =  C1.lnd_dt
	       and  mth_dt          =  C1.mth_dt
	       and  lnd_bank_cd     =  C1.lnd_bank_cd
	       and  stk_cd          =  C1.stk_cd
	       and  lnd_acpt_tp     =  '01'
	    ;
	end loop;

    /*========================================================================*/
    /* Today trade data Create                                                */
    /*========================================================================*/
    for C2 in (
        select  x.acnt_no     acnt_no
             ,  x.lnd_dt      lnd_dt
             ,  x.mrtg_dt     mrtg_dt
             ,  x.lnd_bank_cd     bank_cd
             ,  x.stk_cd      stk_cd
             ,  x.cdt_tp      cdt_tp
             ,  x.sell_qty    sell_qty
             ,  x.buy_qty     buy_qty
          from (
                select  acnt_no
                     ,  lnd_dt
                     ,  mrtg_dt
                     ,  lnd_bank_cd
                     ,  stk_cd
                     ,  cdt_tp
                     ,  sum( decode(sb_tp,'1',decode(stk_setl_yn,'Y',0,nvl(sb_qty,0)),0) )   sell_qty
                     ,  sum( decode(sb_tp,'2',decode(stk_setl_yn,'Y',0,nvl(sb_qty,0)),0) )   buy_qty
                  from  vn.dsc01m00
                 where  setl_dt         =  t_td_setl_dt
                   and  acnt_no      like  i_acnt_no
                   and  stk_cd       like  i_stk_cd
                   and  bank_cd      like  i_lnd_bank_cd
                   and  cdt_tp       like  i_lnd_tp
                   and  cdt_tp         !=  '00'
                 group  by  acnt_no, lnd_dt, mrtg_dt, lnd_bank_cd, stk_cd, cdt_tp
                 order  by  acnt_no, lnd_dt, mrtg_dt, lnd_bank_cd, stk_cd, cdt_tp
                ) x
    ) loop
        o_cnt := o_cnt + 1;

        /* prof Clear */
        t_lnd_rm_amt := 0;
        begin
	    select  PD_SELL_MTH_QTY
	         ,  lnd_amt - lnd_rpy_amt rm_amt
	      into  t_pd_sell_mth_qty
	         ,  t_lnd_rm_amt
	      from  vn.dlm01m00
         where  lnd_tp          =  C2.cdt_tp
	       and  acnt_no         =  C2.acnt_no
	       and  lnd_dt          =  C2.lnd_dt
	       and  mth_dt          =  C2.mrtg_dt
	       and  lnd_bank_cd     =  C2.bank_cd
	       and  stk_cd          =  C2.stk_cd
           and  lnd_acpt_tp     =  '01'
	    ;
        exception
        when no_data_found then
            t_err_msg := vn.fxc_get_err_msg('V','2006');
            raise_application_error(-20100,t_err_msg||' ACNT_NO(C2)='||C2.acnt_no);
        when others then
            t_err_msg := vn.fxc_get_err_msg('V','9002');
            raise_application_error(-20011,t_err_msg||' acnt_no(C2)='||C2.acnt_no);
        end;

        if  t_lnd_rm_amt  >  0  then
            if  C2.sell_qty  <>  t_pd_sell_mth_qty  then
                t_err_msg := vn.fxc_get_err_msg('V','2445');
                raise_application_error(-20100,t_err_msg||' ACNT_NO(C2)='||C2.acnt_no||C2.stk_cd||'-'||C2.sell_qty||'-'||t_pd_sell_mth_qty);
            end if;
        end if;

    end loop;

    /*========================================================================*/
    /* Preday trade data Create                                               */
    /*========================================================================*/
    for C3 in (
        select  x.acnt_no     acnt_no
             ,  x.lnd_dt      lnd_dt
             ,  x.mrtg_dt     mrtg_dt
             ,  x.lnd_bank_cd     bank_cd
             ,  x.stk_cd      stk_cd
             ,  x.cdt_tp      cdt_tp
             ,  x.sell_qty    sell_qty
             ,  x.buy_qty     buy_qty
          from (
                select  acnt_no
                     ,  lnd_dt
                     ,  mrtg_dt
                     ,  lnd_bank_cd
                     ,  stk_cd
                     ,  cdt_tp
                     ,  sum( decode(sb_tp,'1',decode(stk_setl_yn,'Y',0,nvl(sb_qty,0)),0) )   sell_qty
                     ,  sum( decode(sb_tp,'2',decode(stk_setl_yn,'Y',0,nvl(sb_qty,0)),0) )   buy_qty
                  from  vn.dsc01m00
                 where  setl_dt     =  t_pd_setl_dt
                   and  acnt_no  like  i_acnt_no
                   and  stk_cd   like  i_stk_cd
                   and  bank_cd  like  i_lnd_bank_cd
                   and  cdt_tp   like  i_lnd_tp
                   and  cdt_tp     !=  '00'
                 group  by  acnt_no, lnd_dt, mrtg_dt, lnd_bank_cd, stk_cd, cdt_tp
                 order  by  acnt_no, lnd_dt, mrtg_dt, lnd_bank_cd, stk_cd, cdt_tp
                ) x
    ) loop
        o_cnt := o_cnt + 1;

        /* prof Clear */
        t_lnd_rm_amt := 0;
        begin
	    select  PPD_SELL_MTH_QTY
	         ,  lnd_amt - lnd_rpy_amt rm_amt
	      into  t_ppd_sell_mth_qty
	         ,  t_lnd_rm_amt
	      from  vn.dlm01m00
         where  lnd_tp          =  C3.cdt_tp
	       and  acnt_no         =  C3.acnt_no
	       and  lnd_dt          =  C3.lnd_dt
	       and  mth_dt          =  C3.mrtg_dt
	       and  lnd_bank_cd     =  C3.bank_cd
	       and  stk_cd          =  C3.stk_cd
           and  lnd_acpt_tp     =  '01'
	    ;
        exception
        when no_data_found then
            t_err_msg := vn.fxc_get_err_msg('V','2006');
            raise_application_error(-20100,t_err_msg||' ACNT_NO(C3)='||C3.acnt_no);
        when others then
            t_err_msg := vn.fxc_get_err_msg('V','9002');
            raise_application_error(-20011,t_err_msg||' acnt_no(C3)='||C3.acnt_no);
        end;

        if  t_lnd_rm_amt  >  0  then
            if  C3.sell_qty  <>  t_ppd_sell_mth_qty  then
                t_err_msg := vn.fxc_get_err_msg('V','2445');
                raise_application_error(-20100,t_err_msg||' ACNT_NO(C3)='||C3.acnt_no||C3.stk_cd||'-'||C3.sell_qty||'-'||t_ppd_sell_mth_qty);
            end if;
        end if;

    end loop;

    /*========================================================================*/
    /* Preday trade data Create                                               */
    /*========================================================================*/
    for C4 in (
        select  x.acnt_no     acnt_no
             ,  x.lnd_dt      lnd_dt
             ,  x.mrtg_dt     mrtg_dt
             ,  x.lnd_bank_cd     bank_cd
             ,  x.stk_cd      stk_cd
             ,  x.cdt_tp      cdt_tp
             ,  x.sell_qty    sell_qty
             ,  x.buy_qty     buy_qty
          from (
                select  acnt_no
                     ,  lnd_dt
                     ,  mrtg_dt
                     ,  lnd_bank_cd
                     ,  stk_cd
                     ,  cdt_tp
                     ,  sum( decode(sb_tp,'1',decode(stk_setl_yn,'Y',0,nvl(sb_qty,0)),0) )   sell_qty
                     ,  sum( decode(sb_tp,'2',decode(stk_setl_yn,'Y',0,nvl(sb_qty,0)),0) )   buy_qty
                  from  vn.dsc01m00
                 where  setl_dt     =  t_ppd_setl_dt
                   and  acnt_no  like  i_acnt_no
                   and  stk_cd   like  i_stk_cd
                   and  bank_cd  like  i_lnd_bank_cd
                   and  cdt_tp   like  i_lnd_tp
                   and  cdt_tp     !=  '00'
                 group  by  acnt_no, lnd_dt, mrtg_dt, lnd_bank_cd, stk_cd, cdt_tp
                 order  by  acnt_no, lnd_dt, mrtg_dt, lnd_bank_cd, stk_cd, cdt_tp
                ) x
    ) loop
        o_cnt := o_cnt + 1;

        /* prof Clear */
        t_lnd_rm_amt := 0;
        begin
	    select  PPPD_SELL_MTH_QTY
	         ,  lnd_amt - lnd_rpy_amt rm_amt
	      into  t_pppd_sell_mth_qty
	         ,  t_lnd_rm_amt
	      from  vn.dlm01m00
         where  lnd_tp          =  C4.cdt_tp
	       and  acnt_no         =  C4.acnt_no
	       and  lnd_dt          =  C4.lnd_dt
	       and  mth_dt          =  C4.mrtg_dt
	       and  lnd_bank_cd     =  C4.bank_cd
	       and  stk_cd          =  C4.stk_cd
	       and  lnd_acpt_tp     =  '01'
	    ;
        exception
        when no_data_found then
            t_err_msg := vn.fxc_get_err_msg('V','2006');
            raise_application_error(-20100,t_err_msg||' ACNT_NO(C4)='||C4.acnt_no);
        when others then
            t_err_msg := vn.fxc_get_err_msg('V','9002');
            raise_application_error(-20011,t_err_msg||' acnt_no(C4)='||C4.acnt_no);
        end;

        if  t_lnd_rm_amt  >  0  then
            if  C4.sell_qty  <>  t_pppd_sell_mth_qty  then
                t_err_msg := vn.fxc_get_err_msg('V','2445');
                raise_application_error(-20100,t_err_msg||' ACNT_NO(C4)='||C4.acnt_no||C4.stk_cd||'-'||C4.sell_qty||'-'||t_ppd_sell_mth_qty);
            end if;
        end if;

    end loop;

end temp_pds_prof_lnd_clear;
/

