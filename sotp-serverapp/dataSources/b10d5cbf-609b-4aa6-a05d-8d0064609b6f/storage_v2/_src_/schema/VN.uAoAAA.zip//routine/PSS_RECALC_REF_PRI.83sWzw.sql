create procedure pss_recalc_ref_pri(i_sec_cd in varchar2,
                                               i_stk_cd in varchar2 default '%') as
  o_tmp number := 0;
  o_ct  number := 0;
  v_holiday   varchar2(1);
  v_work_mn   varchar2(30);
  v_new_ref_pri number;
begin
  -- Neu la ngay nghi thi khong chay nua
  select vn.fxc_holi_ck(sysdate) into v_holiday from dual;

  if v_holiday = '0' then -- Ngay lam viec
    -- Gia tham chieu cho Ngay giao dich khong huong quyen
    for c1 in (SELECT a.stk_cd,
                      (a.max_pri + a.dn_pri) / 2 ref_pri_new,
                      b.cls_pri
                FROM ssi02m00 a, ssi01h00_pd b, ssi01m00 c, srr01m00 d
                WHERE a.stk_cd = b.stk_cd
                  AND a.stk_cd = c.stk_cd
                  AND a.stk_id = c.stk_id
                  AND c.stk_mkt_tp = '1'
                  AND a.stk_id <> 'XXXX'
                  AND a.stk_cd like i_stk_cd
                  AND a.stk_cd = d.stk_cd
                  AND vn.vwdate = (select vn.fxc_vorderdt_g(to_date(d.rgt_std_dt, 'YYYYMMDD'), -1) from dual)
                  AND ABS((a.max_pri + a.dn_pri) / 2 - b.cls_pri) > 100
                  AND a.stk_tp = '10'
              union
              SELECT a.stk_cd,
                      (a.max_pri + a.dn_pri) / 2 ref_pri_new,
                      b.cls_pri
                FROM ssi03m00 a, ssi01h00_pd b, ssi01m00 c, srr01m00 d
                WHERE a.stk_cd = b.stk_cd
                  AND a.stk_cd = c.stk_cd
                  AND a.stk_id = c.stk_id
                  AND c.stk_mkt_tp = '2'
                  AND a.stk_id <> 'XXXX'
                  AND a.stk_cd like i_stk_cd
                  AND a.stk_cd = d.stk_cd
                  AND vn.vwdate = (select vn.fxc_vorderdt_g(to_date(d.rgt_std_dt, 'YYYYMMDD'), -1) from dual)
                  AND ABS((a.max_pri + a.dn_pri) / 2 - b.cls_pri) > 100
                  AND a.stk_tp = '10'
              union
              SELECT a.stk_cd,
                      (a.high_pri + a.low_pri) / 2 ref_pri_new,
                      b.cls_pri
                FROM ssi04m00 a, ssi01h00_pd b, ssi01m00 c, srr01m00 d
                WHERE a.stk_cd = b.stk_cd
                  AND a.stk_cd = c.stk_cd
                  AND a.stk_id = c.stk_id
                  AND c.stk_mkt_tp = '3'
                  AND a.stk_id <> 'XXXX'
                  AND a.stk_cd like i_stk_cd
                  AND a.stk_cd = d.stk_cd
                  AND vn.vwdate = (select vn.fxc_vorderdt_g(to_date(d.rgt_std_dt, 'YYYYMMDD'), -1) from dual)
                  AND ABS((a.high_pri + a.low_pri) / 2 - b.cls_pri) > 100
                  AND a.stk_tp = '10'
              union
              SELECT a.stk_cd,
                      (a.max_pri + a.dn_pri) / 2 ref_pri_new,
                      b.cls_pri
                FROM ssi03m10 a, ssi01h00_pd b, ssi01m00 c, srr01m00 d
                WHERE a.stk_cd = b.stk_cd
                  AND a.stk_cd = c.stk_cd
                  AND a.stk_id = c.stk_id
                  AND c.stk_mkt_tp = '4'
                  AND a.stk_id <> 'XXXX'
                  AND a.stk_cd like i_stk_cd
                  AND a.stk_cd = d.stk_cd
                  AND vn.vwdate = (select vn.fxc_vorderdt_g(to_date(d.rgt_std_dt, 'YYYYMMDD'), -1) from dual)
                  AND ABS((a.max_pri + a.dn_pri) / 2 - b.cls_pri) > 100
                  AND a.stk_tp = '10') loop
      update ssi01h00_pd
        set cls_pri  = c1.ref_pri_new,
            work_mn  = 'SEC_MODIFIER',
            work_dtm = sysdate,
            work_trm = 'SEC_MODIFIER'
      where stk_cd = c1.stk_cd;

      update ssi01h00
        set cls_pri = c1.ref_pri_new,
            work_mn  = 'SEC_MODIFIER',
            work_dtm = sysdate,
            work_trm = 'SEC_MODIFIER'
      where stk_cd = c1.stk_cd
        and dt = to_char(fxc_orderdt_g(to_date(vwdate,'YYYYMMDD'),-1),'YYYYMMDD');

      vn.pxc_log_write('pss_recalc_ref_pri',
                      'Update ' || c1.stk_cd || ' price from ' || c1.cls_pri ||
                      ' to ' || c1.ref_pri_new);
      -- danh gia tai san cho nhung sub <> 00 va khong phai margin, nhung sub margin dc danh gia trong thu tuc auto, duoc chay ngay sau thu tuc nay
      for c2 in (select a.acnt_no, a.sub_no
                  from vn.ssb01m00 a
                  where a.own_qty > 0
                    and a.stk_cd = c1.stk_cd
                    and a.sub_no <> '00'
                    /*and vn.pkg_setl_multi_capital.fdl_get_mrgn_yn(a.acnt_no,a.sub_no,vn.vwdate()) = 'N'*/
                union
                select b.acnt_no, b.sub_no
                  from vn.tso04m00 b
                  where b.stk_cd = c1.stk_cd
                    and b.td_buy_mth_qty + b.pd_buy_mth_qty +
                        b.ppd_buy_mth_qty > 0
                    and b.sub_no <> '00'
                    /*and vn.pkg_setl_multi_capital.fdl_get_mrgn_yn(b.acnt_no,b.sub_no,vn.vwdate()) = 'N'*/) loop
        vn.pxc_log_write('pss_recalc_ref_pri','Danh gia tai san cho ' || c2.acnt_no||'-'||c2.sub_no);
        vn.pdl_crd_loan_rt_proc_td(
                                  vwdate,
                                  '2', -- '1':cash  '2':stock  '%':All
                                  c2.acnt_no,
                                  c2.sub_no,
                                  1, -- trd_no
                                  'SEC_MODIFIER',
                                  '127.0.0.1',
                                  o_ct);
      end loop; -- end c2

      o_tmp := o_tmp + 1;
    end loop; -- end c1
    commit;
    vn.pxc_log_write('pss_recalc_ref_pri', 'Update price for ' || o_tmp || ' stocks!');
    -- Cap nhat gia tham chieu cho san HNX
    for c3 in (
      select a.stk_cd,std_pri
      from vn.ssi03m00 a, vn.ssi01m00 b
      where a.stk_cd= b.stk_cd
      and b.stk_mkt_tp = '2'
      and a.std_pri <> a.cls_pri
      and a.stk_id not like '%XX%'
      ) loop
      v_work_mn := null; -- reset v_work_mn

      select work_mn into v_work_mn from ssi01h00_pd where stk_cd = c3.stk_cd;

      if v_work_mn <> 'SEC_MODIFIER' then -- Nếu mã ck chưa bị điều chỉnh giá thì mới thực hiện điều chỉnh

        update vn.ssi03m00
        set pd_cls_pri = c3.std_pri,
            cls_pri    = c3.std_pri
        where stk_cd=c3.stk_cd;

        update ssi01h00_pd
        set cls_pri = c3.std_pri,
            work_mn  = 'SEC_MODIFIER',
            work_dtm = sysdate,
            work_trm = 'SEC_MODIFIER'
        where stk_cd =c3.stk_cd;

        update ssi01h00
          set cls_pri = c3.std_pri,
              work_mn  = 'SEC_MODIFIER',
              work_dtm = sysdate,
              work_trm = 'SEC_MODIFIER'
        where stk_cd = c3.stk_cd
          and dt = to_char(fxc_orderdt_g(to_date(vwdate,'YYYYMMDD'),-1),'YYYYMMDD');

            for c5 in (select a.acnt_no, a.sub_no
                    from vn.ssb01m00 a
                    where a.own_qty > 0
                      and a.stk_cd = c3.stk_cd
                      and a.sub_no <> '00'
                  union
                  select b.acnt_no, b.sub_no
                    from vn.tso04m00 b
                    where b.stk_cd = c3.stk_cd
                      and b.td_buy_mth_qty + b.pd_buy_mth_qty +
                          b.ppd_buy_mth_qty > 0
                      and b.sub_no <> '00') loop
          vn.pxc_log_write('pss_recalc_ref_pri','Danh gia tai san cho ' || c5.acnt_no||'-'||c5.sub_no);
          vn.pdl_crd_loan_rt_proc_td(
                                    vwdate,
                                    '2', -- '1':cash  '2':stock  '%':All
                                    c5.acnt_no,
                                    c5.sub_no,
                                    1, -- trd_no
                                    'SEC_MODIFIER',
                                    '127.0.0.1',
                                    o_ct);
        end loop; -- end c5
      end if; -- End check v_work_mn
    end loop; /*Update lai gia tham chieu cho cac ma san HNX*/
    vn.pxc_log_write('pss_recalc_ref_pri', 'Finish update price for HNX');
    -- Cap nhat gia tham chieu cho san UpCOM
    for c4 in (
      select a.stk_cd,std_pri
      from vn.ssi03m10 a, vn.ssi01m00 b
      where a.stk_cd=b.stk_cd
      and b.stk_mkt_tp = '4'
      and a.std_pri <> a.avg_pri
      and a.stk_id not like '%XX%'
      ) loop
        v_work_mn := null; -- reset v_work_mn

        select work_mn into v_work_mn from ssi01h00_pd where stk_cd = c4.stk_cd;

        if v_work_mn <> 'SEC_MODIFIER' then -- Nếu mã ck chưa bị điều chỉnh giá thì mới thực hiện điều chỉnh

          update vn.ssi03m10
          set pd_cls_pri =c4.std_pri,
              avg_pri = c4.std_pri
          where stk_cd=c4.stk_cd;

          update ssi01h00_pd
          set cls_pri = c4.std_pri,
              work_mn  = 'SEC_MODIFIER',
              work_dtm = sysdate,
              work_trm = 'SEC_MODIFIER'
          where stk_cd =c4.stk_cd;

          update ssi01h00
            set cls_pri = c4.std_pri,
                work_mn  = 'SEC_MODIFIER',
                work_dtm = sysdate,
                work_trm = 'SEC_MODIFIER'
          where stk_cd = c4.stk_cd
            and dt = to_char(fxc_orderdt_g(to_date(vwdate,'YYYYMMDD'),-1),'YYYYMMDD');

        end if; -- End check v_work_mn
    end loop; /*Update lai gia tham chieu cho cac ma san UPC*/
    vn.pxc_log_write('pss_recalc_ref_pri', 'Finish update price for UPC');

    -- Cap nhat gia tham chieu cho san HSX
    for c6 in
    ( select s1.stk_cd,s2.cls_pri,s2.pd_cls_pri, (s2.max_pri + s2.dn_pri) / 2 as new_ref_pri
    from ssi01m00 s1, ssi02m00 s2
    where s1.stk_mkt_tp = '1'
    and s1.stk_cd = s2.stk_cd
    and s1.stk_id not like 'XX%'
    and s2.cls_pri <> (s2.max_pri + s2.dn_pri) / 2
    and s2.list_dt = vwdate)
    loop
      v_work_mn := null; -- reset v_work_mn

      select work_mn into v_work_mn from ssi01h00_pd where stk_cd = c6.stk_cd;

      if v_work_mn <> 'SEC_MODIFIER' then -- Nếu mã ck chưa bị điều chỉnh giá thì mới thực hiện điều chỉnh

        v_new_ref_pri := 0;

        if c6.new_ref_pri < 10000 then -- Lam tron theo buoc gia
          v_new_ref_pri := ceil (c6.new_ref_pri / 10) * 10 ;
        elsif c6.new_ref_pri < 50000 then
          v_new_ref_pri := ceil (c6.new_ref_pri / 50) * 50 ;
        else
          v_new_ref_pri := ceil (c6.new_ref_pri / 100) * 100 ;
        end if;

        vn.pxc_log_write('pss_recalc_ref_pri', 'v_new_ref_pri of ' || c6.stk_cd || ' is ' || v_new_ref_pri);

        if v_new_ref_pri <> c6.cls_pri then

          vn.pxc_log_write('pss_recalc_ref_pri', 'Update ref pri of ' || c6.stk_cd
                                                || ' from ' || c6.pd_cls_pri || ' to ' || v_new_ref_pri);
          update ssi02m00
          set --pd_cls_pri = v_new_ref_pri,
              cls_pri    = v_new_ref_pri
          where stk_cd   = c6.stk_cd;

          update ssi01h00_pd
          set cls_pri  = v_new_ref_pri,
              work_mn  = 'SEC_MODIFIER',
              work_dtm = sysdate,
              work_trm = 'SEC_MODIFIER'
          where stk_cd = c6.stk_cd;

          update ssi01h00
            set cls_pri = v_new_ref_pri,
                work_mn  = 'SEC_MODIFIER',
                work_dtm = sysdate,
                work_trm = 'SEC_MODIFIER'
          where stk_cd = c6.stk_cd
            and dt = to_char(fxc_orderdt_g(to_date(vwdate,'YYYYMMDD'),-1),'YYYYMMDD');

          -- DGTS nhung tai khoan bi anh huong
          for c7 in
          ( select a.acnt_no, a.sub_no
              from vn.ssb01m00 a
            where a.own_qty > 0
              and a.stk_cd = c6.stk_cd
              and a.sub_no <> '00'
            union
            select b.acnt_no, b.sub_no
              from vn.tso04m00 b
            where b.stk_cd = c6.stk_cd
              and b.td_buy_mth_qty + b.pd_buy_mth_qty + b.ppd_buy_mth_qty > 0
              and b.sub_no <> '00')
          loop
            vn.pxc_log_write('pss_recalc_ref_pri','Danh gia tai san cho ' || c7.acnt_no||'-'||c7.sub_no);
            vn.pdl_crd_loan_rt_proc_td(
              vwdate,
              '2', -- '1':cash  '2':stock  '%':All
              c7.acnt_no,
              c7.sub_no,
              1, -- trd_no
              'SEC_MODIFIER',
              '127.0.0.1',
              o_ct);
          end loop; -- End DGTS
        end if; -- End v_new_ref_pri <> c6.cls_pri
      end if; -- End v_work_mn <> 'SEC_MODIFIER'
    end loop; -- End cap nhat gia tham chieu cho san HSX

    vn.pxc_log_write('pss_recalc_ref_pri', 'Finished at ' || to_char(sysdate,'DD-Mon-YYYY hh24:mi:ss'));
  else
    vn.pxc_log_write('pss_recalc_ref_pri', 'Today (' || to_char(sysdate,'DD-Mon-YYYY') || ') is holiday.');
  end if;

end pss_recalc_ref_pri;
/

