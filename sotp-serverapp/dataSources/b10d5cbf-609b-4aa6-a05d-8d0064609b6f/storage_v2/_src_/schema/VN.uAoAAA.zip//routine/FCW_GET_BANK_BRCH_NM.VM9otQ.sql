create function fcw_get_bank_brch_nm
(
       i_bank_branch in varchar2
)return varchar2 as
o_bank_branch_nm varchar2(200);
begin
  select nvl(bankname,'!')
  into o_bank_branch_nm
  from cww10m00
  where bankcode = i_bank_branch;

  return o_bank_branch_nm;
  exception
    when others then
      pxc_log_write('fcw_get_bank_brch_nm',sqlerrm);
end fcw_get_bank_brch_nm;
/

