create function fcw_cash_dpo_buy
(
    i_acnt_no    in   varchar2,
    i_sub_no     in   varchar2,
    i_from_dt    in   varchar2,
    i_to_dt      in   varchar2,
    i_type       in   varchar2
)
  return          varchar2
as
    t_dpo        number := 0 ;
    t_buy        number := 0 ;
    t_count      number := 0 ;    
    
    i_min_dt    varchar2(8);
    i_max_dt    varchar2(8);    
 
    t_err_txt        varchar2(100)  ; 

begin

if i_type = '1' then
  
  select nvl((dpo),0) dpo 
    into t_dpo
    from(  
        select a.dpo dpo from vn.cwd01m00 a  
         where a.acnt_no = i_acnt_no
           and a.sub_no = i_sub_no 
           and vn.vhdate between i_from_dt and i_to_dt
        UNION  ALL                  
        Select t.dpo dpo from vn.cwd01h00 t 
         where t.acnt_no = i_acnt_no 
					 and t.sub_no = i_sub_no 
					 /*and t.std_dt < i_from_dt*/
           and t.std_dt between i_from_dt and i_to_dt 
					 and rownum < 2  
					 and t.std_dt = (select max(x.std_dt) from vn.cwd01h00 x 
					                  where x.acnt_no = i_acnt_no 
													    and x.sub_no = i_sub_no 
													    /*and x.std_dt <  i_from_dt */
                              and x.std_dt between i_from_dt and i_to_dt
                              and x.std_dt >= '20120101'))  
   where rownum = 1;
                              
return t_dpo ;                             	
  
elsif i_type = '2' then

			 select	count(*)
				 into t_count
				 from vn.aaa10m00
				where trd_dt between i_from_dt and i_to_dt
					and acnt_no = i_acnt_no		 
					and sub_no = i_sub_no
					and trd_tp in ('10', '11', '30', '31', '40', '41', '60', '61');
          
          if t_count > 0 then 

				     select	min(trd_dt),
						        max(trd_dt) 
				       into i_min_dt,
						        i_max_dt
				       from vn.aaa10m00
				      where trd_dt between i_from_dt and i_to_dt
                and acnt_no = i_acnt_no		 
                and sub_no = i_sub_no
                and trd_tp in ('10', '11', '30', '31', '40', '41', '60', '61');
          else
                i_min_dt := i_from_dt;
                i_max_dt := i_to_dt; 
          end if; 					
  

			select 	to_char(nvl(sum(buy_amt), 0))
				into 	t_buy
				from 
					(select nvl(td_buy_mth_amt, 0) + nvl(pd_buy_mth_amt, 0) + nvl(ppd_buy_mth_amt, 0) + nvl(pppd_buy_mth_amt, 0) buy_amt 
					from vn.tso02m00 
					where acnt_no = i_acnt_no
					and  sub_no = i_sub_no	
					and vn.vhdate = i_max_dt          	
					union all
					select nvl(td_cash_prof_amt, 0) + nvl(pd_cash_prof_amt, 0) + nvl(ppd_cash_prof_amt, 0) + nvl(pppd_cash_prof_amt , 0) buy_amt 
					from vn.tso02h00 
					where acnt_no = i_acnt_no 
					 and sub_no = i_sub_no
					and dt = i_max_dt 
					and vn.vhdate <> i_max_dt) ;
          
/*          if vn.vhdate = '20130106' then
            
             select nvl(td_buy_mth_amt, 0) + nvl(pd_buy_mth_amt, 0) + nvl(ppd_buy_mth_amt, 0) + nvl(pppd_buy_mth_amt, 0) buy_amt  
			         into t_buy             
               from vn.tso02m00 
          		where acnt_no = i_acnt_no
                and sub_no = i_sub_no
				        and vn.vhdate <= i_to_dt ;
          end if ;	*/
            
                              
return t_buy ;            

end if ;

    exception
        when  NO_DATA_FOUND  then
      return  '0';
        when  OTHERS         then
            t_err_txt  :=  '['||to_char(sqlcode)||']';
            raise_application_error (-20100, t_err_txt||'*'||i_acnt_no||'*'||i_sub_no||'*'||t_dpo||'*'||t_buy );

end fcw_cash_dpo_buy;
/

