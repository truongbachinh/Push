create procedure psr_rgt_std_p
( i_proc_tp    in       varchar2,
  i_std_dt     in       varchar2,
  i_stk_cd     in       varchar2,
  i_rgt_tp     in       varchar2,
  i_seq_no     in       number,
  i_work_mn    in       varchar2,
  i_work_trm   in       varchar2,
  o_proc_cnt   in out   number
 ) is

 vs_stk_cd    varchar2(12);
 vs_rgt_tp    varchar2(1) ;
 vn_seq_no    number := 0;
 vn_std_rt    number := 0;
 vn_std_rt2   number := 0;
 vn_stk_rt	  number := 0;

begin

 o_proc_cnt := 0;

 if i_proc_tp = 'I' then

     vn.pxc_log_write('psr_rgt_std_p', i_std_dt||i_stk_cd||i_rgt_tp);

	for  c1  in (

       select   stk_cd,
			    rgt_tp,
				seq_no,
				nvl(std_rt,1)     std_rt,
				nvl(std_pay_rt,1) std_rt2,
				decode(rgt_tp,'7', nvl(divi_stk_rt,100)/100, 1) stk_rt
       from     vn.srr01m00
       where    rgt_std_dt    =  i_std_dt
       and      stk_cd        =  i_stk_cd
       and      rgt_tp        =  i_rgt_tp
	   and      seq_no        =  i_seq_no
       and      rgt_proc_stat = '1'

    ) loop

      vs_rgt_tp  := c1.rgt_tp;
	  vs_stk_cd  := c1.stk_cd;
	  vn_seq_no  := c1.seq_no;
      vn_std_rt  := c1.std_rt;
	  vn_std_rt2 := c1.std_rt2;
	  vn_stk_rt  := c1.stk_rt;

	  if vn_std_rt = 0 then
		 vn_std_rt := 1;
	  end if;

      vn.pxc_log_write('psr_rgt_std_p', c1.rgt_tp);

	  for  c2  in (

         select  a.acnt_no acnt_no,
				 a.sub_no  sub_no,
		         a.stk_cd stk_cd,
		         trunc( ( a.own_qty + a.cd_qty  + nvl(a.DPO_QTY,0))  * (vn_std_rt2 / vn_std_rt) ) * vn_stk_rt  own_qty,
				 a.mrtg_lnd_qty   mrtg_lnd_qty ,
				 b.acnt_mng_bnh   mng_bnh
         from    vn.ssb01h00 a ,
				 vn.aaa01m00 b
         where   a.rgt_std_dt = i_std_dt
         and     a.stk_cd     = vs_stk_cd
	     and     ( a.own_qty + nvl(a.cd_qty,0) )   > 0
		 and     a.acnt_no = b.acnt_no
		 and     a.sub_no  = b.sub_no
		 and     b.acnt_stat = '1'

      ) loop

        vn.pxc_log_write('psr_rgt_std_p', c2.acnt_no||c2.sub_no);
		vn.pxc_log_write('psr_rgt_std_p', c2.own_qty);

		insert into  vn.srr02m00
		 ( rgt_std_dt    ,
		   acnt_no       ,
		   sub_no        ,
		   stk_cd        ,
		   rgt_tp        ,
           seq_no        ,
		   acnt_mng_bnh  ,
		   own_stk_qty	 ,
		   own_qty       ,
		   asn_qty       ,
		   asn_amt       ,
		   flotq_amt     ,
		   mrtg_lnd_qty  ,
           mrtg_asn_qty  ,
		   inq_trd_no    ,
		   rcpt_trd_no   ,
           outq_trd_no   ,
		   outamt_trd_no ,
		   flotq_trd_no  ,
		   inter_trd_no	 ,
		   cons_sbst_qty ,
		   cons_sbst_amt ,
		   conv_yn		 ,
		   work_mn       ,
		   work_dtm      ,
		   work_trm
         ) values  (
		   i_std_dt       ,
           c2.acnt_no     ,
		   c2.sub_no      ,
		   vs_stk_cd      ,
           vs_rgt_tp      ,
           vn_seq_no      ,
		   c2.mng_bnh     ,
		   c2.own_qty     ,
		   c2.own_qty     ,
		   0              ,
		   0              ,
		   0              ,
		   c2.mrtg_lnd_qty,
		   0              ,
           0              ,
		   0              ,
		   0              ,
           0              ,
		   0              ,
		   0			  ,
		   0              ,
		   0              ,
		   decode(vs_rgt_tp,'7','N',''),
	       i_work_mn      ,
		   sysdate        ,
		   i_work_trm
         ) ;

      end loop;

	 update  vn.srr01m00
	 set     rgt_proc_stat = '2'
     where   rgt_std_dt    = i_std_dt
	 and     stk_cd        = vs_stk_cd
	 and     rgt_tp        = vs_rgt_tp
	 and     seq_no        = vn_seq_no;

   o_proc_cnt := o_proc_cnt + 1;

   end loop;

   vn.pxc_log_write('psr_rgt_std_p', '1 '|| to_char( o_proc_cnt ) );

/* chage stock code  */

   for c3 in (
	  select stk_cd                    ,
			 '8'               rgt_tp  ,
			 nvl(std_pay_rt,1) std_rt2 ,
			 nvl(std_rt,1)     std_rt
        from vn.srr01m10
       where stk_cd     = i_stk_cd
		 and rgt_std_dt = i_std_dt
		 and i_rgt_tp   = '8'
		 and rgt_proc_stat = 1
     )loop

      vs_rgt_tp  := c3.rgt_tp;
      vs_stk_cd  := c3.stk_cd;
      vn_std_rt  := c3.std_rt;
      vn_std_rt2 := c3.std_rt2;

      if vn_std_rt2 = 0 then
         vn_std_rt2 := 1;
      end if;

      for  c4  in (

         select  a.acnt_no acnt_no,
                 a.sub_no sub_no,
                 a.stk_cd stk_cd,
                 trunc(a.own_qty * vn_std_rt / vn_std_rt2)  own_qty,
                 a.mrtg_lnd_qty mrtg_lnd_qty,
                 vn.faa_acnt_bnh_cd_g( '0',a.acnt_no, a.sub_no)  bnh_cd
         from    vn.ssb01h00 a ,
                 vn.aaa01m00 b
         where   a.rgt_std_dt = i_std_dt
         and     a.stk_cd     = vs_stk_cd
         and     a.own_qty  > 0
         and     a.acnt_no = b.acnt_no
		 and     a.sub_no  = b.sub_no
         and     b.acnt_stat = '1'

      ) loop


        insert into  vn.srr02m00
         ( rgt_std_dt    ,
           acnt_no       ,
           sub_no        ,
           stk_cd        ,
           rgt_tp        ,
           seq_no        ,
           acnt_mng_bnh  ,
		   own_stk_qty   ,
           own_qty       ,
           asn_qty       ,
           asn_amt       ,
           flotq_amt     ,
           mrtg_lnd_qty  ,
           mrtg_asn_qty  ,
           inq_trd_no    ,
           rcpt_trd_no   ,
           outq_trd_no   ,
           outamt_trd_no ,
           flotq_trd_no  ,
		   inter_trd_no  ,
           cons_sbst_qty ,
           cons_sbst_amt ,
           work_mn       ,
           work_dtm      ,
           work_trm
         ) values  (
           i_std_dt       ,
           c4.acnt_no     ,
           c4.sub_no      ,
           vs_stk_cd      ,
           vs_rgt_tp      ,
           0      ,
           c4.bnh_cd      ,         -- imsi
		   c4.own_qty     ,
           c4.own_qty     ,
           0              ,
           0              ,
           0              ,
           0              , -- mrtr_lnd_qty
           0              ,
           0              ,
           0              ,
           0              ,
           0              ,
           0              ,
		   0			  ,
           0              ,
           0              ,
           i_work_mn      ,
           sysdate        ,
           i_work_trm
         ) ;

      end loop;

     update  vn.srr01m10
     set     rgt_proc_stat = '2'
     where   rgt_std_dt    = i_std_dt
     and     stk_cd        = vs_stk_cd ;

     o_proc_cnt := o_proc_cnt + 1;

   end loop;

   vn.pxc_log_write('psr_rgt_std_p', '2 '|| to_char( o_proc_cnt ) );

  else

	 for d1 in (

	   select   rgt_proc_stat,
				stk_cd,
				rgt_tp,
				seq_no
	   from     vn.srr01m00
	   where    rgt_std_dt    =   i_std_dt
	   and      stk_cd       like i_stk_cd
	   and      rgt_tp       like i_rgt_tp
       and      seq_no       like i_seq_no
	   and      rgt_proc_stat = '2'

	 ) loop

       delete  from  vn.srr02m00
	   where   rgt_std_dt  =  i_std_dt
	   and     stk_cd      =  d1.stk_cd
	   and     rgt_tp      =  d1.rgt_tp
	   and     seq_no      =  d1.seq_no;

       update  vn.srr01m00
	   set     rgt_proc_stat = '1'
       where   rgt_std_dt    = i_std_dt
	   and     stk_cd        = d1.stk_cd
	   and     rgt_tp        = d1.rgt_tp
	   and     seq_no        = d1.seq_no;

	   o_proc_cnt := 1 ;

	 end loop;

   vn.pxc_log_write('psr_rgt_std_p', '3 '|| to_char( o_proc_cnt ) );

	 for d2 in (

      select    stk_cd    ,
                '8' rgt_tp
       from     vn.srr01m10
       where    rgt_std_dt    =  i_std_dt
       and      stk_cd        =  i_stk_cd
       and      i_rgt_tp      =    '8'
       and      rgt_proc_stat = 2

     ) loop

       delete  from  vn.srr02m00
       where   rgt_std_dt  =  i_std_dt
       and     stk_cd      =  d2.stk_cd
       and     rgt_tp      =  d2.rgt_tp ;

       update  vn.srr01m10
       set     rgt_proc_stat = '1'
       where   rgt_std_dt    = i_std_dt
       and     stk_cd        = d2.stk_cd ;

	   o_proc_cnt := 1 ;

     end loop;

  vn.pxc_log_write('psr_rgt_std_p', '4 ' || to_char( o_proc_cnt ) );

 end if;

end  psr_rgt_std_p;
/

