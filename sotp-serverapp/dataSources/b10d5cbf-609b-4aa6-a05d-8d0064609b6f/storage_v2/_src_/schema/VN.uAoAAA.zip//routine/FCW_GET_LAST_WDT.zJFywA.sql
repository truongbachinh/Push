create function fcw_get_last_wdt
(
	i_dt       in  varchar2
)
    return          varchar2
as

    t_dt   date ;

begin

  t_dt := last_day(to_date(i_dt, 'yyyymmdd') ) ;

  if vn.fxc_holi_ck(t_dt ) <> '0' then

     return  vn.fxc_vorderdt_g( t_dt , -1 )   ;

  end if ;


  return to_char(t_dt,'yyyymmdd') ;

end fcw_get_last_wdt;
/

