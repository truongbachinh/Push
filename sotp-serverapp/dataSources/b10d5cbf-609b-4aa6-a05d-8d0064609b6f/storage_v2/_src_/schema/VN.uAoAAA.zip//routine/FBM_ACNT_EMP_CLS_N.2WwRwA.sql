create function fbm_acnt_emp_cls_n
(
  i_sec_id  in   varchar2 ,
  i_acnt_no in   varchar2 ,
  i_sub_no  in   varchar2 ,
  i_reg_dt  in   varchar2 ,
  i_cls_dt  in   date
)
    return          varchar2
as
    o_reg_dt    varchar2(500) ;
    t_err_txt       varchar2(100)  ; -- error text buffer

begin

    o_reg_dt  :=  NULL;
    t_err_txt :=  NULL;

       begin
      select  to_char(max(cls_dtm),'yyyymmdd hh24miss')
      into  o_reg_dt
      from  vn.bmi01m00
      where  acnt_no = i_acnt_no
      and   sub_no  = i_sub_no
      --and    mng_emp_tp = '1'
      and    to_char(cls_dtm,'yyyymmdd') = i_reg_dt
      and   cls_dtm < i_cls_dt
      ;
      exception
          when  NO_DATA_FOUND  then
        return  i_reg_dt ||' 000000';
          when  OTHERS         then
        return  i_reg_dt ||' 000000';
        --raise_application_error (-20100, 'loi cmn roi');
      end;

    return  nvl(o_reg_dt,i_reg_dt ||' 000000');

end fbm_acnt_emp_cls_n;
/

