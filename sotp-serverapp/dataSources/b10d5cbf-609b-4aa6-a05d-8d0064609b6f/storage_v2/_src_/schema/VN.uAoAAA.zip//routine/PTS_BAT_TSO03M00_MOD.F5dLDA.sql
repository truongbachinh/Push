create PROCEDURE    pts_bat_tso03m00_mod (i_work_dt IN varchar2, -- date(yyyymmdd)
                                                     o_err_code IN number, -- error code(0:SUCCESS)
                                                     o_err_msg IN varchar2 -- error message
)
AS
   t_err_code   NUMBER := o_err_code;
   t_err_msg    VARCHAR2 (600) := RTRIM (o_err_msg);
   t_chk        VARCHAR2 (1);
   t_cnt        NUMBER;
   exp_error exception;
/*!
    \file     pts_acnt_prof_g
    \brief    tso03m00 table insert

    \section intro Program Information
        - Program Name              : pts_bat_tso03m00_mod
        - Service Name              :
        - Related Client Program- Client Program ID :
        - Related Tables            : tso03m00
        - Dev. Date                 : 2007/11/27
        - Developer                 : ejlee
        - Business Logic Desc.      :
        - Latest Modification Date  :

    \section history Program Modification History
        - 1.0  2007/11/27

    \section hardcoding Hard-Coding List


    \section info Additional Reference Comments
*/

BEGIN
   t_err_code   := 0;
   t_err_msg    := 'SUCCESS';
   t_chk        := 'Y';

   -- 1. ?? ????????u Fun?u

   -- 2. ???????? ?????? / ????? ???????? ??
   IF t_chk = 'Y'
   THEN
      -- 2-1. ???????? ??????
      DELETE FROM vn.tso03m00;

      -- 2-2. ???????? ????? ???        -- sb_kfx_tp(HASTC:?g??y???, stk_tp(10:???
      INSERT INTO vn.tso03m00
            (
                sb_kfx_tp,
                stk_tp,
                mkt_main_sts,
                mkt_drv_tp,
                work_mn,
                work_dtm,
                work_trm
            )
      VALUES ('HASTC', '10', 'BM', 'BM', 'batch', SYSDATE, 'batch');

      -- sb_kfx_tp(HASTC:?g??y???, stk_tp(20:?
      INSERT INTO vn.tso03m00
            (
                sb_kfx_tp,
                stk_tp,
                mkt_main_sts,
                mkt_drv_tp,
                work_mn,
                work_dtm,
                work_trm
            )
      VALUES ('HASTC', '20', 'BM', 'BM', 'batch', SYSDATE, 'batch');


      -- sb_kfx_tp(HASTC:?g??y???, stk_tp(30:???????
      INSERT INTO vn.tso03m00
            (
                sb_kfx_tp,
                stk_tp,
                mkt_main_sts,
                mkt_drv_tp,
                work_mn,
                work_dtm,
                work_trm
            )
      VALUES ('HASTC', '30', 'BM', 'BM', 'batch', SYSDATE, 'batch');

      INSERT INTO vn.tso03m00
            (
                sb_kfx_tp,
                stk_tp,
                mkt_main_sts,
                mkt_drv_tp,
                work_mn,
                work_dtm,
                work_trm
            )
      VALUES ('HASTC', '40', 'BM', 'BM', 'batch', SYSDATE, 'batch');

      -- sb_kfx_tp(HOSTC:????y???, stk_tp(10:???
      INSERT INTO vn.tso03m00
            (
                sb_kfx_tp,
                stk_tp,
                mkt_main_sts,
                mkt_drv_tp,
                work_mn,
                work_dtm,
                work_trm
            )
      VALUES ('HOSTC', '10', 'BM', 'BM', 'batch', SYSDATE, 'batch');


      -- sb_kfx_tp(HOSTC:????y???, stk_tp(20:?
      INSERT INTO vn.tso03m00
            (
                sb_kfx_tp,
                stk_tp,
                mkt_main_sts,
                mkt_drv_tp,
                work_mn,
                work_dtm,
                work_trm
            )
      VALUES ('HOSTC', '20', 'BM', 'BM', 'batch', SYSDATE, 'batch');


      -- sb_kfx_tp(HOSTC:????y???, stk_tp(30:???????
      INSERT INTO vn.tso03m00
            (
                sb_kfx_tp,
                stk_tp,
                mkt_main_sts,
                mkt_drv_tp,
                work_mn,
                work_dtm,
                work_trm
            )
      VALUES ('HOSTC', '30', 'BM', 'BM', 'batch', SYSDATE, 'batch');

      -- sb_kfx_tp(HOSTC:????y???, stk_tp(40:???????
      INSERT INTO vn.tso03m00
            (
                sb_kfx_tp,
                stk_tp,
                mkt_main_sts,
                mkt_drv_tp,
                work_mn,
                work_dtm,
                work_trm
            )
      VALUES ('HOSTC', '40', 'BM', 'BM', 'batch', SYSDATE, 'batch');

      -- sb_kfx_tp(HOSTC:????y???, stk_tp(40:???????
      INSERT INTO vn.tso03m00
            (
                sb_kfx_tp,
                stk_tp,
                mkt_main_sts,
                mkt_drv_tp,
                work_mn,
                work_dtm,
                work_trm
            )
      VALUES ('HOSTC', '70', 'BM', 'BM', 'batch', SYSDATE, 'batch');

      -- sb_kfx_tp(VSD:????y???, stk_tp(10:???????
      INSERT INTO vn.tso03m00
            (
                sb_kfx_tp,
                stk_tp,
                mkt_main_sts,
                mkt_drv_tp,
                work_mn,
                work_dtm,
                work_trm
            )
      VALUES ('VSD', '10', 'BM', '2222', 'batch', SYSDATE, 'batch');

      -- sb_kfx_tp(HOCNT:?g??y???, stk_tp(90:FEP)
      INSERT INTO vn.tso03m00
            (
                sb_kfx_tp,
                stk_tp,
                mkt_main_sts,
                mkt_drv_tp,
                work_mn,
                work_dtm,
                work_trm
            )
      VALUES ('HOCNT', '90', 'BM', 'FP', 'batch', SYSDATE, 'batch');

      -- sb_kfx_tp(HACNT:????y???, stk_tp(90:FEP)
      INSERT INTO vn.tso03m00
            (
                sb_kfx_tp,
                stk_tp,
                mkt_main_sts,
                mkt_drv_tp,
                work_mn,
                work_dtm,
                work_trm
            )
      VALUES ('HACNT', '90', 'BM', 'FP', 'batch', SYSDATE, 'batch');

      -- sb_kfx_tp(UPCNT:????y??? upcom), stk_tp(90:FEP)
      INSERT INTO vn.tso03m00
            (
                sb_kfx_tp,
                stk_tp,
                mkt_main_sts,
                mkt_drv_tp,
                work_mn,
                work_dtm,
                work_trm
            )
      VALUES ('UPCNT', '90', 'BM', 'FP', 'batch', SYSDATE, 'batch');

      -- sb_kfx_tp(UPCOM:????y???, stk_tp(10:stock)

      INSERT INTO vn.tso03m00
            (
                sb_kfx_tp,
                stk_tp,
                mkt_main_sts,
                mkt_drv_tp,
                work_mn,
                work_dtm,
                work_trm
            )
      VALUES ('UPCOM', '10', 'BM', 'BM', 'batch', SYSDATE, 'batch');

      -- sb_kfx_tp(UPCOM:????y???, stk_tp(10:stock)
      INSERT INTO vn.tso03m00
            (
                sb_kfx_tp,
                stk_tp,
                mkt_main_sts,
                mkt_drv_tp,
                work_mn,
                work_dtm,
                work_trm
            )
      VALUES ('UPCOM', '20', 'BM', 'BM', 'batch', SYSDATE, 'batch');

      -- sb_kfx_tp(UPCOM:????y???, stk_tp(10:stock)
      INSERT INTO vn.tso03m00
            (
                sb_kfx_tp,
                stk_tp,
                mkt_main_sts,
                mkt_drv_tp,
                work_mn,
                work_dtm,
                work_trm
            )
      VALUES ('UPCOM', '30', 'BM', 'BM', 'batch', SYSDATE, 'batch');

      INSERT INTO vn.tso03m00
            (
                sb_kfx_tp,
                stk_tp,
                mkt_main_sts,
                mkt_drv_tp,
                work_mn,
                work_dtm,
                work_trm
            )
      VALUES ('UPCOM', '40', 'BM', 'BM', 'batch', SYSDATE, 'batch');


      -- sb_kfx_tp(BKHLD:??? ???u???? (BIDV), stk_tp(80:FEP) , BM- > ???, UH -> ???????? BK -> ?????
      INSERT INTO vn.tso03m00
            (
                sb_kfx_tp,
                stk_tp,
                mkt_main_sts,
                mkt_drv_tp,
                work_mn,
                work_dtm,
                work_trm
            )
      VALUES ('BKHLD', '80', 'BM', 'BM', 'batch', SYSDATE, 'batch');

      -- sb_kfx_tp(BKHLD:?? ???upcom (BIDV), stk_tp(80:FEP) , BM- > ???, UH -> ???????? BK -> ?????
      INSERT INTO vn.tso03m00
            (
                sb_kfx_tp,
                stk_tp,
                mkt_main_sts,
                mkt_drv_tp,
                work_mn,
                work_dtm,
                work_trm
            )
      VALUES ('UPPTR', '80', 'BM', 'BM', 'batch', SYSDATE, 'batch');
   ELSE
      t_err_code   := -1;
      t_err_msg    := '?? ??????????? ?? ?????????';
      raise_application_error (-20100, '[pts_bat_tso03m00_mod] ' || t_err_msg
      );
   END IF;

   UPDATE SSI03M00
      SET MKT_DRV_TP = '-', MKT_MAIN_STS = '0';

   UPDATE SSI03M10
      SET MKT_DRV_TP = '-', MKT_MAIN_STS = '0';
EXCEPTION
   WHEN exp_error
   THEN
      t_err_code   := SQLCODE;
      t_err_msg    := SQLERRM;
      raise_application_error (-20100, '[pts_bat_tso03m00_mod] ' || t_err_msg
      );
END pts_bat_tso03m00_mod;
/

