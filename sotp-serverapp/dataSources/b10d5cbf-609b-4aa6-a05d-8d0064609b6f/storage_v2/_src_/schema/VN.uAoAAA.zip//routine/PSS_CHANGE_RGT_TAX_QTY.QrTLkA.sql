create procedure pss_change_rgt_tax_qty
( i_tp       in varchar2,
  i_acnt_no  in varchar2,
  i_stk_cd   in varchar2,
  i_qty      in number,
  i_work_mn  in varchar2,
  i_work_trm in varchar2)
as
/* *******************************************************************
  Muc dich: Thay doi so luong can tinh thue sau khi but toan cho duyet duoc duyet.

  i_tp: Phan loai nghiep vu can thao tac
    11: SL TDCN
    12: SL HCCN
    13: SL Cho GD TDCN
    14: SL Cho GD HCCN

  Lich su thay doi:
  16-Dec-2020 vnjvthangnm Khoi tao thu tuc.
******************************************************************* */
  v_tax_qty             number := 0;
  v_tax_sb_lim_qty      number := 0;
  v_tax_delay_qty       number := 0;
  v_tax_delay_sb_qty    number := 0;
  v_wtax_qty            number := 0;
  v_wtax_sb_lim_qty     number := 0;
  v_wtax_delay_qty      number := 0;
  v_wtax_delay_sb_qty   number := 0;
  t_qty                 number := 0;
  t_wqty                number := 0;
  t_cnte                varchar2(200);
begin
  vn.pxc_log_write('pss_change_rgt_tax_qty','Bat dau xu ly cho tai khoan: ' || i_acnt_no || ', MaCK: ' || i_stk_cd || ', SL: ' || to_char(i_qty) || ', type: ' || i_tp);

  if i_tp = '11' then -- TDCN
    v_tax_qty  := 0 - i_qty;
    v_wtax_qty := 0 - i_qty;
    t_cnte := 'Duyet xuat TDCN';

    begin
      select tax_qty - i_qty, wtax_qty - i_qty
        into t_qty,t_wqty
        from ssb05m10
        where acnt_no = i_acnt_no
          and stk_cd  = i_stk_cd;
    exception
      when no_data_found then
        vn.pxc_log_write('pss_change_rgt_tax_qty','Giai toa: Khong co du lieu TDCN cho tai khoan: '||i_acnt_no ||', stk_cd: '||i_stk_cd);
        raise_application_error(-20100,'Tai khoan ' || i_acnt_no || ' chua co phong toa cho ma ' || i_stk_cd);
    end;

    if t_qty < 0 or t_wqty < 0 then
      vn.pxc_log_write('pss_change_rgt_tax_qty','SL giai toa TDCN cho tai khoan:' || i_acnt_no || ', ma: ' || i_stk_cd || ' qua nhieu!!!');
      raise_application_error(-20100,'SL giai toa TDCN cho tai khoan: ' || i_acnt_no || ', ma: ' || i_stk_cd || ' qua nhieu!!!');
    end if;

  elsif i_tp = '12' then -- HCCN
    v_tax_sb_lim_qty  := 0 - i_qty;
    v_wtax_sb_lim_qty := 0 - i_qty;
    t_cnte := 'Duyet xuat HCCN';

    begin
      select tax_sb_lim_qty - i_qty, wtax_sb_lim_qty - i_qty
        into t_qty,t_wqty
        from ssb05m10
        where acnt_no = i_acnt_no
          and stk_cd  = i_stk_cd;
    exception
      when no_data_found then
        vn.pxc_log_write('pss_change_rgt_tax_qty','Giai toa: Khong co du lieu HCCN cho tai khoan: '||i_acnt_no ||', stk_cd: '||i_stk_cd);
        raise_application_error(-20100,'Tai khoan ' || i_acnt_no || ' chua co phong toa cho ma ' || i_stk_cd);
    end;

    if t_qty < 0 or t_wqty < 0 then
      vn.pxc_log_write('pss_change_rgt_tax_qty','SL giai toa HCCN cho tai khoan:' || i_acnt_no || ', ma: ' || i_stk_cd || ' qua nhieu!!!');
      raise_application_error(-20100,'SL giai toa HCCN cho tai khoan: ' || i_acnt_no || ', ma: ' || i_stk_cd || ' qua nhieu!!!');
    end if;
  elsif i_tp = '13' then -- Cho GD TDCN
    v_tax_delay_qty  := 0 - i_qty;
    v_wtax_delay_qty := 0 - i_qty;
    t_cnte := 'Duyet xuat Cho GD TDCN';

    begin
      select tax_delay_qty - i_qty, wtax_delay_qty - i_qty
        into t_qty,t_wqty
        from ssb05m10
        where acnt_no = i_acnt_no
          and stk_cd  = i_stk_cd;
    exception
      when no_data_found then
        vn.pxc_log_write('pss_change_rgt_tax_qty','Giai toa: Khong co du lieu Cho GD TDCN cho tai khoan: '||i_acnt_no ||', stk_cd: '||i_stk_cd);
        raise_application_error(-20100,'Tai khoan ' || i_acnt_no || ' chua co phong toa cho ma ' || i_stk_cd);
    end;

    if t_qty < 0 or t_wqty < 0 then
      vn.pxc_log_write('pss_change_rgt_tax_qty','SL giai toa Cho GD TDCN cho tai khoan:' || i_acnt_no || ', ma: ' || i_stk_cd || ' qua nhieu!!!');
      raise_application_error(-20100,'SL giai toa Cho GD TDCN cho tai khoan: ' || i_acnt_no || ', ma: ' || i_stk_cd || ' qua nhieu!!!');
    end if;

  elsif i_tp = '14' then -- Cho GD HCCN
    v_tax_delay_sb_qty  := 0 - i_qty;
    v_wtax_delay_sb_qty := 0 - i_qty;
    t_cnte := 'Duyet xuat Cho GD HCCN';

    begin
      select tax_delay_sb_qty - i_qty, wtax_delay_sb_qty - i_qty
        into t_qty,t_wqty
        from ssb05m10
        where acnt_no = i_acnt_no
          and stk_cd  = i_stk_cd;
    exception
      when no_data_found then
        vn.pxc_log_write('pss_change_rgt_tax_qty','Giai toa: Khong co du lieu Cho GD HCCN cho tai khoan: '||i_acnt_no ||', stk_cd: '||i_stk_cd);
        raise_application_error(-20100,'Tai khoan ' || i_acnt_no || ' chua co phong toa cho ma ' || i_stk_cd);
    end;

    if t_qty < 0 or t_wqty < 0 then
      vn.pxc_log_write('pss_change_rgt_tax_qty','SL giai toa Cho GD HCCN cho tai khoan:' || i_acnt_no || ', ma: ' || i_stk_cd || ' qua nhieu!!!');
      raise_application_error(-20100,'SL giai toa Cho GD HCCN cho tai khoan: ' || i_acnt_no || ', ma: ' || i_stk_cd || ' qua nhieu!!!');
    end if;

  end if;
  /* Thuc hien thay doi o bang ssb05m10 */
  begin
    update ssb05m10
      set tax_qty           = tax_qty           + v_tax_qty,
          tax_sb_lim_qty    = tax_sb_lim_qty    + v_tax_sb_lim_qty,
          tax_delay_qty     = tax_delay_qty     + v_tax_delay_qty,
          tax_delay_sb_qty  = tax_delay_sb_qty  + v_tax_delay_sb_qty,
          wtax_qty          = wtax_qty          + v_wtax_qty,
          wtax_sb_lim_qty   = wtax_sb_lim_qty   + v_wtax_sb_lim_qty,
          wtax_delay_qty    = wtax_delay_qty    + v_wtax_delay_qty,
          wtax_delay_sb_qty = wtax_delay_sb_qty + v_wtax_delay_sb_qty,
          work_mn           = i_work_mn,
          work_dtm          = sysdate,
          work_trm          = i_work_trm
    where acnt_no = i_acnt_no
      and stk_cd  = i_stk_cd;
  exception
    when others then
      vn.pxc_log_write('pss_change_rgt_tax_qty','Loi khi update ssb05m10.');
      raise_application_error(-20100,'Loi khi update ssb05m10.');
  end;

  /* Luu lich su vao bang ssb05h10 */
  begin
    pss_rgt_tax_history
    ( i_acnt_no  ,
      i_stk_cd   ,
      ''         ,
      t_cnte     ,
      i_work_mn  ,
      i_work_trm
    );
  exception
    when others then
      vn.pxc_log_write('pss_change_rgt_tax_qty','Loi khi chay proc pss_rgt_tax_history.');
      raise_application_error(-20100,'Loi khi chay proc pss_rgt_tax_history.');
  end;

  vn.pxc_log_write('pss_change_rgt_tax_qty','Ket thuc.');
end pss_change_rgt_tax_qty;
/

