create PROCEDURE PGG_ACC_DAY_CLS
    (
    I_WORK_TP       IN      VARCHAR2,       -- 'Y' : Closing, 'N' : Cancel
    I_YYMMDD        IN      VARCHAR2,       -- YYYYMMDD
    I_BRCH_CD       IN      VARCHAR2,       -- Branch
    I_AGNC_BRCH     IN      VARCHAR2,       -- Agency Branch
    I_WORK_MN       IN      VARCHAR2,	    -- Worker
    I_WORK_TRM      IN      VARCHAR2,       -- IP_ADDRESS
    O_RTN_TBL       OUT     VARCHAR2,       -- Return Table
	O_RTN_ERR       OUT     VARCHAR2,       -- Return Error Code
	O_RTN_MSG       OUT     VARCHAR2        -- Return Message
    ) IS

    T_CNT           NUMBER      := 0;
    T_MONTH_CLS_YN  VARCHAR2(1) := 'N';
    -- Constants
    K_ALL_BRCH      VARCHAR2(3) := '000' ;      -- 회사전체
    K_BON_BRCH      VARCHAR2(3) := '901' ;      -- 본점
    K_MAX_DT        VARCHAR2(8) := '30001231' ; -- 지점종료일

    -- Exceptions Declare
    ERR_GGA10M00        EXCEPTION;
    ERR_GGA10M00_N      EXCEPTION;
    ERR_GGA11M00        EXCEPTION;
    ERR_CLS_CHK         EXCEPTION;
    ERR_GGA08M00_INS    EXCEPTION;
    ERR_GGA10M00_UPD    EXCEPTION;
    ERR_GGA10M00_INS    EXCEPTION;

BEGIN
   /* 월마감여부 CHECK */
   SELECT (
           SELECT ACC_CLS_YN
           FROM   VN.GGA11M00
           WHERE  BRCH_CD   = I_BRCH_CD
           AND    AGNC_BRCH = I_AGNC_BRCH
           AND    CLS_YM    = SUBSTR(I_YYMMDD,1,6)
           ) INTO T_MONTH_CLS_YN
   FROM   DUAL;

   IF T_MONTH_CLS_YN = 'Y' THEN
        RAISE ERR_GGA11M00;
    END IF;

   IF I_WORK_TP = 'Y' THEN /* When Closing */

      -- 회사전체일 경우 본점,전지점이 마감된후 처리가능
      T_CNT   := 0 ;
      IF  I_BRCH_CD   =   K_ALL_BRCH  THEN

      	SELECT	COUNT(*)
            INTO  T_CNT
      	  FROM	VN.XCC90M00 v11, /* Branch */
      			(	SELECT	v21.BRCH_CD			AS	BRCH_CD,
      						v21.AGNC_BRCH		AS	AGNC_BRCH,
      						v21.ACC_CLS_YN		AS	ACC_CLS_YN
      				  FROM	VN.GGA10M00 v21
      				 WHERE	v21.Acc_Cls_Dt  =	I_YYMMDD
      				   AND	v21.BRCH_CD		<>	K_ALL_BRCH
      				   AND	v21.AGNC_BRCH	=	'00'
      			)			v12 /* Daily Closing */
      	 WHERE	v11.BRCH_CD = v12.BRCH_CD
           AND  v11.AGNC_BRCH = v12.AGNC_BRCH
           AND  v11.AGNC_BRCH		=	'00'
      	   AND	v11.HEAD_BRCH_TP	IN	('0', '1')
      	   AND	v11.BRCH_CD			<>	K_ALL_BRCH
      	   AND	TO_CHAR(SYSDATE, 'YYYYMMDD')	BETWEEN NVL(v11.BRCH_OPN_DT, TO_CHAR(SYSDATE, 'YYYYMMDD'))
      												AND	NVL(v11.BRCH_END_DT, K_MAX_DT)
      	   AND	NVL(v12.ACC_CLS_YN, 'N')	=	'N' ;

          IF  T_CNT   >=  1   THEN
              RAISE ERR_GGA10M00;
          END IF;

      END IF;

      -- U_1. 본점일 경우 전지점이 마감된후 처리가능
      T_CNT   := 0 ;
      IF  I_BRCH_CD   =   K_BON_BRCH  THEN

      	SELECT	COUNT(*)
            INTO  T_CNT
      	  FROM	VN.XCC90M00 v11,
      			(	SELECT	v21.BRCH_CD			AS	BRCH_CD,
      						v21.AGNC_BRCH		AS	AGNC_BRCH,
      						v21.ACC_CLS_YN		AS	ACC_CLS_YN
      				  FROM	VN.GGA10M00 v21
      				 WHERE	v21.Acc_Cls_Dt	=	I_YYMMDD
      				   AND	v21.BRCH_CD		NOT IN  (K_ALL_BRCH, K_BON_BRCH)
      				   AND	v21.AGNC_BRCH	=	'00'
      			)			v12
      	 WHERE	v11.AGNC_BRCH		=	'00'
      	   AND	v11.HEAD_BRCH_TP	IN	('0', '1')
      	   AND	v11.BRCH_CD			NOT IN  (K_ALL_BRCH, K_BON_BRCH)
      	   AND	TO_CHAR(SYSDATE, 'YYYYMMDD')	BETWEEN NVL(v11.BRCH_OPN_DT, TO_CHAR(SYSDATE, 'YYYYMMDD'))
      												AND	NVL(v11.BRCH_END_DT, K_MAX_DT)
      	   AND	v11.BRCH_CD		=	v12.BRCH_CD
      	   AND	v11.AGNC_BRCH	=	v12.AGNC_BRCH
      	   AND	NVL(v12.ACC_CLS_YN, 'N')	=	'N' ;

          IF  T_CNT   >=  1   THEN
              RAISE ERR_GGA10M00;
          END IF;

      END IF;

      /* Daily Closing Check List */
      T_CNT   := 0 ;

      SELECT  COUNT(*) INTO  T_CNT
      FROM    (
              /* Exists Various Account Balance */
              SELECT DECODE(
                             (NVL(C.DR_EXCH_AMT,0) + NVL(C.DR_CASH_AMT,0))
                              -
                             (NVL(C.CR_EXCH_AMT,0) + NVL(C.CR_CASH_AMT,0))
                             , 0 , 'Y' , 'N' )
                             AS STATUS
              FROM   VN.XCC01C00 A1, /* Common Code Master */
                     VN.XCC01C01 A2, /* Common Code Detail */
                     VN.GGA02C00 B , /* Account            */
                     VN.GGA08M00 C   /* Daily Summary      */
              WHERE  A1.COL_CD        =  A2.COL_CD
              AND    A2.COL_CD_TP_NM  =  B.ACC_ACT_CD
              AND    A2.COL_CD_TP_NM  =  C.ACC_ACT_CD(+)
              AND    UPPER(A2.COL_CD) LIKE 'DT_CLS_CHK_01'
              AND    C.ACC_CLS_DT(+) = I_YYMMDD
              AND    C.BRCH_CD(+)    = I_BRCH_CD
              AND    C.AGNC_BRCH(+)  = I_AGNC_BRCH

              UNION ALL
              /* Exists Not Approved Slip */
              SELECT DECODE( DR_AMT - CR_AMT, 0 , 'N' , 'N' ) AS STATUS
              FROM   VN.XCC01C00 A1, VN.XCC01C01 A2,
                     (
                      SELECT DISTINCT
                             'dt_cls_chk_02' AS KEY_NM,
                             SLIP_NO, TRD_CNTE,
                             SUM(DECODE(DR_CR_TP,'1',SLIP_AMT,0)) DR_AMT,
                             SUM(DECODE(DR_CR_TP,'2',SLIP_AMT,0)) CR_AMT
                      FROM   VN.GGA06M00
                      WHERE  BRCH_CD   = I_BRCH_CD
                      AND    AGNC_BRCH = I_AGNC_BRCH
                      AND    SLIP_DT   = I_YYMMDD AND SLIP_STAT NOT IN ('2','4') /* Approval, DisUse */
                      GROUP BY SLIP_NO, TRD_CNTE
                     ) C
              WHERE  A1.COL_CD =  A2.COL_CD
              AND    A2.COL_CD =  C.KEY_NM
              AND    UPPER(A2.COL_CD) LIKE 'DT_CLS_CHK_02'

              UNION ALL
              /* Exists Non Posting Auto Log */
              SELECT C.CNT AS STATUS
              FROM   VN.XCC01C00 A1, VN.XCC01C01 A2,
                     (
                      SELECT 'dt_cls_chk_03' AS KEY_NM, DECODE(COUNT(*),'0','Y','N') CNT
                      FROM   VN.GGA07M00
                      WHERE  PROC_BRCH_CD   = I_BRCH_CD
                      AND    PROC_AGNC_BRCH = I_AGNC_BRCH
                      AND    PROC_DT        = I_YYMMDD
                      AND    AUTO_SLIP_RFLN_TP IN ( 'N','X' )
                     ) C
              WHERE  A1.COL_CD  =  A2.COL_CD
              AND    A2.COL_CD  =  C.KEY_NM
              AND    UPPER(A2.COL_CD) LIKE 'DT_CLS_CHK_03'

              UNION ALL
              /* Difference with Dr/Cr amount */
              SELECT DECODE( DR_AMT - CR_AMT, 0 , 'N' , 'N' ) AS STATUS
              FROM   VN.XCC01C00 A1, VN.XCC01C01 A2,
                     (
                      SELECT DISTINCT
                             'dt_cls_chk_04' AS KEY_NM,
                             SLIP_NO, TRD_CNTE,
                             SUM(DECODE(DR_CR_TP,'1',SLIP_AMT,0)) DR_AMT,
                             SUM(DECODE(DR_CR_TP,'2',SLIP_AMT,0)) CR_AMT
                      FROM   VN.GGA06M00
                      WHERE  BRCH_CD   = I_BRCH_CD
                      AND    AGNC_BRCH = I_AGNC_BRCH
                      AND    SLIP_DT   = I_YYMMDD AND SLIP_STAT NOT IN ('2','4') /* Approval, DisUse */
                      GROUP BY SLIP_NO, TRD_CNTE
                      HAVING SUM(DECODE(DR_CR_TP,'1',SLIP_AMT,0)) <> SUM(DECODE(DR_CR_TP,'2',SLIP_AMT,0))
                     ) C
              WHERE  A1.COL_CD =  A2.COL_CD
              AND    A2.COL_CD =  C.KEY_NM
              AND    UPPER(A2.COL_CD) LIKE 'DT_CLS_CHK_04'
              )
      WHERE   STATUS = 'N'
      ;

      IF  T_CNT   >  0   THEN
          RAISE ERR_CLS_CHK;
      END IF;

      BEGIN
          /* Delete Daily Summary */
          DELETE FROM VN.GGA08M00
          WHERE  ACC_CLS_DT =    I_YYMMDD
          AND    BRCH_CD    LIKE I_BRCH_CD
          AND    AGNC_BRCH  LIKE I_AGNC_BRCH
          ;

          INSERT INTO VN.GGA08M00 (
                      ACC_CLS_DT,
                      BRCH_CD,
                      AGNC_BRCH,
                      ACC_ACT_CD,
                      DR_EXCH_CNT,
                      DR_EXCH_AMT,
                      DR_CASH_CNT,
                      DR_CASH_AMT,
                      CR_EXCH_CNT,
                      CR_EXCH_AMT,
                      CR_CASH_CNT,
                      CR_CASH_AMT,
                      WORK_MN,
                      WORK_DTM,
                      WORK_TRM
                      )
          SELECT   SLIP_DT AS ACC_CLS_DT,
                   BRCH_CD,
                   DECODE(I_AGNC_BRCH,'%','00',AGNC_BRCH) AS AGNC_BRCH,
                   ACC_ACT_CD,
                   SUM(DR_EXCH_CNT),
                   SUM(DR_EXCH_AMT),
                   SUM(DR_CASH_CNT),
                   SUM(DR_CASH_AMT),
                   SUM(CR_EXCH_CNT),
                   SUM(CR_EXCH_AMT),
                   SUM(CR_CASH_CNT),
                   SUM(CR_CASH_AMT),
                   I_WORK_MN,
                   SYSDATE,
                   I_WORK_TRM
          FROM   (
                   SELECT A.SLIP_DT, A.BRCH_CD, A.AGNC_BRCH, A.ACC_ACT_CD, A.DR_CR_TP, A.SLIP_TP,
                          DECODE(A.DR_CR_TP,'1' ,DECODE(A.SLIP_TP   ,'1',  COUNT(*)
                                                                    ,'2',  COUNT(*) ,0       ),0) DR_CASH_CNT,
                          DECODE(A.DR_CR_TP,'1' ,DECODE(A.SLIP_TP   ,'1',  0
                                                                    ,'2',  0        ,COUNT(*)),0) DR_EXCH_CNT,
                          DECODE(A.DR_CR_TP,'1' ,DECODE(A.SLIP_TP   ,'1',  SUM(A.SLIP_AMT)
                                                                    ,'2',  SUM(A.SLIP_AMT) ,0),0) DR_CASH_AMT,
                          DECODE(A.DR_CR_TP,'1' ,DECODE(A.SLIP_TP   ,'1',  0
                                                                    ,'2',  0 ,SUM(A.SLIP_AMT)),0) DR_EXCH_AMT,
                          DECODE(A.DR_CR_TP,'2' ,DECODE(A.SLIP_TP   ,'1',  COUNT(*)
                                                                    ,'2',  COUNT(*) ,0       ),0) CR_CASH_CNT,
                          DECODE(A.DR_CR_TP,'2' ,DECODE(A.SLIP_TP   ,'1',  0
                                                                    ,'2',  0        ,COUNT(*)),0) CR_EXCH_CNT,
                          DECODE(A.DR_CR_TP,'2' ,DECODE(A.SLIP_TP   ,'1',  SUM(A.SLIP_AMT)
                                                                    ,'2',  SUM(A.SLIP_AMT) ,0),0) CR_CASH_AMT,
                          DECODE(A.DR_CR_TP,'2' ,DECODE(A.SLIP_TP   ,'1',  0
                                                                    ,'2',  0 ,SUM(A.SLIP_AMT)),0) CR_EXCH_AMT
                   FROM   GGA06M00 A, GGA02C00 B
                   WHERE  A.ACC_ACT_CD =    B.ACC_ACT_CD
                   AND    A.SLIP_DT    =    I_YYMMDD
                   AND    A.BRCH_CD    LIKE I_BRCH_CD
                   AND    A.AGNC_BRCH  LIKE I_AGNC_BRCH
                   AND    A.SLIP_STAT  =    '2'
                   GROUP BY A.SLIP_DT, A.BRCH_CD, A.AGNC_BRCH, A.ACC_ACT_CD, A.DR_CR_TP, A.SLIP_TP
                 )
          GROUP BY SLIP_DT, BRCH_CD, AGNC_BRCH, ACC_ACT_CD
          ORDER BY ACC_ACT_CD
          ;
      EXCEPTION WHEN OTHERS THEN
                RAISE ERR_GGA08M00_INS;
      END;

    ELSIF I_WORK_TP = 'N' THEN /* When Closing Cancel */
        /* 최사전체('000') 마감 완료된 경우 본점 마감 취소 불가 */
        /* 본점 마감이 완료된 경우 지점 마감 취소 불가 */
        -- 회사전체 마감체크
        IF  I_BRCH_CD   !=   K_ALL_BRCH  THEN

            T_CNT   := 0 ;

    		SELECT	COUNT(*)
    		  INTO  T_CNT
    		  FROM	VN.GGA10M00
    		 WHERE	ACC_CLS_DT	=	I_YYMMDD
    		   AND	BRCH_CD		=   K_ALL_BRCH
    		   AND	AGNC_BRCH	=	'00'
        	   AND	NVL(ACC_CLS_YN, 'N')	=	'Y' ;

            IF  T_CNT   >=  1   THEN
                RAISE ERR_GGA10M00_N;
            END IF;

            IF  I_BRCH_CD   !=   K_BON_BRCH  THEN

                T_CNT   := 0 ;

        		SELECT	COUNT(*)
        		  INTO  T_CNT
        		  FROM	VN.GGA10M00
        		 WHERE	ACC_CLS_DT	=	I_YYMMDD
        		   AND	BRCH_CD		=   K_BON_BRCH
        		   AND	AGNC_BRCH	=	'00'
            	   AND	NVL(ACC_CLS_YN, 'N')	=	'Y' ;

                IF  T_CNT   >=  1   THEN
                    RAISE ERR_GGA10M00_N;
                END IF;

            END IF;

        END IF;


    END IF;

        -- DAILY CLOSING FLAG SET
      T_CNT   := 0 ;
		SELECT COUNT(*)
		INTO   T_CNT
		FROM	 VN.GGA10M00
		WHERE	 ACC_CLS_DT	=	   I_YYMMDD
		AND	 BRCH_CD	LIKE  I_BRCH_CD
		AND	 AGNC_BRCH	LIKE  I_AGNC_BRCH ;

      IF  T_CNT   >=  1   THEN
			BEGIN
                UPDATE  VN.GGA10M00
                   SET  ACC_CLS_YN  =   I_WORK_TP,
                        WORK_MN     =   I_WORK_MN,
                        WORK_DTM    =   SYSDATE,
                        WORK_TRM    =   I_WORK_TRM
                WHERE	ACC_CLS_DT  =	I_YYMMDD
                AND	    BRCH_CD	    =   I_BRCH_CD
                AND	    AGNC_BRCH	=	I_AGNC_BRCH ;
		    EXCEPTION WHEN OTHERS THEN
		        RAISE ERR_GGA10M00_UPD;
		    END;
      ELSE
			BEGIN
                INSERT INTO  VN.GGA10M00(
                        ACC_CLS_DT,
                        BRCH_CD,
                        AGNC_BRCH,
                        ACC_CLS_YN,
                        WORK_MN,
                        WORK_DTM,
                        WORK_TRM )
                VALUES (I_YYMMDD,
                        I_BRCH_CD,
                        I_AGNC_BRCH,
                        'Y',
                        I_WORK_MN,
                        SYSDATE,
                        I_WORK_TRM );
		    EXCEPTION WHEN OTHERS THEN
		        RAISE ERR_GGA10M00_INS;
		    END;
      END IF;

      IF  SQL%NOTFOUND    THEN
          RAISE_APPLICATION_ERROR(-20100,
              'CLOSE UPDATE ERROR [' ||
              I_YYMMDD || ' ' || I_BRCH_CD || '].');
      END IF;

EXCEPTION
    WHEN    ERR_GGA08M00_INS  THEN
        O_RTN_TBL  :=  'GGA08M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  'CLOSE ERROR - Summary Insert [' || I_BRCH_CD || 'Can not closing! ]';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2629') || ' [' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);

    WHEN    ERR_GGA10M00_UPD  THEN
        O_RTN_TBL  :=  'GGA10M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  'CLOSE ERROR - Closing List Update [' || I_BRCH_CD || 'Can not closing! ';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2629') || ' [' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);

    WHEN    ERR_GGA10M00_INS  THEN
        O_RTN_TBL  :=  'GGA10M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  'CLOSE ERROR - Closing List Insert [' || I_BRCH_CD || 'Can not closing! ';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2629') || ' [' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);

    WHEN    ERR_GGA10M00  THEN
        O_RTN_TBL  :=  'GGA10M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  'CLOSE ERROR [' || I_BRCH_CD || ' Exists not closed Branch. ]';     -- '회계 미마감 팀점이 존재합니다.'
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2623');
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);

    WHEN    ERR_GGA10M00_N  THEN
        O_RTN_TBL  :=  'GGA10M00_N';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  'CLOSE ERROR [' || I_BRCH_CD || ' Exists closed Head Branch. ]';     -- '[V2606] 본점 회계마감 작업이 이미 처리되었습니다.'
        O_RTN_MSG  :=  'HEAD BRANCH Already Closed ' || VN.FXC_GET_ERR_MSG('V','2606');
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);

    WHEN    ERR_GGA11M00  THEN
        O_RTN_TBL  :=  'GGA11M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  'CLOSE ERROR [' || I_BRCH_CD || ' Already monthly closed. ]';     -- '[V2616]이미 회계 월마감이 완료되었습니다!'
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2616');
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);

    WHEN    ERR_CLS_CHK  THEN
        O_RTN_TBL  :=  'XCC01C01';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  'CLOSE ERROR [' || I_BRCH_CD || ' Please Confirm Check List. ]';     -- '[V2610]회계마감확인사항이 존재합니다!'
        O_RTN_MSG  :=  '[ERROR] ' || VN.FXC_GET_ERR_MSG('V','2610');
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);

    WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20100, 'ERROR ' || SUBSTR(SQLERRM, 5, 74));

END PGG_ACC_DAY_CLS;
/

