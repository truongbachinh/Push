create procedure pss_stk_trd_luong
( i_proc_dt    in   varchar2,
  i_acnt_no    in   varchar2,
   i_sub_no    in   varchar2,
  i_work_mn    in   varchar2,
  i_work_trm   in   varchar2,
  o_proc_cnt   out  number
 ) is
  t_sec_cd VARCHAR2(3) := vn.fxc_sec_cd('R');
 vn_cnt number   		:= 0;
/*var o_cnt      number;
exec pss_stk_trd_luong('20140219','%','%', 'DAILY', 'SYSTEM',:o_cnt);
print o_cnt*/
/***************************************************************************/
/* Right standard work                                                     */
/* 2007-10-22                                                              */
/***************************************************************************/

begin

 vn.pxc_log_write('pss_stk_trd_luong', 'start');

 o_proc_cnt  := 0;

 /*for  c1  in (

	select  acnt_no,
			sub_no,
			stk_cd,
			vn.fss_get_stk_tp(stk_cd) stk_tp,
			qty,
			inq_pri,
			trd_tp,
      rmrk_cd
    from    ssb05m00 t
  where proc_dt = '20140219'
  and cncl_yn = 'N' and end_yn = 'Y'
    and  acnt_no like i_acnt_no
    and sub_no like i_sub_no

  ) loop

	o_proc_cnt := o_proc_cnt + 1;

  select count(*) into vn_cnt
  from vn.ssb01m00 
  where acnt_no = c1.acnt_no
      and sub_no = c1.sub_no
      and stk_cd = c1.stk_cd
      and rownum < 2;

  if substr(c1.trd_tp,1,1) = '1' then -- Nhap kho   

    if vn_cnt = 0 then
      insert into vn.ssb01m00
	  (  
		  acnt_no,
		  sub_no,
		  stk_cd,
      stk_tp,
		  own_qty,
		  book_amt,
		  bclm_qty,
		  mrtg_lnd_qty,
		  mrtg_buy_qty,
		  sb_lim_qty,
		  mov_lim_qty,
		  lim_req_qty,
		  outq_req_qty,
		  delay_qty ,
		  delay_sb_qty ,
		  delay_mov_qty ,
		  delay_reg_qty,
		  sbst_dpo ,
		  sbst_able_block ,
		  sbst_unit_amt ,
		  work_mn,
		  work_dtm,
		  work_trm
      ) values (

		  c1.acnt_no,
		  c1.sub_no,
		  c1.stk_cd,
      vn.fss_get_stk_tp(c1.stk_cd),
		  c1.qty,
		  c1.qty*c1.inq_pri,
		  0,
		  0,
		  0,
		  0,
		  0,
		  0,
		  0,
		  0,
		  0,
		  0,
		  0,
		  0,
		  0 ,
		  0 ,
		  i_work_mn,
		  sysdate,
		  i_work_trm);

    else

      update vn.ssb01m00 
      set own_qty = own_qty + c1.qty,
          book_amt = book_amt + c1.qty*c1.inq_pri
      where acnt_no = c1.acnt_no
        and sub_no = c1.sub_no
        and stk_cd = c1.stk_cd;
    end if;


  end if;

  if c1.rmrk_cd = '219' then --Nhan chuyen khoan CK
    if vn_cnt = 0 then
      insert into vn.ssb01m00
	  (  
		  acnt_no,
		  sub_no,
		  stk_cd,
      stk_tp,
		  own_qty,
		  book_amt,
		  bclm_qty,
		  mrtg_lnd_qty,
		  mrtg_buy_qty,
		  sb_lim_qty,
		  mov_lim_qty,
		  lim_req_qty,
		  outq_req_qty,
		  delay_qty ,
		  delay_sb_qty ,
		  delay_mov_qty ,
		  delay_reg_qty,
		  sbst_dpo ,
		  sbst_able_block ,
		  sbst_unit_amt ,
		  work_mn,
		  work_dtm,
		  work_trm
      ) values (

		  c1.acnt_no,
		  c1.sub_no,
		  c1.stk_cd,
      vn.fss_get_stk_tp(c1.stk_cd),
		  c1.qty,
		  c1.qty*c1.inq_pri,
		  0,
		  0,
		  0,
		  0,
		  0,
		  0,
		  0,
		  0,
		  0,
		  0,
		  0,
		  0,
		  0 ,
		  0 ,
		  i_work_mn,
		  sysdate,
		  i_work_trm);

    else
      update vn.ssb01m00 
      set own_qty = own_qty + c1.qty,
          book_amt = book_amt + c1.qty*c1.inq_pri
      where acnt_no = c1.acnt_no
        and sub_no = c1.sub_no
        and stk_cd = c1.stk_cd;
    end if;
  end if;

  if c1.rmrk_cd = '238' then --Xuat chuyen khoan CK  

    if (vn_cnt = 0) then
      raise_application_error(-20000, 'CK ko co ma chuyen khoan duoc a?');
    end if;  
    update vn.ssb01m00
    set own_qty = own_qty - c1.qty,
        book_amt = book_amt - c1.qty*c1.inq_pri
    where acnt_no = c1.acnt_no
      and sub_no = c1.sub_no
      and stk_cd = c1.stk_cd;
  end if;

 end loop;*/

 /*\*thanh toan mua CK ve*\
 for  c2  in (
	select acnt_no, sub_no, stk_cd, --decode(sb_tp, '2', 1, -1) operator,
       sum(sb_qty) sb_qty, sum(sb_amt) sb_amt
        from dsc01m00 t
  where t.setl_dt = '20140219' and sb_tp = '2'
     and  acnt_no like i_acnt_no
      and sub_no like i_sub_no
      and substr(acnt_no,1,3) = '068'
  group by acnt_no, sub_no, stk_cd , sb_tp 

  ) loop

	o_proc_cnt := o_proc_cnt + 1;

  select count(*) into vn_cnt
  from vn.ssb01m00 
  where acnt_no = c2.acnt_no
      and sub_no = c2.sub_no
      and stk_cd = c2.stk_cd
      and rownum < 2;

  if vn_cnt = 0 then
   \* if (c2.operator = -1) then
      raise_application_error(-20000, 'CK ko co ma ban duoc a?');
    end if;*\

    insert into vn.ssb01m00
      (  
        acnt_no,
        sub_no,
        stk_cd,
        stk_tp,
        own_qty,
        book_amt,
        bclm_qty,
        mrtg_lnd_qty,
        mrtg_buy_qty,
        sb_lim_qty,
        mov_lim_qty,
        lim_req_qty,
        outq_req_qty,
        delay_qty ,
        delay_sb_qty ,
        delay_mov_qty ,
        delay_reg_qty,
        sbst_dpo ,
        sbst_able_block ,
        sbst_unit_amt ,
        work_mn,
        work_dtm,
        work_trm
        ) values (

        c2.acnt_no,
        c2.sub_no,
        c2.stk_cd,
        vn.fss_get_stk_tp(c2.stk_cd),
        c2.sb_qty,
        c2.sb_amt,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0 ,
        0 ,
        i_work_mn,
        sysdate,
        i_work_trm);

    else

      update vn.ssb01m00 
      set own_qty = own_qty + c2.sb_qty,--*c2.operator,
          book_amt = book_amt + c2.sb_amt--*c2.operator
      where acnt_no = c2.acnt_no
        and sub_no = c2.sub_no
        and stk_cd = c2.stk_cd;
    end if;

 --commit;

 end loop;*/

 /*thanh toan ban CK di*/
 /*for  c2  in (
	select acnt_no, sub_no, stk_cd, --decode(sb_tp, '2', 1, -1) operator,
       sum(sb_qty) sb_qty, sum(sb_amt) sb_amt
        from dsc01m00 t
  where t.setl_dt = '20140219' and sb_tp = '1'
     and  acnt_no like i_acnt_no
      and sub_no like i_sub_no
      and substr(acnt_no,1,3) = '068'
  group by acnt_no, sub_no, stk_cd , sb_tp 

  ) loop

	o_proc_cnt := o_proc_cnt + 1;

  select count(*) into vn_cnt
  from vn.ssb01m00 
  where acnt_no = c2.acnt_no
      and sub_no = c2.sub_no
      and stk_cd = c2.stk_cd
      and rownum < 2;

  if vn_cnt = 0 then
   -- if (c2.operator = -1) then
      raise_application_error(-20000, 'CK ko co ma ban duoc a'||c2.acnt_no||c2.sub_no||c2.stk_cd);
   -- end if;    

  else

    update vn.ssb01m00 
    set own_qty = own_qty - c2.sb_qty,--*c2.operator,
        book_amt = book_amt - c2.sb_amt--*c2.operator
    where acnt_no = c2.acnt_no
      and sub_no = c2.sub_no
      and stk_cd = c2.stk_cd;
  end if;

 --commit;

 end loop;*/

 /*CK cam co*/
 --select * from VN.dlm01m00 a where (a.lnd_tp = '20') and a.lnd_dt in ('20140219')

 /*for  c1  in (

	select  acnt_no,
			sub_no,
			stk_cd,
			stk_tp,
			own_qty,
			book_amt,
			bclm_qty,
			mrtg_lnd_qty,
			mrtg_buy_qty,
			nvl(sb_lim_qty,0)      sb_lim_qty,
			nvl(mov_lim_qty,0)     mov_lim_qty,
			nvl(lim_req_qty,0)     lim_req_qty ,
			nvl(outq_req_qty,0)    outq_req_qty,
			nvl(delay_qty , 0 )    delay_qty ,
			nvl(delay_sb_qty  , 0 )    delay_sb_qty ,
			nvl(delay_mov_qty , 0 )    delay_mov_qty ,
			nvl(delay_reg_qty , 0 )    delay_reg_qty ,
			nvl(sbst_dpo,0)        sbst_dpo ,
			nvl(sbst_able_block,0) sbst_able_block,
			nvl(sbst_unit_amt,0)   sbst_unit_amt
    from    vn.ssb01m00
	where   own_qty > 0

  ) loop

	o_proc_cnt := o_proc_cnt + 1;

    insert into vn.ssb01h00
	  (   rgt_std_dt,
		  acnt_no,
		  sub_no,
		  stk_cd,
		  own_qty,
		  book_amt,
		  bclm_qty,
		  mrtg_lnd_qty,
		  mrtg_buy_qty,
		  sb_lim_qty,
		  mov_lim_qty,
		  lim_req_qty,
		  outq_req_qty,
		  delay_qty ,
		  delay_sb_qty ,
		  delay_mov_qty ,
		  delay_reg_qty,
		  sbst_dpo ,
		  sbst_able_block ,
		  sbst_unit_amt ,
		  work_mn,
		  work_dtm,
		  work_trm
      ) values (
	      i_proc_dt,
		  c1.acnt_no,
		  c1.sub_no,
		  c1.stk_cd,
		  c1.own_qty,
		  c1.book_amt,
		  c1.bclm_qty,
		  c1.mrtg_lnd_qty,
		  c1.mrtg_buy_qty,
		  c1.sb_lim_qty,
		  c1.mov_lim_qty,
		  c1.lim_req_qty,
		  c1.outq_req_qty ,
		  c1.delay_qty  ,
		  c1.delay_sb_qty  ,
		  c1.delay_mov_qty  ,
		  c1.delay_reg_qty,
		  c1.sbst_dpo ,
		  c1.sbst_able_block ,
		  c1.sbst_unit_amt ,
		  i_work_mn,
		  sysdate,
		  i_work_trm
	  );

 end loop;*/

 /*Nhung TK mua ma ko co trong ssb01m00*/
 /*
 for  c2  in (
      select distinct acnt_no, sub_no, stk_cd from tso01m00 a
    where sell_buy_tp = '2'
      and mth_qty > 0
      and substr(acnt_no,1,3) = '068'
      and not exists (select 'x' from ssb01m00 where acnt_no = a.acnt_no and sub_no = a.sub_no and stk_cd = a.stk_cd)

  ) loop

	o_proc_cnt := o_proc_cnt + 1;

     insert into vn.ssb01m00
      (  
        acnt_no,
        sub_no,
        stk_cd,
        stk_tp,
        own_qty,
        book_amt,
        bclm_qty,
        mrtg_lnd_qty,
        mrtg_buy_qty,
        sb_lim_qty,
        mov_lim_qty,
        lim_req_qty,
        outq_req_qty,
        delay_qty ,
        delay_sb_qty ,
        delay_mov_qty ,
        delay_reg_qty,
        sbst_dpo ,
        sbst_able_block ,
        sbst_unit_amt ,
        work_mn,
        work_dtm,
        work_trm
        ) values (

        c2.acnt_no,
        c2.sub_no,
        c2.stk_cd,
        vn.fss_get_stk_tp(c2.stk_cd),
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0 ,
        0 ,
        i_work_mn,
        sysdate,
        i_work_trm);
  end loop;*/
 for  c2  in (
      select distinct acnt_no, sub_no, stk_cd from tso01h00 a
    where sell_buy_tp = '2'
      and mth_qty > 0
      and substr(acnt_no,1,3) = t_sec_cd
      and stk_ord_dt between '20140217' and '20140218'
      and not exists (select 'x' from ssb01m00 where acnt_no = a.acnt_no and sub_no = a.sub_no and stk_cd = a.stk_cd)

  ) loop

	o_proc_cnt := o_proc_cnt + 1;

     insert into vn.ssb01m00
      (  
        acnt_no,
        sub_no,
        stk_cd,
        stk_tp,
        own_qty,
        book_amt,
        bclm_qty,
        mrtg_lnd_qty,
        mrtg_buy_qty,
        sb_lim_qty,
        mov_lim_qty,
        lim_req_qty,
        outq_req_qty,
        delay_qty ,
        delay_sb_qty ,
        delay_mov_qty ,
        delay_reg_qty,
        sbst_dpo ,
        sbst_able_block ,
        sbst_unit_amt ,
        work_mn,
        work_dtm,
        work_trm
        ) values (

        c2.acnt_no,
        c2.sub_no,
        c2.stk_cd,
        vn.fss_get_stk_tp(c2.stk_cd),
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0 ,
        0 ,
        i_work_mn,
        sysdate,
        i_work_trm);
  end loop;


 vn.pxc_log_write('pss_stk_trd_luong', 'end');
end  pss_stk_trd_luong;
/

