create view V_AAA as
select nvl(t.item_cd, 0) item_cd,
       nvl(t.item_name, 0) item_name,
       nvl(t.ACTIVE_STAT, 0) ACTIVE_STAT,
       nvl(t.lnd_tp, 0) lnd_tp,
       nvl(t.item_id, 0) item_id,
       nvl(t.item_org_id, 0) item_org_id,
       to_char(t.create_dtm, 'DD/MM/YYYY - HH24:MI:SS') create_dtm,
       to_char(t.work_dtm, 'DD/MM/YYYY - HH24:MI:SS') work_dtm,
       nvl(to_char(t.apr_dtm, 'DD/MM/YYYY - HH24:MI:SS'), 'N/A') apr_dtm,
       t.item_cd || t.item_name || lpad(t.item_id, 6, '0') ||
       lpad(nvl(t.item_org_id, '0'), 6, '0') as item,
       nvl(t.tot_lnd_lmit, 0) tot_lnd_lmit,
       nvl(t.acc_lnd_lmit, 0) acc_lnd_lmit,
       nvl(t.item_loan_ord, 0) item_loan_ord,
       nvl(t.item_rpy_ord, 0) item_rpy_ord
  from vn.DLM00M01 t
/

