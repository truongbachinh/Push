create procedure pss_sync_list_stk_qty
(i_stk_cd in varchar2)
AS
    v_count_hnx     number := 0;
    v_count_upc     number := 0;
    v_count_otc     number := 0;
/* ************************************************************************************
    Author:         vnjvthangnm
    Created Date:   31-Aug-2021
    Description:    This function is used to synchronize the listed stock quantity when
                    its equal 0 in table of each exchanges.
    Notes:  This proc don't work for HSX because they using the data from master table.
    Sample call:
        execute vn.fss_get_list_stk_qty('AAA');
        execute vn.fss_get_list_stk_qty('%');

    MODIFICATION DETAILS:
    ----------------------------------------------------------------------------------
    Modified Date   Modified By       Modification Details
    ----------------------------------------------------------------------------------
    31-Aug-2021     vnjvthangnm       Initial creation
************************************************************************************ */
BEGIN
    vn.pxc_log_write ('pss_sync_list_stk_qty', 'Started at ' || to_char(sysdate,'DD-Mon-YYYY hh24:mi:ss'));
    vn.pxc_log_write ('pss_sync_list_stk_qty', 'Input stock: ' || i_stk_cd);

    for c1 in (
        select a.stk_cd, b.stk_mkt_tp, nvl(b.list_stk_qty, 0) as list_stk_qty -- HNX
          from vn.ssi03m00 a, vn.ssi01m00 b
         where a.stk_cd = b.stk_cd
           and b.stk_mkt_tp = '2'
           and b.stk_cd like i_stk_cd
           and nvl(a.list_stk_qty, 0) = 0
           and b.list_stk_qty > 0
        union
        select a.stk_cd, b.stk_mkt_tp, nvl(b.list_stk_qty, 0) as list_stk_qty -- UpCOM
          from vn.ssi03m10 a, vn.ssi01m00 b
         where a.stk_cd = b.stk_cd
           and b.stk_mkt_tp = '4'
           and b.stk_cd like i_stk_cd
           and nvl(a.list_stk_qty, 0) = 0
           and b.list_stk_qty > 0
        union
        select a.stk_cd, b.stk_mkt_tp, nvl(b.list_stk_qty, 0) as list_stk_qty -- DCCNY(OTC)
          from vn.ssi04m00 a, vn.ssi01m00 b
         where a.stk_cd = b.stk_cd
           and b.stk_mkt_tp = '3'
           and b.stk_cd like i_stk_cd
           and nvl(a.list_stk_qty, 0) = 0
           and b.list_stk_qty > 0
    ) loop
        if c1.stk_mkt_tp = '2' THEN
            update vn.ssi03m00
               set list_stk_qty = c1.list_stk_qty
             where stk_cd = c1.stk_cd;

            vn.pxc_log_write ('pss_sync_list_stk_qty', 'Update list_stk_qty of stk_cd ' || c1.stk_cd
                                                        || ' from 0 to ' || to_char(c1.list_stk_qty));
            v_count_hnx := v_count_hnx + 1;

        elsif c1.stk_mkt_tp = '4' THEN
            update vn.ssi03m10
               set list_stk_qty = c1.list_stk_qty
             where stk_cd = c1.stk_cd;

            vn.pxc_log_write ('pss_sync_list_stk_qty', 'Update list_stk_qty of stk_cd ' || c1.stk_cd
                                                        || ' from 0 to ' || to_char(c1.list_stk_qty));
            v_count_upc := v_count_upc + 1;

        elsif c1.stk_mkt_tp = '3' THEN
            update vn.ssi04m00
               set list_stk_qty = c1.list_stk_qty
             where stk_cd = c1.stk_cd;

            vn.pxc_log_write ('pss_sync_list_stk_qty', 'Update list_stk_qty of stk_cd ' || c1.stk_cd
                                                        || ' from 0 to ' || to_char(c1.list_stk_qty));
            v_count_otc := v_count_otc + 1;

        end if;
    end loop;

    vn.pxc_log_write ('pss_sync_list_stk_qty', 'Updated for ' || to_char(v_count_hnx) || ' stocks on HNX.');
    vn.pxc_log_write ('pss_sync_list_stk_qty', 'Updated for ' || to_char(v_count_upc) || ' stocks on UpCOM.');
    vn.pxc_log_write ('pss_sync_list_stk_qty', 'Updated for ' || to_char(v_count_otc) || ' stocks on OTC.');
    vn.pxc_log_write ('pss_sync_list_stk_qty', 'FInished at ' || to_char(sysdate,'DD-Mon-YYYY hh24:mi:ss'));
end pss_sync_list_stk_qty;
/

