create view CWD10MH00 as
select out_1.out_trd_seq_no a,
                   out_1.std_dt b,
                   out_1.out_acnt_nm c,
                   out_1.out_acnt_no ||out_1.out_sub_no d,
                   in_1.in_acnt_nm  e,
                   in_1.in_acnt_no ||in_1.in_sub_no   f,
                   out_1.out_trd_amt h,
                   out_1.out_cnte  i  ,
                   out_1.std_dt || out_1.out_acnt_no ||out_1.out_sub_no || lpad(out_1.out_trd_seq_no,3,'0') j,
                   out_1.cnfm_mn k,
                   out_1.work_mn l
        from (select std_dt         ,
                     trd_seq_no out_trd_seq_no,
                     acnt_no   out_acnt_no, sub_no    out_sub_no  ,
                     vn.faa_acnt_nm_g(acnt_no , sub_no ) out_acnt_nm ,
                     trd_amt    out_trd_amt,
                     nvl(vn.fcw_cash_cnte_q(acnt_no,sub_no , std_dt,trd_seq_no),'') out_cnte,
                     nvl(trim(cnte),'')       out_cnte1,
                     cncl_yn    out_cncl_yn,
                     etc_seq_no,
                     work_mn,
                     cnfm_mn
                from vn.cwd06h00
               where trd_seq_no <> 0
                 and cncl_yn = 'N'
                 and rmrk_cd  = '026'
                 and std_dt between '0' and 'z' ) out_1,
             (select std_dt ,
                     acnt_no   in_acnt_no ,
                     sub_no    in_sub_no  ,
                     vn.faa_acnt_nm_g(acnt_no , sub_no ) in_acnt_nm ,
                     trd_amt    in_trd_amt,
                     nvl(vn.fcw_cash_cnte_q(acnt_no,sub_no,std_dt,trd_seq_no),'') in_cnte,
                     nvl(trim(cnte),'')       in_cnte1,
                     cncl_yn    in_cncl_yn,
                     etc_seq_no,
                     work_mn,
                     cnfm_mn
                from vn.cwd06h00
               where trd_seq_no <> 0
                 and cncl_yn = 'N'
                 and rmrk_cd  = '025'
                and std_dt between '0' and 'z' ) in_1
         where out_1.std_dt = in_1.std_dt
           and out_1.etc_seq_no = in_1.etc_seq_no
           and out_1.out_trd_amt = in_1.in_trd_amt
           and out_1.out_cnte1 =  in_1.in_cnte1
           and out_1.cnfm_mn =  in_1.cnfm_mn
           and out_1.work_mn = in_1.work_mn
     union all
        select b.outamt_trd_seq_no a,
               b.std_dt b,
               vn.faa_acnt_nm_g(b.outamt_acnt_no , b.outamt_sub_no ) c,
               b.outamt_acnt_no||b.outamt_sub_no d,
               vn.faa_acnt_nm_g(b.inamt_acnt_no , b.inamt_sub_no ) e,
               b.inamt_acnt_no||b.inamt_sub_no f,
               b.trd_amt h,
               nvl(vn.fcw_cash_cnte_q(outamt_acnt_no,outamt_sub_no,std_dt,outamt_trd_seq_no),'') i,
              /* nvl(trim(b.cnte),'') i1,*/
               b.std_dt || b.outamt_acnt_no || b.outamt_sub_no || lpad(b.outamt_trd_seq_no,3,'0') j ,
               b.work_mn k,
               b.work_mn l
          from vn.cwd10h00 b
         where b.std_dt between '0' and 'z'
           and (b.std_dt, b.outamt_acnt_no , b.outamt_sub_no, b.outamt_trd_seq_no )
               not in
               (select std_dt, acnt_no, sub_no, trd_seq_no
                  from vn.cwd06h00
                 where rmrk_cd  = '026'
                   and trd_seq_no <> 0
                   and cncl_yn = 'N'
                   and std_dt between '0' and 'z')
     union all
        select out_1.out_trd_seq_no a,
                   vn.vwdate b,
                   out_1.out_acnt_nm c,
                   out_1.out_acnt_no ||out_1.out_sub_no d,
                   in_1.in_acnt_nm  e,
                   in_1.in_acnt_no ||in_1.in_sub_no   f,
                   out_1.out_trd_amt h,
                   out_1.out_cnte  i  ,
                   vn.vwdate || out_1.out_acnt_no ||out_1.out_sub_no || lpad(out_1.out_trd_seq_no,3,'0') j,
                   out_1.cnfm_mn k,
                   out_1.work_mn l
        from (select vn.vwdate          ,
                     trd_seq_no out_trd_seq_no,
                     acnt_no   out_acnt_no, sub_no    out_sub_no  ,
                     vn.faa_acnt_nm_g(acnt_no , sub_no ) out_acnt_nm ,
                     trd_amt    out_trd_amt,
                     nvl(vn.fcw_cash_cnte_q(acnt_no,sub_no,vn.vwdate,trd_seq_no),'') out_cnte,
                     nvl(trim(cnte),'')       out_cnte1,
                     cncl_yn    out_cncl_yn,
                     etc_seq_no,
                     work_mn,
                     cnfm_mn
                from vn.cwd06m00
               where trd_seq_no <> 0
                 and cncl_yn = 'N'
                 and rmrk_cd  = '026' ) out_1,
             (select vn.vwdate  ,
                     acnt_no   in_acnt_no ,
                     sub_no    in_sub_no  ,
                     vn.faa_acnt_nm_g(acnt_no , sub_no ) in_acnt_nm ,
                     trd_amt    in_trd_amt,
                     nvl(vn.fcw_cash_cnte_q(acnt_no,sub_no,vn.vwdate,trd_seq_no),'') in_cnte,
                     nvl(trim(cnte),'')       in_cnte1,
                     cncl_yn    in_cncl_yn,
                     etc_seq_no,
                     work_mn,
                     cnfm_mn
                from vn.cwd06m00
               where trd_seq_no <> 0
                 and cncl_yn = 'N'
                 and rmrk_cd  = '025' ) in_1
         where out_1.etc_seq_no = in_1.etc_seq_no
           and out_1.out_trd_amt = in_1.in_trd_amt
           and out_1.out_cnte1 =  in_1.in_cnte1
           and out_1.cnfm_mn =  in_1.cnfm_mn
           and out_1.work_mn = in_1.work_mn
     union all
        select b.outamt_trd_seq_no a,
               vn.vwdate  b,
               vn.faa_acnt_nm_g(b.outamt_acnt_no , b.outamt_sub_no ) c,
               b.outamt_acnt_no||b.outamt_sub_no d,
               vn.faa_acnt_nm_g(b.inamt_acnt_no , b.inamt_sub_no ) e,
               b.inamt_acnt_no||b.inamt_sub_no f,
               b.trd_amt h,
               nvl(vn.fcw_cash_cnte_q(outamt_acnt_no,outamt_sub_no,vn.vwdate,outamt_trd_seq_no),'') i,
               /*nvl(trim(b.cnte),'') i,*/
               vn.vwdate  || b.outamt_acnt_no || b.outamt_sub_no || lpad(b.outamt_trd_seq_no,3,'0') j ,
               b.work_mn k,
               b.work_mn l
          from vn.cwd10m00 b
         where (vn.vwdate , b.outamt_acnt_no , b.outamt_sub_no, b.outamt_trd_seq_no )
               not in
               (select vn.vwdate, acnt_no, sub_no, trd_seq_no
                  from vn.cwd06m00
                 where rmrk_cd  = '026'
                   and trd_seq_no <> 0
                   and cncl_yn = 'N')
/

