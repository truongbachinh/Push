create PROCEDURE pvsd_resend(
    i_bos_seq_no    VARCHAR2,
    i_acnt_no       VARCHAR2,
    i_vsd_cd        VARCHAR2
)
AS
/******************************************************************
Create date  : 2018/08/20
Create user  : vnjvhuedt
Purpose    	 : Update trang thai dien bi gui loi or bi VSD tu choi
*******************************************************************/
    temp    NUMBER;
BEGIN
/*INSERT INTO vn.testsql values(i_bos_seq_no||', '||i_acnt_no||', '||i_vsd_cd);*/

    UPDATE vn.masterseq
       set seq_no = seq_no + 1
     WHERE seq_nm = 'vsd01m00_seq';

    IF (i_vsd_cd = '1') THEN
        update  vn.vsd02m00
           SET  bos_seq_no = (SELECT seq_no FROM vn.masterseq WHERE seq_nm = 'vsd01m00_seq'),
                vsd_stat = 1,
                recv_stat = '',
                err_msg = '' 
         where acnt_no = i_acnt_no
         and bos_seq_no = i_bos_seq_no;
    ELSIF (i_vsd_cd = '2') THEN
        update  vn.ssb05m00
            SET bos_seq_no = (SELECT seq_no FROM vn.masterseq WHERE seq_nm = 'vsd01m00_seq'),
                bos_stat = 1,
                recv_stat = '',
                err_msg = '' 
          where bos_seq_no = i_bos_seq_no
            and acnt_no = i_acnt_no;
    ELSIF (i_vsd_cd = '3') THEN
        SELECT count(1)
          INTO temp
          FROM vn.srr03m00 a
         WHERE bos_seq_no = i_bos_seq_no;
        IF (temp > 0) then
            update  vn.srr03m00
                SET bos_seq_no = (SELECT seq_no FROM vn.masterseq WHERE seq_nm = 'vsd01m00_seq'),
                    bos_stat = 1,
                    recv_stat = '',
                    err_msg = '' 
              where bos_seq_no = i_bos_seq_no
                and acnt_no = i_acnt_no;
        ELSE
            update  vn.srr06m00
                SET bos_seq_no = (SELECT seq_no FROM vn.masterseq WHERE seq_nm = 'vsd01m00_seq'),
                    bos_stat = 1,
                    recv_stat = '',
                    err_msg = '' 
              where bos_seq_no = i_bos_seq_no
                and acnt_no = i_acnt_no;
        END IF;
    END IF;

END; -- Procedure
/

