create PROCEDURE    PRO_DUYET_BOS(RET IN OUT NUMBER)
-- DUYET PHAN CHI HO
-- KHONG CAP NHAT NEU PROC_TP = 0, 3 NEU TIME OUT
-- CAP NHAT PROC_BANK = 1 NEU BANK BAO OK
as
        is_acnt_no      varchar2(20);
        is_sub_no       varchar2(2);
        is_inout_tp     varchar2(2);
        is_rmrk_cd      varchar2(4);
        is_mdm_tp       varchar2(2);
        is_trd_amt      number;
        is_acc_act_cd   varchar2(20);
        is_cnte         varchar2(200);
        is_bank_cd      varchar2(4);
        is_bank_acnt_no varchar2(20);
        is_bank_acnt_nm varchar2(100);
        is_proc_bank    varchar2(1);
        is_user_1100    varchar2(20);
        is_branch_1100  varchar2(20);
        is_seq_cwd06    number;
        td_outq_dpo_bk  number;
        is_inamt_acnt   varchar2(10);
        is_inamt_sub    varchar2(2);
        ii_incw06m00_seq  number;



        o_trd_dt         varchar2(20); /*out trade date*/
        o_in_trd_dt         varchar2(20);/*in trade date */
        o_trd_seq_no     number; /*out trade seq*/
        o_in_trd_seq_no     number;/*in trade seq */
        o_dpo_prerm      number;
        o_in_dpo_prerm      number ;
        o_dpo_nowrm      number;
        o_in_dpo_nowrm      number;
        o_acnt_place     varchar2(20);
        o_in_acnt_place     varchar2(20);
        o_bnhof_tp       varchar2(20);
        o_in_bnhof_tp       varchar2(20);
        o_proc_bnhof_tp  varchar2(20);
        o_in_proc_bnhof_tp  varchar2(20);

        t_err_txt varchar2(200);
        t_err_msg varchar2(500);

        cursor c is
        (   select a.seq_no, a.proc_bank
            from vn.cwd11m00 a
            where a.proc_bank in ('1')
            and sended_stat = '1'
            and rmrk_cd in ('003','026')
            and inout_tp = '02'
            and std_dt = vn.vwdate
            and bos_desc is null );
begin

   null;
end;
/

