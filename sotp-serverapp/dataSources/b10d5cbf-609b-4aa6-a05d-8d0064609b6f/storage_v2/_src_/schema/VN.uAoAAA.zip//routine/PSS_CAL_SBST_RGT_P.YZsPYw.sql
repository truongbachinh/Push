create procedure    pss_cal_sbst_rgt_p
( i_proc_dt in 	varchar2,
  i_acnt_no	in 	varchar2,
  i_sub_no	in 	varchar2,
  i_work_mn in  varchar2
 ) is

/***************************************************************************
Create date: 2012/08/08
Create user: vnjvluong
Purpose	   : Tinh toan lai sbst_dpo va rgt_sbst trong cwd01m00 (khi thay doi ro CK cho TK)
**************************************************************************/

  o_proc_cnt 	number := 0 ;
  v_rgt_sbst	number := 0 ;
  v_reuse_amt	number := 0 ;

begin

 vn.pxc_log_write('pss_cal_sbst_p_day','START ['|| i_proc_dt ||'-'||i_acnt_no ||'-'||i_sub_no||']' );

/*  update vn.cwd01m00
	set rgt_sbst = 0
	   ,rgt_reuse = 0
  where acnt_no = i_acnt_no
    and sub_no = i_sub_no  ;  */


  select  nvl(sum(x.rgt_sbst),  0 ) * vn.fdl_get_mrgn_grp_acnt_rt( i_acnt_no, i_sub_no,vn.faa_acnt_get_grp_no (i_acnt_no, i_sub_no,'2', vn.vwdate),'02', vn.vwdate)    rgt_sbst ,
		  nvl(sum(x.reuse_amt), 0 )   reuse_amt
	into  v_rgt_sbst,
		  v_reuse_amt
   from
	 ( select a.acnt_no acnt_no ,
			  a.sub_no  sub_no  ,
			  Decode( c.rgt_tp , '1' , decode (a.inq_trd_no , 0 ,  nvl(a.cons_sbst_qty ,0 ) , 0 ) ,
					  Decode ( a.INQ_TRD_NO   , 0 , nvl(a.asn_qty  ,0)  , 0 ))
			   * vn.fss_get_td_cls_pri( a.stk_cd)
			   * vn.fsr_rgt_sbst_rt_acnt( a.stk_cd ,a.acnt_no, a.sub_no )  rgt_sbst   ,

			  (  Decode(a.FLOTQ_TRD_NO , 0 , nvl(a.flotq_amt,0) , 0 )
			   + Decode(a.RCPT_TRD_NO  , 0 , nvl(a.asn_amt  ,0) , 0 )
			   + Decode(a.INTER_TRD_NO , 0 , nvl(a.inter_amt,0) , 0 ) )
			   * vn.fsr_rgt_cash_rt_acnt( a.stk_cd ,a.acnt_no, a.sub_no)  reuse_amt
		 from vn.srr02m00 a ,
			  vn.aaa01m00 b ,
			  vn.srr01m00 c
		where a.rgt_std_dt  = c.rgt_std_dt
		  and a.rgt_tp      = c.rgt_tp
		  and a.stk_cd      = c.stk_cd
		  and a.seq_no      = c.seq_no
		  and a.rgt_tp      <> '8'
		  and c.rgt_proc_stat >= '3'
		  and a.acnt_no      =    b.acnt_no
		  and a.sub_no       =    b.sub_no
		  and a.acnt_no      =	  i_acnt_no
		  and a.sub_no       =	  i_sub_no
		  and b.acnt_stat    =   '1'
		  and c.rgt_tp in ( '1','2','3','9')

	   union all

	   select a.acnt_no acnt_no ,
			  a.sub_no  sub_no  ,
			  Decode( a.inq_trd_no   , 0  , nvl(a.asn_qty   ,0)  , 0 )
			   * vn.fss_get_td_cls_pri( d.cnvt_stk_cd)
			   * vn.fsr_rgt_sbst_rt_acnt( d.cnvt_stk_cd ,a.acnt_no, a.sub_no )  rgt_sbst     ,

			  Decode( a.FLOTQ_TRD_NO , 0  , nvl(a.flotq_amt ,0)  , 0 )
			  * vn.fsr_rgt_cash_rt_acnt( a.stk_cd ,a.acnt_no, a.sub_no)  reuse_amt
		  from vn.srr02m00 a ,
			   vn.aaa01m00 b ,
			   vn.srr01m10 d
		 where a.rgt_std_dt =  d.rgt_std_dt
		  and  a.rgt_tp     =  '8'
		  and  a.stk_cd     =  d.stk_cd
		  and  a.acnt_no    =  b.acnt_no
		  and  a.sub_no     =  b.sub_no
		  and  a.acnt_no    =	  i_acnt_no
		  and  a.sub_no     =	  i_sub_no
		  and  b.acnt_stat  = '1'
		  and  d.rgt_proc_stat >= '3'
	   ) x;

	update  vn.cwd01m00
	 set   rgt_reuse = trunc( v_reuse_amt )
		  ,rgt_sbst  = Trunc( v_rgt_sbst)
	where   acnt_no   = i_acnt_no
	 and   sub_no    = i_sub_no;

 vn.pss_cal_sbst_p
          (vn.vwdate
          ,i_acnt_no
		  ,i_sub_no
          ,i_work_mn
          ,o_proc_cnt
       );

 vn.pxc_log_write('pss_cal_sbst_rgt_p','pss_cal_sbst_p ['|| o_proc_cnt ||'-'||i_acnt_no||'-'||i_sub_no||']');


 vn.pxc_log_write('pss_cal_sbst_rgt_p','pdl_crd_loan_rt_day [ ' || to_char(sqlcode) ||']');
 vn.pxc_log_write('pss_cal_sbst_rgt_p','FINISH');

end  pss_cal_sbst_rgt_p;
/

