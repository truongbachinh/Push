create FUNCTION fcw_int_rt_get(i_int_rt_tp IN VARCHAR2,
                                          i_apy_dt    IN VARCHAR2,
                                          i_amt       IN NUMBER)
  RETURN NUMBER IS
  t_int_rt NUMBER := 0;
  t_sqlcd  NUMBER := 0;

BEGIN

  BEGIN
    SELECT int_rt * 100 /* Tran.Nguyen - Fix 20180711 */
      INTO t_int_rt
      FROM vn.cwd09m01
     WHERE int_rt_cd = i_int_rt_tp
       AND str_amt <= i_amt
       AND end_amt >= i_amt
       AND active_stat = 'Y'
       AND aply_dt = (SELECT MAX(aply_dt)
                        FROM vn.cwd09m01
                       WHERE int_rt_cd = i_int_rt_tp
                         AND str_amt <= i_amt
                         AND end_amt >= i_amt
                         AND active_stat = 'Y'
                         AND aply_dt <= i_apy_dt);
  EXCEPTION
    WHEN no_data_found THEN
      RETURN 0;

    WHEN OTHERS THEN
      raise_application_error(-20100,
                              '*fcw_int_rt_get**' || to_char(t_sqlcd) ||
                              i_int_rt_tp || '*' || i_apy_dt || '*' ||
                              i_amt || '*');
  END;

  RETURN t_int_rt;

END fcw_int_rt_get;
/

