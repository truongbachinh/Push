create view XCS01M03_VW as
select x12.func_nm, x13."FUNC_CD",x13."MSG_LANG",x13."FORM_SMS_MSG",x13."WORK_MN",x13."WORK_DTM",x13."WORK_TRM"
from vn.xcs01m03 x13
inner join vn.xcs01m02 x12
on x13.func_cd = x12.func_cd
order by x13.func_cd, x13.msg_lang
/

