create PROCEDURE    PGG_AST_GGA24H00
   (I_FLAG          IN      VARCHAR2,       -- U:처리,D:취소
    I_BRCH_CD       IN      VARCHAR2,       -- 지점
    I_AGNC_BRCH     IN      VARCHAR2,       -- 대리지점
    I_SLIP_DT       IN      VARCHAR2,       -- 전표일자
    I_SLIP_NO       IN      VARCHAR2,       -- 전표번호
    I_WORK_MN       IN      VARCHAR2,		-- 처리자
    I_WORK_TRM      IN      VARCHAR2,       -- IP_ADDRESS
    O_RTN_TBL       OUT     VARCHAR2,       -- Return Table
	O_RTN_ERR       OUT     VARCHAR2,       -- Return Error Code
	O_RTN_MSG       OUT     VARCHAR2        -- Return Message
	) IS

    -- Constants
    K_SLIP_MAXDT    VARCHAR2(8) := '20080401' ; 	-- 처리시작일

    -- Variables
	T_GGA24H00_REGI_DT				GGA24H00.REGI_DT%TYPE;				-- 등록일
	T_GGA24H00_SEQ_NO				GGA24H00.SEQ_NO%TYPE;               -- 일련번호
	T_GGA24H00_AST_NO               GGA24H00.AST_NO%TYPE;               -- 자산번호
	T_GGA24H00_AST_LKND             GGA24H00.AST_LKND%TYPE;             -- 자산분류
	T_GGA24H00_AST_MKND             GGA24H00.AST_MKND%TYPE;             -- 자산부문
	T_GGA24H00_AST_SEQ              GGA24H00.AST_SEQ%TYPE;              -- 자산순번
	T_GGA24H00_BRCH_CD              GGA24H00.BRCH_CD%TYPE;              -- 지점코드
	T_GGA24H00_AGNC_BRCH            GGA24H00.AGNC_BRCH%TYPE;            -- 대리지점
	T_GGA24H00_DEPT_CD              GGA24H00.DEPT_CD%TYPE;              -- 부서코드
	T_GGA24H00_AST_STAT             GGA24H00.AST_STAT%TYPE;             -- 자산상태
	T_GGA24H00_MVIN_BRCH_CD         GGA24H00.MVIN_BRCH_CD%TYPE;         -- 수관지점
	T_GGA24H00_MVIN_AGNC_BRCH       GGA24H00.MVIN_AGNC_BRCH%TYPE;       -- 수관대리지점
	T_GGA24H00_ACC_ACT_CD           GGA24H00.ACC_ACT_CD%TYPE;           -- 회계계정코드
	T_GGA24H00_AST_NM               GGA24H00.AST_NM%TYPE;               -- 자산명
	T_GGA24H00_AST_STD              GGA24H00.AST_STD%TYPE;              -- 자산규격
	T_GGA24H00_AST_UNIT             GGA24H00.AST_UNIT%TYPE;             -- 자산단위
	T_GGA24H00_AST_QTY              GGA24H00.AST_QTY%TYPE;              -- 자산수량
	T_GGA24H00_AST_ADDR             GGA24H00.AST_ADDR%TYPE;             -- 자산주소
	T_GGA24H00_MNF_CTRY             GGA24H00.MNF_CTRY%TYPE;             -- 제조국가
	T_GGA24H00_MNF_DT               GGA24H00.MNF_DT%TYPE;               -- 제조일자
	T_GGA24H00_AST_TSCD_NO          GGA24H00.AST_TSCD_NO%TYPE;          -- 증명서번호
	T_GGA24H00_AST_TSCD_DT          GGA24H00.AST_TSCD_DT%TYPE;          -- 증명서일자
	T_GGA24H00_USE_YY_CNT           GGA24H00.USE_YY_CNT%TYPE;           -- 사용년수
	T_GGA24H00_DLM_AMT              GGA24H00.DLM_AMT%TYPE;              -- 잔존가액
	T_GGA24H00_DEPR_METH            GGA24H00.DEPR_METH%TYPE;            -- 상각방법
	T_GGA24H00_DEPR_RT              GGA24H00.DEPR_RT%TYPE;              -- 상각율
	T_GGA24H00_FRCT_DT              GGA24H00.FRCT_DT%TYPE;              -- 취득예정일
	T_GGA24H00_COST_AMT             GGA24H00.COST_AMT%TYPE;             -- 원가금액
	T_GGA24H00_TAX_AMT              GGA24H00.TAX_AMT%TYPE;              -- 세액금액
	T_GGA24H00_ETC_AMT              GGA24H00.ETC_AMT%TYPE;              -- 기타경비
	T_GGA24H00_PROC_AMT             GGA24H00.PROC_AMT%TYPE;             -- 처리금액
	T_GGA24H00_VAT_AMT              GGA24H00.VAT_AMT%TYPE;              -- 부가세액
	T_GGA24H00_AST_PROC_TP          GGA24H00.AST_PROC_TP%TYPE;          -- 자산처리구분
	T_GGA24H00_AST_SETL_TP          GGA24H00.AST_SETL_TP%TYPE;          -- 자산결제구분
	T_GGA24H00_CNTE                 GGA24H00.CNTE%TYPE;                 -- 거래비고
	T_GGA24H00_SLIP_DT              GGA24H00.SLIP_DT%TYPE;              -- 전표일자
	T_GGA24H00_SLIP_BRCH_CD         GGA24H00.SLIP_BRCH_CD%TYPE;         -- 전표지점코드
	T_GGA24H00_SLIP_AGNC_BRCH       GGA24H00.SLIP_AGNC_BRCH%TYPE;       -- 전표대리지점
	T_GGA24H00_SLIP_NO              GGA24H00.SLIP_NO%TYPE;              -- 전표번호
	T_GGA24H00_SLIP_SUB_NO          GGA24H00.SLIP_SUB_NO%TYPE;          -- 전표부번호
	T_GGA24H00_CNCL_DT              GGA24H00.CNCL_DT%TYPE;              -- 취소일자
	T_GGA24H00_USE_YN               GGA24H00.USE_YN%TYPE;               -- 사용여부
	T_GGA24H00_WORK_MN              GGA24H00.WORK_MN%TYPE;              -- 처리자
	T_GGA24H00_WORK_DTM             GGA24H00.WORK_DTM%TYPE;             -- 처리일시
	T_GGA24H00_WORK_TRM             GGA24H00.WORK_TRM%TYPE;             -- 처리단말
	T_GGA24H00_MDFY_MN              GGA24H00.MDFY_MN%TYPE;              -- 수정자
	T_GGA24H00_MDFY_DTM             GGA24H00.MDFY_DTM%TYPE;             -- 수정일시
	T_GGA24H00_MDFY_TRM             GGA24H00.MDFY_TRM%TYPE;             -- 수정단말


    -- Exceptions Declare
    ERR_COMMON        	EXCEPTION;
	ERR_GGA24h00_INS    EXCEPTION;
	ERR_GGA24h00_DEL    EXCEPTION;

-- *************************< START OF PROCEDURE >****************************
BEGIN

	/* 0. 처리 시작일 체크 */
	IF  I_SLIP_DT   <=   K_SLIP_MAXDT  THEN
        RAISE ERR_COMMON;
	END IF;

    -- ****************************************
    -- * 고정자산 신규취득 및 자본적지출 처리 *
    -- ****************************************
    IF  I_FLAG  =   'U' THEN

        -- U_6. 전표조회
        FOR C11 IN
        	(	SELECT	v11.SLIP_DT				AS	SLIP_DT,
						v11.BRCH_CD				AS	BRCH_CD,
						v11.AGNC_BRCH			AS	AGNC_BRCH,
						v11.SLIP_NO				AS	SLIP_NO,
						v11.SLIP_SUB_NO			AS	SLIP_SUB_NO,
						v11.ACC_RMRK_CD			AS	ACC_RMRK_CD,
						v11.ACC_ACT_CD			AS	ACC_ACT_CD,
						NVL(v11.SLIP_AMT, 0)	AS	SLIP_AMT,
						(	SELECT	NVL(v21.SLIP_AMT, 0)	AS	SLIP_VAT
							  FROM	VN.GGA06M00	v21,
									(	SELECT	v21.COL_CD_TP_NM	AS	ACC_ACT_CD
										  FROM	VN.XCC01C01	v21
										 WHERE	v21.COL_CD	=	'vat_act_tp'
									)			v22
							 WHERE	v21.SLIP_DT		=	v11.SLIP_DT
							   AND	v21.BRCH_CD		=	v11.BRCH_CD
							   AND	v21.AGNC_BRCH	=	v11.AGNC_BRCH
							   AND	v21.SLIP_NO		=	v11.SLIP_NO
							   AND	v21.ACC_ACT_CD	=	v22.ACC_ACT_CD
						)						AS	SLIP_VAT,
						v11.TRD_CNTE			AS	TRD_CNTE,
						DECODE(SUBSTR(v11.CUST_CD, 1, 2),
							'KD', SUBSTR(v11.CUST_CD, 8, 3), '000')	AS	DEPT_CD,
						DECODE(SUBSTR(v11.ACC_RMRK_CD, 3, 1),
							'1', 'A', '2', 'B', 'X')	AS	AST_STAT,
						v12.AST_LKND			AS	AST_LKND,
						v12.USE_YY_CNT			AS	USE_YY_CNT,
						v12.DLM_AMT				AS	DLM_AMT,
						v12.DEPR_METH			AS	DEPR_METH
				  FROM	VN.GGA06M00	v11,
						VN.GGA21C00	v12
				 WHERE	v11.SLIP_DT		=	I_SLIP_DT
				   AND	v11.BRCH_CD		=	I_BRCH_CD
				   AND	v11.AGNC_BRCH	=	I_AGNC_BRCH
				   AND	v11.SLIP_NO		=	I_SLIP_NO
				   AND	(v11.ACC_RMRK_CD	LIKE	'421%'
				    OR	v11.ACC_RMRK_CD		LIKE	'422%')
				   AND	v11.SLIP_STAT	=	'2'
				   AND	v11.ACC_ACT_CD	=	v12.ACC_ACT_CD
				   AND	ROWNUM			<=	1
            ) LOOP


            -- U_7. 고정자산 거래내역
			T_GGA24H00_REGI_DT			:=	I_SLIP_DT;				-- 등록일

			/* 거래 일련번호 발번 */
			BEGIN
				SELECT	/*+ INDEX_DESC(v11 GGA24H00_PK) */
						NVL(MAX(v11.SEQ_NO), 0) + 1	AS	SEQ_NO
				  INTO	T_GGA24H00_SEQ_NO
				  FROM	VN.GGA24H00	v11
				 WHERE	REGI_DT	=	I_SLIP_DT ;
			EXCEPTION WHEN OTHERS THEN
				T_GGA24H00_SEQ_NO := 1;
			END;

			T_GGA24H00_AST_NO           :=	NULL;				-- 자산번호
			T_GGA24H00_AST_LKND         :=	C11.AST_LKND;		-- 자산분류
			T_GGA24H00_AST_MKND         :=	NULL;				-- 자산부문
			T_GGA24H00_AST_SEQ          :=	NULL;				-- 자산순번
			T_GGA24H00_BRCH_CD          :=	I_BRCH_CD;			-- 지점코드
			T_GGA24H00_AGNC_BRCH        :=	I_AGNC_BRCH;		-- 대리지점
			T_GGA24H00_DEPT_CD          :=	C11.DEPT_CD;		-- 부서코드
			T_GGA24H00_AST_STAT         :=	C11.AST_STAT;		-- 자산상태
			T_GGA24H00_MVIN_BRCH_CD     :=	NULL;				-- 수관지점
			T_GGA24H00_MVIN_AGNC_BRCH   :=	NULL;				-- 수관대리지점
			T_GGA24H00_ACC_ACT_CD       :=	C11.ACC_ACT_CD;		-- 회계계정코드
			T_GGA24H00_AST_NM           :=	NULL;				-- 자산명
			T_GGA24H00_AST_STD          :=	NULL;				-- 자산규격
			T_GGA24H00_AST_UNIT         :=	NULL;				-- 자산단위
			T_GGA24H00_AST_QTY          :=	1;					-- 자산수량
			T_GGA24H00_AST_ADDR         :=	NULL;				-- 자산주소
			T_GGA24H00_MNF_CTRY         :=	NULL;				-- 제조국가
			T_GGA24H00_MNF_DT           :=	NULL;				-- 제조일자
			T_GGA24H00_AST_TSCD_NO      :=	NULL;				-- 증명서번호
			T_GGA24H00_AST_TSCD_DT      :=	NULL;				-- 증명서일자
			T_GGA24H00_USE_YY_CNT       :=	C11.USE_YY_CNT;		-- 사용년수
			T_GGA24H00_DLM_AMT          :=	C11.DLM_AMT;		-- 잔존가액
			T_GGA24H00_DEPR_METH        :=	C11.DEPR_METH;		-- 상각방법
			T_GGA24H00_DEPR_RT          :=	0;					-- 상각율
			T_GGA24H00_FRCT_DT          :=	I_SLIP_DT;			-- 취득예정일
			T_GGA24H00_COST_AMT         :=	C11.SLIP_AMT;		-- 원가금액
			T_GGA24H00_TAX_AMT          :=	0;					-- 세액금액
			T_GGA24H00_ETC_AMT          :=	0;					-- 기타경비
			T_GGA24H00_PROC_AMT         :=	C11.SLIP_AMT;		-- 처리금액
			T_GGA24H00_VAT_AMT          :=	C11.SLIP_VAT;		-- 부가세액
			T_GGA24H00_AST_PROC_TP      :=	'0';				-- 자산처리구분
			T_GGA24H00_AST_SETL_TP      :=	SUBSTR(C11.ACC_RMRK_CD, 5, 1) ;		-- 자산처리구분
			T_GGA24H00_CNTE             :=	C11.TRD_CNTE;		-- 거래비고
			T_GGA24H00_SLIP_DT          :=	C11.SLIP_DT;		-- 전표일자
			T_GGA24H00_SLIP_BRCH_CD     :=	C11.BRCH_CD;		-- 전표지점코드
			T_GGA24H00_SLIP_AGNC_BRCH   :=	C11.AGNC_BRCH;		-- 전표대리지점
			T_GGA24H00_SLIP_NO          :=	C11.SLIP_NO;		-- 전표번호
			T_GGA24H00_SLIP_SUB_NO      :=	C11.SLIP_SUB_NO;	-- 전표부번호
			T_GGA24H00_CNCL_DT          :=	NULL;				-- 취소일자
			T_GGA24H00_USE_YN           :=	'Y';				-- 사용여부
            T_GGA24H00_WORK_MN			:=	I_WORK_MN;			-- 처리자
            T_GGA24H00_WORK_DTM			:=	SYSDATE;			-- 처리일시
            T_GGA24H00_WORK_TRM			:=	I_WORK_TRM;			-- 처리단말
            T_GGA24H00_MDFY_MN			:=	I_WORK_MN;      	-- 수정자
            T_GGA24H00_MDFY_DTM			:=	SYSDATE;        	-- 수정일시
            T_GGA24H00_MDFY_TRM			:=	I_WORK_TRM;     	-- 수정단말


        	-- U_5. 회계전표 Insert
			BEGIN
	            INSERT
	              INTO  VN.GGA24H00(
						REGI_DT,		-- 등록일
						SEQ_NO,			-- 일련번호
						AST_NO,			-- 자산번호
						AST_LKND,		-- 자산분류
						AST_MKND,		-- 자산부문
						AST_SEQ,		-- 자산순번
						BRCH_CD,		-- 지점코드
						AGNC_BRCH,		-- 대리지점
						DEPT_CD,		-- 부서코드
						AST_STAT,		-- 자산상태
						MVIN_BRCH_CD,	-- 수관지점
						MVIN_AGNC_BRCH,	-- 수관대리지점
						ACC_ACT_CD,		-- 회계계정코드
						AST_NM,			-- 자산명
						AST_STD,		-- 자산규격
						AST_UNIT,		-- 자산단위
						AST_QTY,		-- 자산수량
						AST_ADDR,		-- 자산주소
						MNF_CTRY,		-- 제조국가
						MNF_DT,			-- 제조일자
						AST_TSCD_NO,	-- 증명서번호
						AST_TSCD_DT,	-- 증명서일자
						USE_YY_CNT,		-- 사용년수
						DLM_AMT,		-- 잔존가액
						DEPR_METH,		-- 상각방법
						DEPR_RT,		-- 상각율
						FRCT_DT,		-- 취득예정일
						COST_AMT,		-- 원가금액
						TAX_AMT,		-- 세액금액
						ETC_AMT,		-- 기타경비
						PROC_AMT,		-- 처리금액
						VAT_AMT,		-- 부가세액
						AST_PROC_TP,	-- 자산처리구분
						AST_SETL_TP,	-- 자산결제구분
						CNTE,			-- 거래비고
						SLIP_DT,		-- 전표일자
						SLIP_BRCH_CD,	-- 전표지점코드
						SLIP_AGNC_BRCH,	-- 전표대리지점
						SLIP_NO,		-- 전표번호
						SLIP_SUB_NO,	-- 전표부번호
						CNCL_DT,		-- 취소일자
						USE_YN,			-- 사용여부
						WORK_MN,		-- 처리자
						WORK_DTM,		-- 처리일시
						WORK_TRM,		-- 처리단말
						MDFY_MN,		-- 수정자
						MDFY_DTM,		-- 수정일시
						MDFY_TRM)		-- 수정단말
     	       VALUES  (T_GGA24H00_REGI_DT,
						T_GGA24H00_SEQ_NO,
						T_GGA24H00_AST_NO,
						T_GGA24H00_AST_LKND,
						T_GGA24H00_AST_MKND,
						T_GGA24H00_AST_SEQ,
						T_GGA24H00_BRCH_CD,
						T_GGA24H00_AGNC_BRCH,
						T_GGA24H00_DEPT_CD,
						T_GGA24H00_AST_STAT,
						T_GGA24H00_MVIN_BRCH_CD,
						T_GGA24H00_MVIN_AGNC_BRCH,
						T_GGA24H00_ACC_ACT_CD,
						T_GGA24H00_AST_NM,
						T_GGA24H00_AST_STD,
						T_GGA24H00_AST_UNIT,
						T_GGA24H00_AST_QTY,
						T_GGA24H00_AST_ADDR,
						T_GGA24H00_MNF_CTRY,
						T_GGA24H00_MNF_DT,
						T_GGA24H00_AST_TSCD_NO,
						T_GGA24H00_AST_TSCD_DT,
						T_GGA24H00_USE_YY_CNT,
						T_GGA24H00_DLM_AMT,
						T_GGA24H00_DEPR_METH,
						T_GGA24H00_DEPR_RT,
						T_GGA24H00_FRCT_DT,
						T_GGA24H00_COST_AMT,
						T_GGA24H00_TAX_AMT,
						T_GGA24H00_ETC_AMT,
						T_GGA24H00_PROC_AMT,
						T_GGA24H00_VAT_AMT,
						T_GGA24H00_AST_PROC_TP,
						T_GGA24H00_AST_SETL_TP,
						T_GGA24H00_CNTE,
						T_GGA24H00_SLIP_DT,
						T_GGA24H00_SLIP_BRCH_CD,
						T_GGA24H00_SLIP_AGNC_BRCH,
						T_GGA24H00_SLIP_NO,
						T_GGA24H00_SLIP_SUB_NO,
						T_GGA24H00_CNCL_DT,
						T_GGA24H00_USE_YN,
						T_GGA24H00_WORK_MN,
						T_GGA24H00_WORK_DTM,
						T_GGA24H00_WORK_TRM,
						T_GGA24H00_MDFY_MN,
						T_GGA24H00_MDFY_DTM,
						T_GGA24H00_MDFY_TRM );

		    EXCEPTION WHEN OTHERS THEN
		        RAISE ERR_GGA24H00_INS;
		    END;

        END LOOP;   -- C11 End Loop


    -- ****************************************
    -- * 고정자산 신규취득 및 자본적지출 취소 *
    -- ****************************************
    ELSIF   I_FLAG  =   'D' THEN

		BEGIN

	        DELETE
	          FROM  VN.GGA24H00
			 WHERE	SLIP_DT			=	I_SLIP_DT
			   AND	SLIP_BRCH_CD	=   I_BRCH_CD
			   AND	SLIP_AGNC_BRCH	=	I_AGNC_BRCH
			   AND	SLIP_NO			=	I_SLIP_NO
			   AND	AST_PROC_TP		=	'0' ;

	    EXCEPTION WHEN OTHERS THEN
	        RAISE ERR_GGA24H00_DEL;
	    END;

    END IF;

    O_RTN_TBL  :=  'GGA24H00';
    O_RTN_ERR  :=  '0';
    IF  I_FLAG  =   'U' THEN
        --O_RTN_MSG  :=  '[V0602] 정상적으로 처리되었습니다.';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','0602');
    ELSIF   I_FLAG  =   'D' THEN
        --O_RTN_MSG  :=  '[V0603] 정상적으로 처리되었습니다.';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','0603');
    END IF;
    --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);

EXCEPTION
    WHEN    ERR_GGA24H00_INS  THEN
        O_RTN_TBL  :=  'ERR_GGA24H00_INS';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2627]전표번호 생성중 오류가 발생하였습니다. [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2627') || ' [' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA24H00_DEL  THEN
        O_RTN_TBL  :=  'ERR_GGA24H00_DEL';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2627]전표번호 생성중 오류가 발생하였습니다. [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2627') || ' [' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_COMMON  THEN
        O_RTN_TBL  :=  'COMMON';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        O_RTN_MSG  :=  'ERROR ' || SUBSTR(SQLERRM, 1, 100);
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    OTHERS  THEN
        O_RTN_TBL  :=  'OTHERS';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        O_RTN_MSG  :=  'ERROR ' || SUBSTR(SQLERRM, 1, 100);
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
END PGG_AST_GGA24H00;
/

