create procedure pts_bat_tso05m20_trunc (
    i_work_dt       in      varchar2,       -- date(yyyymmdd)
	o_err_code      in      number,         -- error code(0:SUCCESS)
	o_err_msg       in      varchar2,       -- error message
	o_proc_cnt      out     number          -- proc data count
) as

t_err_code      number        := o_err_code;
t_err_msg       varchar2(600) := rtrim(o_err_msg);
t_chk           varchar2(1);
exp_error       exception;

/*!
    \file     pts_bat_tso05m20_trunc
    \brief    tso01m00 table reset

	\section intro Program Information
		- Program Name              : pts_bat_tso05m20_trunc
		- Service Name              :
		- Related Client Program- Client Program ID :
		- Related Tables            : tso01m00
		- Dev. Date                 : 2009/04/27
		- Developer                 : bgcha
		- Business Logic Desc.      :
		- Latest Modification Date  :

	\section history Program Modification History
		- 1.0  2007/11/27

	\section hardcoding Hard-Coding List

	\section info Additional Reference Comments
*/

begin

	t_err_code := 0;
	t_err_msg  := 'SUCCESS';
	t_chk      := 'Y';
    o_proc_cnt := 0;

	-- 1. ���������̺�ʱ� üũ Funüũ

	-- 2. ���������̺�ʱ�  ��̺�ʱ�
	if t_chk = 'Y' then
		DELETE VN.TSO05M20 ;
		--UPDATE VN.TSO05M20 SET OWN_QTY = 0  ;
		o_proc_cnt := SQL%ROWCOUNT;
	else
		t_err_code := -1;
	    t_err_msg  := '��� ���������� ��� ������������ϴ�.!';
		raise_application_error(-20100,'[pts_bat_tso05m20_trunc] ' || t_err_msg);
	end if;

	exception when  exp_error then
		t_err_code := sqlcode;
		t_err_msg  := sqlerrm;
		raise_application_error(-20100,'[pts_bat_tso05m20_trunc] ' || t_err_msg);

end pts_bat_tso05m20_trunc;
/

