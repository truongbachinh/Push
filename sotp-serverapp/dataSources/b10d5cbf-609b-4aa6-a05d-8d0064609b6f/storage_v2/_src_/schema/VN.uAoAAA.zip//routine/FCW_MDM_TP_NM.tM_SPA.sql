create function fcw_mdm_tp_nm
(
	i_mdm_tp			in		varchar2
) return varchar2 as

	o_COL_CD_TP_NM	varchar2(200);

/* ===========================================
	-- Program ID 		: 	fcw_mdm_tp_nm
	-- Date of Program	:    2017/08/16
	-- Programmer		:	hieu.dt
	-- Description 		:
			input  :
					1: mdm_tp
      output
					1: type trans

   =========================================== */
begin

	begin
	select	COL_CD_TP_NM
	into	o_COL_CD_TP_NM
	from	vn.xcc01c01
	where	COL_CD 	=	'mdm_tp'
	and     COL_CD_TP = i_mdm_tp
	and		rownum =1;

		return o_COL_CD_TP_NM;

	exception
	when	 no_data_found then
		return 	'!';
	end;


end ;
/

