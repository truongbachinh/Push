create function    fcw_get_cash
(
    i_acnt_no      in   varchar2,
    i_sub_no       in   varchar2,
    i_type         in   varchar2, --1 PIA, 2 SELL
    i_day          in   number, -- 0 ngay T, 1 ngay T1, 2 ngay T2
    i_date         in   varchar2
)    return          NUMBER  as
	t_sec_cd VARCHAR2(3) := vn.fxc_sec_cd('R');
    o_cash          number ;
    o_pia           number ;
    t_err_txt       VARCHAR(100) := ' ';
    t_lnd_rm_int    number ;
    t_vwdate        varchar(08)  := null;
    i_date1         varchar(08)  := null;
begin
    o_cash     := 0;
    o_pia      := 0;
    t_lnd_rm_int := 0;
     t_vwdate   :=  vn.vwdate;
     i_date1    :=  vn.fxc_vorderdt_g(to_date(i_date,'yyyymmdd'), -i_day );

    if  i_type = '1' then

       /* begin
            SELECT  nvl(sum(nvl(lnd_amt,0) - nvl(lnd_rpy_amt,0)),0)
              INTO  o_pia
              FROM  VN.dlm01m20
             WHERE  ACNT_NO    =  i_acnt_no
               AND  SUB_NO     =  i_sub_no
               AND  MTH_DT = i_date1;

        exception
            when  NO_DATA_FOUND  then
                o_pia    :=  0;

            when  OTHERS         then
                t_err_txt  :=  'error - ' ||  to_char(sqlcode) ;
                raise_application_error (-20100, t_err_txt);
         end;

          SELECT  nvl(sum(lnd_int),0)
          INTO  t_lnd_rm_int
          FROM  vn.dlm01m00
         WHERE  lnd_tp          =  '10'
           AND  acnt_no         =  i_acnt_no
           AND  sub_no          =  i_sub_no
           AND  lnd_amt > lnd_rpy_amt
           AND  MTH_DT = i_date1;

         if   i_day = 0 then
              if t_vwdate = i_date then
               select nvl(sum(nvl(sb_amt,0) - nvl(sb_cmsn,0) - nvl(sb_tax,0))  - o_pia - t_lnd_rm_int,0)
             into o_cash
             from dsc01m10
            where mth_dt = i_date
              and acnt_no = i_acnt_no
              and sub_no = i_sub_no
              and sb_tp = '1' ;
              else
                 select nvl(sum(nvl(sb_amt,0) - nvl(sb_cmsn,0) - nvl(sb_tax,0))  - o_pia - t_lnd_rm_int,0)
                  into o_cash
                    from dsc01m00
                      where mth_dt = i_date
                      and acnt_no = i_acnt_no
                      and sub_no = i_sub_no
                      and sb_tp = '1' ;
              end if;
              return o_cash;
          else
             select nvl(sum(nvl(sb_amt,0) - nvl(sb_cmsn,0) - nvl(sb_tax,0))  - o_pia - t_lnd_rm_int,0)
               into o_cash
               from dsc01m00
              where mth_dt = i_date1
                and acnt_no = i_acnt_no
                and sub_no = i_sub_no
                and sb_tp = '1' ;
         end if;
         return o_cash;*//*edit for jira 2106 affter fdl_Get_pia_amt_dt(t_sec_cd,i_acnt_no,i_sub_no,i_date,'9999')*/
         select vn.fdl_get_pia_amt_cash(t_sec_cd,i_acnt_no,i_sub_no,i_date,'9999')
          into o_cash
          FROM DUAL;
          return o_cash;
    else
      if i_day = 0 then
         if t_vwdate = i_date then
            select nvl(sum( decode(cmsn_setl_yn,'Y',0,nvl(sb_cmsn,0)) ) + sum( decode(dpo_setl_yn,'Y',0,nvl(sb_amt,0)) ),0)
              into o_cash
              from dsc01m10
             where mth_dt = i_date
               and acnt_no = i_acnt_no
               and sub_no = i_sub_no
               and sb_tp = '2' ;
          else
               select nvl(sum( decode(cmsn_setl_yn,'Y',0,nvl(sb_cmsn,0)) ) + sum( decode(dpo_setl_yn,'Y',0,nvl(sb_amt,0)) ),0)
              into o_cash
              from dsc01m00
             where mth_dt = i_date
               and acnt_no = i_acnt_no
               and sub_no = i_sub_no
               and sb_tp = '2' ;
          end if;
        else
            select nvl(sum( decode(cmsn_setl_yn,'Y',0,nvl(sb_cmsn,0)) ) + sum( decode(dpo_setl_yn,'Y',0,nvl(sb_amt,0)) ),0)
              into o_cash
              from dsc01m00
             where mth_dt = i_date1
               and acnt_no = i_acnt_no
               and sub_no = i_sub_no
               and sb_tp = '2' ;
         end if;
         return o_cash;
    end if;

    return o_cash;

end fcw_get_cash;
/

