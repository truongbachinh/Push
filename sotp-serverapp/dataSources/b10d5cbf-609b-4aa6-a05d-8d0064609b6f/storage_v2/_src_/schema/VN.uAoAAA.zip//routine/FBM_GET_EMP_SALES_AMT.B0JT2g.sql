create function fbm_get_emp_sales_amt(
    i_ret_tp        number,     -- Phan loai tra cuu: 1: Khung doanh thu tong
    i_emp_no        varchar2,
    i_st_dt         varchar2,
    i_ed_dt         varchar2
)
return number
/*
    select fbm_get_emp_sales_amt(
        '1',            -- i_ret_tp        number,
        'hainv',        -- i_emp_no        varchar2,
        '20190926',     -- i_st_dt         varchar2,
        '20191025'      -- i_ed_dt         varchar2
    ) a
    from dual;
*/
as
    t_etc_rt        number  := 0.5;
    t_ret           number  := 0;

    o_ret           number  := 0;
begin
    with emp_sales_detail as(
        select
            b2.emp_no,

                        -------------------------------------------------
            -- Doanh so Gia tri giao dich
            case
                when b2.biz_cmsn_tp = '1' and b2.biz_cmsn_knd = '1'
                    then b2.trd_amt
                else
                    0
            end self_trd_amt_net,                           -- Doanh so gia tri GD KH tu phat trien

            case
                when b2.biz_cmsn_tp = '1' and b2.biz_cmsn_knd = '2'
                    then b2.trd_amt
                else
                    0
            end comp_trd_amt_net,                           -- Doanh so gia tri GD KH cty giao

            case
                when b2.biz_cmsn_tp = '1' and b2.biz_cmsn_knd = '4'
                    then b2.trd_amt
                else
                    0
            end rms_trd_amt_net,                            -- Doanh so gia tri GD KH cty giao
            -------------------------------------------------
            -- Phi giao dich
            -- KH tu phat trien
            case
                when b2.biz_cmsn_tp = '2' and b2.biz_cmsn_knd = '1'
                    then b2.pur_amt
                else
                    0
            end self_trd_fee_amt_pur,                       -- Doanh so phi thuan KH tu phat trien

            -- KH cty giao
            case
                when b2.biz_cmsn_tp = '2' and b2.biz_cmsn_knd = '2'
                    then b2.pur_amt
                else
                    0
            end comp_trd_fee_amt_pur,                       -- Doanh so phi thuan KH cty giao

            -------------------------------------------------
            -- Doanh so lai margin
            case
                when b2.biz_cmsn_tp = '3' and b2.biz_cmsn_knd = '1'
                    then b2.admit_amt
                else
                    0
            end self_mrgn_int_amt_admit,                          -- Doanh so margin KH tu phat trien

            case
                when b2.biz_cmsn_tp = '3' and b2.biz_cmsn_knd = '1'
                    then b2.rev_pur_factor
                else
                    0
            end self_mrgn_rev_pur_factor,                   -- Ti le dieu chinh doanh thu thuan KH tu phat trien

            case
                when b2.biz_cmsn_tp = '3' and b2.biz_cmsn_knd = '2'
                    then b2.admit_amt
                else
                    0
            end comp_mrgn_int_amt_admit,                          -- Doanh so margin KH cty giao

            case
                when b2.biz_cmsn_tp = '3' and b2.biz_cmsn_knd = '2'
                    then b2.rev_pur_factor
                else
                    0
            end comp_mrgn_rev_pur_factor,                   -- Ti le dieu chinh doanh thu thuan KH cty giao

            -------------------------------------------------
            -- Doanh so quan ly CTV
            case
                when b2.biz_cmsn_tp in ('2', '3') and b2.biz_cmsn_knd = '4'
                    then b2.pur_amt
            else
                0
            end collab_amt_pur

            /*
            case
                when b2.biz_emp_tp = '3' and b2.biz_cmsn_tp = '2'
                    then b2.pur_amt
                else
                    0
            end tot_trd_amt_ref_collab                      -- Doanh thu thuan cua tat ca khach hang do CTV quan ly
            */

        from bmb20m00 b2
        where b2.std_dt between i_st_dt and i_ed_dt
        and b2.emp_no = i_emp_no
    ),
    emp_sales_sum as(
        select 
            esd.emp_no,

            -- Gia tri giao dich
            sum(esd.self_trd_amt_net)                self_trd_amt_net,
            sum(esd.comp_trd_amt_net)                comp_trd_amt_net,
            sum(esd.rms_trd_amt_net)                 rms_trd_amt_net,

            -- Phi giao dich
            sum(esd.self_trd_fee_amt_pur)            self_trd_fee_amt_pur,
            sum(esd.comp_trd_fee_amt_pur)            comp_trd_fee_amt_pur,
            sum(esd.self_trd_fee_amt_pur
                + esd.comp_trd_fee_amt_pur)          tot_trd_fee_amt_pur,

            -- Lai margin
            sum(esd.self_mrgn_int_amt_admit)         self_mrgn_int_amt_admit,
            max(esd.self_mrgn_rev_pur_factor)        self_mrgn_rev_pur_factor,
            sum(esd.self_mrgn_int_amt_admit
                * esd.self_mrgn_rev_pur_factor)      self_mrgn_int_amt_pur,

            sum(esd.comp_mrgn_int_amt_admit)         comp_mrgn_int_amt_admit,
            max(esd.comp_mrgn_rev_pur_factor)        comp_mrgn_rev_pur_factor,
            sum(esd.comp_mrgn_int_amt_admit
                * esd.comp_mrgn_rev_pur_factor)      comp_mrgn_int_amt_pur,

            sum(esd.self_mrgn_int_amt_admit)
                + sum(esd.comp_mrgn_int_amt_admit)   tot_mrgn_int_amt_admit,
            sum((esd.self_mrgn_int_amt_admit * esd.self_mrgn_rev_pur_factor)
                + (esd.comp_mrgn_int_amt_admit * esd.comp_mrgn_rev_pur_factor)
                )                                   tot_mrgn_int_amt_pur,   -- DS margin thuan

            -- Tong doanh so
            sum(esd.self_trd_fee_amt_pur
                + esd.comp_trd_fee_amt_pur
                + (esd.self_mrgn_int_amt_admit * esd.self_mrgn_rev_pur_factor)
                + (esd.comp_mrgn_int_amt_admit * esd.comp_mrgn_rev_pur_factor)
                )                                   tot_trd_amt_pur,        -- Tong DS thuan, khong bao gom DS CTV

            sum(esd.self_trd_fee_amt_pur
                + esd.comp_trd_fee_amt_pur
                + esd.self_mrgn_int_amt_admit
                + esd.comp_mrgn_int_amt_admit)             tot_trd_amt_net,        -- Tong DS kinh doanh

            -- Doanh so quan ly CTV
            sum(esd.collab_amt_pur)                  collab_amt_pur
            -- sum(esd.tot_trd_amt_ref_collab)          tot_trd_amt_ref_collab
        from
            emp_sales_detail esd
        group by
            esd.emp_no
    )
    select 
        case
            when i_ret_tp = '1' then                                -- tot_trd_amt_limit
                least(
                    (ess.tot_trd_fee_amt_pur
                        + tot_mrgn_int_amt_admit),
                    (ess.tot_trd_fee_amt_pur
                        + tot_mrgn_int_amt_pur) / t_etc_rt
                )
            else
                0
        end ret
    into
        t_ret
    from emp_sales_sum ess
    ;

    o_ret := t_ret;

    return o_ret;

end fbm_get_emp_sales_amt;
/

