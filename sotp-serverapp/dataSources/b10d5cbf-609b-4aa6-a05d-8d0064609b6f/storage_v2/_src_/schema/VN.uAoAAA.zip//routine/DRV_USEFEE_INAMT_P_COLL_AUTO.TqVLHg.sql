create PROCEDURE drv_usefee_inamt_p_coll_auto
(
    is_usefee_pay_dt        in        varchar2
,   i_acnt_no               in        varchar2
,   i_sub_no                in        varchar2
,   i_work_mn               in        varchar2
,   i_work_trm              in        varchar2
,   i_tran_stt              in        varchar2 default 'Y'
)
AS
/*tra lai phai sinh tien gui*/
/*
   \file     drv_usefee_inamt_p_coll_auto.sql
   \brief    ??????????

   \section intro Program Information
        - Program Name              : ??????????
        - Service Name              : N/A
        - Related Client Program- Client Program ID : Client 05101
        - Related Tables            : BMB01M00
        - Dev. Date                 : 2007/11/30
        - Developer                 : ???
        - Business Logic Desc.      : ??????????
        - Latest Modification Date  : 2007-11-30

   \section history Program Modification History
    - 1.0       2007/11/30     ???    ????

   \section hardcoding Hard-Coding List
    - HC-1

   \section info Additional Reference Comments
    - ???? ??
*/

  o_trd_dt                          varchar2(20);
  o_trd_seq_no                      number := 0;

  t_inamt_cnt                       number := 0;
  o_dpo_prerm                       number := 0;
  o_dpo_nowrm                       number := 0;
  o_acnt_place                      varchar2(20);
  o_bnhof_tp                        varchar2(20);
  o_proc_bnhof_tp                   varchar2(20);
  o_fee_amt                         number :=0;
    t_proc_nm                         varchar2(100);
    t_err_txt                         varchar2(200);

    t_err_msg    varchar2(500);


BEGIN

return;
/*vn.pxc_log_write('drv_usefee_inamt_p_coll_auto','is_usefee_pay_dt-'||is_usefee_pay_dt);

vn.pxc_log_write('drv_usefee_inamt_p_coll_auto','i_acnt_no-'||i_acnt_no);
vn.pxc_log_write('drv_usefee_inamt_p_coll_auto','i_work_mn-'||i_work_mn);
vn.pxc_log_write('drv_usefee_inamt_p_coll_auto','i_work_trm-'||i_work_trm);
 if i_tran_stt ='F' then
 begin
            update vn.DRCWDM03
         set CNFM_Y_N  ='N'
                 ,TRANS_STT ='F'
             where usefee_pay_dt  = is_usefee_pay_dt
           and usefee_pay_tp  = '2'
         and acnt_no = i_acnt_no
         and sub_no  = i_sub_no ;
        exception
              when    others  then
               t_err_txt  :=  t_proc_nm
                      ||  '?????? ????????-err:'
                      ||  sqlerrm;
           t_err_msg := vn.fxc_get_err_msg('V','9006');
           raise_application_error(-20100,t_err_msg||t_err_txt);
        end;
 else
  for c1 in (

    select
      acnt_no,
      sub_no ,
      USEFEE_COLL ,
      ACNT_MNG_BNH,
      USEFEE_FEE
    from vn.DRCWDM03
    where usefee_pay_dt  = is_usefee_pay_dt
    and usefee_pay_tp  = '2'
    and acnt_no         = decode(i_acnt_no,'9999999999',acnt_no,i_acnt_no)
    and sub_no          = decode(i_sub_no, '99', sub_no, i_sub_no)
    and rcpt_trd_no = 0
    and cncl_trd_no = 0
   \* and vn.fdr_acnt_bank_auto_y_n(acnt_no,sub_no) ='N'*\
    and USEFEE_COLL > 0
    and CNFM_Y_N = 'N'
    and AUTO_PAY_Y_N ='Y'
    and TRANS_STT in('T')
    order by acnt_no , sub_no
  )
  loop

     vn.pxc_log_write('drv_usefee_inamt_p_coll_auto','start acnt_no-'||c1.acnt_no || ',' || c1.sub_no );

      begin
      vn.drv_pcw_cash_inamt_15711_p
      (
          vn.vhdate
      ,   c1.acnt_no
      ,   c1.sub_no
      ,   'C21'      -- ?????? ????
      ,   c1.USEFEE_COLL
      ,   '00'
      ,   '15708'
      ,   'Y'
      ,   c1.ACNT_MNG_BNH
      ,   ' '
      ,   ' '
      ,   'N'
      ,   i_work_mn
      ,   i_work_trm
      ,   ' '
      ,   o_trd_dt
      ,   o_trd_seq_no

      ,   o_dpo_prerm
      ,   o_dpo_nowrm
      ,   o_acnt_place
      ,   o_bnhof_tp
      ,   o_proc_bnhof_tp
      );
      exception
          when  others         then
              t_err_txt  :=  t_proc_nm
                     ||  '?????? ??????????-err:'
                     ||  sqlerrm;
        t_err_msg := vn.fxc_get_err_msg('V','2711');
        raise_application_error(-20100,t_err_msg||t_err_txt);
      END;
      --if c1.USEFEE_FEE >0  then
      begin
      vn.drv_pcw_cash_inamt_15712_p
      (
          vn.vhdate
      ,   c1.acnt_no
      ,   c1.sub_no
      ,   'F19'      -- ?????? ????
      ,   c1.USEFEE_FEE
      ,   '00'
      ,   '15708'
      ,   'Y'
      ,   c1.ACNT_MNG_BNH
      ,   ' '
      ,   ' '
      ,   'N'
      ,   i_work_mn
      ,   i_work_trm
      ,   ' '
      ,   o_trd_dt
      ,   o_trd_seq_no

      ,   o_dpo_prerm
      ,   o_dpo_nowrm
      ,   o_acnt_place
      ,   o_bnhof_tp
      ,   o_proc_bnhof_tp
      );
      exception
          when  others         then
              t_err_txt  :=  t_proc_nm
                     ||  '?????? ??????????-err:'
                     ||  sqlerrm;
        t_err_msg := vn.fxc_get_err_msg('V','2711');
        raise_application_error(-20100,t_err_msg||t_err_txt);
      END;
--end if;
vn.pxc_log_write('drv_usefee_inamt_p_coll_auto','inamt ok-'||c1.acnt_no);

        begin
            update vn.DRCWDM03
         set rcpt_trd_no  = o_trd_seq_no
                 ,CNFM_Y_N  ='Y'
                 ,TRANS_STT ='Y'
             where usefee_pay_dt  = is_usefee_pay_dt
           and usefee_pay_tp  = '2'
         and rcpt_trd_no = 0
         and cncl_trd_no = 0
         and acnt_no = c1.acnt_no
         and sub_no  = c1.sub_no ;
        exception
              when    others  then
               t_err_txt  :=  t_proc_nm
                      ||  '?????? ????????-err:'
                      ||  sqlerrm;
           t_err_msg := vn.fxc_get_err_msg('V','9006');
           raise_application_error(-20100,t_err_msg||t_err_txt);
        end;

vn.pxc_log_write('drv_usefee_inamt_p_coll_auto','trd_seq ok-'||c1.acnt_no);


  end loop;
end if;*/
end  drv_usefee_inamt_p_coll_auto;
/

