create procedure psr_rgt_std_p_acnt
 (i_sec_cd     in       varchar2,
  i_proc_tp    in       varchar2,
  i_rgt_std_dt in       varchar2,
  i_stk_cd     in       varchar2,
  i_rgt_tp     in       varchar2,
  i_seq_no     in       number,
  i_acnt_no    in       varchar2,
  i_sub_no     in       varchar2,
  i_rgt_std_qty    in   number,
  i_cons_sbst_qty  in   number,
  i_work_mn    in       varchar2,
  i_work_trm   in       varchar2
 ) is

  vn_std_rt         number := 0;
  vn_std_rt2        number := 0;
  vn_rgt_iss_pri    number := 0;
  vn_own_qty        number := 0;
  vn_proc_seq		number := 0;

begin

 --o_proc_cnt := 0;

 if i_proc_tp = 'I' then

     vn.pxc_log_write('psr_rgt_std_p', i_acnt_no||'-'||i_sub_no||'-'||i_rgt_std_dt||'-'||i_stk_cd||'-'||i_rgt_tp);

	Begin
		SELECT  nvl(max(proc_seq),0) + 1
		into vn_proc_seq
		FROM 	vn.srr02m10
		Where	proc_dt = vn.vwdate;
	Exception
		when others then
			vn_proc_seq := 0;
	End;

     if i_rgt_tp = '8' Then --Quyen chuyen doi co phieu/trai phiei -> co phieu khac
       select nvl(std_pay_rt,1) std_rt ,
              nvl(std_rt,1)     std_rt2
         Into vn_std_rt,
              vn_std_rt2
         from vn.srr01m10
        where rgt_std_dt = i_rgt_std_dt
          and stk_cd     = i_stk_cd;
          --and rgt_proc_stat in ('2','3');

     else
       select nvl(std_rt,1)     std_rt,
              nvl(std_pay_rt,1) std_rt2,
              rgt_iss_pri
       Into   vn_std_rt,
              vn_std_rt2,
              vn_rgt_iss_pri
       from   vn.srr01m00
       where  rgt_std_dt    =  i_rgt_std_dt
       and    stk_cd        =  i_stk_cd
       and    rgt_tp        =  i_rgt_tp
       and    seq_no        =  i_seq_no;
       --and    rgt_proc_stat in ('2','3');
     end if;

	  if vn_std_rt = 0 then
       vn_std_rt := 1;
	  end if;


    vn_own_qty :=  trunc(i_rgt_std_qty * (vn_std_rt2 / vn_std_rt));

	vn.pxc_log_write('psr_rgt_std_p', vn_own_qty);

	Update 	vn.srr02m00
	Set		own_stk_qty = own_stk_qty + vn_own_qty,
			own_qty		= own_qty + vn_own_qty,
			cons_sbst_qty = cons_sbst_qty + i_cons_sbst_qty,
			cons_sbst_amt = cons_sbst_amt + i_cons_sbst_qty*vn_rgt_iss_pri,
			trans_tp	= '1',
			work_mn		= i_work_mn,
			work_dtm	= sysdate,
			work_trm	= i_work_trm
	Where	rgt_std_dt	= i_rgt_std_dt
	and		stk_cd		= i_stk_cd
	and 	rgt_tp		= i_rgt_tp
	and		seq_no		= i_seq_no
	and		acnt_no		= i_acnt_no
	and		sub_no		= i_sub_no;

	if sql%rowcount = 0 then
		insert into  vn.srr02m00
                 ( rgt_std_dt    ,
                   acnt_no       ,
                   sub_no       ,
                   stk_cd        ,
                   rgt_tp        ,
                   seq_no        ,
                   acnt_mng_bnh  ,
                   own_stk_qty	 ,
                   own_qty       ,
                   asn_qty       ,
                   asn_amt       ,
                   flotq_amt     ,
                   mrtg_lnd_qty  ,
                   mrtg_asn_qty  ,
                   inq_trd_no    ,
                   rcpt_trd_no   ,
                   outq_trd_no   ,
                   outamt_trd_no ,
                   flotq_trd_no  ,
                   inter_trd_no	 ,
                   cons_sbst_qty ,
                   cons_sbst_amt ,
                   work_mn       ,
                   work_dtm      ,
                   work_trm      ,
                   trans_tp)
        values
              (i_rgt_std_dt       ,
               i_acnt_no     ,
               i_sub_no     ,
               i_stk_cd      ,
               i_rgt_tp      ,
               i_seq_no      ,
               faa_acnt_bnh_cd_g('0',i_acnt_no,i_sub_no),
               vn_own_qty     ,
               vn_own_qty     ,
               0     ,
               0      ,
               0    ,
               0,
               0              ,
               0              ,
               0              ,
               0              ,
               0              ,
               0              ,
               0              ,
               i_cons_sbst_qty,
               i_cons_sbst_qty*vn_rgt_iss_pri,
               i_work_mn      ,
               sysdate        ,
               i_work_trm     ,
               '1' --Nhap quyen
             ) ;
	end if;

	insert into vn.srr02m10
				(   acnt_no
					,sub_no
					,rgt_std_dt
					,rgt_tp
					,stk_cd
					,seq_no
					,rgt_own_qty
					,cons_sbst_qty
					,trans_tp
					,proc_dt
					,proc_tp
					,proc_seq
					,work_mn
					,work_dtm
					,work_trm
				)
	values		(   i_acnt_no
					,i_sub_no
					,i_rgt_std_dt
					,i_rgt_tp
					,i_stk_cd
					,i_seq_no
					,i_rgt_std_qty
					,i_cons_sbst_qty
					,'10'
					,vn.vwdate
					,'Y'
					,vn_proc_seq
					,i_work_mn
					,sysdate
					,i_work_trm
				);

 else /*D: huy*/

     vn.pxc_log_write('psr_rgt_std_p', i_acnt_no||'-'||i_sub_no||'-'||i_rgt_std_dt||'-'||i_stk_cd||'-'||i_rgt_tp);

     if i_rgt_tp = '8' Then --Quyen chuyen doi co phieu/trai phiei -> co phieu khac
       select nvl(std_pay_rt,1) std_rt ,
              nvl(std_rt,1)     std_rt2
         Into vn_std_rt,
              vn_std_rt2
         from vn.srr01m10
        where rgt_std_dt = i_rgt_std_dt
          and stk_cd     = i_stk_cd;

     else
       select nvl(std_rt,1)     std_rt,
              nvl(std_pay_rt,1) std_rt2,
              rgt_iss_pri
       Into   vn_std_rt,
              vn_std_rt2,
              vn_rgt_iss_pri
       from   vn.srr01m00
       where  rgt_std_dt    =  i_rgt_std_dt
       and    stk_cd        =  i_stk_cd
       and    rgt_tp        =  i_rgt_tp
       and    seq_no        =  i_seq_no;
     end if;

	if vn_std_rt = 0 then
		vn_std_rt := 1;
	end if;


    vn_own_qty :=  trunc(i_rgt_std_qty * (vn_std_rt2 / vn_std_rt));

	vn.pxc_log_write('psr_rgt_std_p', vn_own_qty);

	Update 	vn.srr02m00
	Set		own_stk_qty = own_stk_qty - vn_own_qty,
			own_qty		= own_qty - vn_own_qty,
			cons_sbst_qty = cons_sbst_qty - i_cons_sbst_qty,
			cons_sbst_amt = cons_sbst_amt - (i_cons_sbst_qty*vn_rgt_iss_pri),
			trans_tp	= '0',
			work_mn		= i_work_mn,
			work_dtm	= sysdate,
			work_trm	= i_work_trm
	Where	rgt_std_dt	= i_rgt_std_dt
	and		stk_cd		= i_stk_cd
	and 	rgt_tp		= i_rgt_tp
	and		seq_no		= i_seq_no
	and		acnt_no		= i_acnt_no
	and		sub_no		= i_sub_no;
 end if;
end  psr_rgt_std_p_acnt;
/

