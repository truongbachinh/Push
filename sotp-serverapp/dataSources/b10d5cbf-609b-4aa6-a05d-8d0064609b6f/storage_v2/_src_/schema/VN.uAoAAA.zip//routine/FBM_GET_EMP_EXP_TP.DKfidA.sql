create function fbm_get_emp_exp_tp(
    i_dt                varchar2,   -- Ngay tra cuu
    i_emp_no            varchar2    -- Ma nhan vien
)
return varchar2

/*
    select vn.fbm_get_emp_exp_tp(
        vwdate,         -- i_dt                varchar2,   -- Ngay tra cuu
        'lthpt01'       -- i_emp_no            varchar2    -- Ma nhan vien
    ) a
    from dual;
*/

as
    t_emp_working_mon       number      := 0;
    t_min_emp_exp_mon       number      := 0;

    t_proc_nm       varchar2(30)    := 'fbm_get_emp_exp_tp';
    t_vwdate        varchar2(8)     := vwdate;
    t_err_msg       varchar2(500)   := ' ';

    t_emp_exp_tp    varchar2(1)      := '1';        -- 0: All   1: Nhan vien moi    2: Nhan vien lau nam
    o_ret           varchar2(1)      := '1';

begin
    -- Tinh so thang lam viec cua nhan vien
    begin
        select 
            months_between(to_date(i_dt, 'YYYYMMDD'), regi_dtm) emp_working_mon
        into
            t_emp_working_mon
        from vn.xca01m00
        where id = i_emp_no
        and emp_cust_tp <> '1'
        ;
    exception
        when no_data_found then
            t_emp_working_mon := 0;
        when others then
            t_err_msg  := 'Error when getting data from xca01m00:' 
                            || ' i_dt: '        || i_dt
                            || ' i_emp_no: '    || i_emp_no
                            || '. '
                            || sqlcode || ' - ' || sqlerrm;
            vn.pxc_log_write(t_proc_nm, t_err_msg);
            raise_application_error(-20100,t_err_msg);

    end;

    -- Lay tham so he thong: so thang lam viec toi thieu cua nhan vien lau nam
    select to_number(vn.fxc_col_cd_tp('min_emp_exp_mon')) min_emp_exp_mon
    into t_min_emp_exp_mon
    from dual;

    -- So sanh so thang lam viec
    if(t_emp_working_mon > t_min_emp_exp_mon) then
        t_emp_exp_tp := '2';
    else
        t_emp_exp_tp := '1';
    end if;

    o_ret  := t_emp_exp_tp;

    return o_ret;
end fbm_get_emp_exp_tp;
/

