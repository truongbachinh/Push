create function faa_get_sec_bank_acnt
(
  i_bank_cd    in    varchar2
) return varchar2 as

  o_sec_bank_acnt  varchar2(30);


begin

  begin
  select  nvl(BANK_SCRT_ACNT_NO,'!')
  into  o_sec_bank_acnt
  from  vn.cww01h01
  where  bank_cd   =  i_bank_cd 
  and 
  (vn.vhdate between to_char(MNG_STRT_DT,'yyyymmdd')  and  to_char(MNG_END_DT,'yyyymmdd'))
  and rownum = 1 ;

    return o_sec_bank_acnt;

  exception
  when   no_data_found then
    return   '!';
  end;


end ;
/

