create function fbm_get_cnfm_dt(
    i_proc_dt   varchar2
)
return varchar2

as
    t_proc_nm                   varchar2(30)    := 'fbm_get_cnfm_dt';
    t_vwdate                    varchar2(8)     := vn.vwdate;
    t_err_msg                   varchar2(500)   := ' ';


    t_cnfm_dt                   varchar2(8)     := Null;
    t_ord_cnfm_dt               varchar2(8)     := Null;
    t_next_cls_dt               varchar2(8)     := Null;
    t_cnfmm_dt_ins              varchar2(8)     := Null;

    t_ord_cnfmm_tp              varchar2(1)     := Null;

    o_ret                       varchar2(8)    := vn.vwdate;
begin

    --So ngay xac nhan lenh X.
    Begin
        select col_cd_tp
        into t_ord_cnfm_dt
        from xcc01c02
        where col_cd = 'ord_confirm';
        exception
            when others then
                t_err_msg := 'select t_ord_cnfm_dt error.';
                raise_application_error(-20100,t_err_msg);
                vn.pxc_log_write(t_proc_nm, t_err_msg);
    end;

    ---t_ord_cnfmm_tp: '1': Tu ngay dat lenh   '2': Tu ngay cuoi cung cua ky tinh hoa hong  '3': User nhap tay
    Begin
        select col_cd_tp
        into t_ord_cnfmm_tp
        from xcc01c02
        where col_cd = 'ord_cnfmm_tp';
        exception
            when others then
                t_err_msg := 'select t_ord_cnfmm_tp error.';
                raise_application_error(-20100,t_err_msg);
                vn.pxc_log_write(t_proc_nm, t_err_msg);
    end;

    --Ngay user nhap khi dung option 3
    If t_ord_cnfmm_tp = '3' then
        Begin
            select col_cd_tp
            into t_cnfmm_dt_ins
            from xcc01c02
            where col_cd = 'cnfmm_dt_ins';
            exception
                when others then
                t_err_msg := 'select t_cnfmm_dt_ins error.';
                raise_application_error(-20100,t_err_msg);
                vn.pxc_log_write(t_proc_nm, t_err_msg);
        end;
    elsif t_ord_cnfmm_tp = '2' then --Lay ra ngay cuoi cung cua ky tinh hoa hong
        Begin
            select vn.fbm_get_sales_cls_dt('2', i_proc_dt)
            into t_next_cls_dt
            from dual;
            exception
                when others then
                t_err_msg := 'select t_next_cls_dt error.';
                raise_application_error(-20100,t_err_msg);
                vn.pxc_log_write(t_proc_nm, t_err_msg);
        end;
    end if;

    if t_ord_cnfmm_tp = '1' then
        t_cnfm_dt := vn.fxc_vorderdt_g(to_date(t_vwdate, 'yyyymmdd'), - t_ord_cnfm_dt);
    elsif t_ord_cnfmm_tp = '2' then
        t_cnfm_dt := vn.fxc_vorderdt_g(to_date(t_next_cls_dt, 'yyyymmdd'), + t_ord_cnfm_dt);
    elsif t_ord_cnfmm_tp = '3' then
        t_cnfm_dt := vn.fxc_vorderdt_g(to_date(t_cnfmm_dt_ins, 'yyyymmdd'), + t_ord_cnfm_dt);
    end if;

    o_ret := t_cnfm_dt;
    return o_ret;

end fbm_get_cnfm_dt;
/

