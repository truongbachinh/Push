create procedure pxc_sms_fee_out
( i_sec_cd     		in   varchar2,
  i_acnt_no    		in   varchar2,
  i_sms_grp_cd     	in   varchar2,
  i_mobile         	in varchar2,
  i_status         	in varchar2,
  i_work_mn    		in   varchar2,
  i_work_trm   		in   varchar2,
  o_err_msg       	out  varchar2 -- 1: cat duoc tien, 2 khong
) is

K_RMRK_CD                VARCHAR2(3) := '901'; --phi tin nhan
t_acnt_no                varchar2(10);
t_sub_no                 varchar2(2);
t_avail_depo_fee         number :=0; -- so tien co the cat

t_trd_dt                varchar2(20) := ' ';
t_trd_seq_no            number := 0;
t_dpo             		number := 0;
t_dpo_prerm             number := 0;
t_dpo_nowrm             number := 0;
t_acnt_place            varchar2(10) := ' ';
t_bnhof_tp              varchar2(10) := ' ';
t_proc_bnhof_tp         varchar2(10) := ' ';
t_dpo_fee_sms           number := 0;
t_date              	varchar2(8);
t_month              	varchar2(6);
t_month_last            varchar2(6);
t_block_dt              varchar2(8);

t_count_sms             number :=0;
t_row_dt              	varchar2(100);
t_row_count             number :=0;
t_usefee                number :=0;
t_fee_block             number :=0;
t_fee_grp              	number :=0;


begin

		  select 
				  to_char(add_months(to_date(vn.vwdate,'yyyymmdd'), -1),'mm'), ---thang truoc
				  to_char(add_months(to_date(vn.vwdate,'yyyymmdd'), -1),'mmyyyy')---thang truoc insert vao xca01m10
			  into t_month_last,
				   t_month
			  from dual;

		begin

			  /*với khách hàng bình thường, status=0 thu 8800
			  với khách hàng nợ 1 tháng, status=1 thu phi thang hien tai +phi block
			  với khách hàng nợ 2 tháng status =2 phi thang hien tai + phi block (khong nhan duoc sms nen khong tinh phi thang hien tai)
			  */
			  -- tam dong khi thu thang cu
			--select decode(a.status,'2','0',b.sms_grp_fee) + a.fee_block
			 select b.sms_grp_fee + a.fee_block
				   ,b.sms_grp_fee
				  ,nvl(a.block_dtm,'')
				  ,nvl(vn.fxc_count_total_sms(i_acnt_no,i_sms_grp_cd,t_month),'0')--dem so luong SMS phat sinh thang truoc
				  ,nvl(vn.fxc_row_sms(i_acnt_no),t_month_last)--kiem tra cac thang con no
				  ,nvl(a.fee_block,'0')
			  into t_usefee,
				   t_fee_grp,
				   t_block_dt,
				   t_count_sms,
				   t_row_dt,
				   t_fee_block
			  from vn.xca01m07 a,
				   vn.xca01m09 b
			  where a.acnt_no like i_acnt_no
			  and   a.sms_grp_cd NOT IN ('00','01')
			  and   a.sms_grp_cd = b.sms_grp_no
			  and   a.sms_grp_cd = i_sms_grp_cd
			  and   a.sms_grp_fee > '0';

			  exception
				   when others then
				   Pxc_Log_Write ('pxc_sms_fee_out_1',
								   'Khong co thong tin tai khoan no tien :'
								|| '...ACNT_NO:'
								|| i_acnt_no);
					o_err_msg := '2';
					return;
        end;
   /*Neu co phat sinh sms thi moi tien hanh thu tien*/
   if t_count_sms > 0 then    /*Huedt add  1*/
		begin

						for c1 in (
						 select acnt_no
								,sub_no
								,dpo
						from vn.cwd01m00 t
						where acnt_no = i_acnt_no
					   -- order by acnt_no||sub_no
									) loop

			begin -- Kiem tra so tien co the rut cua KH
				  select vn.fcw_avail_cash_depo_fee(i_sec_cd,c1.acnt_no,c1.sub_no)
						 into t_avail_depo_fee
						 from dual;
			exception
			   when others then
				vn.pxc_log_write('pxc_sms_fee_out', ' fcw_avail_cash_depo_fee ['||sqlcode||']');
				t_trd_seq_no := 0;
			end;
				 vn.pxc_log_write('pxc_sms_fee_out','  Tien Hanh: '||c1.acnt_no||'  sub: '
													   ||c1.sub_no||'  status: '||i_status||'  fee: '||t_usefee ||'   balance:  '
													   ||t_avail_depo_fee
													   ||' count sms '
													   ||t_count_sms);
  --  t_avail_depo_fee := vn.fcw_avail_cash_depo_fee(i_sec_cd,c1.acnt_no,c1.sub_no);

    if (t_avail_depo_fee >= t_usefee and t_usefee > 0) then
       /*Cat tien sub dang chay o cursor C1*/
        begin
        vn.pcw_cash_outamt_p(
             to_char(sysdate,'yyyymmdd'),
             c1.acnt_no,
             c1.sub_no,
             K_RMRK_CD,
             t_usefee,
             '01',
             --'Phí tin nhắn'|| ' ' || substr(t_date,5,2) || '/' || substr(t_date,1,4)||' cua sub '||c1.sub_no,
             'Phí tin nhắn tháng'|| ' ' || trim(t_row_dt) || ' cua sub '||c1.sub_no,
             'Y',
             '900',
             i_work_mn,
             i_work_trm,
             t_trd_dt ,
             t_trd_seq_no,
             t_dpo_prerm ,
             t_dpo_nowrm,
             t_acnt_place,
             t_bnhof_tp,
             t_proc_bnhof_tp
            );
        exception
           when others then
            vn.pxc_log_write('pxc_sms_fee_out', ' pcw_cash_outamt_p ['||sqlcode||']');
            rollback;
            t_trd_seq_no := 0;
        end;

       end if;
				if  t_trd_seq_no > '0'  then
				Pxc_Log_Write ('pxc_sms_fee_out',
								   'TK thu phi thanh cong :'
								|| '...ACNT_NO:'
								|| i_acnt_no
								||'  sub: '||c1.sub_no);
				exit;
			  end if;
			end loop; -- Vong lap 1
     /* Neu cat duoc tien thì update trang thái giam lai 1, thu duocj thì các tr?ng thái 1,2,3 chuy?n qua 'N':không n?*/
			if (t_trd_seq_no > 0) then
					 o_err_msg := '1';
					 select acnt_no,
							sub_no
					 into t_acnt_no,
						  t_sub_no
					  from vn.aaa10m00
					  where   acnt_no  =    i_acnt_no
					  and     rmrk_cd = '901'
					  and     trd_dt = t_trd_dt
					  and     rownum = '1';

					 select dpo_fee_sms,
							dpo
							 into t_dpo_fee_sms,
								  t_dpo
							 from vn.cwd01m00
							 where   acnt_no  =    i_acnt_no
							 and     sub_no  =    t_sub_no;
					  /* Update xca01m07 */
					  update  vn.xca01m07
					  set  fee_yn = 'Y'
						   ,fee_obtained = t_usefee
						   ,fee_block    = '0'
						  ,status = '0'
						  ,block_dtm = null
						  ,work_mn = i_work_mn
						  ,work_trm = i_work_trm
						  ,work_dtm = sysdate
						  ,regi_sms_yn = 'Y'
					  where
						   acnt_no        = i_acnt_no
						   and sms_grp_cd = i_sms_grp_cd;
					 ---update lai bang lock tien
						update vn.cwd01m00
						set    dpo_fee_sms = '0'
						where   acnt_no =    i_acnt_no
						and     sub_no  = '00';

        --insert vao bang lich su xca01m10
        begin
         insert into vn.xca01m10(trd_dt,
                                 acnt_no,
                                 sub_no,
                                 sms_grp_cd,
                                 fee_yn,
                                 dpo,
                                 fee_obtained,
                                 obtained_dtm,
                                 fee_block,
                                 block_dtm,
                                 total_block,
                                 work_mn,
                                 work_dtm,
                                 work_trm)
                         values(t_month,
                                 i_acnt_no,
                                 t_sub_no,
                                 i_sms_grp_cd,
                                 'Y',
                                 t_dpo,
                                -- decode(t_fee_block,'0',t_fee_grp,'0'),
                                 t_fee_grp,
                                 to_char(sysdate,'yyyymmdd'),
                                 '0',
                                 null,
                                 '0',
                                 i_work_mn,
                                 sysdate,
                                 i_work_trm);
        exception
           when others then
            vn.pxc_log_write('pxc_sms_fee_out', ' xca01m10 ['||sqlcode||']');
        end;
      /* Update het no vao xca01m10 */
        update  vn.xca01m10
        set  fee_yn = 'Y'
           ,fee_obtained = fee_block
           ,obtained_dtm = to_char(sysdate,'yyyymmdd')
           ,fee_block    = '0'
           ,total_block = '0'
          ,block_dtm = null
        where
           acnt_no        = i_acnt_no
       -- and  sms_grp_cd = i_sms_grp_cd
        and  trd_dt <> t_month
        and fee_yn = 'N';
      /*Gui SMS cho KH neu thu phi thanh cong*/
      /*huedt add k gui tn */
        /* begin
       vn.pxc_sms_ins(
                 i_sec_cd,
                  to_char (sysdate, 'YYYYMMDD'),
                  i_mobile,
                  '84438181888' ,
                  '007',
                  '744',
                  t_acnt_no||t_sub_no||LPAD(t_row_dt,50, ' ')||LPAD(t_usefee,15, ' ')||LPAD(t_dpo,18, ' '),
                   i_work_mn ,
                   i_work_trm );
           exception
           when others then
            vn.pxc_log_write('pxc_sms_fee_out', ' pxc_sms_ins ['||sqlcode||']');
            t_trd_seq_no := 0;
        end;
       Pxc_Log_Write ('pxc_sms_fee_out',
                           'TK hoan tat gui SMS cho KH :'
                        || '...ACNT_NO:'
                        || i_acnt_no
                        || ' sub: ' ||t_sub_no);*/
          /*huedt add k gui tn */
      --Khong du tien de cat
        else
          ---kiem tra neu da block 2 thang thi khong ghi them tien block
           select count(*)
           into t_row_count
           from vn.xca01m10
           where acnt_no = i_acnt_no
           and sms_grp_cd = i_sms_grp_cd;
      if t_row_count < 3 then 
          --tu dong không cat tien duoc thì update trang thái + thêm 1
          update  vn.xca01m07
          set  fee_yn = 'N'
            ,fee_obtained = '0'
            ,status = decode(i_status, '0', '1', '1', '2', i_status)
            ,fee_block = t_usefee
            ,block_dtm = decode(i_status,'0',to_char(sysdate,'yyyymmdd'),t_block_dt)
            ,work_mn = i_work_mn
            ,work_trm = i_work_trm
            ,work_dtm = sysdate
          where
             acnt_no        = i_acnt_no
             and sms_grp_cd = i_sms_grp_cd;

               ----block tien cwd01m00
               update vn.cwd01m00
               set    dpo_fee_sms = t_usefee
                  ,work_mn = i_work_mn
                  ,work_trm = i_work_trm
                  ,work_dtm = sysdate
               where   acnt_no =    i_acnt_no
               and     sub_no  =    '00';

          --insert vao bang lich su xca01m10
        begin
         insert into vn.xca01m10(trd_dt,
                                 acnt_no,
                                 sub_no,
                                 sms_grp_cd,
                                 fee_yn,
                                 dpo,
                                 fee_obtained,
                                 obtained_dtm,
                                 fee_block,
                                 block_dtm,
                                 total_block,
                                 work_mn,
                                 work_dtm,
                                 work_trm)
                          values(t_month,
                                 i_acnt_no,
                                 '00',
                                 i_sms_grp_cd,
                                 'N',
                                 t_dpo,
                                 '0',
                                 null,
                                 --decode(t_row_count,'2','0',t_fee_grp),
                                 t_fee_grp,
                                 to_char(sysdate,'yyyymmdd'),
                                 t_usefee,
                                 i_work_mn,
                                 sysdate,
                                 i_work_trm);
        exception
           when others then
            vn.pxc_log_write('pxc_sms_fee_out', ' xca01m10 ['||sqlcode||']');
            rollback;
        end;
              ----update lai tong no trong xca01m10
                   update vn.xca01m10
                   set    total_block = t_usefee
                          ,work_mn = i_work_mn
                          ,work_trm = i_work_trm
                          ,work_dtm = sysdate
                   where   acnt_no =    i_acnt_no;
           o_err_msg := '2';
        Pxc_Log_Write ('pxc_sms_fee_out',
                           'TK khong thu duoc tien :'
                        || '...ACNT_NO:'
                        || i_acnt_no);
            end if;
           end if;

  end;
  -- tam dong khi thu thang cu
  else
    o_err_msg := '2';
    Pxc_Log_Write ('pxc_sms_fee_out',
                           'TK khong co phat sinh sms :'
                        || '...ACNT_NO:'
                        || i_acnt_no);
  end if;
  commit;

end pxc_sms_fee_out;
/

