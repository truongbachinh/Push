create function fdl_get_int_brkt_rt(
    i_acnt_no           in      varchar2, 
    i_sub_no            in      varchar2,
    i_prd_no            in      varchar2,
    i_int_brkt_no       in      varchar2,   -- Khung lai suat
    i_apy_dt            in      varchar2,
    i_rnge_val          in      number
)
return number
/*
    Sample call:
        select vn.fdl_get_int_brkt_rt(
            '039C003000',   -- i_acnt_no           in      varchar2, 
            '01',           -- 'i_sub_no            in      varchar2,
            'SPK11',        -- i_prd_no            in      varchar2,
            'KLS11',        -- i_int_brkt_no       in      varchar2,   -- Khung lai suat
            '20201201',     -- i_apy_dt            in      varchar2,
            3               -- i_rnge_val          in      number
        ) a
        from dual;
*/
as
    t_proc_nm           varchar2(30)    := 'fdl_get_int_brkt_rt';
    t_err_msg           varchar2(500)   := null;

    t_int_brkt_rt       number          := 0;
    t_max_apy_dt        varchar2(8)     := null;
    o_ret               number          := 0;
begin
    vn.pxc_log_write(t_proc_nm, '');
    vn.pxc_log_write(t_proc_nm, 'Start '                    || t_proc_nm        || ' for: '
                                || 'i_acnt_no: '            || i_acnt_no
                                || ', i_sub_no: '           || i_sub_no
                                || ', i_prd_no: '           || i_prd_no
                                || ', i_int_brkt_no: '      || i_int_brkt_no
                                || ', i_apy_dt: '           || i_apy_dt
                                || ', i_rnge_val: '         || i_rnge_val
                    );

    -- Get latest apply date for interest bracket
    begin
        select
            max(apy_dt) max_apy_dt
        into
            t_max_apy_dt
        from vn.dlm31m00
        where int_brkt_no   = i_int_brkt_no
        and apy_dt         <= i_apy_dt
        and expr_dt        >= i_apy_dt
        and active_stat     = 'Y';
    exception
        when others then
            t_err_msg  := 'Error when getting latest apply date for bracket interest'
                                || '. Error: '          || sqlcode || ' - '     || sqlerrm;
            vn.pxc_log_write(t_proc_nm, t_err_msg);
            raise_application_error(-20100,t_err_msg);
    end;

    -- Get interest rate
    begin
        select
            int_rt
        into
            t_int_brkt_rt
        from vn.dlm31m00
        where int_brkt_no   = i_int_brkt_no
        and apy_dt          = t_max_apy_dt
        and active_stat     = 'Y'
        and rnge_min_val   <= i_rnge_val
        and rnge_max_val   >= i_rnge_val
        ;
    exception
        when others then
            t_err_msg  := 'Error when getting bracket interest rate'
                                || '. Error: '          || sqlcode || ' - '     || sqlerrm;
            vn.pxc_log_write(t_proc_nm, t_err_msg);
            raise_application_error(-20100,t_err_msg);
    end;

    o_ret := t_int_brkt_rt;

    vn.pxc_log_write(t_proc_nm, 'End.');

    return o_ret;

end fdl_get_int_brkt_rt;
/

