create function    fdl_get_lnd_rpy_qty
(
	i_stk_cd         in   varchar2,         --
	i_lnd_amt        in   number,
	i_mrtg_lnd_qty   in   number,
	i_mrtg_rpy_qty   in   number,
    i_lnd_rpy_amt    in   number,
	i_lnd_rpy_all    in   number
)
    return  number
as

	t_rpy_qty     number := 0;
	t_stk_mkt_tp       varchar2(01) := null;
    t_err_msg      varchar2(80)  ; -- error text buffer

begin


/*============================================================================*/
/* Return quantity of unblock stock
/*============================================================================*/
    BEGIN
    SELECT
         stk_mkt_tp
      INTO
          t_stk_mkt_tp
      FROM  vn.ssi01m00
     WHERE  stk_cd = i_stk_cd;

    EXCEPTION
    WHEN no_data_found THEN
        return 0;
    WHEN others THEN
        t_err_msg := vn.fxc_get_err_msg('V','2017');
        t_err_msg := t_err_msg||' STK_CD='||i_stk_cd;
        raise_application_error(-20100,t_err_msg);

    END;


	t_rpy_qty      := 0;
	/* Reference : pdl_coll_loan_rpy */
	IF  t_stk_mkt_tp  =  '1'  THEN
        t_rpy_qty   :=  round(nvl(i_lnd_rpy_amt,0)/nvl(i_lnd_amt,0)*i_mrtg_lnd_qty,-1);
    ELSE
        t_rpy_qty   :=  round(nvl(i_lnd_rpy_amt,0)/nvl(i_lnd_amt,0)*i_mrtg_lnd_qty,-2);

    END IF;

	IF i_mrtg_lnd_qty <  i_mrtg_rpy_qty + t_rpy_qty THEN
   		t_rpy_qty := greatest(i_mrtg_lnd_qty - i_mrtg_rpy_qty,0);
	END IF;
	return t_rpy_qty;
end fdl_get_lnd_rpy_qty;
/

