create function fbm_brch_cd_nm_q
(
    i_brch_cd   in   varchar2        -- 지점번호
,	i_agnc_brch in   varchar2        -- 출장소구분
)
    return          varchar2
as
/*
   \file     fbm_brch_cd_nm_q.sql
   \brief    지점명조회

   \section intro Program Information
        - Program Name              : 지점명조회
        - Service Name              : N/A
        - Related Client Program- Client Program ID : Client 05503
        - Related Tables            : xcc90m00
        - Dev. Date                 : 2007/11/30
        - Developer                 : 김광동
        - Business Logic Desc.      : 지점명조회
        - Latest Modification Date  : 2007-11-30

   \section history Program Modification History
    - 1.0       2007/11/30     김광동    최초개발

   \section hardcoding Hard-Coding List
    - HC-1

   \section info Additional Reference Comments
    - 해당사항 없음
*/
    o_brch_cd_nm		varchar2(100) ;
    t_err_txt       varchar2(100)  ; -- error text buffer

begin

/*============================================================================*/
/* 변수 초기화                                                                */
/*============================================================================*/
    o_brch_cd_nm  :=  NULL;

vn.pxc_log_write('fbm_brch_cd_nm_q','i_brch_cd-'||i_brch_cd);
/*============================================================================*/
/* 사원명 조회                                                                */
/*============================================================================*/
    begin
      	select nvl(brch_cd_nm, '!')
		  into o_brch_cd_nm
          from vn.xcc90m00
         where brch_cd	   = i_brch_cd
		 and   agnc_brch   = i_agnc_brch
		 and   brch_end_dt = '30000101'
		 ;
    exception
        when  NO_DATA_FOUND  then
			return  '!';
        when  OTHERS         then
            t_err_txt  :=  '오류-['||to_char(sqlcode)||']';
            raise_application_error (-20100, t_err_txt);
    end;

    return  o_brch_cd_nm;

end fbm_brch_cd_nm_q;
/

