create FUNCTION FAA_GET_VALID_ACC_NO(T_REF_NO IN VARCHAR2,
                                                T_FROM   IN VARCHAR2, /*vtb or vsd*/
                                                T_LINK   IN VARCHAR2) /*master or history*/
 RETURN VARCHAR2 IS
  V_STR VARCHAR2(20);
  V_MSG VARCHAR2(2000);
  V_LEN NUMBER;
  V_CNT NUMBER;
BEGIN
  begin
    V_STR := '%';
    SELECT nvl(IN_DATA, ' ')
      INTO V_MSG
      FROM VN.XIB01M00
     WHERE nvl(OUT_DATA, ' ') like '%' || T_REF_NO || '%'
       AND T_FROM = 'vtb'
       AND T_LINK = 'm';
  exception
    when no_data_found then
      begin
        SELECT nvl(IN_DATA, ' ')
          INTO V_MSG
          FROM VN.XIB01H00
         WHERE nvl(OUT_DATA, ' ') like '%' || T_REF_NO || '%'
           AND T_FROM = 'vtb'
           AND T_LINK = 'h';
      exception
        when no_data_found then
          RETURN V_STR;
      end;
  end;

  V_MSG := LTRIM(RTRIM(V_MSG));
  V_LEN := LENGTH(V_MSG) - 10;
  IF V_MSG IS NULL THEN
    RETURN V_STR;
  END IF;
  pxc_log_write('faa_get_valid_acc_no',V_MSG);
  FOR i IN 1 .. V_LEN LOOP
    V_STR := SUBSTR(V_MSG, i, 10);
    pxc_log_write('faa_get_valid_acc_no',i || ' '|| V_STR);
    SELECT count(*)
      INTO V_CNT
      FROM VN.AAA01M00
     WHERE ACNT_NO = V_STR;

    IF V_CNT > 0 THEN
      RETURN V_STR;
    END IF;
  END LOOP;
  RETURN V_STR;
END;
/

