create function fbm_get_sub_emp_hier(
    i_emp_no        varchar2,
    i_mng_emp_no    varchar2,
    i_dt            varchar2
)
return sys_refcursor
    /* 
        select vn.fbm_get_sub_emp_hier(
            'tyhpt01',      -- i_emp_no        varchar2(15),
            '%',            -- i_mng_emp_no    varchar2(15),
            vwdate          -- i_dt            varchar2(8)
        ) a
        from dual;
    */
is
    t_cursor        sys_refcursor;
begin
    open t_cursor for
        select *
        from (
            select 
                emp_no,
                rpad('.', (level-1)*2, '.') || emp_no as tree,
                level lvl,
                connect_by_root emp_no as mng_emp_no,
                ltrim(sys_connect_by_path(emp_no, '->'), '->') as path,
                connect_by_isleaf as leaf
            from (select x1.emp_no, x5.mng_emp_no
                  from vn.xca01m01 x1
                  left join vn.rms05m00 x5           -- Ds nhan vien - quan ly
                  on x1.emp_no = x5.emp_no
                  and x5.apy_dt <= i_dt
                  and x5.expr_dt = '30000101')
            START WITH mng_emp_no IS NULL
            connect by nocycle mng_emp_no = prior emp_no
            -- order by emp_no, level
        ) x
        where emp_no like i_emp_no
        and mng_emp_no like i_mng_emp_no
        order by mng_emp_no, lvl
        ;

    return t_cursor;
end;
/

