create FUNCTION    fdl_get_acnt_sum_prd_lnd_limit(i_acnt_no VARCHAR2,
                                                i_sub_no  VARCHAR2,
                                                i_prd_no  VARCHAR2,
                                                i_day_tp  VARCHAR2
                                                )
  RETURN NUMBER AS
  /*!
     \file     fdl_get_acnt_sum_prd_lnd_limit.sql
     \brief    fdl_get_acnt_sum_prd_lnd_limit
     \section intro Program Information
          - Program Name              :
          - Service Name              :
          - Related Client Program- Client Program ID :
          - Related Tables            : dlm51m00, dlm90m00, dlm00m01
          - Dev. Date                 : 2021/07/19
          - Developer                 : TienLH.
          - Business Logic Desc.      : fdl_get_acnt_sum_prd_lnd_limit
          - Latest Modification Date  :
   */
    t_acnt_sum_prd_limit NUMBER      := 0;
    t_acnt_prd_lnd       NUMBER      := 0;
    t_acc_lnd_amt_limit  NUMBER      := 0;
    t_vwdate             VARCHAR2(8) := vn.vwdate;
    -- Neu i_day_tp = '1'- Su dung trong ngay: Co cong them so luong du kien vay (extp) vao so da dung
    -- Neu i_day_tp ='2' - Cuoi ngay: Khong cong them so luong du kien vay (extp) vao so da dung

    --Ham nay nen truyen i_day_tp = '1'- Su dung trong ngay
BEGIN
    t_acnt_sum_prd_limit := 0;
    /*RLL(A) = Sum[Min(RLL(Si,A),RLL(Pi,A)]*/
    FOR c1 IN (SELECT a.acnt_no,
                      a.sub_no,
                      b.grp_acnt_no,
                      b.prd_no,
                      e.lnd_tp -- loai nguon
                FROM vn.dlm51m00 a, --Lien ket Tai khoan - Nhom TK Margin
                      vn.dlm90m00 b, --Cai dat san pham cho nhom TK  Margin
                      vn.dlm00m01 c,  --Danh muc san pham -> lay nguon
                      vn.dlm00m01 e   -- nguon
                WHERE a.acnt_no = i_acnt_no
                    AND a.sub_no = i_sub_no
                    AND a.active_stat = 'Y'
                    AND a.apy_dt = (SELECT MAX(apy_dt) apy_dt
                                    FROM vn.dlm51m00 d
                                    WHERE d.acnt_no = i_acnt_no
                                        AND d.sub_no = i_sub_no
                                        AND d.active_stat = 'Y'
                                        AND d.apy_dt <= t_vwdate)
                    AND a.grp_acnt_no = b.grp_acnt_no
                    AND b.active_stat = 'Y'
                    AND b.apy_dt <= t_vwdate
                    AND b.expr_dt >= t_vwdate
                    AND c.item_tp = '02' -- San pham, tuong ung 1 nguon
                    AND c.item_cd = b.prd_no
                    AND c.active_stat = 'Y'
                    AND c.src_no = e.item_cd
                    AND c.item_cd like trim(i_prd_no)
                    AND e.item_tp = '03' -- nguon
                    AND e.active_stat = 'Y'
                    AND vn.fdl_item_detail_chk (c.item_tp,c.item_cd,t_vwdate) = 'Y'
                    AND exists
                        (select 1
                        FROM vn.dlm71m00
                        WHERE grp_acnt_no =  a.grp_acnt_no
                            AND t_vwdate BETWEEN apy_dt AND expr_dt
                            AND active_stat = 'Y'
                        )
                  --AND c.lnd_tp IN ('70', '80') --- Loai vay chi set o muc Nguon
                ) LOOP
          --(trong ng?y)
            t_acnt_prd_lnd := vn.fdl_get_acnt_lnd_limit(c1.acnt_no,
                                                        c1.sub_no,
                                                        '02',
                                                        c1.prd_no,
                                                        i_day_tp); -- RLL(S);

            t_acnt_sum_prd_limit := t_acnt_sum_prd_limit + t_acnt_prd_lnd;

    END LOOP; --End c1

  RETURN t_acnt_sum_prd_limit;

END fdl_get_acnt_sum_prd_lnd_limit;
/

