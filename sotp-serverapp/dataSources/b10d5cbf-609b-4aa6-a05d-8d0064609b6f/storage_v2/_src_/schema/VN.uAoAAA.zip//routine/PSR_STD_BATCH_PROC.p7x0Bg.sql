create procedure psr_std_batch_proc
(i_dt       in       varchar2,
 i_work_mn   in       varchar2,
 i_work_trm  in       varchar2,
 o_cnt       out      number
 ) is

 o_proc_cnt   number;

begin

 vn.pxc_log_write('psr_std_batch_proc', i_dt);

 o_cnt := 0;

 for  c1  in (

      select   stk_cd,
           rgt_tp,
         seq_no,
         nvl(rgt_proc_stat,'1') rgt_stat
      from     vn.srr01m00
      where    rgt_std_dt    =  i_dt
      and      rgt_proc_stat in ( '1' , '2')

    union all

    select stk_cd ,
        '8' rgt_tp  ,
        0 seq_no  ,
        nvl(rgt_proc_stat,'1') rgt_stat
        from  vn.srr01m10
       where  rgt_std_dt    = i_dt
     and  rgt_proc_stat in  ( '1' , '2')

    ) loop

      o_cnt := o_cnt + 1;
   if c1.rgt_stat = '1' then
     vn.psr_rgt_std_p(
            'I',
            i_dt,
            c1.stk_cd,
            c1.rgt_tp,
            c1.seq_no,
            i_work_mn,
            i_work_trm,
            o_proc_cnt );

      end if ;
         vn.psr_rgt_asn_p(
          'I',
          i_dt,
          c1.stk_cd,
          c1.rgt_tp,
          c1.seq_no,
          i_work_mn,
          i_work_trm,
          o_proc_cnt);


  end loop;
  /*vn.psr_rgt_std_past_proc_non(
                            i_dt    ,
                            '%'    ,
                            i_work_mn   ,
                            i_work_trm
                           );*/
  --Hoai them 20151231: VCSC-1068
   /*vn.psr_rgt_std_past_proc_upd(
                            i_dt    ,
                            '%'    ,
                            i_work_mn   ,
                            i_work_trm
                         );*/--HuongLT comment theo NHSV-1121
 --Huedt add backup quyen chua hach toan srr02h00 (rgt_tp = 1.2.3.5.7.8) /NH782/
  DELETE FROM vn.srr02h00
      WHERE DT = i_dt;

      FOR c1
        IN (SELECT RGT_STD_DT,
        ACNT_NO,
        SUB_NO,
        RGT_TP,
        STK_CD,
        SEQ_NO,
        ACNT_MNG_BNH,
        OWN_STK_QTY,
        OWN_QTY,
        ASN_QTY,
        ANTH_ASN_QTY,
        ASN_AMT,
        FLOTQ_AMT,
        MRTG_ASN_QTY,
        MRTG_LND_QTY,
        nvl(PROC_DT,'!') PROC_DT,
        CONS_SBST_QTY,
        CONS_SBST_AMT,
        INQ_TRD_NO,
        RCPT_TRD_NO,
        OUTQ_TRD_NO,
        OUTAMT_TRD_NO,
        nvl(CONV_YN,'!') CONV_YN,
        FLOTQ_TRD_NO,
        nvl(PAY_YN,'!') PAY_YN,
        nvl(OUTR_PROC_YN,'!') OUTR_PROC_YN,
        INQ_QTY,
        CANCEL_QTY,
        WORK_MN,
        WORK_DTM,
        WORK_TRM,
        INTER_AMT,
        INTER_TRD_NO,
        TAX_ASN,
        TAX_FLOTQ,
        TAX_INT,
        TAX_STOCK,
        TRANS_TP
    FROM VN.SRR02M00
    WHERE INQ_TRD_NO = '0' AND RCPT_TRD_NO = '0' and RGT_TP IN ('1','2','3','5','7','8'))
    LOOP

 INSERT INTO VN.SRR02H00
            (  DT,
                RGT_STD_DT,
        ACNT_NO,
        SUB_NO,
        RGT_TP,
        STK_CD,
        SEQ_NO,
        ACNT_MNG_BNH,
        OWN_STK_QTY,
        OWN_QTY,
        ASN_QTY,
        ANTH_ASN_QTY,
        ASN_AMT,
        FLOTQ_AMT,
        MRTG_ASN_QTY,
        MRTG_LND_QTY,
        PROC_DT,
        CONS_SBST_QTY,
        CONS_SBST_AMT,
        INQ_TRD_NO,
        RCPT_TRD_NO,
        OUTQ_TRD_NO,
        OUTAMT_TRD_NO,
        CONV_YN,
        FLOTQ_TRD_NO,
        PAY_YN,
        OUTR_PROC_YN,
        INQ_QTY,
        CANCEL_QTY,
        WORK_MN,
        WORK_DTM,
        WORK_TRM,
        INTER_AMT,
        INTER_TRD_NO,
        TAX_ASN,
        TAX_FLOTQ,
        TAX_INT,
        TAX_STOCK,
        TRANS_TP
            )
      VALUES (
        i_dt,
        c1.RGT_STD_DT,
        c1.ACNT_NO,
        c1.SUB_NO,
        c1.RGT_TP,
        c1.STK_CD,
        c1.SEQ_NO,
        c1.ACNT_MNG_BNH,
        c1.OWN_STK_QTY,
        c1.OWN_QTY,
        c1.ASN_QTY,
        c1.ANTH_ASN_QTY,
        c1.ASN_AMT,
        c1.FLOTQ_AMT,
        c1.MRTG_ASN_QTY,
        c1.MRTG_LND_QTY,
        nvl(c1.PROC_DT,'!'),
        c1.CONS_SBST_QTY,
        c1.CONS_SBST_AMT,
        c1.INQ_TRD_NO,
        c1.RCPT_TRD_NO,
        c1.OUTQ_TRD_NO,
        c1.OUTAMT_TRD_NO,
        nvl(c1.CONV_YN,'!'),
        c1.FLOTQ_TRD_NO,
        nvl(c1.PAY_YN,'!') ,
        nvl(c1.OUTR_PROC_YN,'!'),
        c1.INQ_QTY,
        c1.CANCEL_QTY,
        c1.WORK_MN,
        c1.WORK_DTM,
        c1.WORK_TRM,
        c1.INTER_AMT,
        c1.INTER_TRD_NO,
        c1.TAX_ASN,
        c1.TAX_FLOTQ,
        c1.TAX_INT,
        c1.TAX_STOCK,
        c1.TRANS_TP
            );
   END LOOP;

   /* insert creadit qty */

end  psr_std_batch_proc;
/

