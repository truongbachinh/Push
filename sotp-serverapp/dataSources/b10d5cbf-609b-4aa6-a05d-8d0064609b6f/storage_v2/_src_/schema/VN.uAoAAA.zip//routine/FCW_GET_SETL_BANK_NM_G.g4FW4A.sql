create function fcw_get_setl_bank_nm_g
(
    i_job_tp in varchar2 ,
    i_bank_cd   in   varchar2        -- bank_cd
)

    return          varchar2
as
    o_bank_cd_nm        varchar2(100) ;
    t_err_txt       varchar2(100)  ; -- error text buffer

begin

    o_bank_cd_nm  :=  NULL;

   begin
    select Trim(BANK_SCRT_ACNT_NM)
      into o_bank_cd_nm
      from vn.cww01h00
     where bank_Cd = i_bank_cd
       and vn.wdate between mng_strt_dt and mng_end_dt ;
   exception
    when others then
      return '!';
  end  ;

  return  o_bank_cd_nm;

end fcw_get_setl_bank_nm_g;
/

