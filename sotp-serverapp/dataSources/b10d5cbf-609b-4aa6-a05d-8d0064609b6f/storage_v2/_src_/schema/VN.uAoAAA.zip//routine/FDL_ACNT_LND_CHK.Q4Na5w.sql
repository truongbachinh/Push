create function fdl_acnt_lnd_chk
(
    i_acnt_no    in   varchar2,       --
    i_sub_no     in   varchar2,       --
    i_bank_cd    in   varchar2        --
)
    return  VARCHAR2
as
	o_chk             VARCHAR2(1);

    t_lnd_rm_amt      number := 0   ;

begin

/*============================================================================*/
/* Valiabl Initialize                                                         */
/*============================================================================*/
    o_chk  :=  'N';

/*============================================================================*/
/* generl commission return                                                   */
/*============================================================================*/
    if  i_bank_cd  =  '%'  then
        for C1 IN (
            select  nvl(sum(lnd_amt),0) - nvl(sum(lnd_rpy_amt),0)  lnd_rm_amt
              from  vn.dlm01m00
             where  acnt_no      like  i_acnt_no
               and  sub_no       like  i_sub_no
               and  lnd_bank_cd  like  i_bank_cd
               and  lnd_acpt_tp     =  '01'
        ) loop
            if  C1.lnd_rm_amt > 0 then
            	o_chk := 'Y';
                return o_chk;
            end if;
        end loop;

        return o_chk;
    else
        for C2 IN (
	        select  lnd_bank_cd
	          from  vn.dlm12m00
	         where  setl_bank_cd =  i_bank_cd
	           and  (lnd_bank_cd, apy_dt) in  (select  lnd_bank_cd, max(apy_dt)
	                                             from  vn.dlm12m00
	                                            where  setl_bank_cd =  i_bank_cd
	                                              and  apy_dt      <=  vn.vwdate
	                                            group  by lnd_bank_cd)
        ) loop
            for C3 IN (
                select  nvl(sum(lnd_amt),0) - nvl(sum(lnd_rpy_amt),0)  lnd_rm_amt
                  from  vn.dlm01m00
                 where  acnt_no      like  i_acnt_no
                   and  sub_no       like  i_sub_no
                   and  lnd_bank_cd     =  C2.lnd_bank_cd
                   and  lnd_acpt_tp     =  '01'
            ) loop
                if  C3.lnd_rm_amt > 0 then
                	o_chk := 'Y';
                    return o_chk;
                end if;
            end loop;

        end loop;

        return o_chk;
    end if;

end fdl_acnt_lnd_chk;
/

