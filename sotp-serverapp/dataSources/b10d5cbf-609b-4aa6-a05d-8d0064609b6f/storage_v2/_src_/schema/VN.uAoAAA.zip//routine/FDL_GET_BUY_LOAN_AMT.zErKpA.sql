create FUNCTION    fdl_get_buy_loan_amt
(
    i_acnt_no        in   varchar2,
    i_sub_no         in   varchar2,
    i_stk_cd         in   varchar2,
    i_tp             in   varchar2
)   RETURN  NUMBER AS
/*!
   \file     fdl_get_buy_loan_amt.sql
   \brief    Get the non settled buying loan
   \new      20110420

select vn.fdl_get_buy_loan_amt('999','045C000001','01','1') from dual;

*/

	td_buy_loan_amt           NUMBER := 0;
	td_mrtg_lnd_qty           NUMBER := 0;
	td_mrtg_rpy_qty           NUMBER := 0;
	td_mrtg_rm_qty            NUMBER := 0;
	td_buy_sbst_rt            NUMBER := 0;
	td_mgn_buy_diff_amt       NUMBER := 0;
	td_mrgn_rt                NUMBER := 0;

	ts_batch_yn         VARCHAR2(01) := NULL;
	ts_wdate            VARCHAR2(08) := NULL;
	ts_mth_dt           VARCHAR2(08) := NULL;

	ts_pd_mth_dt        VARCHAR2(08) := NULL;
	ts_ppd_mth_dt       VARCHAR2(08) := NULL;
	ts_pppd_mth_dt      VARCHAR2(08) := NULL;

begin

/*============================================================================*/
/* Valiabl Initialize
/*============================================================================*/

    ts_batch_yn := vn.fxb_daily_stat_chk ('B','0','2500','2500','*');
    ts_wdate    := vn.vwdate;

	ts_pd_mth_dt   := vn.fxc_vorderdt_g(to_date(ts_wdate,'yyyymmdd'), -1);
	ts_ppd_mth_dt  := vn.fxc_vorderdt_g(to_date(ts_wdate,'yyyymmdd'), -2);
	ts_pppd_mth_dt := vn.fxc_vorderdt_g(to_date(ts_wdate,'yyyymmdd'), -3);

	td_mrgn_rt	   :=  vn.fdl_get_mrgn_grp_acnt_rt( i_acnt_no, i_sub_no,vn.faa_acnt_get_grp_no (i_acnt_no, i_sub_no,'2', ts_wdate),'02', ts_wdate);

    /* CASE 1 : The stock settlment didn't process yet */
    IF ts_batch_yn = 'N' THEN

	    FOR C1 in (
	        select mrtg_lnd_qty
	             , mrtg_rpy_qty
	             , mrtg_lnd_qty - mrtg_rpy_qty rm_qty
	             , mth_dt
	             , vn.fss_get_td_cls_pri(stk_cd)	td_cls_pri
	             , stk_cd
	    	  FROM vn.dlm01m00
	    	 WHERE acnt_no = i_acnt_no
	    	   AND sub_no  = i_sub_no
	    	   AND lnd_tp  = '30'
	    	   AND stk_cd like i_stk_cd
	    	   AND mrtg_lnd_qty > mrtg_rpy_qty
	    	   AND setl_dt >= ts_wdate
	    ) LOOP
	    	td_mrtg_rm_qty := C1.rm_qty;

			if  C1.mth_dt  =  ts_pppd_mth_dt  then

				td_buy_sbst_rt	:= vn.fss_get_match_rate_acnt(C1.stk_cd, 3, i_acnt_no, i_sub_no);

				td_mgn_buy_diff_amt := td_mgn_buy_diff_amt + ROUND(td_mrtg_rm_qty * C1.td_cls_pri) * td_buy_sbst_rt * td_mrgn_rt;

			elsif  C1.mth_dt  =  ts_ppd_mth_dt  then

				td_buy_sbst_rt	:= vn.fss_get_match_rate_acnt(C1.stk_cd, 2, i_acnt_no, i_sub_no);

				td_mgn_buy_diff_amt := td_mgn_buy_diff_amt + ROUND(td_mrtg_rm_qty * C1.td_cls_pri) * td_buy_sbst_rt * td_mrgn_rt;

			elsif  C1.mth_dt  =  ts_pd_mth_dt  then

				td_buy_sbst_rt	:= vn.fss_get_match_rate_acnt(C1.stk_cd, 1, i_acnt_no, i_sub_no);

				td_mgn_buy_diff_amt := td_mgn_buy_diff_amt + ROUND(td_mrtg_rm_qty * C1.td_cls_pri) * td_buy_sbst_rt * td_mrgn_rt;

			elsif  C1.mth_dt  =  ts_wdate  then

				td_buy_sbst_rt	:= vn.fss_get_match_rate_acnt(C1.stk_cd, 0, i_acnt_no, i_sub_no);

				/* i_tp : 1 => Account part use the all amount of buying loan            */
				/* i_tp : 2 => Order part use the all amount of buying loan except today */
				IF i_tp = '1' THEN
					td_mgn_buy_diff_amt := td_mgn_buy_diff_amt + ROUND(td_mrtg_rm_qty * C1.td_cls_pri) * td_buy_sbst_rt * td_mrgn_rt;
				END IF;

		    end if;

			vn.pxc_log_write('fdl_get_buy_loan_amt', 'AMOUNT 1: '||' ACNT ='||i_acnt_no
			                                                                 ||' sbst_rt ='||td_buy_sbst_rt
			                                                                 ||' C1.stk_cd ='||C1.stk_cd
			                                                                 ||' mth_dt ='||C1.mth_dt
			                                                                 ||' rm_qty ='||C1.rm_qty
			                                                                 ||' cls_pri ='||C1.td_cls_pri
			                                                                 ||' CER ='||td_mrgn_rt
			                                                                 ||' AMOUNT ='||td_mgn_buy_diff_amt );

		END LOOP;
	/* CASE 2 : The stock settlment already process               */
	/*          So. settlement date for today should not include  */
    ELSE
	    FOR C2 in (
	        select mrtg_lnd_qty
	             , mrtg_rpy_qty
	             , mrtg_lnd_qty - mrtg_rpy_qty rm_qty
	             , mth_dt
	             , vn.fss_get_td_cls_pri(stk_cd)	td_cls_pri
	             , stk_cd
	    	  FROM vn.dlm01m00
	    	 WHERE acnt_no = i_acnt_no
	    	   AND sub_no  = i_sub_no
	    	   AND lnd_tp  = '30'
	    	   AND stk_cd like i_stk_cd
	    	   AND mrtg_lnd_qty > mrtg_rpy_qty
	    	   AND setl_dt > ts_wdate
	    ) LOOP
	        td_buy_sbst_rt := 0;
	    	td_mrtg_rm_qty := C2.rm_qty;

			if  C2.mth_dt  =  ts_ppd_mth_dt  then

				td_buy_sbst_rt	:= vn.fss_get_match_rate_acnt(C2.stk_cd, 2, i_acnt_no, i_sub_no);

				td_mgn_buy_diff_amt := td_mgn_buy_diff_amt + ROUND(td_mrtg_rm_qty * C2.td_cls_pri) * td_buy_sbst_rt * td_mrgn_rt;

			elsif  C2.mth_dt  =  ts_pd_mth_dt  then

				td_buy_sbst_rt	:= vn.fss_get_match_rate_acnt(C2.stk_cd, 1, i_acnt_no, i_sub_no);

				td_mgn_buy_diff_amt := td_mgn_buy_diff_amt + ROUND(td_mrtg_rm_qty * C2.td_cls_pri) * td_buy_sbst_rt * td_mrgn_rt;

			elsif  C2.mth_dt  =  ts_wdate  then

				td_buy_sbst_rt	:= vn.fss_get_match_rate_acnt(C2.stk_cd, 0, i_acnt_no, i_sub_no);

				/* i_tp : 1 => Account part use the all amount of buying loan            */
				/* i_tp : 2 => Order part use the all amount of buying loan except today */
				IF i_tp = '1' THEN
					td_mgn_buy_diff_amt := td_mgn_buy_diff_amt + ROUND(td_mrtg_rm_qty * C2.td_cls_pri) * td_buy_sbst_rt * td_mrgn_rt;
				END IF;

		    end if;
			vn.pxc_log_write('fdl_get_buy_loan_amt', 'CHECK BUYING AMOUNT 2: '||' ACNT ='||i_acnt_no
			                                                                 ||' sbst_rt ='||td_buy_sbst_rt
			                                                                 ||' C1.stk_cd ='||C2.stk_cd
			                                                                 ||' mth_dt ='||C2.mth_dt
			                                                                 ||' rm_qty ='||C2.rm_qty
			                                                                 ||' AMOUNT ='||td_mgn_buy_diff_amt );

		END LOOP;
	END IF;

    RETURN td_mgn_buy_diff_amt;

END fdl_get_buy_loan_amt;
/

