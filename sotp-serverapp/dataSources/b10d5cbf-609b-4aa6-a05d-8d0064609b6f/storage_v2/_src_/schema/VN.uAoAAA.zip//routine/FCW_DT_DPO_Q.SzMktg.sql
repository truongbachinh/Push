create function fcw_dt_dpo_q
(
	i_std_dt  in   varchar2 ,
	i_acnt_no in   varchar2 ,
	i_sub_no  in   varchar2
)

	return          number
as
    t_std_dt			varchar2(20) := Null  ;
    t_dpo				number := 0;
    t_tmp				number := 0;
	t_tso				number := 0;
	t_tot_out_psbamt	number := 0;
    o_trd_amt			number := 0;
    t_err_txt			varchar2(200)  ; -- error text buffer
    t_err_msg			varchar2(200)  ; -- error text buffer

begin

	t_std_dt	:=	vn.vhdate;

	if t_std_dt = i_std_dt then

		BEGIN
			vn.pcw_outamt_psbamt_q
			   (i_acnt_no
            ,  i_sub_no
            , '9999'
	    	,  t_dpo
			,  t_tmp
			,  t_tmp
			,  t_tmp
			,  t_tmp
			,  t_tmp
            ,  t_tmp
            ,  t_tmp
            ,  t_tmp
            ,  t_tmp
            ,  t_tmp
			,  t_tmp
			,  t_tmp
			,  t_tmp
			,  t_tmp
			,  t_tmp
			,  t_tmp
			,  t_tmp
			,  t_tmp
			,  t_tmp
			,  t_tmp
			,  t_tmp
			,  t_tot_out_psbamt
			);
		EXCEPTION
		WHEN  OTHERS         THEN
			t_err_txt  :=  'pcw_outamt_psbamt_q_err:'
				   ||  to_char(sqlcode);
			t_err_msg := vn.fxc_get_err_msg('V','2733');
			raise_application_error(-20100,t_err_msg||t_err_txt);
		END;

	else

		t_tot_out_psbamt := 0;
		t_dpo := 0;
		t_tso := 0;

		BEGIN
			select dpo
			into  t_dpo
			from vn.cwd01h00
			where std_dt	= i_std_dt
			and acnt_no		= i_acnt_no
			and sub_no      = i_sub_no
			;
		EXCEPTION
			WHEN  NO_DATA_FOUND  THEN
				t_dpo := 0;
			WHEN  OTHERS         THEN
				t_err_txt  :=  'cwd01h00-err-['||to_char(sqlcode)||']';
				raise_application_error (-20100, t_err_txt);
		END;

		BEGIN
			select nvl(sum(nvl(td_cash_prof_amt   , 0) +
				           nvl(pd_cash_prof_amt   , 0)    +
				           nvl(ppd_cash_prof_amt  , 0)    +
				           nvl(pppd_cash_prof_amt , 0)    +

				           nvl(td_cdt_prof_amt ,0) +
				           nvl(pd_cdt_prof_amt ,0) +
				           nvl(ppd_cdt_prof_amt ,0) +
				           nvl(pppd_cdt_prof_amt ,0) +

				           nvl(td_cash_prof_gst_amt ,0) +
					       nvl(pd_cash_prof_gst_amt ,0) +
					       nvl(ppd_cash_prof_gst_amt,0) +
					       nvl(pppd_cash_prof_gst_amt , 0) ) , 0 )  cash_prof_amt
			into  t_tso
			from vn.tso02h00
			where acnt_no = i_acnt_no
			and   sub_no  = i_sub_no
			and   dt = i_std_dt
			;
		EXCEPTION
			WHEN  NO_DATA_FOUND  THEN
				t_tso := 0;
			WHEN  OTHERS         THEN
				t_err_txt  :=  'tso02h00-err-['||to_char(sqlcode)||']';
				raise_application_error (-20100, t_err_txt);
		END;

		t_tot_out_psbamt := t_dpo - t_tso;

	end if;

    return  t_tot_out_psbamt;

end fcw_dt_dpo_q;
/

