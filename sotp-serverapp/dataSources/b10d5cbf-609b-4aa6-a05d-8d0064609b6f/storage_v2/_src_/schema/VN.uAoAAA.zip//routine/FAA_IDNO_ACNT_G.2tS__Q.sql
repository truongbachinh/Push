create function faa_idno_acnt_g
(
  i_idno    in    varchar2
) return varchar2 as

  o_acnt_no  varchar2(10);

/* ===========================================
  -- Program ID     :   faa_acnt_idno_g
  -- Date of Program  :   22/10/2007
  -- Programmer    :  mkkim
  -- Description     :
      input  :  Account Number
      return : ID number
   =========================================== */

begin

  begin
  select  nvl(acnt_no,'!')
  into  o_acnt_no
  from  vn.aaa01m00
  where  idno   =  i_idno
    and   sub_no   = '00'
    AND acnt_stat = '1' ;

    return o_acnt_no;

  exception
  when   no_data_found then
    return   '!';
  end;


end ;
/

