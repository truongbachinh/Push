create PROCEDURE PVSD_INS_UPD_VSD02M00
(
    i_proc_tp     in    varchar2,
    i_send_tp     in    varchar2,
    i_acnt_no     in    varchar2,
    i_work_mn     in    varchar2,
    i_work_trm    in    varchar2
)
/*************************************************
i_proc_tp:
  1: Mo TK
  2: Dong TK
  3: Chuyen khoan tat toan TK
i_send_tp:
  1: Gui VSD
  2: VSD gui ve
*************************************************/
AS
  v_seq   number  := 0;
  v_count number  := 0;
  --v_mess  varchar2(4000);

BEGIN

  IF i_send_tp = '1' THEN
     IF i_proc_tp = '3' THEN
        SELECT COUNT(*) INTO v_count
        FROM   VN.VSD02M00
        WHERE  ACNT_NO = i_acnt_no
        AND    PROC_TP = i_proc_tp
        AND    ROWNUM  < 2;

        IF v_count > 0 THEN
           RETURN;
        END IF;
     END IF;

      BEGIN
        vn.pcom_nextseq( 'vsd01m00_seq', v_seq );
      EXCEPTION
      WHEN others then
        vn.pxc_log_write('pvsd_ins_upd_vsd02m00', ' Loi pcom_nextseq: '||sqlcode);
        raise_application_error(-20100 , sqlcode ||': '|| sqlerrm ) ;
      END;

      vn.pxc_log_write('pvsd_ins_upd_vsd02m00', 'nextseq: '||v_seq);

      INSERT INTO VN.VSD02M00  (PROC_DT, BOS_SEQ_NO, ACNT_NO, PROC_TP, VSD_STAT, WORK_MN, WORK_DTM, WORK_TRM)
      VALUES  (to_char(sysdate,'yyyymmdd'), v_seq, i_acnt_no,i_proc_tp, i_send_tp, i_work_mn, sysdate, i_work_trm);

  END IF;

 END PVSD_INS_UPD_VSD02M00 ;
/

