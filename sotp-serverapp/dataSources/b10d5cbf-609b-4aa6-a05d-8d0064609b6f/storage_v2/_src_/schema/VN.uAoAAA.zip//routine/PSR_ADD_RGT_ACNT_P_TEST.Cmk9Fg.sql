create procedure psr_add_rgt_acnt_p_test
 (i_sec_cd     in       varchar2,
 -- i_proc_tp    in       varchar2,
  i_rgt_std_dt in       varchar2,
  i_stk_cd     in       varchar2,
  i_rgt_tp     in       varchar2,
  i_seq_no     in       number,
  i_acnt_no    in       varchar2,
  i_sub_no     in       varchar2,
  i_rgt_std_qty    in   number,
  i_cons_sbst_qty  in   number,
  i_work_mn    in       varchar2,
  i_work_trm   in       varchar2
 ) is

	vn_std_rt         number := 0;
	vn_std_rt2        number := 0;
	vn_rgt_iss_pri    number := 0;
	vn_proc_seq		number := 0;
	vn_rgt_proc_stat	varchar2(1);

	vn_rgt_asn_rt     number := 0;
	vn_rgt_asn_rt2    number := 0;
	vn_flotq_std_pri  number := 0;
	vn_asn_amt        number := 0;
	vn_inter_amt      number := 0;
	vn_asn_qty        number := 0;
	vn_flotq_amt      number := 0;
	vn_own_qty        number := 0;
	vn_rgt_own_qty    number := 0;
	vn_own_amt        number := 0;
	vn_fac_pri        number := 0;
	vn_flotq_qty      number := 0;

	vn_cash_rate      number := 0;
	vn_stock_rate     number := 0;

	vn_r_t_tp         varchar2(1);
	vn_round_tp       varchar2(4);
	vn_tax_tp         varchar2(1);
	vn_tax_asn      number := 0 ;
	vn_tax_flotq    number := 0 ;
	vn_tax_int      number := 0 ;
	vn_tax_stock    number := 0 ;
	vn_cnt_qty      number := 0 ;
	vn_cnt_amt      number := 0 ;
	vn_cnt_flotq    number := 0 ;
	vn_cnt_inter    number := 0 ;

begin

 --o_proc_cnt := 0;

-- if i_proc_tp = 'I' then

     vn.pxc_log_write('psr_add_rgt_acnt_p', i_acnt_no||'-'||i_sub_no||'-'||i_rgt_std_dt||'-'||i_stk_cd||'-'||i_rgt_tp);

	/*Phan bo quyen*/

    if i_rgt_tp = '8' Then --Quyen chuyen doi co phieu/trai phiei -> co phieu khac
		select 	nvl(std_pay_rt,1) std_rt ,
				nvl(std_rt,1)     std_rt2,
				rgt_proc_stat,
				cnvt_rt,
				cnvt_pay_rt,
				flotq_std_pri,
				nvl(tax_rate,0 ) cash_rate,
				nvl(tax_rate_2,0) stock_rate ,
				substr(NVL(Trim(round_tp),'t'),1,1)   r_t_tp	 ,
				decode(nvl(round_tp, 't1'),'r1','0','r2','-1','r3' ,'-2' , 't1' , '0' ,'t2', '-1','-2')  round_tp
         Into 	vn_std_rt,
				vn_std_rt2,
				vn_rgt_proc_stat,
				vn_rgt_asn_rt,
				vn_rgt_asn_rt2,
				vn_flotq_std_pri,
				vn_cash_rate,
				vn_stock_rate,
				vn_r_t_tp,
				vn_round_tp
         from vn.srr01m10
        where rgt_std_dt = i_rgt_std_dt
          and stk_cd     = i_stk_cd;

    else
		select 	nvl(std_rt,1)     std_rt,
				nvl(std_pay_rt,1) std_rt2,
				rgt_iss_pri,
				rgt_proc_stat,
				rgt_asn_rt,
				rgt_asn_pay_rt,
				flotq_std_pri,
				nvl(tax_rate,0 ) cash_rate,
				nvl(tax_rate_2,0) stock_rate ,
				substr(NVL(Trim(round_tp),'t'),1,1)   r_t_tp	 ,
				decode(nvl(round_tp, 't1'),'r1','0','r2','-1','r3' ,'-2' , 't1' , '0' ,'t2', '-1','-2')  round_tp
       Into   	vn_std_rt,
				vn_std_rt2,
				vn_rgt_iss_pri,
				vn_rgt_proc_stat,
				vn_rgt_asn_rt,
				vn_rgt_asn_rt2,
				vn_flotq_std_pri,
				vn_cash_rate,
				vn_stock_rate,
				vn_r_t_tp,
				vn_round_tp
       from   vn.srr01m00
       where  rgt_std_dt    =  i_rgt_std_dt
       and    stk_cd        =  i_stk_cd
       and    rgt_tp        =  i_rgt_tp
       and    seq_no        =  i_seq_no;
    end if;

	if vn_std_rt = 0 then
		vn_std_rt := 1;
	end if;

    vn_own_qty :=  trunc(i_rgt_std_qty * (vn_std_rt2 / vn_std_rt));

	vn.pxc_log_write('psr_add_rgt_acnt_p', vn_own_qty);

	/*update 	vn.srr02m00
	Set		own_stk_qty = own_stk_qty + vn_own_qty,
			own_qty		= own_qty + vn_own_qty,
			cons_sbst_qty = cons_sbst_qty + i_cons_sbst_qty,
			cons_sbst_amt = cons_sbst_amt + i_cons_sbst_qty*vn_rgt_iss_pri,
			trans_tp	= '1',
			work_mn		= i_work_mn,
			work_dtm	= sysdate,
			work_trm	= i_work_trm
	Where	rgt_std_dt	= i_rgt_std_dt
	and		stk_cd		= i_stk_cd
	and 	rgt_tp		= i_rgt_tp
	and		seq_no		= i_seq_no
	and		acnt_no		= i_acnt_no
	and		sub_no		= i_sub_no;
*/
	if sql%rowcount = 0 then
		insert into  vn.srr02m00
                 ( rgt_std_dt    ,
                   acnt_no       ,
                   sub_no       ,
                   stk_cd        ,
                   rgt_tp        ,
                   seq_no        ,
                   acnt_mng_bnh  ,
                   own_stk_qty	 ,
                   own_qty       ,
                   asn_qty       ,
                   asn_amt       ,
                   flotq_amt     ,
                   mrtg_lnd_qty  ,
                   mrtg_asn_qty  ,
                   inq_trd_no    ,
                   rcpt_trd_no   ,
                   outq_trd_no   ,
                   outamt_trd_no ,
                   flotq_trd_no  ,
                   inter_trd_no	 ,
                   cons_sbst_qty ,
                   cons_sbst_amt ,
                   work_mn       ,
                   work_dtm      ,
                   work_trm      ,
                   trans_tp)
        values
              (i_rgt_std_dt       ,
               i_acnt_no     ,
               i_sub_no     ,
               i_stk_cd      ,
               i_rgt_tp      ,
               i_seq_no      ,
               faa_acnt_bnh_cd_g('0',i_acnt_no,i_sub_no),
               vn_own_qty     ,
               vn_own_qty     ,
               0     ,
               0      ,
               0    ,
               0,
               0              ,
               0              ,
               0              ,
               0              ,
               0              ,
               0              ,
               0              ,
               i_cons_sbst_qty,
               i_cons_sbst_qty*vn_rgt_iss_pri,
               i_work_mn      ,
               sysdate        ,
               i_work_trm     ,
               '1' --Nhap quyen
             ) ;
	end if;

	/*Bat dau Phan bo chung khoan*/

	if vn_rgt_proc_stat > '2' then
		vn.pxc_log_write('psr_add_rgt_acnt_p','Begin 2');

		if vn_r_t_tp = '0' then
			vn_r_t_tp := 't' ;
		end if ;

		if vn_rgt_asn_rt2 = 0 then
			vn_rgt_asn_rt2 := 1;
		end if;

		vn.pxc_log_write('psr_rgt_asn_p_acnt','cash_rate '||vn_cash_rate||'- stock_rate '||vn_stock_rate||'- round or trunc '||vn_round_tp);

		select
			 vn_own_qty * vn_rgt_asn_rt / vn_rgt_asn_rt2     asn_qty ,
			 vn_own_qty                                        own_qty ,
			 nvl(vn.fss_get_fac_pri(i_stk_cd),0)   fac_pri ,
			 vn_own_qty * vn_rgt_asn_rt / vn_rgt_asn_rt2
				  -  trunc( vn_own_qty * vn_rgt_asn_rt / vn_rgt_asn_rt2 , vn_round_tp)   flotq_qty,
			 (vn_rgt_iss_pri * vn_own_qty)   own_amt ,
			 (vn_rgt_iss_pri * vn_rgt_asn_rt/vn_rgt_asn_rt2 * vn_own_qty)   inter_amt ,
			 vn.fsr_tax_tp_g(i_acnt_no, i_sub_no)  tax_tp
		into   vn_asn_qty,
			 vn_rgt_own_qty,
			 vn_fac_pri,
			 vn_flotq_qty,
			 vn_own_amt,
			 vn_inter_amt,
			 vn_tax_tp
		from   dual;

		 vn.pxc_log_write('psr_add_rgt_acnt_p',' rgt_own_qty '||vn_rgt_own_qty||' asn_qty '||vn_asn_qty);

		 if i_rgt_tp = '1' then
			if vn_rgt_proc_stat > '4' Then
				 vn_asn_qty   := 0;
			else
			  if vn_r_t_tp = 't' then
				 vn_asn_qty   := trunc(vn_asn_qty , vn_round_tp);
			  else
				 vn_asn_qty   := round(vn_asn_qty , vn_round_tp);
			  end if ;
			end if;

			vn_asn_amt   := 0 ;
			vn_inter_amt := 0 ;
			vn_flotq_amt := 0 ;

		 elsif i_rgt_tp = '2' then

			vn_tax_stock := round( vn_tax_tp * vn_asn_qty * (vn_stock_rate / 100 ) ) ;
			vn_tax_flotq := round( vn_tax_tp * (vn_flotq_qty * vn_flotq_std_pri) * (vn_cash_rate / 100 ) ) ;

			vn_asn_qty   :=  vn_asn_qty - vn_tax_stock ;
			vn_flotq_amt :=  vn_flotq_qty * vn_flotq_std_pri - vn_tax_flotq ;

			if vn_r_t_tp = 't' then
			   vn_asn_qty   := trunc(vn_asn_qty   , vn_round_tp );
			   vn_flotq_amt := trunc(vn_flotq_amt , vn_round_tp );
			else
				if vn_asn_qty > round(vn_asn_qty   , vn_round_tp) then
					vn_flotq_amt := trunc(vn_flotq_amt , vn_round_tp);
				else
					vn_flotq_amt := 0;
					vn_tax_flotq := 0;
				end if;

				vn_asn_qty   := round(vn_asn_qty   , vn_round_tp);
			end if ;

			SELECT  count(*) INTO  vn_cnt_qty
			 FROM 	vn.srr02m00
			WHERE   rgt_std_dt   = i_rgt_std_dt
			  AND   stk_cd       = i_stk_cd
			  AND   rgt_tp		 = i_rgt_tp
			  AND		seq_no       = i_seq_no
			  AND		asn_qty 	 > 0
			  AND		inq_trd_no	 > 0
			  AND		rownum		 < 2;

			SELECT  count(*) INTO  vn_cnt_flotq
			 FROM 	vn.srr02m00
			WHERE   rgt_std_dt   = i_rgt_std_dt
			  AND   stk_cd       = i_stk_cd
			  AND   rgt_tp		 = i_rgt_tp
			  AND		seq_no       = i_seq_no
			  AND		flotq_amt 	   > 0
			  AND		flotq_trd_no	 > 0
			  AND		rownum		 < 2;

			if vn_cnt_qty > 0 Then
			   vn_tax_stock := 0;
			   vn_asn_qty   := 0;
			end if;

			if vn_cnt_flotq > 0 Then
			   vn_tax_flotq := 0;
			   vn_flotq_amt := 0;
			end if;

				  vn_asn_amt    := 0 ;
				  vn_inter_amt  := 0 ;

		 elsif i_rgt_tp = '3' then
			vn_tax_stock  := round( vn_tax_tp * vn_asn_qty * (vn_stock_rate / 100 ) ) ;
			vn_tax_asn    := round( vn_tax_tp * vn_rgt_own_qty * (vn_rgt_iss_pri / 100 * vn_fac_pri) * (vn_cash_rate / 100 ) );
			vn_tax_flotq  := round( vn_tax_tp * (vn_flotq_qty * vn_flotq_std_pri) * (vn_cash_rate / 100 ) )  ;

			vn_asn_qty   :=  vn_asn_qty   - vn_tax_stock ;
			vn_asn_amt   :=  vn_rgt_own_qty * (vn_rgt_iss_pri / 100 * vn_fac_pri) - vn_tax_asn ;
			vn_flotq_amt :=  vn_flotq_qty * vn_flotq_std_pri - vn_tax_flotq ;

			if vn_r_t_tp = 't' then
			   vn_asn_qty   := trunc(vn_asn_qty   , vn_round_tp );
			   vn_flotq_amt := trunc(vn_flotq_amt , vn_round_tp );
			   vn_asn_amt   := trunc(vn_asn_amt   , vn_round_tp );
			else
			   if vn_asn_qty > round(vn_asn_qty   , vn_round_tp) then
				  vn_flotq_amt := trunc(vn_flotq_amt , vn_round_tp);
			   else
				  vn_flotq_amt := 0;
				  vn_tax_flotq := 0;
			   end if;

			   vn_asn_qty   := round(vn_asn_qty   , vn_round_tp );
			   vn_asn_amt   := round(vn_asn_amt   , vn_round_tp );
			end if ;

			SELECT  count(*) INTO  vn_cnt_qty
			 FROM 	vn.srr02m00
			WHERE   rgt_std_dt   = i_rgt_std_dt
			  AND   stk_cd       = i_stk_cd
			  AND   rgt_tp		 = i_rgt_tp
			  AND		seq_no       = i_seq_no
			  AND		asn_qty 	 > 0
			  AND		inq_trd_no	 > 0
			  AND		rownum		 < 2;

			SELECT  count(*) INTO  vn_cnt_amt
			 FROM 	vn.srr02m00
			WHERE   rgt_std_dt   = i_rgt_std_dt
			  AND   stk_cd       = i_stk_cd
			  AND   rgt_tp		   = i_rgt_tp
			  AND		seq_no       = i_seq_no
			  AND		asn_amt 	   > 0
			  AND		rcpt_trd_no	 > 0
			  AND		rownum		   < 2;

			SELECT  count(*) INTO  vn_cnt_flotq
			 FROM 	vn.srr02m00
			WHERE   rgt_std_dt   = i_rgt_std_dt
			  AND   stk_cd       = i_stk_cd
			  AND   rgt_tp		 = i_rgt_tp
			  AND		seq_no       = i_seq_no
			  AND		flotq_amt 	   > 0
			  AND		flotq_trd_no	 > 0
			  AND		rownum		 < 2;

			if vn_cnt_qty > 0 Then
			   vn_tax_stock := 0;
			   vn_asn_qty   := 0;
			end if;

			if vn_cnt_amt > 0 Then
			   vn_tax_asn   := 0;
			   vn_asn_amt   := 0;
			end if;

			if vn_cnt_flotq > 0 Then
			   vn_tax_flotq := 0;
			   vn_flotq_amt := 0;
			end if;

				  vn_inter_amt := 0 ;

		elsif i_rgt_tp = '4' then
			if vn_rgt_proc_stat > '4' Then
			   vn_asn_qty   := 0;
			else
				if vn_r_t_tp = 't' then
				   vn_asn_qty   := trunc(vn_asn_qty , vn_round_tp);
				else
				   vn_asn_qty   := round(vn_asn_qty , vn_round_tp);
				end if ;
			end if;

				  vn_asn_amt   := 0 ;
					vn_inter_amt := 0 ;
					vn_flotq_amt := 0 ;

		elsif i_rgt_tp = '5' then
			if vn_rgt_proc_stat > '4' Then
			   vn_asn_qty   := 0;
			else
				if vn_r_t_tp = 't' then
				   vn_asn_qty   := trunc(vn_asn_qty , vn_round_tp);
				else
				   vn_asn_qty   := round(vn_asn_qty , vn_round_tp);
				end if ;
			end if;

			vn_asn_amt   := 0 ;
			vn_inter_amt := 0 ;
			vn_flotq_amt := 0 ;

		elsif i_rgt_tp = '8'  then
			vn_tax_stock  := round ( vn_asn_qty   * (vn_stock_rate / 100 ) ) ;
				  vn_tax_flotq  := round ( vn_flotq_qty * vn_flotq_std_pri * (vn_cash_rate  / 100 ) ) ;

			vn_asn_qty   :=  vn_asn_qty   - vn_tax_stock ;
			vn_flotq_amt :=  vn_flotq_qty * vn_flotq_std_pri - vn_tax_flotq ;

			if vn_r_t_tp = 't' then
			   vn_asn_qty   := trunc(vn_asn_qty   , vn_round_tp );
			   vn_flotq_amt := trunc(vn_flotq_amt , vn_round_tp );

			else
			   vn_asn_qty   := round(vn_asn_qty   , vn_round_tp );

			   if vn_asn_qty > round(vn_asn_qty   , vn_round_tp) then
				  vn_flotq_amt := trunc(vn_flotq_amt , vn_round_tp);
			   else
				  vn_flotq_amt := 0;
							vn_tax_flotq := 0;
			   end if;
			end if ;

			SELECT  count(*) INTO  vn_cnt_qty
			 FROM 	vn.srr02m00
			WHERE   rgt_std_dt   = i_rgt_std_dt
			  AND   stk_cd       = i_stk_cd
			  AND   rgt_tp		   = i_rgt_tp
			  AND		seq_no       = i_seq_no
			  AND		asn_qty 	   > 0
			  AND		inq_trd_no	 > 0
			  AND		rownum		   < 2;

			SELECT  count(*) INTO  vn_cnt_flotq
			 FROM 	vn.srr02m00
			WHERE   rgt_std_dt   = i_rgt_std_dt
			  AND   stk_cd       = i_stk_cd
			  AND   rgt_tp		   = i_rgt_tp
			  AND		seq_no       = i_seq_no
			  AND		flotq_amt 	 > 0
			  AND		flotq_trd_no > 0
			  AND		rownum		   < 2;

			if vn_cnt_qty > 0 Then
			   vn_tax_stock := 0;
			   vn_asn_qty   := 0;
			end if;

			if vn_cnt_flotq > 0 Then
			   vn_tax_flotq := 0;
			   vn_flotq_amt := 0;
			end if;

		elsif i_rgt_tp = '9'  then
			vn_tax_asn  :=  0;
			vn_tax_int  :=  round ( vn_tax_tp * vn_inter_amt *  (vn_cash_rate / 100 ) ) ;

			if vn_r_t_tp ='t' then
				vn_asn_amt   := trunc ( vn_own_amt   - vn_tax_asn   , vn_round_tp  ) ;
				vn_inter_amt := trunc ( vn_inter_amt - vn_tax_int   , vn_round_tp  ) ;
			else
				vn_asn_amt   := round ( vn_own_amt   - vn_tax_asn   , vn_round_tp  ) ;
				vn_inter_amt := round ( vn_inter_amt - vn_tax_int   , vn_round_tp  ) ;
			end if ;

			SELECT  count(*) INTO  vn_cnt_amt
			 FROM 	vn.srr02m00
			WHERE   rgt_std_dt   = i_rgt_std_dt
			  AND   stk_cd       = i_stk_cd
			  AND   rgt_tp		   = i_rgt_tp
			  AND		seq_no       = i_seq_no
			  AND		asn_amt 	   > 0
			  AND		rcpt_trd_no	 > 0
			  AND		rownum		   < 2;

			SELECT  count(*) INTO  vn_cnt_inter
			 FROM 	vn.srr02m00
			WHERE   rgt_std_dt   = i_rgt_std_dt
			  AND   stk_cd       = i_stk_cd
			  AND   rgt_tp		   = i_rgt_tp
			  AND		seq_no       = i_seq_no
			  AND		inter_amt 	 > 0
			  AND		inter_trd_no > 0
			  AND		rownum		   < 2;

			if vn_cnt_amt > 0 Then
			   vn_tax_asn   := 0;
			   vn_asn_amt   := 0;
			end if;

			if vn_cnt_inter > 0 Then
			   vn_tax_int := 0;
			   vn_inter_amt := 0;
			end if;

			vn_asn_qty   := 0 ;
			vn_flotq_amt := 0 ;

		 else   -- A
			if vn_rgt_proc_stat > '4' Then
			   vn_asn_qty   := 0;
			else
			   vn_asn_qty   :=  trunc( vn_asn_qty - (vn_asn_qty * (vn_stock_rate / 100 )) );
			end if;

			vn_asn_amt   := 0 ;
			vn_inter_amt := 0 ;
			vn_flotq_amt := 0 ;

		 end if ;

		 update  vn.srr02m00
			set  asn_qty      = asn_qty + vn_asn_qty,
				 flotq_amt    = flotq_amt + vn_flotq_amt,
				 asn_amt      = asn_amt + vn_asn_amt ,
				 inter_amt    = inter_amt + vn_inter_amt ,
				 tax_asn      = tax_asn + vn_tax_asn ,
				 tax_flotq    = tax_flotq + vn_tax_flotq ,
				 tax_int      = tax_int + vn_tax_int ,
				 tax_stock    = tax_stock + vn_tax_stock
		 where   rgt_std_dt   = i_rgt_std_dt
		 and     stk_cd       = i_stk_cd
		 and     rgt_tp       = i_rgt_tp
		 and     seq_no       = i_seq_no
		 and     acnt_no      = i_acnt_no
		 and     sub_no       = i_sub_no;

		 /* make rgt sbst and reuse */

		/* vn.psr_sbst_proc_p
			(
			  'm'          -- make
			, i_rgt_tp
			, i_rgt_std_dt
			, i_stk_cd
			, i_seq_no
			, i_acnt_no
			,i_sub_no
			, i_work_mn
			, i_work_trm
			);*/

		vn.pxc_log_write('psr_rgt_asn_p_acnt','psr_sbst_proc_p make 1 '|| sqlcode );
	end if;
	/*Ket thuc phan bo chung khoan*/

	Begin
      SELECT  nvl(max(proc_seq),0) + 1
      into vn_proc_seq
      FROM 	vn.srr02m10
      Where	proc_dt = vn.vwdate;
    Exception
      when others then
        vn_proc_seq := 0;
    End;

	insert into vn.srr02m10
				(   acnt_no
					,sub_no
					,rgt_std_dt
					,rgt_tp
					,stk_cd
					,seq_no
					,own_qty
					,rgt_own_qty
					,cons_sbst_qty
					,trans_tp
					,proc_dt
					,proc_tp
					,proc_seq
					,asn_qty
					,asn_amt
					,flotq_amt
					,inter_amt
					,tax_asn
					,tax_flotq
					,tax_int
					,work_mn
					,work_dtm
					,work_trm
				)
	values		(   i_acnt_no
					,i_sub_no
					,i_rgt_std_dt
					,i_rgt_tp
					,i_stk_cd
					,i_seq_no
					,i_rgt_std_qty
					,vn_own_qty
					,i_cons_sbst_qty
					,'1'
					,vn.vwdate
					,'Y'
					,vn_proc_seq
					,vn_asn_qty
					,vn_asn_amt
					,vn_flotq_amt
					,vn_inter_amt
					,vn_tax_asn
					,vn_tax_flotq
					,vn_tax_int
					,i_work_mn
					,sysdate
					,i_work_trm
				);

        rollback;
end  psr_add_rgt_acnt_p_test;
/

