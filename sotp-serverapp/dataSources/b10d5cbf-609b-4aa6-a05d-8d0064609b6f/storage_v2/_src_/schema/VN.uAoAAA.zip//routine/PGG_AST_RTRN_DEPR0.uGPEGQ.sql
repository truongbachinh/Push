create PROCEDURE    PGG_AST_RTRN_DEPR0
   (I_TERM_TP       IN      VARCHAR2,       -- 회기시작구분(0:시작, 1:기중, 9:종료)
    I_BRCH_CD       IN      VARCHAR2,       -- 지점
    I_AGNC_BRCH     IN      VARCHAR2,       -- 대리지점
    I_TERMS       	IN      NUMBER,       	-- 회계기수
    I_YYMM       	IN      VARCHAR2,       -- 상각년월
    I_LAST_DAY      IN      VARCHAR2,       -- 처리일
    I_WORK_MN       IN      VARCHAR2,		-- 처리자
    I_WORK_TRM      IN      VARCHAR2,       -- IP_ADDRESS
    O_RTN_TBL       OUT     VARCHAR2,       -- Return Table
	O_RTN_ERR       OUT     VARCHAR2,       -- Return Error Code
	O_RTN_MSG       OUT     VARCHAR2        -- Return Message
	) IS

    -- Constants
    K_SLIP_MAXDT    VARCHAR2(8) := '20080401' ; 	-- 처리시작일


    -- Variables
	T_AST_NO				VN.GGA22M00.AST_NO%TYPE;				-- 자산번호
	T_PST_DEPR_AMT			VN.GGA23M01.PST_DEPR_AMT%TYPE;			-- 추정당기상각금액
	T_TPRD_DEPR_CUM			VN.GGA23M01.TPRD_DEPR_CUM%TYPE;			-- 당기상각누계액

    T_CNT           NUMBER := 0;


    -- Exceptions Declare
    ERR_FGG_AST_RTRN_DEPR		EXCEPTION;
    ERR_GGA23M01_INS			EXCEPTION;
    ERR_GGA23M01_UPD			EXCEPTION;

-- *************************< START OF PROCEDURE >****************************
BEGIN


    -- ************************
    -- * 년상각액 회기초 처리 *
    -- ************************
    IF  I_TERM_TP  =   '0' THEN

        -- CHK_1. 토지/미상각자산 년상각액 회기초 처리
        INSERT
          INTO  VN.GGA23M01(
				TERMS,				DEPR_YY,			AST_NO,
				BRCH_CD,			AGNC_BRCH,			DEPT_CD,
				PST_DEPR_AMT,
				DEPR_AMT_01,		DEPR_AMT_02,		DEPR_AMT_03,
				DEPR_AMT_04,		DEPR_AMT_05,		DEPR_AMT_06,
				DEPR_AMT_07,		DEPR_AMT_08,		DEPR_AMT_09,
				DEPR_AMT_10,		DEPR_AMT_11,		DEPR_AMT_12,
				GET_AMT,			BPRD_DEPR_CUM,		TPRD_DEPR_CUM,
				NDEPR_REMN,			USE_YN,
				WORK_MN,			WORK_DTM,			WORK_TRM,
				MDFY_MN,			MDFY_DTM,			MDFY_TRM )
		SELECT	I_TERMS						AS	TERMS,
				SUBSTR(I_YYMM, 1, 4)		AS	DEPR_YY,
				v11.AST_NO					AS	AST_NO,
				v11.BRCH_CD					AS	BRCH_CD,
				v11.AGNC_BRCH				AS	AGNC_BRCH,
				v11.DEPT_CD					AS	DEPT_CD,
				0							AS	PST_DEPR_AMT,
				0							AS	DEPR_AMT_01,
				0							AS	DEPR_AMT_02,
				0							AS	DEPR_AMT_03,
				0							AS	DEPR_AMT_04,
				0							AS	DEPR_AMT_05,
				0							AS	DEPR_AMT_06,
				0							AS	DEPR_AMT_07,
				0							AS	DEPR_AMT_08,
				0							AS	DEPR_AMT_09,
				0							AS	DEPR_AMT_10,
				0							AS	DEPR_AMT_11,
				0							AS	DEPR_AMT_12,
				NVL(v11.GET_AMT, 0)			AS	GET_AMT,
				0							AS	BPRD_DEPR_CUM,
				0							AS	TPRD_DEPR_CUM,
				NVL(v11.GET_AMT, 0)			AS	NDEPR_REMN,
                'Y'                         AS  USE_YN,
				I_WORK_MN					AS	WORK_MN,
				SYSDATE						AS	WORK_DTM,
				I_WORK_TRM					AS	WORK_TRM,
				I_WORK_MN					AS	MDFY_MN,
				SYSDATE						AS	MDFY_DTM,
				I_WORK_TRM					AS	MDFY_TRM
		  FROM
				(	SELECT	v21.AST_NO					AS	AST_NO,
							(	SELECT	v31.BRCH_CD		AS	BRCH_CD
								  FROM	VN.GGA22M02	v31
								 WHERE	v31.AST_NO		=	v21.AST_NO
								   AND	v31.CHG_END_DT	=	(	SELECT	MAX(v41.CHG_END_DT)
																  FROM	VN.GGA22M02	v41
																 WHERE	v41.AST_NO		=	v21.AST_NO
																   AND	TO_DATE(I_LAST_DAY, 'YYYY/MM/DD')	BETWEEN	TRUNC(v41.CHG_STAT_DT)	AND	TRUNC(v41.CHG_END_DT)
															)
							)							AS	BRCH_CD,
							(	SELECT	v21.AGNC_BRCH	AS	AGNC_BRCH
								  FROM	VN.GGA22M02	v31
								 WHERE	v31.AST_NO		=	v21.AST_NO
								   AND	v31.CHG_END_DT	=	(	SELECT	MAX(v41.CHG_END_DT)
																  FROM	VN.GGA22M02	v41
																 WHERE	v41.AST_NO		=	v21.AST_NO
																   AND	TO_DATE(I_LAST_DAY, 'YYYY/MM/DD')	BETWEEN	TRUNC(v41.CHG_STAT_DT)	AND	TRUNC(v41.CHG_END_DT)
															)
							)							AS	AGNC_BRCH,
							v21.DEPT_CD					AS	DEPT_CD,
							v21.USE_YY_CNT				AS	USE_YY_CNT,
							v21.DLM_AMT					AS	DLM_AMT,
							v21.DEPR_METH				AS	DEPR_METH,
							(	SELECT	v31.CHG_STAT			AS	CHG_STAT
								  FROM	VN.GGA22M01	v31
								 WHERE	v31.AST_NO									=	v21.AST_NO
								   AND	v31.CHG_DT||TRIM(TO_CHAR(v31.CHG_SN,'000'))	=	(	SELECT	MAX(v41.CHG_DT||TRIM(TO_CHAR(v41.CHG_SN,'000')))
																							  FROM	VN.GGA22M01	v41
																							 WHERE	v41.AST_NO		=	v21.AST_NO
																							   AND	v41.CHG_DT		<=	I_LAST_DAY
																						)
							)							AS	AST_STAT,
							(	SELECT	v31.CHG_DT		AS	CHG_DT
								  FROM	VN.GGA22M01	v31
								 WHERE	v31.AST_NO									=	v21.AST_NO
								   AND	v31.CHG_DT||TRIM(TO_CHAR(v31.CHG_SN,'000'))	=	(	SELECT	MAX(v41.CHG_DT||TRIM(TO_CHAR(v41.CHG_SN,'000')))
																							  FROM	VN.GGA22M01	v41
																							 WHERE	v41.AST_NO		=	v21.AST_NO
																							   AND	v41.CHG_DT		<=	I_LAST_DAY
																						)
							)							AS	AST_STAT_DT,
							v21.GET_DT					AS	GET_DT,
							v21.DEPR_END_DT				AS	DEPR_END_DT,
							v21.DISP_DT					AS	DISP_DT,
							NVL(v21.GET_AMT, 0)			AS	GET_AMT
					  FROM	VN.GGA22M00	v21
					 WHERE	v21.DEPR_METH		IN	('0')							/* 상각방법(0:상각안함) */
					   AND	v21.GET_DT			<=	I_LAST_DAY						/* 취득일자 <= 상각일 */
					   AND	(v21.DISP_DT		IS NULL
					    OR	v21.DISP_DT			<	SUBSTR(I_YYMM, 1, 6) || '01')	/* 처분일자 <= 상각일(01) */
				)			v11
		 WHERE	v11.BRCH_CD			=	I_BRCH_CD
		   AND	v11.AGNC_BRCH		=	I_AGNC_BRCH
		   AND	v11.AST_STAT		IN	('A', 'B', 'C', 'E', 'F', 'I', 'M')		/* A:신규취득,B:자본적지출,C:당기상각,E:자산수관,F:타계정대체입,I:자산분리B,M:자산병합B */
		   AND	(v11.AST_STAT_DT	IS NULL
		    OR	v11.AST_STAT_DT		<=	I_LAST_DAY)								/* 자산상태일자 <= 상각일 */
	  ORDER BY	v11.AST_NO,
				v11.BRCH_CD,
				v11.AGNC_BRCH ;


        -- CHK_2. 일반자산 년상각액 회기초 생성자료 조회
        FOR C1 IN
			(	SELECT	v11.AST_NO					AS	AST_NO,
						v11.BRCH_CD					AS	BRCH_CD,
						v11.AGNC_BRCH				AS	AGNC_BRCH,
						v11.DEPT_CD					AS	DEPT_CD,
						v11.DEPR_METH				AS	DEPR_METH,
						NVL(v11.USE_YY_CNT, 0)		AS	USE_YY_CNT,
						NVL(v11.DLM_AMT, 0)			AS	DLM_AMT,
						NVL(v11.DEPR_RT, 0.0)		AS	DEPR_RT,
						NVL(v11.GET_AMT, 0)			AS	GET_AMT,
						NVL(v11.BPRD_DEPR_CUM, 0)	AS	BPRD_DEPR_CUM,
						v11.GET_DT					AS	GET_DT,
						v11.DEPR_END_DT				AS	DEPR_END_DT,
						v11.DISP_DT					AS	DISP_DT,
						v11.AST_STAT				AS	AST_STAT,
						v11.AST_STAT_DT				AS	AST_STAT_DT
				  FROM
						(	SELECT	v21.AST_NO					AS	AST_NO,
									v21.DEPR_METH				AS	DEPR_METH,
									v21.DEPT_CD					AS	DEPT_CD,
									NVL(v21.USE_YY_CNT, 0)		AS	USE_YY_CNT,
									NVL(v21.DLM_AMT, 0)			AS	DLM_AMT,
									NVL(v21.DEPR_RT, 0.0)		AS	DEPR_RT,
									NVL(v21.GET_AMT, 0)			AS	GET_AMT,
									(	SELECT	NVL(v31.BPRD_DEPR_CUM, 0) + NVL(v31.TPRD_DEPR_CUM, 0)	AS	BPRD_DEPR_CUM
										  FROM	VN.GGA23M01	v31
										 WHERE	v31.TERMS	=	(I_TERMS - 1)
										   AND	v31.DEPR_YY	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS - 1, '1'), 1, 4)
										   AND	v31.AST_NO	=	v21.AST_NO
									)							AS	BPRD_DEPR_CUM,
									v21.GET_DT					AS	GET_DT,
									v21.DEPR_END_DT				AS	DEPR_END_DT,
									v21.DISP_DT					AS	DISP_DT,
									(	SELECT	v31.BRCH_CD		AS	BRCH_CD
										  FROM	VN.GGA22M02	v31
										 WHERE	v31.AST_NO		=	v21.AST_NO
										   AND	v31.CHG_END_DT	=	(	SELECT	MAX(v41.CHG_END_DT)
																		  FROM	VN.GGA22M02	v41
																		 WHERE	v41.AST_NO		=	v21.AST_NO
																		   AND	TO_DATE(I_LAST_DAY, 'YYYY/MM/DD')	BETWEEN	TRUNC(v41.CHG_STAT_DT)	AND	TRUNC(v41.CHG_END_DT)
																	)
									)							AS	BRCH_CD,
									(	SELECT	v21.AGNC_BRCH	AS	AGNC_BRCH
										  FROM	VN.GGA22M02	v31
										 WHERE	v31.AST_NO		=	v21.AST_NO
										   AND	v31.CHG_END_DT	=	(	SELECT	MAX(v41.CHG_END_DT)
																		  FROM	VN.GGA22M02	v41
																		 WHERE	v41.AST_NO		=	v21.AST_NO
																		   AND	TO_DATE(I_LAST_DAY, 'YYYY/MM/DD')	BETWEEN	TRUNC(v41.CHG_STAT_DT)	AND	TRUNC(v41.CHG_END_DT)
																	)
									)							AS	AGNC_BRCH,
									(	SELECT	v31.CHG_STAT			AS	CHG_STAT
										  FROM	VN.GGA22M01	v31
										 WHERE	v31.AST_NO									=	v21.AST_NO
										   AND	v31.CHG_DT||TRIM(TO_CHAR(v31.CHG_SN,'000'))	=	(	SELECT	MAX(v41.CHG_DT||TRIM(TO_CHAR(v41.CHG_SN,'000')))
																									  FROM	VN.GGA22M01	v41
																									 WHERE	v41.AST_NO		=	v21.AST_NO
																									   AND	v41.CHG_DT		<=	I_LAST_DAY
																								)
									)							AS	AST_STAT,
									(	SELECT	v31.CHG_DT		AS	CHG_DT
										  FROM	VN.GGA22M01	v31
										 WHERE	v31.AST_NO									=	v21.AST_NO
										   AND	v31.CHG_DT||TRIM(TO_CHAR(v31.CHG_SN,'000'))	=	(	SELECT	MAX(v41.CHG_DT||TRIM(TO_CHAR(v41.CHG_SN,'000')))
																									  FROM	VN.GGA22M01	v41
																									 WHERE	v41.AST_NO		=	v21.AST_NO
																									   AND	v41.CHG_DT		<=	I_LAST_DAY
																								)
									)							AS	AST_STAT_DT
							  FROM	VN.GGA22M00	v21
							 WHERE	v21.DEPR_METH		IN	('1', '2')						/* 상각방법(1:정액,2:정율) */
							   AND	v21.GET_DT			<=	I_LAST_DAY						/* 취득일자 <= 상각일 */
							   AND	(v21.DEPR_END_DT	IS NULL
							    OR	v21.DEPR_END_DT		<=	I_LAST_DAY)						/* 상각완료일자 <= 상각일 */
							   AND	(v21.DISP_DT		IS NULL
							    OR	v21.DISP_DT			<	SUBSTR(I_YYMM, 1, 6) || '01')	/* 처분일자 <= 상각일(01) */
						)			v11
				 WHERE	v11.BRCH_CD			=	I_BRCH_CD
				   AND	v11.AGNC_BRCH		=	I_AGNC_BRCH
				   AND	v11.AST_STAT		IN	('A', 'B', 'C', 'E', 'F', 'I', 'M')		/* A:신규취득,B:자본적지출,C:당기상각,E:자산수관,F:타계정대체입,I:자산분리B,M:자산병합B */
				   AND	(v11.AST_STAT_DT	IS NULL
				    OR	v11.AST_STAT_DT		<=	I_LAST_DAY)								/* 자산상태일자 <= 상각일 */
			  ORDER BY	v11.AST_NO,
						v11.BRCH_CD,
						v11.AGNC_BRCH
            ) LOOP

			T_AST_NO := C1.AST_NO ;
			T_TPRD_DEPR_CUM := 0 ;

	        -- CHK_3. 년상각액 구하기
			BEGIN
				T_PST_DEPR_AMT	:=	VN.FGG_AST_RTRN_DEPR(
										'0',						-- 년상각금액
										I_TERMS,					-- 회계기수
										I_YYMM,						-- 처리월
										I_LAST_DAY,					-- 처리일
										C1.DEPR_METH,				-- 상각방법
										C1.DEPR_RT,					-- 상각율
										C1.GET_DT,					-- 취득일자
										C1.USE_YY_CNT,				-- 사용년수
										C1.DLM_AMT,					-- 잔존가액
										C1.GET_AMT,					-- 취득금액
										C1.BPRD_DEPR_CUM,			-- 전기상각누계액
										T_TPRD_DEPR_CUM) ;			-- 당기상각누계액

		    EXCEPTION WHEN OTHERS THEN
		        RAISE ERR_FGG_AST_RTRN_DEPR;
		    END;


	        -- CHK_4. 일반자산 년상각액 회기초 처리 Insert
			BEGIN
		        INSERT
		          INTO  VN.GGA23M01(
						TERMS,
						DEPR_YY,
						AST_NO,
						BRCH_CD,
						AGNC_BRCH,
						DEPT_CD,
						PST_DEPR_AMT,
						DEPR_AMT_01,
						DEPR_AMT_02,
						DEPR_AMT_03,
						DEPR_AMT_04,
						DEPR_AMT_05,
						DEPR_AMT_06,
						DEPR_AMT_07,
						DEPR_AMT_08,
						DEPR_AMT_09,
						DEPR_AMT_10,
						DEPR_AMT_11,
						DEPR_AMT_12,
						GET_AMT,
						BPRD_DEPR_CUM,
						TPRD_DEPR_CUM,
						NDEPR_REMN,
						USE_YN,
						WORK_MN,
						WORK_DTM,
						WORK_TRM,
						MDFY_MN,
						MDFY_DTM,
						MDFY_TRM )
     	       VALUES  (I_TERMS,
						SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4),
						C1.AST_NO,
						I_BRCH_CD,
						I_AGNC_BRCH,
						C1.DEPT_CD,
						T_PST_DEPR_AMT,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						C1.GET_AMT,
						C1.BPRD_DEPR_CUM,
						0,
						(C1.GET_AMT - C1.BPRD_DEPR_CUM),
						'Y',
						I_WORK_MN,
						SYSDATE,
						I_WORK_TRM,
						I_WORK_MN,
						SYSDATE,
						I_WORK_TRM );

		    EXCEPTION WHEN OTHERS THEN
		        RAISE ERR_GGA23M01_INS;
		    END;


        END LOOP;   -- C1 End Loop


    -- ************************
    -- * 년상각액 회기중 처리 *
    -- ************************
    ELSE

        -- CHK_1. 토지/미상각자산 년상각액 회기중 처리
		MERGE	INTO	VN.GGA23M01	v0
			USING	(	SELECT	I_TERMS						AS	TERMS,
								SUBSTR(I_YYMM, 1, 4)		AS	DEPR_YY,
								v11.AST_NO					AS	AST_NO,
								v11.BRCH_CD					AS	BRCH_CD,
								v11.AGNC_BRCH				AS	AGNC_BRCH,
								v11.DEPT_CD					AS	DEPT_CD,
								0							AS	PST_DEPR_AMT,
								0							AS	DEPR_AMT_01,
								0							AS	DEPR_AMT_02,
								0							AS	DEPR_AMT_03,
								0							AS	DEPR_AMT_04,
								0							AS	DEPR_AMT_05,
								0							AS	DEPR_AMT_06,
								0							AS	DEPR_AMT_07,
								0							AS	DEPR_AMT_08,
								0							AS	DEPR_AMT_09,
								0							AS	DEPR_AMT_10,
								0							AS	DEPR_AMT_11,
								0							AS	DEPR_AMT_12,
								NVL(v11.GET_AMT, 0)			AS	GET_AMT,
								0							AS	BPRD_DEPR_CUM,
								0							AS	TPRD_DEPR_CUM,
								NVL(v11.GET_AMT, 0)			AS	NDEPR_REMN,
				                'Y'                         AS  USE_YN,
								I_WORK_MN					AS	WORK_MN,
								SYSDATE						AS	WORK_DTM,
								I_WORK_TRM					AS	WORK_TRM,
								I_WORK_MN					AS	MDFY_MN,
								SYSDATE						AS	MDFY_DTM,
								I_WORK_TRM					AS	MDFY_TRM
						  FROM
								(	SELECT	v21.AST_NO					AS	AST_NO,
											(	SELECT	v31.BRCH_CD		AS	BRCH_CD
												  FROM	VN.GGA22M02	v31
												 WHERE	v31.AST_NO		=	v21.AST_NO
												   AND	v31.CHG_END_DT	=	(	SELECT	MAX(v41.CHG_END_DT)
																				  FROM	VN.GGA22M02	v41
																				 WHERE	v41.AST_NO		=	v21.AST_NO
																				   AND	TO_DATE(I_LAST_DAY, 'YYYY/MM/DD')	BETWEEN	TRUNC(v41.CHG_STAT_DT)	AND	TRUNC(v41.CHG_END_DT)
																			)
											)							AS	BRCH_CD,
											(	SELECT	v21.AGNC_BRCH	AS	AGNC_BRCH
												  FROM	VN.GGA22M02	v31
												 WHERE	v31.AST_NO		=	v21.AST_NO
												   AND	v31.CHG_END_DT	=	(	SELECT	MAX(v41.CHG_END_DT)
																				  FROM	VN.GGA22M02	v41
																				 WHERE	v41.AST_NO		=	v21.AST_NO
																				   AND	TO_DATE(I_LAST_DAY, 'YYYY/MM/DD')	BETWEEN	TRUNC(v41.CHG_STAT_DT)	AND	TRUNC(v41.CHG_END_DT)
																			)
											)							AS	AGNC_BRCH,
											v21.DEPT_CD					AS	DEPT_CD,
											v21.USE_YY_CNT				AS	USE_YY_CNT,
											v21.DLM_AMT					AS	DLM_AMT,
											v21.DEPR_METH				AS	DEPR_METH,
											(	SELECT	v31.CHG_STAT			AS	CHG_STAT
												  FROM	VN.GGA22M01	v31
												 WHERE	v31.AST_NO									=	v21.AST_NO
												   AND	v31.CHG_DT||TRIM(TO_CHAR(v31.CHG_SN,'000'))	=	(	SELECT	MAX(v41.CHG_DT||TRIM(TO_CHAR(v41.CHG_SN,'000')))
																											  FROM	VN.GGA22M01	v41
																											 WHERE	v41.AST_NO		=	v21.AST_NO
																											   AND	v41.CHG_DT		<=	I_LAST_DAY
																										)
											)							AS	AST_STAT,
											(	SELECT	v31.CHG_DT		AS	CHG_DT
												  FROM	VN.GGA22M01	v31
												 WHERE	v31.AST_NO									=	v21.AST_NO
												   AND	v31.CHG_DT||TRIM(TO_CHAR(v31.CHG_SN,'000'))	=	(	SELECT	MAX(v41.CHG_DT||TRIM(TO_CHAR(v41.CHG_SN,'000')))
																											  FROM	VN.GGA22M01	v41
																											 WHERE	v41.AST_NO		=	v21.AST_NO
																											   AND	v41.CHG_DT		<=	I_LAST_DAY
																										)
											)							AS	AST_STAT_DT,
											v21.GET_DT					AS	GET_DT,
											v21.DEPR_END_DT				AS	DEPR_END_DT,
											v21.DISP_DT					AS	DISP_DT,
											NVL(v21.GET_AMT, 0)			AS	GET_AMT
									  FROM	VN.GGA22M00	v21
									 WHERE	v21.DEPR_METH		IN	('0')							/* 상각방법(0:상각안함) */
									   AND	v21.GET_DT			>=	SUBSTR(I_YYMM, 1, 6) || '01'
									   AND	v21.GET_DT			<=	I_LAST_DAY						/* 취득일자 <= 상각일 */
									   AND	(v21.DISP_DT		IS NULL
									    OR	v21.DISP_DT			<	SUBSTR(I_YYMM, 1, 6) || '01')	/* 처분일자 <= 상각일(01) */
								)			v11
						 WHERE	v11.BRCH_CD			=	I_BRCH_CD
						   AND	v11.AGNC_BRCH		=	I_AGNC_BRCH
						   AND	v11.AST_STAT		IN	('A', 'B', 'C', 'E', 'F', 'I', 'M')		/* A:신규취득,B:자본적지출,C:당기상각,E:자산수관,F:타계정대체입,I:자산분리B,M:자산병합B */
						   AND	(v11.AST_STAT_DT	IS NULL
						    OR	v11.AST_STAT_DT		<=	I_LAST_DAY) 							/* 자산상태일자 <= 상각일 */
					)			v1
			   ON	(	v0.TERMS	=	v1.TERMS
					AND	v0.DEPR_YY	=	v1.DEPR_YY
			   		AND	v0.AST_NO	=	v1.AST_NO)

		WHEN	MATCHED	THEN
            UPDATE
               SET  v0.BRCH_CD			=	v1.BRCH_CD,
					v0.AGNC_BRCH		=	v1.AGNC_BRCH,
					v0.DEPT_CD			=	v1.DEPT_CD,
					v0.PST_DEPR_AMT		=	v1.PST_DEPR_AMT,
					v0.DEPR_AMT_01		=	v1.DEPR_AMT_01,
					v0.DEPR_AMT_02		=	v1.DEPR_AMT_02,
					v0.DEPR_AMT_03		=	v1.DEPR_AMT_03,
					v0.DEPR_AMT_04		=	v1.DEPR_AMT_04,
					v0.DEPR_AMT_05		=	v1.DEPR_AMT_05,
					v0.DEPR_AMT_06		=	v1.DEPR_AMT_06,
					v0.DEPR_AMT_07		=	v1.DEPR_AMT_07,
					v0.DEPR_AMT_08		=	v1.DEPR_AMT_08,
					v0.DEPR_AMT_09		=	v1.DEPR_AMT_09,
					v0.DEPR_AMT_10		=	v1.DEPR_AMT_10,
					v0.DEPR_AMT_11		=	v1.DEPR_AMT_11,
					v0.DEPR_AMT_12		=	v1.DEPR_AMT_12,
					v0.GET_AMT			=	v1.GET_AMT,
					v0.BPRD_DEPR_CUM	=	v1.BPRD_DEPR_CUM,
					v0.TPRD_DEPR_CUM	=	v1.TPRD_DEPR_CUM,
					v0.NDEPR_REMN		=	v1.NDEPR_REMN,
					v0.USE_YN			=	v1.USE_YN,
					v0.MDFY_MN			=	v1.MDFY_MN,
					v0.MDFY_DTM			=	v1.MDFY_DTM,
					v0.MDFY_TRM			=	v1.MDFY_TRM

		WHEN	NOT MATCHED	THEN
	        INSERT	(v0.TERMS,
					v0.DEPR_YY,
					v0.AST_NO,
					v0.BRCH_CD,
					v0.AGNC_BRCH,
					v0.DEPT_CD,
					v0.PST_DEPR_AMT,
					v0.DEPR_AMT_01,
					v0.DEPR_AMT_02,
					v0.DEPR_AMT_03,
					v0.DEPR_AMT_04,
					v0.DEPR_AMT_05,
					v0.DEPR_AMT_06,
					v0.DEPR_AMT_07,
					v0.DEPR_AMT_08,
					v0.DEPR_AMT_09,
					v0.DEPR_AMT_10,
					v0.DEPR_AMT_11,
					v0.DEPR_AMT_12,
					v0.GET_AMT,
					v0.BPRD_DEPR_CUM,
					v0.TPRD_DEPR_CUM,
					v0.NDEPR_REMN,
					v0.USE_YN,
					v0.WORK_MN,
					v0.WORK_DTM,
					v0.WORK_TRM,
					v0.MDFY_MN,
					v0.MDFY_DTM,
					v0.MDFY_TRM )
			VALUES	(v1.TERMS,
					v1.DEPR_YY,
					v1.AST_NO,
					v1.BRCH_CD,
					v1.AGNC_BRCH,
					v1.DEPT_CD,
					v1.PST_DEPR_AMT,
					v1.DEPR_AMT_01,
					v1.DEPR_AMT_02,
					v1.DEPR_AMT_03,
					v1.DEPR_AMT_04,
					v1.DEPR_AMT_05,
					v1.DEPR_AMT_06,
					v1.DEPR_AMT_07,
					v1.DEPR_AMT_08,
					v1.DEPR_AMT_09,
					v1.DEPR_AMT_10,
					v1.DEPR_AMT_11,
					v1.DEPR_AMT_12,
					v1.GET_AMT,
					v1.BPRD_DEPR_CUM,
					v1.TPRD_DEPR_CUM,
					v1.NDEPR_REMN,
					v1.USE_YN,
					v1.WORK_MN,
					v1.WORK_DTM,
					v1.WORK_TRM,
					v1.MDFY_MN,
					v1.MDFY_DTM,
					v1.MDFY_TRM ) ;


        -- CHK_2. 일반자산 년상각액 회기중 생성자료 조회
        FOR C2 IN
			(	SELECT	v11.AST_NO					AS	AST_NO,
						v11.BRCH_CD					AS	BRCH_CD,
						v11.AGNC_BRCH				AS	AGNC_BRCH,
						v11.DEPT_CD					AS	DEPT_CD,
						v11.DEPR_METH				AS	DEPR_METH,
						NVL(v11.USE_YY_CNT, 0)		AS	USE_YY_CNT,
						NVL(v11.DLM_AMT, 0)			AS	DLM_AMT,
						NVL(v11.DEPR_RT, 0.0)		AS	DEPR_RT,
						NVL(v11.GET_AMT, 0)			AS	GET_AMT,
						NVL(v11.BPRD_DEPR_CUM, 0)	AS	BPRD_DEPR_CUM,
						v11.GET_DT					AS	GET_DT,
						v11.DEPR_END_DT				AS	DEPR_END_DT,
						v11.DISP_DT					AS	DISP_DT,
						v11.AST_STAT				AS	AST_STAT,
						v11.AST_STAT_DT				AS	AST_STAT_DT
				  FROM
						(	SELECT	v21.AST_NO					AS	AST_NO,
									v21.DEPT_CD					AS	DEPT_CD,
									v21.DEPR_METH				AS	DEPR_METH,
									NVL(v21.USE_YY_CNT, 0)		AS	USE_YY_CNT,
									NVL(v21.DLM_AMT, 0)			AS	DLM_AMT,
									NVL(v21.DEPR_RT, 0.0)		AS	DEPR_RT,
									NVL(v21.GET_AMT, 0)			AS	GET_AMT,
									(	SELECT	NVL(v31.BPRD_DEPR_CUM, 0) + NVL(v31.TPRD_DEPR_CUM, 0)	AS	BPRD_DEPR_CUM
										  FROM	VN.GGA23M01	v31
										 WHERE	v31.TERMS	=	(I_TERMS - 1)
										   AND	v31.DEPR_YY	=	SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS - 1, '1'), 1, 4)
										   AND	v31.AST_NO	=	v21.AST_NO
									)							AS	BPRD_DEPR_CUM,
									v21.GET_DT					AS	GET_DT,
									v21.DEPR_END_DT				AS	DEPR_END_DT,
									v21.DISP_DT					AS	DISP_DT,
									(	SELECT	v31.BRCH_CD		AS	BRCH_CD
										  FROM	VN.GGA22M02	v31
										 WHERE	v31.AST_NO		=	v21.AST_NO
										   AND	v31.CHG_END_DT	=	(	SELECT	MAX(v41.CHG_END_DT)
																		  FROM	VN.GGA22M02	v41
																		 WHERE	v41.AST_NO		=	v21.AST_NO
																		   AND	TO_DATE(I_LAST_DAY, 'YYYY/MM/DD')	BETWEEN	TRUNC(v41.CHG_STAT_DT)	AND	TRUNC(v41.CHG_END_DT)
																	)
									)							AS	BRCH_CD,
									(	SELECT	v21.AGNC_BRCH	AS	AGNC_BRCH
										  FROM	VN.GGA22M02	v31
										 WHERE	v31.AST_NO		=	v21.AST_NO
										   AND	v31.CHG_END_DT	=	(	SELECT	MAX(v41.CHG_END_DT)
																		  FROM	VN.GGA22M02	v41
																		 WHERE	v41.AST_NO		=	v21.AST_NO
																		   AND	TO_DATE(I_LAST_DAY, 'YYYY/MM/DD')	BETWEEN	TRUNC(v41.CHG_STAT_DT)	AND	TRUNC(v41.CHG_END_DT)
																	)
									)							AS	AGNC_BRCH,
									(	SELECT	v31.CHG_STAT			AS	CHG_STAT
										  FROM	VN.GGA22M01	v31
										 WHERE	v31.AST_NO									=	v21.AST_NO
										   AND	v31.CHG_DT||TRIM(TO_CHAR(v31.CHG_SN,'000'))	=	(	SELECT	MAX(v41.CHG_DT||TRIM(TO_CHAR(v41.CHG_SN,'000')))
																									  FROM	VN.GGA22M01	v41
																									 WHERE	v41.AST_NO		=	v21.AST_NO
																									   AND	v41.CHG_DT		<=	I_LAST_DAY
																								)
									)							AS	AST_STAT,
									(	SELECT	v31.CHG_DT		AS	CHG_DT
										  FROM	VN.GGA22M01	v31
										 WHERE	v31.AST_NO									=	v21.AST_NO
										   AND	v31.CHG_DT||TRIM(TO_CHAR(v31.CHG_SN,'000'))	=	(	SELECT	MAX(v41.CHG_DT||TRIM(TO_CHAR(v41.CHG_SN,'000')))
																									  FROM	VN.GGA22M01	v41
																									 WHERE	v41.AST_NO		=	v21.AST_NO
																									   AND	v41.CHG_DT		<=	I_LAST_DAY
																								)
									)							AS	AST_STAT_DT
							  FROM	VN.GGA22M00	v21
							 WHERE	v21.DEPR_METH		IN	('1', '2')						/* 상각방법(1:정액,2:정율) */
							   AND	v21.GET_DT			>=	SUBSTR(I_YYMM, 1, 6) || '01'
							   AND	v21.GET_DT			<=	I_LAST_DAY						/* 취득일자 <= 상각일 */
							   AND	(v21.DEPR_END_DT	IS NULL
							    OR	v21.DEPR_END_DT		<=	I_LAST_DAY)						/* 상각완료일자 <= 상각일 */
							   AND	(v21.DISP_DT		IS NULL
							    OR	v21.DISP_DT			<	SUBSTR(I_YYMM, 1, 6) || '01')	/* 처분일자 <= 상각일(01) */
						)			v11
				 WHERE	v11.BRCH_CD			=	I_BRCH_CD
				   AND	v11.AGNC_BRCH		=	I_AGNC_BRCH
				   AND	v11.AST_STAT		IN	('A', 'B', 'C', 'E', 'F', 'I', 'M')		/* A:신규취득,B:자본적지출,C:당기상각,E:자산수관,F:타계정대체입,I:자산분리B,M:자산병합B */
				   AND	(v11.AST_STAT_DT	IS NULL
				    OR	v11.AST_STAT_DT		<=	I_LAST_DAY)								/* 자산상태일자 <= 상각일 */
			  ORDER BY	v11.AST_NO,
						v11.BRCH_CD,
						v11.AGNC_BRCH
            ) LOOP

			T_AST_NO := C2.AST_NO ;
			T_TPRD_DEPR_CUM := 0 ;

	        -- CHK_3. 년상각액 구하기
			BEGIN
				T_PST_DEPR_AMT	:=	VN.FGG_AST_RTRN_DEPR(
										'0',						-- 년상각금액
										I_TERMS,					-- 회계기수
										I_YYMM,						-- 처리월
										I_LAST_DAY,					-- 처리일
										C2.DEPR_METH,				-- 상각방법
										C2.DEPR_RT,					-- 상각율
										C2.GET_DT,					-- 취득일자
										C2.USE_YY_CNT,				-- 사용년수
										C2.DLM_AMT,					-- 잔존가액
										C2.GET_AMT,					-- 취득금액
										C2.BPRD_DEPR_CUM,			-- 전기상각누계액
										T_TPRD_DEPR_CUM) ;			-- 당기상각누계액

		    EXCEPTION WHEN OTHERS THEN
		        RAISE ERR_FGG_AST_RTRN_DEPR;
		    END;


	        -- CHK_4. 일반자산 년상각액 회기중 처리 Insert
	        T_CNT   := 0 ;
			SELECT	COUNT(*)
			  INTO  T_CNT
			  FROM	VN.GGA23M01
			 WHERE	TERMS  		=	I_TERMS
			   AND	DEPR_YY		=   SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
			   AND	AST_NO		=	C2.AST_NO  ;

	        IF  T_CNT   >=  1   THEN

				BEGIN
	                UPDATE  VN.GGA23M01
		               SET  BRCH_CD			=	I_BRCH_CD,
							AGNC_BRCH		=	I_AGNC_BRCH,
							DEPT_CD			=	C2.DEPT_CD,
							PST_DEPR_AMT	=	T_PST_DEPR_AMT,
							DEPR_AMT_01		=	0,
							DEPR_AMT_02		=	0,
							DEPR_AMT_03		=	0,
							DEPR_AMT_04		=	0,
							DEPR_AMT_05		=	0,
							DEPR_AMT_06		=	0,
							DEPR_AMT_07		=	0,
							DEPR_AMT_08		=	0,
							DEPR_AMT_09		=	0,
							DEPR_AMT_10		=	0,
							DEPR_AMT_11		=	0,
							DEPR_AMT_12		=	0,
							GET_AMT			=	C2.GET_AMT,
							BPRD_DEPR_CUM	=	C2.BPRD_DEPR_CUM,
							TPRD_DEPR_CUM	=	0,
							NDEPR_REMN		=	(C2.GET_AMT - C2.BPRD_DEPR_CUM),
							USE_YN			=	'Y',
							MDFY_MN			=	I_WORK_MN,
							MDFY_DTM		=	SYSDATE,
							MDFY_TRM		=	I_WORK_TRM
					 WHERE	TERMS  		=	I_TERMS
					   AND	DEPR_YY		=   SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4)
					   AND	AST_NO		=	C2.AST_NO ;

			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA23M01_UPD;
			    END;

			ELSE

				BEGIN
			        INSERT
			          INTO  VN.GGA23M01(
							TERMS,
							DEPR_YY,
							AST_NO,
							BRCH_CD,
							AGNC_BRCH,
							DEPT_CD,
							PST_DEPR_AMT,
							DEPR_AMT_01,
							DEPR_AMT_02,
							DEPR_AMT_03,
							DEPR_AMT_04,
							DEPR_AMT_05,
							DEPR_AMT_06,
							DEPR_AMT_07,
							DEPR_AMT_08,
							DEPR_AMT_09,
							DEPR_AMT_10,
							DEPR_AMT_11,
							DEPR_AMT_12,
							GET_AMT,
							BPRD_DEPR_CUM,
							TPRD_DEPR_CUM,
							NDEPR_REMN,
							USE_YN,
							WORK_MN,
							WORK_DTM,
							WORK_TRM,
							MDFY_MN,
							MDFY_DTM,
							MDFY_TRM )
	     	       VALUES  (I_TERMS,
							SUBSTR(VN.FGG_GET_TERMS_DT(I_TERMS, '1'), 1, 4),
							C2.AST_NO,
							I_BRCH_CD,
							I_AGNC_BRCH,
							C2.DEPT_CD,
							T_PST_DEPR_AMT,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							C2.GET_AMT,
							C2.BPRD_DEPR_CUM,
							0,
							(C2.GET_AMT - C2.BPRD_DEPR_CUM),
							'Y',
							I_WORK_MN,
							SYSDATE,
							I_WORK_TRM,
							I_WORK_MN,
							SYSDATE,
							I_WORK_TRM );

			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA23M01_INS;
			    END;

	        END IF;

        END LOOP;   -- C2 End Loop


    END IF;

    O_RTN_TBL  :=  'PGG_AST_RTRN_DEPR0';
    O_RTN_ERR  :=  '0';
    --O_RTN_MSG  :=  '[V0602] 정상적으로 처리되었습니다.';
    O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','0602');
    --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);

EXCEPTION
    WHEN    ERR_FGG_AST_RTRN_DEPR  THEN
        O_RTN_TBL  :=  'ERR_FGG_AST_RTRN_DEPR';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2016]자료가 존재하지 않습니다';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016');
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA23M01_INS  THEN
        O_RTN_TBL  :=  'ERR_GGA23M01_INS';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2627]전표번호 생성중 오류가 발생하였습니다. [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2627') || ' [' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA23M01_UPD  THEN
        O_RTN_TBL  :=  'ERR_GGA23M01_UPD';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2627]전표번호 생성중 오류가 발생하였습니다. [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2627') || ' [' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    OTHERS  THEN
        O_RTN_TBL  :=  'OTHERS';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        O_RTN_MSG  :=  'ERROR ' || SUBSTR(SQLERRM, 1, 100);
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
END PGG_AST_RTRN_DEPR0;
/

