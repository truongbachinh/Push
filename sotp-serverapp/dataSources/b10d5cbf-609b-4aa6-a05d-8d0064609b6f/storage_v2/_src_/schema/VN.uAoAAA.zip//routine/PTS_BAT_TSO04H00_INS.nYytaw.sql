create PROCEDURE PTS_BAT_TSO04H00_INS (
    I_WORK_DT       IN      VARCHAR2,       -- DATE(YYYYMMDD)
    I_WORK_MN		IN		VARCHAR2,
    I_WORK_TRM		IN		VARCHAR2,
	O_PROC_CNT      IN  OUT NUMBER          -- PROC DATA COUNT
) AS


/*!
    \FILE     PTS_BAT_TSO40H00_INS
	\BRIEF    TSO04M00 SELECT, TSO04H00 INSERT

	\SECTION INTRO PROGRAM INFORMATION
		- PROGRAM NAME              : PTS_BAT_TSO04H00_INS
		- SERVICE NAME              :
		- RELATED CLIENT PROGRAM- CLIENT PROGRAM ID :
		- RELATED TABLES            : TSO04M00, TSO04H00
		- DEV. DATE                 : 2008/02/10
		- DEVELOPER                 : SB.LEE
		- BUSINESS LOGIC DESC.      :
		- LATEST MODIFICATION DATE  :

	\SECTION HISTORY PROGRAM MODIFICATION HISTORY
		- 1.0  2008/02/10

	\SECTION HARDCODING HARD-CODING LIST

	\SECTION INFO ADDITIONAL REFERENCE COMMENTS
*/


	t_err_txt				varchar2(200) := Null;

    t_err_msg    varchar2(500);

BEGIN


		delete tso04h00
		where	dt = i_work_dt;

        FOR  C1  IN (
            SELECT  ACNT_NO                   ACNT_NO          ,
            		SUB_NO					  SUB_NO		   ,
                    STK_CD                    STK_CD           ,
                    BANK_CD                   BANK_CD          ,
                    NVL(TD_SELL_ORD_QTY   ,0) TD_SELL_ORD_QTY  ,
                    NVL(TD_SELL_MTH_QTY   ,0) TD_SELL_MTH_QTY  ,
                    NVL(TD_SELL_MTH_AMT   ,0) TD_SELL_MTH_AMT  ,
                    NVL(TD_BUY_MTH_QTY    ,0) TD_BUY_MTH_QTY   ,
                    NVL(TD_BUY_MTH_AMT    ,0) TD_BUY_MTH_AMT   ,
                    NVL(PD_SELL_MTH_QTY   ,0) PD_SELL_MTH_QTY  ,
                    NVL(PD_SELL_MTH_AMT   ,0) PD_SELL_MTH_AMT  ,
                    NVL(PD_BUY_MTH_QTY    ,0) PD_BUY_MTH_QTY   ,
                    NVL(PD_BUY_MTH_AMT    ,0) PD_BUY_MTH_AMT   ,
                    NVL(PPD_SELL_MTH_QTY  ,0) PPD_SELL_MTH_QTY ,
                    NVL(PPD_SELL_MTH_AMT  ,0) PPD_SELL_MTH_AMT ,
                    NVL(PPD_BUY_MTH_QTY   ,0) PPD_BUY_MTH_QTY  ,
                    NVL(PPD_BUY_MTH_AMT   ,0) PPD_BUY_MTH_AMT  ,
                    NVL(PPPD_SELL_MTH_QTY ,0) PPPD_SELL_MTH_QTY,
                    NVL(PPPD_SELL_MTH_AMT ,0) PPPD_SELL_MTH_AMT,
                    NVL(PPPD_BUY_MTH_QTY  ,0) PPPD_BUY_MTH_QTY ,
                    NVL(PPPD_BUY_MTH_AMT  ,0) PPPD_BUY_MTH_AMT ,
                    nvl(WORK_MN  ,  'SELECT') WORK_MN          ,
                    nvl(WORK_DTM ,  SYSDATE ) WORK_DTM         ,
                    nvl(WORK_TRM ,  'SELECT') WORK_TRM
              FROM  VN.TSO04M00
             WHERE  (TD_SELL_ORD_QTY     > 0 OR TD_SELL_MTH_QTY   > 0 OR TD_SELL_MTH_AMT   > 0
                     OR TD_BUY_MTH_QTY   > 0 OR TD_BUY_MTH_AMT    > 0 OR PD_SELL_MTH_QTY   > 0
                     OR PD_SELL_MTH_AMT  > 0 OR PD_BUY_MTH_QTY    > 0 OR PD_BUY_MTH_AMT    > 0
                     OR PPD_SELL_MTH_QTY > 0 OR PPD_SELL_MTH_AMT  > 0 OR PPD_BUY_MTH_QTY   > 0
                     OR PPD_BUY_MTH_AMT  > 0 OR PPPD_SELL_MTH_QTY > 0 OR PPPD_SELL_MTH_AMT > 0
                     OR PPPD_BUY_MTH_QTY > 0 OR PPPD_BUY_MTH_AMT  > 0 )
        ) LOOP

			BEGIN
	            INSERT INTO VN.TSO04H00 (
	                DT                      ,
	                ACNT_NO                 ,
	                SUB_NO					,
	                STK_CD                  ,
	                BANK_CD                 ,
	                TD_SELL_ORD_QTY         ,
	                TD_SELL_MTH_QTY         ,
	                TD_SELL_MTH_AMT         ,
	                TD_BUY_MTH_QTY          ,
	                TD_BUY_MTH_AMT          ,
	                PD_SELL_MTH_QTY         ,
	                PD_SELL_MTH_AMT         ,
	                PD_BUY_MTH_QTY          ,
	                PD_BUY_MTH_AMT          ,
	                PPD_SELL_MTH_QTY        ,
	                PPD_SELL_MTH_AMT        ,
	                PPD_BUY_MTH_QTY         ,
	                PPD_BUY_MTH_AMT         ,
	                PPPD_SELL_MTH_QTY       ,
	                PPPD_SELL_MTH_AMT       ,
	                PPPD_BUY_MTH_QTY        ,
	                PPPD_BUY_MTH_AMT        ,
	                WORK_MN                 ,
	                WORK_DTM                ,
	                WORK_TRM
	            ) VALUES (
	                I_WORK_DT               ,
	                C1.ACNT_NO              ,
	                C1.SUB_NO				,
	                C1.STK_CD               ,
	                C1.BANK_CD              ,
	                C1.TD_SELL_ORD_QTY      ,
	                C1.TD_SELL_MTH_QTY      ,
	                C1.TD_SELL_MTH_AMT      ,
	                C1.TD_BUY_MTH_QTY       ,
	                C1.TD_BUY_MTH_AMT       ,
	                C1.PD_SELL_MTH_QTY      ,
	                C1.PD_SELL_MTH_AMT      ,
	                C1.PD_BUY_MTH_QTY       ,
	                C1.PD_BUY_MTH_AMT       ,
	                C1.PPD_SELL_MTH_QTY     ,
	                C1.PPD_SELL_MTH_AMT     ,
	                C1.PPD_BUY_MTH_QTY      ,
	                C1.PPD_BUY_MTH_AMT      ,
	                C1.PPPD_SELL_MTH_QTY    ,
	                C1.PPPD_SELL_MTH_AMT    ,
	                C1.PPPD_BUY_MTH_QTY     ,
	                C1.PPPD_BUY_MTH_AMT     ,
	                'SYSTEM'                ,
	                SYSDATE                 ,
	                'SYSTEM'
	            );



			EXCEPTION
	        WHEN  OTHERS         THEN
	            vn.pxc_log_write('pts_bat_tso04h00_ins','Insert cwd04h00 Err-['||sqlcode||']');
	            t_err_txt  :=  'Insert tso04h00 Err-'
	                   ||  to_char(sqlcode);
				t_err_msg := vn.fxc_get_err_msg('V','2713');
				raise_application_error(-20100,t_err_msg||t_err_txt);
	    	END;
	    END LOOP;

	O_PROC_CNT := sql%rowcount;



END PTS_BAT_TSO04H00_INS;
/

