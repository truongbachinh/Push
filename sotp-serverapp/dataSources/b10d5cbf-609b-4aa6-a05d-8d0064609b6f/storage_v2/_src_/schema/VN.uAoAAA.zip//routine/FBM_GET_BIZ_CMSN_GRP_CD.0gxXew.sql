create function fbm_get_biz_cmsn_grp_cd(
    i_dt                varchar2,
    i_emp_no            varchar2,
    i_biz_cmsn_tp       varchar2,
    i_biz_cmsn_knd      varchar2
)
return varchar2
/*
    select fbm_get_biz_cmsn_grp_cd(
        vwdate,         -- i_dt                varchar2,
        'dungnn',       -- i_emp_no            varchar2,
        '2',            -- i_biz_cmsn_tp       varchar2,
        '1'             -- i_biz_cmsn_knd      varchar2
    ) a
    from dual;
*/
as
    t_proc_nm                   varchar2(30)    := 'fbm_get_biz_cmsn_grp_cd';
    t_vwdate                    varchar2(8)     := vwdate;
    t_err_msg                   varchar2(500)   := ' ';

    t_biz_cmsn_grp_cd   varchar2(20);

begin
    begin
        select 
            rm31.biz_cmsn_grp_cd
        into
            t_biz_cmsn_grp_cd
        from vn.rms04m00 rm4                      -- Lien ket SPHH - NV
        inner join vn.rms03m00 rm30                     -- Danh muc SPHH
        on rm4.biz_prd_cd = rm30.biz_prd_cd
        and rm30.biz_cmsn_tp = i_biz_cmsn_tp
        inner join vn.rms03m01 rm31                     -- Chi tiet SPHH
        on rm30.biz_prd_cd = rm31.biz_prd_cd
        and rm31.biz_cmsn_knd = i_biz_cmsn_knd
        and rm31.active_stat = 'Y'
        and (rm31.biz_prd_cd, rm31.biz_cmsn_knd, rm31.apy_dt) in 
            (select rm311.biz_prd_cd, rm311.biz_cmsn_knd, max(rm311.apy_dt)
            from vn.rms03m01 rm311
            where rm311.biz_prd_cd = rm30.biz_prd_cd
            and rm311.biz_cmsn_knd = i_biz_cmsn_knd
            and rm311.active_stat = 'Y'
            and rm311.apy_dt <= i_dt
            group by rm311.biz_prd_cd, rm311.biz_cmsn_knd
            )
        where rm4.emp_no = i_emp_no
        and i_dt between rm4.apy_dt and rm4.expr_dt
        and rm4.active_stat = 'Y'
        ;
    exception
        when no_data_found then
            t_biz_cmsn_grp_cd := '!';
        when others then
            t_err_msg  := 'Error when getting biz_cmsn_grp_cd for:' 
                                    || ' i_dt: '            || i_dt
                                    || ' i_emp_no: '        || i_emp_no
                                    || ' i_biz_cmsn_tp: '   || i_biz_cmsn_tp
                                    || ' i_biz_cmsn_knd: '  || i_biz_cmsn_knd
                                    || '. Error: '          || sqlcode || ' - '     || sqlerrm;
            vn.pxc_log_write(t_proc_nm, t_err_msg);
            raise_application_error(-20100,t_err_msg);
    end;

    return t_biz_cmsn_grp_cd;

end;
/

