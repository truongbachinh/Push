create function fcw_inout_cnfm_lim_q
(
    i_brch_cd   in   varchar2
,   i_proc_tp   in   varchar2
)

	return          number
as
    o_trd_amt	number := 0;
    t_err_txt       varchar2(100)  ; -- error text buffer

begin

    BEGIN
		select trd_amt
		into  o_trd_amt
		from vn.cwd07m00
		where inout_tp	= i_proc_tp
		and brch_cd		= i_brch_cd
		and mng_end_dt	= to_date('30000101','yyyymmdd')
		;
    EXCEPTION
        WHEN  NO_DATA_FOUND  THEN
			return 0;
        WHEN  OTHERS         THEN
            t_err_txt  :=  '['||to_char(sqlcode)||']';
            raise_application_error (-20100, t_err_txt);
    END;

    return  o_trd_amt;
 
end fcw_inout_cnfm_lim_q;
/

