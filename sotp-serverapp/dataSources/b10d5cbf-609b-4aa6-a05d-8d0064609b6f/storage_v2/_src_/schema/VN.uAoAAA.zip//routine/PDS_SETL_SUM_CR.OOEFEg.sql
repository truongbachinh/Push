create procedure    pds_setl_sum_cr
(
	i_dt          in     varchar2,        --
	i_work_mn     in     varchar2,        -- user id
	i_work_trm    in     varchar2,
	o_cnt         in out number
) AS

/*!
   \file     pds_setl_sum_cr.sql
   \brief    previous settlement creation

   \section intro Program Information
        - Program Name              : create settle data
        - Service Name              : N/A
        - Related Client Program- Client Program ID : N/A
        - Related Tables            : dsc01m00, dsc02m00
        - Dev. Date                 : 2007/11/08
        - Developer                 : Han.
        - Business Logic Desc.      : create settle data
        - Latest Modification Date  : 2007/11/08

   \section history Program Modification History
    - 1.0       2007/11/08     Han.    New.

   \section hardcoding Hard-Coding List
    - HC-1      2007/11/08     Han.    [??]

   \section info Additional Reference Comments
    - ?????? ???var a number;
exec vn.pds_setl_sum_cr('20080313','DAILY','SYSTEM',:a);
*/

    t_setl_dt           varchar2(8) := null;
    t_dt                varchar2(8) := null;

    t_mng_brch_cd       varchar2(3) := null;
    t_agnc_brch         varchar2(2) := null;

    t_bank_cd           varchar2(4) := null;

    t_trd_seq_no        number      := 0;
    t_rmrk_job_tp       varchar2(2) := null;
    t_rmrk_trd_tp       varchar2(3) := null;

    ts_work_stat_min    VARCHAR2(1);
    ts_work_stat_max    VARCHAR2(1);

    t_err_msg           varchar2(500);

begin

    o_cnt := 0;

    /*========================================================================*/
    /* Input Date CHECK                                                       */
    /*========================================================================*/
    if  vn.fxc_holi_ck(to_date(i_dt,'yyyymmdd')) !=  '0' then
    	if  i_work_mn <> 'DAILY' then
	        t_err_msg := vn.fxc_get_err_msg('V','2422');
	        t_err_msg := t_err_msg||' Date = '||i_dt;
	        raise_application_error(-20100,t_err_msg);
		else
			return;
		end if;
	end if;

    if  vn.vwdate  !=  i_dt then
        t_err_msg := vn.fxc_get_err_msg('V','2422');
        raise_application_error(-20100,t_err_msg||' Date = '||i_dt);
    end if;


    /*========================================================================*/
    /* Prededing job Check                                                    */
    /*========================================================================*/
    if fxb_daily_stat_chk ('B','0','2200','2500','*') <> 'Y' then
        t_err_msg := vn.fxc_get_err_msg('V','2458');
        t_err_msg := t_err_msg||'[2200],[2500]'||i_dt;
        raise_application_error(-20100,t_err_msg);
    end if;

    /*========================================================================*/
    /* Date Check                                                             */
    /*========================================================================*/
    t_setl_dt := i_dt;

    t_dt      := vn.fxc_vorderdt_g(to_date(t_setl_dt,'yyyymmdd'), -3);

    /*========================================================================*/
    /* Delete pre-data for reprocessing                                       */
    /*========================================================================*/
	delete from vn.dsc02m00
	 where setl_dt = t_setl_dt;

/*============================================================================*/
/* ( )                                                                        */
/*============================================================================*/

    for C1 in (
        select  a.acnt_mng_bnh  acnt_mng_bnh
             ,  a.agnc_brch     agnc_brch
             ,  a.mth_dt        mth_dt
             ,  a.stk_tp        stk_tp
             ,  a.mkt_trd_tp    mkt_trd_tp
             ,  b.acnt_tp       acnt_tp
             ,  a.sb_tp         sb_tp
             ,  a.cdt_tp        cdt_tp
             ,  a.mdm_tp        mdm_tp
             ,  sum(a.sb_qty)   sb_qty
             ,  sum(a.sb_amt)   sb_amt
             ,  sum(a.sb_cmsn)  sb_cmsn
             ,  sum(a.sb_tax)   sb_tax
             ,  sum(a.sb_fee)   sb_fee
          from  vn.dsc01m00 a, vn.aaa01m00 b
         where  a.setl_dt          =  t_setl_dt
           and  a.acnt_no          =  b.acnt_no
           and  a.sub_no           =  b.sub_no
           and  a.dpo_setl_yn      =  'Y'
           and  a.stk_setl_yn      =  'Y'
           and  a.cmsn_setl_yn     =  'Y'
           and  a.tax_setl_yn      =  'Y'
           and  a.stk_setl_fee_yn  =  'Y'
         group  by  a.acnt_mng_bnh, a.agnc_brch, a.mth_dt, a.stk_tp,
                    a.mkt_trd_tp,   b.acnt_tp,   a.sb_tp,  a.cdt_tp, a.mdm_tp
         order  by  a.acnt_mng_bnh, a.agnc_brch, a.mth_dt, a.stk_tp,
                    a.mkt_trd_tp,   b.acnt_tp,   a.sb_tp,  a.cdt_tp, a.mdm_tp
    ) loop
        o_cnt := o_cnt + 1;


        insert into vn.dsc02m00 (
            SETL_DT,        ACNT_MNG_BNH,   AGNC_BRCH,
            STK_TP,         MKT_TRD_TP,     ACNT_TP,
            SB_TP,          CDT_TP,
            MDM_TP,         MTH_DT,
            SB_QTY,         SB_AMT,
            SB_CMSN,        SB_TAX,        sb_fee,
            WORK_MN,        WORK_DTM,       WORK_TRM
        )
        values (
            t_setl_dt,      C1.acnt_mng_bnh, C1.agnc_brch,
            C1.stk_tp,      C1.mkt_trd_tp,   C1.acnt_tp,
            C1.sb_tp,       C1.cdt_tp,
            C1.mdm_tp,      C1.mth_dt,
            C1.sb_qty,      C1.sb_amt,
            C1.sb_cmsn,     C1.sb_tax,       C1.sb_fee,
            i_work_mn,      sysdate,         i_work_trm
        );



    end loop;

end pds_setl_sum_cr;
/

