create PROCEDURE PSS_CASH_INAMT_P
(   I_TRD_DT       	IN      VARCHAR2,
    I_ACNT_NO       IN      VARCHAR2,
    I_SUB_NO        IN      VARCHAR2,
    I_RMRK_CD       IN      VARCHAR2,
    I_CASH       	IN      VARCHAR2,
    I_MDM_TP       	IN      VARCHAR2,
    I_TR_CD       	IN      VARCHAR2,
    I_CNFM_YN       IN      VARCHAR2,
    I_DEPT_NO1      IN      VARCHAR2,
    I_WORK_MN       IN      VARCHAR2,
    I_WORK_TRM      IN      VARCHAR2,
	O_TRD_SEQ_NO    OUT     NUMBER,
    O1_RTN_TBL      OUT     VARCHAR2,
	O1_RTN_ERR      OUT     VARCHAR2,
	O1_RTN_MSG      OUT     VARCHAR2
	) IS


    -- Constants

    -- Variables
    T_CNT           	NUMBER := 0 ;						-- CHECK Count
    o_cnt               number := 0 ;
    t_err_txt           varchar2(200) := null ;
    t_err_msg           varchar2(200) := null ;
	T_ACNT_NO			VN.AAA10M00.ACNT_NO%TYPE ;

	T_ACNT_STAT			VN.AAA01M00.ACNT_STAT%TYPE ;

    TN_DPO				NUMBER := 0 ;
    tn_dpo_block    	NUMBER := 0 ;
    tn_outq_dpo_bk    	NUMBER := 0 ;
	tn_reuse_dpo        number := 0 ;
	tn_sbst_dpo         number := 0 ;
	tn_sbst_able_block  number := 0 ;
	tn_sbst_proof       number := 0 ;
    TN_GST_DPO			NUMBER := 0 ;
    tn_use_vd			NUMBER := 0 ;
    tn_nonrpy_loan_amt	NUMBER := 0 ;
    tn_mgn_loan_amt	    NUMBER := 0 ;
    tn_mgn_lack    	    NUMBER := 0 ;
    tn_cd_lack    	    NUMBER := 0 ;
    TN_CRD_DPO	        NUMBER := 0 ;					--
    tn_used_alowa_rel	NUMBER := 0 ;
    tn_used_alowa_cd	number := 0 ;					--
    tn_used_alowa_vit	NUMBER := 0 ;
    tn_used_tmp        	NUMBER := 0 ;
    tn_able_block      	NUMBER := 0 ;
	tn_tot_out_psbamt	number := 0 ;
	tn_sb_pri	        number := 0 ;

    TN_DPO_PRERM		NUMBER := 0 ;
    T_TOT_TRD_SEQ_NO	NUMBER := 0 ;

	T_ATDPST_FOUND_YN	VARCHAR2(1) := 'Y' ;


    -- View Variables
	V_ACNT_MNG_BNH		VN.AAA10M00.ACNT_MNG_BNH%TYPE ;
	V_AGNC_BRCH			VN.AAA10M00.AGNC_BRCH%TYPE ;
	V_BANK_CNT_YN		VN.AAA01M00.BANK_CNT_YN%TYPE ;
	V_BANK_CD		    VN.AAA01M00.BANK_CD%TYPE ;
	V_WORK_BNH			VN.AAA10M00.WORK_BNH%TYPE ;
	V_PROC_AGNC_BRCH	VN.AAA10M00.PROC_AGNC_BRCH%TYPE ;
	V_TRD_TP            VN.AAA10M00.TRD_TP%TYPE ;


    -- Out Variables
	O_CLS_YN			VARCHAR2(1) := 'Y' ;
	O2_RTN_MSG      	VARCHAR2(254) ;      				-- Return Message


	ts_err_cd      	    VARCHAR2(5) := NULL ;
	T_PROC_DT      	    VARCHAR2(8) := NULL ;


    -- Exceptions Declare
    ERR_TRD_DT				EXCEPTION ;		-- Error of trading date
    ERR_ACNT_NO				EXCEPTION ;		-- Error of account number
    ERR_CASH				EXCEPTION ;		-- Error of withdrawal amount

    ERR_TSO02M00_SEL		EXCEPTION ;		-- Warrant from tso02m00 Table Lock
    ERR_PBM_CLS_YN_Q		EXCEPTION ;		-- Closing branch
    ERR_AAA01M00_SEL		EXCEPTION ;		-- Account number
    ERR_ACNT_STAT_2			EXCEPTION ;		-- Accout status
    ERR_ACNT_STAT_9			EXCEPTION ;		-- Account type error
    ERR_XCA01M01_SEL		EXCEPTION ;		-- Employees department
    ERR_PCW_OUTAMT_PSBAMT_Q	EXCEPTION ;		-- Withdrawal amount > withdrawable amount
    ERR_TN_TOT_OUT_PSBAMT	EXCEPTION ;		-- minus deposit
    ERR_TN_DPO_PRERM		EXCEPTION ;		-- Deposit null or minus
    ERR_TOT_OUT_PSBAMT		EXCEPTION ;		-- Withdrawal amount > withdrawable amount
    ERR_PXC_PSB_SEQ_CRET_P	EXCEPTION ;		-- Trading sequence number
    ERR_CWD01M00_UPD		EXCEPTION ;		-- Update cwd01m00
    ERR_CWD01M00_INS		EXCEPTION ;		-- Insert cwd01m00
    ERR_PDS_DSC10M00		EXCEPTION ;		-- BANK_CUSTOMER
    ERR_AAA10M00_INS		EXCEPTION ;		-- aaa10m00 insert
	ERR_PCW_GGA07M00_INS_P	EXCEPTION ;		-- Accounting


-- *************************< START OF PROCEDURE >****************************
BEGIN


	O_TRD_SEQ_NO	:=	0 ;
	T_TOT_TRD_SEQ_NO	:=	0 ;
	O2_RTN_MSG		:=	NULL ;
	T_ACNT_NO		:=	NULL ;


	IF	I_TRD_DT IS NULL	OR	LENGTH(I_TRD_DT) <= 0	THEN
        RAISE ERR_TRD_DT ;
	END	IF ;


	IF	I_ACNT_NO IS NULL	OR	LENGTH(I_ACNT_NO) <= 0	THEN
        RAISE ERR_ACNT_NO ;
	END	IF ;


	IF	I_CASH IS NULL	OR	I_CASH	<=	0	THEN
        RAISE ERR_CASH ;
	END	IF ;


/* Closing branch */
	IF	I_WORK_MN NOT IN ('DAILY','BATCH')	THEN

	    BEGIN

		    VN.PBM_CLS_YN_Q(
							I_TRD_DT,
							VN.FBM_EMP_BNH_Q(I_WORK_MN),
							VN.FAA_ACNT_BNH_CD_G('0', I_ACNT_NO, I_SUB_NO),
							'1',
							O_CLS_YN,
							O2_RTN_MSG								-- Return Message
							) ;

			IF	O_CLS_YN != 'N'	THEN
		    	RAISE ERR_PBM_CLS_YN_Q ;
			END IF ;

	    EXCEPTION WHEN OTHERS THEN
	    	RAISE ERR_PBM_CLS_YN_Q ;
	    END ;

	END	IF ;



    BEGIN

		SELECT	v11.ACNT_STAT		AS	ACNT_STAT,
				v11.ACNT_MNG_BNH	AS	ACNT_MNG_BNH,
				v11.AGNC_BRCH		AS	AGNC_BRCH ,
				NVL(v11.BANK_CNT_YN,'N')     AS  BANK_CNT_YN ,
				NVL(v11.BANK_CD,'9999')     AS  BANK_CD
		  INTO	T_ACNT_STAT,
		  		V_ACNT_MNG_BNH,
		  		V_AGNC_BRCH ,
				V_BANK_CNT_YN ,
				V_BANK_CD
		  FROM	VN.AAA01M00	v11
		 WHERE	v11.ACNT_NO		=	I_ACNT_NO
           AND  v11.SUB_NO      =   I_SUB_NO;

    EXCEPTION WHEN OTHERS THEN
    	RAISE ERR_AAA01M00_SEL ;
    END ;


	/* 4. account status */
	IF	T_ACNT_STAT NOT IN ('1')	THEN

		IF	T_ACNT_STAT	=	'2'	THEN
    		RAISE ERR_ACNT_STAT_2 ;
		ELSE
    		RAISE ERR_ACNT_STAT_9 ;
		END IF ;

	END IF ;



	IF	I_WORK_MN NOT IN ('DAILY','BATCH')	THEN

		V_WORK_BNH			:=	V_ACNT_MNG_BNH ;
		V_PROC_AGNC_BRCH	:=	V_AGNC_BRCH ;

	ELSE

	    BEGIN

			SELECT	v11.BRCH_CD			AS	BRCH_CD,
					v11.AGNC_BRCH		AS	AGNC_BRCH
			  INTO	V_WORK_BNH,
			  		V_PROC_AGNC_BRCH
			  FROM	VN.XCA01M01	v11
			 WHERE	v11.EMP_NO		=	I_WORK_MN ;

	    EXCEPTION WHEN OTHERS THEN
	    	RAISE ERR_XCA01M01_SEL ;
	    END ;

	END	IF ;





IF V_BANK_CNT_YN = 'N'  THEN

	BEGIN

	    VN.PCW_OUTAMT_PSBAMT_Q(
								I_ACNT_NO,
                                I_SUB_NO,
								'9999' ,
								TN_DPO,
								tn_dpo_block,
								tn_outq_dpo_bk,
								tn_used_tmp,
								tn_reuse_dpo,
								tn_sbst_dpo ,
								tn_sbst_able_block ,
								tn_sbst_proof ,
								TN_GST_DPO,
								tn_use_vd,
								tn_nonrpy_loan_amt,
								tn_mgn_loan_amt,
								tn_mgn_lack    ,
								tn_cd_lack    ,
								TN_CRD_DPO,
								TN_USED_ALOWA_REL,
								TN_USED_ALOWA_CD,
								TN_USED_ALOWA_VIT,
								tn_used_tmp      ,
								tn_used_tmp      ,
								tn_used_tmp      ,
                                tn_able_block    ,
								TN_TOT_OUT_PSBAMT
								) ;

    EXCEPTION WHEN OTHERS THEN
    	RAISE ERR_PCW_OUTAMT_PSBAMT_Q ;
    END ;


	TN_DPO_PRERM	:=	TN_DPO;

	IF	TN_DPO_PRERM	IS NULL	OR
		TN_DPO_PRERM	<	0	THEN
    	RAISE ERR_TN_DPO_PRERM ;
	END IF ;


	IF	TN_TOT_OUT_PSBAMT	<	I_CASH	THEN
    	RAISE ERR_TOT_OUT_PSBAMT ;
	END IF ;



    BEGIN

	    VN.PXC_PSB_SEQ_CRET_P(

							I_ACNT_NO,				-- °èÁÂ¹øÈ£
							I_SUB_NO,				-- °èÁÂ¹øÈ£
							I_TRD_DT,				-- °Å·¡ÀÏ
							O_TRD_SEQ_NO,			-- °Å·¡ÀÏ·Ã¹øÈ£
                            T_TOT_TRD_SEQ_NO			-- °Å·¡ÀÏ·Ã¹øÈ£
							) ;

    EXCEPTION WHEN OTHERS THEN
    	RAISE ERR_PXC_PSB_SEQ_CRET_P ;
    END ;



	TN_DPO	:=	TN_DPO_PRERM - I_CASH ;

	V_TRD_TP := '61' ;



	IF	T_ATDPST_FOUND_YN = 'Y'	THEN

	    BEGIN

			UPDATE	VN.CWD01M00
			   SET	DPO			=	TN_DPO,
					WORK_MN		=	I_WORK_MN,
					WORK_DTM	=	SYSDATE,
					WORK_TRM	=	I_WORK_TRM
			 WHERE	ACNT_NO	=	I_ACNT_NO
               AND  SUB_NO  =   I_SUB_NO;

	    EXCEPTION WHEN OTHERS THEN
	    	RAISE ERR_CWD01M00_UPD ;
	    END ;

	ELSE

	    BEGIN

            INSERT	INTO VN.CWD01M00(
					ACNT_NO,
                    SUB_NO,
					DPO,
					GST_DPO,
					WORK_MN,
					WORK_DTM,
					WORK_TRM )
            VALUES  (
					I_ACNT_NO,
                    I_SUB_NO,
					TN_DPO,
					0,
					I_WORK_MN,
					SYSDATE,
					I_WORK_TRM ) ;

	    EXCEPTION WHEN OTHERS THEN
	    	RAISE ERR_CWD01M00_INS ;
	    END ;

	END IF ;
ELSE   /* end investor customer */

	  begin
		select vn.fxc_vorderdt_g(to_date(I_TRD_DT,'yyyymmdd'), 1 )
	      into T_PROC_DT
		  from dual ;
      end ;

      BEGIN
            VN.PDS_DSC10M00_INS(
							I_TRD_DT ,
							'7' ,         -- job_tp ,
							V_BANK_CD ,
							I_ACNT_NO ,
							I_SUB_NO,
							I_TRD_DT ,
							I_TRD_DT ,
							'2' ,         -- ts_sb_tp ,
							V_ACNT_MNG_BNH ,
							V_AGNC_BRCH ,
							'00' ,
							'00'  ,
							NULL , -- stk_cd
							1 , -- seq_no
							to_number(I_CASH) ,
							to_number(I_CASH) ,
							0,
							0,     --tax
							'00' , --lnd_tp
							I_TRD_DT , --lnd_dt
							I_TRD_DT ,
							'0000' , --lnd_bank_cd
							0,
							0,
							0,
							0,   -- qty
							I_WORK_MN ,
							I_WORK_TRM
							);
        EXCEPTION WHEN OTHERS THEN
            RAISE ERR_PDS_DSC10M00 ;
        END ;

		V_TRD_TP := '63' ;

    BEGIN

       VN.PXC_PSB_SEQ_CRET_P(

							I_ACNT_NO,
							I_SUB_NO,
							I_TRD_DT,
							O_TRD_SEQ_NO,
							O_TRD_SEQ_NO
							) ;

    EXCEPTION WHEN OTHERS THEN
        RAISE ERR_PXC_PSB_SEQ_CRET_P ;
    END ;



END IF ;  /* end bank customer */

/*******************************/
/* call evaluation for margin  */
/*******************************/

   BEGIN
     vn.pdl_crd_loan_rt_proc_td
         (i_trd_dt
         ,'1' -- cash
         ,i_acnt_no
         ,i_sub_no
         ,o_trd_seq_no
         ,i_work_mn
         ,i_work_trm
         ,o_cnt
       );
    EXCEPTION
       WHEN OTHERS THEN
         t_err_txt := 'call pdl_crd_loan_rt_proc_td error : ' || sqlerrm ;
         t_err_msg := vn.fxc_get_err_msg('V','2748');
         raise_application_error(-20100,t_err_msg||t_err_txt);
    END ;

vn.pxc_log_write('pcw_cash_outamt_p','pdl_crd_loan_rt_proc_td ['|| o_cnt ||']');


	BEGIN

        INSERT	INTO VN.AAA10M00(
				ACNT_NO,
                SUB_NO,
				TRD_DT,
				TOT_TRD_SEQ_NO,
				TRD_SEQ_NO,
				TRD_TP,
				RMRK_CD,
				MDM_TP,
				CNCL_YN,
				ORG_TRD_NO,
				TRD_AMT,
				CMSN,
				ADJ_AMT,
				DPO_PRERM,
				DPO_NOWRM,
				CNTE,
				ACNT_MNG_BNH,
				AGNC_BRCH,
				WORK_BNH,
				PROC_AGNC_BRCH,
				WORK_MN,
				WORK_DTM,
				WORK_TRM )
        VALUES  (
				I_ACNT_NO,
                I_SUB_NO,
				I_TRD_DT,
				O_TRD_SEQ_NO,
				T_TOT_TRD_SEQ_NO,
				V_TRD_TP,
				I_RMRK_CD,
				I_MDM_TP,
				'N',
				0,
				I_CASH,
				0,
				I_CASH,
				TN_DPO_PRERM,
				TN_DPO,
				I_CNFM_YN,
				V_ACNT_MNG_BNH,
				V_AGNC_BRCH,
				V_WORK_BNH,
				V_PROC_AGNC_BRCH,
				I_WORK_MN,
				SYSDATE,
				I_WORK_TRM ) ;

    EXCEPTION WHEN OTHERS THEN
		RAISE ERR_AAA10M00_INS ;
    END ;


       BEGIN

	    VN.PCW_GGA07M00_INS_P(

							I_TRD_DT,
							'I',
							I_ACNT_NO,
                            I_SUB_NO,
							O_TRD_SEQ_NO,
							0,
							I_RMRK_CD,
							I_CASH,
							I_WORK_MN,
							I_WORK_TRM
							) ;

       EXCEPTION WHEN OTHERS THEN
    	 RAISE ERR_PCW_GGA07M00_INS_P ;
       END ;

    O1_RTN_TBL  :=  'PSS_CASH_OUTAMT_P' ;
    O1_RTN_ERR  :=  '0' ;
    O1_RTN_MSG  :=  SUBSTR('TRD_DT:(' || I_TRD_DT || ') ACNT_NO:(' || I_ACNT_NO || ') Success.', 1, 254) ;
	vn.pxc_log_write('pss_cash_outamt_p', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG || ']') ;
    --O1_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','0602') ;

EXCEPTION
    WHEN    ERR_TRD_DT  THEN
        O1_RTN_TBL  :=  'ERR_TRD_DT' ;
        O1_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O1_RTN_MSG  :=  'ERROR ' || 'TRD_DT:(' || I_TRD_DT || ') ACNT_NO:(' || I_ACNT_NO || ')' ;
		vn.pxc_log_write('pss_cash_outamt_p', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG || ']') ;
        --O1_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') ;
        --RAISE_APPLICATION_ERROR(-20100, O1_RTN_ERR) ;
    WHEN    ERR_ACNT_NO  THEN
        O1_RTN_TBL  :=  'ERR_ACNT_NO' ;
        O1_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O1_RTN_MSG  :=  'ERROR ' || 'TRD_DT:(' || I_TRD_DT || ') ACNT_NO:(' || I_ACNT_NO || ')' ;
		vn.pxc_log_write('pss_cash_outamt_p', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG || ']') ;
        --O1_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') ;
        --RAISE_APPLICATION_ERROR(-20100, O1_RTN_ERR) ;
    WHEN    ERR_CASH  THEN
        O1_RTN_TBL  :=  'ERR_CASH' ;
        O1_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O1_RTN_MSG  :=  'ERROR ' || 'TRD_DT:(' || I_TRD_DT || ') ACNT_NO:(' || I_ACNT_NO || ')' ;
		vn.pxc_log_write('pss_cash_outamt_p', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG || ']') ;
        --O1_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') ;
        --RAISE_APPLICATION_ERROR(-20100, O1_RTN_ERR) ;
    WHEN    ERR_TSO02M00_SEL  THEN
        O1_RTN_TBL  :=  'ERR_TSO02M00_SEL' ;
        O1_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O1_RTN_MSG  :=  'ERROR ' || 'TRD_DT:(' || I_TRD_DT || ') ACNT_NO:(' || I_ACNT_NO || ')' ;
		vn.pxc_log_write('pss_cash_outamt_p', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG || ']') ;
        --O1_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') ;
        --RAISE_APPLICATION_ERROR(-20100, O1_RTN_ERR) ;
    WHEN    ERR_PBM_CLS_YN_Q  THEN
        O1_RTN_TBL  :=  'ERR_PBM_CLS_YN_Q' ;
        O1_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O1_RTN_MSG  :=  SUBSTR('ERROR ' || 'TRD_DT:(' || I_TRD_DT || ') ACNT_NO:(' || I_ACNT_NO || ') => ' || O2_RTN_MSG, 1, 254) ;
		vn.pxc_log_write('pss_cash_outamt_p', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG || ']') ;
        --O1_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') ;
        --RAISE_APPLICATION_ERROR(-20100, O1_RTN_ERR) ;
    WHEN    ERR_AAA01M00_SEL  THEN
        O1_RTN_TBL  :=  'ERR_AAA01M00_SEL' ;
        O1_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O1_RTN_MSG  :=  'ERROR ' || 'TRD_DT:(' || I_TRD_DT || ') ACNT_NO:(' || I_ACNT_NO || ')' ;
		vn.pxc_log_write('pss_cash_outamt_p', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG || ']') ;
        --O1_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') ;
        --RAISE_APPLICATION_ERROR(-20100, O1_RTN_ERR) ;
    WHEN    ERR_ACNT_STAT_2  THEN
        O1_RTN_TBL  :=  'ERR_ACNT_STAT_2' ;
        O1_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O1_RTN_MSG  :=  'ERROR ' || 'TRD_DT:(' || I_TRD_DT || ') ACNT_NO:(' || I_ACNT_NO || ')' ;
		vn.pxc_log_write('pss_cash_outamt_p', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG || ']') ;
        --O1_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') ;
        --RAISE_APPLICATION_ERROR(-20100, O1_RTN_ERR) ;
    WHEN    ERR_ACNT_STAT_9  THEN
        O1_RTN_TBL  :=  'ERR_ACNT_STAT_9' ;
        O1_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O1_RTN_MSG  :=  'ERROR ' || 'TRD_DT:(' || I_TRD_DT || ') ACNT_NO:(' || I_ACNT_NO || ')' ;
		vn.pxc_log_write('pss_cash_outamt_p', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG || ']') ;
        --O1_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') ;
        --RAISE_APPLICATION_ERROR(-20100, O1_RTN_ERR) ;
    WHEN    ERR_XCA01M01_SEL  THEN
        O1_RTN_TBL  :=  'ERR_XCA01M01_SEL' ;
        O1_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O1_RTN_MSG  :=  'ERROR ' || 'TRD_DT:(' || I_TRD_DT || ') ACNT_NO:(' || I_ACNT_NO || ')' ;
		vn.pxc_log_write('pss_cash_outamt_p', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG || ']') ;
        --O1_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') ;
        --RAISE_APPLICATION_ERROR(-20100, O1_RTN_ERR) ;
    WHEN    ERR_PCW_OUTAMT_PSBAMT_Q  THEN
        O1_RTN_TBL  :=  'ERR_PCW_OUTAMT_PSBAMT_Q' ;
        O1_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O1_RTN_MSG  :=  'ERROR ' || 'TRD_DT:(' || I_TRD_DT || ') ACNT_NO:(' || I_ACNT_NO || ')' ;
		vn.pxc_log_write('pss_cash_outamt_p', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG || ']') ;
        --O1_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') ;
        --RAISE_APPLICATION_ERROR(-20100, O1_RTN_ERR) ;
    WHEN    ERR_TN_TOT_OUT_PSBAMT  THEN
        O1_RTN_TBL  :=  'ERR_TN_TOT_OUT_PSBAMT' ;
        O1_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O1_RTN_MSG  :=  'ERROR ' || 'TRD_DT:(' || I_TRD_DT || ') ACNT_NO:(' || I_ACNT_NO || ')' ;
		vn.pxc_log_write('pss_cash_outamt_p', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG || ']') ;
        --O1_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') ;
        --RAISE_APPLICATION_ERROR(-20100, O1_RTN_ERR) ;
    WHEN    ERR_TN_DPO_PRERM  THEN
        O1_RTN_TBL  :=  'ERR_TN_DPO_PRERM' ;
        O1_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O1_RTN_MSG  :=  'ERROR ' || 'TRD_DT:(' || I_TRD_DT || ') ACNT_NO:(' || I_ACNT_NO || ')' ;
		vn.pxc_log_write('pss_cash_outamt_p', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG || ']') ;
        --O1_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') ;
        --RAISE_APPLICATION_ERROR(-20100, O1_RTN_ERR) ;
    WHEN    ERR_TOT_OUT_PSBAMT  THEN
        O1_RTN_TBL  :=  'ERR_TOT_OUT_PSBAMT' ;
        O1_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O1_RTN_MSG  :=  'ERROR ' || 'TRD_DT:(' || I_TRD_DT || ') ACNT_NO:(' || I_ACNT_NO || ')' ;
		vn.pxc_log_write('pss_cash_outamt_p', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG || ']') ;
        --O1_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') ;
        --RAISE_APPLICATION_ERROR(-20100, O1_RTN_ERR) ;
    WHEN    ERR_PXC_PSB_SEQ_CRET_P  THEN
        O1_RTN_TBL  :=  'ERR_PXC_PSB_SEQ_CRET_P' ;
        O1_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O1_RTN_MSG  :=  'ERROR ' || 'TRD_DT:(' || I_TRD_DT || ') ACNT_NO:(' || I_ACNT_NO || ')' ;
		vn.pxc_log_write('pss_cash_outamt_p', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG || ']') ;
        --O1_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') ;
        --RAISE_APPLICATION_ERROR(-20100, O1_RTN_ERR) ;
    WHEN    ERR_CWD01M00_UPD  THEN
        O1_RTN_TBL  :=  'ERR_CWD01M00_UPD' ;
        O1_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O1_RTN_MSG  :=  'ERROR ' || 'TRD_DT:(' || I_TRD_DT || ') ACNT_NO:(' || I_ACNT_NO || ')' ;
		vn.pxc_log_write('pss_cash_outamt_p', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG || ']') ;
        --O1_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') ;
        --RAISE_APPLICATION_ERROR(-20100, O1_RTN_ERR) ;
    WHEN    ERR_CWD01M00_INS  THEN
        O1_RTN_TBL  :=  'ERR_CWD01M00_INS' ;
        O1_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O1_RTN_MSG  :=  'ERROR ' || 'TRD_DT:(' || I_TRD_DT || ') ACNT_NO:(' || I_ACNT_NO || ')' ;
		vn.pxc_log_write('pss_cash_outamt_p', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG || ']') ;
        --O1_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') ;
        --RAISE_APPLICATION_ERROR(-20100, O1_RTN_ERR) ;
    WHEN    ERR_AAA10M00_INS  THEN
        O1_RTN_TBL  :=  'ERR_AAA10M00_INS' ;
        O1_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O1_RTN_MSG  :=  'ERROR ' || 'TRD_DT:(' || I_TRD_DT || ') ACNT_NO:(' || I_ACNT_NO || ')' ;
		vn.pxc_log_write('pss_cash_outamt_p', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG || ']') ;
        --O1_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') ;
        --RAISE_APPLICATION_ERROR(-20100, O1_RTN_ERR) ;
    WHEN    ERR_PCW_GGA07M00_INS_P  THEN
        O1_RTN_TBL  :=  'ERR_PCW_GGA07M00_INS_P' ;
        O1_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O1_RTN_MSG  :=  'ERROR ' || 'TRD_DT:(' || I_TRD_DT || ') ACNT_NO:(' || I_ACNT_NO || ')' ;
		vn.pxc_log_write('pss_cash_outamt_p', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG || ']') ;
        --O1_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') ;
        --RAISE_APPLICATION_ERROR(-20100, O1_RTN_ERR) ;
    WHEN    ERR_PDS_DSC10M00  THEN
        O1_RTN_TBL  :=  'ERR_PDS_DSC01M))_INS' ;
        O1_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O1_RTN_MSG  :=  'ERROR ' || 'TRD_DT:(' || I_TRD_DT || ') ACNT_NO:(' || I_ACNT_NO || ')' ;
        vn.pxc_log_write('pss_cash_outamt_p', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG || ']') ;
    WHEN    OTHERS  THEN
        O1_RTN_TBL  :=  'OTHERS [PSS_CASH_OUTAMT_P]' ;
        O1_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O1_RTN_MSG  :=  'ERROR ' || SUBSTR(SQLERRM, 1, 100) ;
		vn.pxc_log_write('pss_cash_outamt_p', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG || ']') ;
        --RAISE_APPLICATION_ERROR(-20100, O1_RTN_ERR) ;
END PSS_CASH_INAMT_P ;
/

