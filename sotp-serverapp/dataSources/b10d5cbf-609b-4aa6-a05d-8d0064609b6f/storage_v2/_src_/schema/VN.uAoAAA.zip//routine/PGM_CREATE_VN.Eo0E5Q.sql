create PROCEDURE Pgm_Create_vn (PG_ID IN VARCHAR2,
            s_table_name IN VARCHAR2, t_table_name IN VARCHAR2
) IS

    /* ��������
    /* init.ora file��utl_file_dir ������ directory setting */
    p_FileDir  VARCHAR2(255) :='/VNST/log/ora';
    v_FileHandle UTL_FILE.FILE_TYPE;
    s_owner VARCHAR2(30); -- source table��owner

    /* target table */
    t_tab_comments VARCHAR2(40); /* table comments */
    t_column_id NUMBER := 0;
    t_column_name VARCHAR2(30);
    t_data_type  VARCHAR2(30);
    t_data_length NUMBER := 0;
    t_comments  VARCHAR2(40);

    t_target_pk VARCHAR2(30);

    /* source table */
    s_tab_comments VARCHAR2(40); /* table comments */
    s_column_id NUMBER := 0;
    s_column_name VARCHAR2(30);
    s_data_type  VARCHAR2(30);
    s_data_length NUMBER := 0;
    s_comments  VARCHAR2(40);
    --------------------------------------------------------------

    v_count NUMBER :=0;

    /* Target Table Primary Key Setting */
    CURSOR cur_target_pk IS
        SELECT DISTINCT A.COLUMN_NAME
          FROM ALL_CONS_COLUMNS A
             , ALL_CONSTRAINTS B
         WHERE A.TABLE_NAME = t_table_name
           AND A.TABLE_NAME = B.TABLE_NAME
           AND B.CONSTRAINT_TYPE = 'P'
           AND A.CONSTRAINT_NAME = B.CONSTRAINT_NAME;

    /* Cursor setting (Target) */
    CURSOR cur_target_info IS
        SELECT A.column_id
             , A.column_name
             , A.data_type
             , A.data_length
             , B.comments
          FROM ALL_TAB_COLUMNS A
             , ALL_COL_COMMENTS B
         WHERE A.table_name = t_table_name
           AND A.OWNER = 'VN'
           AND B.OWNER = 'VN'
           AND B.table_name(+)  = A.table_name
           AND B.column_name(+) = A.column_name
        ORDER BY A.column_id;

    /* Cursor setting (Source) */
    CURSOR cur_source_info IS
        SELECT A.column_id
             , A.column_name
             , A.data_type
             , A.data_length
             , nvl(B.comments,' ')
          FROM ALL_TAB_COLUMNS A
             , ALL_COL_COMMENTS B
         WHERE A.table_name = s_table_name
           AND A.OWNER = 'VCSC'
           AND B.OWNER = 'VCSC'
           AND B.table_name(+)  = A.table_name
           AND B.column_name(+) = A.column_name
        ORDER BY A.column_id;

BEGIN

dbms_output.put_line('1111');
    /*=========================================================*/
    /* Header ����                                             */
    /*=========================================================*/
    SELECT DISTINCT COMMENTS
      INTO t_tab_comments  /* target table comments */
      FROM ALL_TAB_COMMENTS
     WHERE table_name = t_table_name
       AND COMMENTS IS NOT NULL;

    --SELECT DISTINCT COMMENTS
    --  INTO s_tab_comments /* source table comments */
    --  FROM ALL_TAB_COMMENTS
    -- WHERE table_name = s_table_name
    --   AND COMMENTS IS NOT NULL;

    /*=========================================================*/
    /* �������� ������ Open���                       */
    /*=========================================================*/
    v_FileHandle := UTL_FILE.FOPEN(p_FileDir, PG_ID || '.sql', 'w');

    /*=========================================================*/
    /* HEADER SETTING                                          */
    /*=========================================================*/
    UTL_FILE.PUT_LINE(v_FileHandle,'------------------------------------------------------------------------');
    UTL_FILE.PUTF(v_FileHandle,    '--  Source : %s (%s)\n', s_table_name,s_tab_comments);
    UTL_FILE.PUTF(v_FileHandle,    '--  Target : %s (%s)\n', t_table_name,t_tab_comments);
    UTL_FILE.PUTF(v_FileHandle,    '--\n');
    UTL_FILE.PUTF(v_FileHandle,    '--  Date : %s\n', TO_CHAR(SYSDATE,'YYYY/MM/DD'));
    UTL_FILE.PUTF(v_FileHandle,    '--  Program Name : %s%s\n\n', PG_ID,'.pl');
    UTL_FILE.PUT_LINE(v_FileHandle,'------------------------------------------------------------------------');
    UTL_FILE.PUTF(v_FileHandle,    '\n\n');


    UTL_FILE.PUTF(v_FileHandle,    'CREATE OR REPLACE PROCEDURE %s\n', PG_ID);
    UTL_FILE.PUT_LINE(v_FileHandle,'IS');
    UTL_FILE.PUTF(v_FileHandle,    '\n');

dbms_output.put_line('2222');
    /*=========================================================*/
    /* target table column                                     */
    /*=========================================================*/
    /* UTL_FILE.PUT_LINE(v_FileHandle,'   -- target table column'); */
/*
    OPEN cur_target_info;
    LOOP
    FETCH cur_target_info INTO t_column_id, t_column_name, t_data_type, t_data_length, t_comments;

        EXIT WHEN cur_target_info%NOTFOUND;

        UTL_FILE.PUTF(v_FileHandle,'   t_%s   %s  -- %s.%s\n', RPAD(t_column_name,30,' '),
                      RPAD((t_data_type ||'('||t_data_length ||');'),15,' '),
                      RPAD(TO_CHAR(t_column_id),3,' '),
                      RPAD(t_comments,40,' '));

    END LOOP;
    CLOSE cur_target_info;
*/

    UTL_FILE.PUTF(v_FileHandle,    '\n');
    UTL_FILE.PUT_LINE(v_FileHandle,'   -- table define');

    /*=========================================================*/
    /* table owner read                                        */
    /*=========================================================*/
dbms_output.put_line('3333');
dbms_output.put_line('1'|| s_table_name);
    SELECT owner
      INTO s_owner
      FROM ALL_OBJECTS
     WHERE object_name = 'vcsc.ACCOUNT'
       and object_type = 'TABLE'
       and rownum      = 1;
dbms_output.put_line('2'|| s_table_name);

    UTL_FILE.PUTF(v_FileHandle,    '   t_%s   %s%ROWTYPE;    -- %s\n',  t_table_name, t_table_name, t_tab_comments);
    UTL_FILE.PUTF(v_FileHandle,    '   s_%s   %s.%s%ROWTYPE;    -- %s\n',  s_table_name, s_owner, s_table_name, s_tab_comments);
    UTL_FILE.PUT_LINE(v_FileHandle,'   -- Valiable Setting');
    UTL_FILE.PUT_LINE(v_FileHandle,'   fetch_cnt            BINARY_INTEGER := 0;          -- ');
    UTL_FILE.PUT_LINE(v_FileHandle,'   err_cnt              BINARY_INTEGER := 0;          -- ');
    UTL_FILE.PUT_LINE(v_FileHandle,'   wrn_cnt              BINARY_INTEGER := 0;          -- ');
    UTL_FILE.PUT_LINE(v_FileHandle,'   ins_cnt              BINARY_INTEGER := 0;          -- ');
    UTL_FILE.PUTF(v_FileHandle,    '\n');
    UTL_FILE.PUT_LINE(v_FileHandle,'   commit_cycle         BINARY_INTEGER := 1000;       -- ');
    UTL_FILE.PUT_LINE(v_FileHandle,'   err_log_commit_cycle BINARY_INTEGER := 100;        -- ');
    UTL_FILE.PUTF(v_FileHandle,    '\n');
    UTL_FILE.PUT_LINE(v_FileHandle,'   v_err_code           NUMBER;                       -- ');
    UTL_FILE.PUT_LINE(v_FileHandle,'   v_err_message        varchar2(255);                -- ');
    UTL_FILE.PUT_LINE(v_FileHandle,'   start_work_time      varchar2(8);                  -- ');
    UTL_FILE.PUTF(v_FileHandle,    '\n');

    UTL_FILE.PUT_LINE(v_FileHandle,'   -- Cursor setting');
    UTL_FILE.PUT_LINE(v_FileHandle,'   CURSOR CUR_MAIN_INFO IS');
    UTL_FILE.PUT_LINE(v_FileHandle,'       SELECT *');
    UTL_FILE.PUTF(v_FileHandle,    '       FROM %s.%s;\n',  s_owner, s_table_name);

dbms_output.put_line('4444');
    UTL_FILE.PUT_LINE(v_FileHandle,'   BEGIN');
    UTL_FILE.PUTF(v_FileHandle,    '\n');

    UTL_FILE.PUTF(v_FileHandle,    '      DELETE %s;\n',  t_table_name);
--    UTL_FILE.PUT_LINE(v_FileHandle,'P_Del_Miglog ('||''''||'1'||''''||','||PG_ID||')');
--    UTL_FILE.PUT_LINE(v_FileHandle,'P_Del_Miglog ('||''''||'2'||''''||','||PG_ID||')');
    UTL_FILE.PUTF(v_FileHandle,    '      DELETE FROM MIG_LOG_ERR WHERE pg_id = '||''''||'%s'||''''||';   -- log table clear\n', PG_ID);
    UTL_FILE.PUTF(v_FileHandle,    '      DELETE FROM MIG_LOG_RES WHERE pg_id = '||''''||'%s'||''''||';   -- result table clear\n', PG_ID);
    UTL_FILE.PUT_LINE(v_FileHandle,'      COMMIT;');
    UTL_FILE.PUTF(v_FileHandle,    '\n');

    UTL_FILE.PUT_LINE(v_FileHandle,'      -- start time setting');
    UTL_FILE.PUT_LINE(v_FileHandle,'      SELECT TO_CHAR(SYSDATE, '||''''||'HH24:MI:SS'||''''||') INTO start_work_time FROM DUAL;');
    UTL_FILE.PUTF(v_FileHandle,    '\n');
    UTL_FILE.PUT_LINE(v_FileHandle,'   -- Open Cursor');
    UTL_FILE.PUT_LINE(v_FileHandle,'   OPEN CUR_MAIN_INFO; ');
    UTL_FILE.PUT_LINE(v_FileHandle,'   LOOP');
    UTL_FILE.PUT_LINE(v_FileHandle,'      -- Initialize');
    UTL_FILE.PUTF(v_FileHandle,    '      t_%s      := NULL;\n', t_table_name);
    UTL_FILE.PUTF(v_FileHandle,    '      s_%s      := NULL;\n', s_table_name);

    UTL_FILE.PUTF(v_FileHandle,    '   FETCH CUR_MAIN_INFO INTO s_%s;\n', s_table_name);
    UTL_FILE.PUTF(v_FileHandle,    '\n');
    UTL_FILE.PUT_LINE(v_FileHandle,'      EXIT WHEN CUR_MAIN_INFO%NOTFOUND;');

    UTL_FILE.PUT_LINE(v_FileHandle,'      ------------------------------------------------------');
    UTL_FILE.PUT_LINE(v_FileHandle,'      -- Source Table(Main) Valiable');
    UTL_FILE.PUT_LINE(v_FileHandle,'      ------------------------------------------------------');

    /*=========================================================*/
    /* source table column                                     */
    /*=========================================================*/
    OPEN cur_source_info;
    LOOP
    FETCH cur_source_info INTO s_column_id, s_column_name, s_data_type, s_data_length, s_comments;

        EXIT WHEN cur_source_info%NOTFOUND;

dbms_output.put_line('1');
        UTL_FILE.PUTF(v_FileHandle,'      --  %s.%s   %s   %s.%s\n', s_table_name,
                      RPAD(s_column_name,30,' '),
                      RPAD((s_data_type ||'('||s_data_length ||');'),15,' '),
                      RPAD(TO_CHAR(s_column_id),3,' '),
                      RPAD(s_comments,40,' '));
    END LOOP;
    CLOSE cur_source_info;

    UTL_FILE.PUT_LINE(v_FileHandle,'      ------------------------------------------------------');
    UTL_FILE.PUT_LINE(v_FileHandle,'      -- Valiable Setting');
    UTL_FILE.PUT_LINE(v_FileHandle,'      -- Data Setting                                       ');
    UTL_FILE.PUT_LINE(v_FileHandle,'      ------------------------------------------------------');

    /*=========================================================*/
    /* target table primary key display                        */
    /*=========================================================*/
    UTL_FILE.PUT_LINE(v_FileHandle,'      -- target table primary key display');

    OPEN cur_target_pk;
    LOOP
    FETCH cur_target_pk INTO t_target_pk;

        EXIT WHEN cur_target_pk%NOTFOUND;

        UTL_FILE.PUTF(v_FileHandle,'      --  t_%s.%s\n', t_table_name, t_target_pk);
    END LOOP;
    CLOSE cur_target_pk;

    UTL_FILE.PUT_LINE(v_FileHandle,'      ------------------------------------------------------');
    UTL_FILE.PUT_LINE(v_FileHandle,'      -- Data Setting');
    UTL_FILE.PUT_LINE(v_FileHandle,'      ------------------------------------------------------');


    /*=========================================================*/
    /* Data Setting <-- Require User Update                    */
    /*=========================================================*/
    UTL_FILE.PUT_LINE(v_FileHandle,'/*');
    OPEN cur_target_info;
    LOOP
    FETCH cur_target_info INTO  t_column_id, t_column_name, t_data_type, t_data_length, t_comments;

        EXIT WHEN cur_target_info%NOTFOUND;

        UTL_FILE.PUTF(v_FileHandle,'      t_%s.%s := ;  -- %s  %s.%s\n',
                      t_table_name,
                      RPAD(t_column_name,30,' '),
                      RPAD((t_data_type ||'('||t_data_length ||');'),15,' '),
                      RPAD(TO_CHAR(t_column_id),3,' '),
                      RPAD(t_comments,40,' '));

    END LOOP;
    CLOSE cur_target_info;
    UTL_FILE.PUT_LINE(v_FileHandle,'*/');
dbms_output.put_line('5555');

    UTL_FILE.PUT_LINE(v_FileHandle,'      ------------------------------------------------------');
    UTL_FILE.PUT_LINE(v_FileHandle,'                                                            ');
    UTL_FILE.PUT_LINE(v_FileHandle,'      ------------------------------------------------------');
    UTL_FILE.PUT_LINE(v_FileHandle,'      -- Insert statement execute                           ');
    UTL_FILE.PUT_LINE(v_FileHandle,'      ------------------------------------------------------');


    UTL_FILE.PUT_LINE(v_FileHandle,'      BEGIN');
    UTL_FILE.PUTF(v_FileHandle,'         -- %s\n', t_comments);
    UTL_FILE.PUT_LINE(v_FileHandle,'/*');
    UTL_FILE.PUTF(v_FileHandle,'         INSERT INTO %s (\n', t_table_name);

    /*=========================================================*/
    /* target table insert                                     */
    /*=========================================================*/
    OPEN cur_target_info;
    LOOP
    FETCH cur_target_info INTO  t_column_id, t_column_name, t_data_type, t_data_length, t_comments;

        EXIT WHEN cur_target_info%NOTFOUND;

        IF t_column_id = 1 THEN
            UTL_FILE.PUTF(v_FileHandle,'             %s -- %s.%s\n', RPAD(t_column_name,30,' '),
                           RPAD(TO_CHAR(t_column_id),3,' '),
                           RPAD(t_comments,40,' '));
        ELSE
            UTL_FILE.PUTF(v_FileHandle,'            ,%s -- %s.%s\n', RPAD(t_column_name,30,' '),
                           RPAD(TO_CHAR(t_column_id),3,' '),
                           RPAD(t_comments,40,' '));
        END IF;

    END LOOP;
    CLOSE cur_target_info;

    UTL_FILE.PUT_LINE(v_FileHandle,'         ) VALUES (');

    OPEN cur_target_info;
    LOOP
    FETCH cur_target_info INTO  t_column_id, t_column_name, t_data_type, t_data_length, t_comments;

        EXIT WHEN cur_target_info%NOTFOUND;

        IF t_column_id = 1 THEN
            UTL_FILE.PUTF(v_FileHandle,'             t_%s.%s\n', t_table_name, t_column_name);
        ELSE
            UTL_FILE.PUTF(v_FileHandle,'            ,t_%s.%s\n', t_table_name, t_column_name);
        END IF;
    END LOOP;
    CLOSE cur_target_info;

    /*=========================================================*/
    /* log ��Result ���able�� �ݿ�                         */
    /*=========================================================*/
    UTL_FILE.PUT_LINE(v_FileHandle,'         );');
    UTL_FILE.PUT_LINE(v_FileHandle,'*/');
    UTL_FILE.PUTF(v_FileHandle,    '\n');

    UTL_FILE.PUT_LINE(v_FileHandle,'         ins_cnt := ins_cnt + 1;');
    UTL_FILE.PUT_LINE(v_FileHandle,'         IF MOD(fetch_cnt+1,commit_cycle) = 0 THEN');
    UTL_FILE.PUT_LINE(v_FileHandle,'            COMMIT;');
    UTL_FILE.PUT_LINE(v_FileHandle,'         END IF;');
    UTL_FILE.PUTF(v_FileHandle,    '\n');

    UTL_FILE.PUT_LINE(v_FileHandle,'      EXCEPTION');
    UTL_FILE.PUT_LINE(v_FileHandle,'         WHEN DUP_VAL_ON_INDEX THEN -- ');
    UTL_FILE.PUT_LINE(v_FileHandle,'            v_err_code    :=SQLCODE;');
    UTL_FILE.PUT_LINE(v_FileHandle,'            v_err_message :=SQLERRM;');
    UTL_FILE.PUTF(v_FileHandle,    '\n');
    UTL_FILE.PUTF(v_FileHandle,'            IF INSTR( v_err_message, '||''''||'PK_'||'%s'||''''||') > 0 THEN\n', t_table_name);
    UTL_FILE.PUT_LINE(v_FileHandle,'               INSERT INTO MIG_LOG_ERR');
    UTL_FILE.PUTF(v_FileHandle,'                  SELECT '||''''||'%s'||''''||'                         ,   -- Program ID \n', PG_ID);
    UTL_FILE.PUT_LINE(v_FileHandle,'                         TO_CHAR(SYSDATE, '||''''||'YYYY-MM-DD HH24:MI:SS'||''''||')  , -- work date');
    UTL_FILE.PUTF(v_FileHandle,'                         '||''''||'%s'||''''||'                             ,   -- target table\n', t_table_name);
    UTL_FILE.PUTF(v_FileHandle,'                         '||''''||'%s'||''''||'                             ,   -- source table\n', s_table_name);
    UTL_FILE.PUT_LINE(v_FileHandle,'                         fetch_cnt+1                                ,   -- fetch cnt');
    UTL_FILE.PUT_LINE(v_FileHandle,'                         '||''''||'PK:'||''''||'||v_err_message                     ,   -- error message');
    UTL_FILE.PUT_LINE(v_FileHandle,'                         NULL                                           -- dup key');
    UTL_FILE.PUT_LINE(v_FileHandle,'                  FROM DUAL;');
    UTL_FILE.PUT_LINE(v_FileHandle,'            END IF;');
    UTL_FILE.PUTF(v_FileHandle,    '\n');
    UTL_FILE.PUT_LINE(v_FileHandle,'            IF MOD(err_cnt+1, err_log_commit_cycle) = 0 THEN');
    UTL_FILE.PUT_LINE(v_FileHandle,'                COMMIT;');
    UTL_FILE.PUT_LINE(v_FileHandle,'            END IF;');
    UTL_FILE.PUT_LINE(v_FileHandle,'            err_cnt := err_cnt+1;');
    UTL_FILE.PUT_LINE(v_FileHandle,'         WHEN OTHERS THEN -- ');
    UTL_FILE.PUT_LINE(v_FileHandle,'            v_err_code    :=SQLCODE;');
    UTL_FILE.PUT_LINE(v_FileHandle,'            v_err_message :=SQLERRM;');
    UTL_FILE.PUTF(v_FileHandle,'            DBMS_OUTPUT.PUT_LINE( fetch_cnt+1||'||''''||' Line '||''''||'||v_err_code||'||''''||' '||''''||'||v_err_message );\n');
    UTL_FILE.PUT_LINE(v_FileHandle,'            ROLLBACK;');
    UTL_FILE.PUT_LINE(v_FileHandle,'            EXIT;');
    UTL_FILE.PUT_LINE(v_FileHandle,'      END;');
    UTL_FILE.PUTF(v_FileHandle,    '\n');
    UTL_FILE.PUT_LINE(v_FileHandle,'      ------------------------------------------------------');
    UTL_FILE.PUTF(v_FileHandle,    '\n');

    UTL_FILE.PUT_LINE(v_FileHandle,'      fetch_cnt := fetch_cnt +1;');
    UTL_FILE.PUTF(v_FileHandle,    '\n');

    UTL_FILE.PUT_LINE(v_FileHandle,'   END LOOP;');
    UTL_FILE.PUT_LINE(v_FileHandle,'   CLOSE CUR_MAIN_INFO; -- Close Cursor');
    UTL_FILE.PUT_LINE(v_FileHandle,'   ------------------------------------------------------');
    UTL_FILE.PUT_LINE(v_FileHandle,'   -- Log Insert');
    UTL_FILE.PUT_LINE(v_FileHandle,'   ------------------------------------------------------');
    UTL_FILE.PUT_LINE(v_FileHandle,'   INSERT INTO MIG_LOG_RES');
    UTL_FILE.PUTF(v_FileHandle,'      SELECT '||''''||'%s'||''''||'             ,   -- Program ID\n', PG_ID);
    UTL_FILE.PUT_LINE(v_FileHandle,'         TO_CHAR(SYSDATE, '||''''||'YYYY-MM-DD'||''''||')   ,   -- work date');
    UTL_FILE.PUTF(v_FileHandle,'             '||''''||'%s'||''''||'                     ,   -- source table\n', s_table_name);
    UTL_FILE.PUTF(v_FileHandle,'             '||''''||'%s'||''''||'                 ,   -- target table\n', t_table_name);
    UTL_FILE.PUTF(v_FileHandle,'             '||''''||'%s'||''''||'             ,   -- target table name\n', t_tab_comments);
    UTL_FILE.PUT_LINE(v_FileHandle,'             start_work_time                ,   -- start time');
    UTL_FILE.PUT_LINE(v_FileHandle,'             TO_CHAR(SYSDATE, '||''''||'HH24:MI:SS'||''''||')   ,   -- end time');
    UTL_FILE.PUT_LINE(v_FileHandle,'             fetch_cnt                      ,   -- fetch cnt');
    UTL_FILE.PUT_LINE(v_FileHandle,'             err_cnt                        ,   -- error cnt');
    UTL_FILE.PUT_LINE(v_FileHandle,'             ins_cnt                            -- conve cnt');
    UTL_FILE.PUT_LINE(v_FileHandle,'      FROM DUAL;');
    UTL_FILE.PUTF(v_FileHandle,    '\n');
    UTL_FILE.PUT_LINE(v_FileHandle,'   COMMIT;');
    UTL_FILE.PUTF(v_FileHandle,    '\n');
    UTL_FILE.PUT_LINE(v_FileHandle,'   DBMS_OUTPUT.PUT_LINE( '||''''||'tot'||''''||'||TO_CHAR(fetch_cnt)||'||''''||'cnt '||''''||'|| TO_CHAR(err_cnt) ||'||''''||'cnt err..'||''''||');');
    UTL_FILE.PUT_LINE(v_FileHandle,'   DBMS_OUTPUT.PUT_LINE( '||''''||'tot'||''''||'||TO_CHAR(ins_cnt)||'||''''||' finish..'||''''||');');

    UTL_FILE.PUTF(v_FileHandle,    '\n');
    UTL_FILE.PUTF(v_FileHandle,'END %s;\n', PG_ID);
    UTL_FILE.PUT_LINE(v_FileHandle,'/');


-- P_Ins_Miglog( '1', 'PG_ID', 's_table_name', 't_table_name', NULL, NULL, NULL, NULL, NULL, 'v_err_message', NULL);

-- P_Ins_Miglog( '2', 'PG_ID', 's_table_name', 't_table_name', 't_comments',  'start_work_time', fetch_cnt, err_cnt, ins_cnt, NULL, NULL);

    dbms_output.put_line('PGM Create Success('||PG_ID||')');

    /*=========================================================*/
    /* File Close                                              */
    /*=========================================================*/
    UTL_FILE.FCLOSE(v_FileHandle);

    /*=========================================================*/
    /* Exception process                                       */
    /*=========================================================*/
    EXCEPTION
        WHEN UTL_FILE.INVALID_OPERATION THEN
             UTL_FILE.FCLOSE(v_FileHandle);
             dbms_output.put_line('Fileoperat='||PG_ID||',INVALID_OPERATION' );
        WHEN UTL_FILE.INVALID_FILEHANDLE THEN
             UTL_FILE.FCLOSE(v_FileHandle);
             dbms_output.put_line('Filehandle='||PG_ID||',INVALID_FILEHANDLE' );
        WHEN UTL_FILE.WRITE_ERROR THEN
             UTL_FILE.FCLOSE(v_FileHandle);
             dbms_output.put_line('Filewrite='||PG_ID||',WRITE_ERROR' );
        WHEN OTHERS THEN
           UTL_FILE.FCLOSE(v_FileHandle);
             dbms_output.put_line('Filename =  '||PG_ID|| SQLCODE ||' , ERROR');

END Pgm_Create_vn;
/

