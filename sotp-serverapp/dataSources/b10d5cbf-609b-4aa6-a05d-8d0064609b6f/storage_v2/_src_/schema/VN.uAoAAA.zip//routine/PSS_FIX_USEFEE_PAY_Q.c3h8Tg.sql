create PROCEDURE PSS_FIX_USEFEE_PAY_Q
  ( I_PAY_YM        IN      VARCHAR2,       -- 지급대상월
    I_ACNT_NO       IN      VARCHAR2,       -- 계좌번호(전체:9999999999)
    I_SUB_NO        IN      VARCHAR2,       -- SUB_NO(전체:99)
    O_AMT           OUT     NUMBER          -- RETURN AMT
  ) AS


/*
   \file     pss_fix_usefee_pay_q.sql
   \brief

   \section intro Program Information
        - Program Name              :
        - Service Name              : N/A
        - Related Client Program- Client Program ID : Client 01102
        - Related Tables            :
        - Dev. Date                 :
        - Developer                 :
        - Business Logic Desc.      :
        - Latest Modification Date  :

   \section history Program Modification History
   \section hardcoding Hard-Coding List
    - HC-1
    - HC-2 2000/00/00

   \section info Additional Reference Comments
*/


    -- Constants
    K_MAX_DT        VARCHAR2(8) := '30000101' ;
    K_ALL_ACNT      VARCHAR2(10) := '9999999999' ;
    K_INT_RT_TP     VARCHAR2(2) := '01' ;
    K_CUST_GRD      VARCHAR2(2) := '00' ;


    -- Variables
	T_STRT_DT		VN.SSB07M00.MAK_STRT_DT%TYPE ;
	T_END_DT		VN.SSB07M00.MAK_END_DT%TYPE ;
    T_INT_RT      	VN.SSB07M00.APY_INT_RT%TYPE ;

    -- Out Variables

	T_CNT           NUMBER := 0 ;                       -- CHECK Count
	T_PROC_CNT      NUMBER := 0;
    V_PAY_FLAG     VARCHAR2(1) ;                       -- N:신규, U:추가, X:대상아님
    t_err_txt      VARCHAR2(200);
    t_err_msg      VARCHAR2(500);


    -- View Variables
	V_USEFEE_PAY_DT	VN.SSB07M00.USEFEE_PAY_DT%TYPE ;	-- 수수료지급일
	V_ACNT_NO		VN.SSB07M00.ACNT_NO%TYPE ;			-- 계좌번호
	V_SUB_NO		VN.SSB07M00.SUB_NO%TYPE ;			-- SUB_NO
	V_MAK_STRT_DT	VN.SSB07M00.MAK_STRT_DT%TYPE ;		-- 생성시작일
	V_MAK_END_DT	VN.SSB07M00.MAK_END_DT%TYPE ;		-- 생성종료일
	V_TOT_DT_CNT	VN.SSB07M00.TOT_DT_CNT%TYPE ;		-- 총일자수
	V_TOT_QTY		VN.SSB07M00.TOT_QTY%TYPE ;			-- 증권 총수량
	V_TOT_AVBL_QTY	VN.SSB07M00.TOT_AVBL_QTY%TYPE ;		-- 증권단위 수량
	V_APY_INT_RT	VN.SSB07M00.APY_INT_RT%TYPE ;		-- 적용수수료
	V_USEFEE		VN.SSB07M00.USEFEE%TYPE ;			-- 예탁수수료
	V_ACNT_MNG_BNH	VN.SSB07M00.ACNT_MNG_BNH%TYPE ;		-- 계좌관리점
	V_AGNC_BRCH		VN.SSB07M00.AGNC_BRCH%TYPE ;		-- 대리지점

-- *************************< START OF PROCEDURE >****************************
BEGIN

    O_AMT := 0 ;

--    vn.pxc_log_write('pss_fix_usefee_pay_q', '[ '|| I_PAY_YM ||' ]'  ||' - '|| '[ '|| I_ACNT_NO ||' ]' );

    BEGIN

		SELECT	TRIM(I_PAY_YM) || '01'		AS	MAK_STRT_DT,
				CASE
					WHEN	VN.VHDATE	<	TO_CHAR(LAST_DAY(TO_DATE(I_PAY_YM || '01', 'YYYYMMDD')), 'YYYYMMDD')	THEN
							TO_CHAR((VN.HDATE - 1), 'YYYYMMDD')
					ELSE	TO_CHAR(LAST_DAY(TO_DATE(I_PAY_YM || '01', 'YYYYMMDD')), 'YYYYMMDD')
				END							AS	MAK_END_DT
		  INTO	T_STRT_DT,	T_END_DT
		  FROM	DUAL ;

    EXCEPTION WHEN OTHERS THEN
	    vn.pxc_log_write('pss_fix_usefee_pay_q', 'get date sqlcode: ' || to_char(sqlcode) );

        t_err_txt  :=  'pss_fix_usefee_pay_q '
                           ||  sqlerrm;
        t_err_msg := vn.fxc_get_err_msg('V','9006');

        raise_application_error(-20100,t_err_msg||t_err_txt);

        T_STRT_DT	:=	TRIM(I_PAY_YM) || '01' ;
        T_END_DT	:=	TRIM(I_PAY_YM) || '31' ;
    END ;

    vn.pxc_log_write('pss_fix_usefee_pay_q','DT : '|| T_STRT_DT || ' -  ' || T_END_DT );

    BEGIN

		SELECT	NVL(v11.INT_RT, 0)		AS	INT_RT
		  INTO	T_INT_RT
		  FROM	VN.SSB08C00	v11
		 WHERE	v11.INT_RT_TP	=	K_INT_RT_TP
		   AND	v11.CUST_GRD	=	K_CUST_GRD
		   AND	v11.END_DT		=	K_MAX_DT
		   AND	ROWNUM			<=	1 ;

    EXCEPTION WHEN OTHERS THEN

		vn.pxc_log_write('pss_fix_usefee_pay_q', 'get int_rt sqlcode: ' || to_char(sqlcode) );

        T_INT_RT	:=	0 ;
    END ;

	vn.pxc_log_write('pss_fix_usefee_pay_q', 'T_INT_RT : ' || T_INT_RT  );


    FOR C1 IN	(
  		SELECT	v11.PAY_YM							AS	PAY_YM,
				v11.USEFEE_PAY_DT					AS	USEFEE_PAY_DT,			/* 수수료지급일 */
				v11.ACNT_NO							AS	ACNT_NO,				/* 계좌번호 */
				v11.SUB_NO              AS  SUB_NO,
				v11.MAK_STRT_DT						AS	MAK_STRT_DT,			/* 생성시작일 */
				v11.MAK_END_DT						AS	MAK_END_DT,				/* 생성종료일 */
				NVL(v11.TOT_DT_CNT, 0)				AS	TOT_DT_CNT,				/* 총일자수 */
				NVL(v11.TOT_QTY, 0)					AS	TOT_QTY,				/* 보유총수량 */
				NVL(v11.TOT_AVBL_QTY, 0)			AS	TOT_AVBL_QTY,			/* 증권단위총수량 */
				NVL(v11.APY_INT_RT, 0)				AS	APY_INT_RT,				/* 적용수수료 */
				ROUND((v11.APY_INT_RT / 30 ) * NVL(v11.TOT_AVBL_QTY, 0))	AS	USEFEE,	/* 예탁수수료 */
				v11.ACNT_MNG_BNH					AS	ACNT_MNG_BNH,			/* 계좌관리점 */
				v11.AGNC_BRCH						AS	AGNC_BRCH,				/* 대리지점 */
				v11.PAY_FLAG						AS	PAY_FLAG				/* N:신규, U:추가, X:대상아님 */
		  FROM
				(	SELECT	v21.PAY_YM					AS	PAY_YM,
							VN.VHDATE					AS	USEFEE_PAY_DT,			/* 수수료지급일 */
							v21.ACNT_NO					AS	ACNT_NO,				/* 계좌번호 */
							v21.SUB_NO          AS  SUB_NO,
							TRIM(T_STRT_DT)				AS	MAK_STRT_DT,			/* 생성시작일 */
							CASE
								WHEN	v22.ACNT_STAT	=	'2'	THEN
									CASE
										WHEN	v22.ACNT_CLS_DT	<	TRIM(T_STRT_DT)	THEN	TRIM(T_STRT_DT)
										WHEN	v22.ACNT_CLS_DT	=	TRIM(T_STRT_DT)	THEN	TRIM(T_STRT_DT)
										WHEN	v22.ACNT_CLS_DT	>	TRIM(T_STRT_DT)	AND
												v22.ACNT_CLS_DT	<	TRIM(T_END_DT)	THEN	v22.ACNT_CLS_DT
										ELSE	TRIM(T_END_DT)
									END
								ELSE	TRIM(T_END_DT)
							END							AS	MAK_END_DT,				/* 생성종료일 */
							CASE
								WHEN	v22.ACNT_STAT	=	'2'	THEN
									CASE
										WHEN	v22.ACNT_CLS_DT	<	TRIM(T_STRT_DT)	THEN
												(TO_DATE(TRIM(T_STRT_DT), 'YYYYMMDD') -
													TO_DATE(TRIM(T_STRT_DT), 'YYYYMMDD')) + 1
										WHEN	v22.ACNT_CLS_DT	=	TRIM(T_STRT_DT)	THEN
												(TO_DATE(TRIM(T_STRT_DT), 'YYYYMMDD') -
													TO_DATE(TRIM(T_STRT_DT), 'YYYYMMDD')) + 1
										WHEN	v22.ACNT_CLS_DT	>	TRIM(T_STRT_DT)	AND
												v22.ACNT_CLS_DT	<	TRIM(T_END_DT)	THEN
												(TO_DATE(TRIM(v22.ACNT_CLS_DT), 'YYYYMMDD') -
													TO_DATE(TRIM(T_STRT_DT), 'YYYYMMDD')) + 1
										ELSE	(TO_DATE(TRIM(T_END_DT), 'YYYYMMDD') -
													TO_DATE(TRIM(T_STRT_DT), 'YYYYMMDD')) + 1
									END
								ELSE	(TO_DATE(TRIM(T_END_DT), 'YYYYMMDD') -
											TO_DATE(TRIM(T_STRT_DT), 'YYYYMMDD')) + 1
							END							AS	TOT_DT_CNT,		/* 총일자수 */
							NVL(v21.TOT_QTY, 0)			AS	TOT_QTY,
							CASE
								WHEN	NVL(v21.TOT_QTY, 0)	> 0	THEN
										NVL(v21.TOT_QTY, 0) / 10					/* (보유총수량 / 증권단위) */
								ELSE	0
							END							AS	TOT_AVBL_QTY,			/* 증권단위총수량 */
							NVL(T_INT_RT, 0)			AS	APY_INT_RT,				/* 적용수수료 */
							v22.ACNT_STAT				AS	ACNT_STAT,
							v22.ACNT_CLS_DT				AS	ACNT_CLS_DT,
							v22.ACNT_MNG_BNH			AS	ACNT_MNG_BNH,			/* 계좌관리점 */
							v22.AGNC_BRCH				AS	AGNC_BRCH,				/* 대리지점 */
							CASE
								WHEN	v22.ACNT_STAT	=	'2'	THEN
									CASE
										WHEN	v22.ACNT_CLS_DT	<	TRIM(T_STRT_DT)	THEN	'X'
										WHEN	v22.ACNT_CLS_DT	=	TRIM(T_STRT_DT)	THEN	'N'
										WHEN	v22.ACNT_CLS_DT	>	TRIM(T_STRT_DT)	AND
												v22.ACNT_CLS_DT	<	TRIM(T_END_DT)	THEN	'N'
										ELSE	'N'
									END
								ELSE	'N'
							END							AS	PAY_FLAG				/* N:신규, U:추가, X:대상아님 */
					  FROM
							(	SELECT	TRIM(I_PAY_YM)				AS	PAY_YM,
										v31.ACNT_NO					AS	ACNT_NO,	/* 계좌번호 */
										v31.SUB_NO          AS  SUB_NO,
										SUM(NVL(v31.OWN_QTY, 0))	AS	TOT_QTY		/* 보유총수량 */
								  FROM	VN.SSB01H00	v31	/* 일별잔고정보 */
								 WHERE	v31.RGT_STD_DT	>=	T_STRT_DT
								   AND	v31.RGT_STD_DT	<=	T_END_DT
								   AND	v31.RGT_STD_DT	<>	VN.VHDATE
								   AND	v31.ACNT_NO		=	I_ACNT_NO	/* 계좌번호 */
								   AND  v31.SUB_NO    = I_SUB_NO
							  GROUP BY	TRIM(I_PAY_YM),
										v31.ACNT_NO,
										v31.SUB_NO
								HAVING	SUM(NVL(v31.OWN_QTY, 0))	>	0
							)			v21,
							VN.AAA01M00	v22
					 WHERE	v21.ACNT_NO		=	v22.ACNT_NO
					   AND  v21.SUB_NO    = v22.SUB_NO
					   AND	v22.ACNT_STAT	=	'1'
				)			v11
		 WHERE	ROUND((v11.APY_INT_RT / 30 ) * NVL(v11.TOT_AVBL_QTY, 0))	>	0
		   AND	v11.PAY_FLAG	<>	'X'
	  ORDER BY	v11.ACNT_NO, v11.SUB_NO

        ) LOOP

		T_PROC_CNT := T_PROC_CNT + 1 ;

		V_USEFEE_PAY_DT		:= C1.USEFEE_PAY_DT ;		-- 수수료지급일
		V_ACNT_NO			:= C1.ACNT_NO ;				-- 계좌번호
		V_SUB_NO      := C1.SUB_NO;
		V_TOT_DT_CNT		:= C1.TOT_DT_CNT ;
		V_TOT_QTY			:= C1.TOT_QTY ;
		V_TOT_AVBL_QTY		:= C1.TOT_AVBL_QTY ;
		V_APY_INT_RT		:= C1.APY_INT_RT ;
		V_USEFEE			:= C1.USEFEE ;
		V_ACNT_MNG_BNH		:= C1.ACNT_MNG_BNH ;		-- 계좌관리점
		V_AGNC_BRCH			:= C1.AGNC_BRCH ;			-- 대리지점

		V_MAK_STRT_DT		:= C1.MAK_STRT_DT ;
		V_MAK_END_DT		:= C1.MAK_END_DT ;
		V_PAY_FLAG			:= C1.PAY_FLAG ;

        vn.pxc_log_write('pss_fix_usefee_pay_q', 'V_USEFEE : ' || V_USEFEE  );

    	BEGIN

			SELECT	COUNT(*)
			  INTO	T_CNT
			  FROM	VN.SSB07M00	v11
			 WHERE	v11.ACNT_NO			=	V_ACNT_NO
			   AND  v11.SUB_NO      = V_SUB_NO
			   AND	v11.RCPT_TRD_NO		<>	0
			   AND	v11.CNCL_TRD_NO		=	0
			   AND	(v11.MAK_STRT_DT	>=	T_STRT_DT
			   AND	v11.MAK_STRT_DT		<=	T_END_DT)
			   AND	(v11.MAK_END_DT		>=	T_STRT_DT
			   AND	v11.MAK_END_DT		<=	T_END_DT) ;

	    EXCEPTION WHEN OTHERS THEN
			T_CNT	:=	0 ;
	    END ;


        IF  T_CNT   >  0   THEN

            vn.pxc_log_write('pss_fix_usefee_pay_q', 'already payment'  );

            BEGIN

                SELECT  v21.MAK_STRT_DT         AS  MAK_STRT_DT,
                        v21.MAK_END_DT          AS  MAK_END_DT,
                        v21.PAY_FLAG            AS  PAY_FLAG        /* N:? 규, U:추转 X:??아??*/
                  INTO  V_MAK_STRT_DT,  V_MAK_END_DT,   V_PAY_FLAG
                  FROM
                        (   SELECT  CASE
                                        WHEN    (v31.MAK_END_DT >   T_STRT_DT)  AND
                                                (v31.MAK_END_DT <   T_END_DT)   THEN
                                                TO_CHAR((TO_DATE(v31.MAK_END_DT, 'YYYYMMDD') + 1), 'YYYYMMDD')
                                        ELSE    TRIM(T_END_DT)
                                    END                     AS  MAK_STRT_DT,
                                    TRIM(T_END_DT)          AS  MAK_END_DT,
                                    CASE
                                        WHEN    (v31.MAK_END_DT >   T_STRT_DT)  AND
                                                (v31.MAK_END_DT <   T_END_DT)       THEN    'U'
                                        ELSE    'X'
                                    END                     AS  PAY_FLAG            /* N:? 규, U:추转 X:??아??*/
                              FROM  VN.SSB07M00 v31
                             WHERE  v31.USEFEE_PAY_DT       =   (   SELECT  MAX(v41.USEFEE_PAY_DT)  AS  USEFEE_PAY_DT
                                                                      FROM  VN.SSB07M00 v41
                                                                     WHERE  v41.ACNT_NO         =   V_ACNT_NO
                                                                       AND  v41.SUB_NO          =   V_SUB_NO
                                                                       AND  v41.RCPT_TRD_NO     <>  0
                                                                       AND  v41.CNCL_TRD_NO     =   0
                                                                       AND  (v41.MAK_STRT_DT    >=  T_STRT_DT
                                                                       AND  v41.MAK_STRT_DT     <=  T_END_DT)
                                                                       AND  (v41.MAK_END_DT     >=  T_STRT_DT
                                                                       AND  v41.MAK_END_DT      <=  T_END_DT)
                                                                )
                               AND  v31.ACNT_NO         =   V_ACNT_NO
                               AND  v31.SUB_NO          =   V_SUB_NO
                               AND  v31.RCPT_TRD_NO     <>  0
                               AND  v31.CNCL_TRD_NO     =   0
                        )           v21 ;


            EXCEPTION WHEN OTHERS THEN

                vn.pxc_log_write('pss_fix_usefee_pay_q', 'already payment get date err ' || to_char(sqlcode)  );
                t_err_txt  :=  'pss_fix_usefee_pay_q '
                           ||  sqlerrm;
                t_err_msg := vn.fxc_get_err_msg('V','9006');

                raise_application_error(-20100,t_err_msg||t_err_txt);

            END;


            BEGIN

                SELECT  NVL(v21.TOT_DT_CNT, 0)              AS  TOT_DT_CNT,
                        NVL(v21.TOT_QTY, 0)                 AS  TOT_QTY,
                        NVL(v21.TOT_AVBL_QTY, 0)            AS  TOT_AVBL_QTY,
                        NVL(v21.APY_INT_RT, 0)              AS  APY_INT_RT,
                        ROUND((v21.APY_INT_RT / 30 ) * NVL(v21.TOT_AVBL_QTY, 0))    AS  USEFEE
                  INTO  V_TOT_DT_CNT,   V_TOT_QTY,  V_TOT_AVBL_QTY, V_APY_INT_RT,   V_USEFEE
                  FROM
                            /* 같꽿¬에 지급건???는 ? 규경우 */
                        (   SELECT  v31.ACNT_NO                 AS  ACNT_NO,
                                    v31.SUB_NO                  AS  SUB_NO,
                                    (TO_DATE(TRIM(V_MAK_STRT_DT), 'YYYYMMDD') -
                                        TO_DATE(TRIM(V_MAK_END_DT), 'YYYYMMDD')) + 1        AS  TOT_DT_CNT,
                                    NVL(v31.TOT_QTY, 0)         AS  TOT_QTY,
                                    CASE
                                        WHEN    NVL(v31.TOT_QTY, 0) > 0 THEN
                                                NVL(v31.TOT_QTY, 0) / 10
                                        ELSE    0
                                    END                         AS  TOT_AVBL_QTY,
                                    NVL(v33.INT_RT, 0)          AS  APY_INT_RT
                              FROM
                                    (   SELECT  v41.ACNT_NO                 AS  ACNT_NO,
                                                v41.SUB_NO                  AS  SUB_NO,
                                                SUM(NVL(v41.OWN_QTY, 0))    AS  TOT_QTY
                                          FROM  VN.SSB01H00 v41 /* ?¼별?고?보 */
                                         WHERE  v41.RGT_STD_DT  >=  V_MAK_STRT_DT
                                           AND  v41.RGT_STD_DT  <=  V_MAK_END_DT
                                           AND  v41.RGT_STD_DT  <>  VN.VHDATE
                                           AND  v41.ACNT_NO     =   V_ACNT_NO
                                           AND  v41.SUB_NO      =   V_SUB_NO
                                      GROUP BY  v41.ACNT_NO, v41.SUB_NO
                                        HAVING  SUM(NVL(v41.OWN_QTY, 0))    >   0
                                    )           v31,
                                    VN.AAA01M00 v32,
                                    (   SELECT  v41.INT_RT      AS  INT_RT
                                          FROM  VN.SSB08C00 v41     /* ?수료逫¦?*/
                                         WHERE  v41.INT_RT_TP   =   K_INT_RT_TP
                                           AND  v41.CUST_GRD    =   K_CUST_GRD
                                           AND  v41.END_DT      =   K_MAX_DT        /* '30000101' */
                                    )           v33
                             WHERE  v31.ACNT_NO     =   v32.ACNT_NO
                               AND  v31.SUB_NO      =   v32.SUB_NO
                               AND  v32.ACNT_STAT   =   '1'
                        )           v21
                 WHERE  ROUND((v21.APY_INT_RT / 30 ) * NVL(v21.TOT_AVBL_QTY, 0))    >   0
              ORDER BY  v21.ACNT_NO, v21.SUB_NO ;

            EXCEPTION WHEN OTHERS THEN
                V_TOT_DT_CNT        := C1.TOT_DT_CNT ;
                V_TOT_QTY           := C1.TOT_QTY ;
                V_TOT_AVBL_QTY      := C1.TOT_AVBL_QTY ;
                V_APY_INT_RT        := C1.APY_INT_RT ;
                V_USEFEE            := C1.USEFEE  ;
            END ;

        END IF ;        -- T_CNT > 0 End If


    END LOOP ;   -- C1 End Loop
    
    V_USEFEE := NVL(V_USEFEE,0);

    O_AMT := V_USEFEE ;

END pss_fix_usefee_pay_q ;
/

