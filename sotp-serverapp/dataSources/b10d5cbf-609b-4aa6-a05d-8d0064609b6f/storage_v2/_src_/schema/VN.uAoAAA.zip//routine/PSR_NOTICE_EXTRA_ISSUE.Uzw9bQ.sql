create procedure psr_notice_extra_issue
as
vs_msg_lang       varchar2(1);
vs_fnc_cd         varchar2(6) := 'F02109';
vs_rgt_std_dt     varchar2(10);
vs_stk_cd         varchar2(20);
vn_asn_qty        varchar2(20);
vs_sms_msg        varchar2(200);
vs_acnt_no        varchar2(10);
vs_sub_no         varchar2(2);
vs_work_mn        varchar2(20) := 'SYSTEM';
vs_work_trm       varchar2(20) := 'SYSTEM';

/* ******************************* Log Changes *******************************
Purpose: This procedure send SMS to clients who still not do right extra issue

11-Jan-2019 vnjvthangnm Initilization
*************************************************************************** */
begin
  if vwdate = to_char(sysdate,'YYYYMMDD') then
    for c1 in
      (select rgt_std_dt,stk_cd,rgt_tp,sbst_lst_dt,seq_no
         from vn.srr01m00
        where rgt_tp = '1'
          and rgt_proc_stat = '3'
          and sbst_lst_dt = vwdate) /* Hom nay la ngay het han dang ky mua PHT*/
    loop
      for c2 in (
        select s2.acnt_no, s2.sub_no, s2.stk_cd, s2.asn_qty, s2.rgt_std_dt, s2.rgt_tp, s2.seq_no
          from vn.srr02m00 s2
         where s2.rgt_std_dt = c1.rgt_std_dt
           and s2.stk_cd = c1.stk_cd
           and s2.rgt_tp = c1.rgt_tp
           and s2.seq_no = c1.seq_no
           and not exists (select 1
                             from vn.srr06m00 s6
                            where s2.acnt_no = s6.acnt_no
                              and s2.sub_no = s6.sub_no
                              and s2.rgt_tp = s6.rgt_tp
                              and s2.stk_cd = s6.stk_cd
                              and s2.rgt_std_dt = s6.rgt_std_dt
                              and s6.anth_cd is null)) /* Tim tai khoan chua dang ky mua PHT*/
      loop
        vs_acnt_no := c2.acnt_no;
        vs_sub_no := c2.sub_no;
        vs_stk_cd := c2.stk_cd;

        select decode(acnt_tp, 'F', 'E', 'V') msg_lang
          into vs_msg_lang
          from vn.aaa01m00
         where acnt_no = vs_acnt_no
           and sub_no = vs_sub_no;

        vn_asn_qty := vn.fxc_format_number (c2.asn_qty,0,vs_msg_lang);

        if vs_msg_lang = 'V' then
          vn.pxc_log_write('psr_notice_extra_issue', 'tieng viet');
          vs_rgt_std_dt := substr(c2.rgt_std_dt,-2) || '/' || substr(c2.rgt_std_dt,5,2) || '/' || substr(c2.rgt_std_dt,1,4);
          vs_sms_msg := '||' || vs_rgt_std_dt || '||' || vs_stk_cd || '||' || vn_asn_qty;
        elsif vs_msg_lang = 'E' then
          vn.pxc_log_write('psr_notice_extra_issue', 'tieng anh');
          vs_rgt_std_dt := substr(c2.rgt_std_dt,-2) || '.' || substr(c2.rgt_std_dt,5,2) || '.' || substr(c2.rgt_std_dt,1,4);
          vs_sms_msg := '||' || vs_stk_cd || '||' || vn_asn_qty || '||' || vs_rgt_std_dt;
        end if;

        vn.pxc_log_write('psr_notice_extra_issue', 'Account: ' || vs_acnt_no || '-' || vs_sub_no
                                                  || ', vs_sms_msg: ' || vs_sms_msg);
        begin
          vn.pxc_sms_ins(
            null,         --i_send_dt          in varchar2,                         -- can put NULL, get from sysdate
            null,         --i_recv_phone_no    in varchar2,                         -- can put NULL, get from account
            null,         --i_send_phone_no    in varchar2,                         -- can put NULL, get from company
            vs_fnc_cd,    --i_func_cd          in varchar2,                         -- NOT null
            null,         --i_msg_lang         in varchar2,                         -- can put NULL, get from account
            vs_sms_msg,   --i_sms_msg          in varchar2,                         -- NOT null
            vs_work_mn,   --i_work_mn          in varchar2,                         -- can put NULL
            vs_work_trm,  --i_work_trm         in varchar2,                         -- can put NULL
            vs_acnt_no,   --i_acnt_no          in varchar2      default null,       -- can put NULL
            vs_sub_no     --i_sub_no           in varchar2      default null        -- can put NULL
          );
        exception
          when others then
            vn.pxc_log_write('psr_notice_extra_issue', 'SMS send ERROR for ' || vs_acnt_no || '-' || vs_sub_no
                                                      || ', rgt_std_dt: ' || vs_rgt_std_dt || ', stk_cd: ' || vs_stk_cd);
            vn.pxc_log_write('psr_notice_extra_issue','SQL Error: ' || sqlcode);
        end;

        vn.pxc_log_write('psr_notice_extra_issue', 'SMS sent for ' || vs_acnt_no || '-' || vs_sub_no);
        
        /* Push notification */
        begin
          vn.pxc_notif_ins(
            vs_acnt_no, --i_acnt_no          in varchar2,    -- NOT NULL
            vs_sub_no,  --i_sub_no           in varchar2,    -- NOT NULL
            vs_fnc_cd,  --i_func_cd          in varchar2,    -- NOT null
            null,       --i_msg_lang         in varchar2,    -- can put NULL, get from account
            vs_sms_msg, --i_sms_msg          in varchar2,    -- NOT null
            '1',        --i_notif_tp         in varchar2,    -- NOT null
            vs_work_mn,  --i_work_mn          in varchar2,    -- can put NULL
            vs_work_trm  --i_work_trm         in varchar2     -- can put NULL
          );
        exception
          when others then
            vn.pxc_log_write('psr_notice_extra_issue', 'Push notify ERROR for ' || vs_acnt_no || '-' || vs_sub_no
                                                      || ', rgt_std_dt: ' || vs_rgt_std_dt || ', stk_cd: ' || vs_stk_cd);
            vn.pxc_log_write('psr_notice_extra_issue','SQL Error: ' || sqlcode);
        end;

      end loop; -- end c2
    end loop; -- end c1
    vn.pxc_log_write('psr_notice_extra_issue', 'Finished.');
  else
    vn.pxc_log_write('psr_notice_extra_issue', 'Flag Check.');
  end if;
end psr_notice_extra_issue;
/

