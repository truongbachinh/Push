create function    fbm_get_mon_dt(
    i_dt        varchar2
)
return number

/*
    select vn.fbm_get_mon_dt(vn.vwdate) mon_dt
    from dual;
*/

as
    t_cls_day               varchar2(8);
    t_cls_dt                varchar2(8);
    t_last_dt_month         varchar2(8);
    t_last_dt_calc_sales    varchar2(20);
    t_mon_dt                varchar2(8);
    t_cnt                   number;

    o_mon_dt                varchar2(6);
begin
    -- Kiem tra xem chu ky nay da duoc tinh hoa hong hay chua
    select count(*) cnt
    into t_cnt
    from vn.rms10m00 
    where i_dt between st_dt and ed_dt
    ;

    -- Neu da duoc tinh hoa hong, thi lay luon trong bang rms10m00
    if(t_cnt > 0) then
        select mon_dt
        into t_mon_dt
        from vn.rms10m00
        where i_dt between st_dt and ed_dt;

        o_mon_dt := t_mon_dt;

        return o_mon_dt;

    -- Neu chua duoc tinh hoa hong, thi lay tu tham so he thong
    else
        t_cls_day   := vn.fxc_col_cd_tp('last_dt_calc_sales');

        t_cls_dt    := substr(i_dt, 1, 6) || t_cls_day;

        t_last_dt_month := to_char(last_day(to_date(i_dt, 'YYYYMMDD')), 'YYYYMMDD');

        t_cls_dt    := least(t_cls_dt, t_last_dt_month);

        if (i_dt <= t_cls_dt) then
            t_mon_dt := t_cls_dt;
        else
            t_mon_dt := to_char(add_months(to_date(t_cls_dt, 'YYYYMMDD'), 1), 'YYYYMMDD');
        end if;

        o_mon_dt := substr(t_mon_dt, 1, 6);

        return o_mon_dt;

    end if;
end;
/

