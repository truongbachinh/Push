create PROCEDURE PGG_JOB_RECV_SND_SLIP2
/********************
    CREATE RECEIVE VOUCHER (FOR SEND LIST) : 수신전표 생성(수기발신전표에 대한)
     -. Using Account 136/336 and 180, so  the voucher is alwasy  transfering voucher...
********************/
(   I_SLIP_DT                   IN  VARCHAR2        --  VOUCHER DATE
   ,I_BRCH_CD                   IN  VARCHAR2        --  SENDER
   ,I_AGNC_BRCH                 IN  VARCHAR2        --  SENDER
   ,I_SLIP_NO                   IN  VARCHAR2        --  VOUCHER NO (SENDING VOUCHER NO)
   ,I_SLIP_SUB_NO               IN  VARCHAR2        --  VOUCHER NO (SENDING VOUCHER NO)
)IS

    T_RECV_BNH_CD         GGA06M00.OPR_BNH_CD%TYPE;
    T_RECV_AGNC_BRCH      GGA06M00.OPR_AGNC_BRCH%TYPE;
    T_WORK_MN             GGA06M00.WORK_MN%TYPE;
    T_WORK_TRM            GGA06M00.WORK_TRM%TYPE   ;
    T_ACC_ACT_CD          GGA06M00.ACC_ACT_CD%TYPE   ;
    T_DR_CR_TP            GGA06M00.DR_CR_TP%TYPE      ;           --차변대변구분(1:차변,2:대변)
    T_RMRK_ROB_TP         GGA06M00.RMRK_JOB_TP%TYPE    ;          --적요업무구분
    T_TRD_CNTE            GGA06M00.TRD_CNTE%TYPE       ;          --거래비고
    T_SLIP_AMT            GGA06M00.SLIP_AMT%TYPE        ;         --전표금액

    T_OPR_ACC_ACT_CD      GGA06M00.ACC_ACT_CD%TYPE   ;
    T_OPR_ACC_ACT_CD2     GGA06M00.ACC_ACT_CD%TYPE   ;
    T_OPR_DR_CR_TP        GGA06M00.DR_CR_TP%TYPE      ;           --차변대변구분(1:차변,2:대변)

    T_GGA06M00_SLIP_DT             GGA06M00.SLIP_DT%TYPE;              --전표일자
    T_GGA06M00_BRCH_CD             GGA06M00.BRCH_CD%TYPE;              --지점코드
    T_GGA06M00_AGNC_BRCH           GGA06M00.AGNC_BRCH%TYPE;            --대리지점
    T_GGA06M00_SLIP_NO             GGA06M00.SLIP_NO%TYPE;              --전표번호
    T_GGA06M00_SLIP_SUB_NO         GGA06M00.SLIP_SUB_NO%TYPE;          --전표부번호
    T_GGA06M00_RMRK_JOB_TP         GGA06M00.RMRK_JOB_TP%TYPE;          --적요업무구분
    T_GGA06M00_SLIP_TP             GGA06M00.SLIP_TP%TYPE;              --전표구분
    T_GGA06M00_ACC_RMRK_CD         GGA06M00.ACC_RMRK_CD%TYPE;          --회계적요코드
    T_GGA06M00_TRD_CNTE            GGA06M00.TRD_CNTE%TYPE;             --거래비고
    T_GGA06M00_DR_CR_TP            GGA06M00.DR_CR_TP%TYPE;             --차변대변구분
    T_GGA06M00_ACC_ACT_CD          GGA06M00.ACC_ACT_CD%TYPE;           --회계계정코드
    T_GGA06M00_OPR_BNH_CD          GGA06M00.OPR_BNH_CD%TYPE;           --상대부점코드
    T_GGA06M00_OPR_AGNC_BRCH       GGA06M00.OPR_AGNC_BRCH%TYPE;        --상대대리지점
    T_GGA06M00_SLIP_AMT            GGA06M00.SLIP_AMT%TYPE;             --전표금액
    T_GGA06M00_DETL_CNTE           GGA06M00.DETL_CNTE%TYPE;            --상세비고
    T_GGA06M00_RECV_SND_TP         GGA06M00.RECV_SND_TP%TYPE;          --수신발신구분
    T_GGA06M00_RECV_YN             GGA06M00.RECV_YN%TYPE;              --수신여부
    T_GGA06M00_AUTO_TP             GGA06M00.AUTO_TP%TYPE;              --자동구분
    T_GGA06M00_SLIP_STAT           GGA06M00.SLIP_STAT%TYPE;            --전표상태
    T_GGA06M00_DRAF_MN             GGA06M00.DRAF_MN%TYPE;              --기안자
    T_GGA06M00_DRAF_DTM            GGA06M00.DRAF_DTM%TYPE;             --기안일시
    T_GGA06M00_CNFM_MN             GGA06M00.CNFM_MN%TYPE;              --승인자
    T_GGA06M00_CNFM_DTM            GGA06M00.CNFM_DTM%TYPE;             --승인일시
    T_GGA06M00_CUST_CD             GGA06M00.CUST_CD%TYPE;              --거래처코드
    T_GGA06M00_SUP_PRI_AMT         GGA06M00.SUP_PRI_AMT%TYPE;          --공급가액
    T_GGA06M00_VAT_AMT             GGA06M00.VAT_AMT%TYPE;              --부가세액
    T_GGA06M00_EVI_TP              GGA06M00.EVI_TP%TYPE;               --증빙구분
    T_GGA06M00_EVI_DT              GGA06M00.EVI_DT%TYPE;               --증빙일자
    T_GGA06M00_EVI_NO              GGA06M00.EVI_NO%TYPE;               --증빙번호
    T_GGA06M00_TAXB_NO             GGA06M00.TAXB_NO%TYPE;              --세무번호
    T_GGA06M00_ORIG_ACNT_NO        GGA06M00.ORIG_ACNT_NO%TYPE;         --원천계좌번호
    T_GGA06M00_ORIG_TRD_DT         GGA06M00.ORIG_TRD_DT%TYPE;          --원천거래일
    T_GGA06M00_ORIG_TRD_SEQ_NO     GGA06M00.ORIG_TRD_SEQ_NO%TYPE;      --원천거래일련번호
    T_GGA06M00_RECV_SND_NO         GGA06M00.RECV_SND_NO%TYPE;          --수신발신번호
    T_GGA06M00_WORK_MN             GGA06M00.WORK_MN%TYPE;              --처리자
    T_GGA06M00_WORK_DTM            GGA06M00.WORK_DTM%TYPE;             --처리일시
    T_GGA06M00_WORK_TRM            GGA06M00.WORK_TRM%TYPE;             --처리단말


    T_GGA06M01_RECV_SND_NO         GGA06M01.RECV_SND_NO%TYPE;          --수신발신번호
    T_GGA06M01_SLIP_DT             GGA06M01.SLIP_DT%TYPE;              --전표일자
    T_GGA06M01_BRCH_CD             GGA06M01.BRCH_CD%TYPE;              --지점코드
    T_GGA06M01_AGNC_BRCH           GGA06M01.AGNC_BRCH%TYPE;            --대리지점
    T_GGA06M01_SLIP_NO             GGA06M01.SLIP_NO%TYPE;              --전표번호
    T_GGA06M01_SLIP_SUB_NO         GGA06M01.SLIP_SUB_NO%TYPE;          --전표부번호
    T_GGA06M01_RECV_SLIP_DT        GGA06M01.RECV_SLIP_DT%TYPE;         --수신전표일자
    T_GGA06M01_RECV_BNH_CD         GGA06M01.RECV_BNH_CD%TYPE;          --수신부점코드
    T_GGA06M01_RECV_AGNC_BRCH      GGA06M01.RECV_AGNC_BRCH%TYPE;       --수신대리지점
    T_GGA06M01_RECV_SLIP_NO        GGA06M01.RECV_SLIP_NO%TYPE;         --수신전표번호
    T_GGA06M01_RECV_SLIP_SUB_NO    GGA06M01.RECV_SLIP_SUB_NO%TYPE;     --수신전표부번호
    T_GGA06M01_RECV_ACT_CD         GGA06M01.RECV_ACT_CD%TYPE;          --수신계정코드
    T_GGA06M01_RECV_YN             GGA06M01.RECV_YN%TYPE;              --수신여부
    T_GGA06M01_WORK_MN             GGA06M01.WORK_MN%TYPE;              --처리자
    T_GGA06M01_WORK_DTM            GGA06M01.WORK_DTM%TYPE;             --처리일시
    T_GGA06M01_WORK_TRM            GGA06M01.WORK_TRM%TYPE;             --처리단말
    T_GGA06M01_RECV_ACC_RMRK_CD    GGA06M01.RECV_ACC_RMRK_CD%TYPE;     --수신적요코드


    T_SLIP_OCUR_YN    VARCHAR2(1);     -- 실계정여부
    T_HEAD_BRCH_TP  XCC90M00.HEAD_BRCH_TP%TYPE;

    T_ROWID     ROWID;
    T_CNT       NUMBER;

BEGIN

        --수발신내역 수발신번호 채번
        SELECT  NVL(MAX(RECV_SND_NO),0) + 1
          INTO  T_GGA06M01_RECV_SND_NO
          FROM  GGA06M01;



        -- 발신 전표정보 가져오기
        SELECT  A.OPR_BNH_CD
               ,A.OPR_AGNC_BRCH
               ,A.WORK_MN
               ,A.WORK_TRM
               ,A.ACC_ACT_CD
               ,A.DR_CR_TP
               ,A.RMRK_JOB_TP
               ,A.TRD_CNTE
               ,A.SLIP_AMT
               ,A.ROWID
          INTO  T_RECV_BNH_CD         --수신부점코드
               ,T_RECV_AGNC_BRCH      --수신대리지점
               ,T_WORK_MN             --처리자
               ,T_WORK_TRM            --처리단말
               ,T_ACC_ACT_CD
               ,T_DR_CR_TP                      --차변대변구분(1:차변,2:대변)
               ,T_RMRK_ROB_TP                   --적요업무구분
               ,T_TRD_CNTE                      --거래비고
               ,T_SLIP_AMT                      --전표금액
               ,T_ROWID
          FROM  GGA06M00 A
         WHERE  A.SLIP_DT       =   I_SLIP_DT
           AND  A.BRCH_CD       =   I_BRCH_CD
           AND  A.AGNC_BRCH     =   I_AGNC_BRCH
           AND  A.SLIP_NO       =   I_SLIP_NO
           AND  A.SLIP_SUB_NO   =   I_SLIP_SUB_NO;


        --발신정보 이므로 발신전표정보에 수발신 번호 UPDATE
        UPDATE GGA06M00
           SET RECV_SND_NO = T_GGA06M01_RECV_SND_NO     --수발신번호
         WHERE ROWID = T_ROWID;

--dbms_output.put_line('...['||T_RECV_BNH_CD||']['||T_RECV_AGNC_BRCH||']['||T_ACC_ACT_CD||']['||T_DR_CR_TP||']');

        -- 본지점 현금(지점입장)  ==> 상대계정 = 지점에 있는 본사의 돈(본사입장)
        IF      T_ACC_ACT_CD = '136000000000' THEN T_OPR_ACC_ACT_CD   :=  '336000000000';
        ELSIF   T_ACC_ACT_CD = '336000000000' THEN T_OPR_ACC_ACT_CD   :=  '136000000000';
        ELSE
            RAISE_APPLICATION_ERROR(-20010,'INVALID HEAD-BRANCH ACC_CD['||T_ACC_ACT_CD||']');
        END IF;

        T_OPR_ACC_ACT_CD2  :=  '181000000000' ; --	임시자산(제좌)



        -- 차대구분(T_OPR_ACC_ACT_CD 의 차대구분; T_OPR_ACC_ACT_CD2의 차대구분은 T_DR_CR_TP가 된다)
        IF  T_DR_CR_TP  =   '1' THEN    T_OPR_DR_CR_TP  :=  '2';
        ELSE                            T_OPR_DR_CR_TP  :=  '1';
        END IF;



        -- Create slip no (
        T_GGA06M00_SLIP_NO          :=  FGG_GET_SLIP_NO(T_RECV_BNH_CD,T_RECV_AGNC_BRCH,I_SLIP_DT,'3');  --전표번호



        T_GGA06M00_ORIG_ACNT_NO     :=  NULL;      --원천계좌번호
        T_GGA06M00_ORIG_TRD_DT      :=  NULL;      --원천거래일
        T_GGA06M00_ORIG_TRD_SEQ_NO  :=  NULL;      --원천거래일련번호

        T_GGA06M00_SLIP_DT      :=  I_SLIP_DT;              --전표일자
        T_GGA06M00_BRCH_CD      :=  T_RECV_BNH_CD;          --지점코드
        T_GGA06M00_AGNC_BRCH    :=  T_RECV_AGNC_BRCH;       --대리지점
        T_GGA06M00_RMRK_JOB_TP  :=  T_RMRK_ROB_TP;          --적요업무구분
        T_GGA06M00_SLIP_TP      :=  '3';                    --적요입출구분(3:대체전표)
        T_GGA06M00_ACC_RMRK_CD  :=  NULL;                   --적요코드
        T_GGA06M00_TRD_CNTE     :=  T_TRD_CNTE;             --비고

        T_GGA06M00_DETL_CNTE    :=  '';             --상세비고
        T_GGA06M00_RECV_YN      :=  'Y';            --수신여부
        T_GGA06M00_AUTO_TP      :=  '2';            --자동구분(1:자동전표,2:수기전표)
        T_GGA06M00_SLIP_STAT    :=  '1';            --전표상태(1:미승인,2:승인,3:반려,4:취소)  -- 뒤에서 '2'로 바꾸는 로직 있음
        T_GGA06M00_DRAF_MN      :=  'SYSTEM';       --기안자
        T_GGA06M00_DRAF_DTM     :=  SYSDATE ;       --기안일시
        T_GGA06M00_CNFM_MN      :=  'SYSTEM';       --승인자
        T_GGA06M00_CNFM_DTM     :=  SYSDATE ;       --승인일시
     --   T_GGA06M00_CUST_CD      :=  NULL;           --거래처코드
        T_GGA06M00_SUP_PRI_AMT  :=  NULL;           --공급가액
        T_GGA06M00_VAT_AMT      :=  NULL;           --부가세액
        T_GGA06M00_EVI_TP       :=  NULL;           --증빙구분
        T_GGA06M00_EVI_DT       :=  NULL;           --증빙일자
        T_GGA06M00_EVI_NO       :=  NULL;           --증빙번호
        T_GGA06M00_TAXB_NO      :=  NULL;           --세무번호
        T_GGA06M00_WORK_MN      :=  'SYSTEM';       --처리자
        T_GGA06M00_WORK_DTM     :=  SYSDATE;        --처리일시
        T_GGA06M00_WORK_TRM     :=  'SYSTEM';       --처리단말
        T_GGA06M00_SLIP_AMT     :=  T_SLIP_AMT;     --전표금액

        -- =============
        -- 수신전표 INSERT
        -- =============
        T_CNT   :=  1;
        -- 전표 입력 2번(1인경우는 본지점계정, 2인경우는 제좌계정)
        WHILE   T_CNT <=2   LOOP

            T_GGA06M00_SLIP_SUB_NO  :=  TO_CHAR(T_CNT,'FM000');  --전표부번호

            --본지점 계정인 경우
            IF  T_CNT   =   1   THEN
                T_GGA06M00_DR_CR_TP     :=  T_OPR_DR_CR_TP;             --차대구분
                T_GGA06M00_ACC_ACT_CD   :=  T_OPR_ACC_ACT_CD;           --계정
                T_GGA06M00_OPR_BNH_CD   :=  I_BRCH_CD;                  --상대부점코드
                T_GGA06M00_OPR_AGNC_BRCH:=  I_AGNC_BRCH;                --상대부점코드(출장소)
                T_GGA06M00_RECV_SND_TP  :=  '2';                        --수발신 구분(2:수신,9:기타)
                T_GGA06M00_RECV_SND_NO  :=  T_GGA06M01_RECV_SND_NO;     --수신발신번호
                T_GGA06M01_RECV_ACT_CD  :=  T_GGA06M00_SLIP_SUB_NO;     --수발신내역 수신전표 SUB 번호




                SELECT  A.HEAD_BRCH_TP          --(0:본사, 1:지점, 2:출장소)
                  INTO  T_HEAD_BRCH_TP
                  FROM  XCC90M00 A  -- 지점정보
                 WHERE  A.BRCH_CD   = T_GGA06M00_OPR_BNH_CD
                   AND  A.AGNC_BRCH = '00';
                --본사부서인경우
                IF T_HEAD_BRCH_TP = '0' THEN
                    T_GGA06M00_CUST_CD := 'HD00000' ||T_GGA06M00_OPR_BNH_CD;   --고객코드는 상대방부서(본사부서)
                --지점인경우
                ELSE
                    T_GGA06M00_CUST_CD := 'BR00000' ||T_GGA06M00_OPR_BNH_CD;  --고객코드는 상대방부서(지점)
                END IF;





            --제좌계정인 경우
            ELSE
                T_GGA06M00_DR_CR_TP     :=  T_DR_CR_TP;                 --차대구분
                T_GGA06M00_ACC_ACT_CD   :=  T_OPR_ACC_ACT_CD2;          --계정
                T_GGA06M00_OPR_BNH_CD   :=  NULL;                       --상대부점코드
                T_GGA06M00_OPR_AGNC_BRCH:=  NULL;                       --상대부점코드(출장소)
                T_GGA06M00_RECV_SND_TP  :=  '9';                        --수발신 구분(2:수신,9:기타)
                T_GGA06M00_RECV_SND_NO  :=  NULL;                       --수신발신번호


                SELECT  A.HEAD_BRCH_TP          --(0:본사, 1:지점, 2:출장소)
                  INTO  T_HEAD_BRCH_TP
                  FROM  XCC90M00 A  -- 지점정보
                 WHERE  A.BRCH_CD   = T_GGA06M00_BRCH_CD
                   AND  A.AGNC_BRCH = '00';
                --본사부서인경우
                IF T_HEAD_BRCH_TP = '0' THEN
                    T_GGA06M00_CUST_CD := 'HD00000' ||T_GGA06M00_BRCH_CD;   --고객코드는 자신(본사부서)
                --지점인경우
                ELSE
                    T_GGA06M00_CUST_CD := 'BR00000' ||T_GGA06M00_BRCH_CD;  --고객코드는 자신(지점)
                END IF;



            END IF;

            --계정이 실계정인지 검사
            SELECT NVL(SLIP_OCUR_YN,'N')
              INTO T_SLIP_OCUR_YN
              FROM GGA02C00
             WHERE ACC_ACT_CD = T_GGA06M00_ACC_ACT_CD;

            IF  T_SLIP_OCUR_YN <> 'Y' THEN
                RAISE_APPLICATION_ERROR(-20001,'['||T_GGA06M00_ACC_ACT_CD ||'] is Not Slip Occur Account !!');
            END IF;



            -- =============
            -- GGA06M00(VOUCHER) INSERT
            -- =============

            INSERT INTO GGA06M00
            (
                 SLIP_DT                --전표일자
                ,BRCH_CD                --지점코드
                ,AGNC_BRCH              --대리지점
                ,SLIP_NO                --전표번호
                ,SLIP_SUB_NO            --전표부번호
                ,RMRK_JOB_TP            --적요업무구분
                ,SLIP_TP                --전표구분
                ,ACC_RMRK_CD            --회계적요코드
                ,TRD_CNTE               --거래비고
                ,DR_CR_TP               --차변대변구분
                ,ACC_ACT_CD             --회계계정코드
                ,OPR_BNH_CD             --상대부점코드
                ,OPR_AGNC_BRCH          --상대대리지점
                ,SLIP_AMT               --전표금액
                ,DETL_CNTE              --상세비고
                ,RECV_SND_TP            --수신발신구분
                ,RECV_YN                --수신여부
                ,AUTO_TP                --자동구분
                ,SLIP_STAT              --전표상태
                ,DRAF_MN                --기안자
                ,DRAF_DTM               --기안일시
                ,CNFM_MN                --승인자
                ,CNFM_DTM               --승인일시
                ,CUST_CD                --거래처코드
                ,SUP_PRI_AMT            --공급가액
                ,VAT_AMT                --부가세액
                ,EVI_TP                 --증빙구분
                ,EVI_DT                 --증빙일자
                ,EVI_NO                 --증빙번호
                ,TAXB_NO                --세무번호
                ,ORIG_ACNT_NO           --원천계좌번호
                ,ORIG_TRD_DT            --원천거래일
                ,ORIG_TRD_SEQ_NO        --원천거래일련번호
                ,RECV_SND_NO            --수신발신번호
                ,WORK_MN                --처리자
                ,WORK_DTM               --처리일시
                ,WORK_TRM               --처리단말
            )
            VALUES
            (
                 T_GGA06M00_SLIP_DT         --전표일자
                ,T_GGA06M00_BRCH_CD         --지점코드
                ,T_GGA06M00_AGNC_BRCH       --대리지점
                ,T_GGA06M00_SLIP_NO         --전표번호
                ,T_GGA06M00_SLIP_SUB_NO     --전표부번호
                ,T_GGA06M00_RMRK_JOB_TP     --적요업무구분
                ,T_GGA06M00_SLIP_TP         --전표구분
                ,T_GGA06M00_ACC_RMRK_CD     --회계적요코드
                ,T_GGA06M00_TRD_CNTE        --거래비고
                ,T_GGA06M00_DR_CR_TP        --차변대변구분
                ,T_GGA06M00_ACC_ACT_CD      --회계계정코드
                ,T_GGA06M00_OPR_BNH_CD      --상대부점코드
                ,T_GGA06M00_OPR_AGNC_BRCH   --상대대리지점
                ,T_GGA06M00_SLIP_AMT        --전표금액
                ,T_GGA06M00_DETL_CNTE       --상세비고
                ,T_GGA06M00_RECV_SND_TP     --수신발신구분
                ,T_GGA06M00_RECV_YN         --수신여부
                ,T_GGA06M00_AUTO_TP         --자동구분
                ,T_GGA06M00_SLIP_STAT       --전표상태
                ,T_GGA06M00_DRAF_MN         --기안자
                ,T_GGA06M00_DRAF_DTM        --기안일시
                ,T_GGA06M00_CNFM_MN         --승인자
                ,T_GGA06M00_CNFM_DTM        --승인일시
                ,T_GGA06M00_CUST_CD         --거래처코드
                ,T_GGA06M00_SUP_PRI_AMT     --공급가액
                ,T_GGA06M00_VAT_AMT         --부가세액
                ,T_GGA06M00_EVI_TP          --증빙구분
                ,T_GGA06M00_EVI_DT          --증빙일자
                ,T_GGA06M00_EVI_NO          --증빙번호
                ,T_GGA06M00_TAXB_NO         --세무번호
                ,T_GGA06M00_ORIG_ACNT_NO    --원천계좌번호
                ,T_GGA06M00_ORIG_TRD_DT     --원천거래일
                ,T_GGA06M00_ORIG_TRD_SEQ_NO --원천거래일련번호
                ,T_GGA06M00_RECV_SND_NO     --수신발신번호
                ,T_GGA06M00_WORK_MN         --처리자
                ,T_GGA06M00_WORK_DTM        --처리일시
                ,T_GGA06M00_WORK_TRM        --처리단말
            );


            T_CNT   :=  T_CNT   +1;
        END LOOP;

        -- =============
        -- 전표승인처리 : GGA08M00(DAILY STATISTICS) APPLY , 전표상태 ==> 승인(2)
        -- 일계반영
        -- =============
        PGG_SLIP_APPROVAL
        (
            'A'                     -- 'A' : Approval, 'C' : Approval Cancel, 'R' :Return, 'X' : DisUse
           ,T_GGA06M00_BRCH_CD      -- PROCESSING BRANCH CODE
           ,T_GGA06M00_AGNC_BRCH    -- PROCESSING BRANCH CODE(AGNC)
           ,T_GGA06M00_SLIP_DT      -- SLIP DATE
           ,T_GGA06M00_SLIP_NO      -- SLIP No.
           ,'SYSTEM'
        );



        -- =============
        -- 수발신내역 INSERT
        -- =============

        --발신정보 지정
        T_GGA06M01_SLIP_DT          :=  I_SLIP_DT;              --전표일자
        T_GGA06M01_BRCH_CD          :=  I_BRCH_CD;              --발신지점
        T_GGA06M01_AGNC_BRCH        :=  I_AGNC_BRCH;            --발신지점(출장소)
        T_GGA06M01_SLIP_NO          :=  I_SLIP_NO;              --전표번호
        T_GGA06M01_SLIP_SUB_NO      :=  I_SLIP_SUB_NO;          --전표부번호
        T_GGA06M01_RECV_SLIP_DT     :=  T_GGA06M00_SLIP_DT;     --수신전표일자(수신전표 처리시 입력)
        T_GGA06M01_RECV_BNH_CD      :=  T_RECV_BNH_CD    ;      --수신부점코드
        T_GGA06M01_RECV_AGNC_BRCH   :=  T_RECV_AGNC_BRCH ;      --수신대리지점
        T_GGA06M01_RECV_SLIP_NO     :=  T_GGA06M00_SLIP_NO;     --수신전표번호(수신전표 처리시 입력)
        T_GGA06M01_RECV_SLIP_SUB_NO :=  T_GGA06M00_SLIP_SUB_NO; --수신전표부번호(수신전표 처리시 입력)
--        T_GGA06M01_RECV_ACT_CD      :=  T_OPR_ACC_ACT_CD;      --수신계정코드
        T_GGA06M01_RECV_YN          :=  'Y';                    --수신여부(수신전표 처리시 입력)
        T_GGA06M01_WORK_MN          :=  T_GGA06M00_WORK_MN;     --처리자
        T_GGA06M01_WORK_DTM         :=  SYSDATE;                --처리일시
        T_GGA06M01_WORK_TRM         :=  T_GGA06M00_WORK_TRM;    --처리단말
        T_GGA06M01_RECV_ACC_RMRK_CD :=  NULL;                   --수신적요코드


        --수발신내역 INSERT
        INSERT  INTO    GGA06M01
        (
             RECV_SND_NO          --수신발신번호
            ,SLIP_DT              --전표일자
            ,BRCH_CD              --지점코드
            ,AGNC_BRCH            --대리지점
            ,SLIP_NO              --전표번호
            ,SLIP_SUB_NO          --전표부번호
            ,RECV_SLIP_DT         --수신전표일자
            ,RECV_BNH_CD          --수신부점코드
            ,RECV_AGNC_BRCH       --수신대리지점
            ,RECV_SLIP_NO         --수신전표번호
            ,RECV_SLIP_SUB_NO     --수신전표부번호
            ,RECV_ACT_CD          --수신계정코드
            ,RECV_YN              --수신여부
            ,RECV_ACC_RMRK_CD     --수신적요
            ,WORK_MN              --처리자
            ,WORK_DTM             --처리일시
            ,WORK_TRM             --처리단말
        )
        VALUES
        (
             T_GGA06M01_RECV_SND_NO       --발신번호
            ,T_GGA06M01_SLIP_DT           --전표일자
            ,T_GGA06M01_BRCH_CD           --발신지점
            ,T_GGA06M01_AGNC_BRCH         --발신지점(출장소)
            ,T_GGA06M01_SLIP_NO           --전표번호
            ,T_GGA06M01_SLIP_SUB_NO       --전표부번호
            ,T_GGA06M01_RECV_SLIP_DT      --수신전표일자
            ,T_GGA06M01_RECV_BNH_CD       --수신부점코드
            ,T_GGA06M01_RECV_AGNC_BRCH    --수신대리지점
            ,T_GGA06M01_RECV_SLIP_NO      --수신전표번호
            ,T_GGA06M01_RECV_SLIP_SUB_NO  --수신전표부번호
            ,T_GGA06M01_RECV_ACT_CD       --수신계정코드
            ,T_GGA06M01_RECV_YN           --수신여부
            ,T_GGA06M01_RECV_ACC_RMRK_CD  --수신적요
            ,T_GGA06M01_WORK_MN           --처리자
            ,T_GGA06M01_WORK_DTM          --처리일시
            ,T_GGA06M01_WORK_TRM          --처리단말
        );
END;
/

