create procedure pts_vwdate_g
(
	o_ord_dt	in out varchar2,
    o_work_dt	in out varchar2,
	o_msg_cd	in out number
) as

	t_ret	      number := 0;
	t_dt	      date;
begin
	select sysdate
	into	t_dt
	from 	dual;

	select 	vn.vhdate(), vn.fxc_vorderdt_g(to_date(vn.vhdate(), 'yyyymmdd') , 0)
  	 into  	o_work_dt, 		o_ord_dt
  	 from   dual;

  	 if (o_work_dt != o_ord_dt) then
		o_msg_cd := -1;
	else
		o_msg_cd := 0;
	end if;


end pts_vwdate_g;
/

