create function vhdate_char(
          i_date in varchar2
)
        return varchar2 as
begin

    return substr(i_date,7,2)||'/'||substr(i_date,5,2)||'/'||substr(i_date,1,4);

end vhdate_char;
/

