create view V_ACC_OFFSETPAYMENT as
select    decode(b.acnt_tp,'B', 'C', b.acnt_tp)       acnt_tp
           ,  a.bank_cd       bank_cd
         ,  d.bank_nm        bank_nm
         ,  sum(decode(a.sb_tp,'2', nvl(a.sb_amt,0),0)) buy_amt
         ,  sum(decode(a.sb_tp,'1', nvl(a.sb_amt,0),0)) sell_amt
         ,  sum(decode(a.sb_tp,'2', nvl(a.sb_cmsn,0),0)) buy_cmsn
         ,  sum(decode(a.sb_tp,'1', nvl(a.sb_cmsn,0),0)) sell_cmsn
         ,  sum(a.sb_tax)   sb_tax
         ,  a.mkt_trd_tp
                 , d.mth_dt  mth_dt
      from  vn.dsc01m00 a, vn.aaa01m00 b,
             (select  c.setl_dt
                   ,  c.acnt_no
                   ,  c.setl_frct_seq_no
                   ,  decode(c.bank_cd,'9999', case when substr(c.acnt_no,1,5) = '068C6'
                                                      or acnt_no = '068C000177' or acnt_no = '068C000094'
                                                    then 'VCSC HN'
                                                    else 'VCSC HCM'
                                               end
                                             , vn.faa_bank_nm_g(c.bank_cd))     bank_nm
                    , c.mth_dt
                from  vn.dsc01m00 c
              ) d
     where  a.setl_dt = d.setl_dt
       and  a.acnt_no = d.acnt_no
       and  a.setl_frct_seq_no = d.setl_frct_seq_no
       --and  b.setl_tp    like  :i_setl_tp
       and  a.acnt_no      =  b.acnt_no
       and  b.acnt_tp in ('P','C','F','B')
      group by a.mkt_trd_tp, decode(b.acnt_tp,'B', 'C', b.acnt_tp), a.bank_cd, d.bank_nm, d.mth_dt
      order by d.mth_dt, a.mkt_trd_tp, decode(b.acnt_tp,'B', 'C', b.acnt_tp), a.bank_cd, d.bank_nm
/

