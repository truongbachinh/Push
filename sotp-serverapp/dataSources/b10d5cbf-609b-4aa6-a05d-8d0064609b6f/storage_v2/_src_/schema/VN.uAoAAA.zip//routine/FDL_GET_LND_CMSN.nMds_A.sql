create function    fdl_get_lnd_cmsn
(
	i_lnd_tp          in     varchar2,        --
	i_acnt_no         in     varchar2,        --
	i_sub_no          in     varchar2,        --
	i_lnd_bank_cd     in     varchar2,        --
	i_fee_tp          in     varchar2,        -- 1:fee 2:dly_fee 3:all
	i_lnd_dt          in     varchar2,        --
	i_rpy_dt          in     varchar2,        --
	i_expr_dt         in     varchar2,        --
	i_last_rpy_dt     in     varchar2,        --
	i_cpt_rpy_tp      in     varchar2,        --
	i_int_rpy_tp      in     varchar2,        --
	i_lnd_amt         in     number,          --
	i_rpy_amt         in     number,          --
	i_remn_amt        in     number,          --
	i_lnd_fee_rt      in     number           --
) return number AS

/*!
   \file     fdl_get_lnd_cmsn.sql
   \brief    commision calculation

   \section intro Program Information
        - Program Name              : commision calculation
        - Service Name              : dl_04513_p1.pc
        - Related Client Program- Client Program ID : w_04513
        - Related Tables            : dlm12m10
        - Dev. Date                 : 2007/11/08
        - Developer                 : Han.
        - Business Logic Desc.      : commision calculation
        - Latest Modification Date  : 2007/11/08

   \section history Program Modification History
    - 1.0       2007/11/08     Han.    New.

   \section hardcoding Hard-Coding List
    - HC-1      2007/11/08     Han.    [»çÀ¯]

   \section info Additional Reference Comments
    - ¼ö¼ö·á°è»êÃ³¸®

select vn.fdl_get_lnd_cmsn('20','0001','055C000001','20080306','20080306','20080606','20080306',5925000,5925000,.0005) from dual;
*/

    t_lnd_int_cal_std_term	NUMBER := 0;
	t_lnd_int_min_term    	NUMBER := 0;
	t_lnd_int_rt            NUMBER := 0; -- 01:lnd_int ratio
	t_lnd_int_rt_min        NUMBER := 0; -- 02:lnd_int ratio for min duration
	t_lnd_int_amt_min       NUMBER := 0; -- 03:min lnd_int amt
	t_lnd_int_rt_dly        NUMBER := 0; -- 04:lnd_int dly_rt
	t_lnd_fee_rt            NUMBER := 0; -- 11:lnd_fee ratio
	t_lnd_fee_rt_min        NUMBER := 0; -- 12:lnd_fee ratio for min duration
	t_lnd_fee_amt_min       NUMBER := 0; -- 13:min lnd_fee amt
	t_lnd_fee_rt_dly        NUMBER := 0; -- 14:min lnd_fee amt

    t_apy_val               NUMBER := 0;
    t_lnd_prd               NUMBER := 0;
    t_dly_prd               NUMBER := 0;
    t_lnd_fee               NUMBER := 0;
    t_lnd_fee_dly           NUMBER := 0;
    o_lnd_fee               NUMBER := 0;

    t_sqlcode               NUMBER := 0;

    t_err_msg               VARCHAR2(500);

begin

    o_lnd_fee := 0;

/*============================================================================*/
/* Get apply loan Valiabl                                                     */
/*============================================================================*/
	if i_lnd_tp not in ('70', '80') then
		BEGIN
		vn.pdl_get_lnd_apy_val(
		    i_lnd_tp				,
		    i_acnt_no    			,
		    i_sub_no    			,
		    i_lnd_bank_cd			,
		    i_lnd_dt				,
		    i_cpt_rpy_tp			,
		    i_int_rpy_tp			,
			t_lnd_int_cal_std_term	,
			t_lnd_int_min_term    	,
		    t_lnd_int_rt            ,  -- 01:lnd_int ratio
		    t_lnd_int_rt_min        ,  -- 02:lnd_int ratio for min duration
		    t_lnd_int_amt_min       ,  -- 03:min lnd_int amt
	        t_lnd_int_rt_dly        ,  -- 04:lnd_int dly_rt
		    t_lnd_fee_rt            ,  -- 11:lnd_fee ratio
		    t_lnd_fee_rt_min        ,  -- 12:lnd_fee ratio for min duration
		    t_lnd_fee_amt_min       ,  -- 13:min lnd_fee amt
		    t_lnd_fee_rt_dly        ); -- 14:lnd_cmsn dly_rt
		EXCEPTION
	    WHEN others then
	        raise_application_error(-20100,'ERROR1');
	    END;
	else
		t_lnd_int_cal_std_term	:=  1;
		t_lnd_int_min_term		:=  0;
	    t_lnd_int_rt			:=  0;  -- 01:lnd_int ratio
	    t_lnd_int_rt_min		:=  0;  -- 02:lnd_int ratio for min duration
	    t_lnd_int_amt_min		:=	0;  -- 03:min lnd_int amt
        t_lnd_int_rt_dly		:=  0;  -- 04:lnd_int dly_rt
	    t_lnd_fee_rt			:=  0;  -- 11:lnd_fee ratio
	    t_lnd_fee_rt_min		:=  0;  -- 12:lnd_fee ratio for min duration
	    t_lnd_fee_amt_min		:=  0;  -- 13:min lnd_fee amt
	    t_lnd_fee_rt_dly		:=  0;  -- 14:lnd_fee dly_rt
	end if;
/*============================================================================*/
/* Calculate period                                                           */
/*============================================================================*/
	/* For VIP */
	if  i_lnd_bank_cd  =  '9999'  then
	    if  i_lnd_fee_rt <> t_lnd_fee_rt and i_lnd_fee_rt > 0 then
		    t_lnd_fee_rt     := i_lnd_fee_rt;
	    end if;
	end if;

    if  i_expr_dt > i_rpy_dt then
        t_dly_prd  :=  0;

        if  i_int_rpy_tp = '1' then
            t_lnd_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_last_rpy_dt, 'yyyymmdd');
        elsif i_int_rpy_tp = '2' then
            t_lnd_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_lnd_dt, 'yyyymmdd');
        else
            t_lnd_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_last_rpy_dt, 'yyyymmdd');
        end if;

    else
        if  i_int_rpy_tp = '1' then
            if  i_expr_dt > i_last_rpy_dt then
                /*==============================================*/
                /* loan period : expire date ~ last repay date  */
                /* dely prriod : repay date ~ expire date       */
                /*==============================================*/
                t_lnd_prd  :=  to_date(i_expr_dt, 'yyyymmdd') - to_date(i_last_rpy_dt, 'yyyymmdd');
                t_dly_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_expr_dt, 'yyyymmdd');
            else
                /*==============================================*/
                /* loan period :                                */
                /* dely prriod : repay date ~ last repay date   */
                /*==============================================*/
                t_dly_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_last_rpy_dt, 'yyyymmdd');
            end if;
        elsif i_int_rpy_tp = '2' then
            if  i_expr_dt > i_last_rpy_dt then
                /*==============================================*/
                /* loan period : expire date ~ lnd date         */
                /* dely prriod : repay date ~ expire date       */
                /*==============================================*/
                /* 2009/10/30 modify
                t_lnd_prd  :=  to_date(i_expr_dt, 'yyyymmdd') - to_date(i_lnd_dt, 'yyyymmdd');
                t_dly_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_expr_dt, 'yyyymmdd');
                */
                t_lnd_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_lnd_dt, 'yyyymmdd');
            else
                /*==============================================*/
                /* loan period :                                */
                /* dely prriod : repay date ~ last repay date   */
                /*==============================================*/
                /* 2009/10/30 modify
                t_lnd_prd  :=  to_date(i_last_rpy_dt, 'yyyymmdd') - to_date(i_lnd_dt, 'yyyymmdd');
                t_dly_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_last_rpy_dt, 'yyyymmdd');
                */
                t_lnd_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_lnd_dt, 'yyyymmdd');
            end if;
        end if;
    end if;

    if  i_int_rpy_tp = '1' then
        /*==================================================*/
        /* fee calc : max(±Ý¾×*¼ö¼ö·áÀ²*±â°£/30, 10,000)    */
        /*==================================================*/
	    if  t_lnd_prd > 0 then
		    t_lnd_fee := greatest(i_remn_amt * t_lnd_fee_rt * t_lnd_prd / t_lnd_int_cal_std_term, t_lnd_fee_amt_min);
	    end if;

        /*==================================================*/
        /* dely fee :                                       */
        /*==================================================*/
	    if  t_dly_prd > 0 then
	 		t_lnd_fee_dly := greatest(i_remn_amt * t_lnd_fee_rt_dly * t_dly_prd / t_lnd_int_cal_std_term, t_lnd_fee_amt_min);
	    end if;

    elsif i_int_rpy_tp = '2' then
        /*==================================================*/
        /* fee calc : max(±Ý¾×*¼ö¼ö·áÀ²*±â°£/30, 10,000)    */
        /*==================================================*/
	    if  t_lnd_prd > 0 then
		    t_lnd_fee := greatest(i_rpy_amt * t_lnd_fee_rt * t_lnd_prd / t_lnd_int_cal_std_term, t_lnd_fee_amt_min);
	    end if;

        /*==================================================*/
        /* dely fee :                                       */
        /*==================================================*/
	    if  t_dly_prd > 0 then
	 		t_lnd_fee_dly := greatest(i_rpy_amt * t_lnd_fee_rt_dly * t_dly_prd / t_lnd_int_cal_std_term, t_lnd_fee_amt_min);
	    end if;

    end if;

    /*==================================================*/
    /* fee type : 1.fee 2.delay fee 3.all               */
    /*==================================================*/
    if  i_fee_tp = '1' then
        o_lnd_fee := round(t_lnd_fee);
    elsif i_fee_tp = '2' then
        o_lnd_fee := round(t_lnd_fee_dly);
    else
        o_lnd_fee := round(t_lnd_fee) + round(t_lnd_fee_dly);
    end if;

    return o_lnd_fee;

end fdl_get_lnd_cmsn;
/

