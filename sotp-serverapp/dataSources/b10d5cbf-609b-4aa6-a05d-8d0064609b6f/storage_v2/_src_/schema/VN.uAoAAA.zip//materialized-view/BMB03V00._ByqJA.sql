create materialized view BMB03V00
    refresh force on commit
as
(
  SELECT bmb01m00.brch_cd,
  bmb01m00.agnc_brch,
  bmb01m00.trd_dt,
  bmb01m00.std_mon,
  bmb01m00.cntrcost_ast_tp,
  bmb01m00.mdm_tp,
  bmb01m00.sell_buy_tp,
  bmb01m00.cdt_tp,
  bmb01m00.stk_mkt_tp,
  bmb01m00.cmsn_tp,
  bmb01m00.ast_gds_tp,
  bmb01m00.bss_info_amt_tp,
  bmb01m00.mng_emp_tp,
  sum (bss_info_mng_amt)
  AS tot_own_amt
  FROM bmb01m00
  GROUP BY brch_cd,
  agnc_brch,
  trd_dt,
  std_mon,
  cntrcost_ast_tp,
  mdm_tp,
  sell_buy_tp,
  cdt_tp,
  stk_mkt_tp,
  cmsn_tp,
  ast_gds_tp,
  bss_info_amt_tp,
  mng_emp_tp
)
/

