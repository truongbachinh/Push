create function    fdl_get_grp_acnt_lnd_limit
	(i_grp_acnt_no varchar2,
     i_day_tp varchar2) 
return number
as
  /*!
     \file     fdl_get_grp_acnt_lnd_limit.sql
     \brief    fdl_get_grp_acnt_lnd_limit
     \section intro Program Information
          - Program Name              : 
          - Service Name              :
          - Related Client Program- Client Program ID :
          - Related Tables            : dlm00m01, dlm09m10
          - Dev. Date                 : 2018/05/21
          - Developer                 : GiangLH.
          - Business Logic Desc.      : fdl_get_grp_acnt_lnd_limit
          - Latest Modification Date  : 2018/05/21
   */
  t_grp_acnt_max_amt 	NUMBER 		:= 0;
  t_grp_acnt_lnd_amt 	NUMBER 		:= 0;
  t_grp_acnt_lnd_limit  NUMBER      := 0;
  t_vwdate				VARCHAR2(8) := vn.vwdate;
-- Neu i_day_tp = '1'- Su dung trong ngay: Co cong them so luong du kien vay (extp) vao so da dung
-- Neu i_day_tp ='2' - Cuoi ngay: Khong cong them so luong du kien vay (extp) vao so da dung
begin
	/*
		RLL(G) = Max(0,Maximum limit(G) - Used(G))
		Maximum Limit(G): Tong han muc toi da duoc phep cho vay cua nhom TK G
			- Lay tu cot <Han muc tong> doi tuong du lieu "Nhom TK MG" dang duoc ap dung cua nhom TK MG G. Neu TK A khong duoc gan nhom TK MG  nao ung thi tra ve 0
		Used(G): Tong gia tri han muc da dung cua nhom TK G
			- = Sum(gia tri vay, gia tri du kien vay) theo san pham P tu bang dlm09m10	
	*/
    BEGIN
     SELECT nvl(tot_lnd_lmit,0) into t_grp_acnt_max_amt
	 FROM vn.dlm00m01 a
	 WHERE  a.item_tp ='08' --nhom TK Margin
			AND a.item_cd = i_grp_acnt_no
			AND active_stat ='Y'
			AND vn.fdl_item_detail_chk (a.item_tp,a.item_cd,t_vwdate) = 'Y';
    EXCEPTION
          WHEN OTHERS THEN
              t_grp_acnt_max_amt := 0;
    END;

    BEGIN
		select sum(nvl(lnd_use_amt,0)) + sum(decode(i_day_tp, '1', nvl(lnd_expt_amt,0), 0))
		 into t_grp_acnt_lnd_amt
		from vn.dlm09m10
		where lnd_tp in ('70', '80')
		and grp_acnt_no =i_grp_acnt_no;
    EXCEPTION
          WHEN OTHERS THEN
              t_grp_acnt_lnd_amt := 0;
    END;
    t_grp_acnt_lnd_limit := greatest(0,nvl(t_grp_acnt_max_amt,0)- nvl(t_grp_acnt_lnd_amt,0));

    return t_grp_acnt_lnd_limit;

end fdl_get_grp_acnt_lnd_limit;
/

