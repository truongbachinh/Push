create view DRCWDM01_10 as
select a.BANK_ACC_NUM,a.BANK_ACC_NM
from vn.DRCWDM01 a
where a.CLS_DTM ='30000101'
    and a.bank_type in('CMR','CSG')
union
select b.BANK_ACC_NUM,b.BANK_ACC_NM
from vn.DRCWDM10 b
where b.CLS_DTM ='30000101'
    and b.bank_type in('CSC')
/

