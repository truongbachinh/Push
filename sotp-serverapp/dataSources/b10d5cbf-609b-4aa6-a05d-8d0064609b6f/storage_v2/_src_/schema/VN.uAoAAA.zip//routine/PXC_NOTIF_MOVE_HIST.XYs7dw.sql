create procedure    pxc_notif_move_hist
as
    -- Common variable
    t_proc_nm       varchar2(100)   := 'pxc_notif_move_hist';
    t_err_msg       varchar2(4000)  := ' ';

    -- Temp variable
    t_ins_cnt       number          := 0;
    t_del_cnt       number          := 0;
    t_diff_cnt      number          := 0;

begin
    vn.pxc_log_write(t_proc_nm, 'Start');

    begin
        -- Backup du lieu vao bang lich su
        vn.pxc_log_write(t_proc_nm, 'Start inserting');

        insert into vn.xcs01h10(
            dt,
            seq_no,
            acnt_no,
            sub_no,
            sent_st,
            sent_dtm,
            sent_err_cd,
            sent_err_msg,
            func_cd,
            notif_title,
            notif_msg,
            notif_lang,
            notif_tp,
            create_mn,
            create_dtm,
            create_trm,
            work_mn,
            work_dtm,
            work_trm,
            backup_dtm
        )
        select
            dt,
            seq_no,
            acnt_no,
            sub_no,
            sent_st,
            sent_dtm,
            sent_err_cd,
            sent_err_msg,
            func_cd,
            notif_title,
            notif_msg,
            notif_lang,
            notif_tp,
            create_mn,
            create_dtm,
            create_trm,
            work_mn,
            work_dtm,
            work_trm,
            sysdate
        from vn.xcs01m10;

        t_ins_cnt   := sql%rowcount;

        -- Xoa du lieu bang hien tai
        vn.pxc_log_write(t_proc_nm, 'Start deleting');

        delete vn.xcs01m10;

        t_del_cnt   := sql%rowcount;
        t_diff_cnt  := t_ins_cnt - t_del_cnt;

        -- Log so dong bi del, ins
        vn.pxc_log_write(t_proc_nm,
                            't_ins_cnt = '          || t_ins_cnt
                            || ', t_del_cnt = '     || t_del_cnt
                            || ', t_diff_cnt = '    || t_diff_cnt
        );

    exception 
        when others then
            t_err_msg  := 'Error when inserting into xcs01h10: ' || sqlcode || ' - ' || sqlerrm;
            vn.pxc_log_write(t_proc_nm, t_err_msg);
            raise_application_error(-20100,t_err_msg);
    end;

    vn.pxc_log_write(t_proc_nm, 'End.');

end pxc_notif_move_hist;
/

