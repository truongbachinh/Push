create FUNCTION fdl_get_acnt_sub_limit_remain
(
    i_acnt_no      in  VARCHAR2
    ,i_sub_no      in  VARCHAR2
)
  return number   as
  /*!
     \file     fdl_get_acnt_sub_limit_remain.sql
     \brief    fdl_get_acnt_sub_limit_remain
     \section intro Program Information
          - Program Name              :
          - Service Name              :
          - Related Client Program- Client Program ID :
          - Related Tables            :
          - Dev. Date                 : 20210723
          - Developer                 : TienLH
          - Business Logic Desc.      : Han muc con lai theo muc sub
          - Modify by                 :
          - Latest Modification Date  :
   */

    t_acnt_sub_use_amt       NUMBER  := 0;
    t_acnt_sub_limit         NUMBER  := 0;
    t_acc_sub_limit_remain   NUMBER  := 0;

    t_err_msg VARCHAR2(500);

BEGIN

    /*Lay han muc theo tk-sub duoc setup*/
    BEGIN
        SELECT vn.fdl_get_acnt_sub_limit(i_acnt_no, i_sub_no)
        INTO t_acnt_sub_limit
        FROM dual;
    EXCEPTION WHEN OTHERS THEN
        t_err_msg := vn.fxc_get_err_msg('V', '46051');
        vn.pxc_log_write('fdl_get_acnt_sub_limit_remain',
                        ' fdl_get_acnt_sub_limit error: ' || t_err_msg || ' ACNT_NO=' ||
                        i_acnt_no || '-' || i_sub_no );
        raise_application_error(-20100,
                                t_err_msg ||
                                ' fdl_get_acnt_sub_limit: csr ACNT_NO =' ||
                                i_acnt_no || '-' || i_sub_no );
    END;

    /*Han muc da dung cua tk - sub*/
    BEGIN
        SELECT vn.fdl_get_mrgn_expt_amt(i_acnt_no, i_sub_no, '3')
        INTO t_acnt_sub_use_amt         /*E*/
        FROM dual;
    EXCEPTION WHEN OTHERS THEN
        t_err_msg := vn.fxc_get_err_msg('V', '46055');
        vn.pxc_log_write('fdl_get_acnt_sub_limit_remain',
                        ' Han muc da dung cua sub tk error: ' || t_err_msg || ' ACNT_NO=' ||
                        i_acnt_no || '-' || i_sub_no);
        raise_application_error(-20100,
                                t_err_msg ||
                                ' fdl_get_acnt_sub_limit_remain: ACNT_NO_STK_i_tp=' ||
                                i_acnt_no || '-' || i_sub_no );
    END;

    /*Han muc kha dung con lai cua tk- sub*/
    t_acc_sub_limit_remain := greatest(t_acnt_sub_limit - t_acnt_sub_use_amt, 0);

    vn.pxc_log_write('fdl_get_acnt_sub_limit_remain', 'i_acnt_no = '|| i_acnt_no ||'  i_sub_no = ' || i_sub_no ||
                         '  t_acnt_sub_limit = '|| t_acnt_sub_limit || '  t_acnt_sub_use_amt = ' || t_acnt_sub_use_amt || '  t_acc_sub_limit_remain = '|| t_acc_sub_limit_remain);

    RETURN  t_acc_sub_limit_remain;

END fdl_get_acnt_sub_limit_remain;
/

