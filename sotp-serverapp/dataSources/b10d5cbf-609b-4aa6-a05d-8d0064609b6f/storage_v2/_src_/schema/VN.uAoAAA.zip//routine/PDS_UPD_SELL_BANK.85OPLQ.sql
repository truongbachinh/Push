create procedure    pds_upd_sell_bank
(
	i_acnt_no     in     varchar2,        --
	i_sub_no      in     varchar2,        --
	i_bank_cd     in     varchar2,        --
	i_work_mn     in     varchar2,        -- user id
	i_work_trm    in     varchar2,
	o_cnt         in out number
) AS

/*!
   \file     pds_upd_sell_bank.sql
   \brief    modify from bank account to security account on selling

   \section intro Program Information
        - Program Name              : modify from bank account to security account on selling
        - Service Name              :
        - Related Client Program- Client Program ID :
        - Related Tables            : dsc01m00,
        - Dev. Date                 : 2007/11/08
        - Developer                 : Han.
        - Business Logic Desc.      : update account's bank
        - Latest Modification Date  : 2007/11/08

   \section history Program Modification History
    - 1.0       2007/11/08     Han.    New.

   \section hardcoding Hard-Coding List
    - HC-1      2007/11/08     Han.    [»çÀ¯]

   \section info Additional Reference Comments
    - °áÁ¦Ã³¸®

var o_cnt number;
exec pds_upd_sell_bank('XXXC000001','9999','Test','Test',:o_cnt);
print o_cnt;
*/

    ts_work_stat_min    VARCHAR2(1);
    ts_work_stat_max    VARCHAR2(1);

    t_vwdate            VARCHAR2(08) := null;
    t_nxt_setl_dt       VARCHAR2(08) := null;
    t_nnxt_setl_dt      VARCHAR2(08) := null;
    t_nnnxt_setl_dt     VARCHAR2(08) := null;

    t_order_yn          VARCHAR2(1)  := 'N';

    t_msg               varchar2(100) := null;
    t_err_msg           varchar2(500) := null;

    t_setl_cnt          number        := 0;

begin

    o_cnt          := 0;
    t_setl_cnt     := 0;

    /*========================================================================*/
    /* Set Date                                                               */
    /*========================================================================*/
    t_vwdate  := vn.vwdate;

    t_nxt_setl_dt   := vn.fxc_vorderdt_g(to_date(t_vwdate,'yyyymmdd'), 1);
    t_nnxt_setl_dt  := vn.fxc_vorderdt_g(to_date(t_vwdate,'yyyymmdd'), 2);
    t_nnnxt_setl_dt := vn.fxc_vorderdt_g(to_date(t_vwdate,'yyyymmdd'), 3);

    /*========================================================================*/
    /* Prededing job Check                                                    */
    /*========================================================================*/
    begin
	select 	case when nvl(sum(mth_qty + nmth_qty), 0) > 0 then 'N'
	             else 'Y'
            end
	  into	t_order_yn
	  from	vn.tso01m00
	 where	acnt_no      =  i_acnt_no
	   and  sub_no		 =  i_sub_no
	   and  sell_buy_tp  =  '1'
	   and  del_yn       =  'N'
	;
    exception
    when others then
        t_err_msg := vn.fxc_get_err_msg('V','9009');
        t_err_msg := t_err_msg||' ACNT_NO = '||i_acnt_no||'-'||i_sub_no;
        raise_application_error(-20100,t_err_msg);
    end;

    if  t_order_yn  =  'N'  then
        t_setl_cnt  :=  0;
        select  count(*)
          into  t_setl_cnt
          from  vn.dsc01m00
         where  acnt_no       =  i_acnt_no
           and  sub_no		 =  i_sub_no
           and  setl_dt       =  t_nnnxt_setl_dt
           and  sb_tp         =  '1'
        ;

        /* pre-settle is not created */
        if  t_setl_cnt  =  0  then
            t_err_msg := vn.fxc_get_err_msg('V','0119');
            t_err_msg := t_err_msg||'cnt : '||t_setl_cnt;
            raise_application_error(-20110,t_err_msg);
        end if;
    end if;


/*============================================================================*/
/* ( )                                                                        */
/*============================================================================*/
    for C0 in (
        select  *
          from  vn.dsc01m00
         where  acnt_no       =  i_acnt_no
           and  sub_no		 =  i_sub_no
           and  setl_dt       =  t_vwdate
           and  sb_tp         =  '1'
         order  by  acnt_no, sub_no, setl_dt, setl_frct_seq_no
    ) loop

        if  C0.dpo_setl_yn  =  'Y'  and
            C0.cmsn_setl_yn =  'Y'  and
            C0.tax_setl_yn  =  'Y'  and
            C0.stk_setl_yn  =  'Y'  then
            t_setl_cnt     := 0;
        else
            if  substr(i_acnt_no,4,1) =  'P'  then
                if  C0.dpo_setl_yn  =  'N'  and
                    C0.tax_setl_yn  =  'N'  and
                    C0.stk_setl_yn  =  'N'  then
                    t_setl_cnt     := 0;
                else
                    t_err_msg := vn.fxc_get_err_msg('V','2474');
                    raise_application_error(-20120,t_err_msg);
                end if;
            else
                if  C0.dpo_setl_yn  =  'N'  and
                    C0.cmsn_setl_yn =  'N'  and
                    C0.tax_setl_yn  =  'N'  and
                    C0.stk_setl_yn  =  'N'  then
                    t_setl_cnt     := 0;
                else
                    t_err_msg := vn.fxc_get_err_msg('V','2474');
                    raise_application_error(-20120,t_err_msg);
                end if;
            end if;
        end if;
    end loop;

    for C1 in (
        select  *
          from  vn.dsc01m00
         where  acnt_no       =  i_acnt_no
           and  sub_no		 =  i_sub_no
           and  setl_dt between  t_vwdate  and  t_nnnxt_setl_dt
           and  sb_tp         =  '1'
           /* and  dpo_setl_yn   =  'N' */
           /* and  cmsn_setl_yn  =  'N' */
           /* and  tax_setl_yn   =  'N' */
         order  by  acnt_no, sub_no, setl_dt, setl_frct_seq_no
    ) loop
        o_cnt := o_cnt + 1;

        begin
            UPDATE  vn.dsc01m00
               set  bank_cd       =  i_bank_cd
             where  setl_dt       =  C1.setl_dt
               and  acnt_no       =  C1.acnt_no
               and  sub_no		  =  C1.sub_no
               and  setl_frct_seq_no  =  C1.setl_frct_seq_no
               and  sb_tp         =  '1'
               /* and  dpo_setl_yn   =  'N' */
               /* and  cmsn_setl_yn  =  'N' */
               /* and  tax_setl_yn   =  'N' */
        ;
        exception
        when others then
	    	t_err_msg := vn.fxc_get_err_msg('V','9414');
	    	raise_application_error(-20130,t_err_msg||' ACNT_NO='||C1.acnt_no||'-'||C1.sub_no);
        end;

    end loop;

    for C2 in (
        select  *
          from  vn.dsc01m00
         where  acnt_no       =  i_acnt_no
           and  sub_no		 =  i_sub_no
           and  setl_dt between  t_vwdate  and  t_nnnxt_setl_dt
           and  sb_tp         =  '2'
         order  by  acnt_no, sub_no, setl_dt, setl_frct_seq_no
    ) loop
        o_cnt := o_cnt + 1;

        begin
            UPDATE  vn.dsc01m00
               set  bank_cd       =  i_bank_cd
             where  setl_dt       =  C2.setl_dt
               and  acnt_no       =  C2.acnt_no
               and  sub_no		  =  C2.sub_no
               and  setl_frct_seq_no  =  C2.setl_frct_seq_no
               and  sb_tp         =  '2'
        ;
        exception
        when others then
	    	t_err_msg := vn.fxc_get_err_msg('V','9414');
	    	raise_application_error(-20140,t_err_msg||' ACNT_NO='||C2.acnt_no||'-'||C2.sub_no);
        end;

    end loop;

end pds_upd_sell_bank;
/

