create FUNCTION    fdl_get_dly_rt
(
    i_acnt_no       IN      VARCHAR2,       -- Account number
    i_sub_no        IN      VARCHAR2,       -- Sub number
    i_prd_no        IN      VARCHAR2,
    i_lnd_int_rt    IN      NUMBER,         -- Loan interm interest ratio
    i_lnd_dt        IN      VARCHAR2        -- Loan date
)
    RETURN NUMBER AS

    t_prd_no            VARCHAR2(15)    := '2';     -- Product number

    t_lnd_int_rt        NUMBER          := 0;       -- Loan interm interest ratio
    t_lnd_dly_rt        NUMBER          := 0;       -- Loan delay interest ratio


BEGIN
    -- Get interest ratio from product setup
    t_lnd_int_rt    := vn.fdl_get_prd_acnt_rt(i_acnt_no, i_sub_no, i_prd_no, '06', i_lnd_dt);
    t_lnd_dly_rt    := vn.fdl_get_prd_acnt_rt(i_acnt_no, i_sub_no, i_prd_no, '07', i_lnd_dt);

    IF t_lnd_int_rt !=  i_lnd_int_rt THEN
        t_lnd_dly_rt := i_lnd_int_rt * 1.5;
    END IF;

    return t_lnd_dly_rt;

END fdl_get_dly_rt;
/

