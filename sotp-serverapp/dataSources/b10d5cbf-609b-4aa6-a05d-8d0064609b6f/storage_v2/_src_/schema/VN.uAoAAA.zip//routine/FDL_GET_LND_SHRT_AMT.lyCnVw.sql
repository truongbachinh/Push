create function    fdl_get_lnd_shrt_amt
(
    i_acnt_no        in   varchar2,
    i_sub_no         in   varchar2
)
    return  number
as

	td_shrt_amt    NUMBER := 0;

begin


/*============================================================================*/
/* generl commission return                                                   */
/*============================================================================*/
	/* CASE '00' : System should return shortage amount for total value of this account
	   CASE '01' : System should return shortage amount that the least amount between
	               all of the lnad amount except margin loan and shortage amount by evaluation */

	for c1 in (
	    select  LEAST( (
					  + NVL(COLL_LOAN_NOWRM, 0) + NVL(COLL_LOAN_INT, 0)
					  + NVL(BUY_LOAN_NOWRM , 0) + NVL(BUY_LOAN_INT , 0)
					  + NVL(MONY_LOAN_NOWRM, 0) + NVL(MONY_LOAN_INT, 0))

					  , NVL(MRGN_SHRT_AMT,0) ) AS LND_SHRT_AMT
		      , NVL(MRGN_SHRT_AMT,0) AS MRGN_SHRT_AMT
	      from  vn.CWD99M00
	     where  acnt_no      =  i_acnt_no
	       and  sub_no       =  i_sub_no
	) loop

		if  c1.LND_SHRT_AMT < 0 then
		    return 0;
		else
		    return c1.LND_SHRT_AMT;
		end if;

	end loop;

	-- No data found error
	return  0;

end fdl_get_lnd_shrt_amt;
/

