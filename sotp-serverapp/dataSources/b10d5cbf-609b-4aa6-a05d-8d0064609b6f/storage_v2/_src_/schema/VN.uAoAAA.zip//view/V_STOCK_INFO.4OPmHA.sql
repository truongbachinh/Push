create view V_STOCK_INFO as
select ngay, ma_ck, tochuc_phathanh, ma_loaiCK, tenloai_ck, menhgia, ma_sangiaodich, ten_sangiaodich
  from
      (
select a.dt ngay,
       a.stk_cd ma_ck,
       b.stk_nm tochuc_phathanh,
       nvl(decode(a.stk_tp,'10','S','20','D','30','U','40','S'),'!') ma_loaiCK,
       vn.fxc_tp_nm_g('stk_tp',a.stk_tp) tenloai_ck,
       b.fac_pri menhgia,
       decode(a.stk_mkt_tp,'1','001',decode(a.stk_mkt_tp,'2','002',decode(a.stk_mkt_tp,'3','003','005'))) ma_sangiaodich,
        vn.fxc_tp_nm_g('stk_mkt_tp',a.stk_mkt_tp) ten_sangiaodich
 from  vn.ssi01h00 a, vn.ssi01m00 b
 where a.stk_cd = b.stk_cd
  union all
  select vn.vhdate ngay,
       a.stk_cd ma_ck,
       a.stk_nm tochuc_phathanh,
       nvl(decode(a.stk_tp,'10','S','20','D','30','U','40','S'),'!') ma_loaiCK,
       vn.fxc_tp_nm_g('stk_tp',a.stk_tp) tenloai_ck,
       a.fac_pri menhgia,
       decode(a.stk_mkt_tp,'1','001',decode(a.stk_mkt_tp,'2','002',decode(a.stk_mkt_tp,'3','003','005'))) ma_sangiaodich,
        vn.fxc_tp_nm_g('stk_mkt_tp',a.stk_mkt_tp) ten_sangiaodich
 from  vn.ssi01m00 a
 )
/

