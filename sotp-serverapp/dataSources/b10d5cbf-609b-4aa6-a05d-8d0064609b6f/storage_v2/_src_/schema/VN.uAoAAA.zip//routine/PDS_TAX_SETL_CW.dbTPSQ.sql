create PROCEDURE    pds_tax_setl_cw
(
  i_setl_dt     IN      VARCHAR2,
  i_acnt_no     IN      VARCHAR2,
  i_sub_no      IN      VARCHAR2,
  i_setl_tp     IN      VARCHAR2,
  i_work_mn     IN      VARCHAR2,        -- user id
  i_work_trm    IN      VARCHAR2,
  o_proc_cnt    IN OUT  NUMBER,
  o_err_cnt     IN OUT  NUMBER
) AS

/* ************************************************************************************************
  Author:         hphan
  Created Date:   29-Jan-2018
  Description:    This procedure is used to implement cw dpo settlement.

  Sample call:
    var o_cnt      number;
    var o_err_cnt  number;
    exec pds_tax_setl_cw('061', '20180131','061C600088','01','9999','Conv_man','Conv_man',:o_cnt,:o_err_cnt);
    print o_cnt
    print o_err_cnt


  MODIFICATION DETAILS:
  -------------------------------------------------------------------------------------------------
  Modified Date   Modified By       Modification Details
  -------------------------------------------------------------------------------------------------
  29-Jan-2018     hphan             Initial creation

**************************************************************************************************/

    -- Declare variable
    t_sec_id                    VARCHAR(10)     := vn.fxc_sec_cd('R');
    t_vwdate                    VARCHAR2(8)     := NULL;
    t_trd_tp                    VARCHAR2(2)     := NULL;
    t_rmrk_cd                   VARCHAR2(3)     := NULL;
    t_rmrk_job_tp               VARCHAR2(3)     := NULL;
    t_rmrk_trd_tp               VARCHAR2(3)     := NULL;
    t_setl_comp                 NUMBER(1)       := 0;
    t_trd_seq_no                NUMBER          := 0;
    t_tot_seq_no                NUMBER          := 0;
    t_setl_bank_cd              VARCHAR2(4)     := NULL;
    t_dpo                       NUMBER          := 0;
    t_dpo_prerm                 NUMBER          := 0;
    t_dpo_nowrm                 NUMBER          := 0;
    t_block_ds_amt              NUMBER          := 0;
    t_block_dl_amt              NUMBER          := 0;
    t_used_allowa_cd            NUMBER          := 0;
    t_nonrpy_loan_amt           NUMBER          := 0;
    t_tot_out_psbamt            NUMBER          := 0;
    t_rpyable_amt               NUMBER          := 0;
    t_short_amt                 NUMBER          := 0;
    t_new_cw_waiting_exec_qty   NUMBER          := 0;
    t_new_cw_own_qty            NUMBER          := 0;
    t_new_cw_book_amt           NUMBER          := 0;

    t_cnt_tp                    VARCHAR2(10)    := 0;
    t_err_chk                   VARCHAR2(1)     := 'N';
    t_err_msg                   VARCHAR2(500)   := NULL;
BEGIN

    o_proc_cnt := 0;
    o_err_cnt  := 0;

    t_vwdate  := vn.vwdate;

    vn.pxc_log_write('pds_tax_setl_cw','START pds_tax_setl_cw');

    /* **************************************************************************/
    /*              Checking data before implementing settlement                */
    /* **************************************************************************/
    -- Check if input date is not current date
    IF vn.vwdate != i_setl_dt THEN
        t_err_msg := vn.fxc_get_err_msg('V', '2422');
        t_err_msg := t_err_msg || ' Date = ' || i_setl_dt;
        raise_application_error(-20100, t_err_msg);
    END IF;

    -- Check if input date is holiday
    IF vn.fxc_holi_ck(TO_DATE(i_setl_dt, 'yyyymmdd')) != '0' THEN
        IF i_work_mn <> 'DAILY' THEN
            t_err_msg := vn.fxc_get_err_msg('V', '2422');
            t_err_msg := t_err_msg || ' Date = ' || i_setl_dt;
            raise_application_error(-20100, t_err_msg);
        ELSE
            RETURN;
        END IF;
    END IF;

    -- Check if pre-requisite job is not completed
    /*
    IF (i_acnt_no = '%' AND vn.fxb_daily_stat_chk ('B','0','6010','6010','*') <> 'Y')
    THEN
        t_err_msg := vn.fxc_get_err_msg('V', '2458');
        t_err_msg := t_err_msg || '[6010],[6010]' || i_setl_dt;
        raise_application_error(-20100, t_err_msg);
    END IF;
    */

    /* **************************************************************************/
    /*                                  End checking                            */
    /* **************************************************************************/

    /* **************************************************************************/
    /*                                  TAX Settlement                          */
    /* **************************************************************************/
    FOR c1 in (
        SELECT
            dc.acnt_no                                      acnt_no,
            dc.sub_no                                       sub_no,
            vn.faa_acnt_nm_g(dc.acnt_no, dc.sub_no)         acnt_nm,
            -- vn.fcw_bank_knd_tp_q(dc.acnt_no, dc.sub_no)     bank_knd_tp,
            dc.cw_cd                                        cw_cd,
            dc.cw_qty                                       cw_qty,
            si.cw_tp                                        cw_tp,
            vn.fss_get_pd_cls_pri(dc.cw_cd)                 cw_cls_pri,
            dc.setl_dt                                      setl_dt,
            dc.setl_tp                                      setl_tp,
            dc.sb_amt                                       dpo_amt,
            dc.sb_tax                                       tax_amt,
            dc.dpo_setl_yn                                  dpo_setl_yn,
            dc.tax_setl_yn                                  tax_setl_yn,
            dc.acnt_brch_cd                                 acnt_brch_cd,
            dc.acnt_agnc_cd                                 acnt_agnc_cd,
            si.cw_exec_tp                                   cw_exec_tp
        FROM vn.dcw01m00 dc
        INNER JOIN ssi01m00 si
           ON dc.cw_cd = si.stk_cd
        WHERE dc.acnt_no    like i_acnt_no
          AND dc.sub_no     like i_sub_no
          AND dc.setl_dt       = i_setl_dt
          AND dc.setl_tp    like i_setl_tp
          AND dc.tax_setl_yn   = 'N'
    )
    LOOP
        IF(c1.tax_amt > 0)
        THEN
            o_proc_cnt  := o_proc_cnt + 1;
            /*
            IF(NVL(c1.short_dpo, 0) <= 0)
            THEN
                t_err_msg := vn.fxc_get_err_msg('V', '2458');           -- Need edited
                t_err_msg := t_err_msg || '[2000],[2000]' || i_setl_dt;
                raise_application_error(-20100, t_err_msg);
            END IF;
            */

            vn.pxc_log_write('pds_tax_setl_cw','pds_tax_setl_cw: '
                                || 'acnt_no = '     || c1.acnt_no   || '-' || c1.sub_no
                                || ' | cw_cd = '    || c1.cw_cd);
            -- 1. Update DPO
            -- Get dpo information
            vn.pxc_log_write('pds_tax_setl_cw','pds_tax_setl_cw: Step 1: Get dpo information');

            -- Bank Account Check
            BEGIN
                vn.paa_bank_yn_p(C1.acnt_no, C1.sub_no, t_cnt_tp);
            EXCEPTION
            WHEN OTHERS THEN
                t_err_msg := vn.fxc_get_err_msg('V','9009');
                RAISE_APPLICATION_ERROR(-20100,t_err_msg||' Acnt_no - '||C1.acnt_no||'-'||C1.sub_no);
            END;

            vn.pds_outamt_psbamt_q(
                C1.acnt_no,
                C1.sub_no,
                t_dpo,
                t_block_ds_amt,
                t_block_dl_amt,
                t_used_allowa_cd,
                t_nonrpy_loan_amt,
                t_tot_out_psbamt,
                t_rpyable_amt
            );

            t_dpo_prerm := t_dpo;
            t_dpo_nowrm := t_dpo - c1.tax_amt;

            IF (c1.setl_tp = 1 AND c1.cw_tp = 2)    -- If Settlement method is Physical delivery for Call CW
            THEN
                SELECT t_rpyable_amt - c1.tax_amt - DECODE(c1.dpo_setl_yn, 'Y', 0, c1.dpo_amt)
                INTO t_short_amt
                FROM DUAL;
            ELSE
                t_short_amt := t_rpyable_amt - c1.tax_amt;
            END IF;

            -- Check if the available dpo is enough to settle or not
            IF (t_short_amt < 0) THEN
                t_err_msg := vn.fxc_get_err_msg('V','3318');
                t_err_msg := t_err_msg||' Acnt_no= '||i_acnt_no||'-'||i_sub_no||' | shortage_amt= '||t_short_amt;
                raise_application_error(-20100,t_err_msg);
            END IF;

            vn.pxc_log_write('pds_tax_setl_cw','pds_tax_setl_cw: dpo_prerm = ' || t_dpo_prerm || ', dpo_nowrm = ' || t_dpo_nowrm);

            -- Update dpo
            IF t_cnt_tp  =  'Y01' THEN  -- Bank Acnt
                vn.pds_cw_dsc10m00_ins (  t_vwdate                 -- TRD_DT
                                        , '1'                  -- JOB_TP
                                        , '0003'                 -- BANK_CD
                                        , c1.acnt_no           -- ACNT_NO
                                        , c1.sub_no            -- SUB_NO
                                        , c1.setl_dt           -- SETL_DT
                                        , c1.setl_dt           -- MTH_DT
                                        , '2'                  -- SB_TP
                                        , c1.acnt_brch_cd      -- ACNT_MNG_BRCH
                                        , c1.acnt_agnc_cd      -- AGNC_BRCH
                                        , null                 -- MKT_TRD_TP
                                        , null                 -- CDT_TP
                                        , c1.cw_cd             -- STK_CD
                                        , 0                    -- SEQ_NO
                                        , c1.tax_amt           -- ADJ_AMT
                                        , 0					   -- SB_AMT
                                        , 0                    -- SB_CMSN
                                        , c1.tax_amt           -- SB_TAX
                                        , null                 -- LND_TP
                                        , null                 -- LND_DT
                                        , null                 -- MRTG_DT
                                        , null                 -- LND_BANK_CD
                                        , 0                    -- lnd_amt
                                        , 0                    -- lnd_int
                                        , 0                    -- lnd_fee
                                        , c1.cw_qty            -- sb_qty
                                        , i_work_mn            -- WORK_MN
                                        , i_work_trm           -- WORK_TRM
                                        );

                UPDATE  vn.dcw01m00
                set  tax_setl_yn     =  'Y'
                where  acnt_no         =  c1.acnt_no
                and  sub_no          =  c1.sub_no
                and  cw_cd           =  c1.cw_cd
                and  setl_dt         =  c1.setl_dt
                and  setl_tp         =  c1.setl_tp
                and  tax_setl_yn    in  ('N');
                -- End bank account
            ELSE
                UPDATE vn.cwd01m00
                SET dpo = t_dpo_nowrm
                WHERE acnt_no = c1.acnt_no
                AND sub_no = c1.sub_no;

                -- 2. Insert aaa10m00
                vn.pxc_log_write('pds_tax_setl_cw','pds_tax_setl_cw: Step 2: Insert aaa10m00');

                IF  c1.cw_tp = '1' THEN
                    t_trd_tp  := '30';
                    t_rmrk_job_tp  := '10';
                ELSIF C1.cw_tp = '2' THEN
                    t_trd_tp  := '31';
                    t_rmrk_job_tp  := '10';
                END IF;

                t_rmrk_cd       := 'W02';
                t_rmrk_trd_tp   := 'W02';

                -- Get the Trade sequence number and Total trade sequence number      */
                BEGIN
                    vn.pxc_psb_seq_cret_p(c1.acnt_no, c1.sub_no, vn.vwdate, t_trd_seq_no, t_tot_seq_no);
                EXCEPTION
                WHEN OTHERS THEN
                    t_err_msg := vn.fxc_get_err_msg('V','9410');
                    t_err_msg := t_err_msg||' Acnt_no= '||i_acnt_no||'-'||i_sub_no;
                    raise_application_error(-20100,t_err_msg);
                END;

                -- Insert
                vn.pds_aaa10m00_ins (
                    c1.acnt_no,                         -- ACNT_NO
                    c1.sub_no,                          -- SUB_NO
                    i_setl_dt,                               -- TRD_DT
                    t_trd_seq_no,                       -- TRD_SEQ_NO
                    t_trd_tp,                           -- TRD_TP
                    t_rmrk_cd,                          -- RMRK_CD
                    NULL,                               -- BANK_CD
                    '00',                               -- MDM_TP
                    '00',                               -- TRD_MDM_TP
                    'N',                                -- CNCL_YN
                    0,                                  -- ORG_TRD_NO
                    c1.tax_amt,                         -- TRD_AMT
                    0,                                  -- CMSN
                    0,                                  -- SB_TAX
                    c1.tax_amt,                         -- ADJ_AMT
                    t_dpo_prerm,                        -- DPO_PRERM
                    t_dpo_nowrm,                        -- DPO_NOWRM
                    c1.cw_cd,                           -- STK_CD
                    vn.fss_get_stk_nm(c1.cw_cd),        -- STK_NM
                    0,                                  -- SB_PRI
                    0,                                  -- SB_QTY
                    0,                                  -- BIL_PRERM_QTY
                    0,                                  -- BIL_NOWRM_QTY
                    0,                                  -- BOOK_AMT
                    vn.fss_get_stk_tp(c1.cw_cd),        -- STK_TP
                    NULL,                               -- MTH_DT
                    0,                                  -- LND_TP
                    NULL,                               -- LND_DT
                    NULL,                               -- LND_BANK_CD
                    0,                                  -- LND_AMT
                    0,                                  -- LND_RPY_AMT
                    0,                                  -- LND_INT
                    0,                                  -- LND_CMSN
                    0,                                  -- LND_INT_DLY
                    0,                                  -- LND_CMSN_DLY
                    'N',                                -- AGNT_YN
                    c1.acnt_brch_cd,                    -- ACNT_MNG_BNH
                    c1.acnt_agnc_cd,                    -- AGNC_BRCH
                    c1.acnt_brch_cd,                    -- WORK_BNH
                    c1.acnt_agnc_cd,                    -- PROC_AGNC_BRCH
                    i_work_mn,                          -- WORK_MN
                    i_work_trm,                         -- WORK_TRM
                    i_setl_dt,                          -- SETL_DT
                    t_tot_seq_no                        -- TOT_SEQ_NO
                );

                -- 3. Insert gga07m00
                vn.pxc_log_write('pds_tax_setl_cw','pds_tax_setl_cw: Step 3: Insert gga07m00');

                vn.pds_gga07m00_ins (
                    i_setl_dt,              -- PROC_DT
                    'I',                    -- AUTO_SLIP_PROC_TP
                    c1.acnt_brch_cd,        -- PROC_BRCH_CD
                    c1.acnt_agnc_cd,        -- PROC_AGNC_BRCH
                    c1.acnt_brch_cd,        -- EXCH_BRCH_CD
                    c1.acnt_agnc_cd,        -- EXCH_AGNC_BRCH
                    c1.acnt_no,              -- ACNT_NO
                    c1.sub_no,               -- SUB_NO
                    i_setl_dt,              -- TRD_DT
                    t_trd_seq_no,           -- TRD_SEQ_NO
                    0,                      -- ORIG_TRD_SEQ_NO
                    t_rmrk_job_tp,          -- RMRK_JOB_TP
                    t_rmrk_trd_tp,          -- RMRK_TRD_TP
                    NULL,                   -- LND_BANK_CD
                    c1.tax_amt,             -- DR_AMT_01
                    0,                      -- DR_AMT_02
                    0,                      -- DR_AMT_03
                    0,                      -- DR_AMT_04
                    0,                      -- DR_AMT_05
                    c1.tax_amt,             -- CR_AMT_01
                    0,                      -- CR_AMT_02
                    0,                      -- CR_AMT_03
                    0,                      -- CR_AMT_04
                    0,                      -- CR_AMT_05
                    NULL,                   -- BANK_CD
                    i_work_mn,              -- WORK_MN
                    i_work_trm              -- WORK_TRM
                );
            END IF;
        END IF; -- End for tax_amt > 0

        -- 4. Update stock settlement status = 'Y'
        vn.pxc_log_write('pds_tax_setl_cw','pds_tax_setl_cw: Step 4: Update stock settlement status');

        UPDATE dcw01m00
        SET tax_setl_yn = 'Y'
        WHERE acnt_no   = c1.acnt_no
          AND sub_no    = c1.sub_no
          AND cw_cd     = c1.cw_cd
          AND setl_dt   = c1.setl_dt
          AND setl_tp   = c1.setl_tp;

        vn.pxc_log_write('pds_tax_setl_cw','pds_tax_setl_cw: acnt_no ' || c1.acnt_no);

    END LOOP;

    IF  t_err_chk  =  'Y' THEN
        /*  o_err_cnt := o_err_cnt + 1;   */
        -- ROLLBACK;
        vn.pxc_log_write('pds_tax_setl_cw','pds_tax_setl_cw: error');
    ELSE
        /*  o_proc_cnt := o_proc_cnt + 1; */
        vn.pxc_log_write('pds_tax_setl_cw','pds_tax_setl_cw: COMMIT');
        -- COMMIT;
    END IF;

    IF  i_work_mn = 'DAILY' THEN
        IF  o_err_cnt > 0 THEN
            t_err_msg := vn.fxc_get_err_msg('V','9410') || t_err_msg;
            raise_application_error(-20100,t_err_msg);
        END IF;
    END IF;

    vn.pxc_log_write('pds_tax_setl_cw', 'END pds_tax_setl_cw: '
                        || ' acnt_no = '    || i_acnt_no   || '-' || i_sub_no
                        || ' | setl_dt = '  || i_setl_dt
                        || ' | setl_tp = '  || i_setl_dt
                        || ' | err_cnt = '  || o_err_cnt
                        || ' | err_chk = '  || t_err_chk );

END pds_tax_setl_cw;
/

