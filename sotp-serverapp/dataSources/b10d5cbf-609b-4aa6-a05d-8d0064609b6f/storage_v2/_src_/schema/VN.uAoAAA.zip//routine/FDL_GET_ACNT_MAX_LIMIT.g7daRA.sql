create FUNCTION    fdl_get_acnt_max_limit(i_acnt_no VARCHAR2,
                                                     i_sub_no  VARCHAR2,
                                                     i_acnt_grp_no VARCHAR2,
                                                     i_stk_cd  VARCHAR2)
  RETURN NUMBER AS
  /*!
     \file     fdl_get_acnt_max_limit.sql
     \brief    fdl_get_acnt_max_limit
     \section intro Program Information
          - Program Name              :
          - Service Name              :
          - Related Client Program- Client Program ID :
          - Related Tables            :
          - Dev. Date                 : 20210602
          - Developer                 : TienLH
          - Business Logic Desc.      : Han muc co the vay cua tk
          - Modify by                 :
          - Latest Modification Date  :
   */

    t_cust_max_amt  NUMBER := 0;
    t_acnt_limit  NUMBER := 0;
    t_all_src_max_limit  NUMBER := 0;
    r_acnt_max_amt  NUMBER := 0;
    t_acnt_max_limit  NUMBER := 0;
    t_rll NUMBER := 0;
    t_all_sub_lnd_amt  NUMBER := 0;
    t_acnt_lnd_amt  NUMBER := 0;
    t_cnt_src_sec NUMBER := 0;
    t_cnt_src_out_sec NUMBER := 0;
    t_acc_lnd_lmit  NUMBER := 0;


    t_err_msg VARCHAR2(500);
    t_lrr     NUMBER := 0;

BEGIN

/*
1. Chính sách riêng hạn mức của tài khoản ( 04606): X
2. Chính sách chung hạn mức của tài khoản ( 90040): A
3. Hạn mức của sub tài khoản tính theo nhóm margin ( 04610-1): B
4. Hạn mức tối đa của 01 sub tài khoản: C
5. Hạn mức còn lại của sub đang đặt lệnh được tính trong công thức tính sức mua: D
6. Hạn mức đã sử dụng của sub đang đặt lệnh : E
7. Tính hạn mức còn lại sub sau khi check hạn mức theo tài khoản:
    B1: Lấy hạn mức X của tài khoản:
        Nếu tồn tại bản ghi còn hiệu lực của tài khoản trong tab 04605-6:  X= giá trị Hạn mức tối đa --> Hạn mức của tài khoản F= X.
        Nếu không tồn tại: --> Hạn mức cùa tài khoản F= A.
    B2: Check nếu F=0 thì Tính hạn mức còn lại của sub = 0 và kết thúc việc tính hạn mức còn lại.
    Nếu F>0 thì check tiếp các bước sau.
    B3: Check sub đang tính hạn mức đó có cài chính sách riêng (csr) không?
        B3.1. Nếu có csr, tính hạn mức tối đa của sub đó  C= min( F, csr)
        B3.2. Nếu không csr, tính hạn mức tối đa của sub đó C = min( F, B)
    B4: Tính tổng hạn mức đã sử dụng của tất các sub thuộc tài khoản: G
    B5: Tính hạn mức còn lại của sub = min( D, min(min(C-E<0,0,C-E),min(F-G<0,0,F-G)))
*/

    vn.pxc_log_write('fdl_get_acnt_max_limit', 'i_acnt_no = ' || i_acnt_no ||'  i_sub_no = '||
                        i_sub_no ||'  i_acnt_grp_no = ' || i_acnt_grp_no || '  i_stk_cd = ' || i_stk_cd );

    BEGIN
        SELECT MIN(nvl(cust_max_amt, 0))
        INTO t_cust_max_amt         /*X*/
        FROM vn.dlm20m06 t
        WHERE  t.apy_dt <= vn.vhdate
            AND t.expr_dt >= vn.vhdate
            AND ACTIVE_STAT='Y'
            AND t.acnt_no LIKE i_acnt_no;
    EXCEPTION
    WHEN OTHERS THEN
        t_err_msg := vn.fxc_get_err_msg('V', '46053');
        vn.pxc_log_write('fdl_get_acnt_max_limit',
                        ' Tong han muc cua tai khoan error: ' || t_err_msg || ' ACNT_NO=' || i_acnt_no);
        raise_application_error(-20100,
                                t_err_msg ||
                                ' fdl_get_acnt_max_limit: ACNT_NO_STK_i_tp=' || i_acnt_no);
    END;

    IF t_cust_max_amt IS NOT NULL THEN
        t_acnt_limit := t_cust_max_amt;
    ELSE
        BEGIN
            SELECT TO_NUMBER(nvl(col_cd_tp, 0))
            INTO t_all_src_max_limit        /*A*/
            FROM vn.xcc01c02 a
            WHERE  a.col_cd LIKE 'all_src_max_limit'
                AND a.param_tp LIKE '401';
        EXCEPTION
            WHEN no_data_found THEN
            t_all_src_max_limit := 0;
            WHEN OTHERS THEN
            t_err_msg := vn.fxc_get_err_msg('V', '46054');
            vn.pxc_log_write('fdl_get_acnt_max_limit',
                                ' Select xcc01c02 error: ' || t_err_msg ||
                                ' col_cd= all_src_max_limit' );
        END;
        t_acnt_limit := nvl(t_all_src_max_limit, 0);
    END IF;

    BEGIN
        SELECT MIN(nvl(d5.acnt_max_amt, 0))
            INTO r_acnt_max_amt
            FROM vn.dlm20m05 d5 -- chinh sach rieng cua han muc tk
            WHERE d5.acnt_no = i_acnt_no
                AND d5.sub_no = i_sub_no
                AND d5.apy_dt <= vn.vhdate
                AND d5.expr_dt >= vn.vhdate
                AND d5.active_stat = 'Y';
    EXCEPTION
    WHEN OTHERS THEN
        t_err_msg := vn.fxc_get_err_msg('V', '46051');
        vn.pxc_log_write('fdl_get_acnt_max_limit',
                        ' Chinh sach rieng error: ' || t_err_msg || ' ACNT_NO=' ||
                        i_acnt_no || '-' || i_sub_no );
        raise_application_error(-20100,
                                t_err_msg ||
                                ' fdl_get_acnt_max_limit: csr ACNT_NO =' ||
                                i_acnt_no || '-' || i_sub_no );
    END;

    IF r_acnt_max_amt IS NOT NULL THEN
        t_acnt_max_limit := LEAST(t_acnt_limit, r_acnt_max_amt);
    ELSE
        BEGIN
            SELECT nvl(a.acc_lnd_lmit, 0)
            INTO t_acc_lnd_lmit         /*B*/
            FROM vn.dlm00m01 a
            WHERE a.item_cd like vn.faa_acnt_get_grp_no(i_acnt_no, i_sub_no, '2', vn.vhdate)
                AND a.active_stat like 'Y'
                AND a.item_tp = '08';
        EXCEPTION
            WHEN no_data_found THEN
            t_all_src_max_limit := 0;
            WHEN OTHERS THEN
            t_err_msg := vn.fxc_get_err_msg('V', '461000');
            vn.pxc_log_write('fdl_get_acnt_max_limit',
                                ' Select dlm00m01 error: ' || t_err_msg ||
                                ' ACNT_NO=' || i_acnt_no || '-' || i_sub_no || '-' ||
                                '08' );
        END;
        t_acnt_max_limit := LEAST(t_acnt_limit, t_acc_lnd_lmit);
    END IF;

    IF t_acnt_max_limit = 0 THEN
        RETURN 0;
    END IF;

    BEGIN
        SELECT SUM(nvl(lnd_use_amt, 0)) + SUM(nvl(lnd_expt_amt, 0))
        INTO t_acnt_lnd_amt         /*E*/
        FROM vn.dlm09m10
        WHERE acnt_no = i_acnt_no
            AND sub_no = i_sub_no
            AND lnd_tp IN ('70', '80');
    EXCEPTION WHEN OTHERS THEN
        t_err_msg := vn.fxc_get_err_msg('V', '46055');
        vn.pxc_log_write('fdl_get_acnt_max_limit',
                        ' Han muc da dung cua sub tk error: ' || t_err_msg || ' ACNT_NO=' ||
                        i_acnt_no || '-' || i_sub_no);
        raise_application_error(-20100,
                                t_err_msg ||
                                ' fdl_get_acnt_max_limit: ACNT_NO_STK_i_tp=' ||
                                i_acnt_no || '-' || i_sub_no );
    END;

    IF t_acnt_lnd_amt IS NULL THEN
        t_acnt_lnd_amt := 0;
    END IF;

    BEGIN
        SELECT SUM(nvl(lnd_use_amt, 0)) + SUM(nvl(lnd_expt_amt, 0))
        INTO t_all_sub_lnd_amt          /*G*/
        FROM vn.dlm09m10
        WHERE acnt_no = i_acnt_no
            AND lnd_tp IN ('70', '80');
    EXCEPTION WHEN OTHERS THEN
        t_err_msg := vn.fxc_get_err_msg('V', '46056');
        vn.pxc_log_write('fdl_get_acnt_max_limit',
                        ' Han muc da dung cua tk error: ' || t_err_msg || ' ACNT_NO=' ||
                        i_acnt_no || '-' || i_sub_no );
        raise_application_error(-20100,
                                t_err_msg ||
                                ' fdl_get_acnt_max_limit: ACNT_NO_STK_i_tp=' ||
                                i_acnt_no || '-' || i_sub_no );
    END;

    IF t_all_sub_lnd_amt IS NULL THEN
        t_all_sub_lnd_amt := 0;
    END IF;

    BEGIN
        SELECT nvl(SUM(decode(c.lnd_tp, '70', 1, 0)), 0) cnt_src_sec,
               nvl(SUM(decode(c.lnd_tp, '80', 1, 0)), 0) cnt_src_out_sec
        INTO t_cnt_src_sec,
           t_cnt_src_out_sec
        FROM vn.dlm90m00 a,
           vn.dlm00m01 b,
           vn.dlm00m01 c
        WHERE a.grp_acnt_no = trim(i_acnt_grp_no)
            AND a.active_stat = 'Y'
            AND a.apy_dt <= vn.vwdate
            AND b.item_tp = '02' /* San pham, tuong ung 1 nguon*/
            AND b.item_cd = a.prd_no
            AND b.active_stat = 'Y'
            and exists
                    (select 1
                    from vn.dlm30m00 sp
                    where sp.prd_no = b.item_cd
                    and vn.vwdate between sp.apy_dt and sp.expr_dt
                    and sp.active_stat = 'Y'
                    )
            AND c.item_tp = '03' /* nguon*/
            AND c.item_cd = b.src_no
            AND c.active_stat = 'Y'
            and exists
                    (select 1
                        from vn.dlm20m00 n
                    where n.src_no = c.item_cd
                        and vn.vwdate between n.apy_dt and n.expr_dt
                        and n.active_stat = 'Y'
                    )
            AND c.lnd_tp IN ('70', '80');

    EXCEPTION WHEN OTHERS THEN
        t_err_msg := vn.fxc_get_err_msg('V', '2157');
        vn.pxc_log_write('fdl_get_acnt_max_limit',
                        ' nguon trong, nguon ngoai error: ' || t_err_msg );
        raise_application_error(-20100,
                                t_err_msg ||
                                ' fdl_get_acnt_max_limit: nguon trong, nguon ngoai' );
    END;

    BEGIN
        SELECT (CASE
                    WHEN t_cnt_src_sec > 0 AND t_cnt_src_out_sec = 0 THEN /*Check nguon cty 70*/
                        LEAST(
                            LEAST(acnt_sum_lnd_limit, acnt_lnd_limit, stk_sum_lnd_limit, acc_lnd_amt_limit),
                            LEAST( GREATEST(t_acnt_max_limit - t_acnt_lnd_amt, 0), GREATEST(t_acnt_limit - t_all_sub_lnd_amt, 0))
                            )
                    ELSE
                        LEAST(
                            LEAST(acnt_sum_lnd_limit, acnt_lnd_limit, stk_sum_lnd_limit),
                            LEAST( GREATEST(t_acnt_max_limit - t_acnt_lnd_amt, 0), GREATEST(t_acnt_limit - t_all_sub_lnd_amt, 0))
                            )
                END) rll
        INTO t_rll
        FROM (SELECT vn.fdl_get_acnt_sum_lnd_limit(trim(i_acnt_no),
                                                        trim(i_sub_no),
                                                        '1') acnt_sum_lnd_limit,                /*1. Han muc gia tri con lai cua tai khoan theo tong cac nguon va san pham*/
                            vn.fdl_get_acnt_lnd_limit(trim(i_acnt_no),
                                                    trim(i_sub_no),
                                                    '08',
                                                    trim(i_acnt_grp_no),
                                                    '1') acnt_lnd_limit,                        /*2. Han muc con lai cua TK theo Nhom TK*/
                            vn.fdl_get_stk_sum_lnd_limit(trim(i_acnt_no),
                                                        trim(i_sub_no),
                                                        trim(i_stk_cd)) stk_sum_lnd_limit,  /*3. Han muc chung khoan con lai*/
                            vn.fdl_get_acc_lnd_amt_limit(trim(i_acnt_no)) acc_lnd_amt_limit  /*4. Han muc con lai so voi 3% Han muc tinh tren VCSH*/
                FROM dual);
        EXCEPTION WHEN OTHERS THEN
            t_err_msg := vn.fxc_get_err_msg('V', '2157');
            vn.pxc_log_write('fdl_get_acnt_max_limit',
                            ' t_rll error: ' || t_err_msg || ' ACNT_NO=' ||
                            i_acnt_no || '-' || i_sub_no || '-' || i_stk_cd || '-' ||
                            i_stk_cd || '-' || i_acnt_grp_no || '-' || i_acnt_grp_no);
            raise_application_error(-20100,
                                    t_err_msg ||
                                    ' fdl_get_acnt_max_limit: t_rll   ACNT_NO=' ||
                                    i_acnt_no || '-' || i_sub_no || '-' || i_stk_cd || '-' ||
                            i_stk_cd || '-' || i_acnt_grp_no || '-' || i_acnt_grp_no);
    END;

    vn.pxc_log_write('fdl_get_acnt_max_limit', 't_cust_max_amt = ' || t_cust_max_amt ||'  t_acnt_limit = '||
                        t_acnt_limit ||'  i_acnt_grp_no = ' || i_acnt_grp_no || '  t_all_src_max_limit = ' || t_all_src_max_limit ||
                        '  r_acnt_max_amt = ' || r_acnt_max_amt || '  t_acnt_max_limit = '|| t_acnt_max_limit || '  t_acc_lnd_lmit = '||
                        t_acc_lnd_lmit || '  t_acnt_lnd_amt = ' || t_acnt_lnd_amt || '  t_all_sub_lnd_amt = '|| t_all_sub_lnd_amt||
                        '  t_cnt_src_sec = '|| t_cnt_src_sec || '  t_cnt_src_out_sec = ' || t_cnt_src_out_sec);

    RETURN t_rll;

END fdl_get_acnt_max_limit;
/

