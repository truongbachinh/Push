create FUNCTION fdl_get_mrgn_basket_rt(
    i_acnt_no       IN  VARCHAR2,
    i_sub_no        IN  VARCHAR2,
    i_grp_acnt_no   IN  VARCHAR2,
    i_basket_cd     IN  VARCHAR2,
    i_stk_cd        IN  VARCHAR2,
    i_rt_tp         IN  VARCHAR2,
    i_apy_dt        IN  VARCHAR2
) RETURN NUMBER AS

/* ************************************************************************************************
    Author:         hphan
    Created Date:   14-May-2018
    Description:    This function is used to get basket information for an account or account group.

    Sample call:
        SELECT fdl_get_mrgn_basket_rt('069C000001', '01', 'G0001', '000', 'FPT', '01', '20180514') o_val
        FROM DUAL;

    MODIFICATION DETAILS:
    -------------------------------------------------------------------------------------------------
    Modified Date   Modified By       Modification Details
    -------------------------------------------------------------------------------------------------
    14-May-2018     hphan             Initial creation
    09-Sep-2019     luonglv           NHSV-1036: Sua logic khi lay chinh sach rieng

**************************************************************************************************/

/* Input description */
-- 01:      cd_bp_rate          Ti le suc mua CK GD
-- 02:      cd_rate             Ti le dam bao CK GD
-- 03:      delay_bp_rate       Ti le suc mua CK cho GD
-- 04:      delay_rate          Ti le dam bao CK cho GD
-- 05:      rgt_bp_rate         Ti le suc mua quyen bang CK
-- 06:      rgt_rate            Ti le dam bao quyen bang CK
-- 07:      cdr_bp              Ti le suc mua quyen bang tien
-- 08:      cdr                 Ti le dam bao quyen bang tien
-- 09:      vd_rt               Ti le cho vay bao lanh
-- 10:      lnd_lmt_pri         Gia cho vay toi da
-- 11:      priority            Thu tu uu tien                      -- removed
-- 12:      lnd_limit_qty       Han muc so luong
-- 13:      lnd_limit_amt       Han muc gia tri

-- Declare variable
    t_sec_cd                    VARCHAR2(5)     := '';
    t_grp_acnt_no               VARCHAR2(20)    := NULL;
    t_basket_cd                 VARCHAR2(5)     := NULL;
    t_acnt_grp_tp               VARCHAR2(2)     := '2';

    t_priv_policy_chk           NUMBER          := 1;
    t_general_policy_chk           NUMBER          := 1;
    t_priv_val                  NUMBER          := NULL;
    t_general_val               NUMBER          := NULL;

    t_vwdate                    VARCHAR2(8)     := NULL;

    t_err_msg                   VARCHAR2(4000)  := '';

    o_out_number                NUMBER;

BEGIN

    t_vwdate    := vn.vwdate();

    -- Validate input value for i_rt_tp
    IF (i_rt_tp NOT IN ('01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '12', '13')) THEN
        t_err_msg := vn.fxc_get_err_msg('V','460500');
        vn.pxc_log_write('fdl_get_mrgn_basket_rt',     'Loi khi lay thong tin ro chung khoan. Loai tra cuu khong chinh xac'
                                                    || ' i_rt_tp = '      || i_rt_tp
                        );

        raise_application_error(-20100, t_err_msg   || ' Loi khi lay thong tin ro chung khoan. Loai tra cuu khong chinh xac'
                                                    || ' i_rt_tp = '      || i_rt_tp
                                );
    END IF;

    -- Get sec_cd
    BEGIN
        SELECT vn.fxc_sec_cd('R')
        INTO t_sec_cd
        FROM DUAL;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        t_sec_cd      := '000';
    END;

    /* ************************************************************************************************/
    /*                    Getting grp_acnt_no and basket_cd if no input parameter                     */
    /* ************************************************************************************************/

    -- If the input grp_acnt_no is null, then get grp_acnt_no from acnt_no
    BEGIN
        IF i_grp_acnt_no IS NULL OR TRIM(i_grp_acnt_no) = '' THEN
            t_grp_acnt_no   := vn.faa_acnt_get_grp_no(i_acnt_no, i_sub_no, t_acnt_grp_tp, i_apy_dt);
        ELSE
            t_grp_acnt_no   := i_grp_acnt_no;
        END IF;

    EXCEPTION
    WHEN OTHERS THEN
        t_grp_acnt_no       := NULL;
    END;

    -- If the input basket_cd is null, then get basket_cd from grp_acnt_no and account
    BEGIN
        IF i_basket_cd IS NULL OR TRIM(i_basket_cd) = '' THEN
            t_basket_cd     := vn.faa_acnt_get_basket_cd(t_sec_cd, i_acnt_no, i_sub_no, t_grp_acnt_no, i_apy_dt);
        ELSE
            t_basket_cd     := i_basket_cd;
        END IF;

    EXCEPTION
    WHEN OTHERS THEN
        t_basket_cd         := NULL;
    END;

    /* ************************************************************************************************/
    /*                      Getting basket information for each request type                          */
    /* ************************************************************************************************/

    /* I. Get basket rate */
    IF(i_rt_tp IN ('01', '02', '03', '04', '05', '06', '07', '08', '09', '10')) THEN
        BEGIN
            -- 1. Get data from private policy dlm71m02
            SELECT DECODE(i_rt_tp,  '01',   NVL(cd_bp_rate, 0)      ,      -- Ti le suc mua CK GD
                                    '02',   NVL(cd_rate, 0)         ,      -- Ti le dam bao CK GD
                                    '03',   NVL(delay_bp_rate, 0)   ,      -- Ti le suc mua CK cho GD
                                    '04',   NVL(delay_rate, 0)      ,      -- Ti le dam bao CK cho GD
                                    '05',   NVL(rgt_bp_rate, 0)     ,      -- Ti le suc mua quyen bang CK
                                    '06',   NVL(rgt_rate, 0)        ,      -- Ti le dam bao quyen bang CK
                                    '07',   NVL(cdr_bp, 0)          ,      -- Ti le suc mua quyen bang tien
                                    '08',   NVL(cdr, 0)             ,      -- Ti le dam bao quyen bang tien
                                    '09',   NVL(vd_rt, 0)           ,      -- Ti le cho vay bao lanh
                                    '10',   lnd_lmt_pri                         -- Gia cho vay toi da
                        ) t_priv_val
            INTO t_priv_val
            FROM vn.dlm71m02
            WHERE acnt_no      = i_acnt_no
              AND sub_no       = i_sub_no
              AND grp_acnt_no  = t_grp_acnt_no
              AND basket_cd    = t_basket_cd
              AND stk_cd       = i_stk_cd
              AND apy_dt      <= i_apy_dt
              AND expr_dt     >= i_apy_dt
              AND active_stat  = 'Y';
        EXCEPTION WHEN NO_DATA_FOUND THEN
            t_priv_policy_chk := 0;

        WHEN OTHERS THEN
            t_err_msg := vn.fxc_get_err_msg('V','460500');
            vn.pxc_log_write('fdl_get_mrgn_basket_rt',     'Loi khi lay chinh sach rieng cho:'
                                                        || ' i_acnt_no = '      || i_acnt_no        || '-' || ' i_sub_no=' || i_sub_no
                                                        || ' t_grp_acnt_no = '  || t_grp_acnt_no
                                                        || ' t_basket_cd = '    || t_basket_cd
                                                        || ' i_stk_cd = '       || i_stk_cd
                            );

            raise_application_error(-20100, t_err_msg   || ' fdl_get_mrgn_basket_rt: Loi khi lay chinh sach rieng cho:'
                                                        || ' i_acnt_no = '      || i_acnt_no        || '-' || ' i_sub_no=' || i_sub_no
                                                        || ' t_grp_acnt_no = '  || t_grp_acnt_no
                                                        || ' t_basket_cd = '    || t_basket_cd
                                                        || ' i_stk_cd = '       || i_stk_cd
                                    );
        END;

        /* NHSV-1036: */
        /*IF (t_priv_policy_chk <> 0 OR t_priv_val IS NOT NULL) THEN
            o_out_number    := t_priv_val;
        ELSE
        */
        -- 2. Get data from general policy ssi01m00/ssi08m00
        BEGIN
            IF(t_basket_cd = '00000') THEN          -- Committee's basket
                IF(i_apy_dt = t_vwdate) THEN     -- Get current data
                    SELECT DECODE(i_rt_tp,  '01',   NVL(cd_bp_rate, 0)      ,      -- Ti le suc mua CK GD
                                            '02',   NVL(cd_rate, 0)         ,      -- Ti le dam bao CK GD
                                            '03',   NVL(delay_bp_rate, 0)   ,      -- Ti le suc mua CK cho GD
                                            '04',   NVL(delay_rate, 0)      ,      -- Ti le dam bao CK cho GD
                                            '05',   NVL(rgt_bp_rate, 0)     ,      -- Ti le suc mua quyen bang CK
                                            '06',   NVL(rgt_rate, 0)        ,      -- Ti le dam bao quyen bang CK
                                            '07',   NVL(cdr_bp, 0)          ,      -- Ti le suc mua quyen bang tien
                                            '08',   NVL(cdr, 0)             ,      -- Ti le dam bao quyen bang tien
                                            '09',   NVL(vd_rt, 0)           ,      -- Ti le cho vay bao lanh
                                            '10',   lnd_lmt_pri                         -- Gia cho vay toi da
                                ) t_general_val
                    INTO t_general_val
                    FROM vn.ssi01m00 s
                    WHERE s.stk_cd = i_stk_cd;
                ELSE                                -- Get history data
                    SELECT DECODE(i_rt_tp,  '01',   NVL(cd_bp_rate, 0)      ,      -- Ti le suc mua CK GD
                                            '02',   NVL(cd_rate, 0)         ,      -- Ti le dam bao CK GD
                                            '03',   NVL(delay_bp_rate, 0)   ,      -- Ti le suc mua CK cho GD
                                            '04',   NVL(delay_rate, 0)      ,      -- Ti le dam bao CK cho GD
                                            '05',   NVL(rgt_bp_rate, 0)     ,      -- Ti le suc mua quyen bang CK
                                            '06',   NVL(rgt_rate, 0)        ,      -- Ti le dam bao quyen bang CK
                                            '07',   NVL(cdr_bp, 0)          ,      -- Ti le suc mua quyen bang tien
                                            '08',   NVL(cdr, 0)             ,      -- Ti le dam bao quyen bang tien
                                            '09',   NVL(vd_rt, 0)           ,      -- Ti le cho vay bao lanh
                                            '10',   lnd_lmt_pri                         -- Gia cho vay toi da
                                ) t_general_val
                    INTO t_general_val
                    FROM vn.ssi01h00 s
                    WHERE s.stk_cd      = i_stk_cd
                      AND s.dt          = i_apy_dt;
                END IF;
            ELSE                                    -- Company's basket
                IF(i_apy_dt = t_vwdate) THEN     -- Get current data
                    SELECT DECODE(i_rt_tp,  '01',   NVL(cd_bp_rate, 0)      ,      -- Ti le suc mua CK GD
                                            '02',   NVL(cd_rate, 0)         ,      -- Ti le dam bao CK GD
                                            '03',   NVL(delay_bp_rate, 0)   ,      -- Ti le suc mua CK cho GD
                                            '04',   NVL(delay_rate, 0)      ,      -- Ti le dam bao CK cho GD
                                            '05',   NVL(rgt_bp_rate, 0)     ,      -- Ti le suc mua quyen bang CK
                                            '06',   NVL(rgt_rate, 0)        ,      -- Ti le dam bao quyen bang CK
                                            '07',   NVL(cdr_bp, 0)          ,      -- Ti le suc mua quyen bang tien
                                            '08',   NVL(cdr, 0)             ,      -- Ti le dam bao quyen bang tien
                                            '09',   NVL(vd_rt, 0)           ,      -- Ti le cho vay bao lanh
                                            '10',   lnd_lmt_pri                         -- Gia cho vay toi da
                                ) t_general_val
                    INTO t_general_val
                    FROM vn.ssi08m00 s
                    WHERE s.basket_cd   = t_basket_cd
                      AND s.stk_cd      = i_stk_cd
                      --AND s.active_stat in ('Y','M','W','D','A');
                      AND s.active_stat||s.bk_active in ('Y','M','D','A','WY','WA','WD');
                ELSE                                -- Get history data
                    SELECT DECODE(i_rt_tp,  '01',   NVL(cd_bp_rate, 0)      ,      -- Ti le suc mua CK GD
                                            '02',   NVL(cd_rate, 0)         ,      -- Ti le dam bao CK GD
                                            '03',   NVL(delay_bp_rate, 0)   ,      -- Ti le suc mua CK cho GD
                                            '04',   NVL(delay_rate, 0)      ,      -- Ti le dam bao CK cho GD
                                            '05',   NVL(rgt_bp_rate, 0)     ,      -- Ti le suc mua quyen bang CK
                                            '06',   NVL(rgt_rate, 0)        ,      -- Ti le dam bao quyen bang CK
                                            '07',   NVL(cdr_bp, 0)          ,      -- Ti le suc mua quyen bang tien
                                            '08',   NVL(cdr, 0)             ,      -- Ti le dam bao quyen bang tien
                                            '09',   NVL(vd_rt, 0)           ,      -- Ti le cho vay bao lanh
                                            '10',   lnd_lmt_pri                         -- Gia cho vay toi da
                                ) t_general_val
                    INTO t_general_val
                    FROM vn.ssi08h00 s
                    WHERE s.basket_cd   = t_basket_cd
                      AND s.stk_cd      = i_stk_cd
                      AND s.dt          = i_apy_dt;
                END IF;
            END IF; -- End Getting data from general policy ssi01m00/ssi08m00
        EXCEPTION WHEN NO_DATA_FOUND THEN
            SELECT DECODE(i_rt_tp,  '01',   0,      -- Ti le suc mua CK GD
                                    '02',   0,      -- Ti le dam bao CK GD
                                    '03',   0,      -- Ti le suc mua CK cho GD
                                    '04',   0,      -- Ti le dam bao CK cho GD
                                    '05',   0,      -- Ti le suc mua quyen bang CK
                                    '06',   0,      -- Ti le dam bao quyen bang CK
                                    '07',   0,      -- Ti le suc mua quyen bang tien
                                    '08',   0,      -- Ti le dam bao quyen bang tien
                                    '09',   0,      -- Ti le cho vay bao lanh
                                    '10',   null       -- Gia cho vay toi da
                        ) t_general_val
            INTO t_general_val
            FROM DUAL;

            t_general_policy_chk := 0;
        WHEN OTHERS THEN 
            t_err_msg := vn.fxc_get_err_msg('V','203500');
            vn.pxc_log_write('fdl_get_mrgn_basket_rt',     'Loi khi lay chinh sach chung cho:'
                                                        || ' i_acnt_no = '      || i_acnt_no        || '-' || ' i_sub_no=' || i_sub_no
                                                        || ' t_grp_acnt_no = '  || t_grp_acnt_no
                                                        || ' t_basket_cd = '    || t_basket_cd
                                                        || ' i_stk_cd = '       || i_stk_cd
                            );
            raise_application_error(-20100, t_err_msg   || ' fdl_get_mrgn_basket_rt: Loi khi lay chinh sach chung cho:'
                                                        || ' i_acnt_no = '      || i_acnt_no        || '-' || ' i_sub_no=' || i_sub_no
                                                        || ' t_grp_acnt_no = '  || t_grp_acnt_no
                                                        || ' t_basket_cd = '    || t_basket_cd
                                                        || ' i_stk_cd = '       || i_stk_cd
                                    );
        END;

        /*Use the private val if general val is existing and private val is not null*/
        IF (t_general_policy_chk <> 0 and t_priv_policy_chk <> 0 and t_priv_val IS NOT NULL) THEN
            o_out_number    := t_priv_val;
        ELSE
            o_out_number := t_general_val;
        END IF;

    /* II. Get basket room */
    ELSIF(i_rt_tp IN ('12', '13')) THEN
        BEGIN
            -- 1. Get data from private policy dlm71m02
            SELECT DECODE(i_rt_tp,  '12',   NVL(lnd_limit_qty, 0),   -- Han muc so luong
                                    '13',   NVL(lnd_limit_amt, 0)    -- Han muc gia tri
                        ) t_priv_val
            INTO t_priv_val
            FROM vn.dlm71m03
            WHERE acnt_no      = i_acnt_no
              AND sub_no       = i_sub_no
              AND grp_acnt_no  = t_grp_acnt_no
              AND basket_cd    = t_basket_cd
              AND stk_cd       = i_stk_cd
              AND apy_dt      <= i_apy_dt
              AND expr_dt     >= i_apy_dt
              AND active_stat  = 'Y';
        EXCEPTION WHEN NO_DATA_FOUND THEN
            t_priv_policy_chk := 0;

        WHEN OTHERS THEN
            t_err_msg := vn.fxc_get_err_msg('V','460500');
            vn.pxc_log_write('fdl_get_mrgn_basket_rt',     'Loi khi lay chinh sach rieng cho:'
                                                        || ' i_acnt_no = '      || i_acnt_no        || '-' || ' i_sub_no=' || i_sub_no
                                                        || ' t_grp_acnt_no = '  || t_grp_acnt_no
                                                        || ' t_basket_cd = '    || t_basket_cd
                                                        || ' i_stk_cd = '       || i_stk_cd
                            );

            raise_application_error(-20100, t_err_msg   || ' fdl_get_mrgn_basket_rt: Loi khi lay chinh sach rieng cho:'
                                                        || ' i_acnt_no = '      || i_acnt_no        || '-' || ' i_sub_no=' || i_sub_no
                                                        || ' t_grp_acnt_no = '  || t_grp_acnt_no
                                                        || ' t_basket_cd = '    || t_basket_cd
                                                        || ' i_stk_cd = '       || i_stk_cd
                                    );
        END;

        /*IF (t_priv_policy_chk <> 0 OR t_priv_val IS NOT NULL) THEN
            o_out_number    := t_priv_val;
        ELSE
        */
        -- 2. Get data from general policy ssi01m00/ssi08m00
        BEGIN
            IF(t_basket_cd = '00000') THEN          -- Committee's basket
                IF(i_apy_dt = t_vwdate) THEN     -- Get current data
                    SELECT DECODE(i_rt_tp,  '12',   NVL(lnd_limit_qty, 0),   -- Han muc so luong
                                            '13',   NVL(lnd_limit_amt, 0)    -- Han muc gia tri
                                ) t_general_val
                    INTO t_general_val
                    FROM vn.ssi01m00 s
                    WHERE s.stk_cd = i_stk_cd;
                ELSE                                -- Get history data
                    SELECT DECODE(i_rt_tp,  '12',   NVL(lnd_limit_qty, 0),   -- Han muc so luong
                                            '13',   NVL(lnd_limit_amt, 0)    -- Han muc gia tri
                                ) t_general_val
                    INTO t_general_val
                    FROM vn.ssi01h00 s
                    WHERE s.stk_cd      = i_stk_cd
                      AND s.dt          = i_apy_dt;
                END IF;
            ELSE                                    -- Company's basket
                IF(i_apy_dt = t_vwdate) THEN     -- Get current data
                    SELECT DECODE(i_rt_tp,  '12',   NVL(lnd_limit_qty, 0),   -- Han muc so luong
                                            '13',   NVL(lnd_limit_amt, 0)    -- Han muc gia tri
                                ) t_general_val
                    INTO t_general_val
                    FROM vn.ssi08m00 s
                    WHERE s.basket_cd   = t_basket_cd
                      AND s.stk_cd      = i_stk_cd
                      --AND s.active_stat in ('Y','M','W','D','A');
                      AND s.active_stat||s.bk_active in ('Y','M','D','A','WY','WA','WD');
                ELSE                                -- Get history data
                    SELECT DECODE(i_rt_tp,  '12',   NVL(lnd_limit_qty, 0),   -- Han muc so luong
                                            '13',   NVL(lnd_limit_amt, 0)    -- Han muc gia tri
                                ) t_general_val
                    INTO t_general_val
                    FROM vn.ssi08h00 s
                    WHERE s.basket_cd   = t_basket_cd
                      AND s.stk_cd      = i_stk_cd
                      AND s.dt          = i_apy_dt;
                END IF;
            END IF; -- End Getting data from general policy ssi01m00/ssi08m00
        EXCEPTION WHEN NO_DATA_FOUND THEN
            SELECT DECODE(i_rt_tp,  '12',   0,   -- Han muc so luong
                                    '13',   0    -- Han muc gia tri
                        ) t_general_val
            INTO t_general_val
            FROM DUAL;

            t_general_policy_chk := 0;

        WHEN OTHERS THEN 
            t_err_msg := vn.fxc_get_err_msg('V','203500');
            vn.pxc_log_write('fdl_get_mrgn_basket_rt',     'Loi khi lay chinh sach chung cho:'
                                                        || ' i_acnt_no = '      || i_acnt_no        || '-' || ' i_sub_no=' || i_sub_no
                                                        || ' t_grp_acnt_no = '  || t_grp_acnt_no
                                                        || ' t_basket_cd = '    || t_basket_cd
                                                        || ' i_stk_cd = '       || i_stk_cd
                            );
            raise_application_error(-20100, t_err_msg   || ' fdl_get_mrgn_basket_rt: Loi khi lay chinh sach chung cho:'
                                                        || ' i_acnt_no = '      || i_acnt_no        || '-' || ' i_sub_no=' || i_sub_no
                                                        || ' t_grp_acnt_no = '  || t_grp_acnt_no
                                                        || ' t_basket_cd = '    || t_basket_cd
                                                        || ' i_stk_cd = '       || i_stk_cd
                                    );
        END;

        /*Use the private val if general val is existing and private val is not null*/
        IF (t_general_policy_chk <> 0 and t_priv_policy_chk <> 0 and t_priv_val IS NOT NULL) THEN
            o_out_number    := t_priv_val;
        ELSE
            o_out_number := t_general_val;
        END IF;

    END IF;

    RETURN o_out_number;

END fdl_get_mrgn_basket_rt;
/

