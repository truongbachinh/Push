create PROCEDURE PGG_CREDATA_GGA10M00
       (
       I_YYYYMMDD IN      VARCHAR2
       ) IS

BEGIN

    INSERT INTO VN.GGA10M00
    /* 출장소제외, 부점중에서도 실부점만 */
    SELECT   A.YY||A.MM||B.DD AS ACC_CLS_DT,
             BR.BRCH_CD       AS BRCH_CD   ,
             BR.AGNC_BRCH     AS AGNC_BRCH ,
             'N'              AS ACC_CLS_YN,
             'CONV'           AS WORK_MN   ,
             SYSDATE          AS WORK_DTM  ,
             'CONV'           AS WORK_TRM
    FROM     (
              SELECT BRCH_CD, AGNC_BRCH, HEAD_BRCH_TP FROM VN.XCC90M00
              WHERE  AGNC_BRCH    = '00'
              /* AND    REAL_BRCH_YN = 'Y' */
              AND    AGNC_BRCH NOT IN (SELECT COL_CD_TP FROM VN.XCC01C01 WHERE COL_CD = 'ALL_COM')
              AND    AGNC_BRCH NOT IN (SELECT COL_CD_TP FROM VN.XCC01C01 WHERE COL_CD = 'NCL_COM')
             ) BR,
             (
              SELECT SUBSTR(I_YYYYMMDD,1,4) YY, LPAD(ROWNUM, 2, '0') MM
              FROM   DICT
              WHERE  ROWNUM <= 12
             ) A,
             (
              SELECT LPAD(ROWNUM, 2, '0') DD
              FROM   DICT
              WHERE  ROWNUM <= 31
             ) B
    WHERE    B.DD IN (
                      SELECT LPAD(ROWNUM, 2, '0') DD
                      FROM   DICT
                      WHERE  ROWNUM <= SUBSTR(TO_CHAR(LAST_DAY(A.YY||A.MM||'01'), 'YYYYMMDD'),7,2)
                     )
    AND     (BR.BRCH_CD,A.YY||A.MM||B.DD) NOT IN (SELECT BRCH_CD, ACC_CLS_DT FROM VN.GGA10M00)
    AND      A.YY||A.MM||B.DD >= I_YYYYMMDD
    ORDER BY BR.BRCH_CD, A.YY, A.MM, B.DD
    ;

    COMMIT;

END PGG_CREDATA_GGA10M00;
/

