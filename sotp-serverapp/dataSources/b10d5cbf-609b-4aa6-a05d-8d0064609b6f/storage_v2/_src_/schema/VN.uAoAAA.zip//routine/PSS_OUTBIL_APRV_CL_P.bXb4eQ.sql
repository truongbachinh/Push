create PROCEDURE pss_outbil_aprv_cl_p
(
  is_proc_dt    in  varchar2,
  is_acnt_no    in  varchar2,
  is_sub_no     in  varchar2,
  is_seq_no      in  varchar2,
  is_work_mn  in  varchar2,
  is_work_trm  in  varchar2,
  is_work_bnh  in  varchar2,
  is_dept_no2  in  varchar2,
  os_end_yn      out  varchar2,
  os_err_msg  out  varchar2

) AS

  tn_cncl_trd_no  number  := 0;
  tn_trd_seq_no    number  := 0;
  tn_qty      number  := 0;
  tn_sb_lmt_qty    number  := 0;
  tn_delay_qty    number  := 0; --Hoai them 20151229: VCSC-1531
  tn_delay_sb_qty		number	:= 0; --Huedt add 20180607
  tn_sb_pri      number  := 0;
  tn_cnt      number  := 0;

  tot_cnt      number    := 0;
  tn_loop_cnt    number    := 0;

  ts_stk_cd      varchar2(12)  := '';

  ts_inq_dt      varchar2(8)   := '' ;
  ts_wdate      varchar2(8)   := '' ;
  ts_date        varchar2(8)   := '' ;
  ts_step      varchar2(10) := '' ;
  ts_std_inq_dt     varchar2(8)  :=  '';   --approving date
  ts_rgt_chk        varchar2(2)  := null;

  o_cnt          number    := 0;

  t_rtn_val         varchar2(1)    := null;
  t_err_txt         varchar2(200)  := null;
  t_err_msg         varchar2(200)  := null;

  -- LTHN-248
  tn_std_inq_dt         varchar2(8);
  tn_rgt_tax_qty        number := 0;
  tn_rgt_tax_price      number := 0;
  tn_rgt_tax_amt        number := 0;
  tn_tax_qty            number := 0;
  tn_tax_sb_lim_qty     number := 0;
  tn_tax_delay_qty      number := 0;
  tn_tax_delay_sb_qty   number := 0;
  tn_wtax_qty           number := 0;
  tn_wtax_sb_lim_qty    number := 0;
  tn_wtax_delay_qty     number := 0;
  tn_wtax_delay_sb_qty  number := 0;

  ERR_RTN      EXCEPTION;

BEGIN

  -- work_date

  ts_step := '1';

  SELECT VN.VWDATE()
  INTO ts_wdate
  FROM DUAL;

  vn.pxc_log_write('pss_outbil_aprv_cl_p','acnt_no '||is_acnt_no ||' is_proc_dt '|| is_proc_dt ||' seq_no '||is_seq_no);

 /*** check closing ***/

 t_rtn_val := 'Y';

 if  is_work_mn  not in ('DAILY','BATCH') then

        vn.pbm_cls_yn_q(  vn.vhdate
                       ,  vn.fbm_emp_bnh_q(     is_work_mn)
                       ,  vn.faa_acnt_bnh_cd_g( '0',is_acnt_no, is_sub_no)
                       , '1'
                       ,  t_rtn_val
                       ,  t_err_txt
                       );

        if  t_rtn_val  !=  'N' then
            t_err_msg := vn.fxc_get_err_msg('V','2716');
            raise_application_error(-20100,t_err_msg||t_err_txt);
        end if;

 end if;

  -- ssb05m00

  ts_step := '2';

  SELECT inq_dt
        ,trd_seq_no
        ,stk_cd
        ,qty
        ,sb_lmt_qty
        ,std_inq_dt
        ,delay_qty --Hoai them 20151229: VCSC-1531
        ,delay_sb_qty  --Huedt add 20180607
        ,std_inq_dt
        ,rgt_tax_qty
        ,rgt_tax_price
        ,rgt_tax_amt
  INTO   ts_inq_dt
        ,tn_trd_seq_no
        ,ts_stk_cd
        ,tn_qty
        ,tn_sb_lmt_qty
        ,ts_std_inq_dt
        ,tn_delay_qty
        ,tn_delay_sb_qty
        ,tn_std_inq_dt
        ,tn_rgt_tax_qty
        ,tn_rgt_tax_price
        ,tn_rgt_tax_amt
  FROM  VN.SSB05M00 t
 WHERE  PROC_DT = is_proc_dt
   AND  ACNT_NO = is_acnt_no
   AND  SUB_NO  = is_sub_no
   AND  SEQ_NO = to_number(is_seq_no);

 pxc_log_write('pss_outbil_aprv_cl_p','select ssb05m00  inq_dt :' || ts_inq_dt  );

 /*check change rights */
  select  vn.fsr_chage_rgt_p( ts_stk_cd , ts_wdate)
    into  ts_rgt_chk
    from dual;

  if  ts_rgt_chk = 'Y' then
      os_end_yn := 'N';
    os_err_msg := '2029';
    RAISE  ERR_RTN;
  end if ;

 IF  ts_wdate <> ts_inq_dt  THEN   /* must proc date is today   */
    os_end_yn := 'N';
    os_err_msg := '2030';
    RAISE ERR_RTN;
 END IF;

/** Get Trd_Seq_no **/

 ts_step := '3';

 if ts_wdate =  ts_std_inq_dt then      /* confirm date is today  */
   pxc_psb_seq_cret_p (is_acnt_no, is_sub_no, ts_wdate, tn_cncl_trd_no, tn_cncl_trd_no);
 else

   begin
    select nvl(max(trd_seq_no),0)
       into tn_cncl_trd_no
       from vn.aaa10m00
      where acnt_no = is_acnt_no
      and sub_no = is_sub_no
        and trd_dt = ts_std_inq_dt;
      exception
          when NO_DATA_FOUND then
        tn_cncl_trd_no := 0;
   end;

   tn_cncl_trd_no := tn_cncl_trd_no + 1 ;
  end if ;

  pxc_log_write('pss_outbil_aprv_cl_p','tn_cncl_trd_no :' || tn_cncl_trd_no);

/** Get unit price **/

  ts_step := '4';

  SELECT  sb_pri
    INTO  tn_sb_pri
    FROM  vn.aaa10m00
   WHERE  acnt_no = is_acnt_no
   AND    sub_no  = is_sub_no
     AND  trd_dt = ts_std_inq_dt
     AND  trd_seq_no = tn_trd_seq_no;

  pxc_log_write('pss_outbil_aprv_cl_p','tn_sb_pri : ' || tn_sb_pri);

 ts_step := '5';

 UPDATE  vn.aaa10m00
    SET  cncl_yn  = 'Y'
       ,work_bnh = is_work_bnh
       ,work_mn  = is_work_mn
       ,work_dtm = sysdate
       ,work_trm = is_work_trm
  WHERE  acnt_no = is_acnt_no
  AND sub_no  = is_sub_no
    AND  trd_dt  = ts_std_inq_dt
    AND  trd_seq_no = tn_trd_seq_no;

 INSERT INTO vn.aaa10m00 (    acnt_no            --
                             ,sub_no             --
                             ,trd_dt             --
                             ,trd_seq_no         --
                             ,trd_tp             --
                             ,rmrk_cd            --
                             ,mdm_tp             --
                             ,trd_mdm_tp         --
                             ,cncl_yn            --
                             ,org_trd_no         --
                             ,trd_amt            --
                             ,cmsn               --
                             ,adj_amt            --
                             ,dpo_prerm          --
                             ,dpo_nowrm          --
                             ,stk_cd             --
                             ,stk_nm             --
                             ,sb_pri             --
                             ,sb_qty             --
                             ,bil_prerm_qty      --
                             ,bil_nowrm_qty      --
                             ,tot_bil_prerm      --
                             ,tot_bil_nowrm      --
                             ,book_amt           --
                             ,stk_tp             --
                             ,mth_dt             --
                             ,lnd_tp
                             ,lnd_dt
                             ,lnd_int
                             ,agnt_yn            --
                             ,acnt_mng_bnh       --
                             ,work_bnh           --
                             ,work_mn            --
                             ,work_dtm           --
                             ,work_trm           --
                             ,agnc_brch
                             ,proc_agnc_brch
                             ,cnfm_dt          )
                    ( SELECT  acnt_no                     -- acnt_no
                             ,sub_no                     -- trd_dt
                             ,trd_dt                     -- trd_dt
                             ,tn_cncl_trd_no             -- trd_seq_no
                             ,trd_tp                         -- trd_tp
                             ,decode(rmrk_cd, '221', '230', '222', '231', '223', '232', '229', '233', '234', '235')  -- rmrk_cd
                             ,mdm_tp                     -- mdm_tp
                             ,trd_mdm_tp                 -- trd_mdm_tp
                             ,'N'                            -- cncl_yn
                             ,trd_seq_no                 -- org_trd_no
                             ,0                          -- trd_amt
                             ,0                          -- cmsn
                             ,0                          -- adj_amt
                             ,0                          -- dpo_prerm            --> ?
                             ,0                          -- dpo_nowrm            --> ?
                             ,stk_cd                     -- stk_cd
                             ,stk_nm                     -- stk_nm
                             ,sb_pri                     -- sb_pri
                             ,sb_qty                     -- sb_qty
                             ,bil_nowrm_qty              -- bil_prerm_qty
                             ,bil_nowrm_qty + sb_qty     -- bil_nowrm_qty
                             ,tot_bil_nowrm              -- bil_prerm_qty
                             ,tot_bil_nowrm + sb_qty     -- bil_nowrm_qty
                             ,book_amt                   -- book_amt
                             ,stk_tp                     -- stk_tp
                             ,null                       -- mth_dt
                             ,null
                             ,null
                             ,0
                             ,'N'                            -- agnt_yn
                             ,acnt_mng_bnh               -- acnt_mng_bnh
                             ,is_work_bnh                    -- work_bnh
                             ,is_work_mn                 -- work_mn
                             ,sysdate                        -- work_dtm
                             ,is_work_trm                    -- work_trm
                             ,agnc_brch
                             ,is_dept_no2
                             ,cnfm_dt
                        FROM  vn.aaa10m00
                       WHERE  acnt_no = is_acnt_no
             AND  sub_no  = is_sub_no
                         AND  trd_dt = ts_std_inq_dt
                         AND  trd_seq_no = tn_trd_seq_no);


 /* update aaa10m00  and ssb01h00 */

 if ts_std_inq_dt <> ts_wdate then

   ts_step := 6 ;

   select to_date(ts_wdate, 'yyyymmdd') - to_date(ts_std_inq_dt, 'yyyymmdd')
     into tot_cnt
     from dual;

   pxc_log_write('pss_outbil_aprv_cl_p','std_inq_dt aaa10m00 cnt: ' || ts_std_inq_dt || ' ' || tot_cnt);

   for c1 in 0..tot_cnt loop

     select to_char((to_date(ts_std_inq_dt,'yyyymmdd') + tn_loop_cnt),'yyyymmdd')
        into ts_date
        from dual;

      if vn.fxc_holi_ck(to_date(ts_date,'yyyymmdd')) =  '0' then

     if ts_date >  ts_std_inq_dt then /* excepts trd_dt */

       pxc_log_write('pss_outbil_aprv_cl_p',' update trd_dt  :' || ts_date);

           BEGIN
             update vn.aaa10m00
               set bil_prerm_qty = bil_prerm_qty + (tn_qty + tn_sb_lmt_qty + tn_delay_qty + tn_delay_sb_qty) --Hoai them tn_delay_qty VCSC-1531
                   ,bil_nowrm_qty = bil_nowrm_qty + (tn_qty + tn_sb_lmt_qty + tn_delay_qty + tn_delay_sb_qty)--Huedt add SL cho GD HCCN
                   ,tot_bil_prerm = tot_bil_prerm + (tn_qty + tn_sb_lmt_qty + tn_delay_qty + tn_delay_sb_qty)
                   ,tot_bil_nowrm = tot_bil_nowrm + (tn_qty + tn_sb_lmt_qty + tn_delay_qty + tn_delay_sb_qty)
          where acnt_no = is_acnt_no
          and sub_no  = is_sub_no
             and stk_cd = ts_stk_cd
             and trd_dt = ts_date
             and (nvl(bil_prerm_qty,0) > 0 or nvl(bil_nowrm_qty,0) > 0);
           exception
             when OTHERS then
                raise_application_error(-20100,'error' );
          end;
     end if ;

       if  ts_date < ts_wdate then   /* excepts today  */

             pxc_log_write('pss_outbil_aprv_cl_p','rgt_std_dt update :' || ts_date );

             merge into vn.ssb01h00
             using dual
             on (acnt_no = is_acnt_no
          AND   sub_no = is_sub_no
                AND   stk_cd = ts_stk_cd
                AND   rgt_std_dt = ts_date)

             when matched then
                update  set
                    own_qty = own_qty + (tn_qty + tn_sb_lmt_qty + tn_delay_qty + tn_delay_sb_qty) --Hoai them tn_delay_qty VCSC-1531
                   ,sb_lim_qty = sb_lim_qty + tn_sb_lmt_qty
                   ,delay_qty = delay_qty + tn_delay_qty --Hoai them VCSC-1531
                   ,book_amt = book_amt + ((tn_qty + tn_sb_lmt_qty + tn_delay_qty + tn_delay_sb_qty) * tn_sb_pri) --Hoai them tn_delay_qty VCSC-1531
                   ,outq_req_qty = outq_req_qty + tn_qty
				           ,lim_req_qty = lim_req_qty + tn_sb_lmt_qty
				           ,delay_req_qty = delay_req_qty + tn_delay_qty
							     ,delay_sb_qty = delay_sb_qty + tn_delay_sb_qty
							     ,delay_req_sb_qty = delay_req_sb_qty + tn_delay_sb_qty
                   ,work_mn = is_work_mn
                   ,work_dtm = sysdate
                   ,work_trm = is_work_trm

            when not matched then
        insert (rgt_std_dt ,
            acnt_no    ,
            sub_no     ,
            stk_cd     ,
            own_qty    ,
            book_amt   ,
            sb_lim_qty ,
            mov_lim_qty ,
            outq_req_qty,
						lim_req_qty,
						delay_req_qty,
            delay_req_sb_qty)
                values ( ts_date    ,
                         is_acnt_no ,
                         is_sub_no  ,
                         ts_stk_cd  ,
                         tn_qty + tn_sb_lmt_qty ,
                         (tn_qty + tn_sb_lmt_qty ) * tn_sb_pri ,
                         tn_sb_lmt_qty ,
                         0,
                         tn_qty ,
						             tn_sb_lmt_qty,
						             tn_delay_qty,
                         tn_delay_sb_qty) ;
       end if ;

     end if ;

     tn_loop_cnt := tn_loop_cnt + 1 ;

    end loop;
  end if ;


  ts_step := '7';

  UPDATE  vn.ssb01m00
     SET  own_qty = own_qty + (tn_qty + tn_sb_lmt_qty + tn_delay_qty + tn_delay_sb_qty) --Hoai them tn_delay_qty VCSC-1531
           ,book_amt = book_amt + ((tn_qty + tn_sb_lmt_qty + tn_delay_qty + tn_delay_sb_qty) * tn_sb_pri)
           ,work_mn = is_work_mn
           ,work_dtm = sysdate
           ,work_trm = is_work_trm
           ,sb_lim_qty = sb_lim_qty + tn_sb_lmt_qty
           ,delay_qty = delay_qty + tn_delay_qty --Hoai them VCSC-1531
           ,outq_req_qty = outq_req_qty + tn_qty
           ,lim_req_qty = lim_req_qty + tn_sb_lmt_qty
           ,DELAY_REG_QTY = DELAY_REG_QTY + tn_delay_qty --Hoai them VCSC-1531
           ,delay_req_sb_qty = delay_req_sb_qty + tn_delay_sb_qty
           ,delay_sb_qty = delay_sb_qty + tn_delay_sb_qty
    WHERE  acnt_no = is_acnt_no
    AND   sub_no  = is_sub_no
      AND  stk_cd = ts_stk_cd;

-- ssb05m00
   UPDATE   VN.SSB05M00
      SET   inq_dt = NULL
           ,std_inq_dt = NULL
           ,cncl_trd_no = tn_cncl_trd_no
           ,end_yn = 'N'
           ,err_msg = NULL
           ,work_mn = is_work_mn
           ,work_dtm = sysdate
           ,work_trm = is_work_trm
     WHERE  proc_dt = is_proc_dt
       AND  acnt_no = is_acnt_no
     AND  sub_no  = is_sub_no
       AND  seq_no = to_number(is_seq_no);

  /* LTHN-248 */
  if tn_rgt_tax_qty > 0 then
    if tn_qty > 0 then
      tn_tax_qty := tn_rgt_tax_qty;
      tn_wtax_qty := tn_rgt_tax_qty;
    end if;

    if tn_sb_lmt_qty > 0 then
      tn_tax_sb_lim_qty := tn_rgt_tax_qty;
      tn_wtax_sb_lim_qty := tn_rgt_tax_qty;
    end if;

    if tn_delay_qty > 0 then
      tn_tax_delay_qty := tn_rgt_tax_qty;
      tn_wtax_delay_qty := tn_rgt_tax_qty;
    end if;

    if tn_delay_sb_qty > 0 then
      tn_tax_delay_sb_qty := tn_rgt_tax_qty;
      tn_wtax_delay_sb_qty := tn_rgt_tax_qty;
    end if;
    /* Update ssb05m10 */
    update ssb05m10
    set tax_qty = tax_qty + tn_tax_qty,
        tax_sb_lim_qty = tax_sb_lim_qty + tn_tax_sb_lim_qty,
        tax_delay_qty = tax_delay_qty + tn_tax_delay_qty,
        tax_delay_sb_qty = tax_delay_sb_qty + tn_tax_delay_sb_qty,
        wtax_qty = wtax_qty + tn_wtax_qty,
        wtax_sb_lim_qty = wtax_sb_lim_qty + tn_wtax_sb_lim_qty,
        wtax_delay_qty = wtax_delay_qty + tn_wtax_delay_qty,
        wtax_delay_sb_qty = wtax_delay_sb_qty + tn_wtax_delay_sb_qty,
        work_mn = is_work_mn,
        work_dtm = sysdate,
        work_trm = is_work_trm
    where acnt_no = is_acnt_no
      and stk_cd = ts_stk_cd;

    /* Update ssb05h10 */
    for c1 in (
      select max(id) as id_max, proc_dt, acnt_no, stk_cd
        from ssb05h10
       where proc_dt >= tn_std_inq_dt
         and acnt_no = is_acnt_no
         and stk_cd = ts_stk_cd
       group by proc_dt, acnt_no, stk_cd
    ) loop
      vn.pxc_log_write('pss_inbil_aprv_cl_p', 'c1.proc_dt: ' || c1.proc_dt || ', ' ||'c1.acnt_no: ' || c1.acnt_no || ', ' || 'c1.stk_cd: ' || c1.stk_cd);
      insert into ssb05h10
            ( id,
              proc_dt,
              acnt_no,
              stk_cd,
              tax_qty,
              tax_sb_lim_qty,
              tax_delay_qty,
              tax_delay_sb_qty,
              wtax_qty,
              wtax_sb_lim_qty,
              wtax_delay_qty,
              wtax_delay_sb_qty,
              cnte,
              create_mn,
              create_dtm,
              create_trm,
              work_mn,
              work_dtm,
              work_trm,
              backup_mn,
              backup_dtm,
              backup_trm)
            select ssb05h10_seq.nextval,
                  c1.proc_dt,
                  acnt_no,
                  stk_cd,
                  tax_qty + tn_tax_qty,
                  tax_sb_lim_qty + tn_tax_sb_lim_qty,
                  tax_delay_qty + tn_tax_delay_qty,
                  tax_delay_sb_qty + tn_tax_delay_sb_qty,
                  wtax_qty,
                  wtax_sb_lim_qty,
                  wtax_delay_qty,
                  wtax_delay_sb_qty,
                  'Huy duỵet xuat kho ' || stk_cd,
                  create_mn,
                  create_dtm,
                  create_trm,
                  work_mn,
                  work_dtm,
                  work_trm,
                  is_work_mn,
                  sysdate,
                  is_work_trm
              from ssb05h10
            where acnt_no = c1.acnt_no
              and stk_cd = c1.stk_cd
              and proc_dt = c1.proc_dt
              and id = c1.id_max;
    end loop;

  end if;

  /* End LTHN-248 */

 /* out parametres */
  ts_step := '16';

  os_end_yn := 'N';
  os_err_msg := 'OK';

 /*******************************/
 /* call evaluation for margin  */
 /*******************************/
/*huedt add k danh gia tai san*/
 /* vn.pdl_crd_loan_rt_proc_td
        (ts_wdate
        ,'2' -- stock
        ,is_acnt_no
    ,is_sub_no
        ,tn_cncl_trd_no
        ,is_work_mn
        ,is_work_trm
        ,o_cnt
       );

  vn.pxc_log_write('pss_outbil_aprv_cl_p','pdl_crd_loan_rt_proc_td ['|| o_cnt ||']');*/

 /* right proc  */

 vn.psr_rgt_std_past_proc(
            ts_std_inq_dt,
            ts_stk_cd,
            is_acnt_no,
            is_sub_no,
            tn_qty + tn_sb_lmt_qty,
            '1',
            is_work_mn,
            is_work_trm
            );


RETURN;

EXCEPTION
WHEN   ERR_RTN  THEN
raise_application_error(-20100, os_err_msg || ':[pss_outbil_aprv_cl_p ' || ts_step || '] ' || os_err_msg);
RETURN;

WHEN  NO_DATA_FOUND  THEN
raise_application_error(-20200, '[pss_outbil_aprv_cl_p ' || ts_step || '] ' || SQLERRM);
RETURN;

WHEN  OTHERS  THEN
raise_application_error(-20300, '[pss_outbil_aprv_cl_p ' || ts_step || '] ' || SQLERRM);
RETURN;

END pss_outbil_aprv_cl_p;
/

