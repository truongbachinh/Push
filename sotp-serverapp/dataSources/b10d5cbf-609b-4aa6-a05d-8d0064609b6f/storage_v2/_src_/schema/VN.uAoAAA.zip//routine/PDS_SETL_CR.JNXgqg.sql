create procedure    pds_setl_cr
(
  i_dt          in     varchar2,        --
  i_acnt_no     in     varchar2,        -- acnt_no
  i_sub_no      in     varchar2,        -- acnt_no
  i_work_mn     in     varchar2,        -- user id
  i_work_trm    in     varchar2,
  o_cnt         in out number
) AS

/*!
   \file     pds_setl_cr.sql
   \brief    previous settlement creation

   \section intro Program Information
        - Program Name              : create previous settle data
        - Service Name              : ds_04001_p1.pc
        - Related Client Program- Client Program ID : w_04001
        - Related Tables            : tso01m00, tso01m10, dsc01m00, aaa01m00
        - Dev. Date                 : 2007/11/08
        - Developer                 : Han.
        - Business Logic Desc.      : previous settle data creation
        - Latest Modification Date  : 2007/11/08

   \section history Program Modification History
    - 1.0       2007/11/08     Han.       New.
    - 2.0       2019/05/13     luonglv.   NHSV-955:.

   \section hardcoding Hard-Coding List
    - HC-1      2007/11/08     Han.    [??]

   \section info Additional Reference Comments
    - ???? ?????? ??

var o_cnt number;
exec pds_setl_cr('20090122','%','Test','Test',:o_cnt);
print o_cnt

*/

    t_setl_dt          varchar2(8) := null;
    t_setl_big_dt      varchar2(8) := null;
    t_dt               varchar2(8) := null;

    t_nmth_cnt         NUMBER      := 0;
    t_mth_amt          NUMBER      := 0;
    t_cmsn_rt          NUMBER      := 0;
    t_cmsn             NUMBER      := 0;
    t_adj_amt          NUMBER      := 0;
    t_setl_frct_seq_no NUMBER      := 0;
    t_setl_exist_cnt   NUMBER      := 0;

    t_setl_knd_tp      VARCHAR2(2) := NULL;
    t_cmsn_tp          VARCHAR2(2) := NULL;
    t_tax_clct_tp      VARCHAR2(1) := NULL;
    t_acnt_mng_bnh     varchar2(3) := null;
    t_agnc_brch        varchar2(2) := null;

    t_acnt_no          VARCHAR2(10);
    t_sub_no           VARCHAR2(2);
    t_corp_acnt_no     VARCHAR2(10);
    t_corp_sub_no      VARCHAR2(2);

    ts_cnt_tp          varchar2(3) := null;
    t_setl_bank_cd     VARCHAR2(4) := null;
    t_lnd_bank_cd      VARCHAR2(4) := null;

    ts_work_stat_min   VARCHAR2(1);
    ts_work_stat_max   VARCHAR2(1);

    t_pgm_id           varchar2(4) := '2000'; /* Batch control PGM_ID */
    t_msg              varchar2(10);
    t_err_msg          varchar2(500);

begin

    o_cnt    := 0;

    /*========================================================================*/
    /* Input Date CHECK                                                       */
    /*========================================================================*/
    if  vn.fxc_holi_ck(to_date(i_dt,'yyyymmdd')) !=  '0' then
        if  i_work_mn <> 'DAILY' then
            t_err_msg := vn.fxc_get_err_msg('V','2422');
            t_err_msg := t_err_msg||' Date = '||i_dt;
            raise_application_error(-20100,t_err_msg);
        else
            return;
        end if;
    end if;

    if  vn.vwdate  !=  i_dt then
        t_err_msg := vn.fxc_get_err_msg('V','2422');
        t_err_msg := t_err_msg||' Date = '||i_dt;
        raise_application_error(-20100,t_err_msg);
    end if;

    /*========================================================================*/
    /* Prededing job Check                                                    */
    /*========================================================================*/
    if  i_acnt_no = '%' and
        fxb_daily_stat_chk ('G','1','0000','0000','*') <> 'Y' then
        t_err_msg := vn.fxc_get_err_msg('V','2458');
        t_err_msg := t_err_msg||'[G1]'||i_dt;
        raise_application_error(-20100,t_err_msg);
    end if;

    if  vn.fts_get_market_tp_ck('DS', 'DS', '%') = 'N' then
        t_err_msg := vn.fxc_get_err_msg('V','3317');
        raise_application_error(-20100,t_err_msg);
    end if;

    /*========================================================================*/
    /* non-matching  Check                                                    */
    /*========================================================================*/
    t_nmth_cnt    := 0;
    begin
        select  count(*)
          into  t_nmth_cnt
          from  vn.tso01m00
         where  sell_buy_tp     =  '1'
           and  mkt_trd_tp     in ('02')
           and  bnh_cd         !=  '999'
           and  nvl(del_yn,'N') =  'N'
           and  nmth_qty        >  0
        ;
    exception
    when others then
        t_err_msg := vn.fxc_get_err_msg('V','2006');
        raise_application_error(-20012,t_err_msg||' cnt='||t_nmth_cnt);
    end;

    if  t_nmth_cnt  >  0  then
        t_err_msg := vn.fxc_get_err_msg('V','2486');
        raise_application_error(-20100,t_err_msg);
    end if;

    t_nmth_cnt    := 0;
    begin
        select  count(*)
          into  t_nmth_cnt
          from  vn.tso01m00
         where  bnh_cd          =  '999'
           and  nvl(del_yn,'N') =  'N'
           and  mth_qty         >  0
           and  accp_tp        <>  '1'
        ;
    exception
    when others then
        t_err_msg := vn.fxc_get_err_msg('V','2006');
        raise_application_error(-20012,t_err_msg||' cnt='||t_nmth_cnt);
    end;

    if  t_nmth_cnt  >  0  then
        t_err_msg := vn.fxc_get_err_msg('V','0119');
        raise_application_error(-20100,t_err_msg);
    end if;

    /*========================================================================*/
    /* Set Date                                                               */
    /*========================================================================*/
    t_dt      := i_dt;

    t_setl_dt := vn.fxc_vorderdt_g(to_date(t_dt,'yyyymmdd'), 2);
    /* 20150209 will apply bond is T1 */
    t_setl_big_dt := vn.fxc_vorderdt_g(to_date(t_dt,'yyyymmdd'), 1);
    /*t_dt      := vn.fxc_vorderdt_g(to_date(t_setl_dt,'yyyymmdd'), -3);*/


/*============================================================================*/
/* ( )                                                                        */
/*============================================================================*/
    /*========================================================================*/
    /* odd stock SETL_FRCT_SEQ_NO Create                                      */
    /*========================================================================*/
    for C1 in (
        select  t_dt                    stk_ord_dt
             ,  a.bnh_cd                --
             ,  a.ord_no                --
             ,  a.acnt_no               --
             ,  a.sub_no               --
             ,  a.stk_cd                --
             ,  a.ord_qty               --
             ,  a.ord_pri               --
             ,  a.ord_knd               --
             ,  a.sell_buy_tp           --
             ,  a.mkt_trd_tp            --
             ,  a.stk_ord_tp            --
             ,  a.crrt_cncl_tp          --
             ,  a.stk_tp                --
             ,  a.mdm_tp                --
             ,  vn.fds_get_cmsn_mdm_tp(a.mdm_tp) cmsn_mdm_tp
             ,  a.ord_time              --
             ,  a.ord_veto_cau          --
             ,  a.ord_accp_time         --
             ,  a.org_ord_no            --
             ,  a.first_org_ord_no      --
             ,  a.cncl_qty              --
             ,  a.crrt_qty              --
             ,  a.cncl_cnfm_qty         --
             ,  a.crrt_cnfm_qty         --
             ,  a.org_ord_pri           --
             ,  a.cash_prof_rt          --
             ,  a.frgn_tp               --
             ,  a.sms_yn                --
             ,  a.work_bnh              --
             ,  a.kfx_accp_no           --
             ,  a.sesn_tp               --
             ,  a.agnc_brch_cd          --
             ,  a.bank_cd               --
             ,  a.cdt_tp                --
             ,  a.lnd_dt                --
             ,  a.mrtg_dt               --
             ,  b.ord_mth_no            --
             ,  b.mth_qty               --
             ,  b.mth_pri               --
             ,  b.mth_time              --
             ,  a.force_sell_yn         --
             ,   nvl(b.rgt_tax_qty, 0)       rgt_tax_qty
             ,  nvl(b.rgt_tax_calc_yn, 'N') rgt_tax_calc_yn
             ,  case
                    when
                        b.rgt_tax_qty > 0 then 'N'
                    else
                        'Y'
                end                         rgt_tax_setl_yn
          from  vn.tso01m00 a, vn.tso01m10 b, vn.aaa01m00 c
         where  a.acnt_no        like  i_acnt_no
           and  a.sub_no         like  i_sub_no
           and  a.mkt_trd_tp     in ('02','04','06')
           and  a.mth_amt         >  0
           and  a.bnh_cd          =  b.bnh_cd
           and  a.ord_no          =  b.ord_no
           and  a.acnt_no         =  b.acnt_no
           and  a.sub_no          =  b.sub_no
           and  a.acnt_no         =  c.acnt_no
           and  a.sub_no          =  c.sub_no
           and  nvl(a.del_yn,'N') = 'N'
           and  nvl(b.del_yn,'N') = 'N'
         order  by  a.bnh_cd, a.acnt_no, a.sub_no, b.ord_no, b.mth_time
    ) loop
        o_cnt := o_cnt + 1;

        t_mth_amt := C1.mth_qty * C1.mth_pri;
        t_cmsn := 0;

        /*====================================================================*/
        /* customer account SETL_FRCT_SEQ_NO Create                           */
        /*====================================================================*/
        /* t_setl_frct_seq_no := fcz_auto_num('SS',t_dt);  */
        begin
            select  nvl(max(setl_frct_seq_no),0)+1
              into  t_setl_frct_seq_no
              from  vn.dsc01m00
             where  setl_dt  =  t_setl_dt
               and  acnt_no  =  C1.acnt_no
               and  sub_no   =  C1.sub_no
            ;
        exception
        when others then
            t_err_msg := vn.fxc_get_err_msg('V','9406');
            raise_application_error(-20011,t_err_msg||' ACNT_NO='||C1.acnt_no||'-'||C1.sub_no);
        end;

        begin
            select  vn.faa_get_acnt_grp_rt_tp(acnt_no,sub_no,'01',vn.vwdate)/*SL_01_New_version*/
                 ,  nvl(acnt_mng_bnh,'000')
                 ,  nvl(agnc_brch,'00')
              into  t_cmsn_tp
                 ,  t_acnt_mng_bnh
                 ,  t_agnc_brch
              from  vn.aaa01m00
             where  acnt_no  =  C1.acnt_no
               and  sub_no   =  C1.sub_no
            ;
        exception
        when no_data_found then
            t_err_msg := vn.fxc_get_err_msg('V','2006');
            raise_application_error(-20100,t_err_msg||' ACNT_NO='||C1.acnt_no||'-'||C1.sub_no);
        when others then
            t_err_msg := vn.fxc_get_err_msg('V','2006');
            raise_application_error(-20012,t_err_msg||' ACNT_NO='||C1.acnt_no||'-'||C1.sub_no);
        end;

        t_tax_clct_tp := '1';

        /* setl_knd_tp setting ( 01:Normal 02:Odd-lot 03:Big-lot 04:UPCOM ) */
        if  C1.stk_ord_tp in ('06') and C1.Mkt_Trd_Tp in ('02')then
            t_setl_knd_tp := '03';
        else
            if  C1.mkt_trd_tp in ('01','03','05','04','06') then
                t_setl_knd_tp := '01';
            elsif C1.mkt_trd_tp in ('02') then
                t_setl_knd_tp := '02';
            /*
            elsif C1.mkt_trd_tp in ('05') then
                t_setl_knd_tp := '04';
            */
            else
                t_err_msg := vn.fxc_get_err_msg('V','2439');
                raise_application_error(-20100,t_err_msg||' MKT_TRD_TP='||C1.mkt_trd_tp);
            end if;
        end if;

        if  C1.cdt_tp in ('00') then
            t_setl_bank_cd := C1.bank_cd;
            t_lnd_bank_cd  := null;
        else
            begin
                select  lnd_bank_cd
                     ,  setl_bank_cd
                  into  t_lnd_bank_cd
                     ,  t_setl_bank_cd
                  from  vn.dlm01m00
                 where  lnd_tp       =  C1.cdt_tp
                   and  acnt_no      =  C1.acnt_no
                   and  sub_no     =  C1.sub_no
                   and  lnd_dt       =  C1.lnd_dt
                   and  mth_dt       =  C1.mrtg_dt
                   and  lnd_bank_cd  =  C1.bank_cd
                   and  stk_cd       =  C1.stk_cd
                ;
            exception
            when others then
                t_err_msg := vn.fxc_get_err_msg('V','2006');
                raise_application_error(-20012,t_err_msg||' ACNT_NO='||C1.acnt_no||'-'||C1.sub_no);
            end;

            begin
                vn.paa_bank_yn_p( C1.acnt_no, C1.sub_no, ts_cnt_tp);
            exception
            when others then
                t_err_msg := vn.fxc_get_err_msg('V','9009');
                raise_application_error(-20100,t_err_msg||' Acnt_no - '||C1.acnt_no||'-'||C1.sub_no);
            end;

            if  C1.cdt_tp   =  '20'   then
                if  C1.bank_cd  =  '9999' then
                    /* Bank Acnt */
                    if  ts_cnt_tp  <>  'Y01'  then
                        t_setl_bank_cd :=  '9999';
                    end if;
                end if;
            elsif  C1.cdt_tp   =  '30'   then
                if  C1.bank_cd  =  '9999' then
                    /* Bank Acnt */
                    if  ts_cnt_tp  <>  'Y01'  then
                        t_setl_bank_cd :=  '9999';
                    end if;
                end if;
            end if;
        end if;

        insert into vn.dsc01m00 (
            SETL_DT        , ACNT_NO        , SUB_NO       , SETL_FRCT_SEQ_NO   ,
            BANK_CD        , ACNT_MNG_BNH   , AGNC_BRCH          ,
            AGNC_BRCH_CD   , SETL_KND_TP    , MKT_TRD_TP         ,
            SB_TP          , MDM_TP         , CMSN_MDM_TP        ,
            STK_TP         , STK_CD         ,
            SB_PRI         , SB_QTY         , SB_AMT             ,
            CMSN_TP        , TAX_CLCT_TP    , APY_CMSN_RT        ,
            SB_CMSN        , SB_TAX         ,
            ADJ_AMT        , ADJ_YN         ,
            MTH_DT         , DPO_SETL_DT    , CMSN_SETL_DT       ,
            TAX_SETL_DT    , STK_SETL_DT    ,
            BRCH_CD        , ORD_NO         ,
            ORG_ORD_NO     , FIRST_ORG_ORD_NO, KFX_ACCP_NO       ,
            DPO_SETL_YN    , STK_SETL_YN    , CMSN_SETL_YN       ,
            TAX_SETL_YN    , STK_SETL_FEE_YN, TRD_SEQ_NO     ,
            MRGN_SETL_YN   ,
            CDT_TP         , LND_BANK_CD    ,
            LND_DT         , MRTG_DT        , FORCE_SELL_YN  ,
            SB_RGT_TAX_QTY , SB_RGT_TAX_RT  , SB_RGT_TAX         ,  -- LTHN-247: right tax
            RGT_TAX_SETL_YN, RGT_TAX_SETL_DT, ORD_MTH_NO         ,
            WORK_MN        , WORK_DTM       , WORK_TRM
        )
        values (
            t_setl_dt      , C1.acnt_no     , C1.sub_no       , t_setl_frct_seq_no ,
            t_setl_bank_cd , t_acnt_mng_bnh , t_agnc_brch        ,
            C1.agnc_brch_cd, t_setl_knd_tp  , C1.mkt_trd_tp      ,
            C1.sell_buy_tp , C1.mdm_tp      , C1.cmsn_mdm_tp     ,
            C1.stk_tp      , C1.stk_cd      ,
            C1.mth_pri     , C1.mth_qty     , t_mth_amt          ,
            t_cmsn_tp      , t_tax_clct_tp  , t_cmsn_rt          ,
            t_cmsn         , 0              ,
            t_adj_amt      , 'N'            ,
            C1.stk_ord_dt  , C1.stk_ord_dt  , C1.stk_ord_dt      ,
            C1.stk_ord_dt  , C1.stk_ord_dt  ,
            C1.bnh_cd      , C1.ord_no      ,
            C1.org_ord_no  , C1.first_org_ord_no, C1.kfx_accp_no ,
            'N'            , 'N'            , 'N'                ,
            'N'            , 'N'            , 0              ,
            'Y'            ,
            C1.cdt_tp      , t_lnd_bank_cd  ,
            C1.lnd_dt      , C1.mrtg_dt     , C1.force_sell_yn   ,
            C1.rgt_tax_qty , 0              , 0                  ,  -- LTHN-247: right tax
            'Y'            , C1.stk_ord_dt  , C1.ord_mth_no      ,
            i_work_mn      , sysdate        , i_work_trm
        );

        /*====================================================================*/
        /* company account SETL_FRCT_SEQ_NO Create                            */
        /*====================================================================*/
        if C1.Mkt_Trd_Tp in ('02') then
            select acnt_no, sub_no
              into t_corp_acnt_no, t_corp_sub_no
              from vn.aaa01m00
             where acnt_tp = 'P'
               and acnt_stat = '1'
               and sub_no  = '00';

            /*====================================================================*/
            /* Bank Account Check                                                 */
            /*====================================================================*/
            begin
                vn.paa_bank_yn_p(t_corp_acnt_no, t_corp_sub_no, ts_cnt_tp);
            exception
            when others then
                t_err_msg := vn.fxc_get_err_msg('V','9009');
                raise_application_error(-20100,t_err_msg||' Acnt_no - '||t_corp_acnt_no||'-'||t_corp_sub_no);
            end;

            begin
                select  nvl(max(setl_frct_seq_no),0)+1
                  into  t_setl_frct_seq_no
                  from  vn.dsc01m00
                 where  setl_dt  =  t_setl_dt
                   and  acnt_no  =  t_corp_acnt_no
                   AND  sub_no   =  '00'
                ;
            exception
            when others then
                t_err_msg := vn.fxc_get_err_msg('V','9406');
                raise_application_error(-20013,t_err_msg||' ACNT_NO='||t_corp_acnt_no||'-'||t_corp_sub_no);
            end;

            begin
                select  vn.faa_get_acnt_grp_rt_tp(acnt_no,sub_no,'01',vn.vwdate)/*SL_01_New_version*/
                     ,  nvl(acnt_mng_bnh,'000')
                     ,  nvl(agnc_brch,'00')
                  into  t_cmsn_tp
                     ,  t_acnt_mng_bnh
                     ,  t_agnc_brch
                  from  vn.aaa01m00
                 where  acnt_no  =  t_corp_acnt_no
                   AND  sub_no   =  t_corp_sub_no
                ;
            exception
            when no_data_found then
                t_err_msg := vn.fxc_get_err_msg('V','2006');
                raise_application_error(-20100,t_err_msg||' ACNT_NO='||t_corp_acnt_no||'-'||t_corp_sub_no);
            when others then
                t_err_msg := vn.fxc_get_err_msg('V','2006');
                raise_application_error(-20014,t_err_msg||' ACNT_NO='||t_corp_acnt_no||'-'||t_corp_sub_no);
            end;

            t_tax_clct_tp := '1';

            if  ts_cnt_tp  =  'Y01'  then  /* Bank Acnt */
                t_setl_bank_cd := C1.bank_cd;
            else
                t_setl_bank_cd := '9999';
            end if;


            insert into vn.dsc01m00 (
                SETL_DT        , ACNT_NO        , SUB_NO       , SETL_FRCT_SEQ_NO   ,
                BANK_CD        , ACNT_MNG_BNH   , AGNC_BRCH          ,
                AGNC_BRCH_CD   , SETL_KND_TP    , MKT_TRD_TP         ,
                SB_TP          , MDM_TP         , CMSN_MDM_TP        ,
                STK_TP         , STK_CD         ,
                SB_PRI         , SB_QTY         , SB_AMT             ,
                CMSN_TP        , TAX_CLCT_TP    , APY_CMSN_RT        ,
                SB_CMSN        , SB_TAX         ,
                ADJ_AMT        , ADJ_YN         ,
                MTH_DT         , DPO_SETL_DT    , CMSN_SETL_DT       ,
                TAX_SETL_DT    , STK_SETL_DT    ,
                BRCH_CD        , ORD_NO         ,
                ORG_ORD_NO     , FIRST_ORG_ORD_NO, KFX_ACCP_NO       ,
                DPO_SETL_YN    , STK_SETL_YN    , CMSN_SETL_YN       ,
                TAX_SETL_YN    , STK_SETL_FEE_YN, TRD_SEQ_NO     ,
                MRGN_SETL_YN   ,
                CDT_TP         , LND_BANK_CD    ,
                LND_DT         , MRTG_DT        , FORCE_SELL_YN      ,
                SB_RGT_TAX_QTY , SB_RGT_TAX_RT  , SB_RGT_TAX         ,  -- LTHN-247: right tax
                RGT_TAX_SETL_YN, RGT_TAX_SETL_DT, ORD_MTH_NO         ,
                WORK_MN        , WORK_DTM       , WORK_TRM
            )
            values (
                t_setl_dt      , t_corp_acnt_no , t_corp_sub_no     , t_setl_frct_seq_no ,
                t_setl_bank_cd , t_acnt_mng_bnh , t_agnc_brch        ,
                '000'          , t_setl_knd_tp  , C1.mkt_trd_tp      ,
                decode(C1.sell_buy_tp,'1','2','1'),
                                 C1.mdm_tp      , C1.cmsn_mdm_tp     ,
                C1.stk_tp      , C1.stk_cd      ,
                C1.mth_pri     , C1.mth_qty     , t_mth_amt          ,
                t_cmsn_tp      , t_tax_clct_tp  , t_cmsn_rt          ,
                t_cmsn         , 0              ,
                t_adj_amt      , 'N'            ,
                C1.stk_ord_dt  , C1.stk_ord_dt  , C1.stk_ord_dt      ,
                C1.stk_ord_dt  , C1.stk_ord_dt  ,
                C1.bnh_cd      , C1.ord_no      ,
                C1.org_ord_no  , C1.first_org_ord_no, C1.kfx_accp_no ,
                'N'            , 'N'            , 'N'                ,
                'N'            , 'N'            , 0              ,
                'Y',
                C1.cdt_tp      , t_lnd_bank_cd  ,
                C1.lnd_dt      , C1.mrtg_dt     , C1.force_sell_yn   ,
                C1.rgt_tax_qty , 0              , 0                  ,  -- LTHN-247: right tax
                'Y'            , C1.stk_ord_dt  , C1.ord_mth_no      ,
                i_work_mn      , sysdate        , i_work_trm
            );
        end if;
    end loop;

    /*========================================================================*/
    /* stock SETL_FRCT_SEQ_NO Create                                          */
    /*========================================================================*/
    for C2 in (
        select  t_dt                    stk_ord_dt
             ,  a.bnh_cd                --
             ,  a.ord_no                --
             ,  a.acnt_no               --
             ,  a.SUB_no               --
             ,  a.stk_cd                --
             ,  a.ord_qty               --
             ,  a.ord_pri               --
             ,  a.ord_knd               --
             ,  a.sell_buy_tp           --
             ,  a.mkt_trd_tp            --
             ,  a.stk_ord_tp            --
             ,  a.crrt_cncl_tp          --
             ,  a.stk_tp                --
             ,  a.mdm_tp                --
             ,  vn.fds_get_cmsn_mdm_tp(a.mdm_tp) cmsn_mdm_tp
             ,  a.ord_time              --
             ,  a.ord_veto_cau          --
             ,  a.ord_accp_time         --
             ,  a.org_ord_no            --
             ,  a.first_org_ord_no      --
             ,  a.cncl_qty              --
             ,  a.crrt_qty              --
             ,  a.cncl_cnfm_qty         --
             ,  a.crrt_cnfm_qty         --
             ,  a.org_ord_pri           --
             ,  a.cash_prof_rt          --
             ,  a.frgn_tp               --
             ,  a.sms_yn                --
             ,  a.work_bnh              --
             ,  a.kfx_accp_no           --
             ,  a.sesn_tp               --
             ,  a.agnc_brch_cd          --
             ,  a.bank_cd               --
             ,  a.cdt_tp                --
             ,  a.lnd_dt                --
             ,  a.mrtg_dt               --
             ,  b.ord_mth_no           --
             ,  b.mth_qty               --
             ,  b.mth_pri               --
             ,  b.mth_time              --
             ,  a.force_sell_yn         --
             ,  nvl(b.rgt_tax_qty, 0) rgt_tax_qty
             ,  nvl(b.rgt_tax_calc_yn, 'N') rgt_tax_calc_yn
             ,  case
                    when
                        b.rgt_tax_qty > 0 then 'N'
                    else
                        'Y'
                end rgt_tax_setl_yn
          from  vn.tso01m00 a, vn.tso01m10 b, vn.aaa01m00 c
         where  a.acnt_no      like  i_acnt_no
           and  a.sub_no     like  i_sub_no
           and  a.mkt_trd_tp     in ('01','03','05')
           and  a.mth_amt         >  0
           and  a.bnh_cd          =  b.bnh_cd
           and  a.ord_no          =  b.ord_no
           and  a.acnt_no         =  b.acnt_no
           and  a.sub_no          =  b.sub_no
           and  a.acnt_no         =  c.acnt_no
           and  a.sub_no          =  c.sub_no
           and  nvl(a.del_yn,'N') = 'N'
           and  nvl(b.del_yn,'N') = 'N'
         order  by  a.bnh_cd, a.acnt_no, a.sub_no, b.ord_no, b.mth_time
    ) loop
        o_cnt := o_cnt + 1;

        t_mth_amt := C2.mth_qty * C2.mth_pri;
        t_cmsn := 0;

        /*====================================================================*/
        /* SETL_FRCT_SEQ_NO Create                                            */
        /*====================================================================*/
        /* t_setl_frct_seq_no := fcz_auto_num('SS',t_dt);  */
        if  C2.stk_tp  in  ('20') then
            begin
                select  nvl(max(setl_frct_seq_no),0)+1
                  into  t_setl_frct_seq_no
                  from  vn.dsc01m00
                 where  setl_dt  =  t_setl_big_dt
                   and  acnt_no  =  C2.acnt_no
                   and  sub_no   =  C2.sub_no
                ;
            exception when others then
                t_err_msg := vn.fxc_get_err_msg('V','9406');
                raise_application_error(-20021,t_err_msg||' ACNT_NO='||C2.acnt_no||'-'||C2.sub_no);
            end;
        else
            begin
                select  nvl(max(setl_frct_seq_no),0)+1
                  into  t_setl_frct_seq_no
                  from  vn.dsc01m00
                 where  setl_dt  =  t_setl_dt
                   and  acnt_no  =  C2.acnt_no
                   and  sub_no   =  C2.sub_no
                ;
            exception when others then
                t_err_msg := vn.fxc_get_err_msg('V','9406');
                raise_application_error(-20021,t_err_msg||' ACNT_NO='||C2.acnt_no||'-'||C2.sub_no);
            end;
        end if;


        begin
            select  vn.faa_get_acnt_grp_rt_tp(acnt_no,sub_no,'01',vn.vwdate) /*SL_01_New_version*/
                 ,  nvl(acnt_mng_bnh,'000')
                 ,  nvl(agnc_brch,'00')
              into  t_cmsn_tp
                 ,  t_acnt_mng_bnh
                 ,  t_agnc_brch
              from  vn.aaa01m00
             where  acnt_no  =  C2.acnt_no
               and  sub_no   =  C2.sub_no
            ;
        exception
        when no_data_found then
            t_err_msg := vn.fxc_get_err_msg('V','2006');
            raise_application_error(-20100,t_err_msg||' ACNT_NO='||C2.acnt_no||'-'||C2.sub_no);
        when others then
            t_err_msg := vn.fxc_get_err_msg('V','2006');
            raise_application_error(-20022,t_err_msg||' ACNT_NO='||C2.acnt_no||'-'||C2.sub_no);
        end;

        t_tax_clct_tp := '1';

        /* setl_knd_tp setting ( 01:Normal 02:Odd-lot 03:Big-lot 04:UPCOM ) */
        if  C2.stk_ord_tp in ('06') then
            t_setl_knd_tp := '03';
        else
            if  C2.mkt_trd_tp in ('01','03','05') then
                t_setl_knd_tp := '01';
            elsif C2.mkt_trd_tp in ('02','04','06') then
                t_setl_knd_tp := '02';
            /*
            elsif C2.mkt_trd_tp in ('05') then
                t_setl_knd_tp := '04';
            */
            else
                t_err_msg := vn.fxc_get_err_msg('V','2439');
                raise_application_error(-20100,t_err_msg||' MKT_TRD_TP='||C2.mkt_trd_tp);
            end if;
        end if;

        if  C2.cdt_tp in ('00') then
            t_setl_bank_cd := C2.bank_cd;
            t_lnd_bank_cd  := null;
        else
            begin
                select  lnd_bank_cd
                     ,  setl_bank_cd
                  into  t_lnd_bank_cd
                     ,  t_setl_bank_cd
                  from  vn.dlm01m00
                 where  lnd_tp       =  C2.cdt_tp
                   and  acnt_no      =  C2.acnt_no
                   and  sub_no      =  C2.sub_no
                   and  lnd_dt       =  C2.lnd_dt
                   and  mth_dt       =  C2.mrtg_dt
                   and  lnd_bank_cd  =  C2.bank_cd
                   and  stk_cd       =  C2.stk_cd
                ;
            exception
            when others then
                t_err_msg := vn.fxc_get_err_msg('V','2006');
                raise_application_error(-20012,t_err_msg||' ACNT_NO='||C2.acnt_no||'-'||C2.sub_no);
            end;

            begin
                vn.paa_bank_yn_p( C2.acnt_no, C2.sub_no, ts_cnt_tp);
            exception
            when others then
                t_err_msg := vn.fxc_get_err_msg('V','9009');
                raise_application_error(-20100,t_err_msg||' Acnt_no - '||C2.acnt_no||'-'||C2.sub_no);
            end;

            if  C2.cdt_tp   =  '20'   then
                if  C2.bank_cd  =  '9999' then
                    /* Bank Acnt */
                    if  ts_cnt_tp  <>  'Y01'  then
                        t_setl_bank_cd :=  '9999';
                    end if;
                end if;
            elsif  C2.cdt_tp   =  '30'   then
                if  C2.bank_cd  =  '9999' then
                    /* Bank Acnt */
                    if  ts_cnt_tp  <>  'Y01'  then
                        t_setl_bank_cd :=  '9999';
                    end if;
                end if;
            end if;
        end if;

        /* bond settle-date : T+1 */
        if  C2.stk_tp  in  ('20')  then
            insert into vn.dsc01m00 (
                SETL_DT        , ACNT_NO        , SUB_NO       , SETL_FRCT_SEQ_NO   ,
                BANK_CD        , ACNT_MNG_BNH   , AGNC_BRCH          ,
                AGNC_BRCH_CD   , SETL_KND_TP    , MKT_TRD_TP         ,
                SB_TP          , MDM_TP         , CMSN_MDM_TP        ,
                STK_TP         , STK_CD         ,
                SB_PRI         , SB_QTY         , SB_AMT             ,
                CMSN_TP        , TAX_CLCT_TP    , APY_CMSN_RT        ,
                SB_CMSN        , SB_TAX         ,
                ADJ_AMT        , ADJ_YN         ,
                MTH_DT         , DPO_SETL_DT    , CMSN_SETL_DT       ,
                TAX_SETL_DT    , STK_SETL_DT    ,
                BRCH_CD        , ORD_NO         ,
                ORG_ORD_NO     , FIRST_ORG_ORD_NO, KFX_ACCP_NO       ,
                DPO_SETL_YN    , STK_SETL_YN    , CMSN_SETL_YN       ,
                TAX_SETL_YN    , STK_SETL_FEE_YN, TRD_SEQ_NO     ,
                MRGN_SETL_YN   ,
                CDT_TP         , LND_BANK_CD    ,
                LND_DT         , MRTG_DT        , FORCE_SELL_YN      ,
                SB_RGT_TAX_QTY , SB_RGT_TAX_RT  , SB_RGT_TAX         ,  -- LTHN-247: right tax
                RGT_TAX_SETL_YN, RGT_TAX_SETL_DT, ORD_MTH_NO         ,
                WORK_MN        , WORK_DTM       , WORK_TRM
            )
            values (
                t_setl_big_dt  , C2.acnt_no     , C2.sub_no       , t_setl_frct_seq_no ,
                t_setl_bank_cd , t_acnt_mng_bnh , t_agnc_brch        ,
                C2.agnc_brch_cd, t_setl_knd_tp  , C2.mkt_trd_tp      ,
                C2.sell_buy_tp , C2.mdm_tp      , C2.cmsn_mdm_tp     ,
                C2.stk_tp      , C2.stk_cd      ,
                C2.mth_pri     , C2.mth_qty     , t_mth_amt          ,
                t_cmsn_tp      , t_tax_clct_tp  , t_cmsn_rt          ,
                t_cmsn         , 0              ,
                t_adj_amt      , 'N'            ,
                C2.stk_ord_dt  , C2.stk_ord_dt  , C2.stk_ord_dt      ,
                C2.stk_ord_dt  , C2.stk_ord_dt  ,
                C2.bnh_cd      , C2.ord_no      ,
                C2.org_ord_no  , C2.first_org_ord_no, C2.kfx_accp_no ,
                'N'            , 'N'            , 'N'                ,
                'N'            , 'N'            , 0              ,
                DECODE(C2.sell_buy_tp,'1','N','Y'),
                C2.cdt_tp      , t_lnd_bank_cd  ,
                C2.lnd_dt      , C2.mrtg_dt     , C2.force_sell_yn   ,
                C2.rgt_tax_qty , 0              , 0                  ,  -- LTHN-247: right tax
                'Y'            , C2.stk_ord_dt  , C2.ord_mth_no      ,
                i_work_mn      , sysdate        , i_work_trm
            );
        else
            insert into vn.dsc01m00 (
                SETL_DT        , ACNT_NO        , SUB_NO       , SETL_FRCT_SEQ_NO   ,
                BANK_CD        , ACNT_MNG_BNH   , AGNC_BRCH          ,
                AGNC_BRCH_CD   , SETL_KND_TP    , MKT_TRD_TP         ,
                SB_TP          , MDM_TP         , CMSN_MDM_TP        ,
                STK_TP         , STK_CD         ,
                SB_PRI         , SB_QTY         , SB_AMT             ,
                CMSN_TP        , TAX_CLCT_TP    , APY_CMSN_RT        ,
                SB_CMSN        , SB_TAX         ,
                ADJ_AMT        , ADJ_YN         ,
                MTH_DT         , DPO_SETL_DT    , CMSN_SETL_DT       ,
                TAX_SETL_DT    , STK_SETL_DT    ,
                BRCH_CD        , ORD_NO         ,
                ORG_ORD_NO     , FIRST_ORG_ORD_NO, KFX_ACCP_NO       ,
                DPO_SETL_YN    , STK_SETL_YN    , CMSN_SETL_YN       ,
                TAX_SETL_YN    , STK_SETL_FEE_YN, TRD_SEQ_NO     ,
                MRGN_SETL_YN   ,
                CDT_TP         , LND_BANK_CD    ,
                LND_DT         , MRTG_DT        , FORCE_SELL_YN  ,
                SB_RGT_TAX_QTY , SB_RGT_TAX_RT  , SB_RGT_TAX         ,  -- LTHN-247: right tax
                RGT_TAX_SETL_YN, RGT_TAX_SETL_DT, ORD_MTH_NO         ,
                WORK_MN        , WORK_DTM       , WORK_TRM
            )
            values (
                t_setl_dt      , C2.acnt_no     , C2.sub_no       , t_setl_frct_seq_no ,
                t_setl_bank_cd , t_acnt_mng_bnh , t_agnc_brch        ,
                C2.agnc_brch_cd, t_setl_knd_tp  , C2.mkt_trd_tp      ,
                C2.sell_buy_tp , C2.mdm_tp      , C2.cmsn_mdm_tp     ,
                C2.stk_tp      , C2.stk_cd      ,
                C2.mth_pri     , C2.mth_qty     , t_mth_amt          ,
                t_cmsn_tp      , t_tax_clct_tp  , t_cmsn_rt          ,
                t_cmsn         , 0              ,
                t_adj_amt      , 'N'            ,
                C2.stk_ord_dt  , C2.stk_ord_dt  , C2.stk_ord_dt      ,
                C2.stk_ord_dt  , C2.stk_ord_dt  ,
                C2.bnh_cd      , C2.ord_no      ,
                C2.org_ord_no  , C2.first_org_ord_no, C2.kfx_accp_no ,
                'N'            , 'N'            , 'N'                ,
                'N'            , 'N'            , 0              ,
                DECODE(C2.sell_buy_tp,'1','N','Y'),
                C2.cdt_tp      , t_lnd_bank_cd  ,
                C2.lnd_dt      , C2.mrtg_dt     , C2.force_sell_yn  ,
                C2.rgt_tax_qty , 0              , 0                  ,  -- LTHN-247: right tax
                'Y'            , C2.stk_ord_dt  , C2.ord_mth_no      ,
                i_work_mn      , sysdate        , i_work_trm
            );
        end if;
    end loop;

end pds_setl_cr;
/

