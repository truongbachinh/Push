create FUNCTION    fdl_get_all_stk_sum_lnd_limit(i_acnt_no VARCHAR2,
                                                        i_sub_no  VARCHAR2,
                                                        i_stk_cd  VARCHAR2)
  RETURN NUMBER AS
  /*!
     \file     fdl_get_all_stk_sum_lnd_limit.sql
     \brief    fdl_get_all_stk_sum_lnd_limit
     \section intro Program Information
          - Program Name              :
          - Service Name              :
          - Related Client Program- Client Program ID :
          - Related Tables            : dlm51m00, dlm90m00, dlm00m01
          - Dev. Date                 : 2021/08/05
          - Developer                 : TienLH.
          - Business Logic Desc.      : Ham lay tong han muc con lai cua cac ma chung khoan dang nam giu
          - Latest Modification Date  : 2021/08/26
          - review
   */

  t_sec_cd                  VARCHAR2(3);
  t_acnt_grp_no             VARCHAR2(5);
  t_basket_cd               VARCHAR2(5);

  t_acnt_stk_bsk_lnd_limit  NUMBER := 0;
  t_all_stk_sum_lnd_limit       NUMBER := 0;
  t_ssc_lnd_limit_amt       NUMBER := 0;

  t_cnt_src_sec number := 0;
  t_vwdate varchar2(8);

BEGIN

    t_sec_cd  := vn.fxc_sec_cd('R');
    t_vwdate  := vn.vwdate;

    FOR c1 IN
        ( SELECT acnt_no, sub_no, stk_cd
        FROM vn.acnt_sbst_own
        WHERE acnt_no like trim(i_acnt_no)
        AND sub_no like trim(i_sub_no)
        AND stk_cd like trim(i_stk_cd)
        AND (able_qty > 0 or buy_mth_qty > 0 or buy_nmth_qty > 0)
        )
    LOOP

        t_acnt_grp_no := vn.faa_acnt_get_grp_no(c1.acnt_no,
                                                c1.sub_no,
                                                '2',
                                                t_vwdate);
        t_basket_cd := vn.faa_acnt_get_basket_cd(c1.stk_cd,c1.acnt_no,c1.sub_no,t_acnt_grp_no,t_vwdate);

        -- Tinh han muc con lai cua ma CK theo ro
        t_acnt_stk_bsk_lnd_limit := vn.fdl_get_acnt_stk_bsk_lnd_limit(c1.acnt_no,
                                                                        c1.sub_no,
                                                                        t_basket_cd,
                                                                        c1.stk_cd);-- RLL(B,S)

        /*
        voi tai khoan co su dung nguon '70' thi han muc = min (t_acnt_stk_bsk_lnd_limit,t_ssc_lnd_limit_amt)
        */
        --B1. Xac dinh tai khoan co su dung nguon cty ('70) hay khong?
            Begin
                SELECT count(1)
                INTO t_cnt_src_sec
                FROM vn.dlm90m00 a,
                    vn.dlm00m01 b,
                    vn.dlm00m01 c
                WHERE a.grp_acnt_no = t_acnt_grp_no
                AND a.active_stat = 'Y'
                AND a.apy_dt <= t_vwdate
                AND b.item_tp = '02' /* San pham, tuong ung 1 nguon*/
                AND b.item_cd = a.prd_no
                AND b.active_stat = 'Y'
                AND c.item_tp = '03' /* nguon*/
                AND c.item_cd = b.src_no
                AND c.active_stat = 'Y'
                AND c.lnd_tp = '70'
                AND EXISTS(  SELECT 1
                                FROM dlm20m00 d20
                                WHERE d20.src_no = c.item_cd
                                AND t_vwdate BETWEEN d20.apy_dt AND d20.expr_dt
                                AND d20.active_stat = 'Y'
                            );
            Exception when others then
                t_cnt_src_sec := 0;
            end ;

        --B2. Kiem tra
        if t_cnt_src_sec >0 then -- co dung nguon cty ('70') thi kiem tra han muc toan cty
            t_ssc_lnd_limit_amt := vn.fdl_get_ssc_lnd_limit_amt(c1.stk_cd);
            t_all_stk_sum_lnd_limit := t_all_stk_sum_lnd_limit + least (t_acnt_stk_bsk_lnd_limit,t_ssc_lnd_limit_amt);
        else
            -- Tinh han muc con lai cua ma CK
            t_all_stk_sum_lnd_limit := t_all_stk_sum_lnd_limit + t_acnt_stk_bsk_lnd_limit;
        end if;

        vn.pxc_log_write('fdl_get_all_stk_sum_lnd_limit',
                            ' i_acnt_no = ' || i_acnt_no || ' - i_sub_no = ' || i_sub_no || ' - stk_cd = ' || c1.stk_cd ||
                            ' - i_stk_cd = '|| i_stk_cd ||' - t_acnt_grp_no = ' || t_acnt_grp_no || ' - t_basket_cd = ' ||
                            t_basket_cd  );
    END LOOP;

    vn.pxc_log_write('fdl_get_all_stk_sum_lnd_limit', ' t_all_stk_sum_lnd_limit = ' || t_all_stk_sum_lnd_limit );

    RETURN t_all_stk_sum_lnd_limit;

END fdl_get_all_stk_sum_lnd_limit;
/

