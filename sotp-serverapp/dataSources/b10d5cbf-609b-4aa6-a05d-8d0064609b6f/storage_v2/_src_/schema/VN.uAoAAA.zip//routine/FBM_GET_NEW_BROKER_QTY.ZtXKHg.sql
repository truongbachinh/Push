create function    fbm_get_new_broker_qty(
    i_emp_no        varchar2,       -- Ma nhan vien
    i_st_dt         varchar2,       -- Tra cuu tu ngay
    i_ed_dt         varchar2,       -- Tra cuu den ngay
    i_biz_emp_tp    varchar2        -- Phan loai nhan vien: '%': Tat ca     1: Nghiep vu    2: Moi gioi     3: CTV  23: Nghiep vu + Moi gioi
)
return number
/*
    select vn.fbm_get_new_broker_qty(
        'tyhpt01',      -- i_emp_no        varchar2,       -- Ma nhan vien
        '20190101',     -- i_st_dt         varchar2,       -- Tra cuu tu ngay
        vwdate,         -- i_ed_dt         varchar2,       -- Tra cuu den ngay
        '23'            -- i_biz_emp_tp    varchar2        -- Phan loai nhan vien
    ) a
    from dual;
*/

as
    t_st_emp_cnt    number;
    t_ed_emp_cnt    number;
    t_new_emp_cnt   number;

    o_ret           number;
begin
    select count(hie.sub_no)   st_emp_cnt
    into t_st_emp_cnt
    from vn.xca01m01 x1
    inner join table (vn.fbm_get_sub_item_hier(
                    '1',            -- i_tp        
                    i_emp_no,       -- i_mng_emp_no
                    i_st_dt         -- i_dt        
                    )
                ) hie
    on x1.emp_no = hie.sub_no
    where
        (i_biz_emp_tp = '23' 
        and x1.biz_emp_tp in ('2', '3')
        )
    or  (i_biz_emp_tp != '23' 
        and x1.biz_emp_tp like i_biz_emp_tp
        )
    ;

    select count(hie.sub_no)   st_emp_cnt
    into t_ed_emp_cnt
    from vn.xca01m01 x1
    inner join table (vn.fbm_get_sub_item_hier(
                    '1',            -- i_tp        
                    i_emp_no,       -- i_mng_emp_no
                    i_ed_dt         -- i_dt        
                    )
                ) hie
    on x1.emp_no = hie.sub_no
    where
        (i_biz_emp_tp = '23' 
        and x1.biz_emp_tp in ('2', '3')
        )
    or  (i_biz_emp_tp != '23' 
        and x1.biz_emp_tp like i_biz_emp_tp
        )
    ;

    select t_ed_emp_cnt - t_st_emp_cnt
    into t_new_emp_cnt
    from dual;

    o_ret := t_new_emp_cnt;

    return o_ret;

end;
/

