create FUNCTION faa_reply_tp_g(
  i_acnt_no      IN  VARCHAR,
  i_sub_no      IN  VARCHAR
  ) RETURN VARCHAR2   AS
BEGIN
 FOR c1 IN (
     SELECT nvl(reply_tp,'Y') reply_tp
     FROM   vn.aaa01m00
     WHERE  acnt_no  = i_acnt_no
	 AND    sub_no  = i_sub_no
 ) LOOP
		RETURN c1.reply_tp;
 END LOOP;
 RETURN ' ';
END;
/

