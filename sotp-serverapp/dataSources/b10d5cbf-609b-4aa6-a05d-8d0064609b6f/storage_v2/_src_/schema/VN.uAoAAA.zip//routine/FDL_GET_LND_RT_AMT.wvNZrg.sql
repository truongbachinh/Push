create function fdl_get_lnd_rt_amt
(
    i_acnt_no        in   varchar2,        --
    i_sub_no         in   varchar2,        --
    i_lnd_bank_cd    in   varchar2,        --
	i_lnd_apy_val_tp in   varchar2,        --
    i_lnd_dt         in   varchar2         --
)
    return  number
as

	/* -------------------------------------------------------------------------
	   * i_lnd_apy_val_tp
	     - 01:lnd_int ratio
	     - 02:lnd_int ratio for min duration
	     - 03:min lnd_int amt
	     - 11:lnd_fee ratio
	     - 02:lnd_fee ratio for min duration
	     - 03:min lnd_fee amt
	------------------------------------------------------------------------- */
	o_lnd_apy_val		number  := 0;
    t_err_txt			varchar2(80); -- error text buffer
    t_err_msg           VARCHAR2(500);

begin


/*============================================================================*/
/* generl commission return                                                   */
/*============================================================================*/
	for c1 in (
		select lnd_apy_val
	      from vn.dlm12m10
	     where lnd_tp         = '20'
	       and lnd_apy_val_tp = i_lnd_apy_val_tp
	       and apy_dt         = (select max(apy_dt)
	                               from vn.dlm12m10
	                              where lnd_tp          = '20'
	                                and lnd_apy_val_tp  = i_lnd_apy_val_tp
	                                and apy_dt         <= i_lnd_dt)
	) loop
		return c1.lnd_apy_val;
	end loop;

	-- No data found error
	t_err_msg := vn.fxc_get_err_msg('V','2016')||'[DLM12M10]';
	raise_application_error(-20100,t_err_msg);

end fdl_get_lnd_rt_amt;
/

