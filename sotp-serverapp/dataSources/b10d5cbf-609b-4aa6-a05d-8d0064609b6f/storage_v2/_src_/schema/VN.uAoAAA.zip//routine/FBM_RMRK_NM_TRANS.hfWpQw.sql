create function fbm_rmrk_nm_trans
(
    i_rmrk_cd   in   varchar2
)
    return          varchar2
as
    o_rmrk_CD_new    varchar2(100) ;
   -- o_use_yn        varchar2(1)   ;
    t_err_txt       varchar2(100) ; -- error text buffer
   -- o_check_rmrk_cd NUMBER ;
    --o_check_y_rmk   VARCHAR2(1);

begin

/*============================================================================*/
/* º¯¼ö ÃÊ±âÈ­                                                                */
/*============================================================================*/
    o_rmrk_CD_new  :=  NULL;
    --o_use_yn  :=  NULL;
   -- o_check_rmrk_cd := 0;
    --o_check_y_rmk := 'N';

/*============================================================================*/
/* »ç¿ø¸í Á¶È¸                                                                */
/*============================================================================*/

    --begin
    select RMRK_CD_NEW
    into o_rmrk_CD_new
    from  BMI03C00
    where rmrk_Cd = i_rmrk_cd;
    return o_rmrk_CD_new;
     exception
        when  NO_DATA_FOUND  then
      return  ' ';
        when  OTHERS         then
            t_err_txt  :=  '['||to_char(sqlcode)||']';
            raise_application_error (-20100, t_err_txt||'*'||i_rmrk_cd );



end fbm_rmrk_nm_trans;
/

