create function    fdl_get_loan_amt_t1(
  i_acnt_no in varchar2,
  i_sub_no  in varchar2,
  i_bank_cd in varchar2
  ) return number   as

      /*
    ==> so tien no T1 = So tien chua thanh toan lenh mua ngay T1 - so tien kha dung (Tien mat - tien rut cho phe duyet - tien phong toa vi ly do khac - tien ung truoc (neu co ut tu dong )
    */

    t_loan_sum_amt_t1_sum       number := 0 ;
    t_notyet_pia_loan_amt_sum   number := 0 ;
    t_dpo                       number := 0 ;
    t_dpo_block                 number := 0 ;
    t_outq_dpo_bk               number := 0 ;
    t_temp                      number := 0 ;
    o_loan_amt_t1               number := 0 ;

begin

    BEGIN
        SELECT  sum(adj_amt)
           INTO  t_loan_sum_amt_t1_sum
           FROM  vn.dsc01m00
           WHERE  acnt_no = i_acnt_no
            AND sub_no = i_sub_no
            AND sb_tp ='2'
            AND dpo_setl_yn ='N'
            AND mth_dt = vn.vwdate - 1;
    EXCEPTION when others then
        t_loan_sum_amt_t1_sum :=0;
    End;

    vn.pcw_outamt_psbamt_q(
                            i_acnt_no, i_sub_no, nvl(i_bank_cd,'9999')  ,
                            t_dpo  , t_dpo_block     , t_outq_dpo_bk , 
                            t_temp , t_temp , t_temp , t_temp ,
                            t_temp , t_temp , t_temp , t_temp ,
                            t_temp , t_temp , t_temp , t_temp ,
                            t_temp , t_temp , t_temp , t_temp ,
                            t_temp , t_temp , t_temp , t_temp
                            ); 
    if vn.fdl_get_pia_auto_yn(i_acnt_no, i_sub_no,vn.vwdate()) = 'Y' then
    	vn.pdl_get_not_pia_amt_yet(
					i_acnt_no, i_sub_no, t_notyet_pia_loan_amt_sum
					);
    end if;
    o_loan_amt_t1 := greatest(t_loan_sum_amt_t1_sum - ( greatest(t_dpo - t_dpo_block - t_outq_dpo_bk,0) + t_notyet_pia_loan_amt_sum), 0);

    return o_loan_amt_t1;


end fdl_get_loan_amt_t1;
/

