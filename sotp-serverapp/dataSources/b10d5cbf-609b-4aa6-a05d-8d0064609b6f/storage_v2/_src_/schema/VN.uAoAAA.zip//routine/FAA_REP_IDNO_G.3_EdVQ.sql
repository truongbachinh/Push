create function faa_rep_idno_g
(
	i_acnt_no		in		varchar2,
	i_sub_no		in		varchar2
) return varchar2 as

	o_idno	varchar2(20);


/* ===========================================
	-- Program ID 		: 	faa_rep_idno_g
	-- Date of Program	: 	22/10/2007
	-- Programmer		:	mkkim
	-- Description 		:
			input  :  Account no
			return :  Representative IDNO
   =========================================== */

begin

	begin
	select	nvl(idno,'!')
	into	o_idno
	from	vn.aaa01m20
	where	acnt_no		=	i_acnt_no
	and     sub_no      =   i_sub_no
	and     vn.vwdate  between  regi_dt and to_char(cls_dtm,'yyyymmdd')
	and		cls_dtm		=	to_date('30000101','yyyymmdd');

		return o_idno;

	exception
	when	 no_data_found then
		return 	'!';
	end;


end ;
/

