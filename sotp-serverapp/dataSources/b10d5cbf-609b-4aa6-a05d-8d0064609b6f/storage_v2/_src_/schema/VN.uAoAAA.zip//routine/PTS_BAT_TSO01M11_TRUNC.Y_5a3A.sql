create procedure pts_bat_tso01m11_trunc (
    i_work_dt       in      varchar2,       -- date(yyyymmdd)
	o_err_code      in      number,         -- error code(0:SUCCESS)
	o_err_msg       in      varchar2,       -- error message
	o_proc_cnt      out     number          -- proc data count
) as

t_err_code      number        := o_err_code;
t_err_msg       varchar2(600) := rtrim(o_err_msg);
exp_error       exception;

begin

	t_err_code := 0;
	t_err_msg  := 'SUCCESS';

	delete from vn.tso01m11 ;

	o_proc_cnt := SQL%ROWCOUNT;

	exception when  exp_error then
		t_err_code := sqlcode;
		t_err_msg  := sqlerrm;
		raise_application_error(-20100,'[pts_bat_tso01m11_trunc] ' || t_err_msg);

end pts_bat_tso01m11_trunc;
/

