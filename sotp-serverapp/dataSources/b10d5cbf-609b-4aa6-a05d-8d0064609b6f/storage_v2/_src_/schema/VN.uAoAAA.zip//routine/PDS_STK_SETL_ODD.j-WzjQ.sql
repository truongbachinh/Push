create procedure pds_stk_setl_odd
(
  i_setl_dt     in     varchar2,        --
  i_mth_dt      in     varchar2,        --
  i_acnt_no     in     varchar2,        --
  i_sub_no      in     varchar2,        --
  i_setl_seq_no in     number,          --
  i_cnfrm_dt    in     varchar2,        --
  i_work_mn     in     varchar2,        -- user id
  i_work_trm    in     varchar2,
  o_cnt         in out number
) AS

/*!
   \file     pds_stk_setl_odd.sql
   \brief    stock of odd-lot settlement

   \section intro Program Information
        - Program Name              : settle stock of odd-lot
        - Service Name              : ds_04003_p1.pc
        - Related Client Program- Client Program ID : w_04001
        - Related Tables            : dsc01m00, ssb01m00
                                    : aaa01m00, aaa10m00
        - Dev. Date                 : 2007/11/08
        - Developer                 : Han.
        - Business Logic Desc.      : create settle data
        - Latest Modification Date  : 2007/11/08

   \section history Program Modification History
    - 1.0       2007/11/08     Han.    New.

   \section hardcoding Hard-Coding List
    - HC-1      2007/11/08     Han.    [»çÀ¯]

   \section info Additional Reference Comments
    - °áÁ¦Ã³¸®

var o_cnt number;
exec pds_stk_setl_odd('20080117','20080117','%','055C000020','%','00','Test','Test',:o_cnt);
print o_cnt;
*/

    t_mng_brch_cd       varchar2(3) := null;
    t_agnc_brch         varchar2(2) := null;
    t_setl_tp           varchar2(1) := null;

    t_qty               number      := 0;     --
    t_bil_prerm         number      := 0;     --
    t_bil_nowrm         number      := 0;     --
    t_book_amt          number      := 0;     --
    t_pre_book_amt      number      := 0;     --
    t_outble_qty        number      := 0;     --
    t_sb_pl             number      := 0;     --

    t_trd_seq_no       number       := 0;
    t_tot_seq_no       number       := 0;
  t_trd_dt           varchar2(8)  := NULL;
    t_pd_dt           varchar2(8)  := null;
    t_ppd_dt           varchar2(8)  := null;

    t_trd_tp            varchar2(2) := NULL;
    t_rmrk_cd           varchar2(3) := NULL;

    ts_work_stat_min    VARCHAR2(1);
    ts_work_stat_max    VARCHAR2(1);

    t_seq_no            number      := 0;     --
    ts_end_yn           varchar2(1);
    ts_err_msg          varchar2(100);
    ts_inq_dt           varchar2(8);
    ts_cnte             varchar2(10);

  tmp_acnt_no        varchar2(10) := '!';
    tmp_sub_no        varchar2(2)   := null;
    tmp_trd_seq_no      number       := 0;

  t_acnt_tp      VARCHAR2(1) := NULL;
    t_err_msg           varchar2(500);
    t_pos               varchar2(100);
    o_cnt1              number      := 0;

begin

    o_cnt     :=  0;

  t_pos     :=  'CHK DT1';
  t_trd_dt  :=  vn.vwdate;

    t_pd_dt   := vn.fxc_vorderdt_g(to_date(i_mth_dt,'yyyymmdd'), 1);
    t_ppd_dt  := vn.fxc_vorderdt_g(to_date(i_mth_dt,'yyyymmdd'), 2);

    /*========================================================================*/
    /* Input Date CHECK                                                       */
    /*========================================================================*/
    if  vn.fxc_holi_ck(to_date(t_trd_dt,'yyyymmdd')) !=  '0' then
      if  i_work_mn <> 'DAILY' then
          t_err_msg := vn.fxc_get_err_msg('V','2422');
          t_err_msg := t_err_msg||' Date1 = '||t_trd_dt;
          raise_application_error(-20100,t_err_msg);
    else
      return;
    end if;
    end if;

  if  i_setl_dt  >  t_trd_dt  then
        t_err_msg := vn.fxc_get_err_msg('V','2422');
        t_err_msg := t_err_msg||' Date = '||i_setl_dt;
        raise_application_error(-20100,t_err_msg);
  end if;

    /*========================================================================*/
    /* Prededing job Check                                                    */
    /*========================================================================*/
  t_pos := 'CHK BAT';

  if  vn.fxb_daily_stat_chk ('B','0','2600','2800','*') = 'Y' then
    t_err_msg := vn.fxc_get_err_msg('V','9416');
    t_err_msg := t_err_msg||'[2600],[2800]'||i_setl_dt;
    raise_application_error(-20100,t_err_msg);
  end if;

/*============================================================================*/
/* ( )                                                                        */
/*============================================================================*/
    for C1 in (
        select  a.setl_dt
             ,  a.acnt_no
             ,  a.sub_no
             ,  a.setl_frct_seq_no
             ,  a.mth_dt
             ,  a.acnt_mng_bnh
             ,  a.agnc_brch
             ,  a.sb_tp
             ,  a.mkt_trd_tp
             ,  a.cdt_tp
             ,  a.stk_cd
             ,  a.mdm_tp
             ,  a.stk_tp
             ,  a.sb_pri
             ,  a.sb_qty
             ,  a.sb_amt
             ,  a.sb_cmsn
             ,  a.sb_tax
             ,  a.adj_amt
             ,  a.bank_cd
          from  vn.dsc01m00 a
         where  a.setl_dt           =  i_setl_dt
           and  a.acnt_no           =  i_acnt_no
           and  a.sub_no            =  i_sub_no
           and  a.setl_frct_seq_no  =  i_setl_seq_no
           and  a.mth_dt            =  i_mth_dt
           and  a.mkt_trd_tp       in  ('02')
           and  a.stk_setl_yn      in  ('N')
         order  by  a.setl_dt, a.acnt_no, a.sub_no, a.setl_frct_seq_no, a.mth_dt
    ) loop
        o_cnt := o_cnt + 1;

        /*====================================================================*/
        /* Account management branch                                          */
        /*====================================================================*/
        begin
            select  nvl(agnc_brch,'00')
                 ,  setl_tp
              into  t_agnc_brch
                 ,  t_setl_tp
              from  vn.aaa01m00
             where  acnt_no      =  C1.acnt_no
               and  sub_no     =  C1.sub_no
            ;
        exception
        when no_data_found then
      t_err_msg := vn.fxc_get_err_msg('V','2006');
      raise_application_error(-20100,t_err_msg||' ACNT_NO='||C1.acnt_no||'-'||C1.sub_no);
        when others then
        t_err_msg := vn.fxc_get_err_msg('V','9002');
        raise_application_error(-20011,t_err_msg||' acnt_no='||C1.acnt_no||'-'||C1.sub_no);
        end;

    /*====================================================================*/
    /* Get the Trade sequence number and Total trade sequence number      */
    /*====================================================================*/
    begin
        vn.pxc_psb_seq_cret_p(C1.acnt_no, C1.sub_no, vn.vwdate, t_trd_seq_no, t_tot_seq_no);
    exception
    when others then
        t_err_msg := vn.fxc_get_err_msg('V','9414');
        t_err_msg := t_err_msg||' Acnt_no= '||C1.acnt_no||'-'||C1.sub_no;
        raise_application_error(-20100,t_err_msg);
    end;

        /*====================================================================*/
        /* stock's balance check                                              */
        /*====================================================================*/
        t_qty               := 0;                    --
        t_bil_prerm         := 0;                    -- pre balance
        t_bil_nowrm         := 0;                    -- now balance
        t_book_amt          := 0;                    --
        t_pre_book_amt      := 0;                    --

        /* 2008.10.28 CTB Account check */
        if  t_setl_tp = '1' then
            for C2 in (
                select *
                  from vn.ssb01m00
                 where acnt_no = c1.acnt_no
                   and sub_no  = c1.sub_no
                   and stk_cd  = C1.stk_cd
            ) loop

              t_qty               := C2.own_qty;
              t_bil_prerm         := C2.own_qty;
              t_book_amt          := C2.book_amt;
              t_pre_book_amt      := C2.book_amt;

            end loop;

            /*================================================================*/
            /* stock balance qty update                                       */
            /*================================================================*/
            /* sell */
            if  C1.sb_tp = '1' then
                if  C1.sb_qty <= t_bil_prerm then

                    t_bil_nowrm  := t_bil_prerm  -  C1.sb_qty;
                else
                    t_bil_nowrm  := 0;
            t_err_msg := vn.fxc_get_err_msg('V','2205');
            raise_application_error(-20100,t_err_msg||' ACNT_NO='||C1.acnt_no||'-'||C1.sub_no
                                                    ||'-'||C1.sb_qty
                                                    ||'-'||t_bil_prerm);
                end if;
            else
                t_bil_nowrm      := t_bil_prerm  +  C1.sb_qty;
            end if;

            if  C1.sb_tp = '1' then
                if  C1.sb_qty < t_bil_prerm and t_bil_prerm > 0 then
                    t_book_amt := t_book_amt -
                                  trunc(t_book_amt * C1.sb_qty / t_bil_prerm);
                else
                    t_book_amt := 0;
                end if;

                /*  profit and loss calculate  */
                t_sb_pl := C1.sb_amt - trunc(t_pre_book_amt / t_bil_prerm * C1.sb_qty);

            else
                if  t_bil_prerm < 0 then
                    if  C1.sb_qty < abs(t_bil_prerm) then
                        t_book_amt := 0;
                    else
                        t_book_amt := (C1.sb_qty - abs(t_bil_prerm)) *
                                                         C1.sb_amt / C1.sb_qty;
                    end if;
                else
                      t_book_amt := t_book_amt + C1.sb_amt;
                end if;

            end if;

            /* reset block  */
            if  C1.sb_tp = '1' THEN
              if  t_trd_dt = i_mth_dt THEN
                  update  vn.tso04m00
                     set  TD_SELL_MTH_QTY  =  case when TD_SELL_MTH_QTY - C1.sb_qty < 0 then 0
                                                     else TD_SELL_MTH_QTY - C1.sb_qty
                                                end
                       ,  TD_SELL_MTH_AMT  =  case when TD_SELL_MTH_AMT - C1.sb_amt < 0 then 0
                                                     else TD_SELL_MTH_AMT - C1.sb_amt
                                                end
                   where  acnt_no  =  C1.acnt_no
                     and  sub_no   =  C1.sub_no
                     and  bank_cd  =  C1.bank_cd
                     and  stk_cd   =  C1.stk_cd
                  ;
              elsif  t_trd_dt = t_pd_dt THEN
                  update  vn.tso04m00
                     set  PD_SELL_MTH_QTY  =  case when PD_SELL_MTH_QTY - C1.sb_qty < 0 then 0
                                                     else PD_SELL_MTH_QTY - C1.sb_qty
                                                end
                       ,  PD_SELL_MTH_AMT  =  case when PD_SELL_MTH_AMT - C1.sb_amt < 0 then 0
                                                     else PD_SELL_MTH_AMT - C1.sb_amt
                                                end
                   where  acnt_no  =  C1.acnt_no
                     and  sub_no   =  C1.sub_no
                     and  bank_cd  =  C1.bank_cd
                     and  stk_cd   =  C1.stk_cd
                  ;
              else
                  update  vn.tso04m00
                     set  PPD_SELL_MTH_QTY  =  case when PPD_SELL_MTH_QTY - C1.sb_qty < 0 then 0
                                                     else PPD_SELL_MTH_QTY - C1.sb_qty
                                                end
                       ,  PPD_SELL_MTH_AMT  =  case when PPD_SELL_MTH_AMT - C1.sb_amt < 0 then 0
                                                     else PPD_SELL_MTH_AMT - C1.sb_amt
                                                end
                   where  acnt_no  =  C1.acnt_no
                     and  sub_no   =  C1.sub_no
                     and  bank_cd  =  C1.bank_cd
                     and  stk_cd   =  C1.stk_cd
                  ;
              end if;
            else

              if  t_trd_dt = i_mth_dt THEN
                  update  vn.tso04m00
                     set  TD_BUY_MTH_QTY  =  case when TD_BUY_MTH_QTY - C1.sb_qty < 0 then 0
                                                    else TD_BUY_MTH_QTY - C1.sb_qty
                                               end
                       ,  TD_BUY_MTH_AMT  =  case when TD_BUY_MTH_AMT - C1.sb_amt < 0 then 0
                                                    else TD_BUY_MTH_AMT - C1.sb_amt
                                               end
                   where  acnt_no  =  C1.acnt_no
                     and  sub_no   =  C1.sub_no
                     and  bank_cd  =  C1.bank_cd
                     and  stk_cd   =  C1.stk_cd
                  ;
              elsif  t_trd_dt = t_pd_dt THEN
                  update  vn.tso04m00
                     set  PD_BUY_MTH_QTY  =  case when PD_BUY_MTH_QTY - C1.sb_qty < 0 then 0
                                                    else PD_BUY_MTH_QTY - C1.sb_qty
                                               end
                       ,  PD_BUY_MTH_AMT  =  case when PD_BUY_MTH_AMT - C1.sb_amt < 0 then 0
                                                    else PD_BUY_MTH_AMT - C1.sb_amt
                                               end
                   where  acnt_no  =  C1.acnt_no
                     and  sub_no   =  C1.sub_no
                     and  bank_cd  =  C1.bank_cd
                     and  stk_cd   =  C1.stk_cd
                  ;
              else
                  update  vn.tso04m00
                     set  PPD_BUY_MTH_QTY  =  case when PPD_BUY_MTH_QTY - C1.sb_qty < 0 then 0
                                                    else PPD_BUY_MTH_QTY - C1.sb_qty
                                               end
                       ,  PPD_BUY_MTH_AMT  =  case when PPD_BUY_MTH_AMT - C1.sb_amt < 0 then 0
                                                    else PPD_BUY_MTH_AMT - C1.sb_amt
                                               end
                   where  acnt_no  =  C1.acnt_no
                     and  sub_no   =  C1.sub_no
                     and  bank_cd  =  C1.bank_cd
                     and  stk_cd   =  C1.stk_cd
                  ;
              end if;

            end if;


        end if;


    /*====================================================================*/
        /* account type (1:Security-Account  2:Bank-Account  3:Non-custodian) */
        /*====================================================================*/
        t_acnt_tp :=  vn.faa_get_acnt_tp(C1.acnt_no, C1.sub_no) ;
        /*====================================================================*/
        /* pds_aaa10m00_ins(°Å·¡³»¿ª) Create                                  */
        /*====================================================================*/
        /* 2008.10.28 CTB Account => [605,606] */
        if  t_setl_tp = '2' then
            if  C1.sb_tp = '1' then
                t_trd_tp  := '55';
                t_rmrk_cd := '605';
            elsif C1.sb_tp = '2' THEN
                t_trd_tp  := '54';
                t_rmrk_cd := '606';
            end if;

            vn.pds_aaa10m00_ins (  C1.acnt_no          -- ACNT_NO
                       , C1.sub_no
                                 , t_trd_dt            -- TRD_DT
                                 , t_trd_seq_no        -- TRD_SEQ_NO
                                 , t_trd_tp            -- TRD_TP
                                 , t_rmrk_cd           -- RMRK_CD
                                 , ''                  -- BANK_CD
                                 , C1.mdm_tp           -- MDM_TP
                                 , C1.mdm_tp           -- TRD_MDM_TP
                                 , 'N'                 -- CNCL_YN
                                 , 0                   -- ORG_TRD_NO
                                 , C1.adj_amt          -- TRD_AMT
                                 , C1.sb_cmsn          -- CMSN
                                 , C1.sb_tax           -- SB_TAX
                                 , C1.adj_amt          -- ADJ_AMT
                                 , 0                   -- DPO_PRERM
                                 , 0                   -- DPO_NOWRM
                                 , C1.stk_cd           -- STK_CD
                                 , vn.fss_get_stk_nm(C1.stk_cd)
                                                       -- STK_NM
                                 , C1.sb_pri           -- SB_PRI
                                 , C1.sb_qty           -- SB_QTY
                                 , t_bil_prerm         -- BIL_PRERM_QTY
                                 , t_bil_nowrm         -- BIL_NOWRM_QTY
                                 , abs(t_pre_book_amt-t_book_amt)
                                                       -- BOOK_AMT
                                 --, t_pre_book_amt      -- PRE_BOOK_AMT
                                 --, t_aft_book_amt      -- AFT_BOOK_AMT
                                 --, t_sb_pl             -- SB_PL
                                 , C1.stk_tp           -- STK_TP
                                 , C1.mth_dt           -- MTH_DT
                                 , C1.cdt_tp           -- LND_TP
                                 , null                -- LND_DT
                                 , null                -- LND_BANK_CD
                                 , 0                   -- LND_AMT
                                 , 0                   -- LND_RPY_AMT
                                 , 0                   -- LND_INT
                                 , 0                   -- LND_CMSN
                                 , 0                   -- LND_INT_DLY
                                 , 0                   -- LND_CMSN_DLY
                                 , 'N'                 -- AGNT_YN
                                 , C1.acnt_mng_bnh     -- ACNT_MNG_BNH
                                 , C1.agnc_brch        -- AGNC_BRCH
                                 , C1.acnt_mng_bnh     -- WORK_BNH
                                 , C1.agnc_brch        -- PROC_AGNC_BRCH
                                 , i_work_mn           -- WORK_MN
                                 , i_work_trm          -- WORK_TRM
                                 , C1.setl_dt
                                 , t_tot_seq_no
                                );
        else
        if  C1.sb_tp = '1' then
          t_rmrk_cd  := '603';
          ts_cnte    := 'SELL';
        elsif C1.sb_tp = '2' THEN
          t_rmrk_cd  := '604';
          ts_cnte    := 'BUY';
        end if;

            /*================================================================*/
            /* stock balance qty 2009-05-10                                   */
            /*================================================================*/
            SELECT  NVL(MAX(SEQ_NO)+1, 1)
              INTO  t_seq_no
              FROM  VN.SSB05M00
             WHERE  PROC_DT  =  t_trd_dt
               AND  ACNT_NO  =  C1.acnt_no
               AND  sub_no   =  C1.sub_no;


            begin
            INSERT INTO VN.SSB05M00
            (  PROC_DT
            ,  ACNT_NO
            ,  SUB_no
            ,  SEQ_NO
            ,  TRD_TP
            ,  STK_CD
            ,  RMRK_CD
            ,  QTY
            ,  SB_LMT_QTY
            ,  MOV_LMY_QTY
            ,  INQ_PRI
            ,  BUY_DT
            ,  INQ_DT
            ,  ANTH_CD
            ,  ANTH_ACNT_NO
            ,  CNTE
            ,  CNCL_YN
            ,  END_YN
            ,  WORK_MN
            ,  WORK_DTM
            ,  WORK_TRM
            )
            VALUES  (
               t_trd_dt
            ,  C1.acnt_no
            ,  C1.sub_no
            ,  t_seq_no
            ,  t_trd_tp    /* trd_tp */
            ,  C1.stk_cd
            ,  t_rmrk_cd   /* rmrk_cd */
            ,  C1.sb_qty
            ,  0
            ,  0
            ,  0
            ,  C1.mth_dt
            ,  NULL
            ,  NULL
            ,  NULL
            ,  ts_cnte
            ,  'N'
            ,  'N'
            ,  i_work_mn
            ,  sysdate
            ,  i_work_trm
            );
            exception
            when others then
          t_err_msg := vn.fxc_get_err_msg('V','2207');
          raise_application_error(-20013,t_err_msg||' ACNT_NO1='||C1.acnt_no||'-'||C1.sub_no);
            end;

        if  C1.sb_tp = '1' then
                --begin
                begin
                  vn.pss_outbil_aprv_p (  t_trd_dt        /* setl_dt */
                                       ,  C1.acnt_no
                                       ,  C1.sub_no
                                       ,  t_seq_no
                                       ,  i_cnfrm_dt      /* confirm_dt */
                                       ,  i_work_mn
                                       ,  i_work_trm
                                       ,  C1.acnt_mng_bnh
                                       ,  C1.agnc_brch
                                       ,  C1.adj_amt
                                       ,  C1.sb_cmsn
                                       ,  C1.sb_tax
                                       ,  C1.adj_amt
                                       ,  ts_end_yn
                                       ,  ts_err_msg
                                       ,  ts_inq_dt
                      );
        exception
                when others then
          vn.pxc_log_write('pds_stk_setl_odd', ' pss_outbil_aprv_p:'
                                                                    ||' ts_end_yn ='   ||ts_end_yn
                                                                    ||' ts_err_msg ='   ||ts_err_msg
                                                                    ||' ts_inq_dt ='||ts_inq_dt
                                                                    ||' sqlcode ='||sqlcode);
              t_err_msg := vn.fxc_get_err_msg('V','2207');
              raise_application_error(-20013,t_err_msg||' NO2='||C1.acnt_no||'-'||C1.sub_no);
                end;

        elsif C1.sb_tp = '2' THEN
                begin
                vn.pss_inbil_aprv_p  (  t_trd_dt        /* setl_dt */
                                     ,  C1.acnt_no
                                     ,  C1.sub_no
                                     ,  t_seq_no
                                     ,  i_cnfrm_dt      /* confirm_dt */
                                     ,  i_cnfrm_dt      /* confirm_dt */
                                     ,  i_work_mn
                                     ,  i_work_trm
                                     ,  C1.acnt_mng_bnh
                                     ,  C1.agnc_brch
                                     ,  C1.adj_amt
                                     ,  C1.sb_cmsn
                                     ,  C1.sb_tax
                                     ,  C1.adj_amt
                                     ,  ts_end_yn
                                     ,  ts_err_msg
                                     ,  ts_inq_dt
                   );
                exception
                when others then
                  vn.pxc_log_write('pds_stk_setl_odd', ' pss_inbil_aprv_p:'
                                                                    ||' ts_end_yn ='   ||ts_end_yn
                                                                    ||' ts_err_msg ='   ||ts_err_msg
                                                                    ||' ts_inq_dt ='||ts_inq_dt
                                                                    ||' sqlcode ='||sqlcode);
              t_err_msg := vn.fxc_get_err_msg('V','2207');
              raise_application_error(-20013,t_err_msg||' ACNT_NO3='||C1.acnt_no||'-'||C1.sub_no);
                end;
        end if;

            /*  daily profit and loss create */
            if  C1.sb_tp = '1' then
                vn.pds_dsc20m00_ins (  t_trd_dt            -- TRD_DT
                                     , C1.acnt_no          -- ACNT_NO
                                     , C1.sub_no
                                     , to_number(ts_inq_dt)-- TRD_SEQ_NO
                                     , C1.stk_cd           -- STK_CD
                                     , C1.sb_pri           -- SB_PRI
                                     , C1.sb_qty           -- SB_QTY
                                     , C1.sb_cmsn          -- SB_CMSN
                                     , C1.sb_tax           -- SB_TAX
                                     , t_sb_pl             -- SB_PL
                                     , t_bil_prerm         -- PRERM_QTY
                                     , t_bil_nowrm         -- NOWRM_QTY
                                     , t_pre_book_amt      -- PRE_BOOK_AMT
                                     , t_book_amt          -- NOW_BOOK_AMT
                                     , 'N'                 -- CNCL_YN
                                     , i_work_mn           -- WORK_MN
                                     , i_work_trm          -- WORK_TRM
                                    );
        end if;
    end if;

        /*====================================================================*/
        /* dsc01m00(°áÁ¦¿¹Á¤³»¿ª) Update                                      */
        /*====================================================================*/
        /* TABLE UPDATE */
        UPDATE  vn.dsc01m00
           set  stk_setl_yn       =  'Y'
             ,  stk_setl_dt       =  t_trd_dt
             ,  trd_seq_no        =  t_trd_seq_no
         where  setl_dt           =  C1.setl_dt
           and  acnt_no           =  C1.acnt_no
           and  sub_no         =  C1.sub_no
           and  setl_frct_seq_no  =  C1.setl_frct_seq_no
           and  mth_dt            =  C1.mth_dt
        ;

    /*====================================================================*/
        /* Margin Evaluation                                                  */
        /*====================================================================*/
    if  tmp_acnt_no = '!' then
      tmp_acnt_no    := C1.acnt_no;
      tmp_sub_no    := C1.sub_no;
      tmp_trd_seq_no  := t_trd_seq_no;
    else
      if  (tmp_acnt_no <> C1.acnt_no) or (tmp_sub_no <> C1.sub_no) then
            o_cnt1 := 0;
            begin
            vn.pdl_crd_loan_rt_proc_td( t_trd_dt,  '2',
                                        tmp_acnt_no, tmp_sub_no, tmp_trd_seq_no,
                                        i_work_mn, i_work_trm,  o_cnt1 );

            exception
            when others then
                vn.pxc_log_write('pds_stk_setl_odd', ' crd_loan_td:'||' C1.ACNT ='||C1.acnt_no||'-'||C1.sub_no
                                                                    ||' T_ACNT =' ||tmp_acnt_no||'-'||tmp_sub_no
                                                                    ||' SEQ_NO =' ||tmp_trd_seq_no
                                                                    ||' DATE ='   ||t_trd_dt
                                                                    ||' sqlcode ='||sqlcode);
                t_err_msg := vn.fxc_get_err_msg('V','2491');
                raise_application_error(-20011,t_err_msg||' ACNT_NO='||tmp_acnt_no||'-'||tmp_sub_no);
            end;

            tmp_acnt_no    := C1.acnt_no;
            tmp_sub_no    := C1.sub_no;
            tmp_trd_seq_no  := t_trd_seq_no;
          end if;
      end if;
    end loop;

end pds_stk_setl_odd;
/

