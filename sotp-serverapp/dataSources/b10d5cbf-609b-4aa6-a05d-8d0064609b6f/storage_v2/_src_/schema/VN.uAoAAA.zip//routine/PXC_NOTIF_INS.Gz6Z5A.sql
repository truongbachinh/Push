create procedure    pxc_notif_ins(
    i_acnt_no       in varchar2,
    i_sub_no        in varchar2,
    i_func_cd       in varchar2,                         -- NOT null
    i_msg_lang      in varchar2,                         -- can put NULL, get from account
    i_notif_msg     in varchar2,                         -- NOT null
    i_notif_tp      in varchar2,
    i_work_mn       in varchar2,                         -- can put NULL
    i_work_trm      in varchar2                         -- can put NULL
)
/*
    begin
        vn.pxc_notif_ins(
            '039C000088',   -- i_acnt_no       in varchar2,
            '00',           -- i_sub_no        in varchar2,
            'F03101',       -- i_func_cd       in varchar2,                         -- NOT null
            null,            -- i_msg_lang      in varchar2,                         -- can put NULL, get from account
            '||039C000088||00||ACB||1,000||5,000||13/8/2021 9:39AM',        -- i_notif_msg     in varchar2,                         -- NOT null
            '1',            -- i_notif_tp      in varchar2,
            'lthpt01',      -- i_work_mn       in varchar2,                         -- can put NULL
            '1.1.1.1'       -- 'i_work_trm      in varchar2                         -- can put NULL
        );
    end;
*/
as
/* Declare variable */
    -- Common variable
    t_proc_nm               varchar2(100)   := 'pxc_notif_ins';
    t_err_msg               varchar2(4000)  := ' ';
    t_vwdate                varchar2(8)     := vn.vwdate;

    -- Info variable
    t_sent_st               varchar2(10)    := 'N';
    t_re_try_cnt            number          := 0;
    t_notif_title           varchar2(100)   := null;
    t_notif_msg_trunc       varchar2(1000)  := ' ';
    t_notif_msg             varchar2(1000)  := ' ';
    t_notif_msg_max_sz      number          := 160;
    t_send_dt               varchar2(14)    := vn.vwdate;
    t_msg_lang              varchar2(1)     := i_msg_lang;
    t_notif_reg_yn          varchar2(1)     := 'Y';

begin
    /* Steps:
        1. Check if account is registered sending notif
        2. Get input values if null
        3. Get message content from input
        4. Validate message content
        5. Insert into xcs01m10
    */

    vn.pxc_log_write(t_proc_nm, '');
    vn.pxc_log_write(t_proc_nm, 'Start ' || t_proc_nm || ' for: '
                                    || 'i_acnt_no: '    || i_acnt_no
                                    || ', i_sub_no: '   || i_sub_no
                                    || ', i_func_cd: '  || i_func_cd
                                    || ', i_msg_lang: ' || i_msg_lang
                                    || ', i_notif_msg: '|| i_notif_msg
                                    || ', i_notif_tp: ' || i_notif_tp
    );

    -- 1. Check if account is registered sending notif
    begin
        t_notif_reg_yn    := vn.fxc_acnt_notif_reg_chk(i_acnt_no, i_func_cd);
    exception
        when others then
            vn.Pxc_Log_Write (t_proc_nm, 'Error when getting account notif registration: ' || sqlcode || ' - ' || sqlerrm);
            return;
    end;

    if(t_notif_reg_yn = 'N') then
        vn.pxc_log_write(t_proc_nm, 
                               'Account: ' || i_acnt_no || '-' || i_sub_no
                            || ' is not registered sending notif for: ' || i_func_cd
                        );
        return;
    else
        -- 2. Get input values if null
        begin
            if(i_msg_lang is null) then
                select decode(acnt_tp, 'F', 'E', 'V') ms_lang
                into t_msg_lang
                from vn.aaa01m00
                where acnt_no = i_acnt_no
                and sub_no = i_sub_no;
            end if;

        exception
            when others then
                vn.Pxc_Log_Write (t_proc_nm, 'Error when replacing NULL input parameter: ' || sqlcode || ' - ' || sqlerrm);
                return;
        end;

        -- 3. Get message content from input
        t_notif_msg_trunc := trim(i_notif_msg);
        t_notif_msg_trunc := regexp_replace(t_notif_msg_trunc, ' {2,}', ' ');
        t_notif_msg_trunc := replace(t_notif_msg_trunc, ' ||' , '||');
        t_notif_msg_trunc := replace(t_notif_msg_trunc, '|| ' , '||');

        begin
            t_notif_msg := vn.fxc_get_notif_msg(
                            i_notif_tp,
                            i_func_cd,
                            t_msg_lang,
                            t_notif_msg_trunc
                        );
        exception
            when others then
                vn.Pxc_Log_Write (t_proc_nm, 'Error when getting msg content: ' || sqlcode || ' - ' || sqlerrm);
                return;
        end;

        vn.pxc_log_write(t_proc_nm, 't_notif_msg: ' || t_notif_msg); 

        -- 4. Validate message content
        if trim(t_notif_msg) is null then
            if(i_notif_tp = '1') then
                vn.pxc_log_write(t_proc_nm, 'Message content is null');
                return;
            else
                t_notif_msg := i_notif_msg;
            end if;
        end if;

        -- 5. Get notification's title
        begin
            select notif_title
            into t_notif_title
            from vn.xcs01m03
            where func_cd = i_func_cd
            and msg_lang = t_msg_lang;
        exception
            when others then
                vn.Pxc_Log_Write (t_proc_nm, 'Error when getting msg title: ' || sqlcode || ' - ' || sqlerrm);
                return;
        end;

        -- 5. Insert into xcs01m10
        vn.pxc_log_write(t_proc_nm, 'Start inserting into xcs01m10');
        begin
            insert into vn.xcs01m10(
                dt,
                seq_no,
                acnt_no,
                sub_no,
                sent_st,
                sent_dtm,
                -- re_try_cnt,
                func_cd,
                notif_title,
                notif_msg,
                notif_lang,
                notif_tp,
                create_mn,
                create_dtm,
                create_trm
            )
            values(
                t_send_dt,
                vn.xcs01m10_seq.nextval,
                i_acnt_no,
                i_sub_no,
                t_sent_st,
                null,
                -- t_re_try_cnt,
                i_func_cd,
                t_notif_title,
                t_notif_msg,
                t_msg_lang,
                i_notif_tp,
                i_work_mn,
                sysdate,
                i_work_trm
            );

        exception
            when others then
                t_err_msg  := 'Error when inserting into xcs01m10: ' || sqlcode || ' - ' || sqlerrm;
                -- raise_application_error(-20100,t_err_msg);
                vn.pxc_log_write(t_proc_nm, t_err_msg);

                return;
        end;

        vn.pxc_log_write(
            t_proc_nm, 
            'Sending notification successfully to: '
                || 'acnt_no: '  || i_acnt_no
                || ', sub_no: ' || i_sub_no
        );

    end if;

end pxc_notif_ins;
/

