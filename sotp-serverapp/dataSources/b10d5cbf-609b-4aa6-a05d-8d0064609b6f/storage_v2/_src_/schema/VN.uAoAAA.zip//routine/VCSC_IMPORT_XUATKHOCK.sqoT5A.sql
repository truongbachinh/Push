create PROCEDURE VCSC_Import_XuatKHoCK
( i_sec_cd     in   varchar2,
 is_std_inq_dt  	in	varchar2,         --approving date
 is_apy_dt     	in	varchar2,  
  is_work_mn			in	varchar2,
 is_work_trm		in	varchar2,
 o_proc_cnt   in out   number)
as
/*   vn_cnt             number :=0;*/
  -- vn_fee          number := 0;
 --  vn_count           number :=0;
   tn_qty					number 	:= 0;
 tn_sb_lmt_qty			number 	:= 0;
 tn_mov_lmy_qty			number 	:= 0;
 tn_inq_pri             number 	:= 0;
  tot_cnt				number 	:= 0;
-- os_end_yn				varchar2;
-- os_err_msg				varchar2;
  tn_loop_cnt			number	:= 0;
   ERR_RTN				EXCEPTION;
   os_err_msg			    varchar2(200)	:= '';
 --  ts_stk_cd			varchar2(20)	:= '';
     ts_wdate				varchar2(8)		:= '';
 ts_trd_dt				varchar2(8)		:= '';
 ts_date				varchar2(8)		:= '';
 ts_apy_dt      varchar2(8)		:= '';
  ts_sub_no				varchar2(2)		:= '';
 ts_acnt_no				varchar2(10)		:= '';
begin

 vn.pxc_log_write('VCSC_Import_XuatKHoCK', 'start update ssb01h00');
 o_proc_cnt := 0;
    FOR C1 IN (
		select   proc_dt
		,acnt_no
    ,sub_no
		,seq_no
		,vn.faa_acnt_nm_g( acnt_no,sub_no) acnt_nm
		,stk_cd
		,nvl(qty, 0) qty
		,nvl(sb_lmt_qty, 0) sb_lmt_qty
		,nvl(mov_lmy_qty, 0) mov_lmy_qty
--		,nvl(cnte, ' ')||'('||vn.fbm_rmrk_nm_q(rmrk_cd)||')'
		,nvl(std_inq_dt, ' ') std_inq_dt/*decode(std_inq_dt, null, ' ', substr(std_inq_dt, 7, 2) ||substr(std_inq_dt, 5, 2) || substr(std_inq_dt, 1, 4))*/
		,nvl(err_msg, ' ') err_msg
		,nvl(end_yn, 'N') end_yn
		,inq_dt/*decode(inq_dt, null, ' ', substr(inq_dt, 7, 2) ||substr(inq_dt, 5, 2) || substr(inq_dt, 1, 4))*/
    ,nvl(apy_dt, ' ') apy_dt/*decode(apy_dt, null, ' ', substr(apy_dt, 7, 2) ||substr(apy_dt, 5, 2) || substr(apy_dt, 1, 4))*/ /* Apply date Hung new 20100723 */
    ,' ' --vn.faa_acnt_email_g(acnt_no)
    ,' ' --vn.faa_acnt_tp_g(acnt_no)
    ,nvl(work_mn,'!') work_mn
    ,nvl(delay_qty, 0) delay_qty
    from  vn.ssb05m00
    where  proc_dt >= '20180501' and proc_dt <= '20180517'
    and  (trd_tp like '3' || '%' or ('3' = '1' and trd_tp like '7' || '%'))
    and '3' != '3'
    and  nvl(end_yn, 'N') = decode('2', '1', 'N','3','N','Y')
    and  nvl(cncl_yn, 'N') = decode('2','3','Y','N')
    and acnt_no||sub_no like '%'
    and stk_cd like 'VND'
    and sub_no <> '80'
    and  ( vn.faa_acnt_bnh_cd_g( '0', acnt_no, sub_no ) = '000' or '000' = '000' )
    and proc_dt || acnt_no || sub_no || lpad(seq_no , 3 , '0') > '0'
    and acnt_no||sub_no <>  '068C00006200'
    Union

    select  proc_dt
     		,acnt_no
    ,sub_no
     ,seq_no
     ,vn.faa_acnt_nm_g( acnt_no,sub_no) acnt_nm
     ,stk_cd
     ,nvl(qty, 0) qty
     ,nvl(sb_lmt_qty, 0) sb_lmt_qty
     ,nvl(mov_lmy_qty, 0) mov_lmy_qty
    -- ,nvl(cnte, ' ')||'('||vn.fbm_rmrk_nm_q(rmrk_cd)||')'
     ,nvl(std_inq_dt, ' ') std_inq_dt/*decode(std_inq_dt, null, ' ', substr(std_inq_dt, 7, 2) ||substr(std_inq_dt, 5, 2) || substr(std_inq_dt, 1, 4))*/
     ,nvl(err_msg, ' ') err_msg
     ,nvl(end_yn, 'N') end_yn
     ,inq_dt/*decode(inq_dt, null, ' ', substr(inq_dt, 7, 2) ||substr(inq_dt, 5, 2) || substr(inq_dt, 1, 4))*/
     ,nvl(apy_dt, ' ') apy_dt/*decode(apy_dt, null, ' ', substr(apy_dt, 7, 2) ||substr(apy_dt, 5, 2) || substr(apy_dt, 1, 4))*/ /* Apply date Hung new 20100723 */
     ,' ' --vn.faa_acnt_email_g(acnt_no)
     ,' ' --vn.faa_acnt_tp_g(acnt_no)
     ,nvl(work_mn,'!') work_mn
     ,nvl(delay_qty, 0) delay_qty
     from  vn.ssb05m00
     where  proc_dt >= '20180501' and proc_dt <= '20180517'
     and to_char(vn.wdate,'yyyymmdd') < apy_dt
     and  (trd_tp like '1' || '%' or trd_tp like '7' || '%')
     and '3' = '3'
     and vn.faa_acnt_stat_g(acnt_no, sub_no) <> '2' /* Hoai sua: VCSC-1792*/
		 and	nvl(end_yn, 'N') = decode('2', '1', 'N','3','N','Y')
		 and	nvl(cncl_yn, 'N') = decode('2','3','Y','N')
		 and acnt_no || sub_no like '%'
		 and stk_cd like 'VND'
		 and sub_no <> '80'
		 and  ( vn.faa_acnt_bnh_cd_g( '0', acnt_no, sub_no ) = '000' or '000' = '000' )
		 and proc_dt || acnt_no || sub_no || lpad(seq_no , 3 , '0') > '0'
     and acnt_no||sub_no <>  '068C00006200'
		-- order by next
   )LOOP
     ts_sub_no := C1.SUB_NO;
     ts_acnt_no := C1.ACNT_NO;
     tn_loop_cnt := 0;
      IF  tn_inq_pri = 0    THEN
         tn_inq_pri := vn.fss_get_pd_cls_pri('VND');

        IF  tn_inq_pri = 0  THEN
            tn_inq_pri := vn.fss_get_fac_pri( 'VND');
        END IF;
      END IF;
      tn_qty := C1.QTY;
      tn_sb_lmt_qty := C1.SB_LMT_QTY;
      tn_mov_lmy_qty := C1.MOV_LMY_QTY;
      pxc_log_write('pss_inbil_aprv_p','tn_inq_pri-'||tn_inq_pri);

      IF tn_inq_pri <= 0    THEN
        /* os_end_yn := 'N';
         os_err_msg := '9412';*/
         RAISE  ERR_RTN;
      END IF;
    IF is_apy_dt is null  then
       ts_apy_dt := is_std_inq_dt ;
      ELSE
       ts_apy_dt := is_apy_dt     ;
      END if ;    	
       /* update aaa10m00 and ssb01h00 */
 SELECT to_char(vn.wdate(),'ddmmyyyy') , to_char(vn.wdate(),'yyyymmdd')-1
 INTO   ts_wdate , ts_trd_dt
 FROM DUAL;
   if  is_std_inq_dt <>  ts_trd_dt then

        select to_date(ts_trd_dt,'yyyymmdd') - to_date(is_std_inq_dt,'yyyymmdd')
          into tot_cnt
          from dual;

        pxc_log_write('pss_inbil_aprv_p','std_inq_dt aaa10m00 cnt:' || is_std_inq_dt || ' ' || tot_cnt);

        for c1 in 0..tot_cnt loop

	      select to_char((to_date(is_std_inq_dt,'yyyymmdd') + tn_loop_cnt),'yyyymmdd')
	        into ts_date
	        from dual;


		  if vn.fxc_holi_ck(to_date( ts_date,'yyyymmdd' )) =  '0' then

          if  ts_date < ts_trd_dt then   /* excepts today  */

             pxc_log_write('pss_inbil_aprv_p','rgt_std_dt update :' || ts_date );

             merge into vn.ssb01h00
             using dual
             on (   acnt_no = ts_acnt_no
				and sub_no  = ts_sub_no
                and stk_cd = 'VND'
                and rgt_std_dt = ts_date)

             when matched then
             update set own_qty = own_qty + (tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty)
                       ,sb_lim_qty = sb_lim_qty + tn_sb_lmt_qty
                       ,mov_lim_qty = mov_lim_qty + tn_mov_lmy_qty
					   ,delay_qty     =  Decode( Sign ( ts_apy_dt - ts_trd_dt ) , 1  , delay_qty     + tn_qty          , delay_qty    )
					   ,delay_sb_qty  =  Decode( Sign ( ts_apy_dt - ts_trd_dt ) , 1  , delay_sb_qty  + tn_sb_lmt_qty   , delay_sb_qty )
					   ,delay_mov_qty =  Decode( Sign ( ts_apy_dt - ts_trd_dt ) , 1  , delay_mov_qty + tn_mov_lmy_qty  , delay_mov_qty)
                       ,book_amt = book_amt + ((tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty) * tn_inq_pri)
                       ,work_mn = is_work_mn
                       ,work_dtm = sysdate
                       ,work_trm = is_work_trm

             when not matched then
             insert ( rgt_std_dt
             		, acnt_no
					, sub_no
             		, stk_cd
             		, own_qty
             		, book_amt
             		, sb_lim_qty
             		, mov_lim_qty
					, delay_qty
					, delay_sb_qty
					, delay_mov_qty
					, work_mn
					, work_dtm
					, work_trm
             		)
             values ( ts_date
             		, ts_acnt_no
					, ts_sub_no
             		, 'VND'
             		, (tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty)
             		, ((tn_qty + tn_sb_lmt_qty + tn_mov_lmy_qty) * tn_inq_pri)
             		, tn_sb_lmt_qty
             		, tn_mov_lmy_qty
					, Decode( Sign ( ts_apy_dt - ts_trd_dt ) , 1  , tn_qty          , 0)
					, Decode( Sign ( ts_apy_dt - ts_trd_dt ) , 1  , tn_sb_lmt_qty   , 0)
					, Decode( Sign ( ts_apy_dt - ts_trd_dt ) , 1  , tn_mov_lmy_qty  , 0)
					, is_work_mn
					, sysdate
					, is_work_trm
             		);

           end if ;

         end if;
		 tn_loop_cnt := tn_loop_cnt + 1 ;
     o_proc_cnt := o_proc_cnt + 1;
	   end loop;
   end if ;
  
   END LOOP;	
	-- commit;
   
   vn.pxc_log_write('VCSC_Import_XuatKHoCK', 'finish, tong dong: ' ||o_proc_cnt );
    EXCEPTION
 WHEN 	ERR_RTN	THEN
   vn.pxc_log_write('VCSC_Import_XuatKHoCK','o_proc_cnt-'||o_proc_cnt);
   raise_application_error(-20100, os_err_msg || ':[pss_inbil_aprv_p ' || o_proc_cnt || '] ' || os_err_msg);
   RETURN;

  WHEN	NO_DATA_FOUND	THEN
   vn.pxc_log_write('VCSC_Import_XuatKHoCK','o_proc_cnt-'||o_proc_cnt);
    raise_application_error(-20200, '[pss_inbil_aprv_p ' || o_proc_cnt || '] ' || SQLERRM);
    RETURN;

  WHEN	OTHERS	THEN
   vn.pxc_log_write('VCSC_Import_XuatKHoCK','o_proc_cnt-'||o_proc_cnt);
     raise_application_error(-20300, '[VCSC_Import_XuatKHoCK ' || o_proc_cnt || '] ' || SQLERRM);
     RETURN;
     
end  VCSC_Import_XuatKHoCK;
/

