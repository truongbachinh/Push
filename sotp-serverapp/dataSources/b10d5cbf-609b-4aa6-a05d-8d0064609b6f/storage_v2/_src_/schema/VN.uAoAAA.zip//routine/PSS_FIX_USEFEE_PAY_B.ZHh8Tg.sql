create PROCEDURE    PSS_FIX_USEFEE_PAY_B
   (I_PAY_YM        IN      VARCHAR2,       -- Payment month
    I_ACNT_NO       IN      VARCHAR2,       -- (All:9999999999)
	I_SUB_NO        IN      VARCHAR2,       -- (All:99)
    I_BRCH_CD       IN      VARCHAR2,       -- (All:000)
    I_ACNT_TP       IN      VARCHAR2,       -- 9:All
    I_TR_CD       	IN      VARCHAR2,       -- Screen number
    I_DEPT_NO1    	IN      VARCHAR2,
    I_WORK_MN       IN      VARCHAR2,
    I_WORK_TRM      IN      VARCHAR2,       -- IP_ADDRESS
    O_RTN_TBL       OUT     VARCHAR2,       -- Return Table
	O_RTN_ERR       OUT     VARCHAR2,       -- Return Error Code
	O_RTN_MSG       OUT     VARCHAR2        -- Return Message
	) IS


    -- Constants
    K_ALL_BRCH      VARCHAR2(3) := '000' ;      		-- All
    K_MAX_DT        VARCHAR2(8) := '30000101' ; 		-- End date
    K_ALL_ACNT      VARCHAR2(10) := '9999999999' ;      -- All account
    K_ALL_SUB_NO    VARCHAR2(10) := '99' ;              -- All account
    K_INT_RT_TP     VARCHAR2(2) := '01' ;      			-- Interests type
    K_CUST_GRD      VARCHAR2(2) := '00' ;      			-- Customer grade

    K_RMRK_CD       VARCHAR2(3) := '247' ; 				-- Remark code
	K_MDM_TP        VARCHAR2(2) := '00' ; 				--
	K_CNFM_YN       VARCHAR2(1) := 'Y' ; 				--


    -- Variables
	T_STRT_DT		VN.SSB07M00.MAK_STRT_DT%TYPE ;		-- Start date
	T_END_DT		VN.SSB07M00.MAK_END_DT%TYPE ;		-- End date
    T_INT_RT      	VN.SSB07M00.APY_INT_RT%TYPE ;		-- Applied rate


    T_CNT           NUMBER := 0 ;						-- CHECK Count

    T_TOT_CNT       NUMBER := 0 ;						-- Total count
    T_PROC_CNT      NUMBER := 0 ;						-- Processed count
    T_SKIP_CNT      NUMBER := 0 ;						-- No processed count


    -- Out Variables
	O_TRD_SEQ_NO	VN.AAA10M00.TRD_SEQ_NO%TYPE ;		-- Trading sequence number

    O1_RTN_TBL      VARCHAR2(100) ;      				-- Return Table
	O1_RTN_ERR      VARCHAR2(100) ;      				-- Return Error Code
	O1_RTN_MSG      VARCHAR2(254) ;      				-- Return Message


    -- View Variables
	V_USEFEE_PAY_DT	VN.SSB07M00.USEFEE_PAY_DT%TYPE ;	-- Payment date
	V_ACNT_NO		VN.SSB07M00.ACNT_NO%TYPE ;			-- Account
	V_SUB_NO		VN.SSB07M00.SUB_NO%TYPE ;			-- Sub_no
	V_MAK_STRT_DT	VN.SSB07M00.MAK_STRT_DT%TYPE ;		-- Making strat date
	V_MAK_END_DT	VN.SSB07M00.MAK_END_DT%TYPE ;		-- Making end date
	V_TOT_DT_CNT	VN.SSB07M00.TOT_DT_CNT%TYPE ;		-- Total day
	V_TOT_QTY		VN.SSB07M00.TOT_QTY%TYPE ;			-- Stock total quantity
	V_TOT_AVBL_QTY	VN.SSB07M00.TOT_AVBL_QTY%TYPE ;		-- Stock available quantity
	V_APY_INT_RT	VN.SSB07M00.APY_INT_RT%TYPE ;		-- Applied rate
	V_USEFEE		VN.SSB07M00.USEFEE%TYPE ;			-- Stock fee
	V_ACNT_MNG_BNH	VN.SSB07M00.ACNT_MNG_BNH%TYPE ;		--
	V_AGNC_BRCH		VN.SSB07M00.AGNC_BRCH%TYPE ;		--
	V_PAY_FLAG		VARCHAR2(1) ;						-- N:New, U:Update(add), X:nothing


    -- Exceptions Declare
    ERR_SSB07M00_UPD    	EXCEPTION ;			--  Payment account saving
    ERR_SSB07M00_INS    	EXCEPTION ;			--  Payment account making
    ERR_SSB07M00_CONT    	EXCEPTION ;			--  Paymnet error contents
    ERR_SSB07M00_TRD    	EXCEPTION ;			-- Payment trading sequence
    ERR_PSS_USEFEE_PAY_P	EXCEPTION ;


-- *************************< START OF PROCEDURE >****************************
BEGIN

    BEGIN

		/* 0. Making start date and end date */
		SELECT	TRIM(I_PAY_YM) || '01'		AS	MAK_STRT_DT,
				CASE
					WHEN	VN.VHDATE	<	TO_CHAR(LAST_DAY(TO_DATE(I_PAY_YM || '01', 'YYYYMMDD')), 'YYYYMMDD')	THEN
							TO_CHAR((VN.HDATE - 1), 'YYYYMMDD')
					ELSE	TO_CHAR(LAST_DAY(TO_DATE(I_PAY_YM || '01', 'YYYYMMDD')), 'YYYYMMDD')
				END							AS	MAK_END_DT
		  INTO	T_STRT_DT,	T_END_DT
		  FROM	DUAL ;

    EXCEPTION WHEN OTHERS THEN
        T_STRT_DT	:=	TRIM(I_PAY_YM) || '01' ;
        T_END_DT	:=	TRIM(I_PAY_YM) || '31' ;
    END ;


    BEGIN

		/* 0. Getting rate */
		SELECT	NVL(v11.INT_RT, 0)		AS	INT_RT
		  INTO	T_INT_RT
		  FROM	VN.SSB08C00	v11		/* Managing rate */
		 WHERE	v11.INT_RT_TP	=	K_INT_RT_TP
		   AND	v11.CUST_GRD	=	K_CUST_GRD
		   AND	v11.END_DT		=	K_MAX_DT		/* '30000101' */
		   AND	ROWNUM			<=	1 ;

    EXCEPTION WHEN OTHERS THEN
        T_INT_RT	:=	0 ;
    END ;


    BEGIN

    	/* 1. All */
    	SELECT	A.COL_CD_TP		AS	COL_CD_TP
    	  INTO	K_ALL_BRCH
    	  FROM	VN.XCC01C01 A
         WHERE	A.COL_CD	=	'cmp_full_cd'
    	   AND	ROWNUM	<=	1 ;

    EXCEPTION WHEN OTHERS THEN
        K_ALL_BRCH	:=	'000' ;
    END ;


    /* 2. Inquiry account for paying stock fee*/
    FOR C1 IN	(
  		SELECT	v11.PAY_YM							AS	PAY_YM,
				v11.USEFEE_PAY_DT					AS	USEFEE_PAY_DT,
				v11.ACNT_NO							AS	ACNT_NO,
				v11.SUB_NO							AS	SUB_NO,
				v11.MAK_STRT_DT						AS	MAK_STRT_DT,
				v11.MAK_END_DT						AS	MAK_END_DT,
				NVL(v11.TOT_DT_CNT, 0)				AS	TOT_DT_CNT,
				NVL(v11.TOT_QTY, 0)					AS	TOT_QTY,
				NVL(v11.TOT_AVBL_QTY, 0)			AS	TOT_AVBL_QTY,
				NVL(v11.APY_INT_RT, 0)				AS	APY_INT_RT,
				ROUND((v11.APY_INT_RT / 30 ) * NVL(v11.TOT_AVBL_QTY, 0))	AS	USEFEE,
				v11.ACNT_MNG_BNH					AS	ACNT_MNG_BNH,
				v11.AGNC_BRCH						AS	AGNC_BRCH,
				v11.PAY_FLAG						AS	PAY_FLAG
		  FROM
					/* New ( same month, no history ) */
				(	SELECT	v21.PAY_YM					AS	PAY_YM,
							VN.VHDATE					AS	USEFEE_PAY_DT,
							v21.ACNT_NO					AS	ACNT_NO,
							v21.SUB_NO					AS	SUB_NO,
							TRIM(T_STRT_DT)				AS	MAK_STRT_DT,
							CASE
								WHEN	v22.ACNT_STAT	=	'2'	THEN
									CASE
										WHEN	v22.ACNT_CLS_DT	<	TRIM(T_STRT_DT)	THEN	TRIM(T_STRT_DT)
										WHEN	v22.ACNT_CLS_DT	=	TRIM(T_STRT_DT)	THEN	TRIM(T_STRT_DT)
										WHEN	v22.ACNT_CLS_DT	>	TRIM(T_STRT_DT)	AND
												v22.ACNT_CLS_DT	<	TRIM(T_END_DT)	THEN	v22.ACNT_CLS_DT
										ELSE	TRIM(T_END_DT)
									END
								ELSE	TRIM(T_END_DT)
							END							AS	MAK_END_DT,
							CASE
								WHEN	v22.ACNT_STAT	=	'2'	THEN
									CASE
										WHEN	v22.ACNT_CLS_DT	<	TRIM(T_STRT_DT)	THEN
												(TO_DATE(TRIM(T_STRT_DT), 'YYYYMMDD') -
													TO_DATE(TRIM(T_STRT_DT), 'YYYYMMDD')) + 1
										WHEN	v22.ACNT_CLS_DT	=	TRIM(T_STRT_DT)	THEN
												(TO_DATE(TRIM(T_STRT_DT), 'YYYYMMDD') -
													TO_DATE(TRIM(T_STRT_DT), 'YYYYMMDD')) + 1
										WHEN	v22.ACNT_CLS_DT	>	TRIM(T_STRT_DT)	AND
												v22.ACNT_CLS_DT	<	TRIM(T_END_DT)	THEN
												(TO_DATE(TRIM(v22.ACNT_CLS_DT), 'YYYYMMDD') -
													TO_DATE(TRIM(T_STRT_DT), 'YYYYMMDD')) + 1
										ELSE	(TO_DATE(TRIM(T_END_DT), 'YYYYMMDD') -
													TO_DATE(TRIM(T_STRT_DT), 'YYYYMMDD')) + 1
									END
								ELSE	(TO_DATE(TRIM(T_END_DT), 'YYYYMMDD') -
											TO_DATE(TRIM(T_STRT_DT), 'YYYYMMDD')) + 1
							END							AS	TOT_DT_CNT,		/* total day count */
							NVL(v21.TOT_QTY, 0)			AS	TOT_QTY,
							CASE
								WHEN	NVL(v21.TOT_QTY, 0)	> 0	THEN
										NVL(v21.TOT_QTY, 0) / 10
								ELSE	0
							END							AS	TOT_AVBL_QTY,
							NVL(T_INT_RT, 0)			AS	APY_INT_RT,
							v22.ACNT_STAT				AS	ACNT_STAT,
							v22.ACNT_CLS_DT				AS	ACNT_CLS_DT,
							v22.ACNT_MNG_BNH			AS	ACNT_MNG_BNH,
							v22.AGNC_BRCH				AS	AGNC_BRCH,
							CASE
								WHEN	v22.ACNT_STAT	=	'2'	THEN
									CASE
										WHEN	v22.ACNT_CLS_DT	<	TRIM(T_STRT_DT)	THEN	'X'
										WHEN	v22.ACNT_CLS_DT	=	TRIM(T_STRT_DT)	THEN	'N'
										WHEN	v22.ACNT_CLS_DT	>	TRIM(T_STRT_DT)	AND
												v22.ACNT_CLS_DT	<	TRIM(T_END_DT)	THEN	'N'
										ELSE	'N'
									END
								ELSE	'N'
							END							AS	PAY_FLAG
					  FROM
							(	SELECT	TRIM(I_PAY_YM)				AS	PAY_YM,
										v31.ACNT_NO					AS	ACNT_NO,
										v31.SUB_NO					AS	SUB_NO,
										SUM(NVL(v31.OWN_QTY, 0))	AS	TOT_QTY
								  FROM	(
								   SELECT a.rgt_std_dt dt, a.*
								   FROM VN.SSB01H00	a	/* ?????? */
								   WHERE	a.RGT_STD_DT	>=	T_STRT_DT
								     AND	a.RGT_STD_DT	<=	T_END_DT
								     AND	a.RGT_STD_DT	<>	VN.VHDATE
								     AND	a.ACNT_NO		=	DECODE(I_ACNT_NO,  K_ALL_ACNT, a.ACNT_NO, I_ACNT_NO)
								     AND	a.SUB_NO		=	DECODE(I_SUB_NO ,  K_ALL_SUB_NO, a.SUB_NO, I_SUB_NO)

								   /*NGUYEN: tinh phi cho cac ngay khong phai working day trong khoang thoi gian tra cuu*/
								   UNION
								   SELECT b.dt,a.*
								    FROM vn.ssb01h00 a,
										(SELECT to_char(dt_dt, 'yyyymmdd')dt FROM vn.xcc20m00
										WHERE  to_char(dt_dt, 'yyyymmdd') >= T_STRT_DT AND  to_char(dt_dt, 'yyyymmdd') <= T_END_DT
										AND holi_tp IN (1,2,3)) b
									WHERE rgt_std_dt = vn.fxc_vorderdt_g(to_date(b.dt,'yyyymmdd'),-1)
									AND	a.RGT_STD_DT	>=	T_STRT_DT
									AND	a.RGT_STD_DT	<=	T_END_DT
									AND	a.RGT_STD_DT	<>	VN.VHDATE
									AND	a.ACNT_NO		=	DECODE(I_ACNT_NO,  K_ALL_ACNT, a.ACNT_NO, I_ACNT_NO)
								    AND	a.SUB_NO		=	DECODE(I_SUB_NO ,  K_ALL_SUB_NO, a.SUB_NO, I_SUB_NO)
								   ) v31

							  GROUP BY	TRIM(I_PAY_YM),
										v31.ACNT_NO,
                                        v31.SUB_NO
								HAVING	SUM(NVL(v31.OWN_QTY, 0))	>	0
							)			v21,
							VN.AAA01M00	v22
					 WHERE	v21.ACNT_NO		=	v22.ACNT_NO
					   AND  v21.SUB_NO      =   v22.SUB_NO
					   AND	v22.ACNT_STAT	=	'1'
				)			v11
		 WHERE	ROUND((v11.APY_INT_RT / 30 ) * NVL(v11.TOT_AVBL_QTY, 0))	>	0
		   AND	v11.PAY_FLAG	<>	'X'
	  ORDER BY	v11.ACNT_NO, v11.SUB_NO

        ) LOOP


		V_USEFEE_PAY_DT		:= C1.USEFEE_PAY_DT ;
		V_ACNT_NO			:= C1.ACNT_NO ;
		V_SUB_NO			:= C1.SUB_NO ;
		V_TOT_DT_CNT		:= C1.TOT_DT_CNT ;
		V_TOT_QTY			:= C1.TOT_QTY ;
		V_TOT_AVBL_QTY		:= C1.TOT_AVBL_QTY ;
		V_APY_INT_RT		:= C1.APY_INT_RT ;
		V_USEFEE			:= C1.USEFEE ;
		V_ACNT_MNG_BNH		:= C1.ACNT_MNG_BNH ;
		V_AGNC_BRCH			:= C1.AGNC_BRCH ;

		V_MAK_STRT_DT		:= C1.MAK_STRT_DT ;
		V_MAK_END_DT		:= C1.MAK_END_DT ;
		V_PAY_FLAG			:= C1.PAY_FLAG ;


		T_TOT_CNT := T_TOT_CNT + 1 ;

		/* 3. Same month but exist history */
		T_CNT	:=	0 ;

    	BEGIN

			SELECT	COUNT(*)
			  INTO	T_CNT
			  FROM	VN.SSB07M00	v11
			 WHERE	v11.ACNT_NO			=	V_ACNT_NO
			   AND  v11.SUB_NO          =   v_SUB_NO
			   AND	v11.RCPT_TRD_NO		<>	0
			   AND	v11.CNCL_TRD_NO		=	0
			   AND	(v11.MAK_STRT_DT	>=	T_STRT_DT
			   AND	v11.MAK_STRT_DT		<=	T_END_DT)
			   AND	(v11.MAK_END_DT		>=	T_STRT_DT
			   AND	v11.MAK_END_DT		<=	T_END_DT) ;

	    EXCEPTION WHEN OTHERS THEN
			T_CNT	:=	0 ;
	    END ;


        IF  T_CNT   >  0   THEN

			/* 4. Same month, exist history making start date and end date */
	    	BEGIN

				SELECT	v21.MAK_STRT_DT			AS	MAK_STRT_DT,
						v21.MAK_END_DT			AS	MAK_END_DT,
						v21.PAY_FLAG			AS	PAY_FLAG
				  INTO	V_MAK_STRT_DT,	V_MAK_END_DT,	V_PAY_FLAG
				  FROM
						(	SELECT	CASE
										WHEN	(v31.MAK_END_DT	>	T_STRT_DT)	AND
												(v31.MAK_END_DT	<	T_END_DT)	THEN
												TO_CHAR((TO_DATE(v31.MAK_END_DT, 'YYYYMMDD') + 1), 'YYYYMMDD')
										ELSE	TRIM(T_END_DT)
									END						AS	MAK_STRT_DT,
									TRIM(T_END_DT)			AS	MAK_END_DT,
									CASE
										WHEN	(v31.MAK_END_DT	>	T_STRT_DT)	AND
												(v31.MAK_END_DT	<	T_END_DT)		THEN	'U'
										ELSE	'X'
									END						AS	PAY_FLAG
							  FROM	VN.SSB07M00	v31
							 WHERE	v31.USEFEE_PAY_DT		=	(	SELECT	MAX(v41.USEFEE_PAY_DT)	AS	USEFEE_PAY_DT
																	  FROM	VN.SSB07M00	v41
																	 WHERE	v41.ACNT_NO			=	V_ACNT_NO
																	   AND  v41.SUB_NO          =   V_SUB_NO
																	   AND	v41.RCPT_TRD_NO		<>	0
																	   AND	v41.CNCL_TRD_NO		=	0
																	   AND	(v41.MAK_STRT_DT	>=	T_STRT_DT
																	   AND	v41.MAK_STRT_DT		<=	T_END_DT)
																	   AND	(v41.MAK_END_DT		>=	T_STRT_DT
																	   AND	v41.MAK_END_DT		<=	T_END_DT)
																)
							   AND	v31.ACNT_NO			=	V_ACNT_NO
							   AND  v31.SUB_NO          =   V_SUB_NO
							   AND	v31.RCPT_TRD_NO		<>	0
							   AND	v31.CNCL_TRD_NO		=	0
						)			v21 ;


		    EXCEPTION WHEN OTHERS THEN
				V_MAK_STRT_DT		:= C1.MAK_STRT_DT ;
				V_MAK_END_DT		:= C1.MAK_END_DT ;
				V_PAY_FLAG			:= C1.PAY_FLAG ;
		    END;


			/* 5. Same month, exist history making account */
	    	BEGIN

				SELECT	NVL(v21.TOT_DT_CNT, 0)				AS	TOT_DT_CNT,
						NVL(v21.TOT_QTY, 0)					AS	TOT_QTY,
						NVL(v21.TOT_AVBL_QTY, 0)			AS	TOT_AVBL_QTY,
						NVL(v21.APY_INT_RT, 0)				AS	APY_INT_RT,
						ROUND((v21.APY_INT_RT / 30 ) * NVL(v21.TOT_AVBL_QTY, 0))	AS	USEFEE
				  INTO	V_TOT_DT_CNT,	V_TOT_QTY,	V_TOT_AVBL_QTY,	V_APY_INT_RT,	V_USEFEE
				  FROM

						(	SELECT	v31.ACNT_NO					AS	ACNT_NO,
									v31.SUB_NO                  AS  SUB_NO ,
									(TO_DATE(TRIM(V_MAK_STRT_DT), 'YYYYMMDD') -
										TO_DATE(TRIM(V_MAK_END_DT), 'YYYYMMDD')) + 1		AS	TOT_DT_CNT,
									NVL(v31.TOT_QTY, 0)			AS	TOT_QTY,
									CASE
										WHEN	NVL(v31.TOT_QTY, 0)	> 0	THEN
												NVL(v31.TOT_QTY, 0) / 10
										ELSE	0
									END							AS	TOT_AVBL_QTY,
									NVL(v33.INT_RT, 0)			AS	APY_INT_RT
							  FROM
									(	SELECT	v41.ACNT_NO					AS	ACNT_NO,
												v41.SUB_NO                  AS  SUB_NO,
												SUM(NVL(v41.OWN_QTY, 0))	AS	TOT_QTY

										FROM
										(
											SELECT a.ACNT_NO AS ACNT_NO,
												   a.SUB_NO  AS SUB_NO ,
											       NVL(a.OWN_QTY, 0) AS  OWN_QTY
										  FROM	VN.SSB01H00	a
										 WHERE	a.RGT_STD_DT	>=	V_MAK_STRT_DT
										   AND	a.RGT_STD_DT	<=	V_MAK_END_DT
										   AND	a.RGT_STD_DT	<>	VN.VHDATE
										   AND	a.ACNT_NO		=	V_ACNT_NO
										   AND  a.SUB_NO        =   V_SUB_NO

										UNION ALL
										  SELECT a.ACNT_NO AS ACNT_NO,
												 a.SUB_NO AS SUB_NO,
												NVL(a.OWN_QTY, 0)          AS  OWN_QTY
										FROM vn.ssb01h00 a,
										  (SELECT to_char(dt_dt, 'yyyymmdd')dt FROM vn.xcc20m00
										  WHERE  to_char(dt_dt, 'yyyymmdd') >= V_MAK_STRT_DT AND  to_char(dt_dt, 'yyyymmdd') <= V_MAK_END_DT
										  AND holi_tp IN (1,2,3)) b
										WHERE rgt_std_dt = vn.fxc_vorderdt_g(to_date(b.dt,'yyyymmdd'),-1)
										AND a.acnt_no        =  V_ACNT_NO
										AND a.SUB_NO         =  V_SUB_NO
										AND	a.RGT_STD_DT	>=	V_MAK_STRT_DT
										AND	a.RGT_STD_DT	<=	V_MAK_END_DT
									) v41
									  GROUP BY	v41.ACNT_NO, v41.SUB_NO
										HAVING	SUM(NVL(v41.OWN_QTY, 0))	>	0
									)			v31,
									VN.AAA01M00	v32,
									(	SELECT	v41.INT_RT		AS	INT_RT
										  FROM	VN.SSB08C00	v41
										 WHERE	v41.INT_RT_TP	=	K_INT_RT_TP
										   AND	v41.CUST_GRD	=	K_CUST_GRD
										   AND	v41.END_DT		=	K_MAX_DT		/* '30000101' */
									)			v33
							 WHERE	v31.ACNT_NO		=	v32.ACNT_NO
							   AND  v32.SUB_NO      =   v32.SUB_NO
							   AND	v32.ACNT_STAT	=	'1'
						)			v21
				 WHERE	ROUND((v21.APY_INT_RT / 30 ) * NVL(v21.TOT_AVBL_QTY, 0))	>	0
			  ORDER BY	v21.ACNT_NO, v21.SUB_NO ;

		    EXCEPTION WHEN OTHERS THEN
				V_TOT_DT_CNT		:= C1.TOT_DT_CNT ;
				V_TOT_QTY			:= C1.TOT_QTY ;
				V_TOT_AVBL_QTY		:= C1.TOT_AVBL_QTY ;
				V_APY_INT_RT		:= C1.APY_INT_RT ;
				V_USEFEE			:= C1.USEFEE ;
		    END ;

        END IF ;		-- T_CNT > 0 End If


		IF  V_PAY_FLAG   NOT IN	('X') THEN

			T_CNT	:=	0 ;

			SELECT	COUNT(*)
			  INTO	T_CNT
			  FROM	VN.SSB07M00
			 WHERE	USEFEE_PAY_DT	=	V_USEFEE_PAY_DT
			   AND	ACNT_NO			=	V_ACNT_NO
			   AND	SUB_NO			=	V_SUB_NO
			   AND	RCPT_TRD_NO		=	0
			   AND	CNCL_TRD_NO		=	0 ;

			IF	T_CNT	>	0	THEN

				/* 3. Save payment account */
		    	BEGIN

					UPDATE	VN.SSB07M00
					  SET	MAK_STRT_DT		=	V_MAK_STRT_DT,
							MAK_END_DT		=	V_MAK_END_DT,
							TOT_DT_CNT		=	V_TOT_DT_CNT,
							TOT_QTY			=	V_TOT_QTY,
							TOT_AVBL_QTY	=	V_TOT_AVBL_QTY,
							APY_INT_RT		=	V_APY_INT_RT,
							USEFEE			=	V_USEFEE,
							ACNT_MNG_BNH	=	V_ACNT_MNG_BNH,
							AGNC_BRCH		=	V_AGNC_BRCH,
							WORK_MN			=	I_WORK_MN,
							WORK_DTM		=	SYSDATE,
							WORK_TRM		=	I_WORK_TRM
					 WHERE	USEFEE_PAY_DT	=	V_USEFEE_PAY_DT
					   AND	ACNT_NO			=	V_ACNT_NO
					   AND  SUB_NO          =   V_SUB_NO
					   AND	RCPT_TRD_NO		=	0
					   AND	CNCL_TRD_NO		=	0 ;

			    EXCEPTION WHEN OTHERS THEN
		        	RAISE ERR_SSB07M00_UPD ;
			    END ;

			ELSE

				/* 6. New */
		    	BEGIN

		            INSERT	INTO VN.SSB07M00(
							USEFEE_PAY_DT,
							ACNT_NO,
							SUB_NO,
							MAK_STRT_DT,
							MAK_END_DT,
							TOT_DT_CNT,
							TOT_QTY,
							TOT_AVBL_QTY,
							APY_INT_RT,
							USEFEE,
							ACNT_MNG_BNH,
							AGNC_BRCH,
							RCPT_TRD_NO,
							ERR_CONT,
							CNCL_YN,
							CNCL_TRD_NO,
							WORK_MN,
							WORK_DTM,
							WORK_TRM )
		            VALUES  (
							V_USEFEE_PAY_DT,
							V_ACNT_NO,
							V_SUB_NO,
							V_MAK_STRT_DT,
							V_MAK_END_DT,
							V_TOT_DT_CNT,
							V_TOT_QTY,
							V_TOT_AVBL_QTY,
							V_APY_INT_RT,
							V_USEFEE,
							V_ACNT_MNG_BNH,
							V_AGNC_BRCH,
							0,
							NULL,
							'N',
							0,
							I_WORK_MN,
							SYSDATE,
							I_WORK_TRM ) ;

			    EXCEPTION WHEN OTHERS THEN
	        		RAISE ERR_SSB07M00_INS ;
			    END ;

	        END IF ;		-- T_CNT > 0 End If

			T_PROC_CNT := T_PROC_CNT + 1 ;

	    	O_TRD_SEQ_NO	:=	0 ;
		    O1_RTN_TBL		:=	NULL ;
			O1_RTN_ERR		:=	NULL ;
			O1_RTN_MSG		:=	NULL ;

			/* 2. Call withdrawal procedure */
		    VN.PSS_CASH_OUTAMT_P(
		        V_USEFEE_PAY_DT,
		        V_ACNT_NO,
				V_SUB_NO,
		        K_RMRK_CD,
		        V_USEFEE,
		        K_MDM_TP,
		        I_TR_CD,
		        K_CNFM_YN,
		        I_DEPT_NO1,
		        I_WORK_MN,
		        I_WORK_TRM,
				O_TRD_SEQ_NO,
			    O1_RTN_TBL,
				O1_RTN_ERR,
				O1_RTN_MSG
				) ;

			IF	TO_NUMBER(O1_RTN_ERR)	<>	0	THEN

			vn.pxc_log_write('pss_fix_usefee_pay_b', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG|| ']') ;

				/* 3. UPdate error contents */
		    	BEGIN

					UPDATE	VN.SSB07M00
					  SET	RCPT_TRD_NO		=	0,
							ERR_CONT		=	SUBSTR('[' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG || ']', 1, 254)
					 WHERE	USEFEE_PAY_DT	=	V_USEFEE_PAY_DT
					   AND	ACNT_NO			=	V_ACNT_NO
					   AND  SUB_NO          =   V_SUB_NO
					   AND	RCPT_TRD_NO		=	0
					   AND	CNCL_TRD_NO		=	0 ;

			    EXCEPTION WHEN OTHERS THEN
		        	RAISE ERR_SSB07M00_CONT ;
			    END ;

			ELSE

				/* 3. Update withdrawal trading sequence */
		    	BEGIN

					UPDATE	VN.SSB07M00
					  SET	RCPT_TRD_NO		=	O_TRD_SEQ_NO,
							ERR_CONT		=	NULL
					 WHERE	USEFEE_PAY_DT	=	V_USEFEE_PAY_DT
					   AND	ACNT_NO			=	V_ACNT_NO
					   AND  SUB_NO          =   V_SUB_NO
					   AND	RCPT_TRD_NO		=	0
					   AND	CNCL_TRD_NO		=	0 ;

			    EXCEPTION WHEN OTHERS THEN
		        	RAISE ERR_SSB07M00_TRD ;
			    END ;

			END IF ;

		ELSE

			T_SKIP_CNT := T_SKIP_CNT + 1 ;

        END IF ;		-- V_PAY_FLAG   NOT IN	('X') End If


    END LOOP ;   -- C1 End Loop

    O_RTN_TBL  :=  'PSS_FIX_USEFEE_PAY_B' ;
    O_RTN_ERR  :=  '0' ;
    O_RTN_MSG  :=  SUBSTR('PAY_YM:(' || I_PAY_YM || ') USEFEE_PAY_DT:(' || V_USEFEE_PAY_DT || ') Count:(' || TO_CHAR(T_PROC_CNT) || ') 정상적으로 처리되었습니다.', 1, 254) ;
	vn.pxc_log_write('pss_fix_usefee_pay_b', ' [' || O_RTN_ERR || '] [' || O_RTN_TBL || '] [' || O_RTN_MSG|| ']') ;
     --O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','0602') ;

EXCEPTION
    WHEN    ERR_SSB07M00_UPD  THEN
        O_RTN_TBL  :=  'ERR_SSB07M00_UPD' ;
        O_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O_RTN_MSG  :=  SUBSTR('ERROR ' || 'PAY_YM:(' || I_PAY_YM || ') USEFEE_PAY_DT:(' || V_USEFEE_PAY_DT || ') ACNT_NO:(' || V_ACNT_NO || ')', 1, 254) ;
		vn.pxc_log_write('pss_fix_usefee_pay_b', ' [' || O_RTN_ERR || '] [' || O_RTN_TBL || '] [' || O_RTN_MSG|| ']') ;
        --O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') ;
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG) ;
    WHEN    ERR_SSB07M00_INS  THEN
        O_RTN_TBL  :=  'ERR_SSB07M00_INS' ;
        O_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O_RTN_MSG  :=  SUBSTR('ERROR ' || 'PAY_YM:(' || I_PAY_YM || ') USEFEE_PAY_DT:(' || V_USEFEE_PAY_DT || ') ACNT_NO:(' || V_ACNT_NO || ')', 1, 254) ;
		vn.pxc_log_write('pss_fix_usefee_pay_b', ' [' || O_RTN_ERR || '] [' || O_RTN_TBL || '] [' || O_RTN_MSG|| ']') ;
        --O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') ;
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG) ;
    WHEN    ERR_SSB07M00_CONT  THEN
        O_RTN_TBL  :=  'ERR_SSB07M00_CONT' ;
        O_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O_RTN_MSG  :=  SUBSTR('ERROR ' || 'PAY_YM:(' || I_PAY_YM || ') USEFEE_PAY_DT:(' || V_USEFEE_PAY_DT || ') ACNT_NO:(' || V_ACNT_NO || ')', 1, 254) ;
		vn.pxc_log_write('pss_fix_usefee_pay_b', ' [' || O_RTN_ERR || '] [' || O_RTN_TBL || '] [' || O_RTN_MSG|| ']') ;
        --O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') ;
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG) ;
    WHEN    ERR_SSB07M00_TRD  THEN
        O_RTN_TBL  :=  'ERR_SSB07M00_TRD' ;
        O_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O_RTN_MSG  :=  SUBSTR('ERROR ' || 'PAY_YM:(' || I_PAY_YM || ') USEFEE_PAY_DT:(' || V_USEFEE_PAY_DT || ') ACNT_NO:(' || V_ACNT_NO || ')', 1, 254) ;
		vn.pxc_log_write('pss_fix_usefee_pay_b', ' [' || O_RTN_ERR || '] [' || O_RTN_TBL || '] [' || O_RTN_MSG|| ']') ;
        --O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') ;
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG) ;
    WHEN    OTHERS  THEN
        O_RTN_TBL  :=  'OTHERS [PSS_FIX_USEFEE_PAY_B]' ;
        O_RTN_ERR  :=  TO_CHAR(SQLCODE) ;
        O_RTN_MSG  :=  SUBSTR('ERROR ' || SQLERRM, 1, 254) ;
		vn.pxc_log_write('pss_fix_usefee_pay_b', ' [' || O_RTN_ERR || '] [' || O_RTN_TBL || '] [' || O_RTN_MSG|| ']') ;
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG) ;
END PSS_FIX_USEFEE_PAY_B ;
/

