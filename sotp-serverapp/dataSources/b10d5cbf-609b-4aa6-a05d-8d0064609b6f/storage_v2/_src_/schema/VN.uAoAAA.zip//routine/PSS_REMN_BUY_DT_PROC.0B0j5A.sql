create procedure  pss_remn_buy_dt_proc
 ( i_proc_dt    in   varchar2,
   i_acnt_no    in   varchar2,
   i_sub_no     in   varchar2,
   i_stk_cd     in   varchar2,
   i_tp         in   varchar2,
   i_qty        in   number
 ) is

 vn_count    number;
 vn_count2   number;
 vn_count3   number;
 vn_count4   number;
 vn_out_qty  number;
 vn_own_qty  number;
 vs_stk_tp   varchar2(2);

begin

 vn.pxc_log_write('pss_remn_buy_dt_proc', 'start');

 select  vn.fss_get_stk_tp(i_stk_cd)
 into    vs_stk_tp
 from    dual;

 if  vs_stk_tp <> '10' and vs_stk_tp <> '20' and vs_stk_tp <> '30'  then
     raise_application_error(-20100, '��������߸� �Ǿ����ϴ�');
 end if;

end  pss_remn_buy_dt_proc;
/

