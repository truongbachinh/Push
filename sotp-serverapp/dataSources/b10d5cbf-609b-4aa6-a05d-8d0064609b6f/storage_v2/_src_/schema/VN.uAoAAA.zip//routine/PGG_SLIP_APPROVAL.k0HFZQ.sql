create PROCEDURE PGG_SLIP_APPROVAL
   (
   I_WORK_TP       IN      VARCHAR2,       -- 'A' : Approval, 'C' : Approval Cancel, 'R' :Return, 'X' : DisUse
   I_BRCH_CD       IN      VARCHAR2,       -- ??
   I_AGNC_BRCH     IN      VARCHAR2,       -- ????
   I_SLIP_DT       IN      VARCHAR2,       -- SLIP DATE
   I_SLIP_NO       IN      VARCHAR2,       -- SLIP No.
   I_CNFM_NM       IN      VARCHAR2
   ) IS
   -- VARIABLES
   -- VARIABLES

/* 2008/05/30 SeoHaeSeok Modify : ��� ��ǥ��üũ */
/* Start ------------------------------*/
   T_OLD_SLIP_STAT	VARCHAR2(1) := '0' ;   -- ��ǥ��1:�̽��2:���3:�ݷ�,4:���
   T_AUTO_TP		VARCHAR2(1) := '1' ;   -- �ڵ�����1:�ڵ�,2:����)
/* End --------------------------------*/

BEGIN
   IF I_WORK_TP <> 'R' THEN
       FOR C1 IN
            (
             SELECT  X.AUTO_TP,
                     X.ACC_ACT_CD,
                     DECODE(I_WORK_TP,'A',   SUM(DR_CASH_CNT)
                                     ,'C', - SUM(DR_CASH_CNT)
                                     ,'X', - SUM(DR_CASH_CNT), 0) DR_CASH_CNT,
                     DECODE(I_WORK_TP,'A',   SUM(DR_EXCH_CNT)
                                     ,'C', - SUM(DR_EXCH_CNT)
                                     ,'X', - SUM(DR_EXCH_CNT), 0) DR_EXCH_CNT,
                     DECODE(I_WORK_TP,'A',   SUM(DR_CASH_AMT)
                                     ,'C', - SUM(DR_CASH_AMT)
                                     ,'X', - SUM(DR_CASH_AMT), 0) DR_CASH_AMT,
                     DECODE(I_WORK_TP,'A',   SUM(DR_EXCH_AMT)
                                     ,'C', - SUM(DR_EXCH_AMT)
                                     ,'X', - SUM(DR_EXCH_AMT), 0) DR_EXCH_AMT,
                     DECODE(I_WORK_TP,'A',   SUM(CR_CASH_CNT)
                                     ,'C', - SUM(CR_CASH_CNT)
                                     ,'X', - SUM(CR_CASH_CNT), 0) CR_CASH_CNT,
                     DECODE(I_WORK_TP,'A',   SUM(CR_EXCH_CNT)
                                     ,'C', - SUM(CR_EXCH_CNT)
                                     ,'X', - SUM(CR_EXCH_CNT), 0) CR_EXCH_CNT,
                     DECODE(I_WORK_TP,'A',   SUM(CR_CASH_AMT)
                                     ,'C', - SUM(CR_CASH_AMT)
                                     ,'X', - SUM(CR_CASH_AMT), 0) CR_CASH_AMT,
                     DECODE(I_WORK_TP,'A',   SUM(CR_EXCH_AMT)
                                     ,'C', - SUM(CR_EXCH_AMT)
                                     ,'X', - SUM(CR_EXCH_AMT), 0) CR_EXCH_AMT
             FROM    (
                         SELECT  A.AUTO_TP         AS  AUTO_TP,
                                 A.SLIP_TP         AS  SLIP_TP,
                                 A.DR_CR_TP        AS  DR_CR_TP,
                                 A.ACC_ACT_CD      AS  ACC_ACT_CD,
                                 DECODE(A.DR_CR_TP||A.SLIP_TP, '11', 1
                                                             , '12', 1,0)                AS  DR_CASH_CNT,
                                 DECODE(A.DR_CR_TP||A.SLIP_TP, '13', 1
                                                             , '14', 1
                                                             , '15', 1
                                                             , '16', 1
                                                             , '17', 1
                                                             , '18', 1
                                                             , '19', 1
                                                             , '1A', 1,0)                AS  DR_EXCH_CNT,

                                 DECODE(A.DR_CR_TP||A.SLIP_TP, '11', A.SLIP_AMT
                                                             , '12', A.SLIP_AMT,0)       AS  DR_CASH_AMT,
                                 DECODE(A.DR_CR_TP||A.SLIP_TP, '13', A.SLIP_AMT
                                                             , '14', A.SLIP_AMT
                                                             , '15', A.SLIP_AMT
                                                             , '16', A.SLIP_AMT
                                                             , '17', A.SLIP_AMT
                                                             , '18', A.SLIP_AMT
                                                             , '19', A.SLIP_AMT
                                                             , '1A', A.SLIP_AMT,0)       AS  DR_EXCH_AMT,

                                 DECODE(A.DR_CR_TP||A.SLIP_TP, '21', 1
                                                             , '22', 1,0)                AS  CR_CASH_CNT,
                                 DECODE(A.DR_CR_TP||A.SLIP_TP, '23', 1
                                                             , '24', 1
                                                             , '25', 1
                                                             , '26', 1
                                                             , '27', 1
                                                             , '28', 1
                                                             , '29', 1
                                                             , '2A', 1,0)                AS  CR_EXCH_CNT,

                                 DECODE(A.DR_CR_TP||A.SLIP_TP, '21', A.SLIP_AMT
                                                             , '22', A.SLIP_AMT,0)       AS  CR_CASH_AMT,
                                 DECODE(A.DR_CR_TP||A.SLIP_TP, '23', A.SLIP_AMT
                                                             , '24', A.SLIP_AMT
                                                             , '25', A.SLIP_AMT
                                                             , '26', A.SLIP_AMT
                                                             , '27', A.SLIP_AMT
                                                             , '28', A.SLIP_AMT
                                                             , '29', A.SLIP_AMT
                                                             , '2A', A.SLIP_AMT,0)       AS  CR_EXCH_AMT
                         FROM    VN.GGA06M00 A
                         WHERE  A.BRCH_CD     = I_BRCH_CD
                         AND    A.AGNC_BRCH   = I_AGNC_BRCH
                         AND    A.SLIP_DT     = I_SLIP_DT
                         AND    A.SLIP_NO     = I_SLIP_NO
                      ) X
             GROUP BY X.AUTO_TP, X.ACC_ACT_CD
            ) LOOP

           IF I_WORK_TP = 'X' AND C1.AUTO_TP = '2' THEN
             VN.PGG_ACCM_DAILY(
                               I_SLIP_DT        ,       -- ????
                               I_BRCH_CD        ,       -- ??
                               '00'             ,       -- ????
                               0    ,       -- ????
                               0   ,
                               0   ,
                               0   ,
                               0   ,
                               0   ,
                               0   ,
                               0   ,
                               0   ,
                               'SYSTEM'              -- ???
                              );
           ELSE

             VN.PGG_ACCM_DAILY(
                               I_SLIP_DT        ,       -- ????
                               I_BRCH_CD        ,       -- ??
                               '00'             ,       -- ????
                               C1.ACC_ACT_CD    ,       -- ????
                               C1.DR_EXCH_CNT   ,
                               C1.DR_EXCH_AMT   ,
                               C1.DR_CASH_CNT   ,
                               C1.DR_CASH_AMT   ,
                               C1.CR_EXCH_CNT   ,
                               C1.CR_EXCH_AMT   ,
                               C1.CR_CASH_CNT   ,
                               C1.CR_CASH_AMT   ,
                               'SYSTEM'              -- ???
                              );
            END IF;

       END LOOP;
   END IF;

/* 2008/05/30 SeoHaeSeok Modify : ��� ��ǥ��üũ */
/* Start ------------------------------*/
    BEGIN
		SELECT	NVL(A.SLIP_STAT, '0'),	A.AUTO_TP
    	  INTO	T_OLD_SLIP_STAT,		T_AUTO_TP
		  FROM	VN.GGA06M00	A
		 WHERE	A.SLIP_DT	=	I_SLIP_DT
		   AND	A.BRCH_CD	=	I_BRCH_CD
		   AND	A.AGNC_BRCH	=	I_AGNC_BRCH
		   AND	A.SLIP_NO	=	I_SLIP_NO
		   AND	ROWNUM		<=	1 ;

    EXCEPTION WHEN OTHERS THEN
        T_OLD_SLIP_STAT := '0';
    END;

    IF  T_OLD_SLIP_STAT  =   '0' THEN
        RAISE_APPLICATION_ERROR(-20001,'OLD_SLIP_STAT ['|| T_OLD_SLIP_STAT ||'] Error!!!');
    END IF;

    IF  I_WORK_TP  =   'A' THEN		/* �������ô������ǥ��� [1:�̽�� ��̿����*/
	    IF  T_OLD_SLIP_STAT  !=   '1' THEN
        	RAISE_APPLICATION_ERROR(-20001,'OLD_SLIP_STAT ['|| T_OLD_SLIP_STAT ||'] Approval Error!!!');
	    END IF;
	ELSIF  I_WORK_TP  =   'C' THEN		/* �������ô������ǥ��� [2:��� ��̿����*/
	    IF  T_OLD_SLIP_STAT  !=   '2' THEN
        	RAISE_APPLICATION_ERROR(-20001,'OLD_SLIP_STAT ['|| T_OLD_SLIP_STAT ||'] Approval Cancel Error!!!');
	    END IF;
	ELSIF  I_WORK_TP  =   'R' THEN		/* �ݷ�ó���ô������ǥ��� [1:�̽��]��̿����*/
	    IF  T_OLD_SLIP_STAT  !=   '1' THEN
        	RAISE_APPLICATION_ERROR(-20001,'OLD_SLIP_STAT ['|| T_OLD_SLIP_STAT ||'] Return Error!!!');
	    END IF;
	ELSIF  I_WORK_TP  =   'X' THEN		/* ������ô������ǥ��� [1:�̽�� �̰ų� [3:�ݷ�] ��̿����*/
	    IF  T_AUTO_TP  =   '1' THEN
		    IF  T_OLD_SLIP_STAT  NOT IN ('1', '2', '3') THEN
	        	RAISE_APPLICATION_ERROR(-20001,'OLD_SLIP_STAT ['|| T_OLD_SLIP_STAT ||'] DisUse Error!!!');
		    END IF;
		ELSIF	T_AUTO_TP  =   '2' THEN
		    IF  T_OLD_SLIP_STAT  NOT IN ('1', '3') THEN
	        	RAISE_APPLICATION_ERROR(-20001,'OLD_SLIP_STAT ['|| T_OLD_SLIP_STAT ||'] DisUse Error!!!');
		    END IF;
	    END IF;
	ELSE
        RAISE_APPLICATION_ERROR(-20001,'I_WORK_TP ['|| I_WORK_TP ||'] Error!!!');
    END IF;
/* End --------------------------------*/


   BEGIN
      UPDATE VN.GGA06M00 A
      SET    A.SLIP_STAT = DECODE(I_WORK_TP,'A','2'
                                           ,'C','1'
                                           ,'R','3'
                                           ,'X','4',A.SLIP_STAT),
             A.CNFM_MN     = I_CNFM_NM,
             A.CNFM_DTM    = SYSDATE
      WHERE  A.BRCH_CD     = I_BRCH_CD
      AND    A.AGNC_BRCH   = I_AGNC_BRCH
      AND    A.SLIP_DT     = I_SLIP_DT
      AND    A.SLIP_NO     = I_SLIP_NO
      ;
   END;

EXCEPTION WHEN OTHERS THEN
  RAISE_APPLICATION_ERROR(-20001,'P:'||SUBSTR(SQLERRM, 5, 78));

END PGG_SLIP_APPROVAL;
/

