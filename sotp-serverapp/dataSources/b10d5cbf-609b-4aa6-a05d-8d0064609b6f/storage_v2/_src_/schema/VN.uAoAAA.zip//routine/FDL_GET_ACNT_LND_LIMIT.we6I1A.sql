create FUNCTION    fdl_get_acnt_lnd_limit(i_acnt_no VARCHAR2,
                                                     i_sub_no  VARCHAR2,
                                                     i_item_tp VARCHAR2,
                                                     i_item_cd VARCHAR2,
                                                     i_day_tp  VARCHAR2)
  RETURN NUMBER AS
  /*!
     \file     fdl_get_acnt_lnd_limit.sql
     \brief    fdl_get_acnt_lnd_limit
     \section intro Program Information
          - Program Name              :
          - Service Name              :
          - Related Client Program- Client Program ID :
          - Related Tables            : dlm20m05, dlm09m10, dlm00m01
          - Dev. Date                 : 2018/05/21
          - Developer                 : GiangLH.
          - Business Logic Desc.      : fdl_get_acnt_lnd_limit
      - Modify by                 : TienLH
          - Latest Modification Date  : 2021/03/26
   */
  r_acnt_max_amt NUMBER := 0;
  c_acnt_max_amt NUMBER := 0;

  t_acnt_max_amt   NUMBER := 0;
  t_acnt_lnd_amt   NUMBER := 0;
  t_acnt_lnd_limit NUMBER := 0;
  t_acc_lnd_amt_limit NUMBER := 0;
  t_lnd_tp         VARCHAR2(10);

  t_err_msg VARCHAR2(500);
  t_lrr     NUMBER := 0;

  t_vwdate varchar2(8) := vn.vwdate;

  -- Neu i_day_tp = '1'- Su dung trong ngay: Co cong them so luong du kien vay (extp) vao so da dung
  -- Neu i_day_tp ='2' - Cuoi ngay: Khong cong them so luong du kien vay (extp) vao so da dung
BEGIN
  /*
    1.Nguon: i_item_tp = '03'
  RLL(S,A) = Min[RLL(S),Max(0,Maximum limit(S,A) - Used(S,A))]

  Maximum Limit(S, A): Tong han muc toi da duoc phep cho vay cua nguon S cho tai khoan A
    "- Neu tai khoan A co chinh sach rieng ve  han muc nguon voi nguon S tai thoi diem tinh toan thi lay Han muc toi da theo chinh sach rieng tu doi tuong du lieu ""Chinh sach rieng HM tai khoan""
    - Neu tai khoan khong co CSR ve han muc thi lay tu cot Han muc tai khoan o doi tuong du lieu ""Chi tiet nguon"" cua nguon S. Neu khong co thi tra ve 0"
  Used(S,A): Tong gia tri han muc da dung cua nguon S cho Tai khoan A
    = Sum(gia tri vay, gia tri du kien vay) theo tai khoan A va nguon S tu bang dlm09m10

    2.San pham: i_item_tp = '02'
    RLL(P,A) = Min[RLL(P),Maximum limit(P,A) - Used(P,A)]
      Maximum Limit(P,A): Tong han muc toi da duoc phep cho vay cua nguon cho mot tai khoan
    - Neu tai khoan A co chinh sach rieng ve  han muc san pham tai thoi diem tinh toan thi lay Han muc toi da theo chinh sach rieng
    - Neu tai khoan khong co CSR ve han muc thi lay tu cot Han muc tai khoan o doi tuong du lieu ""Chi tiet san pham"" cua san pham ma tai khoan A dang su dung"
      Used(P,A): Tong gia tri han muc da dung cua  san pham P cho tai khoan A
    Sum(gia tri vay, gia tri du kien vay) theo tai khoan A va san pham P tu bang dlm09m10

  3.Nhom TK Margin: i_item_tp = '08'

    */

  --B1: Xac dinh han muc cua tai khoan (San pham, nguon, nhom TK)
  -- 1. Neu tai khoan co chinh sach rieng ve han muc nguon/san pham/Nhom TK thi lay theo chinh sach rieng(dlm20m05)
  BEGIN
    SELECT MAX(nvl(d5.acnt_max_amt, 0))
      INTO r_acnt_max_amt
      FROM vn.dlm20m05 d5 -- chinh sach rieng cua han muc tk - nguon
     WHERE d5.apy_tp = i_item_tp
       AND d5.apy_cd = i_item_cd
       AND d5.acnt_no = i_acnt_no
       AND d5.sub_no = i_sub_no
       AND d5.apy_dt <= t_vwdate
       AND d5.expr_dt >= t_vwdate
       AND d5.active_stat = 'Y';
  EXCEPTION
    WHEN OTHERS THEN
      t_err_msg := vn.fxc_get_err_msg('V', '46051');
      vn.pxc_log_write('fdl_get_acnt_lnd_limit',
                       ' account error: ' || t_err_msg || ' ACNT_NO=' ||
                       i_acnt_no || '-' || i_sub_no || '-' || i_item_tp || '-' ||
                       i_item_cd);
      raise_application_error(-20100,
                              t_err_msg ||
                              ' fdl_get_acnt_lnd_limit: ACNT_NO_STK_i_tp=' ||
                              i_acnt_no || '-' || i_sub_no || '-' ||
                              i_item_tp || '-' || i_item_cd);
  END;
  -- 2. Nguoc lai lay theo chinh sach chung (dlm00m01)
  IF r_acnt_max_amt IS NOT NULL THEN
    t_acnt_max_amt := r_acnt_max_amt;
  ELSE
    BEGIN
      SELECT nvl(acc_lnd_lmit, 0)
        INTO c_acnt_max_amt
        FROM vn.dlm00m01
       WHERE item_tp = i_item_tp
         AND item_cd = i_item_cd
         AND active_stat = 'Y'
         AND vn.fdl_item_detail_chk( i_item_tp, i_item_cd, t_vwdate) ='Y'
         ;
    EXCEPTION
      WHEN no_data_found THEN
        c_acnt_max_amt := 0;
      WHEN OTHERS THEN
        t_err_msg := vn.fxc_get_err_msg('V', '46051');
        vn.pxc_log_write('fdl_get_acnt_lnd_limit',
                         ' Select dlm00m01 error: ' || t_err_msg ||
                         ' ACNT_NO=' || i_acnt_no || '-' || i_sub_no || '-' ||
                         i_item_tp || '-' || i_item_cd);
    END;
    t_acnt_max_amt := nvl(c_acnt_max_amt, 0);
  END IF;

  --B2: Xac dinh so tien da dung:
  /* Co the viet ngon lai, nhung performance se khong tot
    SELECT SUM(nvl(lnd_use_amt, 0)) +
           SUM(decode(i_day_tp, '1', nvl(lnd_expt_amt, 0), 0))
      INTO t_acnt_lnd_amt
      FROM vn.dlm09m10
     WHERE ((i_item_tp = '03' AND src_no = i_item_cd) OR
           (i_item_tp = '02' AND prd_no = i_item_cd) OR
           (i_item_tp = '08' AND grp_acnt_no = i_item_cd))
       AND acnt_no = i_acnt_no
       AND sub_no = i_sub_no
       AND lnd_tp IN ('70', '80');
  */
  BEGIN
  IF i_item_tp = '03' THEN

  SELECT nvl(lnd_tp, '!')
      INTO t_lnd_tp
      FROM vn.dlm00m01
     WHERE item_tp = i_item_tp
         AND item_cd = i_item_cd
         AND active_stat = 'Y'
         AND vn.fdl_item_detail_chk( i_item_tp, i_item_cd, t_vwdate) ='Y';

    SELECT SUM(nvl(lnd_use_amt, 0)) +
         SUM(decode(i_day_tp, '1', nvl(lnd_expt_amt, 0), 0))
      INTO t_acnt_lnd_amt
      FROM vn.dlm09m10
     WHERE src_no = i_item_cd
       AND acnt_no = i_acnt_no
       AND sub_no = i_sub_no
       AND lnd_tp IN ('70', '80');

  ELSIF i_item_tp = '02' THEN
    SELECT SUM(nvl(lnd_use_amt, 0)) +
         SUM(decode(i_day_tp, '1', nvl(lnd_expt_amt, 0), 0))
      INTO t_acnt_lnd_amt
      FROM vn.dlm09m10
     WHERE prd_no = i_item_cd
       AND acnt_no = i_acnt_no
       AND sub_no = i_sub_no
       AND lnd_tp IN ('70', '80');

  ELSIF i_item_tp = '08' THEN
    SELECT SUM(nvl(lnd_use_amt, 0)) +
         SUM(decode(i_day_tp, '1', nvl(lnd_expt_amt, 0), 0))
      INTO t_acnt_lnd_amt
      FROM vn.dlm09m10
     WHERE grp_acnt_no = i_item_cd
       AND acnt_no = i_acnt_no
       AND sub_no = i_sub_no
       AND lnd_tp IN ('70', '80');
  END IF;

  EXCEPTION
    WHEN OTHERS THEN
      t_acnt_lnd_amt := 0;
  END;
  IF i_item_tp = '03' THEN
    --Nguon
  IF t_lnd_tp = '70' THEN
    t_acc_lnd_amt_limit := vn.fdl_get_acc_lnd_amt_limit(trim(i_acnt_no), i_day_tp); /*3% hm/tk*/
    t_lrr := LEAST(t_acc_lnd_amt_limit, vn.fdl_get_src_lnd_limit(i_item_cd, i_day_tp));
  ELSE
    t_lrr := vn.fdl_get_src_lnd_limit(i_item_cd, i_day_tp); --trong ngay
  END IF;
  ELSIF i_item_tp = '02' THEN
    --san pham
    t_lrr := vn.fdl_get_prd_lnd_limit(i_item_cd, i_day_tp); --trong ngay
  ELSIF i_item_tp = '08' THEN
    --nhom tk
    t_lrr := vn.fdl_get_grp_acnt_lnd_limit(i_item_cd, i_day_tp); --trong ngay
  END IF;

  t_acnt_lnd_limit := LEAST(t_lrr, GREATEST(0, nvl(t_acnt_max_amt, 0) - nvl(t_acnt_lnd_amt, 0)));

  RETURN t_acnt_lnd_limit;

END fdl_get_acnt_lnd_limit;
/

