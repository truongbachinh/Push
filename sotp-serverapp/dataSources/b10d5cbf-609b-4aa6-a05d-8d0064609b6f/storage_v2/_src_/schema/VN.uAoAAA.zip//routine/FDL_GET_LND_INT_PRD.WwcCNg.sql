create function    fdl_get_lnd_int_prd
(
    i_lnd_dt         in   varchar2,                 --
    i_rpy_dt         in   varchar2,                 --
    i_expr_dt        in   varchar2,                 --
    i_last_rpy_dt    in   varchar2,                 --
    i_int_rpy_tp     in   varchar2,                 -- 1. Uu tien thu lai truoc          2. Lai goc tuong duong
    i_tp             in   varchar2,                 -- 1. So ngay tinh lai trong han     2. So ngay tinh lai qua han
    i_acnt_no        in   varchar2  default null,
    i_sub_no         in   varchar2  default null,
    i_prd_no         in   varchar2  default null
)
    return  number
as

    t_lnd_prd               number := 0;
    t_dly_prd               number := 0;

    t_lnd_dt                date;
    t_rpy_dt                date;
    t_expr_dt               date;
    t_last_rpy_dt           date;

    t_int_waive_days        number;
    t_int_waive_day_tp      number;

    t_first_int_dt          date;

    t_err_txt               varchar2(80)  ; -- error text buffer

begin

/*============================================================================*/
/*                                                                            */
/* for Margin check fdl_get_mrgn_rt_01 key '08'                               */
/* i_tp                                                                       */
/* 1 : lnad interest period : ?? ??                                       */
/* 2 : lnd delay interest period : ?? ?? ??                             */
/*============================================================================*/

    t_lnd_dt        := to_date(i_lnd_dt     , 'YYYYMMDD');
    t_rpy_dt        := to_date(i_rpy_dt     , 'YYYYMMDD');
    t_expr_dt       := to_date(i_expr_dt    , 'YYYYMMDD');
    t_last_rpy_dt   := to_date(i_last_rpy_dt, 'YYYYMMDD');

    -- Xac dinh so ngay mien lai, phan loai ngay mien lai
    if(i_acnt_no is not null and i_sub_no is not null and i_prd_no is not null) then
        t_int_waive_days    := vn.fdl_get_prd_acnt_rt(i_acnt_no, i_sub_no, i_prd_no, '10', i_lnd_dt);
        t_int_waive_day_tp  := vn.fdl_get_prd_acnt_rt(i_acnt_no, i_sub_no, i_prd_no, '11', i_lnd_dt);
    else
        t_int_waive_days    := 0;
        t_int_waive_day_tp  := 0;
    end if;

    -- Lay ngay bat dau tinh lai = ngay vay + so ngay mien lai
    if t_int_waive_day_tp = 2 then          -- Tinh theo lich lam viec, co tinh ngay nghi
        t_first_int_dt  := to_date(vn.fxc_vorderdt_g(t_lnd_dt, t_int_waive_days), 'YYYYMMDD');
    else                                    -- ko tinh ngay nghi
        t_first_int_dt  := t_lnd_dt + t_int_waive_days;
    end if;

    if  t_expr_dt > t_rpy_dt then
        t_dly_prd  :=  0;

        if  i_int_rpy_tp = '1' then
            t_lnd_prd  :=  t_rpy_dt - greatest(t_last_rpy_dt, t_first_int_dt);
        elsif i_int_rpy_tp = '2' then
            t_lnd_prd  := t_rpy_dt - t_first_int_dt;
        else
            t_lnd_prd  := t_rpy_dt - t_first_int_dt;
        end if;

    else
        /*
            1. Doi voi phuong thuc Uu tien thu lai truoc:
                - Lai duoc tinh tu ngay hoan tra gan nhat
            2. Doi voi phuong thuc Lai goc tuong duong
                - Lai duoc tinh tu ngay phat vay
        */
        if  i_int_rpy_tp = '1' then
            if  t_expr_dt > t_last_rpy_dt then
                /*==============================================*/
                /* loan period : expire date ~ last repay date  */
                /* dely prriod : repay date ~ expire date       */
                /*==============================================*/
                t_lnd_prd  :=  t_expr_dt - greatest(t_last_rpy_dt, t_first_int_dt);
                t_dly_prd  :=  t_rpy_dt  - t_expr_dt;
            else
                /*==============================================*/
                /* loan period :                                */
                /* dely prriod : repay date ~ last repay date   */
                /*==============================================*/
                t_dly_prd  :=  t_rpy_dt - t_last_rpy_dt;
            end if;
        elsif i_int_rpy_tp = '2' then
            /*==============================================*/
            /* loan period : expire date ~ land date        */
            /* dely prriod : repay date ~ expire date       */
            /*==============================================*/
            t_lnd_prd  :=  t_expr_dt - t_first_int_dt;
            t_dly_prd  :=  t_rpy_dt  - t_expr_dt;
        end if;
    end if;

    t_lnd_prd := greatest(0, t_lnd_prd);
    t_dly_prd := greatest(0, t_dly_prd);

    /* return value setting */
    if i_tp = '1' then
        return t_lnd_prd;
    elsif i_tp = '2' then
        return t_dly_prd;
    else
        return t_dly_prd;
    end if ;

end fdl_get_lnd_int_prd;
/

