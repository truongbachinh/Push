create function fbm_rcm_cmsn_chk(
    i_tp                varchar2,   -- Phan loai: 1: emp_no - acnt_no   2: emp_no - emp_no     3: acnt_no - acnt_no
    i_recommender       varchar2,   -- Nguoi gioi thieu
    i_recommendee       varchar2,   -- Nguoi duoc gioi thieu
    i_dt_chk            varchar2    -- Ngay tra cuu
)
return varchar2

/*
select vn.fbm_rcm_cmsn_chk(
            '1',            -- i_tp                varchar2,   -- Phan loai: 1: emp_no - acnt_no   2: emp_no - emp_no     3: acnt_no - acnt_no
            'tyhpt01',      -- i_recommender       varchar2,   -- Nguoi gioi thieu
            '039C003000',   -- i_recommendee       varchar2,   -- Nguoi duoc gioi thieu
            vn.vwdate       -- i_dt_chk            varchar2    -- Ngay tra cuu
        ) chk
from dual;
*/
as
    t_dt_chk                    date;
    t_rcm_acnt_cmsn_prd         number      := 0;       -- So thang duoc huong hoa hong gioi thieu
    t_cnt                       number      := 0;
    t_chk                       varchar2(1) := 'N';
    t_rcm_cmsn_expr_dt          date;

    o_ret                   varchar2(1) := 'N';
begin
    t_dt_chk    := to_date(i_dt_chk, 'YYYYMMDD');

    -- Kiem tra Nhan vien co duoc huong hoa hong gioi thieu Khach hang hay khong
    if (i_tp = '1') then
        t_rcm_acnt_cmsn_prd := vn.fxc_col_cd_tp('rcm_acnt_cmsn_prd');

        begin
            select add_months(to_date(acnt_open_dt, 'YYYYMMDD'), t_rcm_acnt_cmsn_prd)
            into t_rcm_cmsn_expr_dt
            from vn.aaa01m00
            where sub_no = '00'
            and acnt_no = i_recommendee
            and ifno_idno = i_recommender;
        exception when others then
            o_ret := 'N';
            return o_ret;
        end;

        if (t_rcm_cmsn_expr_dt >= t_dt_chk) then
            o_ret := 'Y';
        else
            o_ret := 'N';
        end if;

        return o_ret;

    end if;

    -- Kiem tra Nhan vien co duoc huong hoa hong gioi thieu Nhan vien hay khong
    if (i_tp = '2') then
        t_rcm_acnt_cmsn_prd := vn.fxc_col_cd_tp('rcm_emp_cmsn_prd');

        begin
            select add_months(x01.regi_dtm, t_rcm_acnt_cmsn_prd)
            into t_rcm_cmsn_expr_dt
            from vn.xca01m01 x11
            inner join vn.xca01m00 x01
            on x11.emp_no = x01.id
            where x11.emp_no = i_recommendee
            and x11.rcm_emp_no = i_recommender;
        exception when others then
            o_ret := 'N';
            return o_ret;
        end;

        if (t_rcm_cmsn_expr_dt >= t_dt_chk) then
            o_ret := 'Y';
        else
            o_ret := 'N';
        end if;

        return o_ret;

    end if;

    return o_ret;
end;
/

