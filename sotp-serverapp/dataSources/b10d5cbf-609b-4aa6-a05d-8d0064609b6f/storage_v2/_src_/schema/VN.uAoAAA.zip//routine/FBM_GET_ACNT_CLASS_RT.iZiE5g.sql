create function fbm_get_acnt_class_rt(
    i_dt                varchar2,
    i_acnt_no           varchar2,
    i_sub_no            varchar2,
    i_acnt_class_cd     varchar2,
    i_biz_cmsn_tp       varchar2,
    i_emp_tp            varchar2
)
return number
/*
    select fbm_get_acnt_class_rt(
        vwdate,         -- i_dt                varchar2,
        '039C005669',   -- i_acnt_no           varchar2,
        '00',           -- i_sub_no            varchar2,
        'N0001',        -- i_acnt_class_cd     varchar2,
        '2',            -- i_biz_cmsn_tp       varchar2,
        '2'             -- i_emp_tp            varchar2
    ) a
    from dual;
*/
as
    t_acnt_class_cd         varchar2(15)    := i_acnt_class_cd;
    t_rt_df                 number          := 0;

    t_proc_nm               varchar2(30)    := 'fbm_get_acnt_class_rt';
    t_err_msg               varchar2(100)   := ' ';

    o_ret                   varchar2(38)    := '';
begin
    vn.pxc_log_write(t_proc_nm, '');
    vn.pxc_log_write(t_proc_nm, 'Start '                || t_proc_nm        || ' for: '
                                || 'i_dt: '             || i_dt
                                || ' i_acnt_no: '       || i_acnt_no        || '-' || i_sub_no
                                || 'i_acnt_class_cd: '  || i_acnt_class_cd
                                || 'i_biz_cmsn_tp: '    || i_biz_cmsn_tp
                                || 'i_emp_tp: '         || i_emp_tp
                    );

    if(i_acnt_no is not null and t_acnt_class_cd is null) then
        begin
            select acnt_class_cd
            into t_acnt_class_cd
            from vn.rms07m10 r7
            where r7.acnt_no = i_acnt_no
            and r7.data_dt = (
                    select max(r71.data_dt) max_data_dt
                    from vn.rms07m10 r71
                    where r71.acnt_no = i_acnt_no
                    and r71.data_dt <= i_dt
                )
            ;
        exception 
            when no_data_found then
                t_acnt_class_cd := null;
            when others then
                t_err_msg   := 'Error when getting data'
                        || ' sqlcode= ' || sqlcode
                        || ' sqlerrm= ' || sqlerrm;

                vn.pxc_log_write(t_proc_nm, t_err_msg);
                raise_application_error(-20100, t_err_msg);
        end;
    end if;

    if (t_acnt_class_cd is null) then
        begin
            select nvl(min(class_rt), 0) class_rt
            into o_ret
            from vn.rms08m02 r8
            where r8.biz_cmsn_tp = i_biz_cmsn_tp
            and r8.mng_tp = i_emp_tp
            and r8.apy_dt <= i_dt
            ;
        exception 
            when no_data_found then
                o_ret   := t_rt_df;
                return o_ret;
            when others then
                t_err_msg   := 'Error when getting data'
                        || ' sqlcode= ' || sqlcode
                        || ' sqlerrm= ' || sqlerrm;

                vn.pxc_log_write(t_proc_nm, t_err_msg);
                raise_application_error(-20100, t_err_msg);
        end;

    else
        begin
            select class_rt
            into o_ret
            from vn.rms08m02 r8
            where (r8.acnt_class_cd, r8.biz_cmsn_tp, r8.mng_tp, r8.apy_dt) in (
                        select
                            r81.acnt_class_cd, r81.biz_cmsn_tp, r81.mng_tp,
                            max(r81.apy_dt) apy_dt
                        from vn.rms08m02 r81
                        where r81.acnt_class_cd = t_acnt_class_cd
                        and r81.biz_cmsn_tp = i_biz_cmsn_tp
                        and r81.mng_tp = i_emp_tp
                        and r81.apy_dt <= i_dt
                        group by r81.acnt_class_cd, r81.biz_cmsn_tp, r81.mng_tp
                )
            ;
        exception 
            when no_data_found then
                o_ret   := t_rt_df;
                return o_ret;
            when others then
                t_err_msg   := 'Error when getting data'
                        || ' sqlcode= ' || sqlcode
                        || ' sqlerrm= ' || sqlerrm;

                vn.pxc_log_write(t_proc_nm, t_err_msg);
                raise_application_error(-20100, t_err_msg);
        end;
    end if;

    return o_ret;

end fbm_get_acnt_class_rt;
/

