create procedure    pts_ord_comm_data_g
(
	i_sb_kfx_tp       IN     VARCHAR2,	/* ?�Uy??????      */
	i_ord_comm_cd     IN     VARCHAR2,	/* ?????????       */
	i_standard_price  IN     VARCHAR2,	/* ???????????????*/
    o_strt_val        OUT    VARCHAR2,	/* ????               */
    o_end_val         OUT    VARCHAR2,	/* ????               */
    o_cd_data         OUT    VARCHAR2,	/* ??????           */
    P_ErrCode         OUT    NUMBER,    /* ???? ???          */
    P_ErrMsg          OUT    VARCHAR2   /* Error Message        */
) as

begin
	o_strt_val     := ' ';
    o_end_val      := ' ';
    o_cd_data      := ' ';
    P_ErrCode      := 0  ;
    P_ErrMsg       := ' ';
vn.pxc_log_write('pts_acnt_prof_g',' i_sb_kfx_tp['||i_sb_kfx_tp||']  i_ord_comm_cd['|| i_ord_comm_cd ||'] i_standard_price['|| i_standard_price ||']');
	begin
    SELECT NVL(strt_val,' '),
		   NVL(end_val,' '),
		   NVL(cd_data,' ')
      INTO o_strt_val,
           o_end_val,
	  	   o_cd_data
	  FROM vn.tso08m00
	 WHERE sb_kfx_tp   = i_sb_kfx_tp
	   AND ord_comm_cd = i_ord_comm_cd
	   AND decode(i_ord_comm_cd, '03', to_number(strt_val), i_standard_price)
		   <= to_number(i_standard_price)
	   AND decode(i_ord_comm_cd, '03', to_number(end_val ), i_standard_price)
		   >= to_number(i_standard_price)
	   AND ROWNUM = 1
    ;

    exception
    when no_data_found then
        P_ErrCode := 0  ;
        P_ErrMsg  := ' ';

		if i_ord_comm_cd = '01' then       -- ????
			if i_sb_kfx_tp = 'HOSTC' then
				o_strt_val := '0830';
				o_end_val  := '1045';
			else
				o_strt_val := '0830';
				o_end_val  := '1100';
			end if;
		elsif i_ord_comm_cd = '02' then    -- ??????????
			if i_sb_kfx_tp = 'HOSTC' then
				o_cd_data  := '100';	-- NHSV-1319
			else
				o_cd_data  := '100';
			end if;
		elsif i_ord_comm_cd = '03' then    -- ?????????
			if i_sb_kfx_tp = 'HOSTC' then
				if to_number(i_standard_price) <= 49999 then
					o_strt_val := '0';
					o_end_val  := '49999';
					o_cd_data  := '100';
				elsif 50000 <= to_number(i_standard_price) and
					  to_number(i_standard_price) <= 99999 then
			        o_strt_val := '50000';
					o_end_val  := '99999';
				    o_cd_data  := '500';
				elsif to_number(i_standard_price) >= 100000 then
					o_strt_val := '100000';
					o_strt_val := '999999999999999';
					o_cd_data  := '1000';
				end if;
			else
				o_strt_val := '0';
				o_strt_val := '999999999999999';
				o_cd_data  := '100';
			end if;
		end if;

    when others then
        P_ErrCode := SQLCODE;
	    P_ErrMsg  := SQLERRM;
	    raise_application_error(-20100,'[pts_ord_comm_data_g] ' || P_ErrMsg);
    end;

end pts_ord_comm_data_g;
/

