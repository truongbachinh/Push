create procedure extr_acnt_otp_csv(
    i_acnt_no       varchar2
)
as
    cursor c_otp is
        select
            '1' stt_1, a9.m_1 otp_1, '2' stt_2, a9.m_2 otp_2, '3' stt_3, a9.m_3 otp_3, '4' stt_4, a9.m_4 otp_4, '5' stt_5, a9.m_5 otp_5
        from aaa01m00 a1
        inner join aaa99m01 a9
        on a1.iss_no = a9.iss_no
        where
            a1.acnt_no  = i_acnt_no
        and a1.sub_no   = '00'
        and rownum = 1

        UNION ALL

        select
            '6' stt, a9.m_6 otp, '7' stt, a9.m_7 otp, '8' stt, a9.m_8 otp, '9' stt, a9.m_9 otp, '10' stt, a9.m_10 otp
        from aaa01m00 a1
        inner join aaa99m01 a9
        on a1.iss_no = a9.iss_no
        where
            a1.acnt_no  = i_acnt_no
        and a1.sub_no   = '00'
        and rownum = 1

        UNION ALL

        select
            '11' stt, a9.m_11 otp, '12' stt, a9.m_12 otp, '13' stt, a9.m_13 otp, '14' stt, a9.m_14 otp, '15' stt, a9.m_15 otp
        from aaa01m00 a1
        inner join aaa99m01 a9
        on a1.iss_no = a9.iss_no
        where
            a1.acnt_no  = i_acnt_no
        and a1.sub_no   = '00'
        and rownum = 1

        UNION ALL

        select
            '16' stt, a9.m_16 otp, '17' stt, a9.m_17 otp, '18' stt, a9.m_18 otp, '19' stt, a9.m_19 otp, '20' stt, a9.m_20 otp
        from aaa01m00 a1
        inner join aaa99m01 a9
        on a1.iss_no = a9.iss_no
        where
            a1.acnt_no  = i_acnt_no
        and a1.sub_no   = '00'
        and rownum = 1

        UNION ALL

        select
            '21' stt, a9.m_21 otp, '22' stt, a9.m_22 otp, '23' stt, a9.m_23 otp, '24' stt, a9.m_24 otp, '25' stt, a9.m_25 otp
        from aaa01m00 a1
        inner join aaa99m01 a9
        on a1.iss_no = a9.iss_no
        where
            a1.acnt_no  = i_acnt_no
        and a1.sub_no   = '00'
        and rownum = 1

        UNION ALL

        select
            '26' stt, a9.m_26 otp, '27' stt, a9.m_27 otp, '28' stt, a9.m_28 otp, '29' stt, a9.m_29 otp, '30' stt, a9.m_30 otp
        from aaa01m00 a1
        inner join aaa99m01 a9
        on a1.iss_no = a9.iss_no
        where
            a1.acnt_no  = i_acnt_no
        and a1.sub_no   = '00'
        and rownum = 1

        UNION ALL

        select
            '31' stt, a9.m_31 otp, '32' stt, a9.m_32 otp, '33' stt, a9.m_33 otp, '34' stt, a9.m_34 otp, '35' stt, a9.m_35 otp
        from aaa01m00 a1
        inner join aaa99m01 a9
        on a1.iss_no = a9.iss_no
        where
            a1.acnt_no  = i_acnt_no
        and a1.sub_no   = '00'
        and rownum = 1
        ;

    t_file_name     varchar2(100)       := i_acnt_no || '_otp.csv';
    t_file          utl_file.file_type  := null;
    t_otp_dir_name  varchar2(50)        := 'OTP_DIR';
    t_max_linesize  number              := 32767;
begin

    t_file :=   utl_file.fopen(
                    location     => t_otp_dir_name,
                    filename     => t_file_name,
                    open_mode    => 'w',
                    max_linesize => t_max_linesize
                );
    utl_file.put_line(
        t_file,
        'STT'       || ',' ||
        'OTP'       || ',' ||
        'STT'       || ',' ||
        'OTP'       || ',' ||
        'STT'       || ',' ||
        'OTP'       || ',' ||
        'STT'       || ',' ||
        'OTP'       || ',' ||
        'STT'       || ',' ||
        'OTP'

    );

    for cur_rec in c_otp loop
        utl_file.put_line(
            t_file,
            cur_rec.stt_1       || ',' ||
            cur_rec.otp_1       || ',' ||
            cur_rec.stt_2       || ',' ||
            cur_rec.otp_2       || ',' ||
            cur_rec.stt_3       || ',' ||
            cur_rec.otp_3       || ',' ||
            cur_rec.stt_4       || ',' ||
            cur_rec.otp_4       || ',' ||
            cur_rec.stt_5       || ',' ||
            cur_rec.otp_5
        );

    end loop;

    utl_file.fclose(t_file);

exception
    when others then
        utl_file.fclose(t_file);
        raise;
end;
/

