create procedure    pds_tax_setl_proc
(
	i_dt          in     varchar2,        --
	i_acnt_no     in     varchar2,        --
	i_sub_no      in     varchar2,        --
	i_bank_cd     in     varchar2,        --
	i_work_mn     in     varchar2,        -- user id
	i_work_trm    in     varchar2,
	o_proc_cnt    in out number,
	o_err_cnt		in out number
) AS

/*!
   \file     pds_tax_setl_proc.sql
   \brief    commision settlement

   \section intro Program Information
        - Program Name              : settle commision
        - Service Name              : ds_04003_p1.pc
        - Related Client Program- Client Program ID : w_04001
        - Related Tables            : dsc01m00, cwd01m00,
                                    : aaa01m00, aaa10m00
        - Dev. Date                 : 2007/11/08
        - Developer                 : Han.
        - Business Logic Desc.      : create settle data
        - Latest Modification Date  : 2007/11/08

   \section history Program Modification History
    - 1.0       2007/11/08     Han.    New.

   \section hardcoding Hard-Coding List
    - HC-1      2007/11/08     Han.    [����]

   \section info Additional Reference Comments
    - ����ó��

var o_cnt1 number;
var o_cnt2 number;
exec pds_tax_setl_proc('20090107','%','9999','Conv_man','Conv_man',:o_cnt1,:o_cnt2);
print o_cnt1;
print o_cnt2;
*/

    t_setl_dt           varchar2(8)   := null;
    t_mth_dt            varchar2(8)   := null;

    t_amt1              number        := 0;     --
    t_amt2              number        := 0;     --
    t_amt3              number        := 0;     --

    t_dpo_prerm         number        := 0;     --
    t_dpo_nowrm         number        := 0;     --

    t_dpo               number		  := 0;
	t_block_ds_amt		number		  := 0;
	t_block_dl_amt		number		  := 0;
	t_used_allowa_cd	number		  := 0;
	t_nonrpy_loan_amt	number		  := 0;
	t_tot_out_psbamt	number		  := 0;
	t_rpyable_amt		number		  := 0;

    t_bank_knd_tp       varchar2(2)   := null;
    t_bank_cd           varchar2(4)   := null;

    ts_cnt_tp           varchar2(3)   := null;
    ts_bank_cd          varchar2(4)   := null;
    ts_bank_nm          varchar2(100) := null;
    ts_bank_acnt_no     varchar2(50)  := null;
    ts_bank_acnt_nm     varchar2(100) := null;

    t_trd_seq_no       number         := 0;
    t_tot_seq_no       number         := 0;

    t_grp_tp           VARCHAR2(1)    := null;
    t_frgn_tp          VARCHAR2(1)    := null;
    t_trd_tp            varchar2(2)   := NULL;
    t_rmrk_cd           varchar2(3)   := NULL;

    t_mng_brch_cd       varchar2(3)   := null;
    t_agnc_brch         varchar2(2)   := null;
    t_setl_tp           varchar2(1)   := null;

    t_rmrk_job_tp       varchar2(2)   := null;
    t_rmrk_trd_tp       varchar2(3)   := null;

    ts_work_stat_min    VARCHAR2(1);
    ts_work_stat_max    VARCHAR2(1);

    t_err_chk           varchar2(1);
    t_err_msg           VARCHAR2(500);
    t_pgm_id            VARCHAR2(4) := '2450'; /* Batch control PGM_ID */

    t_msg               VARCHAR2(10);
    t_pos               varchar2(100);

    t_sqlcode           NUMBER      := 0;
	t_sec_cd            VARCHAR2(10);

begin

    o_proc_cnt := 0;
    o_err_cnt  := 0;
	t_sec_cd   := vn.fxc_sec_cd('R');
    /*========================================================================*/
    /* Date Check                                                             */
    /*========================================================================*/
    t_setl_dt := i_dt;
    t_mth_dt  := vn.fxc_vorderdt_g(to_date(i_dt,'yyyymmdd'), -3);

    /*========================================================================*/
    /* Input Date CHECK                                                       */
    /*========================================================================*/
    if  vn.fxc_holi_ck(to_date(i_dt,'yyyymmdd')) !=  '0' then
    	if  i_work_mn <> 'DAILY' then
	        t_err_msg := vn.fxc_get_err_msg('V','2422');
	        t_err_msg := t_err_msg||' Date = '||i_dt;
	        raise_application_error(-20100,t_err_msg);
		else
			return;
		end if;
    end if;

    /*  i_dt = setl_dt for buy cmsn on match day       */
    /*  t_mth_dt = mth_dt for sell cmsn on settle day  */
    if  vn.vwdate  !=  i_dt     then
        t_err_msg := vn.fxc_get_err_msg('V','2422');
        t_err_msg := t_err_msg||' Date = '||i_dt||'-'||t_mth_dt;
        raise_application_error(-20100,t_err_msg);
    end if;


    /*========================================================================*/
    /* Prededing job Check                                                    */
    /*========================================================================*/
/*
    if  i_acnt_no = '%' and
        fxb_daily_stat_chk ('E','0','2400','2400','*') <> 'Y' then
        t_err_msg := vn.fxc_get_err_msg('V','2458');
        t_err_msg := t_err_msg||'[2000],[2000]'||i_dt;
        raise_application_error(-20100,t_err_msg);
    end if;
*/
/*============================================================================*/
/* ( )                                                                        */
/*============================================================================*/
--  begin
    for C1 in (
        select  setl_dt
             ,  mth_dt
             ,  acnt_mng_bnh
             ,  agnc_brch
             ,  acnt_no
             ,  sub_no
             ,  bank_cd
             ,  sb_tp
             ,  mkt_trd_tp
             ,  cdt_tp
             ,  stk_cd
             ,  sb_qty
             ,  sb_amt
             ,  sb_cmsn
             ,  sb_tax
             ,  adj_amt
          from  (
                 select  a.setl_dt
                      ,  a.mth_dt
                      ,  a.acnt_mng_bnh
                      ,  a.agnc_brch
                      ,  a.acnt_no
                      ,  a.sub_no
                      ,  a.bank_cd
                      ,  a.sb_tp
                      ,  a.mkt_trd_tp
                      ,  a.cdt_tp
                      ,  a.stk_cd
                      ,  sum(nvl(a.sb_qty,0))      sb_qty
                      ,  sum(nvl(a.sb_amt,0))      sb_amt
                      ,  sum(nvl(a.sb_cmsn,0))     sb_cmsn
                      ,  sum(nvl(a.sb_tax,0))      sb_tax
                      ,  sum(nvl(a.adj_amt,0))     adj_amt
                   from  vn.dsc01m00 a
                  where  a.setl_dt        =  i_dt
                    and  a.acnt_no     like  i_acnt_no
                    and  a.sub_no	   like  i_sub_no
                    and  a.bank_cd     like  i_bank_cd
                    and  a.mkt_trd_tp    in  ('01','03','05','04','06')
                    and  a.tax_setl_yn   in  ('N')
                  group  by  a.setl_dt, a.acnt_no, a.sub_no, a.mth_dt, a.acnt_mng_bnh, a.agnc_brch
                          ,  a.bank_cd, a.sb_tp,   a.mkt_trd_tp,   a.cdt_tp,  a.stk_cd
                 )  x
         order  by  x.setl_dt, x.acnt_no, x.sub_no, x.mth_dt, x.acnt_mng_bnh, x.agnc_brch
                 ,  x.bank_cd, x.sb_tp,   x.mkt_trd_tp,   x.cdt_tp,  x.stk_cd
    ) loop

        t_err_chk  := 'N';

        /*================================================================*/
        /* Bank Account Check                                             */
        /*================================================================*/
		begin
            vn.paa_bank_yn_p( C1.acnt_no, C1.sub_no, ts_cnt_tp);
		exception
		when others then
			t_err_msg := vn.fxc_get_err_msg('V','9009');
			raise_application_error(-20100,t_err_msg||' Acnt_no - '||C1.acnt_no||'-'||C1.sub_no);
		end;

        if  C1.sb_tp = '1' and
            C1.sb_tax > 0 then
            /*================================================================*/
            /* Account management branch                                      */
            /*================================================================*/
            begin
                select  nvl(agnc_brch,'00')
                     ,  setl_tp
                  into  t_agnc_brch
                     ,  t_setl_tp
                  from  vn.aaa01m00
                 where  acnt_no      =  C1.acnt_no
                   and  sub_no		 =  C1.sub_no
                ;
            exception
            when no_data_found then
                t_err_msg := vn.fxc_get_err_msg('V','2006');
                raise_application_error(-20100,t_err_msg||' ACNT_NO='||C1.acnt_no||'-'||C1.sub_no);
            when others then
                t_err_msg := vn.fxc_get_err_msg('V','9002');
                raise_application_error(-20011,t_err_msg||' acnt_no='||C1.acnt_no||'-'||C1.sub_no);
            end;

		    if  ts_cnt_tp  =  'Y01'  then  -- Bank Acnt
                vn.pds_dsc10m00_ins (  i_dt                -- TRD_DT
                                     , '1'                 -- JOB_TP
                                     , C1.bank_cd          -- BANK_CD
                                     , C1.acnt_no          -- ACNT_NO
                                     , C1.sub_no
                                     , C1.setl_dt          -- SETL_DT
                                     , C1.mth_dt           -- MTH_DT
                                     , C1.sb_tp            -- SB_TP
                                     , C1.acnt_mng_bnh     -- ACNT_MNG_BRCH
                                     , C1.agnc_brch        -- AGNC_BRCH
                                     , C1.mkt_trd_tp       -- MKT_TRD_TP
                                     , C1.cdt_tp           -- CDT_TP
                                     , C1.stk_cd           -- STK_CD
                                     , 0                   -- SEQ_NO
                                     , 0                   -- ADJ_AMT
                                     , 0                   -- SB_AMT
                                     , 0                   -- SB_CMSN
                                     , C1.sb_tax           -- SB_TAX
                                     , C1.cdt_tp           -- LND_TP
                                     , null                -- LND_DT
                                     , null                -- MRTG_DT
                                     , null                -- LND_BANK_CD
                                     , 0                   -- lnd_amt
                                     , 0                   -- lnd_int
                                     , 0                   -- lnd_fee
                                     , C1.sb_qty           -- sb_qty
                                     , i_work_mn           -- WORK_MN
                                     , i_work_trm          -- WORK_TRM
                                    );

		    else

                /*============================================================*/
                /* acntno deposit select                                      */
                /*============================================================*/
                t_dpo_prerm         := 0;           --
                t_dpo_nowrm         := 0;           --

				t_dpo               := 0;
				t_block_ds_amt		:= 0;
				t_block_dl_amt		:= 0;
				t_used_allowa_cd	:= 0;
				t_nonrpy_loan_amt	:= 0;
				t_tot_out_psbamt	:= 0;
				t_rpyable_amt		:= 0;

                /*============================================================*/
                /* dpo update                                                 */
                /*============================================================*/
                t_bank_knd_tp := vn.fcw_bank_knd_tp_q(C1.acnt_no, C1.sub_no);
                /* t_bank_cd     := vn.faa_acnt_bank_cd_g(C1.acnt_no); */
                t_bank_cd     := '0000';

	            t_pos := 'GET DPO';
                /* if  t_bank_knd_tp = '02' then */
                /* 2008.10.28 CTB Account check */
                if  t_setl_tp = '1' then
                    vn.pds_outamt_psbamt_q(  C1.acnt_no
										  ,  C1.sub_no
										  ,  t_dpo
										  ,  t_block_ds_amt
										  ,  t_block_dl_amt
										  ,  t_used_allowa_cd
										  ,  t_nonrpy_loan_amt
										  ,  t_tot_out_psbamt
										  ,  t_rpyable_amt
										  );

                    t_dpo_prerm          := t_dpo;

                    if  t_dpo_prerm is null then
                        t_err_msg := vn.fxc_get_err_msg('V','9001');
                		t_err_chk := 'Y';
                        raise_application_error(-20100,t_err_msg||' ACNT_NO='||C1.acnt_no||'-'||C1.sub_no);
                    end if;

                    /*if  C1.sb_tax <= t_dpo then*/
                    if  C1.sb_tax <= (t_dpo - t_block_ds_amt - t_used_allowa_cd) then
                        t_dpo_nowrm      := t_dpo  -  C1.sb_tax;
                    else
                        t_err_msg := vn.fxc_get_err_msg('V','2002');
                		t_err_chk := 'Y';
                        raise_application_error(-20100,t_err_msg||' ACNT='||C1.acnt_no||'-'||C1.sub_no
                                                                ||' Tax= '||C1.sb_tax
                                                                ||' Dpo= '||t_dpo);
                    end if;

                    update  vn.cwd01m00
                       set  dpo       =  t_dpo_nowrm
                     where  acnt_no   =  C1.acnt_no
                       and  sub_no	  =  C1.sub_no
                    ;

                    if  sql%notfound or sql%notfound is null then
                        insert into vn.cwd01m00
                         (acnt_no,      sub_no, 	 dpo,         gst_dpo,
                          work_mn,      work_dtm,    work_trm)
                        values
                         (C1.acnt_no,   C1.sub_no, 	 t_dpo_nowrm, 0,
                          i_work_mn,    sysdate,     i_work_trm);
                    end if;
                end if;

	            /*============================================================*/
	            /* pdk_get_last_trd_no Create                                 */
	            /*============================================================*/
	            t_pos := 'GET TRD_NO';

	            /*====================================================================*/
				/* Get the Trade sequence number and Total trade sequence number      */
				/*====================================================================*/
				begin
				    vn.pxc_psb_seq_cret_p(C1.acnt_no, C1.sub_no, vn.vwdate, t_trd_seq_no, t_tot_seq_no);
				exception
				when others then
				    t_err_msg := vn.fxc_get_err_msg('V','9414');
				    t_err_msg := t_err_msg||' Acnt_no= '||C1.acnt_no||'-'||C1.sub_no;
				    raise_application_error(-20100,t_err_msg);
				end;

                /*============================================================*/
                /* pds_aaa10m00_ins(�ŷ�����) Create                          */
                /*============================================================*/
                /* t_grp_tp  (1:individual accout 2:corporation account) */
                /* t_frgn_tp (1:native accout 2:forgigner) */
                t_grp_tp  :=  vn.faa_acnt_grp_tp_g(C1.acnt_no, C1.sub_no);
                t_frgn_tp :=  vn.faa_acnt_frgn_tp_g(C1.acnt_no, C1.sub_no);

                t_pos := 'INS TRD';
	            /*
	            if  C1.sb_tp = '1' then
	                t_trd_tp  := '31';
	            else
	                t_trd_tp  := '30';
	            end if;
	            */

	            /* 2008.10.28 CTB Account => [635,636] */
	            if  t_setl_tp = '2' then
	                if  C1.sb_tp = '1' then
	                    t_trd_tp  := '35';
	                    t_rmrk_cd := '635';
	                elsif C1.sb_tp = '2' THEN
	                    t_trd_tp  := '35';
	                    t_rmrk_cd := '636';
	                end if;
	            else
	                if  ts_cnt_tp  !=  'Y01'  then  -- Security Account
	                    if  C1.sb_tp = '1' then
	                    	if  t_grp_tp  =  '2' and
	                    	    t_frgn_tp =  '2' then
	                            t_trd_tp  := '31';
	                            t_rmrk_cd := '631';
	                        else
	                            t_trd_tp  := '31';
	                            t_rmrk_cd := '631';
	                        end if;
	                    elsif C1.sb_tp = '2' THEN
	                    	if  t_grp_tp  =  '2' and
	                    	    t_frgn_tp =  '2' then
	                            t_trd_tp  := '31';
	                            t_rmrk_cd := '632';
	                        else
	                            t_trd_tp  := '31';
	                            t_rmrk_cd := '632';
	                        end if;
	                    end if;
	                else
	                    if  C1.sb_tp = '1' then
	                    	if  t_grp_tp  =  '2' and
	                    	    t_frgn_tp =  '2' then
	                            t_trd_tp  := '33';
	                            t_rmrk_cd := '631';
	                        else
	                            t_trd_tp  := '33';
	                            t_rmrk_cd := '631';
	                        end if;
	                    elsif C1.sb_tp = '2' THEN
	                    	if  t_grp_tp  =  '2' and
	                    	    t_frgn_tp =  '2' then
	                            t_trd_tp  := '33';
	                            t_rmrk_cd := '632';
	                        else
	                            t_trd_tp  := '33';
	                            t_rmrk_cd := '632';
	                        end if;
	                    end if;
	                end if;
	            end if;

                vn.pds_aaa10m00_ins (  C1.acnt_no          -- ACNT_NO
                					 , C1.sub_no
                                     , i_dt                -- TRD_DT
                                     , t_trd_seq_no        -- TRD_SEQ_NO
                                     , t_trd_tp            -- TRD_TP
                                     , t_rmrk_cd           -- RMRK_CD
                                     , C1.bank_cd          -- BANK_CD
                                     , '00'                -- MDM_TP
                                     , '00'                -- TRD_MDM_TP
                                     , 'N'                 -- CNCL_YN
                                     , 0                   -- ORG_TRD_NO
                                     , C1.sb_tax           -- TRD_AMT
                                     , 0                   -- CMSN
                                     , C1.sb_tax           -- SB_TAX
                                     , C1.sb_tax           -- ADJ_AMT
                                     , t_dpo_prerm         -- DPO_PRERM
                                     , t_dpo_nowrm         -- DPO_NOWRM
                                     , C1.stk_cd           -- STK_CD
                                     , null                -- STK_NM
                                     , 0                   -- SB_PRI
                                     , 0                   -- SB_QTY
                                     , 0                   -- BIL_PRERM_QTY
                                     , 0                   -- BIL_NOWRM_QTY
                                     , 0                   -- BOOK_AMT
                                     , vn.fss_get_stk_tp(c1.stk_cd)
                                                           -- STK_TP
                                     , C1.mth_dt           -- MTH_DT
                                     , C1.cdt_tp           -- LND_TP
                                     , null                -- LND_DT
                                     , null                -- LND_BANK_CD
                                     , 0                   -- LND_AMT
                                     , 0                   -- LND_RPY_AMT
                                     , 0                   -- LND_INT
                                     , 0                   -- LND_CMSN
                                     , 0                   -- LND_INT_DLY
                                     , 0                   -- LND_CMSN_DLY
                                     , 'N'                 -- AGNT_YN
                                     , C1.acnt_mng_bnh     -- ACNT_MNG_BNH
                                     , C1.agnc_brch        -- AGNC_BRCH
                                     , C1.acnt_mng_bnh     -- WORK_BNH
                                     , C1.agnc_brch        -- PROC_AGNC_BRCH
                                     , i_work_mn           -- WORK_MN
                                     , i_work_trm          -- WORK_TRM
                                     , C1.setl_dt
                                     , t_tot_seq_no
                                    );

                /*============================================================*/
                /* ȸ��ݿ�                                                   */
                /*============================================================*/

                if  substr(C1.acnt_no,4,1) =  'P' then
                    if  C1.mkt_trd_tp  in  ('02') then
                        t_rmrk_job_tp := '25';
                    else
                        t_rmrk_job_tp := '20';
                    end if;
                else
                    if  C1.mkt_trd_tp  in  ('02') then
                        t_rmrk_job_tp := '11';
                    else
                        t_rmrk_job_tp := '10';
                    end if;
                end if;

                /* 2008.10.28 CTB Account => [635,636] */
                if  t_setl_tp = '2' then
                    if  C1.sb_tp  =  '1' then
                        t_rmrk_trd_tp := '635';
                    else
                        t_rmrk_trd_tp := '636';
                    end if;
                else
                    if  C1.sb_tp = '1' then
                    	if  t_grp_tp  =  '2' and
                    	    t_frgn_tp =  '2' then
                            t_rmrk_trd_tp := '631';
                        else
                            t_rmrk_trd_tp := '631';
                        end if;
                    elsif C1.sb_tp = '2' THEN
                    	if  t_grp_tp  =  '2' and
                    	    t_frgn_tp =  '2' then
                            t_rmrk_trd_tp := '632';
                        else
                            t_rmrk_trd_tp := '632';
                        end if;
                    end if;
                end if;

                vn.pds_gga07m00_ins (  i_dt                -- PROC_DT
                                     , 'I'                 -- AUTO_SLIP_PROC_TP
                                     , C1.acnt_mng_bnh     -- PROC_BRCH_CD
                                     , C1.agnc_brch        -- PROC_AGNC_BRCH
                                     , C1.acnt_mng_bnh     -- EXCH_BRCH_CD
                                     , C1.agnc_brch        -- EXCH_AGNC_BRCH
                                     , C1.acnt_no          -- ACNT_NO
                                     , C1.sub_no
                                     , i_dt                -- TRD_DT
                                     , t_trd_seq_no        -- TRD_SEQ_NO
                                     , 0                   -- ORIG_TRD_SEQ_NO
                                     , t_rmrk_job_tp       -- RMRK_JOB_TP
                                     , t_rmrk_trd_tp       -- RMRK_TRD_TP
                                     , '0000'              -- LND_BANK_CD
                                     , C1.sb_tax           -- DR_AMT_01
                                     , 0                   -- DR_AMT_02
                                     , 0                   -- DR_AMT_03
                                     , 0                   -- DR_AMT_04
                                     , 0                   -- DR_AMT_05
                                     , C1.sb_tax           -- CR_AMT_01
                                     , 0                   -- CR_AMT_02
                                     , 0                   -- CR_AMT_03
                                     , 0                   -- CR_AMT_04
                                     , 0                   -- CR_AMT_05
                                     , t_bank_cd           -- BANK_CD
                                     , i_work_mn           -- WORK_MN
                                     , i_work_trm          -- WORK_TRM
                                 );

            end if;
            o_proc_cnt := o_proc_cnt + 1;
        else
            o_err_cnt := o_err_cnt + 1;
        end if;

        /*====================================================================*/
        /* TABLE UPDATE                                                       */
        /* dsc01m00(������������) Update                                      */
        /*====================================================================*/
        if  ts_cnt_tp  !=  'Y01'  then  -- Security Account
            UPDATE  vn.dsc01m00
               set  tax_setl_yn   =  'Y'
                 ,  tax_setl_dt   =  i_dt
             where  setl_dt       =  C1.setl_dt
               and  mth_dt        =  C1.mth_dt
               and  acnt_no       =  C1.acnt_no
               and  sub_no		  =  C1.sub_no
               and  acnt_mng_bnh  =  C1.acnt_mng_bnh
               and  agnc_brch     =  C1.agnc_brch
               and  bank_cd       =  C1.bank_cd
               and  sb_tp         =  C1.sb_tp
               and  mkt_trd_tp    =  C1.mkt_trd_tp
               and  cdt_tp        =  C1.cdt_tp
               and  stk_cd        =  C1.stk_cd
            ;
        else
            UPDATE  vn.dsc01m00
               set  tax_setl_yn   =  'C'
             where  setl_dt       =  C1.setl_dt
               and  mth_dt        =  C1.mth_dt
               and  acnt_no       =  C1.acnt_no
               and  sub_no		  =  C1.sub_no
               and  acnt_mng_bnh  =  C1.acnt_mng_bnh
               and  agnc_brch     =  C1.agnc_brch
               and  bank_cd       =  C1.bank_cd
               and  sb_tp         =  C1.sb_tp
               and  mkt_trd_tp    =  C1.mkt_trd_tp
               and  cdt_tp        =  C1.cdt_tp
               and  stk_cd        =  C1.stk_cd
            ;
        end if;

    end loop;

--  exception when others then
--      t_sqlcode := sqlcode;
--      t_err_msg := sqlerrm;
--      t_err_msg := vn.fxc_get_err_msg('V','2713')||t_err_msg;
--      raise_application_error(-20100,t_err_msg);
--
--  end;

end pds_tax_setl_proc;
/

