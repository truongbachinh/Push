create procedure    pds_stk_setl_proc_auto
(
    i_sec_cd         in     varchar2,
    i_sb_tp          in     varchar2,
    i_work_mn        in     varchar2,
    i_work_trm       in     varchar2
) AS
/*============================================================================*/
-- 1. Process Name : pds_auto_sell_setl                                       --
-- 2. Process func : Auto sell settlement                                     --
-- 3. developer    : Hungtm                                                   --
-- 4. modifier     :                                                          --
-- 5. note         :                                                          --
/*============================================================================*/
/*
var o_cnt      number;
var o_err_cnt  number;
exec pds_stk_setl_proc_auto(i_sec_cd,'1','AUTO','SYSTIME');
print o_cnt
print o_err_cnt
*/

    /* For SMS */
    t_com_full_nm    VARCHAR2(100)   := NULL;
  t_com_nm         VARCHAR2(100)   := NULL;
  t_com_vnm         VARCHAR2(100)   := NULL;
  t_com_sms        VARCHAR2(100)   := NULL;
  t_com_phone      VARCHAR2(100)   := NULL;
  t_com_email      VARCHAR2(100)   := NULL;
  t_com_addr       VARCHAR2(100)   := NULL;
  t_hn_brch        VARCHAR2(100)   := NULL;
  t_hcm_brch       VARCHAR2(100)   := NULL;
  t_etc_brch       VARCHAR2(100)   := NULL;
    t_fax               VARCHAR2(100)   := NULL;
    t_website           VARCHAR2(100)   := NULL;

    t_sms_msg      VARCHAR2(1000)  := NULL;
    /* End SMS */

    t_job_chk          VARCHAR2(1)  ;
    t_rtn              VARCHAR2(1)  ;
    t_vwdate           varchar2(8)  := null;

    t_err_msg          VARCHAR2(500);
    t_pgm_id           VARCHAR2(4)  ; /* Batch control PGM_ID */

    o_cnt1             NUMBER       := 0;
    o_err_cnt1         NUMBER       := 0;
     o_cnt2             NUMBER       := 0;
    o_err_cnt2         NUMBER       := 0;
    o_cnt_row          NUMBER       := 0;

    t_dpo               number      := 0;
    t_block_ds_amt    number      := 0;
    t_block_dl_amt    number      := 0;
    t_used_allowa_cd  number      := 0;
    t_nonrpy_loan_amt  number      := 0;
    t_tot_out_psbamt  number      := 0;
    t_rpyable_amt    number      := 0;

    t_tot_rpy_amt    number      := 0;
    t_lnd_rpy_int   number      := 0;
    t_rpy_int_dly   number      := 0;
    t_lnd_rpy_amt   number      := 0;

begin

    t_vwdate  := to_char(vn.hdate,'yyyymmdd');

    if  vn.fxc_holi_ck(to_date(t_vwdate,'yyyymmdd')) !=  '0' then
        return;
    end if;
    -- 2. get represent company phone number
    vn.Pxc_Company_Info(i_sec_cd
            , 'R'
            , 'V'
            , t_com_full_nm
            , t_com_nm
            , t_com_vnm
            , t_com_sms
            , t_com_phone
            , t_com_email
            , t_com_addr
            , t_hn_brch
            , t_hcm_brch
            , t_etc_brch
            , t_fax
            , t_website);

    /* Evaluate margin */
    UPDATE vn.dsc30m00
       SET job_chk  =  '1'
         , work_dtm =  SYSDATE
     WHERE job_id  =  '0010'
       AND exe_dt  =  '30000101'
    ;
    commit;

    for C1 IN (
        SELECT  distinct a.acnt_no,a.sub_no
          FROM  vn.dsc01m00 a
         WHERE  a.setl_dt     = t_vwdate
           AND  a.mkt_trd_tp    IN  ('01','03','05','04','06')
         GROUP  BY  a.acnt_no,a.sub_no
         ORDER  BY  a.acnt_no,a.sub_no
    ) loop

        o_cnt1     := 0;
         vn.pxc_log_write('pds_auto_sell_setl', 'Start pdl_crd_loan_rt_proc_td : '||' acnt_no ='||C1.acnt_no||'-'||C1.sub_no);
        begin
            vn.pdl_crd_loan_rt_proc_td( t_vwdate
                                      , '2'
                                      , C1.acnt_no
                                      , C1.sub_no
                                      , 0
                                      , i_work_mn
                                      , i_work_trm
                                      , o_cnt1
                                      );
        exception when others then
            t_err_msg  := 'Error margin evaluate''-'||sqlcode||'-'||sqlerrm;
            t_sms_msg := 'Error evaluate margin in auto sell settle';
            vn.pxc_log_write('pds_auto_sell_setl', t_err_msg||t_sms_msg);
            vn.Pxc_Sms_Ins(t_vwdate, '84918222688', t_com_sms, '999', '999', t_sms_msg, 'Settle', 'Settle');
            vn.Pxc_Sms_Ins(t_vwdate, '84937216153', t_com_sms, '999', '999', t_sms_msg, 'Settle', 'Settle');
            vn.Pxc_Sms_Ins(t_vwdate, '84988649841', t_com_sms, '999', '999', t_sms_msg, 'Settle', 'Settle');
            vn.Pxc_Sms_Ins(t_vwdate, '84938836896', t_com_sms, '999', '999', t_sms_msg, 'Settle', 'Settle');
            vn.Pxc_Sms_Ins(t_vwdate, '84907131262', t_com_sms, '999', '999', t_sms_msg, 'Settle', 'Settle');
            vn.Pxc_Sms_Ins(t_vwdate, '84903632660', t_com_sms, '999', '999', t_sms_msg, 'Settle', 'Settle');
            commit;
            raise_application_error(-20010,t_err_msg);
        end;

    end loop;
    commit;

    UPDATE vn.dsc30m00
       SET job_chk  =  '2'
         , work_dtm =  SYSDATE
     WHERE job_id  =  '0010'
       AND exe_dt  =  '30000101'
    ;
    commit;

end pds_stk_setl_proc_auto;
/

