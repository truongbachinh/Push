create function fbm_acnt_emp_bnh_yn
(
    is_emp_no     in   varchar2,
    i_acnt_no     in   VARCHAR2,
    i_tp          IN   VARCHAR2
)
    return          varchar2
AS

    o_acnt_mng_bnh  varchar2(10);
   -- t_err_txt       varchar2(100);
    o_agnc_brch     varchar2(10);
    o_emp_bnh       varchar2(10);
    --t_err_txt       varchar2(100);
    o_emp_agnc_brch varchar2(10);
    os_add_brch   varchar2(200);


begin
    o_acnt_mng_bnh  :=  NULL;
  --  os_return_cnt:='N' ;
  IF i_tp = '1' THEN 
    begin
       SELECT t.acnt_mng_bnh,t.agnc_brch
       INTO o_acnt_mng_bnh,o_agnc_brch
       FROM aaa01m00  t
       WHERE t.acnt_no =  i_acnt_no
       AND t.sub_no = '00';
    exception
        when  NO_DATA_FOUND  then
      return  '!';
    end;

  begin
       SELECT t.BRCH_CD,t.AGNC_BRCH,t.addl_bnh_cd
       INTO  o_emp_bnh,o_emp_agnc_brch,os_add_brch
       FROM xca01m01 t
       WHERE t.emp_no =  is_emp_no ;
    exception
        when  NO_DATA_FOUND  then
      return  '!';
    end;


    IF o_acnt_mng_bnh = o_emp_bnh THEN
       IF o_agnc_brch = o_emp_agnc_brch OR o_emp_agnc_brch = '00' OR INSTR(os_add_brch,o_agnc_brch) <> 0 THEN
      RETURN 'Y';
      END IF ;
      END IF ;
   RETURN 'N';
   END IF  ;
   
  IF i_tp = '2' THEN 
    BEGIN 
      SELECT t.BRCH_CD,t.AGNC_BRCH
       INTO  o_emp_bnh,o_emp_agnc_brch
       FROM xca01m01 t
       WHERE t.emp_no =  is_emp_no ; 
       END ;
       
       IF o_emp_agnc_brch = '00' THEN 
         RETURN '%';
       ELSE 
         RETURN o_emp_agnc_brch;
       END IF;
       END IF ;
  
end fbm_acnt_emp_bnh_yn;
/

