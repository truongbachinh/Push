create function fdl_get_cmsn_amt(
    i_acnt_no       in     varchar2,       --
    i_sub_no        in     varchar2,       --
    i_stk_cd        in     varchar2,       --
    i_sb_tp         in     varchar2,       --
    i_cmsn_tp       in     varchar2,       --
    i_stk_tp        in     varchar2,       --
    i_mkt_trd_tp    in     varchar2,       --
    i_mdm_tp        in     varchar2,       --
    i_setl_knd_tp   in     varchar2,       --
    i_stk_ord_tp    in     varchar2,       --
    i_apy_dt        in     varchar2,       --
    i_sb_amt        in     number ,        -- 
    i_mth_dt        in     varchar2,
    i_sb_sum_amt    in     number
    ) return number is
  FunctionResult number;
  t_cmsn_rt number;
  t_cmsn_amt number;
begin
  vn.pds_get_cmsn_rt ( i_acnt_no     ,  i_sub_no	  ,
                                     i_stk_cd       ,  i_sb_tp        ,
                                     i_cmsn_tp      ,  i_stk_tp       ,
                                     i_mkt_trd_tp   ,  /* => mkt_trd_tp */
                                     i_mdm_tp  ,  i_setl_knd_tp ,
                                     '00'           ,  /* => stk_ord_tp */
                                     i_mth_dt      ,  i_sb_sum_amt ,
                                     t_cmsn_rt      ,  t_cmsn_amt     );
  return(t_cmsn_rt);
end fdl_get_cmsn_amt;
/

