create PROCEDURE DEL_USER_CONFIRM (IS_SEQ_NO in VARCHAR2 )
AS
    t_err_txt       varchar2(200);
    t_err_msg       varchar2(500);
BEGIN

    BEGIN

        UPDATE VN.CWD11M00
        SET SENDED_STAT = '0'
        WHERE SEQ_NO = IS_SEQ_NO
        AND STD_DT=VN.VWDATE;
        COMMIT;
    EXCEPTION WHEN OTHERS THEN
       vn.pxc_log_write('DEL_USER_CONFIRM','UPDATE KHONG THANH CONG'||IS_SEQ_NO);
       t_err_txt  := 'UPDATE KHONG THANH CONG ';
       t_err_msg := vn.fxc_get_err_msg('V','2701');
       raise_application_error(-20100,t_err_msg||t_err_txt);
    END;

END;
/

