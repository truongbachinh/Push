create procedure pds_test
    ( i_input    	  in     varchar2,
      o_output        in out varchar2
	) AS

exp_err      exception;

BEGIN

	o_output := 'X';

	begin

		o_output := i_input;

		if i_input = 'X' then
			raise_application_error(-20100,'Error Occur');
		elsif i_input = 'E' then
			raise exp_err;
		end if;


    exception
    	when exp_err then
    		o_output := 'AAA';
        	raise_application_error(-20001, '['||i_input||' - '||o_output||']');
    	when others  then
    		o_output := 'AAA';
        	raise_application_error(-20002, '['||i_input||' - '||o_output||']');
	end;

/*

var a varchar2(100);
exec pds_test('A',:a);
print a

var a varchar2(100);
exec pds_test('X',:a);
print a

var a varchar2(100);
exec pds_test('E',:a);
print a

*/
end pds_test;
/

