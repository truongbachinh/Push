create procedure    pxb_daily_backup
(
    i_dt             in     varchar2,
    i_tp             in     varchar2
) as

t_cnt number;

begin
    -- holi tp : [1, Sunday], [2, holiday], [3, Saturday]
    if vn.fxc_holi_ck(to_date(i_dt,'YYYYMMDD')) in ('1','2', '3') then
        return;
    else
        if i_tp = '0000' then
            null;
        elsif i_tp = 'BACK' then
            select count(*)
            into t_cnt
            from vn.xbd01h00
            where exe_dt = to_char(vn.fxc_wdt_g(to_date(i_dt,'YYYYMMDD'),-1),'YYYYMMDD');

            if t_cnt > 0 then
                raise_application_error(-20001,'?? ??? ???????.');
            end if;

            -- ?? ?? ??? backup ??.
            insert  into vn.xbd01h00 value(
                    pgm_id        
                ,  exe_dt        
                ,  pgm_nm        
                ,  work_detl     
                ,  work_strt_time
                ,  work_end_time 
                ,  seq_work_tp   
                ,  exe_yn        
                ,  work_stat     
                ,  exe_apy_yn    
                ,  proc_cnt
                ,  adm_mn_empno  
                ,  adm_emp_nm    
                ,  cnte          
                ,  pgm_tp        
                ,  work_mn       
                ,  work_dtm      
                ,  work_trm      
            )
            select
                    pgm_id        
                ,  exe_dt        
                ,  pgm_nm        
                ,  work_detl     
                ,  work_strt_time
                ,  work_end_time 
                ,  seq_work_tp   
                ,  exe_yn        
                ,  work_stat     
                ,  exe_apy_yn    
                ,  proc_cnt
                ,  adm_mn_empno  
                ,  adm_emp_nm    
                ,  cnte          
                ,  pgm_tp        
                ,  work_mn       
                ,  work_dtm      
                ,  work_trm      
            from  vn.xbd01m00
            ;
        end if;     -- End i_tp = 'BACK'

        -- Reset work status for jobs which are required to run
        merge into vn.xbd01m00 xb
        using(
            select *
            from vn.xcc01c02
        ) t
        on (xb.pgm_tp = t.col_cd(+)
            and nvl(t.col_cd_tp, 'Y') = 'Y'
        ) 
        when matched then update
        set 
            work_stat      =  '0'
        ;

        update  vn.xbd01m00
           set  exe_yn      = 'Y'
        where  exe_apy_yn  = 'Y'
        ;

        -- Update new executed date for all jobs
        update  vn.xbd01m00
            set  exe_dt       =  i_dt
            ,  work_strt_time =  null
            ,  work_end_time  =  null
            ,  proc_cnt       =  0
        ;

    end if;

end pxb_daily_backup;
/

