create procedure    pds_tax_setl_odd
(
	i_setl_dt     in     varchar2,        --
	i_mth_dt      in     varchar2,        --
	i_acnt_no     in     varchar2,        --
	i_sub_no      in     varchar2,        --
	i_setl_seq_no in     number,          --
	i_work_mn     in     varchar2,        -- user id
	i_work_trm    in     varchar2,
	o_cnt         in out number
) AS

/*!
   \file     pds_tax_setl_odd.sql
   \brief    tax of odd-lot settlement

   \section intro Program Information
        - Program Name              : settle tax of odd-lot
        - Service Name              : ds_04008_p1.pc
        - Related Client Program- Client Program ID : w_04008
        - Related Tables            : dsc01m00, cwd01m00,
                                    : aaa01m00, aaa10m00
        - Dev. Date                 : 2010/03/27
        - Developer                 : Hung
        - Business Logic Desc.      : settle tax of odd-lot
        - Latest Modification Date  : 2010/03/27

   \section history Program Modification History
    - 1.0

   \section hardcoding Hard-Coding List
    -

   \section info Additional Reference Comments
    -

var o_cnt      number;
var o_err_cnt  number;
exec pds_tax_setl_odd('20080627','%','%','0001','Test','Test',:o_cnt,:o_err_cnt);
print o_cnt
print o_err_cnt

*/

    t_mng_brch_cd      varchar2(3)   := null;
    t_agnc_brch        varchar2(2)   := null;
    t_setl_tp          varchar2(1)   := null;

    t_dpo_prerm        number        := 0;     --
    t_dpo_nowrm        number        := 0;     --

    t_dpo               number		:= 0;
	t_block_ds_amt		number		:= 0;
	t_block_dl_amt		number		:= 0;
	t_used_allowa_cd	number		:= 0;
	t_nonrpy_loan_amt	number		:= 0;
	t_tot_out_psbamt	number		:= 0;
	t_rpyable_amt		number		:= 0;

    t_bank_knd_tp      varchar2(2)  := null;
    t_bank_cd          varchar2(4)  := null;

    ts_cnt_tp          varchar2(3)  := null;

    t_trd_seq_no       number       := 0;
    t_tot_seq_no       number       := 0;
	t_trd_dt            varchar2(8) := NULL;

    t_grp_tp           VARCHAR2(1)   := null;
    t_frgn_tp          VARCHAR2(1)   := null;

    t_trd_tp           varchar2(2)  := NULL;
    t_rmrk_cd          varchar2(3)  := NULL;

    t_rmrk_job_tp      varchar2(2)  := null;
    t_rmrk_trd_tp      varchar2(3)  := null;

	tmp_acnt_no		   varchar2(10) := '!';
    tmp_sub_no		   varchar2(2)  := null;
    tmp_trd_seq_no     number       := 0;

    ts_work_stat_min   VARCHAR2(1);
    ts_work_stat_max   VARCHAR2(1);

    t_err_msg          varchar2(500);
    t_pos              varchar2(100);
    o_cnt1             number      := 0;
	t_sec_cd           VARCHAR2(10);

begin

    o_cnt     :=  0;

	t_trd_dt  :=  vn.vwdate;
	t_sec_cd   := vn.fxc_sec_cd('R');

    /*========================================================================*/
    /* Input Date CHECK                                                       */
    /*========================================================================*/
    if  vn.fxc_holi_ck(to_date(t_trd_dt,'yyyymmdd')) !=  '0' then
        if  i_work_mn <> 'DAILY' then
            t_err_msg := vn.fxc_get_err_msg('V','2422');
            t_err_msg := t_err_msg||' Date = '||t_trd_dt;
            raise_application_error(-20100,t_err_msg);
        else
            return;
        end if;
    end if;

	if  i_setl_dt  >  t_trd_dt  then
        t_err_msg := vn.fxc_get_err_msg('V','2422');
        t_err_msg := t_err_msg||' Date = '||i_setl_dt;
        raise_application_error(-20100,t_err_msg);
	end if;

    /*========================================================================*/
    /* Prededing job Check                                                    */
    /*========================================================================*/
/*  confirm !!  */
	if  vn.fxb_daily_stat_chk ('B','0','2600','2800','*') = 'Y' then
		t_err_msg := vn.fxc_get_err_msg('V','9416');
		t_err_msg := t_err_msg||'[2600],[2800]'||i_setl_dt;
		raise_application_error(-20100,t_err_msg);
	end if;

/*
    if  i_acnt_no = '%' and
        i_sb_tp   = '2' and
        vn.fxb_daily_stat_chk ('B','0','2000','2100','*') <> 'Y' then
        t_err_msg := vn.fxc_get_err_msg('V','2458');
        t_err_msg := t_err_msg||'[2000],[2250]'||i_dt;
        raise_application_error(-20100,t_err_msg);
    end if;
*/
/*============================================================================*/
/* ( )                                                                        */
/*============================================================================*/
    for C1 in (
        select  a.setl_dt
             ,  a.acnt_no
             ,  a.sub_no
             ,  a.setl_frct_seq_no
             ,  a.mth_dt
             ,  a.bank_cd
             ,  a.acnt_mng_bnh
             ,  a.agnc_brch
             ,  a.sb_tp
             ,  a.mkt_trd_tp
             ,  a.cdt_tp
             ,  a.stk_cd
             ,  a.mdm_tp
             ,  a.stk_tp
             ,  a.sb_pri
             ,  a.sb_qty
             ,  a.sb_amt
             ,  a.sb_cmsn
             ,  a.sb_tax
             ,  a.adj_amt
          from  vn.dsc01m00 a
         where  a.setl_dt           =  i_setl_dt
           and  a.acnt_no           =  i_acnt_no
           and  a.sub_no            =  i_sub_no
           and  a.setl_frct_seq_no  =  i_setl_seq_no
           and  a.mth_dt            =  i_mth_dt
           and  a.mkt_trd_tp       in  ('02','04','06')
           and  a.tax_setl_yn      in  ('N')
           and  nvl(a.sb_tax,0)     >  0
         order  by  a.setl_dt, a.acnt_no, a.sub_no, a.setl_frct_seq_no, a.mth_dt
    ) loop

        /*====================================================================*/
        /* Account management branch                                          */
        /*====================================================================*/
        /*
        t_mng_brch_cd := vn.faa_acnt_bnh_cd_g('0',C1.acnt_no);
        t_agnc_brch   := '00';
        */
        begin
            select  nvl(agnc_brch,'00')
                 ,  setl_tp
              into  t_agnc_brch
                 ,  t_setl_tp
              from  vn.aaa01m00
             where  acnt_no      =  C1.acnt_no
               and  sub_no		 =  C1.sub_no
            ;
        exception
        when no_data_found then
            t_err_msg := vn.fxc_get_err_msg('V','2006');
            raise_application_error(-20100,t_err_msg||' ACNT_NO='||C1.acnt_no||'-'||C1.sub_no);
        when others then
            t_err_msg := vn.fxc_get_err_msg('V','9002');
            raise_application_error(-20011,t_err_msg||' acnt_no='||C1.acnt_no||'-'||C1.sub_no);
        end;

        /*====================================================================*/
        /* Bank Account Check                                                 */
        /*====================================================================*/
        begin
            vn.paa_bank_yn_p(C1.acnt_no, C1.sub_no, ts_cnt_tp);
        exception
        when others then
            t_err_msg := vn.fxc_get_err_msg('V','9009');
            raise_application_error(-20100,t_err_msg||' Acnt_no - '||C1.acnt_no||'-'||C1.sub_no);
        end;

		if  C1.sb_tp = '1' THEN
	        if  ts_cnt_tp  =  'Y01'  then  -- Bank Acnt

	            vn.pds_dsc10m00_ins (  t_trd_dt            -- TRD_DT
	                                 , '5'                 -- JOB_TP
	                                 , C1.bank_cd          -- BANK_CD
	                                 , C1.acnt_no          -- ACNT_NO
	                                 , C1.sub_no
	                                 , C1.setl_dt          -- SETL_DT
	                                 , C1.mth_dt           -- MTH_DT
	                                 , C1.sb_tp            -- SB_TP
	                                 , C1.acnt_mng_bnh     -- ACNT_MNG_BRCH
	                                 , C1.agnc_brch        -- AGNC_BRCH
	                                 , C1.mkt_trd_tp       -- MKT_TRD_TP
	                                 , C1.cdt_tp           -- CDT_TP
	                                 , C1.stk_cd           -- STK_CD
	                                 , C1.setl_frct_seq_no -- SEQ_NO
	                                 , 0                   -- ADJ_AMT
	                                 , 0                   -- SB_AMT
	                                 , 0                   -- SB_CMSN
	                                 , C1.sb_tax           -- SB_TAX
	                                 , C1.cdt_tp           -- LND_TP
	                                 , null                -- LND_DT
	                                 , null                -- MRTG_DT
	                                 , null                -- LND_BANK_CD
	                                 , 0                   -- lnd_amt
	                                 , 0                   -- lnd_int
	                                 , 0                   -- lnd_fee
	                                 , C1.sb_qty           -- sb_qty
	                                 , i_work_mn           -- WORK_MN
	                                 , i_work_trm          -- WORK_TRM
	                                );

	        else

				/*====================================================================*/
				/* Get the Trade sequence number and Total trade sequence number      */
				/*====================================================================*/
				begin
				    vn.pxc_psb_seq_cret_p(C1.acnt_no, C1.sub_no, vn.vwdate, t_trd_seq_no, t_tot_seq_no);
				exception
				when others then
				    t_err_msg := vn.fxc_get_err_msg('V','9414');
				    t_err_msg := t_err_msg||' Acnt_no= '||C1.acnt_no||'-'||C1.sub_no;
				    raise_application_error(-20100,t_err_msg);
				end;

	            /*================================================================*/
	            /* acntno deposit select                                          */
	            /*================================================================*/
	            t_dpo_prerm         := 0;           --
	            t_dpo_nowrm         := 0;           --

				t_dpo               := 0;
				t_block_ds_amt		:= 0;
				t_block_dl_amt		:= 0;
				t_used_allowa_cd	:= 0;
				t_nonrpy_loan_amt	:= 0;
				t_tot_out_psbamt	:= 0;
				t_rpyable_amt		:= 0;
	            /*================================================================*/
	            /* dpo update                                                     */
	            /*================================================================*/
	            t_bank_knd_tp := vn.fcw_bank_knd_tp_q(C1.acnt_no, C1.sub_no);
	            /* t_bank_cd     := vn.faa_acnt_bank_cd_g(C1.acnt_no); */
	            t_bank_cd     := '0000';

	            t_pos := 'GET DPO';
	            /* if  t_bank_knd_tp = '02' then */
	            /* 2008.10.28 CTB Account check */
	            if  t_setl_tp = '1' then
	                vn.pds_outamt_psbamt_q(  C1.acnt_no
										  ,  C1.sub_no
										  ,  t_dpo
										  ,  t_block_ds_amt
										  ,  t_block_dl_amt
										  ,  t_used_allowa_cd
										  ,  t_nonrpy_loan_amt
										  ,  t_tot_out_psbamt
										  ,  t_rpyable_amt
										  );

	                t_dpo_prerm          := t_dpo;

	                if  t_dpo_prerm is null then
	                    t_err_msg := vn.fxc_get_err_msg('V','9001');
	                    raise_application_error(-20100,t_err_msg||' ACNT_NO='||C1.acnt_no||'-'||C1.sub_no);
	                end if;

	                /*if  C1.sb_tax <= t_dpo then*/
	                if  C1.sb_tax <= (t_dpo - t_block_ds_amt - t_used_allowa_cd) then
                        t_dpo_nowrm      := t_dpo  -  C1.sb_tax;
                    else
                        t_err_msg := vn.fxc_get_err_msg('V','2002');
                        raise_application_error(-20100,t_err_msg||' ACNT='||C1.acnt_no||'-'||C1.sub_no
                                                                ||' Tax= '||C1.sb_tax
                                                                ||' Dpo= '||t_dpo);
                    end if;

	                update  vn.cwd01m00
	                   set  dpo       =  t_dpo_nowrm
	                 where  acnt_no   =  C1.acnt_no
	                   and  sub_no	  =  C1.sub_no
	                ;

	                if  sql%notfound or sql%notfound is null then
	                    insert into vn.cwd01m00
	                     (acnt_no,      sub_no,		 dpo,         gst_dpo,
	                      work_mn,      work_dtm,    work_trm)
	                    values
	                     (C1.acnt_no,   C1.sub_no, 	 t_dpo_nowrm, 0,
	                      i_work_mn,    sysdate,     i_work_trm);
	                end if;
	            end if;

	            /*============================================================*/
                /* pdk_get_last_trd_no Create                                 */
                /*============================================================*/
                t_pos := 'GET TRD_NO';

				/*====================================================================*/
				/* Get the Trade sequence number and Total trade sequence number      */
				/*====================================================================*/
				begin
				    vn.pxc_psb_seq_cret_p(C1.acnt_no, C1.sub_no, vn.vwdate, t_trd_seq_no, t_tot_seq_no);
				exception
				when others then
				    t_err_msg := vn.fxc_get_err_msg('V','9414');
				    t_err_msg := t_err_msg||' Acnt_no= '||C1.acnt_no||'-'||C1.sub_no;
				    raise_application_error(-20100,t_err_msg);
				end;


                /*============================================================*/
                /* pds_aaa10m00_ins(�ŷ�����) Create                          */
                /* t_grp_tp  (1:individual accout 2:corporation account)      */
                /* t_frgn_tp (1:native accout 2:forgigner)                    */
                /*============================================================*/
                t_grp_tp  :=  vn.faa_acnt_grp_tp_g(C1.acnt_no,C1.sub_no);
                t_frgn_tp :=  vn.faa_acnt_frgn_tp_g(C1.acnt_no,C1.sub_no);

                t_pos := 'INS TRD';
                /*
                if  C1.sb_tp = '1' then
                    t_trd_tp  := '31';
                else
                    t_trd_tp  := '30';
                end if;
                */

                /* 2008.10.28 CTB Account => [635,636] */
                if  t_setl_tp = '2' then
                    if  C1.sb_tp = '1' then
                        t_trd_tp  := '35';
                        t_rmrk_cd := '635';
                    elsif C1.sb_tp = '2' THEN
                        t_trd_tp  := '35';
                        t_rmrk_cd := '636';
                    end if;
                else
                    if  ts_cnt_tp  !=  'Y01'  then  -- Security Account
                        if  C1.sb_tp = '1' then
                        	if  t_grp_tp  =  '2' and
                        	    t_frgn_tp =  '2' then
                                t_trd_tp  := '31';
                                t_rmrk_cd := '631';
                            else
                                t_trd_tp  := '31';
                                t_rmrk_cd := '631';
                            end if;
                        elsif C1.sb_tp = '2' THEN
                        	if  t_grp_tp  =  '2' and
                        	    t_frgn_tp =  '2' then
                                t_trd_tp  := '31';
                                t_rmrk_cd := '632';
                            else
                                t_trd_tp  := '31';
                                t_rmrk_cd := '632';
                            end if;
                        end if;
                    else
                        if  C1.sb_tp = '1' then
                        	if  t_grp_tp  =  '2' and
                        	    t_frgn_tp =  '2' then
                                t_trd_tp  := '33';
                                t_rmrk_cd := '631';
                            else
                                t_trd_tp  := '33';
                                t_rmrk_cd := '631';
                            end if;
                        elsif C1.sb_tp = '2' THEN
                        	if  t_grp_tp  =  '2' and
                        	    t_frgn_tp =  '2' then
                                t_trd_tp  := '33';
                                t_rmrk_cd := '632';
                            else
                                t_trd_tp  := '33';
                                t_rmrk_cd := '632';
                            end if;
                        end if;
                    end if;
                end if;

	            vn.pds_aaa10m00_ins (  C1.acnt_no          -- ACNT_NO
	            					 , C1.sub_no
	                                 , t_trd_dt            -- TRD_DT
	                                 , t_trd_seq_no        -- TRD_SEQ_NO
	                                 , t_trd_tp            -- TRD_TP
	                                 , t_rmrk_cd           -- RMRK_CD
	                                 , C1.bank_cd          -- BANK_CD
	                                 , C1.mdm_tp           -- MDM_TP
	                                 , C1.mdm_tp           -- TRD_MDM_TP
	                                 , 'N'                 -- CNCL_YN
	                                 , 0                   -- ORG_TRD_NO
	                                 , C1.sb_tax           -- TRD_AMT
	                                 , 0                   -- CMSN
	                                 , C1.sb_tax           -- SB_TAX
	                                 , C1.sb_tax           -- ADJ_AMT
	                                 , t_dpo_prerm         -- DPO_PRERM
	                                 , t_dpo_nowrm         -- DPO_NOWRM
	                                 , C1.stk_cd           -- STK_CD
	                                 , null                -- STK_NM
	                                 , 0                   -- SB_PRI
	                                 , 0                   -- SB_QTY
	                                 , 0                   -- BIL_PRERM_QTY
	                                 , 0                   -- BIL_NOWRM_QTY
	                                 , 0                   -- BOOK_AMT
	                                 , C1.stk_tp           -- STK_TP
	                                 , C1.mth_dt           -- MTH_DT
	                                 , C1.cdt_tp           -- LND_TP
	                                 , null                -- LND_DT
	                                 , null                -- LND_BANK_CD
	                                 , 0                   -- LND_AMT
	                                 , 0                   -- LND_RPY_AMT
	                                 , 0                   -- LND_INT
	                                 , 0                   -- LND_CMSN
	                                 , 0                   -- LND_INT_DLY
	                                 , 0                   -- LND_CMSN_DLY
	                                 , 'N'                 -- AGNT_YN
	                                 , C1.acnt_mng_bnh     -- ACNT_MNG_BNH
	                                 , C1.agnc_brch        -- AGNC_BRCH
	                                 , C1.acnt_mng_bnh     -- WORK_BNH
	                                 , C1.agnc_brch        -- PROC_AGNC_BRCH
	                                 , i_work_mn           -- WORK_MN
	                                 , i_work_trm          -- WORK_TRM
	                                 , C1.setl_dt
	                                 , t_tot_seq_no
	                                );

	            /*================================================================*/
	            /* ȸ��ݿ�                                                       */
	            /*================================================================*/

	            if  substr(C1.acnt_no,4,1) =  'P' then
	                if  C1.mkt_trd_tp  in  ('02') then
	                    t_rmrk_job_tp := '25';
	                else
	                    t_rmrk_job_tp := '20';
	                end if;
	            else
                    if  ts_cnt_tp  !=  'Y01'  then  -- Security Account
                        if  C1.mkt_trd_tp  in  ('02') then
                            t_rmrk_job_tp := '11';
                        else
                            t_rmrk_job_tp := '10';
                        end if;
                    else
                        if  C1.mkt_trd_tp  in  ('02') then
                            t_rmrk_job_tp := '13';
                        else
                            t_rmrk_job_tp := '12';
                        end if;
                    end if;
	            end if;

	            /* 2008.10.28 CTB Account => [615,616] */
	            if  t_setl_tp = '2' then
	                if  C1.sb_tp  =  '1' then
	                    t_rmrk_trd_tp := '635';
	                else
	                    t_rmrk_trd_tp := '636';
	                end if;
	            else
                    if  C1.sb_tp = '1' then
                    	if  t_grp_tp  =  '2' and
                    	    t_frgn_tp =  '2' then
                            t_rmrk_trd_tp := '631';
                        else
                            t_rmrk_trd_tp := '631';
                        end if;
                    elsif C1.sb_tp = '2' THEN
                    	if  t_grp_tp  =  '2' and
                    	    t_frgn_tp =  '2' then
                            t_rmrk_trd_tp := '632';
                        else
                            t_rmrk_trd_tp := '632';
                        end if;
                    end if;

	                vn.pds_gga07m00_ins (  t_trd_dt            -- PROC_DT
	                                     , 'I'                 -- AUTO_SLIP_PROC_TP
	                                     , C1.acnt_mng_bnh     -- PROC_BRCH_CD
	                                     , C1.agnc_brch        -- PROC_AGNC_BRCH
	                                     , C1.acnt_mng_bnh     -- EXCH_BRCH_CD
	                                     , C1.agnc_brch        -- EXCH_AGNC_BRCH
	                                     , C1.acnt_no          -- ACNT_NO
	                                     , C1.sub_no
	                                     , t_trd_dt            -- TRD_DT
	                                     , t_trd_seq_no        -- TRD_SEQ_NO
	                                     , 0                   -- ORIG_TRD_SEQ_NO
	                                     , t_rmrk_job_tp       -- RMRK_JOB_TP
	                                     , t_rmrk_trd_tp       -- RMRK_TRD_TP
	                                     , '0000'              -- LND_BANK_CD
	                                     , C1.sb_tax           -- DR_AMT_01
	                                     , 0                   -- DR_AMT_02
	                                     , 0                   -- DR_AMT_03
	                                     , 0                   -- DR_AMT_04
	                                     , 0                   -- DR_AMT_05
	                                     , C1.sb_tax           -- CR_AMT_01
	                                     , 0                   -- CR_AMT_02
	                                     , 0                   -- CR_AMT_03
	                                     , 0                   -- CR_AMT_04
	                                     , 0                   -- CR_AMT_05
	                                     , t_bank_cd           -- BANK_CD
	                                     , i_work_mn           -- WORK_MN
	                                     , i_work_trm          -- WORK_TRM
	                                 );

	            end if;
				/*====================================================================*/
		        /* Margin Evaluation                                                  */
		        /*====================================================================*/
				if tmp_acnt_no = '!' then
					tmp_acnt_no		:= C1.acnt_no;
					tmp_sub_no		:= C1.sub_no;
					tmp_trd_seq_no	:= t_trd_seq_no;
				else
					if (tmp_acnt_no <> C1.acnt_no) or (tmp_sub_no <> C1.sub_no) then
				        o_cnt1 := 0;
				        begin
				        vn.pdl_crd_loan_rt_proc_td( t_trd_dt,  '1',
				                                    tmp_acnt_no, tmp_sub_no, tmp_trd_seq_no,
				                                    i_work_mn, i_work_trm,  o_cnt1 );

				        exception
				        when others then
				            vn.pxc_log_write('pds_tax_setl_odd', ' crd_loan_td:'||' C1.ACNT ='||C1.acnt_no||'-'||C1.sub_no
				                                                                ||' T_ACNT =' ||tmp_acnt_no||'-'||tmp_sub_no
				                                                                ||' SEQ_NO =' ||tmp_trd_seq_no
				                                                                ||' DATE ='   ||t_trd_dt
				                                                                ||' sqlcode ='||sqlcode);
				            t_err_msg := vn.fxc_get_err_msg('V','2491');
				            raise_application_error(-20011,t_err_msg||' ACNT_NO='||tmp_acnt_no||'-'||tmp_sub_no);
			        	end;

			        	tmp_acnt_no		:= C1.acnt_no;
			        	tmp_sub_no		:= C1.sub_no;
				        tmp_trd_seq_no	:= t_trd_seq_no;
			        end if;
			    end if;

	        end if;

	        /*====================================================================*/
	        /* TABLE UPDATE                                                       */
	        /* dsc01m00(������������) Update                                      */
	        /*====================================================================*/
	        if  ts_cnt_tp  !=  'Y01'  then  -- Security Account
	            UPDATE  vn.dsc01m00
	               set  tax_setl_yn       =  'Y'
	                 ,  tax_setl_dt       =  t_trd_dt
	                 ,  trd_seq_no        =  t_trd_seq_no
	             where  setl_dt           =  C1.setl_dt
	               and  acnt_no           =  C1.acnt_no
	               and  sub_no			  =  C1.sub_no
	               and  setl_frct_seq_no  =  C1.setl_frct_seq_no
	               and  mth_dt            =  C1.mth_dt
	            ;

	            /*================================================================*/
	            /*  pds_prof_cash_clear_setl :                                    */
	            /*================================================================*/
	        else
	            UPDATE  vn.dsc01m00
	               set  tax_setl_yn       =  'C'
	             where  setl_dt           =  C1.setl_dt
	               and  acnt_no           =  C1.acnt_no
	               and  sub_no			  =  C1.sub_no
	               and  setl_frct_seq_no  =  C1.setl_frct_seq_no
	               and  mth_dt            =  C1.mth_dt
	            ;
	        end if;
        END if;
    end loop;

    /* Last data checking of pdl_crd_loan_rt_proc_td*/
	o_cnt1 := 0;
    begin
    vn.pdl_crd_loan_rt_proc_td( t_trd_dt,  '2',
                                tmp_acnt_no, tmp_sub_no, tmp_trd_seq_no,
                                i_work_mn, i_work_trm,  o_cnt1 );
    exception
    when others then
        vn.pxc_log_write('pds_tax_setl_odd', ' crd_loan_td:'||' T_ACNT =' ||tmp_acnt_no||'-'||tmp_sub_no
                                                            ||' SEQ_NO =' ||tmp_trd_seq_no
                                                            ||' DATE ='   ||t_trd_dt
                                                            ||' sqlcode ='||sqlcode);
        t_err_msg := vn.fxc_get_err_msg('V','2491');
        raise_application_error(-20011,t_err_msg||' ACNT_NO='||tmp_acnt_no||'-'||tmp_sub_no);
	end;

end pds_tax_setl_odd;
/

