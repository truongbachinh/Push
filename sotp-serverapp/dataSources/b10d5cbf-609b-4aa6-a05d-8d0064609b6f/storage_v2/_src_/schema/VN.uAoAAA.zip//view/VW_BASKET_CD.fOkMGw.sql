create view VW_BASKET_CD as
select '00000' as item_cd, 'Ro Uy ban' as item_name
  from dual
union
select distinct t.item_cd, t.item_name
  from vn.dlm00m01 t, vn.ssi08m00 s8
 where t.item_tp = '06'
   and t.active_stat = 'Y'
   and t.item_cd = s8.basket_cd
   and s8.active_stat||s8.bk_active in ('I', 'Y','M','D','A','WY','WA','WD')
 order by 1
/

