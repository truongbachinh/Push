create PROCEDURE PVSD_MT542
(
  i_sec_cd  IN VARCHAR2,
  i_tp      IN VARCHAR2,
  i_biz_cd  IN VARCHAR2,
  i_message IN VARCHAR2
)
/*************************************************
    i_tp:
    1: Rut chung khoan (dung cho Xuat chung khoan: rmrm_cd = 221)
    2: Chuyen khoan chung khoan (dung cho loai Chuyen khoan CK khac: rmrk_cd = 236)
    3: Chuyen nhuong quyen mua CK

    i_biz_cd:
      001: TK
      002: CK + quyen
      003: Lenh
      004: Thanh toan + Cho vay

    i_mess:
      Cac tham so duoc ngan cach boi chuoi cac ky tu dac biet: !@#
      Doi voi bao cao yeu cau tham so dau tien phai la Ma bao cao. VD: CS001
    *************************************************/
 AS
  TYPE t_array IS TABLE OF VARCHAR2(200) INDEX BY PLS_INTEGER;

  v_send_dat VARCHAR2(4000);
  vn_message VARCHAR2(1000) := i_message;
  vn_pos     NUMBER := 0;
  i          NUMBER := 0;
  vn_var     t_array;

BEGIN

  vn.pxc_log_write('pvsd_mt542', 'Type: '||i_tp || '-' ||i_message);

	IF i_tp = '1' THEN
		WHILE INSTR(vn_message, '!@#') > 0
		LOOP
		  i      := i + 1;
		  vn_pos := INSTR(vn_message, '!@#');

		  vn_var(i) := substr(vn_message, 1, vn_pos - 1);

		  vn_message := substr(vn_message, vn_pos + 3);
		END LOOP;

		vn_var(i + 1) := vn_message;

		FOR C1 IN (SELECT A.PROC_DT,
				  A.STK_CD,
						decode(sign(A.QTY), 1, 'NORM', decode(sign(A.SB_LMT_QTY), 1, 'NORM', 'PEND')) STK_TP,
				  decode(sign(A.QTY), 1, '1', decode(sign(A.DELAY_QTY), 1, '1', '2')) VSD_STK_TP,
				  decode(sign(A.QTY), 1, A.QTY, decode(sign(A.SB_LMT_QTY), 1, A.SB_LMT_QTY, decode(sign(A.DELAY_QTY), 1, A.DELAY_QTY, A.DELAY_SB_QTY))) STK_QTY,
					replace(A.CNTE, '/', '?_?') CNTE,
							A.ACNT_NO,
							A.BOS_SEQ_NO,
				  DECODE(VN.FSS_GET_STK_TP(A.STK_CD), '20', 'FAMT', 'UNIT') UNIT,
				  VN.fvsd_getbiccode(i_sec_cd) BICCODE,
          A.VSD_BRCH
			   FROM VN.SSB05M00 A
			  WHERE A.PROC_DT = vn_var(1)
				AND A.BOS_SEQ_NO = vn_var(2)
				AND A.BOS_STAT = '1'
				AND	A.TRD_TP = '23')
		LOOP
				--Block: Thong tin chung
		  v_send_dat :=   ':16R:GENL' || chr(13) ||
				  ':20C::SEME//' || C1.BOS_SEQ_NO || chr(13) ||
				  ':23G:NEWM' || chr(13) ||
				  ':98A::PREP//' || to_char(SYSDATE, 'yyyymmdd') || chr(13) ||
				  --':16R:LINK' || chr(13) ||
				  --':20C:PREV' || chr(13) ||
				  --':16S:LINK' || chr(13) ||
				  --':16R:LINK' || chr(13) ||
				  --':20C:PCTI' || chr(13) ||
				  --':16S:LINK' || chr(13) ||
				  ':16S:GENL' || chr(13) ||

				--Block: Thong tin giao dich
				  ':16R:TRADDET' || chr(13) ||
				  ':98A::SETT//' || C1.PROC_DT || chr(13) ||
				  ':35B:/VN/' || C1.STK_CD || chr(13) ||
				  ':16R:FIA' || chr(13) ||
				  --':94B::PLIS//EXCH/' || C1.STK_MKT_TP || chr(13) ||
				  ':12A::CLAS//' || C1.STK_TP || '/' || C1.VSD_STK_TP || chr(13) ||
				  --':70E::FIAN//' || C1.QTY_TP || chr(13) ||
				  ':16S:FIA' || chr(13) ||
				  ':70E::SPRO//'|| 'SHAR' || chr(13) ||
				  ':16S:TRADDET' || chr(13) ||

				--Block: Thong tin chi tiet
				  ':16R:FIAC' || chr(13) ||
				  ':36B::SETT//' || C1.UNIT|| '/' || C1.STK_QTY || chr(13) ||
				  ':95P::ACOW//' || C1.BICCODE || chr(13) ||
				  ':97A::SAFE//' || C1.ACNT_NO || chr(13) ||
				  ':16S:FIAC' || chr(13) ||

				--Block: Thong tin thanh toan
				  ':16R:SETDET' || chr(13) ||
				  ':22F::SETR//' || 'TRAD' || chr(13) ||
				  ':22F::STCO//' || 'PHYS' || chr(13) ||
				  ':16R:SETPRTY' || chr(13) ||
				  ':95C::PSET//' || 'VN' || chr(13) ||
				  ':16S:SETPRTY' || chr(13) ||

				--Block: Doi tac thanh toan
				  ':16R:SETPRTY' || chr(13) ||
				  ':95P::REAG//' || C1.BICCODE || chr(13) ||
				  ':16S:SETPRTY' || chr(13) ||
				  ':16S:SETDET';

		  INSERT INTO VN.VSD01M00
			(REG_DT,
			 SEQ_NO,
			 BIZ_CD,
			 DAT_CD,
			 SND_DAT,
			 SND_TP,
			 WORK_DTM,
       VSD_BRCH
       )
		  VALUES
			(to_char(SYSDATE, 'yyyymmdd'),
			 C1.BOS_SEQ_NO,
			 i_biz_cd,
			 '542',
			 v_send_dat,
			 '1',
			 SYSDATE,
       C1.VSD_BRCH);

		END LOOP;

	ELSIF i_tp = '2' THEN
		WHILE INSTR(vn_message, '!@#') > 0
		LOOP
			i      := i + 1;
			vn_pos := INSTR(vn_message, '!@#');

			vn_var(i) := substr(vn_message, 1, vn_pos - 1);

			vn_message := substr(vn_message, vn_pos + 3);
		END LOOP;

		vn_var(i + 1) := vn_message;

		FOR C2 IN (
		SELECT 	B.PROC_DT,
				B.STK_CD,
				decode(sign(B.QTY), 1, 'NORM', decode(sign(B.SB_LMT_QTY), 1, 'NORM', 'PEND')) STK_TP,
				decode(sign(B.QTY), 1, '1', decode(sign(B.DELAY_QTY), 1, '1', '2')) VSD_STK_TP,
				decode(sign(B.QTY), 1, B.QTY, decode(sign(B.SB_LMT_QTY), 1, B.SB_LMT_QTY, decode(sign(B.DELAY_QTY), 1, B.DELAY_QTY, B.DELAY_SB_QTY))) STK_QTY,
					replace(B.CNTE, '/', '?_?') CNTE,
				B.ACNT_NO,
				decode(NVL(B.ANTH_CD, i_sec_cd), i_sec_cd, 'OWNI', 'OWNE') TRANS_TP,
				VN.fvsd_getbiccode(NVL(B.ANTH_CD, i_sec_cd)) RECV_BICCODE,
				B.ANTH_ACNT_NO,
				B.BOS_SEQ_NO,
				DECODE(VN.FSS_GET_STK_TP(B.STK_CD), '20', 'FAMT', 'UNIT') UNIT,
				VN.fvsd_getbiccode(i_sec_cd) BICCODE,
				B.VSD_BRCH,
				decode(B.VSD_BRCH, '02', 'VSDSVN02', 'VSDSVN01') VSD_BRCH_NM
		FROM 	VN.SSB05M00 B
		WHERE 	B.PROC_DT = vn_var(1)
		AND 	B.BOS_SEQ_NO = vn_var(2)
		AND 	B.BOS_STAT = '1')
		LOOP

				--Block: Thong tin chung
		  v_send_dat :=   ':16R:GENL' || chr(13) ||
				  ':20C::SEME//' || C2.BOS_SEQ_NO || chr(13) ||
				  ':23G:NEWM' || chr(13) ||
				  ':98A::PREP//' || to_char(SYSDATE, 'yyyymmdd') || chr(13) ||
				  --':16R:LINK' || chr(13) ||
				  --':20C:PREV' || chr(13) ||
				  --':16S:LINK' || chr(13) ||
				  --':16R:LINK' || chr(13) ||
				  --':20C:PCTI' || chr(13) ||
				  --':16S:LINK' || chr(13) ||
				  ':16S:GENL' || chr(13) ||

				--Block: Chuyen khoan chi tiet
				  ':16R:TRADDET' || chr(13) ||
				  ':98A::SETT//' || C2.PROC_DT || chr(13) ||
				  ':35B:/VN/' || C2.STK_CD || chr(13) ||
				  ':16R:FIA' || chr(13) ||
				  --':94B::PLIS//EXCH/' || C2.STK_MKT_TP || chr(13) ||
				  ':12A::CLAS//' || C2.STK_TP || '/' || C2.VSD_STK_TP || chr(13) ||
				  --':70E::FIAN//' || C2.QTY_TP || chr(13) ||
				  ':16S:FIA' || chr(13) ||
				  ':70E::SPRO//'|| C2.CNTE || chr(13) ||
				  ':16S:TRADDET' || chr(13) ||

				--Block: Thong tin tai khoan chuyen
				  ':16R:FIAC' || chr(13) ||
				  ':36B::SETT//' || C2.UNIT|| '/' || C2.STK_QTY || chr(13) ||
				  ':95P::ACOW//' || C2.BICCODE || chr(13) ||
				  ':97A::SAFE//' || C2.ACNT_NO || chr(13) ||
				  ':16S:FIAC' || chr(13) ||

				--Block: Thong tin thanh toan chi tiet
				  ':16R:SETDET' || chr(13) ||
				  ':22F::SETR//' || C2.TRANS_TP || chr(13) ||
				  ':22F::STCO//' || 'DLWM' || chr(13) ||
				  ':16R:SETPRTY' || chr(13) ||
				  ':95P::PSET//' || C2.VSD_BRCH_NM || chr(13) ||
				  ':16S:SETPRTY' || chr(13) ||
				  ':16R:SETPRTY' || chr(13) ||
				  ':95P::DEAG//' || C2.BICCODE || chr(13) ||
				  ':16S:SETPRTY' || chr(13) ||
				  ':16R:SETPRTY' || chr(13) ||
				  ':95P::REAG//' || C2.RECV_BICCODE || chr(13) ||
				  ':97A::SAFE//' || C2.ANTH_ACNT_NO || chr(13) ||
				  ':16S:SETPRTY' || chr(13) ||
				  ':16S:SETDET';

		  INSERT INTO VN.VSD01M00
			(REG_DT,
			 SEQ_NO,
			 BIZ_CD,
			 DAT_CD,
			 SND_DAT,
			 SND_TP,
			 WORK_DTM,
			 VSD_BRCH)
		  VALUES
			(to_char(SYSDATE, 'yyyymmdd'),
			 C2.BOS_SEQ_NO,
			 i_biz_cd,
			 '542',
			 v_send_dat,
			 '1',
			 SYSDATE,
			 C2.VSD_BRCH);

		END LOOP;

	ELSIF i_tp = '3' THEN
		WHILE INSTR(vn_message, '!@#') > 0
		LOOP
		  i      := i + 1;
		  vn_pos := INSTR(vn_message, '!@#');

		  vn_var(i) := substr(vn_message, 1, vn_pos - 1);

		  vn_message := substr(vn_message, vn_pos + 3);
		END LOOP;

		vn_var(i + 1) := vn_message;

		FOR C3 IN (
		SELECT 	B.PROC_DT,
				B.STK_CD,
				'CORP' STK_TP,
				'1' VSD_STK_TP,
				NVL(ASN_QTY,0) STK_QTY,
				replace(B.CNTE, '/', '?_?') CNTE,
				B.ACNT_NO,
				VN.fvsd_getbiccode(ANTH_CD) RECV_BICCODE,
				B.INQ_ACNT_NO ANTH_ACNT_NO,
				decode(ANTH_PROC_TP, '2', 'OWNI', 'OWNE') TRANS_TP,
				B.BOS_SEQ_NO,
				DECODE(VN.FSS_GET_STK_TP(B.STK_CD), '20', 'FAMT', 'UNIT') UNIT,
				VN.fvsd_getbiccode(i_sec_cd) BICCODE,
				NVL(A.RGT_VSD_SEQ,0) RGT_VSD_SEQ,
				vn.fss_get_vsd_brch(i_sec_cd, B.STK_CD) VSD_BRCH,
				decode(vn.fss_get_vsd_brch(i_sec_cd, B.STK_CD), '02', 'VSDSVN02', 'VSDSVN01') VSD_BRCH_NM,
				decode(D.IDNO_TP
                      ,'1'
                      ,'IDNO'
                      ,'2'
                      ,'CCPT'
                      ,'3'
                      ,'CORP'
                      ,'4'
                      ,'OTHR'
                      ,'5'
                      ,'FIIN'
                      ,'6'
                      ,'ARNU'
                      ,'7'
                      ,'GOVT') IDNO_TP,
                      replace(C.IDNO, '/', '?_?') IDNO,
                      D.IDNO_ISS_DT,
                      C.CUST_NM
		FROM 	VN.SRR06M00 B,
				VN.SRR01M00 A,
				VN.AAA01M00 C,
				VN.AAA02M00 D
        WHERE 	A.Rgt_Std_Dt = B.RGT_STD_DT
        AND   	A.Rgt_Tp = b.rgt_tp
        and   	a.stk_cd = b.stk_cd
        and   	a.seq_no = b.rgt_seq_no
		AND   	B.ACNT_NO = C.ACNT_NO
        AND   	B.SUB_NO = C.SUB_NO
        and   	C.IDNO = D.IDNO
        AND   	B.PROC_DT = vn_var(1)
        AND 	B.BOS_SEQ_NO = vn_var(2)
        AND 	B.BOS_STAT = '1')
		LOOP

				--Block: Thong tin chung
		  v_send_dat :=   ':16R:GENL' || chr(13) ||
				  ':20C::SEME//' || C3.BOS_SEQ_NO || chr(13) ||
				  ':23G:NEWM' || chr(13) ||
				  ':98A::PREP//' || to_char(SYSDATE, 'yyyymmdd') || chr(13) ||
				  --':16R:LINK' || chr(13) ||
				  --':20C:PREV' || chr(13) ||
				  --':16S:LINK' || chr(13) ||
				   ':16R:LINK' || chr(13) ||
				  ':20C::PCTI//' || C3.RGT_VSD_SEQ || chr(13) ||
				  ':16S:LINK' || chr(13) ||
				  ':16S:GENL' || chr(13) ||

				--Block: Chuyen khoan chi tiet
				  ':16R:TRADDET' || chr(13) ||
				  ':98A::SETT//' || C3.PROC_DT || chr(13) ||
				  ':35B:/VN//'|| 'RHTS//' || C3.STK_CD || chr(13) ||
				  ':16R:FIA' || chr(13) ||
				  --':94B::PLIS//EXCH/' || C2.STK_MKT_TP || chr(13) ||
				  ':12A::CLAS//' || C3.STK_TP || '/' || C3.VSD_STK_TP || chr(13) ||
				  --':70E::FIAN//' || C2.QTY_TP || chr(13) ||
				  ':16S:FIA' || chr(13) ||
				  ':70E::SPRO//'|| C3.CNTE || chr(13) ||
				  ':16S:TRADDET' || chr(13) ||

				--Block: Thong tin tai khoan chuyen
				  ':16R:FIAC' || chr(13) ||
				  ':36B::SETT//' || C3.UNIT || '/' || C3.STK_QTY || chr(13) ||
				  ':70D::DENC//' || C3.CNTE || chr(13) ||
								 C3.IDNO_TP || chr(13) ||
								 C3.IDNO || chr(13) ||
								 C3.IDNO_ISS_DT || chr(13) ||
								 C3.CUST_NM || chr(13) ||
				  ':95P::ACOW//' || C3.BICCODE || chr(13) ||
				  ':97A::SAFE//' || C3.ACNT_NO || chr(13) ||
				  ':16S:FIAC' || chr(13) ||

				--Block: Thong tin thanh toan chi tiet
				  ':16R:SETDET' || chr(13) ||
				  ':22F::SETR//' || C3.TRANS_TP || chr(13) ||
				  ':22F::STCO//' || 'DLWM' || chr(13) ||
				  ':16R:SETPRTY' || chr(13) ||
				  ':95P::PSET//' || C3.VSD_BRCH_NM || chr(13) ||
				  ':16S:SETPRTY' || chr(13) ||
				  ':16R:SETPRTY' || chr(13) ||
				  ':95P::REAG//' || C3.RECV_BICCODE || chr(13) ||
				  ':97A::SAFE//' || C3.ANTH_ACNT_NO || chr(13) ||
				  ':16S:SETPRTY' || chr(13) ||
				  ':16S:SETDET';

		  INSERT INTO VN.VSD01M00
			(REG_DT,
			 SEQ_NO,
			 BIZ_CD,
			 DAT_CD,
			 SND_DAT,
			 SND_TP,
			 WORK_DTM,
			 VSD_BRCH)
		  VALUES
			(to_char(SYSDATE, 'yyyymmdd'),
			 C3.BOS_SEQ_NO,
			 i_biz_cd,
			 '542',
			 v_send_dat,
			 '1',
			 SYSDATE,
			 C3.VSD_BRCH);

		END LOOP;
	END IF;

END PVSD_MT542;
/

