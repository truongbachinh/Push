create function fdl_get_money_expr_dt
(
    i_lnd_tp         in   varchar2,       --
    i_acnt_no        in   varchar2,       --
    i_sub_no         in   varchar2,       --
    i_lnd_bank_cd    in   varchar2,       --
    i_lnd_dt         in   varchar2,       --
    i_mth_dt         in   varchar2,       --
    i_stk_cd         in   varchar2        --
)
    return  VARCHAR2
as
	o_expr_dt         VARCHAR2(8);

    t_lnd_rm_amt      number := 0   ;

begin

/*============================================================================*/
/* Valiabl Initialize                                                         */
/*============================================================================*/
    o_expr_dt  :=  '30000101';

/*============================================================================*/
/* generl commission return                                                   */
/*============================================================================*/
    for C1 IN (
        select  max(expr_dt)  expr_dt
          from  vn.dlm04m00
         where  lnd_tp          =  i_lnd_tp
           and  acnt_no         =  i_acnt_no
           and  sub_no          =  i_sub_no
           and  lnd_bank_cd     =  i_lnd_bank_cd
           and  lnd_dt          =  i_lnd_dt
           and  mth_dt          =  i_mth_dt
           and  stk_cd          =  i_stk_cd
           and  lnd_acpt_tp     =  '01'
    ) loop
        o_expr_dt  :=  nvl(C1.expr_dt,'30000101');
        return  o_expr_dt;
    end loop;

    return  o_expr_dt;

end fdl_get_money_expr_dt;
/

