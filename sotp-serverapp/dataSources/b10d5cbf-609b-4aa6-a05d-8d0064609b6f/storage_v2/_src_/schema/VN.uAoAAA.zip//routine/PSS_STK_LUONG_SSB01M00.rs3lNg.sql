create procedure pss_stk_luong_ssb01m00
( i_proc_dt    in   varchar2,
  i_acnt_no    in   varchar2,
   i_sub_no    in   varchar2,
  i_work_mn    in   varchar2,
  i_work_trm   in   varchar2,
  o_proc_cnt   out  number
 ) is
 
/*var o_proc_cnt      number;
exec pss_stk_luong_ssb01m00('20140219','%','%', 'DAILY', 'SYSTEM', :o_proc_cnt);
print o_cnt*/
/***************************************************************************/
/* Right standard work                                                     */
/* 2007-10-22                                                              */
/***************************************************************************/

begin

 vn.pxc_log_write('pss_stk_luong_ssb01m00', 'start');

 o_proc_cnt  := 0;

delete from vn.ssb01m00;

commit;

 for  c1  in (

	select  acnt_no,
			sub_no,
			stk_cd,
			vn.fss_get_stk_tp(stk_cd) stk_tp,
			own_qty,
			book_amt,
			bclm_qty,
			mrtg_lnd_qty,
			mrtg_buy_qty,
			nvl(sb_lim_qty,0)      sb_lim_qty,
			nvl(mov_lim_qty,0)     mov_lim_qty,
			nvl(lim_req_qty,0)     lim_req_qty ,
			nvl(outq_req_qty,0)    outq_req_qty,
			nvl(delay_qty , 0 )    delay_qty ,
			nvl(delay_sb_qty  , 0 )    delay_sb_qty ,
			nvl(delay_mov_qty , 0 )    delay_mov_qty ,
			nvl(delay_reg_qty , 0 )    delay_reg_qty ,
			nvl(sbst_dpo,0)        sbst_dpo ,
			nvl(sbst_able_block,0) sbst_able_block,
			nvl(sbst_unit_amt,0)   sbst_unit_amt,
      nvl(stk_room_used, 0) stk_room_used,
      nvl(stk_room_amt_used, 0) stk_room_amt_used
    from    vn.ssb01h00
	where  rgt_std_dt = '20140218'
    and  acnt_no like i_acnt_no
    and sub_no like i_sub_no

  ) loop

	o_proc_cnt := o_proc_cnt + 1;

    insert into vn.ssb01m00
	  (  
		  acnt_no,
		  sub_no,
		  stk_cd,
      stk_tp,
		  own_qty,
		  book_amt,
		  bclm_qty,
		  mrtg_lnd_qty,
		  mrtg_buy_qty,
		  sb_lim_qty,
		  mov_lim_qty,
		  lim_req_qty,
		  outq_req_qty,
		  delay_qty ,
		  delay_sb_qty ,
		  delay_mov_qty ,
		  delay_reg_qty,
		  sbst_dpo ,
		  sbst_able_block ,
		  sbst_unit_amt ,
		  work_mn,
		  work_dtm,
		  work_trm,
      stk_room_used,
      stk_room_amt_used
      ) values (
	    
		  c1.acnt_no,
		  c1.sub_no,
		  c1.stk_cd,
      c1.stk_tp,
		  c1.own_qty,
		  c1.book_amt,
		  c1.bclm_qty,
		  c1.mrtg_lnd_qty,
		  c1.mrtg_buy_qty,
		  c1.sb_lim_qty,
		  c1.mov_lim_qty,
		  c1.lim_req_qty,
		  c1.outq_req_qty ,
		  c1.delay_qty  ,
		  c1.delay_sb_qty  ,
		  c1.delay_mov_qty  ,
		  c1.delay_reg_qty,
		  c1.sbst_dpo ,
		  c1.sbst_able_block ,
		  c1.sbst_unit_amt ,
		  i_work_mn,
		  sysdate,
		  i_work_trm,
      c1.stk_room_used,
      c1.stk_room_amt_used
	  );
    
 --commit;

 end loop;

 vn.pxc_log_write('pss_stk_luong_ssb01m00', 'end');
end  pss_stk_luong_ssb01m00;
/

