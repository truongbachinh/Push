create procedure pts_tso04m00_col
(
	acnt_no			in		varchar2,       -- account number (068CXXXXXX)
	sub_no			in		varchar2,
	b_bnk_no		in		varchar2,		-- before bank number
	a_bnk_no		in		varchar2		-- after bank number
) as

t_acnt_no			varchar2(10)	:= acnt_no;
t_sub_no			varchar2(2)		:= sub_no;
t_b_bnk_no			varchar2(4)		:= b_bnk_no;
t_a_bnk_no			varchar2(4)		:= a_bnk_no;
t_chk				number;

/*!
    \file     pts_tso04m00_col
	\brief    tso04m00 update

	\section intro Program Information
		- Program Name              : pts_tso04m00_col
		- Service Name              :
		- Related Client Program- Client Program ID :
		- Related Tables            : tso04m00
		- Dev. Date                 : 2009/07/27
		- Developer                 : jcSa
		- Business Logic Desc.      :
		- Latest Modification Date  :

	\section history Program Modification History
		- 1.0  2009/07/27

	\section hardcoding Hard-Coding List

	\section info Additional Reference Comments
*/

begin
	t_chk := 0;
    for  c1  in
    (
		select  acnt_no as acnt_no,
				sub_no as sub_no,
		        stk_cd as stk_cd,
		       	sum (td_sell_ord_qty) as td_sell_ord_qty,
				sum (td_sell_mth_qty) as td_sell_mth_qty,
				sum (td_sell_mth_amt) as td_sell_mth_amt,
				sum (td_buy_mth_qty)  as td_buy_mth_qty,
				sum (td_buy_mth_amt)  as td_buy_mth_amt,
				sum (pd_sell_mth_qty) as pd_sell_mth_qty,
				sum (pd_sell_mth_amt) as pd_sell_mth_amt,
				sum (pd_buy_mth_qty)  as pd_buy_mth_qty,
				sum (pd_buy_mth_amt)  as pd_buy_mth_amt,
				sum (ppd_sell_mth_qty) as ppd_sell_mth_qty,
				sum (ppd_sell_mth_amt) as ppd_sell_mth_amt,
				sum (ppd_buy_mth_qty)  as ppd_buy_mth_qty,
				sum (ppd_buy_mth_amt)  as ppd_buy_mth_amt,
				sum (pppd_sell_mth_qty) as pppd_sell_mth_qty,
				sum (pppd_sell_mth_amt) as pppd_sell_mth_amt,
				sum (pppd_buy_mth_qty) as pppd_buy_mth_qty,
				sum (pppd_buy_mth_amt) as pppd_buy_mth_amt
		  from	vn.tso04m00
		 where	acnt_no = t_acnt_no
		   and	sub_no = trim ( t_sub_no )
	   	   and	(bank_cd like t_b_bnk_no
	   	    or  bank_cd = t_a_bnk_no  )
		group by acnt_no,sub_no, stk_cd
    )

    loop
			delete from vn.tso04m00
			 where acnt_no = t_acnt_no
			   and sub_no = trim ( t_sub_no )
			   and bank_cd like t_b_bnk_no
			   and stk_cd  = c1.stk_cd ;

			insert into vn.tso04m00
			(
				acnt_no,
				sub_no,
				bank_cd,
				stk_cd,
				td_sell_ord_qty,
				td_sell_mth_qty,
				td_sell_mth_amt,
				td_buy_mth_qty,
				td_buy_mth_amt,
				pd_sell_mth_qty,
				pd_sell_mth_amt,
				pd_buy_mth_qty,
				pd_buy_mth_amt,
				ppd_sell_mth_qty,
				ppd_sell_mth_amt,
				ppd_buy_mth_qty,
				ppd_buy_mth_amt,
				pppd_sell_mth_qty,
				pppd_sell_mth_amt,
				pppd_buy_mth_qty,
				pppd_buy_mth_amt
			)
			values
			(
				t_acnt_no,
				t_sub_no,
				t_a_bnk_no,
				c1.stk_cd,
				c1.td_sell_ord_qty,
				c1.td_sell_mth_qty,
				c1.td_sell_mth_amt,
				c1.td_buy_mth_qty,
				c1.td_buy_mth_amt,
				c1.pd_sell_mth_qty,
				c1.pd_sell_mth_amt,
				c1.pd_buy_mth_qty,
				c1.pd_buy_mth_amt,
				c1.ppd_sell_mth_qty,
				c1.ppd_sell_mth_amt,
				c1.ppd_buy_mth_qty,
				c1.ppd_buy_mth_amt,
				c1.pppd_sell_mth_qty,
				c1.pppd_sell_mth_amt,
				c1.pppd_buy_mth_qty,
				c1.pppd_buy_mth_amt
			);

	end loop;

end pts_tso04m00_col;
/

