create procedure psr_rgt_inoutbil_p
 (i_apy_dt       in     varchar2, -- add 20100723
  i_std_dt       in       varchar2,
  i_stk_cd       in       varchar2,
  i_rgt_tp       in       varchar2,
  i_proc_dt      in       varchar2, -- inq date
  i_exp_dt       in       varchar2, -- out date
  i_rgt_amt      in       number  ,
  i_list_stk_cd  in       varchar2,
  i_seq_no       in       number,
  i_work_mn      in       varchar2,
  i_work_trm     in       varchar2,
  o_proc_cnt     in out   number
 ) is

  vs_acnt_no      varchar2(10);
  vs_sub_no       varchar2(2);
  vs_list_stk_cd  varchar2(12);
  vs_stk_nm       varchar2(100);
  vs_acnt_mng_bnh varchar2(5);
  vn_own_qty      number;
  vn_loan_qty      number;
  vn_outq_qty      number;
  vn_mov_lim_qty   number;
  vn_asn_qty      number;
  vn_sbst_amt     number;
  vn_bank_cnt_yn  varchar2(1);
  vn_bank_cd      varchar2(4);
  --
  vs_fnc_cd        varchar2(10);
  vs_sms_msg       varchar2(200);
  vs_msg_lang      varchar2(1);
  vs_asn_qty       varchar2(30);
  --
  vo_trd_seq_no   number;
  vo_rcdb_no      number;
  vo_pre_rm       number;
  vo_now_rm       number;
  vo_inq_trd_no   number;
  vo_outq_trd_no  number;

  o_trd_dt        varchar2(8);
  o_trd_seq_no    number;
  o_dpo_prerm     number;
  o_dpo_nowrm     number;
  o_acnt_place    varchar2(10);
  o_bnhof_tp      varchar2(2);
  o_proc_bnhof_tp varchar2(2);
  o_cnt            number  := 0;
  --
  tmp_cnt             number; /* LTHN-248 */
  tmp_tax_delay_qty   number; /* LTHN-248 */
  tmp_tax_qty         number; /* LTHN-248 */
  tmp_cnte            varchar2(500); /* LTHN-248 */
  tmp_inq_dt          varchar2(8) := i_exp_dt; /* LTHN-248 */
  tmp_rmrk_cd         varchar2(3); /* LTHN-248 */
  tmp_grp_tp          varchar2(1); /* LTHN-248 */
  tn_min_proc_dt_inq  varchar2(8); /* LTHN-248 */
  tn_max_proc_dt_inq  varchar2(8); /* LTHN-248 */
  tn_max_id_inq       number := 0; /* LTHN-248 */
  tn_min_proc_dt_apy  varchar2(8); /* LTHN-248 */
  tn_max_proc_dt_apy  varchar2(8); /* LTHN-248 */
  tn_max_id_apy       number := 0; /* LTHN-248 */
  tn_max_id_vwdate    number := 0; /* LTHN-248 */
  v_count             number := 0; /* LTHN-248 */
/* ************************************** Log changes ****************************************
02-Jan-2019 vnjvthangnm Gui tin nhan SMS
14-Dec-2020 vnjvthangnm LTHN-248
******************************************************************************************* */
begin
  
  vn.pxc_log_write('psr_rgt_inoutbil_p', '  start    '  );
  vn.pxc_log_write('psr_rgt_inoutbil_p', 'apply_date ' || i_apy_dt );
  vn.pxc_log_write('psr_rgt_inoutbil_p', 'std_dt ' || i_std_dt);
  vn.pxc_log_write('psr_rgt_inoutbil_p', 'stk_cd ' || i_stk_cd);
  vn.pxc_log_write('psr_rgt_inoutbil_p', 'rgt_tp ' || i_rgt_tp);
  vn.pxc_log_write('psr_rgt_inoutbil_p', 'proc_dt ' || i_proc_dt);
  vn.pxc_log_write('psr_rgt_inoutbil_p', 'exp_dt ' || i_exp_dt);
  vn.pxc_log_write('psr_rgt_inoutbil_p', 'rgt_amt ' || i_rgt_amt);
  vn.pxc_log_write('psr_rgt_inoutbil_p', 'list_stk_cd ' || i_list_stk_cd);
  vn.pxc_log_write('psr_rgt_inoutbil_p', 'seq_no ' || i_seq_no);

  if i_rgt_tp = '1' then

    for  c1  in (

      select  acnt_no,
              sub_no,
              nvl(cons_sbst_qty,0)  asn_qty,
              vn.fss_get_stk_nm( i_list_stk_cd)  stk_nm,
              acnt_mng_bnh
      from  vn.srr02m00
      where rgt_std_dt    =  i_std_dt
        and stk_cd        =  i_stk_cd
        and rgt_tp        =  '1'
        and cons_sbst_qty > 0
        and seq_no        = i_seq_no
        and inq_trd_no    = 0
        and vn.faa_acnt_stat_g( acnt_no,sub_no) = '1'

    ) loop

      vs_acnt_no       := c1.acnt_no;
      vs_sub_no        := c1.sub_no;
      vn_asn_qty       := c1.asn_qty;
      vs_stk_nm        := c1.stk_nm;
      vs_acnt_mng_bnh  := c1.acnt_mng_bnh;

      vn.pxc_log_write('psr_rgt_inoutbil_p', vs_acnt_no||' rgt_tp 1');

      vn.pss_inbil_p(
        i_proc_dt,
        vs_acnt_mng_bnh,
        '5',
        vs_acnt_no,
        vs_sub_no,
        i_list_stk_cd,
        vs_stk_nm,
        vn_asn_qty,
        i_rgt_amt,
        i_apy_dt,
        '',
        '',
        '',
        '204',
        i_work_mn,
        i_work_trm,
        vn.faa_acnt_bnh_cd_g( '3',vs_acnt_no, vs_sub_no),
        vo_trd_seq_no,
        vo_pre_rm,
        vo_now_rm
      );

      /* 20100723 Blocking the bonus amount  According apply date  by jung */

      if i_apy_dt > vn.vwdate  then

        vn.psr_rgt_inbil_bk (
          vs_acnt_no    ,
          vs_sub_no     ,
          i_list_stk_cd ,
          '204'         ,
          vo_trd_seq_no ,
          vn_asn_qty    ,
          i_apy_dt      ,
          i_work_mn     ,
          i_work_trm
        ) ;
      end if ;

      /* 20100623 rights sbst  processing by jung */

      vn.psr_sbst_pay_p (
        's' ,  -- stock
        vn_asn_qty ,
        i_list_stk_cd ,
        vs_acnt_no    ,
        vs_sub_no     ,
        i_work_mn     ,
        i_work_trm
      );

      update  vn.srr02m00
      set     inq_trd_no  = vo_trd_seq_no
      where   rgt_std_dt  = i_std_dt
      and     stk_cd      = i_stk_cd
      and     rgt_tp      = '1'
      and     acnt_no     = vs_acnt_no
      and     sub_no      = vs_sub_no
      and     seq_no      = i_seq_no;

      vn.pdl_crd_loan_rt_proc_td
        ( i_proc_dt
          ,'2' -- stock
          ,vs_acnt_no
          ,vs_sub_no
          ,vo_trd_seq_no
          ,i_work_mn
          ,i_work_trm
          ,o_cnt
        );

      /* Send SMS */
      select decode(acnt_tp, 'F', 'E', 'V') msg_lang
      into vs_msg_lang
      from vn.aaa01m00
      where acnt_no = vs_acnt_no
      and sub_no = vs_sub_no;

      vs_fnc_cd := 'F02112';
      vs_asn_qty := vn.fxc_format_number (vn_asn_qty,0,vs_msg_lang);

      if vs_msg_lang = 'V' then
        vn.pxc_log_write('psr_rgt_inoutbil_p', 'tieng viet');
        vs_sms_msg := '||' || vs_acnt_no || '||' || vs_sub_no || '||' || i_stk_cd || '||' || vs_asn_qty;
      elsif vs_msg_lang = 'E' then
        vn.pxc_log_write('psr_rgt_inoutbil_p', 'tieng anh');
        vs_sms_msg := '||' || i_stk_cd || '||' || vs_asn_qty || '||' || vs_acnt_no || '||' || vs_sub_no;
      end if;

      vn.pxc_sms_ins(
        null,       --i_send_dt          in varchar2,                         -- can put NULL, get from sysdate
        null,       --i_recv_phone_no    in varchar2,                         -- can put NULL, get from account
        null,       --i_send_phone_no    in varchar2,                         -- can put NULL, get from company
        vs_fnc_cd,  --i_func_cd          in varchar2,                         -- NOT null
        null,       --i_msg_lang         in varchar2,                         -- can put NULL, get from account
        vs_sms_msg, --i_sms_msg          in varchar2,                         -- NOT null
        i_work_mn,  --i_work_mn          in varchar2,                         -- can put NULL
        i_work_trm, --i_work_trm         in varchar2,                         -- can put NULL
        vs_acnt_no, --vs_acnt_no          in varchar2      default null,       -- can put NULL
        vs_sub_no   --vs_sub_no           in varchar2      default null        -- can put NULL
      );
      /* Push notification */
      vn.pxc_notif_ins(
        vs_acnt_no, --i_acnt_no          in varchar2,    -- NOT NULL
        vs_sub_no,  --i_sub_no           in varchar2,    -- NOT NULL
        vs_fnc_cd,  --i_func_cd          in varchar2,    -- NOT null
        null,       --i_msg_lang         in varchar2,    -- can put NULL, get from account
        vs_sms_msg, --i_sms_msg          in varchar2,    -- NOT null
        '1',        --i_notif_tp         in varchar2,    -- NOT null
        i_work_mn,  --i_work_mn          in varchar2,    -- can put NULL
        i_work_trm  --i_work_trm         in varchar2     -- can put NULL
      );

    end loop;

    update  vn.srr01m00
    set     rgt_proc_stat = '5'
    where   rgt_std_dt    = i_std_dt
    and     stk_cd        = i_stk_cd
    and     rgt_tp        = '1'
    and     seq_no        = i_seq_no;

  elsif i_rgt_tp = '4' then

    for  e1  in (

      select  acnt_no,
              sub_no,
              nvl(cons_sbst_qty,0)  asn_qty,
              vn.fss_get_stk_nm( i_list_stk_cd)  stk_nm,
              acnt_mng_bnh
         from vn.srr02m00
        where rgt_std_dt    =  i_std_dt
          and stk_cd        =  i_stk_cd
          and rgt_tp        =  '4'
          and cons_sbst_qty > 0
          and seq_no        = i_seq_no
          and inq_trd_no    = 0
          and vn.faa_acnt_stat_g(acnt_no,sub_no) = '1'
    ) loop

      vs_acnt_no       := e1.acnt_no;
      vs_sub_no        := e1.sub_no;
      vn_asn_qty       := e1.asn_qty;
      vs_stk_nm        := e1.stk_nm;
      vs_acnt_mng_bnh  := e1.acnt_mng_bnh;

      vn.pxc_log_write('psr_rgt_inoutbil_p', vs_acnt_no||' rgt_tp 4');

      vn.pss_inbil_p(
        i_proc_dt,
        vs_acnt_mng_bnh,
        '5',
        vs_acnt_no,
        vs_sub_no,
        i_list_stk_cd,
        vs_stk_nm,
        vn_asn_qty,
        i_rgt_amt,
        i_apy_dt,
        '',
        '',
        '',
        '204',
        i_work_mn,
        i_work_trm,
        vn.faa_acnt_bnh_cd_g( '3',vs_acnt_no,vs_sub_no),
        vo_trd_seq_no,
        vo_pre_rm,
        vo_now_rm
      );

      /* 20100723 Blocking the bonus amount  According apply date  by jung */

      if i_apy_dt >  vn.vwdate  then

          vn.psr_rgt_inbil_bk (
            vs_acnt_no    ,
            vs_sub_no    ,
            i_list_stk_cd ,
            '204'         ,
            vo_trd_seq_no ,
            vn_asn_qty    ,
            i_apy_dt      ,
            i_work_mn     ,
            i_work_trm
          ) ;
      end if ;

      /* 20100623 rights sbst  processing by jung */

      vn.psr_sbst_pay_p (
        's' ,  -- stock
        vn_asn_qty ,
        i_list_stk_cd ,
        vs_acnt_no    ,
        vs_sub_no    ,
        i_work_mn     ,
        i_work_trm
      );

      update  vn.srr02m00
      set     inq_trd_no  = vo_trd_seq_no
      where   rgt_std_dt  = i_std_dt
      and     stk_cd      = i_stk_cd
      and     rgt_tp      = '4'
      and     acnt_no     = vs_acnt_no
      and     sub_no      = vs_sub_no
      and     seq_no      = i_seq_no;

    vn.pdl_crd_loan_rt_proc_td
      ( i_proc_dt
        ,'2' -- stock
        ,vs_acnt_no
        ,vs_sub_no
        ,vo_trd_seq_no
        ,i_work_mn
        ,i_work_trm
        ,o_cnt
      );

    end loop;

    update  vn.srr01m00
    set     rgt_proc_stat = '5'
    where   rgt_std_dt    = i_std_dt
    and     stk_cd        = i_stk_cd
    and     rgt_tp        = '4'
    and     seq_no        = i_seq_no;


  elsif i_rgt_tp = '5' then

    for  c2  in (

      select  acnt_no,
              sub_no,
              nvl(cons_sbst_qty,0)  asn_qty,
              vn.fss_get_stk_nm( i_list_stk_cd)  stk_nm,
              acnt_mng_bnh
         from vn.srr02m00
        where rgt_std_dt    =  i_std_dt
          and stk_cd        =  i_stk_cd
          and rgt_tp        =  '5'
          and cons_sbst_qty > 0
          and seq_no        = i_seq_no
          and inq_trd_no    = 0
          and vn.faa_acnt_stat_g(acnt_no,sub_no) = '1'
    ) loop

      vs_acnt_no       := c2.acnt_no;
      vs_sub_no        := c2.sub_no;
      vn_asn_qty       := c2.asn_qty;
      vs_stk_nm        := c2.stk_nm;
      vs_acnt_mng_bnh  := c2.acnt_mng_bnh;

      vn.pxc_log_write('psr_rgt_inoutbil_p', vs_acnt_no||' rgt_tp 5');

      vn.pss_inbil_p(
        i_proc_dt,
        vs_acnt_mng_bnh,
        '5',
        vs_acnt_no,
        vs_sub_no,
        i_list_stk_cd,
        vs_stk_nm,
        vn_asn_qty,
        i_rgt_amt,
        i_apy_dt,
        '',
        '',
        '',
        '208',
        i_work_mn,
        i_work_trm,
        vn.faa_acnt_bnh_cd_g( '3',vs_acnt_no,vs_sub_no),
        vo_trd_seq_no,
        vo_pre_rm,
        vo_now_rm
      );

      /* 20100723 Blocking the bonus amount  According apply date  by jung */

      if i_apy_dt >  vn.vwdate  then

        vn.psr_rgt_inbil_bk (
          vs_acnt_no    ,
          vs_sub_no    ,
          i_list_stk_cd ,
          '208'         ,
          vo_trd_seq_no ,
          vn_asn_qty    ,
          i_apy_dt      ,
          i_work_mn     ,
          i_work_trm
        ) ;
      end if ;

      /* 20100623 rights sbst  processing by jung */

      vn.psr_sbst_pay_p (
        's' ,  -- stock
        vn_asn_qty ,
        i_list_stk_cd ,
        vs_acnt_no    ,
        vs_sub_no    ,
        i_work_mn     ,
        i_work_trm
      );

      update  vn.srr02m00
      set     inq_trd_no  = vo_trd_seq_no
      where   rgt_std_dt  = i_std_dt
      and     stk_cd      = i_stk_cd
      and     rgt_tp      = '4'
      and     acnt_no     = vs_acnt_no
      and     sub_no      = vs_sub_no
      and     seq_no      = i_seq_no;

      vn.pdl_crd_loan_rt_proc_td
        ( i_proc_dt
          ,'2' -- stock
          ,vs_acnt_no
          ,vs_sub_no
          ,vo_trd_seq_no
          ,i_work_mn
          ,i_work_trm
          ,o_cnt
        );

    end loop;

    update  vn.srr01m00
    set     rgt_proc_stat = '5'
    where   rgt_std_dt    = i_std_dt
    and     stk_cd        = i_stk_cd
    and     rgt_tp        = '5'
    and     seq_no        = i_seq_no;

  elsif  i_rgt_tp  = '2'  then

    for f1 in (

      select  acnt_no,
              sub_no,
              asn_qty,
              vn.fss_get_stk_nm( i_list_stk_cd)  stk_nm,
              acnt_mng_bnh
         from vn.srr02m00
        where rgt_std_dt    =  i_std_dt
          and stk_cd        =  i_stk_cd
          and rgt_tp        =  '2'
          and seq_no        = i_seq_no
          and asn_qty       > 0
          and inq_trd_no    = 0
          and vn.faa_acnt_stat_g( acnt_no,sub_no) = '1'
    ) loop

      vs_acnt_no       := f1.acnt_no;
      vs_sub_no        := f1.sub_no;
      vn_asn_qty       := f1.asn_qty;
      vs_stk_nm        := f1.stk_nm;
      vs_acnt_mng_bnh  := f1.acnt_mng_bnh;

      vn.pss_inbil_p(
        i_proc_dt,
        vs_acnt_mng_bnh,
        '5',
        vs_acnt_no,
        vs_sub_no,
        i_list_stk_cd,
        vs_stk_nm,
        vn_asn_qty,
        i_rgt_amt,
        i_apy_dt,
        '',
        '',
        '',
        '205',
        i_work_mn,
        i_work_trm,
        vn.faa_acnt_bnh_cd_g( '3',vs_acnt_no, vs_sub_no),
        vo_trd_seq_no,
        vo_pre_rm,
        vo_now_rm
      );

      vn.pxc_log_write('psr_rgt_inoutbil_p', vs_acnt_no||'rgt_tp 2 ');

      /* LTHN-248: Thue TNCN cho quyen CPT, CT bang CP */
      tmp_grp_tp := '0';
      select b.grp_tp
        into tmp_grp_tp
        from aaa01m00 a, aaa02m00 b
       where a.idno = b.idno
         and a.acnt_no = vs_acnt_no
         and a.sub_no = '00'
         and a.acnt_stat = '1';
      
      if tmp_grp_tp = '1' then
        tmp_cnte := 'Co phieu thuong, ma ' || i_stk_cd || ', ngay DKCC ' || i_std_dt || ', seq ' || to_char(i_seq_no);
        tmp_rmrk_cd := '205';
        select count(*) 
          into tmp_cnt
          from ssb05m10
         where acnt_no = vs_acnt_no
           and stk_cd = i_list_stk_cd;
           
        if tmp_cnt = 0 then
          /* Insert vao bang hien tai */
          if i_apy_dt <= vwdate then
            tmp_tax_delay_qty   := 0;
            tmp_tax_qty         := vn_asn_qty;
          else
            tmp_tax_delay_qty   := vn_asn_qty;
            tmp_tax_qty         := 0;
          end if;
          
          vn.pxc_log_write('psr_rgt_inoutbil_p', 'CPT: Insert into ssb05m10');
          vn.pxc_log_write('psr_rgt_inoutbil_p', 'tmp_tax_qty: ' || to_char(tmp_tax_qty));
          vn.pxc_log_write('psr_rgt_inoutbil_p', 'tmp_tax_delay_qty: ' || to_char(tmp_tax_delay_qty));
          
          insert into ssb05m10
          ( acnt_no,          -- 1
            stk_cd,           -- 2
            tax_qty,          -- 3
            tax_delay_qty,    -- 4
            create_mn,        -- 5
            create_dtm,       -- 6
            create_trm        -- 7
          )
          values
          ( vs_acnt_no,               -- 1
            i_list_stk_cd,            -- 2
            tmp_tax_qty,              -- 3
            tmp_tax_delay_qty,        -- 4
            i_work_mn,                -- 5
            sysdate,                  -- 6
            i_work_trm                -- 7
            );
        else
          /* Lay SL cho HCCN can tinh thue hien tai */
          select tax_qty,     tax_delay_qty
            into tmp_tax_qty, tmp_tax_delay_qty
            from ssb05m10
           where acnt_no = vs_acnt_no
             and stk_cd = i_list_stk_cd;
          
          if i_apy_dt <= vwdate then
            tmp_tax_qty         := tmp_tax_qty + vn_asn_qty;
          else
            tmp_tax_delay_qty   := tmp_tax_delay_qty + vn_asn_qty;
          end if;
          
          /* Cap nhat SL HCCN can tinh thue */
          vn.pxc_log_write('psr_rgt_inoutbil_p', 'CPT: Update ssb05m10');
          update ssb05m10
             set tax_qty = tmp_tax_qty,
                 tax_delay_qty = tmp_tax_delay_qty
           where acnt_no = vs_acnt_no
             and stk_cd = i_list_stk_cd;
        end if;
        /* Luu lich su */
        vn.pxc_log_write('psr_rgt_inoutbil_p', 'CPT: Insert into ssb05h10');
        if tmp_inq_dt = vwdate then
          vn.pss_rgt_tax_history
          ( vs_acnt_no,         -- vs_acnt_no   ,
            i_list_stk_cd,      -- i_stk_cd    ,
            '',                 -- i_proc_dt   ,
            tmp_cnte,           -- i_cnte      ,
            i_work_mn   ,
            i_work_trm  
          );
        elsif tmp_inq_dt < vwdate then
          select min (proc_dt)
            into tn_min_proc_dt_inq
            from ssb05h10
           where acnt_no = vs_acnt_no
            and stk_cd = i_list_stk_cd
            and proc_dt > tmp_inq_dt;
        
          select max (proc_dt), max (id)
              into tn_max_proc_dt_inq, tn_max_id_inq
              from ssb05h10
             where acnt_no = vs_acnt_no
              and stk_cd = i_list_stk_cd
              and proc_dt <= tmp_inq_dt;
          
          vn.pxc_log_write('psr_rgt_inoutbil_p', 'tn_min_proc_dt_inq: ' || tn_min_proc_dt_inq);
          vn.pxc_log_write('psr_rgt_inoutbil_p', 'tn_max_proc_dt_inq: ' || tn_max_proc_dt_inq);
          vn.pxc_log_write('psr_rgt_inoutbil_p', 'tn_max_id_inq: ' || tn_max_id_inq);
          
          if tn_min_proc_dt_inq is null then
            if i_apy_dt <= vwdate then
              insert into ssb05h10
              ( id,
                proc_dt,
                acnt_no,
                stk_cd,
                tax_qty,
                tax_sb_lim_qty,
                tax_delay_qty,
                tax_delay_sb_qty,
                wtax_qty,
                wtax_sb_lim_qty,
                wtax_delay_qty,
                wtax_delay_sb_qty,
                cnte,
                create_mn,
                create_dtm,
                create_trm,
                work_mn,
                work_dtm,
                work_trm,
                backup_mn,
                backup_dtm,
                backup_trm)
              select ssb05h10_seq.nextval,
                    tmp_inq_dt,
                    acnt_no,
                    stk_cd,
                    tax_qty - vn_asn_qty,
                    tax_sb_lim_qty,
                    tax_delay_qty + vn_asn_qty,
                    tax_delay_sb_qty,
                    wtax_qty,
                    wtax_sb_lim_qty,
                    wtax_delay_qty,
                    wtax_delay_sb_qty,
                    'Backdate 1 ' || fbm_rmrk_nm_q(tmp_rmrk_cd),
                    create_mn,
                    create_dtm,
                    create_trm,
                    work_mn,
                    work_dtm,
                    work_trm,
                    i_work_mn,
                    sysdate,
                    i_work_trm
                from ssb05m10
              where acnt_no = vs_acnt_no
                and stk_cd = i_list_stk_cd;

              vn.pss_rgt_tax_history
              ( vs_acnt_no,     -- vs_acnt_no   ,
                i_list_stk_cd,      -- i_stk_cd    ,
                '',        -- i_proc_dt   ,
                'Backdate 2 ' || fbm_rmrk_nm_q(tmp_rmrk_cd),           -- i_cnte      ,
                i_work_mn   ,
                i_work_trm  
              );
            elsif i_apy_dt > vwdate then
              vn.pss_rgt_tax_history
            ( vs_acnt_no,     -- vs_acnt_no   ,
              i_list_stk_cd,      -- i_stk_cd    ,
              tmp_inq_dt,        -- i_proc_dt   ,
              'Backdate 3 ' || fbm_rmrk_nm_q(tmp_rmrk_cd),           -- i_cnte      ,
              i_work_mn   ,
              i_work_trm  
            );
            end if; -- End check i_apy_dt
          elsif tn_min_proc_dt_inq is not null then
            
            if tn_max_proc_dt_inq is null then
              insert into ssb05h10
              ( id,
                proc_dt,
                acnt_no,
                stk_cd,
                tax_qty,
                tax_sb_lim_qty,
                tax_delay_qty,
                tax_delay_sb_qty,
                wtax_qty,
                wtax_sb_lim_qty,
                wtax_delay_qty,
                wtax_delay_sb_qty,
                cnte,
                create_mn,
                create_dtm,
                create_trm,
                backup_mn,
                backup_dtm,
                backup_trm)
              values
              ( ssb05h10_seq.nextval,
                tmp_inq_dt,
                vs_acnt_no,
                i_list_stk_cd,
                0,
                0,
                tmp_tax_qty, -- Cho TDCN
                tmp_tax_delay_qty, -- Cho HCCN
                0,
                0,
                0,
                0,
                'Backdate 4 ' || fbm_rmrk_nm_q(tmp_rmrk_cd),
                i_work_mn,
                sysdate,
                i_work_trm,
                i_work_mn,
                sysdate,
                i_work_trm
              );
            elsif tn_max_proc_dt_inq is not null then
              vn.pxc_log_write('pss_inbil_aprv_p', 'tn_max_proc_dt is not null 1.');
              
              insert into ssb05h10
              ( id,
                proc_dt,
                acnt_no,
                stk_cd,
                tax_qty,
                tax_sb_lim_qty,
                tax_delay_qty,
                tax_delay_sb_qty,
                wtax_qty,
                wtax_sb_lim_qty,
                wtax_delay_qty,
                wtax_delay_sb_qty,
                cnte,
                create_mn,
                create_dtm,
                create_trm,
                work_mn,
                work_dtm,
                work_trm,
                backup_mn,
                backup_dtm,
                backup_trm)
              select ssb05h10_seq.nextval,
                    tmp_inq_dt,
                    acnt_no,
                    stk_cd,
                    tax_qty,
                    tax_sb_lim_qty ,
                    tax_delay_qty + vn_asn_qty,
                    tax_delay_sb_qty,
                    wtax_qty,
                    wtax_sb_lim_qty,
                    wtax_delay_qty,
                    wtax_delay_sb_qty,
                    'Backdate 5 ' || fbm_rmrk_nm_q(tmp_rmrk_cd),
                    create_mn,
                    create_dtm,
                    create_trm,
                    work_mn,
                    work_dtm,
                    work_trm,
                    i_work_mn,
                    sysdate,
                    i_work_trm
                from ssb05h10
              where acnt_no = vs_acnt_no
                and stk_cd = i_list_stk_cd
                and proc_dt = tn_max_proc_dt_inq
                and id = tn_max_id_inq;
            end if;
          end if; -- End check tn_min_proc_dt_inq
          
          for c1 in (
            select max(id) as id_max, proc_dt, acnt_no, stk_cd
              from ssb05h10
             where acnt_no = vs_acnt_no
               and stk_cd = i_list_stk_cd
               and proc_dt >= tmp_inq_dt
             group by proc_dt,acnt_no,stk_cd)
          loop
            if i_apy_dt = tmp_inq_dt and c1.proc_dt = tmp_inq_dt then
              update ssb05h10
                 set tax_qty = tax_qty + vn_asn_qty,
                     tax_delay_qty = tax_delay_qty - vn_asn_qty,
                     cnte = cnte || ' Backdate 10',
                     work_mn = i_work_mn,
                     work_dtm = sysdate,
                     work_trm = i_work_trm
               where acnt_no = c1.acnt_no
                 and stk_cd = c1.stk_cd
                 and proc_dt = c1.proc_dt
                 and id = c1.id_max;
            elsif i_apy_dt = tmp_inq_dt and c1.proc_dt > tmp_inq_dt then
              insert into ssb05h10
              ( id,
                proc_dt,
                acnt_no,
                stk_cd,
                tax_qty,
                tax_sb_lim_qty,
                tax_delay_qty,
                tax_delay_sb_qty,
                wtax_qty,
                wtax_sb_lim_qty,
                wtax_delay_qty,
                wtax_delay_sb_qty,
                cnte,
                create_mn,
                create_dtm,
                create_trm,
                work_mn,
                work_dtm,
                work_trm,
                backup_mn,
                backup_dtm,
                backup_trm)
              select ssb05h10_seq.nextval,
                    c1.proc_dt,
                    acnt_no,
                    stk_cd,
                    tax_qty + vn_asn_qty,
                    tax_sb_lim_qty,
                    tax_delay_qty,
                    tax_delay_sb_qty,
                    wtax_qty,
                    wtax_sb_lim_qty,
                    wtax_delay_qty,
                    wtax_delay_sb_qty,
                    'Backdate 6 ' || fbm_rmrk_nm_q(tmp_rmrk_cd),
                    create_mn,
                    create_dtm,
                    create_trm,
                    work_mn,
                    work_dtm,
                    work_trm,
                    i_work_mn,
                    sysdate,
                    i_work_trm
                from ssb05h10
              where acnt_no = c1.acnt_no
                and stk_cd = c1.stk_cd
                and proc_dt = c1.proc_dt
                and id = c1.id_max;
            elsif i_apy_dt <> tmp_inq_dt then
              if c1.proc_dt > tmp_inq_dt and c1.proc_dt < i_apy_dt then
                insert into ssb05h10
                ( id,
                  proc_dt,
                  acnt_no,
                  stk_cd,
                  tax_qty,
                  tax_sb_lim_qty,
                  tax_delay_qty,
                  tax_delay_sb_qty,
                  wtax_qty,
                  wtax_sb_lim_qty,
                  wtax_delay_qty,
                  wtax_delay_sb_qty,
                  cnte,
                  create_mn,
                  create_dtm,
                  create_trm,
                  work_mn,
                  work_dtm,
                  work_trm,
                  backup_mn,
                  backup_dtm,
                  backup_trm)
                select ssb05h10_seq.nextval,
                      c1.proc_dt,
                      acnt_no,
                      stk_cd,
                      tax_qty,
                      tax_sb_lim_qty,
                      tax_delay_qty + vn_asn_qty,
                      tax_delay_sb_qty,
                      wtax_qty,
                      wtax_sb_lim_qty,
                      wtax_delay_qty,
                      wtax_delay_sb_qty,
                      'Backdate 7 ' || fbm_rmrk_nm_q(tmp_rmrk_cd),
                      create_mn,
                      create_dtm,
                      create_trm,
                      work_mn,
                      work_dtm,
                      work_trm,
                      i_work_mn,
                      sysdate,
                      i_work_trm
                  from ssb05h10
                where acnt_no = c1.acnt_no
                  and stk_cd = c1.stk_cd
                  and proc_dt = c1.proc_dt
                  and id = c1.id_max;
              elsif c1.proc_dt >= i_apy_dt and c1.proc_dt <> vwdate then
                insert into ssb05h10
                ( id,
                  proc_dt,
                  acnt_no,
                  stk_cd,
                  tax_qty,
                  tax_sb_lim_qty,
                  tax_delay_qty,
                  tax_delay_sb_qty,
                  wtax_qty,
                  wtax_sb_lim_qty,
                  wtax_delay_qty,
                  wtax_delay_sb_qty,
                  cnte,
                  create_mn,
                  create_dtm,
                  create_trm,
                  work_mn,
                  work_dtm,
                  work_trm,
                  backup_mn,
                  backup_dtm,
                  backup_trm)
                select ssb05h10_seq.nextval,
                      c1.proc_dt,
                      acnt_no,
                      stk_cd,
                      tax_qty + vn_asn_qty,
                      tax_sb_lim_qty,
                      tax_delay_qty,
                      tax_delay_sb_qty,
                      wtax_qty,
                      wtax_sb_lim_qty,
                      wtax_delay_qty,
                      wtax_delay_sb_qty,
                      'Backdate 8 ' || fbm_rmrk_nm_q(tmp_rmrk_cd),
                      create_mn,
                      create_dtm,
                      create_trm,
                      work_mn,
                      work_dtm,
                      work_trm,
                      i_work_mn,
                      sysdate,
                      i_work_trm
                  from ssb05h10
                where acnt_no = c1.acnt_no
                  and stk_cd = c1.stk_cd
                  and proc_dt = c1.proc_dt
                  and id = c1.id_max;
              end if;
            end if;
          end loop;
          
          v_count := 0;
          select count(*)
          into v_count
          from ssb05h10
          where acnt_no = vs_acnt_no
               and stk_cd = i_list_stk_cd
               and proc_dt = i_apy_dt;
          
          if v_count = 0 then
            select min (proc_dt)
              into tn_min_proc_dt_apy
              from ssb05h10
             where acnt_no = vs_acnt_no
              and stk_cd = i_list_stk_cd
              and proc_dt > i_apy_dt;
          
            select max (proc_dt), max (id)
                into tn_max_proc_dt_apy, tn_max_id_apy
                from ssb05h10
               where acnt_no = vs_acnt_no
                and stk_cd = i_list_stk_cd
                and proc_dt < i_apy_dt;
            
            vn.pxc_log_write('psr_rgt_inoutbil_p', 'tn_min_proc_dt_apy: ' || tn_min_proc_dt_apy);
            vn.pxc_log_write('psr_rgt_inoutbil_p', 'tn_max_proc_dt_apy: ' || tn_max_proc_dt_apy);
            vn.pxc_log_write('psr_rgt_inoutbil_p', 'tn_max_id_apy: ' || tn_max_id_apy);
            
            insert into ssb05h10
              ( id,
                proc_dt,
                acnt_no,
                stk_cd,
                tax_qty,
                tax_sb_lim_qty,
                tax_delay_qty,
                tax_delay_sb_qty,
                wtax_qty,
                wtax_sb_lim_qty,
                wtax_delay_qty,
                wtax_delay_sb_qty,
                cnte,
                create_mn,
                create_dtm,
                create_trm,
                work_mn,
                work_dtm,
                work_trm,
                backup_mn,
                backup_dtm,
                backup_trm)
              select ssb05h10_seq.nextval,
                    i_apy_dt,
                    acnt_no,
                    stk_cd,
                    tax_qty + vn_asn_qty,
                    tax_sb_lim_qty,
                    tax_delay_qty - vn_asn_qty,
                    tax_delay_sb_qty,
                    wtax_qty,
                    wtax_sb_lim_qty,
                    wtax_delay_qty,
                    wtax_delay_sb_qty,
                    'Backdate 9 ' || fbm_rmrk_nm_q(tmp_rmrk_cd),
                    create_mn,
                    create_dtm,
                    create_trm,
                    work_mn,
                    work_dtm,
                    work_trm,
                    i_work_mn,
                    sysdate,
                    i_work_trm
                from ssb05h10
              where acnt_no = vs_acnt_no
                and stk_cd = i_list_stk_cd
                and proc_dt = tn_max_proc_dt_apy
                and id = tn_max_id_apy;
          end if;
          -- Backup for vwdate
          vn.pss_rgt_tax_history
          ( vs_acnt_no,     -- vs_acnt_no   ,
            i_list_stk_cd,      -- i_stk_cd    ,
            '',        -- i_proc_dt   ,
            'Backdate 0 ' || fbm_rmrk_nm_q(tmp_rmrk_cd),           -- i_cnte      ,
            i_work_mn   ,
            i_work_trm  
          );
        end if; -- End check tmp_inq_dt
      end if; -- End check tmp_grp_tp
      /* End LTHN-248 */
      /* 20100723 Blocking the bonus amount  According apply date  by jung */

      if i_apy_dt >  vn.vwdate  then

        vn.psr_rgt_inbil_bk (
          vs_acnt_no    ,
          vs_sub_no     ,
          i_list_stk_cd ,
          '205'         ,
          vo_trd_seq_no ,
          vn_asn_qty    ,
          i_apy_dt      ,
          i_work_mn     ,
          i_work_trm
        ) ;
      end if ;

      /* 20100623 rights sbst  processing by jung */

      vn.psr_sbst_pay_p (
        's' ,  -- stock
        vn_asn_qty ,
        i_list_stk_cd ,
        vs_acnt_no    ,
        vs_sub_no    ,
        i_work_mn     ,
        i_work_trm
      );

     update  vn.srr02m00
     set     inq_trd_no  = vo_trd_seq_no
     where   rgt_std_dt  = i_std_dt
     and     stk_cd      = i_stk_cd
     and     rgt_tp      = '2'
     and     acnt_no     = vs_acnt_no
     and     sub_no      = vs_sub_no
     and     seq_no      = i_seq_no;

    vn.pdl_crd_loan_rt_proc_td
      ( i_proc_dt
        ,'2' -- stock
        ,vs_acnt_no
        ,vs_sub_no
        ,vo_trd_seq_no
        ,i_work_mn
        ,i_work_trm
        ,o_cnt
      );

    /* Send SMS */
    vn.pxc_log_write('psr_rgt_inoutbil_p', 'SMS start. ');
    select decode(acnt_tp, 'F', 'E', 'V') msg_lang
    into vs_msg_lang
    from vn.aaa01m00
    where acnt_no = vs_acnt_no
    and sub_no = vs_sub_no;

    vs_fnc_cd := 'F02111';
    vs_asn_qty := vn.fxc_format_number (vn_asn_qty,0,vs_msg_lang);

    if vs_msg_lang = 'V' then
      vn.pxc_log_write('psr_rgt_inoutbil_p', 'tieng viet');
      vs_sms_msg := '||' || vs_acnt_no || '||' || vs_sub_no || '||' || i_stk_cd || '||' || vs_asn_qty;
    elsif vs_msg_lang = 'E' then
      vn.pxc_log_write('psr_rgt_inoutbil_p', 'tieng anh');
      vs_sms_msg := '||' || i_stk_cd || '||' || vs_asn_qty || '||' || vs_acnt_no || '||' || vs_sub_no;
    end if;

    vn.pxc_sms_ins(
      null,       --i_send_dt          in varchar2,                         -- can put NULL, get from sysdate
      null,       --i_recv_phone_no    in varchar2,                         -- can put NULL, get from account
      null,       --i_send_phone_no    in varchar2,                         -- can put NULL, get from company
      vs_fnc_cd,  --i_func_cd          in varchar2,                         -- NOT null
      null,       --i_msg_lang         in varchar2,                         -- can put NULL, get from account
      vs_sms_msg, --i_sms_msg          in varchar2,                         -- NOT null
      i_work_mn,  --i_work_mn          in varchar2,                         -- can put NULL
      i_work_trm, --i_work_trm         in varchar2,                         -- can put NULL
      vs_acnt_no, --vs_acnt_no          in varchar2      default null,       -- can put NULL
      vs_sub_no   --vs_sub_no           in varchar2      default null        -- can put NULL
    );
    vn.pxc_log_write('psr_rgt_inoutbil_p', 'SMS finished. ');
    /* Push notification */
      vn.pxc_notif_ins(
        vs_acnt_no, --i_acnt_no          in varchar2,    -- NOT NULL
        vs_sub_no,  --i_sub_no           in varchar2,    -- NOT NULL
        vs_fnc_cd,  --i_func_cd          in varchar2,    -- NOT null
        null,       --i_msg_lang         in varchar2,    -- can put NULL, get from account
        vs_sms_msg, --i_sms_msg          in varchar2,    -- NOT null
        '1',        --i_notif_tp         in varchar2,    -- NOT null
        i_work_mn,  --i_work_mn          in varchar2,    -- can put NULL
        i_work_trm  --i_work_trm         in varchar2     -- can put NULL
      );

    end loop;

    update  vn.srr01m00
    set     rgt_proc_stat = '5'
    where   rgt_std_dt    = i_std_dt
    and     stk_cd        = i_stk_cd
    and     rgt_tp        = '2'
    and     seq_no        = i_seq_no;

  elsif i_rgt_tp = '3' then

    for g1 in  (

      select  acnt_no,
              sub_no ,
              asn_qty ,
              vn.fss_get_stk_nm( i_list_stk_cd)  stk_nm,
              acnt_mng_bnh
         from vn.srr02m00
        where rgt_std_dt    =  i_std_dt
          and stk_cd        =  i_stk_cd
          and seq_no        =  i_seq_no
          and rgt_tp        =  '3'
          and asn_qty       >  0
          and inq_trd_no    =  0
          and vn.faa_acnt_stat_g( acnt_no,sub_no) = '1'
    ) loop

      vs_acnt_no       := g1.acnt_no;
      vs_sub_no        := g1.sub_no;
      vn_asn_qty       := g1.asn_qty;
      vs_stk_nm        := g1.stk_nm;
      vs_acnt_mng_bnh  := g1.acnt_mng_bnh;

      vn.pxc_log_write('psr_inoutbil_p', vs_acnt_no);
      vn.pxc_log_write('psr_inoutbil_p', vs_sub_no);

      vn.pss_inbil_p(
        i_proc_dt,
        vs_acnt_mng_bnh,
        '5',
        vs_acnt_no,
        vs_sub_no,
        i_list_stk_cd,
        vs_stk_nm,
        vn_asn_qty,
        i_rgt_amt,
        i_apy_dt,
        '',
        '',
        '',
        '206',
        i_work_mn,
        i_work_trm,
        vn.faa_acnt_bnh_cd_g(  '3',vs_acnt_no,vs_sub_no),
        vo_trd_seq_no,
        vo_pre_rm,
        vo_now_rm
      );

      vn.pxc_log_write('psr_rgt_inoutbil_p', vs_acnt_no||'rgt_tp 3 ');
      /* LTHN-248: Thue TNCN cho quyen CPT, CT bang CP */
      tmp_grp_tp := '0';
      select b.grp_tp
        into tmp_grp_tp
        from aaa01m00 a, aaa02m00 b
       where a.idno = b.idno
         and a.acnt_no = vs_acnt_no
         and a.sub_no = '00'
         and a.acnt_stat = '1';
      
      if tmp_grp_tp = '1' then
        tmp_cnte := 'Co tuc bang CP, ma ' || i_stk_cd || ', ngay DKCC ' || i_std_dt || ', seq ' || to_char(i_seq_no);
        tmp_rmrk_cd := '206';
        select count(*) 
          into tmp_cnt
          from ssb05m10
         where acnt_no = vs_acnt_no
           and stk_cd = i_list_stk_cd;
           
        if tmp_cnt = 0 then
          /* Insert vao bang hien tai */
          if i_apy_dt <= vwdate then
            tmp_tax_delay_qty   := 0;
            tmp_tax_qty         := vn_asn_qty;
          else
            tmp_tax_delay_qty   := vn_asn_qty;
            tmp_tax_qty         := 0;
          end if;
          
          vn.pxc_log_write('psr_rgt_inoutbil_p', 'CT bang CP: Insert into ssb05m10');
          vn.pxc_log_write('psr_rgt_inoutbil_p', 'tmp_tax_qty: ' || to_char(tmp_tax_qty));
          vn.pxc_log_write('psr_rgt_inoutbil_p', 'tmp_tax_delay_qty: ' || to_char(tmp_tax_delay_qty));
          
          insert into ssb05m10
          ( acnt_no,          -- 1
            stk_cd,           -- 2
            tax_qty,          -- 3
            tax_delay_qty,    -- 4
            create_mn,        -- 5
            create_dtm,       -- 6
            create_trm        -- 7
          )
          values
          ( vs_acnt_no,               -- 1
            i_list_stk_cd,            -- 2
            tmp_tax_qty,              -- 3
            tmp_tax_delay_qty,        -- 4
            i_work_mn,                -- 5
            sysdate,                  -- 6
            i_work_trm                -- 7
          );
        else
          /* Lay SL cho HCCN can tinh thue hien tai */
          select tax_qty,     tax_delay_qty
            into tmp_tax_qty, tmp_tax_delay_qty
            from ssb05m10
           where acnt_no = vs_acnt_no
             and stk_cd = i_list_stk_cd;
          
          if i_apy_dt <= vwdate then
            tmp_tax_qty         := tmp_tax_qty + vn_asn_qty;
          else
            tmp_tax_delay_qty   := tmp_tax_delay_qty + vn_asn_qty;
          end if;
          
          /* Cap nhat SL HCCN can tinh thue */
          vn.pxc_log_write('psr_rgt_inoutbil_p', 'CT bang CP: Update ssb05m10');
          update ssb05m10
             set tax_qty = tmp_tax_qty,
                 tax_delay_qty = tmp_tax_delay_qty
           where acnt_no = vs_acnt_no
             and stk_cd = i_list_stk_cd;
        end if;
        /* Luu lich su */
        vn.pxc_log_write('psr_rgt_inoutbil_p', 'CT bang CP: Insert into ssb05h10');
        if tmp_inq_dt = vwdate then
          vn.pss_rgt_tax_history
          ( vs_acnt_no,         -- vs_acnt_no   ,
            i_list_stk_cd,      -- i_stk_cd    ,
            '',                 -- i_proc_dt   ,
            tmp_cnte,           -- i_cnte      ,
            i_work_mn   ,
            i_work_trm  
          );
        elsif tmp_inq_dt < vwdate then
          select min (proc_dt)
            into tn_min_proc_dt_inq
            from ssb05h10
           where acnt_no = vs_acnt_no
            and stk_cd = i_list_stk_cd
            and proc_dt > tmp_inq_dt;
        
          select max (proc_dt), max (id)
              into tn_max_proc_dt_inq, tn_max_id_inq
              from ssb05h10
             where acnt_no = vs_acnt_no
              and stk_cd = i_list_stk_cd
              and proc_dt <= tmp_inq_dt;
          
          vn.pxc_log_write('psr_rgt_inoutbil_p', 'tn_min_proc_dt_inq: ' || tn_min_proc_dt_inq);
          vn.pxc_log_write('psr_rgt_inoutbil_p', 'tn_max_proc_dt_inq: ' || tn_max_proc_dt_inq);
          vn.pxc_log_write('psr_rgt_inoutbil_p', 'tn_max_id_inq: ' || tn_max_id_inq);
          
          if tn_min_proc_dt_inq is null then
            if i_apy_dt <= vwdate then
              insert into ssb05h10
              ( id,
                proc_dt,
                acnt_no,
                stk_cd,
                tax_qty,
                tax_sb_lim_qty,
                tax_delay_qty,
                tax_delay_sb_qty,
                wtax_qty,
                wtax_sb_lim_qty,
                wtax_delay_qty,
                wtax_delay_sb_qty,
                cnte,
                create_mn,
                create_dtm,
                create_trm,
                work_mn,
                work_dtm,
                work_trm,
                backup_mn,
                backup_dtm,
                backup_trm)
              select ssb05h10_seq.nextval,
                    tmp_inq_dt,
                    acnt_no,
                    stk_cd,
                    tax_qty - vn_asn_qty,
                    tax_sb_lim_qty,
                    tax_delay_qty + vn_asn_qty,
                    tax_delay_sb_qty,
                    wtax_qty,
                    wtax_sb_lim_qty,
                    wtax_delay_qty,
                    wtax_delay_sb_qty,
                    'Backdate 1 ' || fbm_rmrk_nm_q(tmp_rmrk_cd),
                    create_mn,
                    create_dtm,
                    create_trm,
                    work_mn,
                    work_dtm,
                    work_trm,
                    i_work_mn,
                    sysdate,
                    i_work_trm
                from ssb05m10
              where acnt_no = vs_acnt_no
                and stk_cd = i_list_stk_cd;

              vn.pss_rgt_tax_history
              ( vs_acnt_no,     -- vs_acnt_no   ,
                i_list_stk_cd,      -- i_stk_cd    ,
                '',        -- i_proc_dt   ,
                'Backdate 2 ' || fbm_rmrk_nm_q(tmp_rmrk_cd),           -- i_cnte      ,
                i_work_mn   ,
                i_work_trm  
              );
            elsif i_apy_dt > vwdate then
              vn.pss_rgt_tax_history
            ( vs_acnt_no,     -- vs_acnt_no   ,
              i_list_stk_cd,      -- i_stk_cd    ,
              tmp_inq_dt,        -- i_proc_dt   ,
              'Backdate 3 ' || fbm_rmrk_nm_q(tmp_rmrk_cd),           -- i_cnte      ,
              i_work_mn   ,
              i_work_trm  
            );
            end if; -- End check i_apy_dt
          elsif tn_min_proc_dt_inq is not null then
            
            if tn_max_proc_dt_inq is null then
              insert into ssb05h10
              ( id,
                proc_dt,
                acnt_no,
                stk_cd,
                tax_qty,
                tax_sb_lim_qty,
                tax_delay_qty,
                tax_delay_sb_qty,
                wtax_qty,
                wtax_sb_lim_qty,
                wtax_delay_qty,
                wtax_delay_sb_qty,
                cnte,
                create_mn,
                create_dtm,
                create_trm,
                backup_mn,
                backup_dtm,
                backup_trm)
              values
              ( ssb05h10_seq.nextval,
                tmp_inq_dt,
                vs_acnt_no,
                i_list_stk_cd,
                0,
                0,
                tmp_tax_qty, -- Cho TDCN
                tmp_tax_delay_qty, -- Cho HCCN
                0,
                0,
                0,
                0,
                'Backdate 4 ' || fbm_rmrk_nm_q(tmp_rmrk_cd),
                i_work_mn,
                sysdate,
                i_work_trm,
                i_work_mn,
                sysdate,
                i_work_trm
              );
            elsif tn_max_proc_dt_inq is not null then
              vn.pxc_log_write('pss_inbil_aprv_p', 'tn_max_proc_dt is not null 1.');
              
              insert into ssb05h10
              ( id,
                proc_dt,
                acnt_no,
                stk_cd,
                tax_qty,
                tax_sb_lim_qty,
                tax_delay_qty,
                tax_delay_sb_qty,
                wtax_qty,
                wtax_sb_lim_qty,
                wtax_delay_qty,
                wtax_delay_sb_qty,
                cnte,
                create_mn,
                create_dtm,
                create_trm,
                work_mn,
                work_dtm,
                work_trm,
                backup_mn,
                backup_dtm,
                backup_trm)
              select ssb05h10_seq.nextval,
                    tmp_inq_dt,
                    acnt_no,
                    stk_cd,
                    tax_qty,
                    tax_sb_lim_qty ,
                    tax_delay_qty + vn_asn_qty,
                    tax_delay_sb_qty,
                    wtax_qty,
                    wtax_sb_lim_qty,
                    wtax_delay_qty,
                    wtax_delay_sb_qty,
                    'Backdate 5 ' || fbm_rmrk_nm_q(tmp_rmrk_cd),
                    create_mn,
                    create_dtm,
                    create_trm,
                    work_mn,
                    work_dtm,
                    work_trm,
                    i_work_mn,
                    sysdate,
                    i_work_trm
                from ssb05h10
              where acnt_no = vs_acnt_no
                and stk_cd = i_list_stk_cd
                and proc_dt = tn_max_proc_dt_inq
                and id = tn_max_id_inq;
            end if;
          end if; -- End check tn_min_proc_dt_inq
          
          for c1 in (
            select max(id) as id_max, proc_dt, acnt_no, stk_cd
              from ssb05h10
             where acnt_no = vs_acnt_no
               and stk_cd = i_list_stk_cd
               and proc_dt >= tmp_inq_dt
             group by proc_dt,acnt_no,stk_cd)
          loop
            if i_apy_dt = tmp_inq_dt and c1.proc_dt = tmp_inq_dt then
              update ssb05h10
                 set tax_qty = tax_qty + vn_asn_qty,
                     tax_delay_qty = tax_delay_qty - vn_asn_qty,
                     cnte = cnte || ' Backdate 10',
                     work_mn = i_work_mn,
                     work_dtm = sysdate,
                     work_trm = i_work_trm
               where acnt_no = c1.acnt_no
                 and stk_cd = c1.stk_cd
                 and proc_dt = c1.proc_dt
                 and id = c1.id_max;
            elsif i_apy_dt = tmp_inq_dt and c1.proc_dt > tmp_inq_dt then
              insert into ssb05h10
              ( id,
                proc_dt,
                acnt_no,
                stk_cd,
                tax_qty,
                tax_sb_lim_qty,
                tax_delay_qty,
                tax_delay_sb_qty,
                wtax_qty,
                wtax_sb_lim_qty,
                wtax_delay_qty,
                wtax_delay_sb_qty,
                cnte,
                create_mn,
                create_dtm,
                create_trm,
                work_mn,
                work_dtm,
                work_trm,
                backup_mn,
                backup_dtm,
                backup_trm)
              select ssb05h10_seq.nextval,
                    c1.proc_dt,
                    acnt_no,
                    stk_cd,
                    tax_qty + vn_asn_qty,
                    tax_sb_lim_qty,
                    tax_delay_qty,
                    tax_delay_sb_qty,
                    wtax_qty,
                    wtax_sb_lim_qty,
                    wtax_delay_qty,
                    wtax_delay_sb_qty,
                    'Backdate 6 ' || fbm_rmrk_nm_q(tmp_rmrk_cd),
                    create_mn,
                    create_dtm,
                    create_trm,
                    work_mn,
                    work_dtm,
                    work_trm,
                    i_work_mn,
                    sysdate,
                    i_work_trm
                from ssb05h10
              where acnt_no = c1.acnt_no
                and stk_cd = c1.stk_cd
                and proc_dt = c1.proc_dt
                and id = c1.id_max;
            elsif i_apy_dt <> tmp_inq_dt then
              if c1.proc_dt > tmp_inq_dt and c1.proc_dt < i_apy_dt then
                insert into ssb05h10
                ( id,
                  proc_dt,
                  acnt_no,
                  stk_cd,
                  tax_qty,
                  tax_sb_lim_qty,
                  tax_delay_qty,
                  tax_delay_sb_qty,
                  wtax_qty,
                  wtax_sb_lim_qty,
                  wtax_delay_qty,
                  wtax_delay_sb_qty,
                  cnte,
                  create_mn,
                  create_dtm,
                  create_trm,
                  work_mn,
                  work_dtm,
                  work_trm,
                  backup_mn,
                  backup_dtm,
                  backup_trm)
                select ssb05h10_seq.nextval,
                      c1.proc_dt,
                      acnt_no,
                      stk_cd,
                      tax_qty,
                      tax_sb_lim_qty,
                      tax_delay_qty + vn_asn_qty,
                      tax_delay_sb_qty,
                      wtax_qty,
                      wtax_sb_lim_qty,
                      wtax_delay_qty,
                      wtax_delay_sb_qty,
                      'Backdate 7 ' || fbm_rmrk_nm_q(tmp_rmrk_cd),
                      create_mn,
                      create_dtm,
                      create_trm,
                      work_mn,
                      work_dtm,
                      work_trm,
                      i_work_mn,
                      sysdate,
                      i_work_trm
                  from ssb05h10
                where acnt_no = c1.acnt_no
                  and stk_cd = c1.stk_cd
                  and proc_dt = c1.proc_dt
                  and id = c1.id_max;
              elsif c1.proc_dt >= i_apy_dt and c1.proc_dt <> vwdate then
                insert into ssb05h10
                ( id,
                  proc_dt,
                  acnt_no,
                  stk_cd,
                  tax_qty,
                  tax_sb_lim_qty,
                  tax_delay_qty,
                  tax_delay_sb_qty,
                  wtax_qty,
                  wtax_sb_lim_qty,
                  wtax_delay_qty,
                  wtax_delay_sb_qty,
                  cnte,
                  create_mn,
                  create_dtm,
                  create_trm,
                  work_mn,
                  work_dtm,
                  work_trm,
                  backup_mn,
                  backup_dtm,
                  backup_trm)
                select ssb05h10_seq.nextval,
                      c1.proc_dt,
                      acnt_no,
                      stk_cd,
                      tax_qty + vn_asn_qty,
                      tax_sb_lim_qty,
                      tax_delay_qty,
                      tax_delay_sb_qty,
                      wtax_qty,
                      wtax_sb_lim_qty,
                      wtax_delay_qty,
                      wtax_delay_sb_qty,
                      'Backdate 8 ' || fbm_rmrk_nm_q(tmp_rmrk_cd),
                      create_mn,
                      create_dtm,
                      create_trm,
                      work_mn,
                      work_dtm,
                      work_trm,
                      i_work_mn,
                      sysdate,
                      i_work_trm
                  from ssb05h10
                where acnt_no = c1.acnt_no
                  and stk_cd = c1.stk_cd
                  and proc_dt = c1.proc_dt
                  and id = c1.id_max;
              end if;
            end if;
          end loop;
          
          v_count := 0;
          select count(*)
          into v_count
          from ssb05h10
          where acnt_no = vs_acnt_no
               and stk_cd = i_list_stk_cd
               and proc_dt = i_apy_dt;
          
          if v_count = 0 then
            select min (proc_dt)
              into tn_min_proc_dt_apy
              from ssb05h10
             where acnt_no = vs_acnt_no
              and stk_cd = i_list_stk_cd
              and proc_dt > i_apy_dt;
          
            select max (proc_dt), max (id)
                into tn_max_proc_dt_apy, tn_max_id_apy
                from ssb05h10
               where acnt_no = vs_acnt_no
                and stk_cd = i_list_stk_cd
                and proc_dt < i_apy_dt;
            
            vn.pxc_log_write('psr_rgt_inoutbil_p', 'tn_min_proc_dt_apy: ' || tn_min_proc_dt_apy);
            vn.pxc_log_write('psr_rgt_inoutbil_p', 'tn_max_proc_dt_apy: ' || tn_max_proc_dt_apy);
            vn.pxc_log_write('psr_rgt_inoutbil_p', 'tn_max_id_apy: ' || tn_max_id_apy);
            
            insert into ssb05h10
              ( id,
                proc_dt,
                acnt_no,
                stk_cd,
                tax_qty,
                tax_sb_lim_qty,
                tax_delay_qty,
                tax_delay_sb_qty,
                wtax_qty,
                wtax_sb_lim_qty,
                wtax_delay_qty,
                wtax_delay_sb_qty,
                cnte,
                create_mn,
                create_dtm,
                create_trm,
                work_mn,
                work_dtm,
                work_trm,
                backup_mn,
                backup_dtm,
                backup_trm)
              select ssb05h10_seq.nextval,
                    i_apy_dt,
                    acnt_no,
                    stk_cd,
                    tax_qty + vn_asn_qty,
                    tax_sb_lim_qty,
                    tax_delay_qty - vn_asn_qty,
                    tax_delay_sb_qty,
                    wtax_qty,
                    wtax_sb_lim_qty,
                    wtax_delay_qty,
                    wtax_delay_sb_qty,
                    'Backdate 9 ' || fbm_rmrk_nm_q(tmp_rmrk_cd),
                    create_mn,
                    create_dtm,
                    create_trm,
                    work_mn,
                    work_dtm,
                    work_trm,
                    i_work_mn,
                    sysdate,
                    i_work_trm
                from ssb05h10
              where acnt_no = vs_acnt_no
                and stk_cd = i_list_stk_cd
                and proc_dt = tn_max_proc_dt_apy
                and id = tn_max_id_apy;
          end if;
          -- Backup for vwdate
          vn.pss_rgt_tax_history
          ( vs_acnt_no,     -- vs_acnt_no   ,
            i_list_stk_cd,      -- i_stk_cd    ,
            '',        -- i_proc_dt   ,
            'Backdate 0 ' || fbm_rmrk_nm_q(tmp_rmrk_cd),           -- i_cnte      ,
            i_work_mn   ,
            i_work_trm  
          );
        end if; -- End check tmp_inq_dt
      end if; -- End check tmp_grp_tp
      /* End LTHN-248 */
      /* 20100723 Blocking the bonus amount  According apply date  by jung */

      if i_apy_dt > vn.vwdate then

        vn.psr_rgt_inbil_bk (
          vs_acnt_no    ,
          vs_sub_no    ,
          i_list_stk_cd ,
          '206'         ,
          vo_trd_seq_no ,
          vn_asn_qty    ,
          i_apy_dt      ,
          i_work_mn     ,
          i_work_trm
        ) ;
      end if ;

      /* 20100623 rights sbst  processing by jung */

      vn.psr_sbst_pay_p (
        's' ,  -- stock
        vn_asn_qty ,
        i_list_stk_cd ,
        vs_acnt_no    ,
        vs_sub_no    ,
        i_work_mn     ,
        i_work_trm
      );

      update  vn.srr02m00
      set     inq_trd_no  = vo_trd_seq_no
      where   rgt_std_dt  = i_std_dt
      and     stk_cd      = i_stk_cd
      and     rgt_tp      = '3'
      and     seq_no      = i_seq_no
      and     acnt_no     = vs_acnt_no
      and     sub_no      = vs_sub_no;


      vn.pdl_crd_loan_rt_proc_td
        ( i_proc_dt
          ,'2' -- stock
          ,vs_acnt_no
          ,vs_sub_no
          ,vo_trd_seq_no
          ,i_work_mn
          ,i_work_trm
          ,o_cnt
        );
      /* Send SMS */
      select decode(acnt_tp, 'F', 'E', 'V') msg_lang
      into vs_msg_lang
      from vn.aaa01m00
      where acnt_no = vs_acnt_no
      and sub_no = vs_sub_no;

      vs_fnc_cd := 'F02116';
      vs_asn_qty := vn.fxc_format_number (vn_asn_qty,0,vs_msg_lang);

      if vs_msg_lang = 'V' then
        vn.pxc_log_write('psr_rgt_inoutbil_p', 'tieng viet');
        vs_sms_msg := '||' || vs_acnt_no || '||' || vs_sub_no || '||' || i_stk_cd || '||' || vs_asn_qty;
      elsif vs_msg_lang = 'E' then
       vn.pxc_log_write('psr_rgt_inoutbil_p', 'tieng anh');
        vs_sms_msg := '||' || i_stk_cd || '||' || vs_asn_qty || '||' || vs_acnt_no || '||' || vs_sub_no;
      end if;

      vn.pxc_sms_ins(
        null,       --i_send_dt          in varchar2,                         -- can put NULL, get from sysdate
        null,       --i_recv_phone_no    in varchar2,                         -- can put NULL, get from account
        null,       --i_send_phone_no    in varchar2,                         -- can put NULL, get from company
        vs_fnc_cd,  --i_func_cd          in varchar2,                         -- NOT null
        null,       --i_msg_lang         in varchar2,                         -- can put NULL, get from account
        vs_sms_msg, --i_sms_msg          in varchar2,                         -- NOT null
        i_work_mn,  --i_work_mn          in varchar2,                         -- can put NULL
        i_work_trm, --i_work_trm         in varchar2,                         -- can put NULL
        vs_acnt_no, --vs_acnt_no          in varchar2      default null,       -- can put NULL
        vs_sub_no   --vs_sub_no           in varchar2      default null        -- can put NULL
      );
      /* Push notification */
      vn.pxc_notif_ins(
        vs_acnt_no, --i_acnt_no          in varchar2,    -- NOT NULL
        vs_sub_no,  --i_sub_no           in varchar2,    -- NOT NULL
        vs_fnc_cd,  --i_func_cd          in varchar2,    -- NOT null
        null,       --i_msg_lang         in varchar2,    -- can put NULL, get from account
        vs_sms_msg, --i_sms_msg          in varchar2,    -- NOT null
        '1',        --i_notif_tp         in varchar2,    -- NOT null
        i_work_mn,  --i_work_mn          in varchar2,    -- can put NULL
        i_work_trm  --i_work_trm         in varchar2     -- can put NULL
      );

    end loop;

    update  vn.srr01m00
    set     rgt_proc_stat = '5'
    where   rgt_std_dt    = i_std_dt
    and     stk_cd        = i_stk_cd
    and     rgt_tp        = '3'
    and     seq_no        = i_seq_no;


  elsif i_rgt_tp = '7' then

    for n4 in (
      select  a.list_stk_cd,
              b.acnt_no,
              b.sub_no,
              b.asn_qty  ,
              b.acnt_mng_bnh
         from vn.srr01m00 a, vn.srr02m00 b
        where a.rgt_std_dt =  b.rgt_std_dt
          and a.stk_cd   =  b.stk_cd
          and a.rgt_tp   =  b.rgt_tp
          and a.seq_no   =  b.seq_no
          and a.rgt_std_dt =  i_std_dt
          and a.stk_cd     =  i_stk_cd
          and a.rgt_tp     =  '7'
          and a.seq_no     =  i_seq_no
          and a.std_inq_dt =  i_proc_dt
          and a.std_inq_dt <> '00000000'
          and b.asn_qty  >  0
          and b.inq_trd_no = 0
          and nvl(b.conv_yn,'N') = 'Y'
          and vn.faa_acnt_stat_g(b.acnt_no, b.sub_no) = '1'
    ) loop

      vn.pss_inbil_p(
        i_proc_dt,
        n4.acnt_mng_bnh,
        '5',
        n4.acnt_no,
        n4.sub_no,
        n4.list_stk_cd,
        vn.fss_get_stk_nm(n4.list_stk_cd),
        n4.asn_qty,
        i_rgt_amt,
        i_apy_dt,
        '',
        '',
        '',
        '210',  /*Huedt fix quyen chuyen doi TP thanh CP*/
        i_work_mn,
        i_work_trm,
        vn.faa_acnt_bnh_cd_g('3',n4.acnt_no, n4.sub_no),
        vo_trd_seq_no,
        vo_pre_rm,
        vo_now_rm
      );

      /* 20100723 Blocking the bonus amount  According apply date  by jung */

      if i_apy_dt > vn.vwdate  then

        vn.psr_rgt_inbil_bk ( n4.acnt_no    ,
          n4.sub_no    ,
          n4.list_stk_cd ,
          '210'         ,
          vo_trd_seq_no ,
          n4.asn_qty    ,
          i_apy_dt      ,
          --i_proc_dt     ,
          i_work_mn     ,
          i_work_trm
        ) ;
      end if ;

      /* 20100623 rights sbst  processing by jung */

      vn.psr_sbst_pay_p ( 's' ,  -- stock
        n4.asn_qty ,
        n4.list_stk_cd ,
        n4.acnt_no    ,
        n4.sub_no    ,
        i_work_mn     ,
        i_work_trm
      );

      update  vn.srr02m00
          set inq_trd_no = vo_trd_seq_no
        where rgt_std_dt = i_std_dt
          and stk_cd     = i_stk_cd
          and rgt_tp     = '7'
          and seq_no   = i_seq_no
          and acnt_no    =  n4.acnt_no
          and sub_no     =  n4.sub_no
          and asn_qty  > 0
          and inq_trd_no = 0;

      update  vn.srr01m00
          set rgt_proc_stat = '5'
        where rgt_std_dt    = i_std_dt
          and stk_cd        = i_stk_cd
          and rgt_tp    = '7'
          and seq_no    = i_seq_no;

    end loop;

    for n6 in (
      select  a.acnt_no,
            a.sub_no,
            a.asn_qty,
            a.acnt_mng_bnh,
            a.own_qty
       from vn.srr02m00 a, vn.srr01m00 b
      where a.rgt_std_dt = b.rgt_std_dt
        and a.stk_cd   = b.stk_cd
        and a.rgt_tp   = b.rgt_tp
        and a.seq_no   = b.seq_no
        and a.rgt_std_dt =  i_std_dt
        and a.stk_cd     =  i_stk_cd
        and a.rgt_tp     =  '7'
        and a.seq_no     =  i_seq_no
        and a.outq_trd_no = 0
        and b.std_out_dt = i_exp_dt
        and b.std_out_dt <> '00000000'
        and nvl(a.conv_yn,'N') = 'Y'
        and vn.faa_acnt_stat_g(a.acnt_no,a.sub_no) = '1'

    ) loop
      begin
        select nvl(outq_req_qty, 0 ) ,
               nvl(mov_lim_qty, 0  )
          into vn_outq_qty ,
               vn_mov_lim_qty
          from vn.ssb01m00
         where acnt_no = n6.acnt_no
           and sub_no  = n6.sub_no
           and stk_cd  = i_stk_cd  ;
      exception
        when others then
          vn_outq_qty := 0 ;
          vn_mov_lim_qty := 0 ;
      end ;

      if vn_outq_qty > 0 then   /* Neu co SL cho xuat kho thi cancel toan bo giao dich*/
        update vn.ssb05m00
           set cncl_yn = 'Y'
         where acnt_no = n6.acnt_no
           and sub_no  = n6.sub_no
           and stk_cd  = i_stk_cd
           and trd_tp like '2%'
           and nvl(end_yn,'N') <> 'Y'
           and nvl(cncl_yn,'N') <> 'Y' ;

        update vn.ssb01m00
           set outq_req_qty = 0
         where acnt_no = n6.acnt_no
           and sub_no  = n6.sub_no
           and stk_cd  = i_stk_cd ;
      end if ;

      if vn_mov_lim_qty > 0 then  /* Neu co SL HCCN update = 0 */
        update vn.ssb01m00
           set mov_lim_qty = 0
         where acnt_no = n6.acnt_no
           and sub_no  = n6.sub_no
           and stk_cd  = i_stk_cd ;
      end if;

      vn.pss_outbil_p(
        i_exp_dt,
        n6.acnt_mng_bnh,
        '5',
        n6.acnt_no,
        n6.sub_no,
        i_stk_cd,
        vn.fss_get_stk_nm(i_stk_cd),
        n6.own_qty,
        '',
        '',
        '',
        '227',/*Huedt fix quyen chuyen doi TP thanh CP*/
        i_work_mn,
        i_work_trm,
        vn.faa_acnt_bnh_cd_g('3',n6.acnt_no, n6.sub_no),
        vo_trd_seq_no,
        vo_pre_rm,
        vo_now_rm
        );

      update  vn.srr02m00
          set outq_trd_no  = vo_trd_seq_no
        where rgt_std_dt   =  i_std_dt
          and stk_cd     =  i_stk_cd
          and rgt_tp     =  '7'
          and seq_no     =  i_seq_no
          and acnt_no    =  n6.acnt_no
          and sub_no     =  n6.sub_no
          and outq_trd_no = 0      ;

      update vn.srr01m00
         set rgt_proc_stat = '8'
       where rgt_std_dt    = i_std_dt
         and stk_cd        = i_stk_cd
         and rgt_tp      = '7'
         and seq_no        = i_seq_no;
      vn.pdl_crd_loan_rt_proc_td
      ( i_proc_dt
        ,'2' -- stock
        ,vs_acnt_no
        ,vs_sub_no
        ,vo_trd_seq_no
        ,i_work_mn
        ,i_work_trm
        ,o_cnt
      );

    end loop;

  elsif i_rgt_tp = '8' then

    for n1 in (

      select  stk_cd ,
              cnvt_stk_cd
         from vn.srr01m10
        where rgt_std_dt =  i_std_dt
          and std_inq_dt =  i_proc_dt
          and stk_cd     =  i_stk_cd
          and nvl(inout_end_yn,'N') <>  'Y'

    ) loop


      for n2 in (

        select  acnt_no,
                sub_no,
                asn_qty,
                acnt_mng_bnh
           from vn.srr02m00
          where rgt_std_dt =  i_std_dt
            and stk_cd     =  i_stk_cd
            and rgt_tp     =  '8'
            and inq_trd_no = 0
            and seq_no    = 0
            and vn.faa_acnt_stat_g(acnt_no,sub_no) = '1'

      ) loop

        vn.pss_inbil_p(
          i_proc_dt,
          n2.acnt_mng_bnh,
          '5',
          n2.acnt_no,
          n2.sub_no,
          n1.cnvt_stk_cd,
          vn.fss_get_stk_nm( n1.cnvt_stk_cd),
          n2.ASN_QTY,
          i_rgt_amt,
          i_apy_dt,
          '',
          '',
          '',
          '209', /*Huedt fix quyen chuyen doi CP thanh TP*/
          i_work_mn,
          i_work_trm,
          vn.faa_acnt_bnh_cd_g( '3',n2.acnt_no, n2.sub_no),
          vo_trd_seq_no,
          vo_pre_rm,
          vo_now_rm
        );

        /* 20100723 Blocking the bonus amount  According apply date  by jung */

        if i_apy_dt > vn.vwdate  then

          vn.psr_rgt_inbil_bk (
            n2.acnt_no    ,
            n2.sub_no    ,
            n1.cnvt_stk_cd ,
            '209'          , /*Huedt fix quyen chuyen doi CP thanh CP*/
            vo_trd_seq_no ,
            n2.ASN_QTY    ,
            i_apy_dt      ,
            i_work_mn     ,
            i_work_trm
          ) ;
        end if ;

        /* 20100623 rights sbst  processing by jung */

        vn.psr_sbst_pay_p (
          's' ,  -- stock
          n2.ASN_QTY ,
          n1.cnvt_stk_cd ,
          n2.acnt_no    ,
          n2.sub_no    ,
          i_work_mn     ,
          i_work_trm
        );

        update  vn.srr02m00
            set inq_trd_no   = vo_trd_seq_no
          where rgt_std_dt   = i_std_dt
            and stk_cd     = i_stk_cd
            and rgt_tp     = '8'
            and acnt_no    =  n2.acnt_no
            and sub_no     =  n2.sub_no
            and seq_no   = 0
            and asn_qty > 0
            and inq_trd_no = 0
            and outq_trd_no = 0     ;

        begin
          select  nvl(own_qty,0) ,
                  nvl(mrtg_lnd_qty,0) + nvl(mrtg_buy_qty,0) ,
                  nvl(outq_req_qty, 0 ) ,
                  nvl(mov_lim_qty, 0  )
             into vn_own_qty  ,
                  vn_loan_qty ,
                  vn_outq_qty ,
                  vn_mov_lim_qty
             from vn.ssb01m00
            where acnt_no = n2.acnt_no
              and sub_no  = n2.sub_no
              and stk_cd  = i_stk_cd  ;
        exception
          when others then
            vn_own_qty  := 0 ;
            vn_loan_qty := 0 ;
            vn_outq_qty := 0 ;
            vn_mov_lim_qty := 0 ;
        end ;

        if vn_outq_qty > 0 then

          update  vn.ssb05m00
              set cncl_yn = 'Y'
            where acnt_no = n2.acnt_no
              and sub_no  = n2.sub_no
              and stk_cd  = i_stk_cd
              and trd_tp like '2%'
              and nvl(end_yn,'N') <> 'Y'
              and nvl(cncl_yn,'N') <> 'Y' ;

          update  vn.ssb01m00
              set outq_req_qty = 0
            where acnt_no = n2.acnt_no
              and sub_no  = n2.sub_no
              and stk_cd  = i_stk_cd ;
        end if ;

        if vn_mov_lim_qty > 0 then

         update vn.ssb01m00
            set mov_lim_qty = 0
          where acnt_no = n2.acnt_no
            and sub_no  = n2.sub_no
            and stk_cd  = i_stk_cd ;

        end if;

        if  vn_own_qty > 0 then

          vn.pss_outbil_p(
            i_proc_dt,
            n2.acnt_mng_bnh,
            '5',
            n2.acnt_no,
            n2.sub_no,
            i_stk_cd,
            vn.fss_get_stk_nm( i_stk_cd),
            vn_own_qty,
            '',
            '',
            '',
            '226',  /*Huedt fix quyen chuyen doi CP thanh CP*/
            i_work_mn,
            i_work_trm,
            vn.faa_acnt_bnh_cd_g('3',n2.acnt_no, n2.sub_no),
            vo_trd_seq_no,
            vo_pre_rm,
            vo_now_rm
          );

          update  vn.srr02m00
              set outq_trd_no  = vo_trd_seq_no
            where rgt_std_dt   =  i_std_dt
              and stk_cd     =  i_stk_cd
              and rgt_tp     =  '8'
              and acnt_no    =  n2.acnt_no
              and sub_no     =  n2.sub_no
              and seq_no   = 0
              and outq_trd_no = 0;
          vn.pdl_crd_loan_rt_proc_td
          ( i_proc_dt
            ,'2' -- stock
            ,n2.acnt_no
            ,n2.sub_no
            ,vo_trd_seq_no
            ,i_work_mn
            ,i_work_trm
            ,o_cnt
          );
        end if ;

      end loop;

      update  vn.srr01m10
          set rgt_proc_stat = '5' ,
              inout_end_yn  = 'Y'
        where stk_cd        = i_stk_cd
          and rgt_std_dt    = i_std_dt
          and nvl(inout_end_yn,'N') <> 'Y';

    end loop;

  end if;

end  psr_rgt_inoutbil_p;
/

