create function faa_num_bank_check
(
  i_numbank   in    varchar2
) return varchar2 as
  o_bank_cd varchar2(15);
  o_yes_no  varchar2(1);

begin

  begin
   select  ACC_ACT_CD
	into	o_bank_cd
	from	vn.GGA13T00
	where	ACC_ACT_CD =trim(i_numbank);
    return 'Y';
  exception
  when   no_data_found then
    return   'N';
  end;


end ;
/

