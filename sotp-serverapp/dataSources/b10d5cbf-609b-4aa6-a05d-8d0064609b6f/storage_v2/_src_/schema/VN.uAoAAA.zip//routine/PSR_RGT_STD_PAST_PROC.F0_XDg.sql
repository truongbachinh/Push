create procedure psr_rgt_std_past_proc
 (
  i_proc_dt    in       varchar2,
  i_stk_cd     in       varchar2,
  i_acnt_no    in       varchar2,
  i_sub_no     in       varchar2,
  i_qty        in       number  ,
  i_tp         in       varchar2,
  i_work_mn    in       varchar2,
  i_work_trm   in       varchar2
 ) is

  --vs_stk_cd    varchar2(12);
  -- vs_rgt_tp    varchar2(1) ;
  vn_count     number := 0;
  vn_own_qty   number := 0;
  vn_proc_cnt  number := 0;
  vn_asn_amt   number := 0;
  vn_tax_asn   number := 0 ;

begin

    vn.pxc_log_write('psr_rgt_std_past_proc', i_proc_dt||' '||i_stk_cd);

  for  c1  in (

  select  stk_cd,
      rgt_tp,
      rgt_std_dt,
      seq_no,
      rgt_proc_stat,
      rgt_iss_pri,
      nvl(tax_rate,0 )cash_rate
  from     vn.srr01m00
  where    rgt_std_dt    >=  i_proc_dt
  and      stk_cd         =  i_stk_cd
  and      rgt_proc_stat in ('2','3')

    ) loop

    select count(*)
    into   vn_count
    from   vn.srr02m00
    where  rgt_std_dt = c1.rgt_std_dt
    and    stk_cd     = c1.stk_cd
    and    rgt_tp     = c1.rgt_tp
    and    seq_no     = c1.seq_no
    and    acnt_no    = i_acnt_no
    and    sub_no     = i_sub_no;

    if vn_count > 0 then

      if i_tp = '1' then

        update  vn.srr02m00
        set     own_stk_qty    = own_stk_qty + i_qty,
            own_qty    = own_qty + i_qty
            --,     asn_qty    = own_qty + i_qty   -- Tai 22052015 jira VCSC - 1068
        where   rgt_std_dt = c1.rgt_std_dt
        and     stk_cd     = c1.stk_cd
        and     rgt_tp     = c1.rgt_tp
        and     seq_no     = c1.seq_no
        and     acnt_no    = i_acnt_no
        and     sub_no     = i_sub_no;

         /* for  c2  in (

           select  own_qty    own_qty   ,
               nvl(vn.fss_get_fac_pri(stk_cd),0)   fac_pri         ,
               vn.fsr_tax_tp_g(acnt_no, sub_no)  tax_tp
           from    vn.srr02m00 t
           where   rgt_std_dt = c1.rgt_std_dt
           and     stk_cd     = c1.stk_cd
           and     rgt_tp     = c1.rgt_tp
           and     seq_no     = c1.seq_no
           and     acnt_no    = i_acnt_no
           and     sub_no     = i_sub_no
               ) loop

           if c1.rgt_tp = '3' then
           vn_tax_asn    := round( c2.tax_tp * c2.own_qty * (c1.rgt_iss_pri / 100 * c2.fac_pri) * (c1.cash_rate / 100 ) );
           vn_asn_amt   :=  c2.own_qty * (c1.rgt_iss_pri / 100 * c2.fac_pri) - vn_tax_asn ;

             update  vn.srr02m00
             set      asn_amt      = vn_asn_amt ,
                tax_asn      = vn_tax_asn
             where   rgt_std_dt   = c1.rgt_std_dt
             and     stk_cd       = c1.stk_cd
             and     rgt_tp       = c1.rgt_tp
             and     seq_no       = c1.seq_no
             and     acnt_no      = i_acnt_no
             and     sub_no       = i_sub_no;

           end if;
        end loop; -- c2   */

      else

        update  vn.srr02m00
        set     own_stk_qty    = own_stk_qty + i_qty,
            own_qty    = own_qty - i_qty
            --,asn_qty    = own_qty - i_qty   -- Tai 22052015 jira VCSC - 1068
        where   rgt_std_dt = c1.rgt_std_dt
        and     stk_cd     = c1.stk_cd
        and     rgt_tp     = c1.rgt_tp
        and     seq_no     = c1.seq_no
        and     acnt_no    = i_acnt_no
        and     sub_no     = i_sub_no;

        /* for  c3  in (

        select  own_qty    own_qty   ,
            nvl(vn.fss_get_fac_pri(stk_cd),0)   fac_pri         ,
            vn.fsr_tax_tp_g(acnt_no, sub_no)  tax_tp
        from    vn.srr02m00 t
        where   rgt_std_dt = c1.rgt_std_dt
        and     stk_cd     = c1.stk_cd
        and     rgt_tp     = c1.rgt_tp
        and     seq_no     = c1.seq_no
        and     acnt_no    = i_acnt_no
        and     sub_no     = i_sub_no

        ) loop

          if c1.rgt_tp = '3' then
            vn_tax_asn    := round( c3.tax_tp * c3.own_qty * (c1.rgt_iss_pri / 100 * c3.fac_pri) * (c1.cash_rate / 100 ) );
            vn_asn_amt   :=  c3.own_qty * (c1.rgt_iss_pri / 100 * c3.fac_pri) - vn_tax_asn ;

            update  vn.srr02m00
            set      asn_amt      = vn_asn_amt ,
                tax_asn      = vn_tax_asn
            where   rgt_std_dt   = c1.rgt_std_dt
            and     stk_cd       = c1.stk_cd
            and     rgt_tp       = c1.rgt_tp
            and     seq_no       = c1.seq_no
            and     acnt_no      = i_acnt_no
            and     sub_no       = i_sub_no;

          end if;
        end loop; -- c3 */

      end if;

    else

      if i_tp = '1' then

        insert into vn.srr02m00
          (  rgt_std_dt,
          stk_cd,
          acnt_no,
          sub_no,
          rgt_tp,
          seq_no,
          acnt_mng_bnh,
          own_stk_qty,
          own_qty,
          asn_qty,
          asn_amt,
          flotq_amt,
          mrtg_lnd_qty,
          mrtg_asn_qty,
          inq_trd_no,
          rcpt_trd_no,
          outq_trd_no,
          outamt_trd_no,
          flotq_trd_no,
          cons_sbst_qty,
          cons_sbst_amt,
          outr_proc_yn,
          work_mn,
          work_dtm,
          work_trm
        ) values (
          c1.rgt_std_dt,
          c1.stk_cd,
          i_acnt_no,
          i_sub_no,
          c1.rgt_tp,
          c1.seq_no,
          vn.faa_acnt_bnh_cd_g('0',i_acnt_no,i_sub_no), --Hoai sua tu '3' sang '0'
          i_qty,
          i_qty,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          'Y',
          i_work_mn,
          sysdate,
          i_work_trm
        );

      end if;

    end if;


    if  c1.rgt_proc_stat in ('3') then

      vn.psr_rgt_asn_p_acnt(
        'I',
        c1.rgt_std_dt,
        c1.stk_cd,
        c1.rgt_tp,
        c1.seq_no,
        i_acnt_no,
        i_sub_no,
        i_work_mn,
        i_work_trm,
        vn_proc_cnt
      );

      /* need to check PSI, SHS and HBS */

      /* vn.psr_rgt_asn_p(
        c1.rgt_std_dt,
        c1.stk_cd,
        'c',
        c1.rgt_tp,
        c1.seq_no,
        i_work_mn,
        i_work_trm,
        vn_proc_cnt
        ); */

    end if;

    select  sum(own_qty)
    into    vn_own_qty
    from    vn.srr02m00
    where   rgt_std_dt = c1.rgt_std_dt
    and     stk_cd     = c1.stk_cd
    and     rgt_tp     = c1.rgt_tp
    and     seq_no     = c1.seq_no
    and     acnt_no    = i_acnt_no
    and     sub_no     = i_sub_no;

    if nvl(vn_own_qty,0) = 0  then

      delete from vn.srr02m00
      where   rgt_std_dt = c1.rgt_std_dt
      and     stk_cd     = c1.stk_cd
      and     rgt_tp     = c1.rgt_tp
      and     seq_no     = c1.seq_no
      and     acnt_no    = i_acnt_no
      and     sub_no     = i_sub_no;

    end if;

  end loop;

end  psr_rgt_std_past_proc;
/

