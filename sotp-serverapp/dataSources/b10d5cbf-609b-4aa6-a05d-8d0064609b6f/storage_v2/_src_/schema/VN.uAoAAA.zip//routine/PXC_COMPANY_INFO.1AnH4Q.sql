create PROCEDURE pxc_company_info(
	i_com_cd 				IN		VARCHAR2, 			--  company code
	i_test_yn 				IN		VARCHAR2, 			--  check real or test version
	i_lng_tp    			IN		VARCHAR2, 			--  language type
	o_com_full_nm			IN OUT 	VARCHAR2, 			--  company full name
	o_com_nm     		 	IN OUT 	VARCHAR2, 			--  company short form name
	o_com_vnm     			IN OUT 	VARCHAR2, 			--  company name in Vietnamese
	o_com_sms    			IN OUT 	VARCHAR2, 			--  company sms phone number
	o_com_phone  			IN OUT 	VARCHAR2, 			--  company representitive phone
	o_com_email  			IN OUT 	VARCHAR2, 			--  company email address
	o_com_addr   			IN OUT 	VARCHAR2, 			--  comapny address
	o_hn_brch    			IN OUT 	VARCHAR2, 			--  hanoi branch code
	o_hcm_brch  	 		IN OUT 	VARCHAR2, 			--  hochiminh branch code
	o_etc_brch   			IN OUT 	VARCHAR2,  			--  other branch code
  o_fax             out     varchar2,        -- Fax
  o_website         out     varchar2        -- Website
) IS

	t_sqlcode          NUMBER      := 0;
  	t_err_msg          VARCHAR2(500);

BEGIN
	o_com_full_nm		:= '!' ;
	o_com_nm     		:= '!' ;
	o_com_vnm     		:= '!' ;
	o_com_sms    		:= '!' ;
	o_com_phone  		:= '!' ;
	o_com_email  		:= '!' ;
	o_com_addr   		:= '!' ;
	o_hn_brch    		:= '!' ;
	o_hcm_brch  		:= '!' ;
	o_etc_brch   		:= '!' ;
  o_website       := '!';
  o_fax            := '!';


  vn.pxc_log_write('pxc_company_info','i_com_cd -['||i_com_cd||']');
  vn.pxc_log_write('pxc_company_info','i_test_yn -['||i_test_yn||']');
  vn.pxc_log_write('pxc_company_info','i_lng_tp -['||i_lng_tp||']');

	/*------------------------------------------------------------------------------*/
	/*   1. get general informaion of the securities
	/*------------------------------------------------------------------------------*/

	BEGIN
							SELECT  NVL(COM_FULL_NM, '!')            AS COM_FULL_NM
							      , NVL(COM_NM, '!')                 AS COM_NM
							      , NVL(COM_VNM, '!')				 AS COM_VNM
							      , NVL(COM_SMS, '!')                AS COM_SMS
                    , NVL(COM_PHONE, '!')              AS COM_PHONE
                    , NVL(COM_EMAIL, '!')              AS COM_EMAIL
                    , NVL((COM_ADDR), '!')               AS COM_ADDR
                    , NVL(HN_BRCH, '!')                AS HN_BRCH
                    , NVL(HCM_BRCH, '!')               AS HCM_BRCH
                    , NVL(ETC_BRCH, '!')               AS ETC_BRCH
                    , nvl(FAX, '!')                    As FAX
                    , nvl(website, '!')                As Website

               INTO   o_com_full_nm
                    , o_com_nm
                    , o_com_vnm
                    , o_com_sms
                    , o_com_phone
                    , o_com_email
                    , o_com_addr
                    , o_hn_brch
                    , o_hcm_brch
                    , o_etc_brch
                    , o_fax
                    , o_website
               FROM VN.XCC99M00
              WHERE trim(COM_CD) = trim(i_com_cd)
                AND trim(TEST_YN) = trim(i_test_yn)
                ;



    EXCEPTION WHEN OTHERS THEN

   vn.pxc_log_write('pxc_company_info','err code  -['||to_char(sqlcode)||']');

vn.pxc_log_write('pxc_company_info','o_com_full_nm -['||o_com_full_nm||']');
vn.pxc_log_write('pxc_company_info','o_com_nm -['||o_com_nm||']');
vn.pxc_log_write('pxc_company_info','o_com_vnm -['||o_com_vnm||']');
vn.pxc_log_write('pxc_company_info','o_com_sms -['||o_com_sms||']');
vn.pxc_log_write('pxc_company_info','o_com_phone -['||o_com_phone||']');
vn.pxc_log_write('pxc_company_info','o_com_email -['||o_com_email||']');
vn.pxc_log_write('pxc_company_info','o_com_addr -['||o_com_addr||']');
vn.pxc_log_write('pxc_company_info','o_hn_brch -['||o_hn_brch||']');
vn.pxc_log_write('pxc_company_info','o_hcm_brch -['||o_hcm_brch||']');
vn.pxc_log_write('pxc_company_info','o_etc_brch -['||o_etc_brch||']');
vn.pxc_log_write('pxc_company_info','o_fax -['||o_fax||']');

        t_sqlcode := sqlcode;
        t_err_msg := sqlerrm;
        -- rollback;

        t_err_msg := vn.fxc_get_err_msg('V','2713')||t_err_msg;
        -- vn.pxb_daily_stat(i_dt,t_pgm_id,'END',t_sqlcode,t_err_msg);
        raise_application_error(-20100,t_err_msg);

    END;


  /*------------------------------------------------------------------------------*/
  /*    2.find SMS
  /*------------------------------------------------------------------------------*/

  IF o_com_sms IS NULL THEN

   BEGIN
    SELECT BRCH_TEL
      INTO o_com_sms
      FROM VN.XCC90M00
     WHERE BRCH_CD = '901'
       AND AGNC_BRCH = '00';
    EXCEPTION
      WHEN others THEN
        t_err_msg := vn.fxc_get_err_msg(i_lng_tp,'9822');
        raise_application_error(-20004,t_err_msg);
        RETURN;
    END;
  END IF;

  /*------------------------------------------------------------------------------*/
  /*    3.find PHONE
  /*------------------------------------------------------------------------------*/

  IF o_com_phone IS NULL THEN

    BEGIN
      SELECT BRCH_TEL
        INTO o_com_phone
        FROM VN.XCC90M00
       WHERE BRCH_CD = '901'
         AND AGNC_BRCH = '00';
    EXCEPTION
      WHEN others THEN
        t_err_msg := vn.fxc_get_err_msg(i_lng_tp,'9822');
        raise_application_error(-20004,t_err_msg);
        RETURN;
    END;
  END IF;


  /*------------------------------------------------------------------------------*/
  /*    4.find EMAIL
  /*------------------------------------------------------------------------------*/

  IF o_com_email IS NULL THEN

   BEGIN
    SELECT EMAIL
      INTO o_com_email
      FROM VN.XCC90M00
     WHERE BRCH_CD = '901'
       AND AGNC_BRCH = '00';
    EXCEPTION
      WHEN others THEN
        t_err_msg := vn.fxc_get_err_msg(i_lng_tp,'9822');
        raise_application_error(-20004,t_err_msg);
        RETURN;
    END;
  END IF;


  /*------------------------------------------------------------------------------*/
  /*    4.find COM_ADDR
  /*------------------------------------------------------------------------------*/

  IF o_com_addr IS NULL THEN

   BEGIN
    SELECT BRCH_ADDR
      INTO o_com_addr
      FROM VN.XCC90M00
     WHERE BRCH_CD = '901'
       AND AGNC_BRCH = '00';
    EXCEPTION
      WHEN others THEN
        t_err_msg := vn.fxc_get_err_msg(i_lng_tp,'9822');
        raise_application_error(-20004,t_err_msg);
        RETURN;
    END;
  END IF;

  vn.pxc_log_write('pxc_company_info','o_com_full_nm -['||o_com_full_nm||']');
  vn.pxc_log_write('pxc_company_info','o_com_nm -['||o_com_nm||']');
  vn.pxc_log_write('pxc_company_info','o_com_vnm -['||o_com_vnm||']');
  vn.pxc_log_write('pxc_company_info','o_com_sms -['||o_com_sms||']');
  vn.pxc_log_write('pxc_company_info','o_com_phone -['||o_com_phone||']');
  vn.pxc_log_write('pxc_company_info','o_com_email -['||o_com_email||']');
  vn.pxc_log_write('pxc_company_info','o_com_addr -['||o_com_addr||']');
  vn.pxc_log_write('pxc_company_info','o_hn_brch -['||o_hn_brch||']');
  vn.pxc_log_write('pxc_company_info','o_hcm_brch -['||o_hcm_brch||']');
  vn.pxc_log_write('pxc_company_info','o_etc_brch -['||o_etc_brch||']');
  vn.pxc_log_write('pxc_company_info','final -['||to_char(sqlcode)||']');

END pxc_company_info;
/

