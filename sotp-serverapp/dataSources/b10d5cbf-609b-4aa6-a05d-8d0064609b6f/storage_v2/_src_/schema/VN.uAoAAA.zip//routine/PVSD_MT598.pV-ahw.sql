create PROCEDURE PVSD_MT598
(
  i_sec_cd  IN VARCHAR2,
  i_tp      IN VARCHAR2,
  i_biz_cd  IN VARCHAR2,
  i_message IN VARCHAR2
)
/*************************************************
    i_tp:
      1: Cap nhat mo tai khoan giao dich chung khoan cua NDT
      2: Dong tai khoan giao dich chung khoan cua NDT
      3: Tat toan tai khoan
      4: Xac nhan so du chung khoan
      41: Xac nhan phan bo quyen
      42: Xac nhan TTBT
      5: Huy xac nhan so du chung khoan
      51: huy Xac nhan phan bo quyen
      6: Xac nhan danh sach so huu chung khoan luu ky thuc hien quyen
      7: Huy xac nhan danh sach so huu chung khoan luu ky thuc hien quyen
      8: Tra cuu bao cao

    i_biz_cd:
      001: TK
      002: CK + quyen
      003: Lenh
      004: Thanh toan + Cho vay

    i_mess:
      Cac tham so duoc ngan cach boi chuoi cac ky tu dac biet: !@#
      Doi voi bao cao yeu cau tham so dau tien phai la Ma bao cao. VD: CS001
    *************************************************/
 AS
  TYPE t_array IS TABLE OF VARCHAR2(200) INDEX BY PLS_INTEGER;

  v_send_dat VARCHAR2(4000);
  v_seq      NUMBER := 0;
  v_message  VARCHAR2(1000) := i_message;
  v_string   VARCHAR2(1000);
  v_pos      NUMBER := 0;
  i          NUMBER := 0;
  v_var      t_array;
  o_nextseq  number := 0;
  v_file_nm  varchar2(1000) := '';
  v_app_tp   varchar2(10);
  v_stk_cd   varchar2(10);/*Huedt add xac nhan bao cao quyen*/
  v_stk_mkt  varchar2(10);/*Huedt add xac nhan bao cao quyen*/
  v_trans_dt varchar2(8);
  v_trans_dt1 varchar2(8);/*Huedt add xac nhan bao cao quyen*/
  con_frm_seq number := 0;
  v_rgt_vsd_seq  VARCHAR2(20);

BEGIN
  vn.pxc_log_write('pvsd_mt598', 'Type: '|| i_tp || '-' ||i_message);

  IF i_tp = '1' THEN
    FOR C1 IN (SELECT A.ACNT_NO,
              replace(decode(A.ACNT_TP, 'F', A.FRGN_TRD_CD, A.IDNO), '/', '?_?') IDNO,
              decode(B.IDNO_TP
                ,'1'
                ,'IDNO'
                ,'2'
                ,'CCPT'
                ,'3'
                ,'CORP'
                ,'4'
                ,'OTHR'
                ,'5'
                ,'FIIN'
                ,'6'
                ,'ARNU'
                ,'7'
                ,'GOVT') IDNO_TP,
              (SELECT CURR_CD
               FROM AAA03C20 C
              WHERE C.CTRY_CD = B.CTRY_CD) CURR_CD,
              A.CUST_NM,
              replace(vn.faa_acnt_addr_g(A.ACNT_NO, A.SUB_NO), '/', '?_?') ADDR,
              decode(A.ACNT_TP, 'F', A.FRGN_ISS_DT, B.IDNO_ISS_DT) IDNO_ISS_DT,
              replace(decode(A.ACNT_TP, 'F', A.FRGN_ISS_ORGA, B.IDNO_ISS_ORGA), '/', '?_?') IDNO_ISS_ORGA,
              C.EMAIL,
              vn.faa_acnt_contact_tel_g(A.ACNT_NO
                           ,A.SUB_NO) TEL,
              D.BOS_SEQ_NO
           FROM VN.AAA01M00 A,
              VN.AAA02M00 B,
              VN.AAA02M10 C,
              VN.VSD02M00 D
          WHERE A.IDNO = B.IDNO
            AND A.IDNO = C.IDNO
            AND A.ACNT_NO = D.ACNT_NO
            AND A.ACNT_NO = i_message
            AND A.SUB_NO = '00'
            AND D.PROC_TP = i_tp
            AND D.VSD_STAT in ('1', '2'))
    LOOP

      v_send_dat :=   ':20:' || C1.BOS_SEQ_NO || chr(13) ||
              ':12:' || '001' || chr(13) ||
              ':77E:NORMAL' || chr(13) ||
              ':16R:GENL' || chr(13) ||
              ':23G:NEWM' || chr(13) ||
              ':22H::ACCT//AOPN' || chr(13) ||
              ':98A::PREP//' || to_char(SYSDATE, 'yyyymmdd') || chr(13) ||
              ':16S:GENL' || chr(13) ||
              ':16R:REGDET' || chr(13) ||
              ':97A::SAFE//' || C1.ACNT_NO || chr(13) ||
              ':95Q::INVE//' || C1.CUST_NM || chr(13) ||
              ':95S::ALTE/VISD/' || C1.IDNO_TP || '/' ||
                      C1.CURR_CD || '/' || C1.IDNO || chr(13) ||
              ':98A::ISSU//' || C1.IDNO_ISS_DT || chr(13) ||
              ':94G::ISSU//' || C1.IDNO_ISS_ORGA || chr(13) ||
              ':94G::EMAI//' || C1.EMAIL || chr(13) ||
              ':94G::PHON//' || C1.TEL || chr(13) ||
              ':94G::ADDR//' || C1.ADDR || chr(13) ||
              ':94D::CITY//' || chr(13) ||
              ':70E:ADTX' || chr(13) ||
              ':16S:REGDET';

      INSERT INTO VN.VSD01M00
        (REG_DT,
         SEQ_NO,
         BIZ_CD,
         DAT_TP,
         DAT_CD,
         SND_DAT,
         SND_TP,
         WORK_DTM)
      VALUES
        (to_char(SYSDATE, 'yyyymmdd'),
         C1.BOS_SEQ_NO,
         i_biz_cd,
         i_tp,
         '598',
         v_send_dat,
         '1',
         SYSDATE);

    END LOOP;

  ELSIF i_tp = '2' THEN

    FOR C2 IN (SELECT A.ACNT_NO,
              replace(decode(A.ACNT_TP, 'F', A.FRGN_TRD_CD, A.IDNO), '/', '?_?') IDNO,
              decode(B.IDNO_TP
                ,'1'
                ,'IDNO'
                ,'2'
                ,'CCPT'
                ,'3'
                ,'CORP'
                ,'4'
                ,'OTHR'
                ,'5'
                ,'FIIN'
                ,'6'
                ,'ARNU'
                ,'7'
                ,'GOVT') IDNO_TP,
              (SELECT CURR_CD
               FROM AAA03C20 C
              WHERE C.CTRY_CD = B.CTRY_CD) CURR_CD,
              A.CUST_NM,
              replace(vn.faa_acnt_addr_g(A.ACNT_NO, A.SUB_NO), '/', '?_?') ADDR,
              decode(A.ACNT_TP, 'F', A.FRGN_ISS_DT, B.IDNO_ISS_DT) IDNO_ISS_DT,
              replace(decode(A.ACNT_TP, 'F', A.FRGN_ISS_ORGA, B.IDNO_ISS_ORGA), '/', '?_?') IDNO_ISS_ORGA,
              C.EMAIL,
              vn.faa_acnt_contact_tel_g(A.ACNT_NO
                           ,A.SUB_NO) TEL,
              D.BOS_SEQ_NO
           FROM VN.AAA01M00 A,
              VN.AAA02M00 B,
              VN.AAA02M10 C,
              VN.VSD02M00 D
          WHERE A.IDNO = B.IDNO
            AND A.IDNO = C.IDNO
            AND A.ACNT_NO = D.ACNT_NO
            AND A.ACNT_NO = i_message
            AND A.SUB_NO = '00'
            AND D.PROC_TP = i_tp
            AND D.VSD_STAT in ('1', '2'))
    LOOP

      v_send_dat :=   ':20:' || C2.BOS_SEQ_NO || chr(13) ||
              ':12:' || '001' || chr(13) ||
              ':77E:NORMAL' || chr(13) ||
              ':16R:GENL' || chr(13) ||
              ':23G:NEWM' || chr(13) ||
              ':22H::ACCT//ACLS' || chr(13) ||
              ':98A::PREP//' || to_char(SYSDATE, 'yyyymmdd') || chr(13) ||
              ':16S:GENL' || chr(13) ||
              ':16R:REGDET' || chr(13) ||
              ':97A::SAFE//' || C2.ACNT_NO || chr(13) ||
              ':95Q::INVE//' || C2.CUST_NM || chr(13) ||
              ':95S::ALTE/VISD/' || C2.IDNO_TP || '/' ||
                      C2.CURR_CD || '/' || C2.IDNO || chr(13) ||
              ':98A::ISSU//' || C2.IDNO_ISS_DT || chr(13) ||
              ':94G::ISSU//' || C2.IDNO_ISS_ORGA || chr(13) ||
              ':94G::EMAI//' || C2.EMAIL || chr(13) ||
              ':94G::PHON//' || C2.TEL || chr(13) ||
              ':94G::ADDR//' || C2.ADDR || chr(13) ||
              ':94D::CITY//' || chr(13) ||
              ':70E:ADTX' || chr(13) ||
              ':16S:REGDET';
      INSERT INTO VN.VSD01M00
        (REG_DT,
         SEQ_NO,
         BIZ_CD,
         DAT_TP,
         DAT_CD,
         SND_DAT,
         SND_TP,
         WORK_DTM)
      VALUES
        (to_char(SYSDATE, 'yyyymmdd'),
         C2.BOS_SEQ_NO,
         i_biz_cd,
         i_tp,
         '598',
         v_send_dat,
         '1',
         SYSDATE);

    END LOOP;

  ELSIF i_tp = '3' THEN
    WHILE INSTR(v_message, '!@#') > 0
    LOOP
      i      := i + 1;
      v_pos := INSTR(v_message, '!@#');

      v_var(i) := substr(v_message, 1, v_pos - 1);

      v_message := substr(v_message, v_pos + 3);
    END LOOP;

    v_var(i + 1) := v_message;

    FOR C3 IN (SELECT DISTINCT D.ACNT_NO,
                   replace(decode(A.ACNT_TP, 'F', A.FRGN_ISS_DT, A.IDNO), '/', '?_?') IDNO,
                   decode(B.IDNO_TP
                  ,'1'
                  ,'IDNO'
                  ,'2'
                  ,'CCPT'
                  ,'3'
                  ,'CORP'
                  ,'4'
                  ,'OTHR'
                  ,'5'
                  ,'FIIN'
                  ,'6'
                  ,'ARNU'
                  ,'7'
                  ,'GOVT') IDNO_TP,
                   (SELECT CURR_CD
                    FROM AAA03C20 C
                   WHERE C.CTRY_CD = B.CTRY_CD) CURR_CD,
                   A.CUST_NM,
                   replace(vn.faa_acnt_addr_g(A.ACNT_NO, A.SUB_NO), '/', '?_?') ADDR,
                   decode(A.ACNT_TP, 'F', A.FRGN_ISS_DT, B.IDNO_ISS_DT) IDNO_ISS_DT,
                   replace(decode(A.ACNT_TP, 'F', A.FRGN_ISS_ORGA, B.IDNO_ISS_ORGA), '/', '?_?') IDNO_ISS_ORGA,
                   VN.fvsd_getbiccode(D.ANTH_CD) RECV_BICCODE,
                   D.ANTH_ACNT_NO,
                   D.BOS_SEQ_NO,
                   D.VSD_BRCH,
                   decode(D.TRD_TP, '21', 'TBAC', 'TWAC') TRD_TP
          FROM   VN.AAA01M00 A,
              VN.AAA02M00 B,
              VN.SSB05M00 D
          WHERE   A.IDNO = B.IDNO
          AND   A.ACNT_NO = D.ACNT_NO
          AND   A.SUB_NO = D.SUB_NO
          AND   D.TRD_TP in ('21', '28')
          AND   D.PROC_DT = v_var(1)
          AND   D.BOS_SEQ_NO = v_var(2)
          AND   D.BOS_STAT = '1'
          AND    ROWNUM < 2)
    LOOP

      v_send_dat :=   ':20:' || C3.BOS_SEQ_NO || chr(13) ||
              ':12:' || '001' || chr(13) ||
              ':77E:' || 'NORMAL' || chr(13) ||
              ':16R:GENL' || chr(13) ||
              ':23G:NEWM' || chr(13) ||
              ':22H::ACCT//' || C3.TRD_TP || chr(13) ||
              ':98A::PREP//' || to_char(SYSDATE, 'yyyymmdd') || chr(13) ||
              ':16S:GENL' || chr(13) ||
              ':16R:REGDET' || chr(13) ||
              ':97A::OWND//' || C3.ACNT_NO || chr(13) ||
              ':95Q::INVE//' || C3.CUST_NM || chr(13) ||
              ':95S::ALTE/VISD/' || C3.IDNO_TP || '/' ||
                      C3.CURR_CD || '/' || C3.IDNO || chr(13) ||
              ':70E::ADTX//' || C3.ADDR || chr(13) ||
              ':98A::ISSU//' || C3.IDNO_ISS_DT || chr(13) ||
              ':94G::ADDR//' || C3.IDNO_ISS_ORGA || chr(13) ||
              ':16S:REGDET' || chr(13) ||
              ':16R:SETPRTY' || chr(13) ||
              ':95P::ACOW//' || C3.RECV_BICCODE || chr(13) ||
              ':97A::SAFE//' || C3.ANTH_ACNT_NO || chr(13) ||
              ':16S:SETPRTY';

      INSERT INTO VN.VSD01M00
        (REG_DT,
         SEQ_NO,
         BIZ_CD,
         DAT_TP,
         DAT_CD,
         SND_DAT,
         SND_TP,
         WORK_DTM,
     VSD_BRCH)
      VALUES
        (to_char(SYSDATE, 'yyyymmdd'),
         C3.BOS_SEQ_NO,
         i_biz_cd,
         i_tp,
         '598',
         v_send_dat,
         '1',
         SYSDATE,
     C3.VSD_BRCH);

    END LOOP;

    elsif i_tp = '4' or i_tp = '5' THEN  /*Huedt add xac nhan DE*/
      WHILE INSTR(v_message, '!@#') > 0
      LOOP
        i      := i + 1;
        v_pos := INSTR(v_message, '!@#');

        v_var(i) := substr(v_message, 1, v_pos - 1);

        v_message := substr(v_message, v_pos + 3);
      END LOOP;

      v_var(i + 1) := v_message;

       pcom_nextseq('vsd01m00_seq', o_nextseq);

        select file_nm, TRANS_DT
          into v_file_nm, v_trans_dt
          from vn.vsd00m00
         where REPT_TP = v_var(1)
           and TRANS_REF = v_var(2);

          SELECT DECODE(FSS_GET_STK_MKT(V_STK_CD),
                      1,
                      '0002',
                      2,
                      '0001',
                      3,
                      '0007',
                      4,
                      '0003',
                      '0000')
          INTO V_STK_MKT
          FROM DUAL;

          if i_tp = '4' then
             v_app_tp := '005';
          else
             v_app_tp := '006';
          end if;
          v_send_dat  :=   ':20:'|| o_nextseq ||chr(13)||
                ':12:'|| v_app_tp ||chr(13)||
                ':77E:BALANCE' || chr(13) ||
                'TXNUM:' || v_var(2) ||chr(13)||
                'RPTID:' || v_var(1) ||chr(13)||
                'TRANDATE:' || v_trans_dt ||chr(13)||
                'BRID:'||v_stk_mkt||chr(13)||
                /*'BRID:0003'||chr(13)||*/
                ':16R:GENL' ||  chr(13) ||
                ':23G:NEWM'||chr(13)||
                ':98A::PREP//'||to_char(sysdate,'yyyymmdd')||chr(13)||
                /*':16R:LINK'||chr(13)||
                ':20C::PREV//'|| v_var(2) ||chr(13)||
                ':16S:LINK' ||chr(13)||*/
                ':20C::STAT//' || v_file_nm || chr(13);
           if i_tp = '4' then
                v_send_dat  :=  v_send_dat  || ':25D::STAT//CONF' || chr(13);
           else
                v_send_dat  :=  v_send_dat  || ':25D::STAT//REJT' || chr(13);
           end if;

           v_send_dat  :=  v_send_dat  ||    ':16S:GENL';

          INSERT INTO VN.VSD01M00  (REG_DT, SEQ_NO, BIZ_CD, DAT_CD, SND_DAT, SND_TP, WORK_DTM)
          VALUES  (to_char(sysdate,'yyyymmdd'), o_nextseq, '002', '598', v_send_dat, '1', sysdate);
          /*Ket thuc khoi ins xac nhan DE*/

  elsif i_tp = '41' or i_tp = '51' THEN    /*Huedt add cf or rej quyen*/
      WHILE INSTR(v_message, '!@#') > 0
      LOOP
        i      := i + 1;
        v_pos := INSTR(v_message, '!@#');

        v_var(i) := substr(v_message, 1, v_pos - 1);

        v_message := substr(v_message, v_pos + 3);
      END LOOP;

      v_var(i + 1) := v_message;

       pcom_nextseq('vsd01m00_seq', o_nextseq);

        /*select file_nm, TRANS_DT, conf_seq_no
          into v_file_nm, v_trans_dt, con_frm_seq
          from vn.vsd00m00
         where REPT_TP = v_var(1)
           and TRANS_REF = v_var(2);*/

        SELECT FILE_NM,
               FVSD_CA005_GET_INFO(FILE_NM, '+', '-', 2),
               FVSD_CA005_GET_INFO(FILE_NM, '+', '-', 4),
               CONF_SEQ_NO
          INTO V_FILE_NM, V_STK_CD, V_TRANS_DT, CON_FRM_SEQ
          FROM VN.VSD00M00
         WHERE REPT_TP = V_VAR(1)
           AND TRANS_REF = V_VAR(2);

        SELECT DECODE(FSS_GET_STK_MKT(V_STK_CD),
                      1,
                      '0002',
                      2,
                      '0001',
                      3,
                      '0007',
                      4,
                      '0003',
                      '0000')
          INTO V_STK_MKT
          FROM DUAL;

        SELECT SUBSTR(V_TRANS_DT, 5, 4) || SUBSTR(V_TRANS_DT, 3, 2) ||
               SUBSTR(V_TRANS_DT, 1, 2)
          INTO V_TRANS_DT1
          FROM DUAL;

          if i_tp = '41' then
             v_app_tp := '005';
          else
             v_app_tp := '006';
          end if;
          v_send_dat  :=   ':20:'|| o_nextseq ||chr(13)||
                ':12:'|| v_app_tp ||chr(13)||
                ':77E:CAINFO' || chr(13) ||
                'TXNUM:' || v_var(2) ||chr(13)||
                'RPTID:' || v_var(1) ||chr(13)||
                'TRANDATE:' || v_trans_dt1 ||chr(13)||
                'BRID:'||v_stk_mkt||chr(13)||
                ':16R:GENL' ||  chr(13) ;

                if i_tp = '41' then
                    v_send_dat  :=   v_send_dat || ':23G:NEWM'||chr(13);
                else
                  v_send_dat  :=   v_send_dat || ':23G:CANC'||chr(13) ||
                                   ':16R:LINK' || chr(13) ||
                                   ':20C::PREV//' || con_frm_seq || chr(13) ||
                                   ':16S:LINK' || chr(13);
                end if;

           v_send_dat  :=   v_send_dat || ':98A::PREP//'||to_char(sysdate,'yyyymmdd')||chr(13)||
                ':20C::STAT//' || v_file_nm || chr(13);

           if i_tp = '41' then
                v_send_dat  :=  v_send_dat  || ':25D::STAT//CONF' || chr(13);
           else
                v_send_dat  :=  v_send_dat  || ':25D::STAT//REJT' || chr(13);
           end if;

           v_send_dat  :=  v_send_dat  ||    ':16S:GENL';

          INSERT INTO VN.VSD01M00  (REG_DT, SEQ_NO, BIZ_CD, DAT_CD, SND_DAT, SND_TP, WORK_DTM)
          VALUES  (to_char(sysdate,'yyyymmdd'), o_nextseq, '002', '598', v_send_dat, '1', sysdate);
          /*Het Huedt add cf or rej quyen*/
  /* Thang add confirm CS077*/
  ELSIF i_tp = '42' THEN -- Xac nhan CS077
    -- Separate the input string
    i := 0;
    WHILE INSTR(v_message, '!@#') > 0
      LOOP
        i      := i + 1;
        v_pos := INSTR(v_message, '!@#');

        v_var(i) := substr(v_message, 1, v_pos - 1);
        vn.pxc_log_write('pvsd_mt598', 'v_var(' || i || '): ' || v_var(i));
        v_message := substr(v_message, v_pos + 3);
      END LOOP;

      v_var(i + 1) := v_message;
      vn.pxc_log_write('pvsd_mt598', 'v_message: ' || v_message);
    -- Get next sequence
    pcom_nextseq('vsd01m00_seq', o_nextseq);
    -- Confirm status
    v_app_tp := '005';
    -- Get some information
    select file_nm,
           upper(substr(file_nm,1,3)) as stk_cd,
           faa_to_yyyymmdd(fvsd_cs077_get_info(file_nm, '+', '-', 4))
      into v_file_nm, v_stk_cd, v_trans_dt
      from vn.vsd00m00
     where rept_tp = v_var(1)
       and trans_ref = v_var(2);
    -- Get Market code
    select '0001' /*decode(fss_get_stk_mkt(v_stk_cd),
                     1,
                     '0002',
                     2,
                     '0001',
                     3,
                     '0007',
                     4,
                     '0003',
                     '0000')*/
         into v_stk_mkt
         from dual;
    -- Generate send data
    v_send_dat  := ':20:'|| o_nextseq ||chr(13)||
                ':12:'|| v_app_tp ||chr(13)||
                ':77E:TRADE' || chr(13) ||
                'RPTID:' || v_var(1) ||chr(13)||
                'TRANDATE:' || v_trans_dt ||chr(13)||
                'BRID:' || v_stk_mkt || chr(13) ||
                ':16R:GENL' ||  chr(13) ||
                ':23G:NEWM' ||  chr(13) ||
                ':98A::PREP//' || v_trans_dt || chr(13) ||
                ':20C::STAT//' || v_file_nm || chr(13) ||
                ':25D::STAT//CONF' ||  chr(13) ||
                ':16S:GENL';
    -- Put data into vsd01m00 table
    insert into vn.vsd01m00  (reg_dt, seq_no, biz_cd, dat_cd, snd_dat, snd_tp, work_dtm)
    values  (to_char(sysdate,'yyyymmdd'), o_nextseq, '004', '598', v_send_dat, '1', sysdate);

  ELSIF i_tp = '8' THEN -- Yeu cau bao cao
    WHILE INSTR(v_message, '!@#') > 0
    LOOP
      v_pos := INSTR(v_message, '!@#');
      v_var(i) := substr(v_message, 1, v_pos - 1);
      v_message := substr(v_message, v_pos + 3);

      i := i + 1;
    END LOOP;

    v_var(i) := v_message;
    vn.pxc_log_write('pvsd_mt598', 'Gui yeu cau bao cao.');
    vn.pxc_log_write('pvsd_mt598', 'v_message: ' || v_message);

    /* CS077 */
     vn.pxc_log_write('pvsd_mt598','v_var(0): ' || v_var(0));
     if v_var(0) = 'CS077' then
       v_string := 'MICODE:'||v_var(1)||chr(13)||
                    'PERIOD:'||v_var(2)||chr(13)||
                    'TRANDATE:'||v_var(3)||chr(13)||
                    'FROM:' || v_var(4)||chr(13)||
                    'TO:' ||v_var(5);
     end if;

      BEGIN
        vn.pcom_nextseq('vsd01m00_seq', v_seq);
      EXCEPTION
        WHEN OTHERS THEN
          vn.pxc_log_write('pvsd_mt598'
                  ,' Loi pcom_nextseq: ' || SQLCODE);
          raise_application_error(-20100
                       ,SQLCODE || ': ' || SQLERRM);
      END;

    vn.pxc_log_write('pvsd_mt598', 'nextseq: ' || v_seq);

    v_send_dat := ':20:' || v_seq || chr(13) ||
          ':12:' || '003' || chr(13) ||
          ':77E:' || chr(13) ||
                 v_string || chr(13) ||
              --'TRANDATE:' || to_char(SYSDATE, 'yyyymmdd') || chr(13) ||
          ':16R:GENL' || chr(13) ||
          ':23G:NEWM' || chr(13) ||
          ':98A::PREP//' || to_char(SYSDATE, 'yyyymmdd') || chr(13) ||
          ':13B::STAT//' || v_var(0) || chr(13) ||
          ':16S:GENL';
    vn.pxc_log_write('pvsd_mt598', 'v_send_dat: ' || v_send_dat);
    if INSTR(v_var(0), 'CA') > 0 then
     v_rgt_vsd_seq := v_var(1);
    else
     v_rgt_vsd_seq := null;
    end if;

    INSERT INTO VN.VSD01M00
        (REG_DT,
         SEQ_NO,
         BIZ_CD,
         DAT_TP,
         DAT_CD,
         SND_DAT,
         SND_TP,
         WORK_DTM,
         RGT_VSD_SEQ)
    VALUES
      (to_char(SYSDATE, 'yyyymmdd'),
       v_seq,
       i_biz_cd,
       i_tp,
       '598',
       v_send_dat,
       '1',
       SYSDATE,
       v_rgt_vsd_seq);
       vn.pxc_log_write('pvsd_mt598','v_send_dat: ' || v_send_dat);

  END IF;

END PVSD_MT598;
/

