create function fcw_bank_order_knd_tp_q
(
    i_bank_cd   in   varchar2
)
    return          varchar2
as
    o_bank_knd_tp	varchar2(100) ;
    t_err_txt       varchar2(100)  ; -- error text buffer

begin

    o_bank_knd_tp  :=  NULL;


	if i_bank_cd = '9999' then
	   o_bank_knd_tp := 'tp01' ;
	   return o_bank_knd_tp ;
    end if ;

	begin
		select nvl(bank_tp_cd,'XXXX')
		  into o_bank_knd_tp
		 from  vn.cww01h00
		where  bank_cd = i_bank_cd
		  and  mng_end_dt = to_date('30000101','yyyymmdd') ;
    exception
        when  OTHERS         then
            t_err_txt  :=  '¿À·ù-['||to_char(sqlcode)||']';
            raise_application_error (-20100, t_err_txt);
    end;

    return  o_bank_knd_tp;

end fcw_bank_order_knd_tp_q;
/

