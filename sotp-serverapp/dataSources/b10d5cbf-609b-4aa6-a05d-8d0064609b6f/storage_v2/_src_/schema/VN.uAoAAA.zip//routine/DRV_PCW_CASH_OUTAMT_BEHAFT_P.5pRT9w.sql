create procedure drv_pcw_cash_outamt_behaft_p
  (
      i_trd_dt in varchar2,
      i_seq_no in number,
      i_rmk_cd in varchar2,
      i_status in varchar2,
      i_work_mn in varchar2 default 'DAILY',
      i_work_trm in varchar2
  ) AS
  /*
   \file     drv_pcw_cash_outamt_behaft_p.sql
   \brief    ????

  \section intro Program Information
        - Program Name              : drv_pcw_cash_outamt_behaft_p.sql
        - Service Name              : DAILY
        - Related Client Program- Client Program ID : Client 15704
        - Related Tables            : DRCWDM06
        - Dev. Date                 : 2017/10/16
        - Developer                 : hieu.dt
        - Business Logic Desc.      : cash-bank-withdraw
        - Latest Modification Date  : 2007-11-30

  \section history Program Modification History
    - 1.0       2007/11/30     ???    ????

   \section hardcoding Hard-Coding List
    - HC-1

   \section info Additional Reference Comments
    - ???? ??
*/

t_proc_nm                varchar2(100) ;
    t_err_txt                varchar2(200);
    t_err_cd                 number;
    t_rtn_val                char(1);
    t_work_dtm               date;
    t_amt                    number;
    t_proc_brch              varchar2(3);
    t_std_dt                 varchar2(08) ;

    t_tr_cd           varchar2(20);
    t_seq_no         number := 0 ;
  ts_acnt_stat       varchar2(20);
  ts_acnt_mng_bnh       varchar2(20);
  ts_agnc_brch       varchar2(20);
  ts_proc_bnhof_tp     varchar2(20) := ' ';

    ts_chyes         varchar2(1);

  tn_dpo           number := 0;
  tn_dpo_prerm       number := 0;
  tn_tot_dpo_prerm     number := 0;
  tn_tot_dpo           number := 0;
  tn_inout_cnfm_lim     number := 0;

  t_ATDPST_found_yn      varchar2(1);

    t_trd_dt                 varchar2(20) := ' ';
    t_trd_seq_no             number := 0;
    t_tot_trd_seq_no         number := 0;
    t_dpo_prerm              number := 0;
    t_dpo_nowrm              number := 0;
    t_acnt_place             varchar2(10) := ' ';
    t_bnhof_tp               varchar2(10) := ' ';
    t_proc_bnhof_tp          varchar2(10) := ' ';
    t_fee_amt                number := 0;
    t_trd_amt                number := 0;
    t_cash_unblock           number := 0;
    t_fee_type               varchar2(10) := 'N';
    t_proc_brch_cd           varchar2(20) := Null;
    t_proc_agnc_brch         varchar2(20) := Null;
    tn_outq_dpo_bk           number := 0;
    ts_acnt_stop_yn          varchar2(500) := 'N';
    o_trd_seq_no             varchar2(500) := null;
    t_err_msg    varchar2(500);

    t_acnt_no          varchar2(20) := null;
    t_sub_no          varchar2(20) := null;
    t_mdm_tp          varchar2(20) := null;
    t_mdm_bnh          varchar2(3)  := null;
    o_result_yn        varchar2(20) := null;
    t_work_trm         varchar2(30) := null;
    t_work_mn          varchar2(50) := null;
    t_acc_act_cd       varchar2(20) := null;
    t_cnte             varchar2(200):= null;
   /* t_work_mn          varchar2(200):= null;*/
  o_cnt              number := 0;
  o_cwd06m00_seq     number := 0;
  tn_dpo_fee         number := 0;
  o_seq_no_cwd06     number := 0;
begin
                     t_proc_nm        :=  'drv_pcw_cash_outamt_behaft_p';
                     t_work_dtm       :=  SYSDATE;
                     t_ATDPST_found_yn           :=  'N';
       SELECT  vn.vhdate() INTO  t_std_dt       FROM  dual;

       vn.pxc_log_write('drv_pcw_cash_outamt_behaft_p','start');
       vn.pxc_log_write('drv_pcw_cash_outamt_behaft_p',i_seq_no);

    if  i_trd_dt  IS  NULL
    then
        t_err_txt  :=  t_proc_nm  ||  '??? ??? ??';
    t_err_msg := vn.fxc_get_err_msg('V','2701');
    raise_application_error(-20100,t_err_msg||t_err_txt);
    end if;
    /*ghi log*/

    vn.pxc_log_write('drv_pcw_cash_outamt_behaft_p', 'i_seq_no '||i_seq_no  );
    vn.pxc_log_write('drv_pcw_cash_outamt_behaft_p','i_rmk_cd ' ||i_rmk_cd  );
    vn.pxc_log_write('drv_pcw_cash_outamt_behaft_p','i_status ' ||i_status  );
    vn.pxc_log_write('drv_pcw_cash_outamt_behaft_p','i_work_mn ' ||i_work_mn  );
    vn.pxc_log_write('drv_pcw_cash_outamt_behaft_p','i_work_trm ' ||i_work_trm  );

    /*lay cac bien de xu ly thu chi ho*/

  BEGIN
       select acnt_no,
              sub_no,
              MDM_TP,
              nvl(FEE_AMT,0),
              nvl(TRD_AMT,0),
              nvl(FEE_TYPE,'N'),
              WORK_MN,
              ACC_ACT_CD,
              cnte,
              SEQ_CWD06M00
          into
          t_acnt_no,
          t_sub_no,
          t_mdm_tp,
          t_fee_amt,
               t_trd_amt,
               t_fee_type,
               t_work_mn,
               t_acc_act_cd,
               t_cnte,
               o_cwd06m00_seq
          from vn.Drcwdm06
          where TRD_DT = vn.vwdate
            and SEQ_NO = i_seq_no
            and TRANS_STT <> 'Y'
             for  update;
   EXCEPTION
        WHEN  NO_DATA_FOUND  THEN
            vn.pxc_log_write('drv_pcw_cash_outamt_behaft_p',' check 2: ' || sqlcode );
            t_ATDPST_found_yn           :=  'N';
            t_err_txt  :=  t_proc_nm
                   ||  '????(DRCWDM06) ??? ??:'
                   ||  to_char(sqlcode);
      t_err_msg := vn.fxc_get_err_msg('V','2704');
      raise_application_error(-20100,t_err_msg||t_err_txt);
    WHEN  OTHERS         THEN
        vn.pxc_log_write('drv_pcw_cash_outamt_behaft_p',' check 3: ' || sqlcode );
        t_err_txt  :=  t_proc_nm
                   ||  '????(DRCWDM06) ??? ??:'
                   ||  to_char(sqlcode);
      t_err_msg := vn.fxc_get_err_msg('V','2704');
      raise_application_error(-20100,t_err_msg||t_err_txt);
   END;     /*----------------------------------------*/
   if t_fee_type  ='E' then
      t_cash_unblock := t_trd_amt + t_fee_amt;
   else
      t_cash_unblock :=t_trd_amt;
   end if;
   BEGIN
        select  acnt_stat
             ,  acnt_mng_bnh
             ,  agnc_brch
          into  ts_acnt_stat
             ,  ts_acnt_mng_bnh
             ,  ts_agnc_brch
          from  vn.aaa01m00
         where  acnt_no  =  t_acnt_no
       and  sub_no   =  t_sub_no;
    EXCEPTION
        WHEN  OTHERS         THEN
            t_err_txt  :=  t_proc_nm
                   ||  '??_??(aaa01m00) ????? ????:'
                   ||  to_char(sqlcode);
      t_err_msg := vn.fxc_get_err_msg('V','2001');
      raise_application_error(-20100,t_err_msg||t_err_txt);
    END;
     if i_work_mn in ('DAILY','VTBMT900EARN','BATCH') or t_mdm_tp <> '00' then

    t_proc_brch_cd := ts_acnt_mng_bnh;
    t_proc_agnc_brch := ts_agnc_brch;

  else

      BEGIN
          select  brch_cd,
                  agnc_brch
            into  t_proc_brch_cd,
                  t_proc_agnc_brch
            from  vn.xca01m01
            where emp_no = i_work_mn
            ;
      EXCEPTION
          WHEN  OTHERS         THEN
              t_err_txt  :=  t_proc_nm
                     ||  '????????(xca01m01) ????? ????:'
                     ||  to_char(sqlcode);
      t_err_msg := vn.fxc_get_err_msg('V','2819');
      raise_application_error(-20100,t_err_msg||t_err_txt);
      END;

  end if;
/*check phan loai phi*/


       /*unblock so tien da block*/
       if i_status ='F' then/*trang thai xu ly*/
       BEGIN
          update  vn.DRCWDM06
             set TRANS_STT          = 'F'
               ,  work_dtm         = sysdate
               ,  work_trm         = i_work_trm
           where  SEQ_NO = i_seq_no;
      EXCEPTION
          WHEN  OTHERS         THEN
              t_err_txt  :=  t_proc_nm
                     ||  '??_????(DRCWDM06) ??? ??:'
                     ||  to_char(sqlcode);
        t_err_msg := vn.fxc_get_err_msg('V','2703');
        raise_application_error(-20100,t_err_msg||t_err_txt);
      END;
      /*update ve trang thai chua xu ly de user day lai*/
       return;
       else
       BEGIN
     vn.drv_pcw_waitting_bk_ubk_p
     (
           '02'
          , vn.vhdate
      , t_acnt_no
      , t_sub_no
      , t_cash_unblock
      , t_mdm_tp
      , i_work_mn
      , i_work_trm
      , tn_outq_dpo_bk
         );

       EXCEPTION
      WHEN OTHERS THEN
         t_err_txt := t_proc_nm
            || 'pcw_waitting_block_p_err:'
            || to_char(sqlcode);
               t_err_msg := vn.fxc_get_err_msg('V','9009');
         raise_application_error(-20100,t_err_msg||t_err_txt);
       END;
        BEGIN
        select  nvl(dpo,0)
          into  tn_dpo_prerm
          from  vn.DRCWDM00
         where  acnt_no  =  t_acnt_no
       and  sub_no   =  t_sub_no

           for  update;
           /*lay so du */
    EXCEPTION
        WHEN  NO_DATA_FOUND  THEN
            vn.pxc_log_write('drv_pcw_cash_outamt_behaft_p',' check 2: ' || sqlcode );
      t_ATDPST_found_yn           :=  'N';
            t_err_txt  :=  t_proc_nm
                   ||  '????(DRCWDM00) ??? ??:'
                   ||  to_char(sqlcode);
      t_err_msg := vn.fxc_get_err_msg('V','2704');
      raise_application_error(-20100,t_err_msg||t_err_txt);
        WHEN  OTHERS         THEN
        vn.pxc_log_write('drv_pcw_cash_outamt_behaft_p',' check 3: ' || sqlcode );
            t_err_txt  :=  t_proc_nm
                   ||  '????(DRCWDM00) ??? ??:'
                   ||  to_char(sqlcode);
      t_err_msg := vn.fxc_get_err_msg('V','2704');
      raise_application_error(-20100,t_err_msg||t_err_txt);
   END;
   if tn_dpo_prerm                 IS NULL
   then
        t_err_txt  :=  t_proc_nm
               ||  '?????????? NULL? ?';
    t_err_msg := vn.fxc_get_err_msg('V','2708');
    raise_application_error(-20100,t_err_msg||t_err_txt);
    end if;

   if  tn_dpo_prerm          <  0
   then
        t_err_txt  :=  t_proc_nm
               ||  '????(DRCWDM00)? ??? ??';
    t_err_msg := vn.fxc_get_err_msg('V','2002');
    raise_application_error(-20100,t_err_msg||t_err_txt);
   end if;
    tn_dpo      := tn_dpo_prerm;

/*tao but toan rut tien */
vn.pxc_psb_seq_cret_p  (   t_acnt_no
               ,  t_sub_no
                           ,  i_trd_dt
                           ,  o_trd_seq_no
                           ,  t_tot_trd_seq_no
                           );

                           ------------lay so du kha dung-------
                            tn_dpo      := tn_dpo - t_trd_amt;
    tn_tot_dpo_prerm := vn.drv_fcw_tot_dpo_prerm(t_acnt_no);
    tn_tot_dpo       := tn_tot_dpo_prerm - t_trd_amt;
    o_seq_no_cwd06   := o_trd_seq_no;
   -- o_trd_seq_no := o_trd_seq_no + 1;
   -- t_tot_trd_seq_no := t_tot_trd_seq_no +1;
    ----update so du--------
    BEGIN
          update  vn.DRCWDM00
             set  dpo              = tn_dpo
               ,  work_mn          = i_work_mn
               ,  work_dtm         = sysdate
               ,  work_trm         = i_work_trm
           where  acnt_no  =  t_acnt_no
         and  sub_no   =  t_sub_no;
      EXCEPTION
          WHEN  OTHERS         THEN
              t_err_txt  :=  t_proc_nm
                     ||  '??_????(cwd01m00) ??? ??:'
                     ||  to_char(sqlcode);
        t_err_msg := vn.fxc_get_err_msg('V','2703');
        raise_application_error(-20100,t_err_msg||t_err_txt);
      END;
    BEGIN
        insert  into  vn.aaa10m00
             (
         acnt_no
        ,sub_no
        ,trd_dt
        ,tot_trd_seq_no
        ,trd_seq_no
        ,trd_tp
        ,rmrk_cd
        ,mdm_tp
        ,cncl_yn
        ,org_trd_no
        ,trd_amt
        ,cmsn
        ,adj_amt
        ,dpo_prerm
        ,dpo_nowrm
        ,tot_dpo_prerm
        ,tot_dpo_nowrm
                ,acnt_mng_bnh
                ,agnc_brch
                ,work_bnh
                ,proc_agnc_brch
        ,work_mn
        ,work_dtm
        ,work_trm
        ,cnte
             )
        values
             (
         t_acnt_no
        ,t_sub_no
        ,i_trd_dt
        ,t_tot_trd_seq_no
        ,o_trd_seq_no
        ,'11'
        ,i_rmk_cd
        ,t_mdm_tp
        ,'N'
        ,0
        ,t_trd_amt
        ,0
        ,t_trd_amt
        ,tn_dpo_prerm
        ,tn_dpo
        ,tn_tot_dpo_prerm
        ,tn_tot_dpo
                ,ts_acnt_mng_bnh
                ,ts_agnc_brch
                ,t_proc_brch_cd
                ,t_proc_agnc_brch
        ,t_work_mn
        ,t_work_dtm
        ,i_work_trm
        ,t_acc_act_cd||'-' || to_char(o_trd_seq_no) || '-' ||t_cnte
             );
    EXCEPTION
        WHEN  OTHERS         THEN
            t_err_txt  :=  t_proc_nm
                   ||  'aaa10m00 error : '
                   ||  to_char(sqlcode);
      t_err_msg := vn.fxc_get_err_msg('V','9405');
      raise_application_error(-20100,t_err_msg||t_err_txt);
    END;

/* if t_fee_amt > 0 then*/
   if t_fee_type  ='E' then
   /*tao but toan phi*/
   tn_dpo_fee :=  tn_dpo;
   ----------lay seq_no--------
    vn.pxc_psb_seq_cret_p  (   t_acnt_no
               ,  t_sub_no
                           ,  i_trd_dt
                           ,  o_trd_seq_no
                           ,  t_tot_trd_seq_no
                           );

                           ------------lay so du kha dung-------
                            tn_dpo      := tn_dpo - t_fee_amt;
    tn_tot_dpo_prerm := vn.drv_fcw_tot_dpo_prerm(t_acnt_no);
    tn_tot_dpo       := tn_tot_dpo_prerm - t_fee_amt;


    ----update so du--------
    BEGIN
          update  vn.DRCWDM00
             set  dpo              = tn_dpo
               ,  work_mn          = t_work_mn
               ,  work_dtm         = sysdate
               ,  work_trm         = t_work_trm
           where  acnt_no  =  t_acnt_no
         and  sub_no   =  t_sub_no;
      EXCEPTION
          WHEN  OTHERS         THEN
              t_err_txt  :=  t_proc_nm
                     ||  '??_????(cwd01m00) ??? ??:'
                     ||  to_char(sqlcode);
        t_err_msg := vn.fxc_get_err_msg('V','2703');
        raise_application_error(-20100,t_err_msg||t_err_txt);
      END;
    BEGIN
        insert  into  vn.aaa10m00
             (
         acnt_no
        ,sub_no
        ,trd_dt
        ,tot_trd_seq_no
        ,trd_seq_no
        ,trd_tp
        ,rmrk_cd
        ,mdm_tp
        ,cncl_yn
        ,org_trd_no
        ,trd_amt
        ,cmsn
        ,adj_amt
        ,dpo_prerm
        ,dpo_nowrm
        ,tot_dpo_prerm
        ,tot_dpo_nowrm
                ,acnt_mng_bnh
                ,agnc_brch
                ,work_bnh
                ,proc_agnc_brch
        ,work_mn
        ,work_dtm
        ,work_trm
        ,cnte
             )
        values
             (
         t_acnt_no
        ,t_sub_no
        ,i_trd_dt
        ,t_tot_trd_seq_no
        ,o_trd_seq_no
        ,'10'
        ,'F02'
        ,t_mdm_tp
        ,'N'
        ,0
        ,t_fee_amt
        ,0
        ,t_fee_amt
        ,tn_dpo_fee
        ,tn_dpo
        ,tn_tot_dpo_prerm
        ,tn_tot_dpo
                ,ts_acnt_mng_bnh
                ,ts_agnc_brch
                ,t_proc_brch_cd
                ,t_proc_agnc_brch
        ,t_work_mn
        ,t_work_dtm
        ,i_work_trm
        ,t_acc_act_cd||'-' || to_char(o_trd_seq_no) || '-' ||t_cnte
             );
    EXCEPTION
        WHEN  OTHERS         THEN
            t_err_txt  :=  t_proc_nm
                   ||  'aaa10m00 error : '
                   ||  to_char(sqlcode);
      t_err_msg := vn.fxc_get_err_msg('V','9405');
      raise_application_error(-20100,t_err_msg||t_err_txt);
    END;
    end if;
/*end if;*/
 BEGIN
          update  vn.DRCWDM06
             set  TRD_SEQ_NO              = o_seq_no_cwd06
               ,  TRANS_STT          = 'Y'
               ,  work_dtm         = sysdate
               ,  work_trm         = i_work_trm
           where  SEQ_NO = i_seq_no;
      EXCEPTION
          WHEN  OTHERS         THEN
              t_err_txt  :=  t_proc_nm
                     ||  '??_????(DRCWDM06) ??? ??:'
                     ||  to_char(sqlcode);
        t_err_msg := vn.fxc_get_err_msg('V','2703');
        raise_application_error(-20100,t_err_msg||t_err_txt);
      END;
   BEGIN
          update  vn.CWD06M00
             set  TRD_SEQ_NO              = o_seq_no_cwd06
               ,  work_dtm         = sysdate
               ,  work_trm         = i_work_trm
           where  SEQ_NO = o_cwd06m00_seq;
      EXCEPTION
          WHEN  OTHERS         THEN
              t_err_txt  :=  t_proc_nm
                     ||  '??_????(CWD06M00) ??? ??:'
                     ||  to_char(sqlcode);
        t_err_msg := vn.fxc_get_err_msg('V','2703');
        raise_application_error(-20100,t_err_msg||t_err_txt);
      END;

       end if;


end drv_pcw_cash_outamt_behaft_p;
/

