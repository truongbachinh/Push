create function fdl_get_mon_lnd_cmsn
(
    i_lnd_tp       in   varchar2,        --
    i_acnt_no      in   varchar2,        --
    i_sub_no       in   varchar2,        --
    i_lnd_bank_cd  in   varchar2,        --
    i_fee_tp       in   varchar2,        -- 1:int 2:dly_int 3:all
    i_lnd_dt       in   varchar2,        --
    i_rpy_dt       in   varchar2,        --
    i_expr_dt      in   varchar2,        --
    i_last_rpy_dt  in   varchar2,        --
    i_remn_amt     in   number           --
)
    return  number
as

    t_last_rpy_dt           VARCHAR2(8) := null;

    t_lnd_int_cal_std_term	NUMBER := 0;
	t_lnd_int_min_term    	NUMBER := 0;
	t_lnd_int_rt            NUMBER := 0; -- 01:lnd_int ratio
	t_lnd_int_rt_min        NUMBER := 0; -- 02:lnd_int ratio for min duration
	t_lnd_int_amt_min       NUMBER := 0; -- 03:min lnd_int amt
	t_lnd_int_rt_dly        NUMBER := 0; -- 04:lnd_int dly_rt
	t_lnd_fee_rt            NUMBER := 0; -- 11:lnd_fee ratio
	t_lnd_fee_rt_min        NUMBER := 0; -- 12:lnd_fee ratio for min duration
	t_lnd_fee_amt_min       NUMBER := 0; -- 13:min lnd_fee amt
	t_lnd_fee_rt_dly        NUMBER := 0; -- 14:min lnd_fee amt

    t_tot_prd               NUMBER := 0;
    t_lnd_prd               NUMBER := 0;
    t_dly_prd               NUMBER := 0;
    t_lnd_fee               NUMBER := 0;
    t_lnd_fee_dly           NUMBER := 0;

	o_lnd_fee               NUMBER;
	o_dly_fee               NUMBER;
    t_err_txt               VARCHAR2(80)  ; -- error text buffer

begin
/*
select vn.fdl_get_mon_lnd_cmsn('055C000001','0001','20080202','20080201','20080501','20080215',10000000) from dual;
*/

/*============================================================================*/
/* Get apply loan Valiabl                                                     */
/*============================================================================*/
	if i_lnd_tp <> '70' then
		BEGIN
			vn.pdl_get_lnd_apy_val(
			    i_lnd_tp				,
			    i_acnt_no    			,
			    i_sub_no    			,
			    i_lnd_bank_cd			,
			    i_lnd_dt				,
			    '1'						,
			    '1'						,
				t_lnd_int_cal_std_term	,
				t_lnd_int_min_term    	,
			    t_lnd_int_rt            ,  -- 01:lnd_int ratio
			    t_lnd_int_rt_min        ,  -- 02:lnd_int ratio for min duration
			    t_lnd_int_amt_min       ,  -- 03:min lnd_int amt
		        t_lnd_int_rt_dly        ,  -- 04:lnd_int dly_rt
			    t_lnd_fee_rt            ,  -- 11:lnd_fee ratio
			    t_lnd_fee_rt_min        ,  -- 12:lnd_fee ratio for min duration
			    t_lnd_fee_amt_min       ,  -- 13:min lnd_fee amt
			    t_lnd_fee_rt_dly        ); -- 14:min lnd_fee amt
		EXCEPTION
	    WHEN others then
	        raise_application_error(-20100,'ERROR1');
	    END;
	else
		t_lnd_int_cal_std_term	:=  1;
		t_lnd_int_min_term		:=  0;
	    t_lnd_int_rt			:=  0;  -- 01:lnd_int ratio
	    t_lnd_int_rt_min		:=  0;  -- 02:lnd_int ratio for min duration
	    t_lnd_int_amt_min		:=  0;  -- 03:min lnd_int amt
        t_lnd_int_rt_dly		:=  0;  -- 04:lnd_int dly_rt
	    t_lnd_fee_rt			:=  0;  -- 11:lnd_fee ratio
	    t_lnd_fee_rt_min		:=  0;  -- 12:lnd_fee ratio for min duration
	    t_lnd_fee_amt_min		:=  0;  -- 13:min lnd_fee amt
	    t_lnd_fee_rt_dly		:=  0;  -- 14:lnd_cmsn dly_rt
	end if;

/*============================================================================*/
/* Calculate period                                                           */
/*============================================================================*/

	t_tot_prd      :=  to_date(i_rpy_dt,'yyyymmdd') - to_date(i_lnd_dt,'yyyymmdd');
	t_tot_prd 	   :=  GREATEST(t_tot_prd, 1);
	t_last_rpy_dt  :=  greatest(i_lnd_dt, i_last_rpy_dt);

    if  i_expr_dt > i_rpy_dt then
        t_dly_prd  :=  0;

        t_lnd_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_last_rpy_dt, 'yyyymmdd');

    else
        if  i_expr_dt > i_last_rpy_dt then
            /*==============================================*/
            /* loan period : expire date ~ last repay date  */
            /* dely prriod : repay date ~ expire date       */
            /*==============================================*/
            t_lnd_prd  :=  to_date(i_expr_dt, 'yyyymmdd') - to_date(i_last_rpy_dt, 'yyyymmdd');
            t_dly_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_expr_dt, 'yyyymmdd');
        else
            /*==============================================*/
            /* loan period :                                */
            /* dely prriod : repay date ~ last repay date   */
            /*==============================================*/
            t_dly_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_last_rpy_dt, 'yyyymmdd');
        end if;
    end if;


        /*==================================================*/
        /* fee calc : max(�ݾ�������*�Ⱓ/30, 10,000)    */
        /*==================================================*/
	    if  t_lnd_prd > 0 then
		    t_lnd_fee := greatest(i_remn_amt * t_lnd_fee_rt * t_lnd_prd / t_lnd_int_cal_std_term, t_lnd_fee_amt_min);
	    end if;

        /*==================================================*/
        /* dely fee :                                       */
        /*==================================================*/
	    if  t_dly_prd > 0 then
	 		t_lnd_fee_dly := greatest(i_remn_amt * t_lnd_fee_rt * t_dly_prd / t_lnd_int_cal_std_term * t_lnd_fee_rt_dly, t_lnd_fee_amt_min);
	    end if;


    /*==================================================*/
    /* fee type : 1.fee 2.delay fee 3.all               */
    /*==================================================*/
    if  i_fee_tp = '1' then
        o_lnd_fee := round(t_lnd_fee);
    elsif i_fee_tp = '2' then
        o_lnd_fee := round(t_lnd_fee_dly);
    else
        o_lnd_fee := round(t_lnd_fee) + round(t_lnd_fee_dly);
    end if;

    return o_lnd_fee;

end fdl_get_mon_lnd_cmsn;
/

