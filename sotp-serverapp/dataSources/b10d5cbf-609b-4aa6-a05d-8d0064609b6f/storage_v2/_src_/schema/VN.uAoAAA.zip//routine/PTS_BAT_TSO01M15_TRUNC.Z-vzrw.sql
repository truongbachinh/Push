create procedure    pts_bat_tso01m15_trunc (
    i_work_dt       in      varchar2,       -- date(yyyymmdd)
	o_err_code      in      number,         -- error code(0:SUCCESS)
	o_err_msg       in      varchar2,       -- error message
	o_proc_cnt      out     number          -- proc data count
) as

t_err_code      number        := o_err_code;
t_err_msg       varchar2(600) := rtrim(o_err_msg);
t_chk           varchar2(1);
exp_error       exception;

/*!
    \file     pts_bat_tso01m00_trunc
    \brief    tso01m15 table reset

	\section intro Program Information
		- Program Name              : pts_bat_tso01m15_trunc
		- Service Name              :
		- Related Client Program- Client Program ID :
		- Related Tables            : tso01m15
		- Dev. Date                 : 2019/05/21
		- Developer                 : HieuPM
		- Business Logic Desc.      :
		- Latest Modification Date  :

	\section history Program Modification History
		- 1.0  2007/11/27

	\section hardcoding Hard-Coding List

	\section info Additional Reference Comments
*/

begin

	t_err_code := 0;
	t_err_msg  := 'SUCCESS';
	t_chk      := 'Y';
    o_proc_cnt := 0;

	-- 1. ¢¥cAI ¡ÆaA|A¨ù¡Æa ¢¯I¡¤a A¨ùA¨Ï FunA¨ùA¨Ï

	-- 2. AO©ö¢ç©ø¡í¢¯¨£¡Æu¢¬¢ç A¡¿AI¨¬i AE¡¾aE¡©
	if t_chk = 'Y' then
		delete from vn.tso01m15 ;
		o_proc_cnt := SQL%ROWCOUNT;
	else
		t_err_code := -1;
	    t_err_msg  := '¢¥cAI ¡ÆaA|A¨ù¡Æa ©öI¢¯I¡¤aAO¢¥I¢¥U. A¨ù¡Æa ¡ÆaA| EA A©ø¢¬¢çCI¨öE¨öA¢¯a.!';
		raise_application_error(-20100,'[pts_bat_tso01m00_trunc] ' || t_err_msg);
	end if;

	exception when  exp_error then
		t_err_code := sqlcode;
		t_err_msg  := sqlerrm;
		raise_application_error(-20100,'[pts_bat_tso01m00_trunc] ' || t_err_msg);

end pts_bat_tso01m15_trunc;
/

