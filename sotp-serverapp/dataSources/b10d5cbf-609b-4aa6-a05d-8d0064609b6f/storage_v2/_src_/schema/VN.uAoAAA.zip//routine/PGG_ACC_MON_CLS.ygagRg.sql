create PROCEDURE    PGG_ACC_MON_CLS
   (I_FLAG          IN      VARCHAR2,       -- U:마감,D:취소
    I_YYMM          IN      VARCHAR2,       -- 마감년월
    I_BRCH_CD       IN      VARCHAR2,       -- 지점
    I_AGNC_BRCH     IN      VARCHAR2,       -- 대리지점
    I_WORK_MN       IN      VARCHAR2,		-- 처리자
    I_WORK_TRM      IN      VARCHAR2,       -- IP_ADDRESS
    O_RTN_TBL       OUT     VARCHAR2,       -- Return Table
	O_RTN_ERR       OUT     VARCHAR2,       -- Return Error Code
	O_RTN_MSG       OUT     VARCHAR2        -- Return Message
	) IS

    -- Constants
    K_ALL_BRCH      VARCHAR2(3) := '000' ;      -- 회사전체
    K_BON_BRCH      VARCHAR2(3) := '901' ;      -- 본점
    K_MAX_DT        VARCHAR2(8) := '30001231' ; -- 지점종료일

    -- Variables
    T_TERMS         NUMBER := VN.FGG_GET_TERMS(I_YYMM || '01'); -- 회계기수
    T_PRE_YYMM      VARCHAR2(6) := TO_CHAR(ADD_MONTHS(TO_DATE(I_YYMM || '01', 'YYYYMMDD'), -1), 'YYYYMM') ; -- 전월
    T_NEX_YYMM      VARCHAR2(6) := TO_CHAR(ADD_MONTHS(TO_DATE(I_YYMM || '01', 'YYYYMMDD'), 1), 'YYYYMM') ;  -- 익월
    T_LAST_WORK     VARCHAR2(8) := VN.FGG_GET_WORK_DT(TO_CHAR(LAST_DAY(TO_DATE(I_YYMM || '01', 'YYYYMMDD')), 'YYYYMMDD'), '-') ;   -- 당월마지막영업일
    T_LAST_DAY      VARCHAR2(8) := TO_CHAR(LAST_DAY(TO_DATE(I_YYMM || '01', 'YYYYMMDD')), 'YYYYMMDD') ;   -- 당월마지막일

    T_OPN_DT        VARCHAR2(8) := VN.FGG_GET_TERMS_DT(T_TERMS, '1') ;
    T_TERMS_LAST    VARCHAR2(8) := VN.FGG_GET_WORK_DT(VN.FGG_GET_TERMS_DT(T_TERMS, '2'), '-') ;
    T_BRCH_OPN_DT   VARCHAR2(8) := TO_CHAR(SYSDATE, 'YYYYMMDD') ;
                                                       -- 기 마지막영업일자
    T_CNT           NUMBER := 0;
    T_DAY_CNT       NUMBER := TO_NUMBER(T_LAST_DAY) - TO_NUMBER(I_YYMM || '00');
    T_TERM_TP       VARCHAR2(1) ;   -- 회기시작구분(0:시작월, 1:그외월, 9:종료월)
    T_CHECK         VARCHAR2(1) ;

    T_TERMS_NEX     VARCHAR2(6) := SUBSTR(VN.FGG_GET_TERMS_DT(T_TERMS + 1, '1'), 1, 4) || '00' ;

    O1_RTN_TBL      VARCHAR2(100) ;      				-- Return Table
	O1_RTN_ERR      VARCHAR2(100) ;      				-- Return Error Code
	O1_RTN_MSG      VARCHAR2(254) ;      				-- Return Message


    -- Exceptions Declare
    ERR_GGA01C00        EXCEPTION;
    ERR_GGA11M00        EXCEPTION;
    ERR_GGA11M00_1      EXCEPTION;
    ERR_GGA10M00        EXCEPTION;
    ERR_GGA11M00_2      EXCEPTION;
    ERR_GGA11M00_3      EXCEPTION;
    ERR_GGA11M00_UPD	EXCEPTION;
    ERR_GGA11M00_INS	EXCEPTION;
    ERR_GGA09M00_INS	EXCEPTION;
    ERR_GGA09M00_INS_1	EXCEPTION;
    ERR_GGA14M00_INS	EXCEPTION;
    ERR_GGA14M00_INS_1	EXCEPTION;
    ERR_GGA25T00_INS	EXCEPTION;

    ERR_GGA11M00_4      EXCEPTION;
    ERR_GGA11M00_5      EXCEPTION;
    ERR_GGA11M00_6      EXCEPTION;

-- *************************< START OF PROCEDURE >****************************
BEGIN

    T_TERM_TP := '1' ;
    T_CHECK   := '1' ;

    BEGIN
    	/* 0. 회기시작구분 */
    	SELECT	CASE
    	   			WHEN	SUBSTR(A.OPN_DT, 5, 2)	=	SUBSTR(I_YYMM, 5, 2)	THEN	'0'
    	   			WHEN	SUBSTR(A.END_DT, 5, 2)	=	SUBSTR(I_YYMM, 5, 2)	THEN	'9'
    	   			ELSE	'1'
    			END				AS	TERM_TP
    	  INTO	T_TERM_TP
    	  FROM	VN.GGA01C00 A
    	 WHERE	I_YYMM || '01'	BETWEEN	A.OPN_DT AND A.END_DT
    	   AND	ROWNUM	<=	1 ;

    	/* 0. 지점시작구분 */
    	SELECT	CASE
    	   			WHEN	SUBSTR(NVL(A.BRCH_OPN_DT, TO_CHAR(SYSDATE, 'YYYYMMDD')), 1, 6)	=	SUBSTR(I_YYMM, 1, 6)	THEN	'0'
    	   			ELSE	'1'
    			END													AS	CHECK_TP,
    			NVL(A.BRCH_OPN_DT, TO_CHAR(SYSDATE, 'YYYYMMDD'))	AS	BRCH_OPN_DT
    	  INTO	T_CHECK,	T_BRCH_OPN_DT
    	  FROM	VN.XCC90M00 A
         WHERE	A.BRCH_CD	=	I_BRCH_CD
           AND	A.AGNC_BRCH	=	I_AGNC_BRCH
    	   AND	ROWNUM	<=	1 ;

    	/* 0. 회사전체 */
    	SELECT	A.COL_CD_TP		AS	COL_CD_TP
    	  INTO	K_ALL_BRCH
    	  FROM	VN.XCC01C01 A
         WHERE	A.COL_CD	=	'cmp_full_cd'
    	   AND	ROWNUM	<=	1 ;

    EXCEPTION WHEN OTHERS THEN
		RAISE ERR_GGA01C00;
    END;

	/* 0. 지점 마감일수 계산 */
	IF  T_CHECK   =   '0'  THEN
		T_DAY_CNT := TO_NUMBER(T_LAST_DAY) - (TO_NUMBER(T_BRCH_OPN_DT) - 1);
	ELSE
		T_DAY_CNT := TO_NUMBER(T_LAST_DAY) - TO_NUMBER(I_YYMM || '00');
    END IF;

    /* 0. 회사전체 */
    BEGIN
    	SELECT	A.COL_CD_TP		AS	COL_CD_TP
    	  INTO	K_ALL_BRCH
    	  FROM	VN.XCC01C01 A
         WHERE	A.COL_CD	=	'cmp_full_cd'
    	   AND	ROWNUM	<=	1 ;

    EXCEPTION WHEN OTHERS THEN
        K_ALL_BRCH := '000';
    END;

    /* 0. 본사회계부서코드 */
    BEGIN
    	SELECT	A.COL_CD_TP		AS	COL_CD_TP
    	  INTO	K_BON_BRCH
    	  FROM	VN.XCC01C01 A
         WHERE	A.COL_CD	=	'head_acc_bnh_cd'
    	   AND	ROWNUM	<=	1 ;

    EXCEPTION WHEN OTHERS THEN
        K_BON_BRCH := '901';
    END;


    -- *********************
    -- * 회   계   마   감 *
    -- *********************
    IF  I_FLAG  =   'U' THEN

        -- U_1. 회사전체일 경우 본점,전지점이 마감된후 처리가능
        T_CNT   := 0 ;
        IF  I_BRCH_CD   =   K_ALL_BRCH  THEN

        	SELECT	COUNT(*)
              INTO  T_CNT
        	  FROM	VN.XCC90M00 v11,
        			(	SELECT	v21.BRCH_CD			AS	BRCH_CD,
        						v21.AGNC_BRCH		AS	AGNC_BRCH,
        						v21.ACC_CLS_YN		AS	ACC_CLS_YN
        				  FROM	VN.GGA11M00 v21
        				 WHERE	v21.TERMS		=	T_TERMS
        				   AND	v21.CLS_YM		=	SUBSTR(I_YYMM, 1, 6)
        				   AND	v21.BRCH_CD		<>	K_ALL_BRCH
        				   AND	v21.AGNC_BRCH	=	'00'
        			)			v12
        	 WHERE	v11.AGNC_BRCH		=	'00'
        	   AND	v11.HEAD_BRCH_TP	IN	('0', '1')
        	   AND	v11.BRCH_CD			<>	K_ALL_BRCH
        	   AND	SUBSTR(I_YYMM, 1, 6)	BETWEEN SUBSTR(NVL(v11.BRCH_OPN_DT, TO_CHAR(SYSDATE, 'YYYYMMDD')), 1, 6)
        										AND	SUBSTR(NVL(v11.BRCH_END_DT, K_MAX_DT), 1, 6)
        	   AND	v11.BRCH_CD		=	v12.BRCH_CD(+)
        	   AND	v11.AGNC_BRCH	=	v12.AGNC_BRCH(+)
        	   AND	NVL(v12.ACC_CLS_YN, 'N')	=	'N' ;

            IF  T_CNT   >=  1   THEN
                RAISE ERR_GGA11M00;
            END IF;

        END IF;

        -- U_1. 본점일 경우 전지점이 마감된후 처리가능
        T_CNT   := 0 ;
        IF  I_BRCH_CD   =   K_BON_BRCH  THEN

        	SELECT	COUNT(*)
              INTO  T_CNT
        	  FROM	VN.XCC90M00 v11,
        			(	SELECT	v21.BRCH_CD			AS	BRCH_CD,
        						v21.AGNC_BRCH		AS	AGNC_BRCH,
        						v21.ACC_CLS_YN		AS	ACC_CLS_YN
        				  FROM	VN.GGA11M00 v21
        				 WHERE	v21.TERMS		=	T_TERMS
        				   AND	v21.CLS_YM		=	SUBSTR(I_YYMM, 1, 6)
        				   AND	v21.BRCH_CD		NOT IN  (K_ALL_BRCH, K_BON_BRCH)
        				   AND	v21.AGNC_BRCH	=	'00'
        			)			v12
        	 WHERE	v11.AGNC_BRCH		=	'00'
        	   AND	v11.HEAD_BRCH_TP	IN	('0', '1')
        	   AND	v11.BRCH_CD			NOT IN  (K_ALL_BRCH, K_BON_BRCH)
        	   AND	SUBSTR(I_YYMM, 1, 6)	BETWEEN SUBSTR(NVL(v11.BRCH_OPN_DT, TO_CHAR(SYSDATE, 'YYYYMMDD')), 1, 6)
        										AND	SUBSTR(NVL(v11.BRCH_END_DT, K_MAX_DT), 1, 6)
        	   AND	v11.BRCH_CD		=	v12.BRCH_CD(+)
        	   AND	v11.AGNC_BRCH	=	v12.AGNC_BRCH(+)
        	   AND	NVL(v12.ACC_CLS_YN, 'N')	=	'N' ;

            IF  T_CNT   >=  1   THEN
                RAISE ERR_GGA11M00;
            END IF;

        END IF;

        -- U_2. 회계월마감체크(당월)
        T_CNT   := 0 ;
		SELECT	COUNT(*)
		  INTO  T_CNT
		  FROM	VN.GGA11M00
		 WHERE	TERMS		=	T_TERMS
		   AND	CLS_YM		=	SUBSTR(I_YYMM, 1, 6)
		   AND	BRCH_CD		=   I_BRCH_CD
		   AND	AGNC_BRCH	=	I_AGNC_BRCH
       	   AND	NVL(ACC_CLS_YN, 'N')	=	'Y' ;

        IF  T_CNT   >=  1   THEN
            RAISE ERR_GGA11M00_1;
        END IF;

        -- U_3. 회계일마감체크
        T_CNT   := 0 ;
        IF  I_BRCH_CD   !=   K_ALL_BRCH  THEN
    		SELECT	COUNT(*)
    		  INTO  T_CNT
    		  FROM	VN.GGA10M00
    		 WHERE	ACC_CLS_DT  >=	I_YYMM || '01'
    		   AND	ACC_CLS_DT  <=	T_LAST_DAY
    		   AND	BRCH_CD		=   I_BRCH_CD
    		   AND	AGNC_BRCH	=	I_AGNC_BRCH
           	   AND	NVL(ACC_CLS_YN, 'N')	=	'Y' ;

            IF  T_CNT   <  T_DAY_CNT   THEN
                RAISE ERR_GGA10M00;
            END IF;
        END IF;

        -- U_4. 회계월마감체크(전월)
        T_CNT   := 1 ;
        IF  T_TERM_TP   !=   '0'  OR    T_CHECK   !=   '1'  THEN
    		SELECT	COUNT(*)
    		  INTO  T_CNT
    		  FROM	VN.GGA11M00
    		 WHERE	TERMS		=	T_TERMS
    		   AND	CLS_YM		=	SUBSTR(T_PRE_YYMM, 1, 6)
    		   AND	BRCH_CD		=   I_BRCH_CD
    		   AND	AGNC_BRCH	=	I_AGNC_BRCH
           	   AND	NVL(ACC_CLS_YN, 'N')	=	'Y' ;
        END IF;

        IF  T_CNT   <=  0   THEN
            RAISE ERR_GGA11M00_2;
        END IF;

        -- U_5. 회계월마감체크(익월)
        IF  T_TERM_TP   !=   '9'  THEN
            T_CNT   := 0 ;
    		SELECT	COUNT(*)
    		  INTO  T_CNT
    		  FROM	VN.GGA11M00
    		 WHERE	TERMS		=	T_TERMS
    		   AND	CLS_YM		=	SUBSTR(T_NEX_YYMM, 1, 6)
    		   AND	BRCH_CD		=   I_BRCH_CD
    		   AND	AGNC_BRCH	=	I_AGNC_BRCH
           	   AND	NVL(ACC_CLS_YN, 'N')	=	'Y' ;

            IF  T_CNT   >=  1   THEN
                RAISE ERR_GGA11M00_3;
            END IF;

        END IF;

        -- U_6. 회계월계 기존자료 삭제
        DELETE
          FROM  VN.GGA09M00
		 WHERE	TERMS		=	T_TERMS
		   AND	CLS_YM		=	SUBSTR(I_YYMM, 1, 6)
		   AND	BRCH_CD		=   I_BRCH_CD
		   AND	AGNC_BRCH	=	I_AGNC_BRCH ;

        -- U_6. 회계거래처월계 기존자료 삭제
        DELETE
          FROM  VN.GGA14M00
		 WHERE	TERMS		=	T_TERMS
		   AND	CLS_YM		=	SUBSTR(I_YYMM, 1, 6)
		   AND	BRCH_CD		=   I_BRCH_CD
		   AND	AGNC_BRCH	=	I_AGNC_BRCH ;

        -- U_6. 회계월마감 FLAG SET
        T_CNT   := 0 ;
		SELECT	COUNT(*)
		  INTO  T_CNT
		  FROM	VN.GGA11M00
		 WHERE	TERMS		=	T_TERMS
		   AND	CLS_YM		=	SUBSTR(I_YYMM, 1, 6)
		   AND	BRCH_CD		=   I_BRCH_CD
		   AND	AGNC_BRCH	=	I_AGNC_BRCH ;

        -- U_6. 회계월마감 FLAG SET
        IF  T_CNT   >=  1   THEN
			BEGIN
                UPDATE  VN.GGA11M00
                   SET  ACC_CLS_YN  =   'Y',
                        WORK_MN     =   I_WORK_MN,
                        WORK_DTM    =   SYSDATE,
                        WORK_TRM    =   I_WORK_TRM
        		 WHERE	TERMS		=	T_TERMS
        		   AND	CLS_YM		=	SUBSTR(I_YYMM, 1, 6)
        		   AND	BRCH_CD		=   I_BRCH_CD
        		   AND	AGNC_BRCH	=	I_AGNC_BRCH ;
		    EXCEPTION WHEN OTHERS THEN
		        RAISE ERR_GGA11M00_UPD;
		    END;
        -- U_7. 회계월마감 FLAG SET
        ELSE
			BEGIN
                INSERT
                  INTO  VN.GGA11M00(
                        TERMS,
                        CLS_YM,
                        BRCH_CD,
                        AGNC_BRCH,
                        ACC_CLS_YN,
                        WORK_MN,
                        WORK_DTM,
                        WORK_TRM )
                VALUES  (T_TERMS,
                        I_YYMM,
                        I_BRCH_CD,
                        I_AGNC_BRCH,
                        'Y',
                        I_WORK_MN,
                        SYSDATE,
                        I_WORK_TRM );
		    EXCEPTION WHEN OTHERS THEN
		        RAISE ERR_GGA11M00_INS;
		    END;
        END IF;

        -- U_8. 회계월마감처리
        FOR C1 IN
        	(	SELECT	v11.CLS_YM					        AS	CLS_YM,
        				v11.ACC_ACT_CD					    AS	ACC_ACT_CD,
        				NVL(SUM(v11.PM_DR_ACCM_AMT), 0)		AS	PM_DR_ACCM_AMT,
        				NVL(SUM(v11.PM_CR_ACCM_AMT), 0)		AS	PM_CR_ACCM_AMT,
        				NVL(SUM(v11.TM_DR_AMT), 0)		    AS	TM_DR_AMT,
        				NVL(SUM(v11.TM_CR_AMT), 0)		    AS	TM_CR_AMT
        		  FROM
        					/* 전월까지 누적금액 누계 */
        				(	SELECT	v21.CLS_YM                      AS	CLS_YM,
        							v21.ACC_ACT_CD					AS	ACC_ACT_CD,
        							NVL(v21.PM_DR_ACCM_AMT, 0)		AS	PM_DR_ACCM_AMT,
        							NVL(v21.PM_CR_ACCM_AMT, 0)		AS	PM_CR_ACCM_AMT,
        							NVL(v21.TM_DR_AMT, 0)			AS	TM_DR_AMT,
        							NVL(v21.TM_CR_AMT, 0)			AS	TM_CR_AMT
        					  FROM
        								/* 전기이월 집계 */
        							(	SELECT	SUBSTR(I_YYMM, 1, 6)                AS	CLS_YM,
        							            v31.ACC_ACT_CD					    AS	ACC_ACT_CD,
        							            NVL(v31.PM_DR_ACCM_AMT, 0) +
        											NVL(v31.TM_DR_AMT, 0)		    AS	PM_DR_ACCM_AMT,		/* 차변누적금액 */
        										NVL(v31.PM_CR_ACCM_AMT, 0) +
        											NVL(v31.TM_CR_AMT, 0)		    AS	PM_CR_ACCM_AMT,		/* 대변누적금액 */
        										0                                   AS  TM_DR_AMT,          /* 차변금액 */
        										0                                   AS  TM_CR_AMT           /* 대변금액 */
        								  FROM	VN.GGA09M00	v31	/* 회계월계 */
        								 WHERE	v31.TERMS		=	T_TERMS
        								   AND	v31.CLS_YM		=	SUBSTR(I_YYMM, 1, 4) || '00'
        								   AND	v31.BRCH_CD		=	I_BRCH_CD
        								   AND	v31.AGNC_BRCH	=	I_AGNC_BRCH
                                    UNION ALL
        								/* 전월까지발생금액 집계 */
        								SELECT	SUBSTR(I_YYMM, 1, 6)                AS	CLS_YM,
        							            v31.ACC_ACT_CD					    AS	ACC_ACT_CD,
        							            NVL(v31.TM_DR_AMT, 0)		        AS	PM_DR_ACCM_AMT,		/* 차변누적금액 */
        										NVL(v31.TM_CR_AMT, 0)		        AS	PM_CR_ACCM_AMT,		/* 대변누적금액 */
        										0                                   AS  TM_DR_AMT,          /* 차변금액 */
        										0                                   AS  TM_CR_AMT           /* 대변금액 */
        								  FROM	VN.GGA09M00	v31	/* 회계월계 */
        								 WHERE	v31.TERMS		=	T_TERMS
                    					   AND	v31.CLS_YM		>=	SUBSTR(T_OPN_DT, 1, 6)
                    					   AND	v31.CLS_YM		<	SUBSTR(I_YYMM, 1, 6)
        								   AND	v31.BRCH_CD		=	I_BRCH_CD
        								   AND	v31.AGNC_BRCH	=	I_AGNC_BRCH
        							)			v21
        					UNION ALL
        					/* 당월까지 발생금액 누계 */
        					SELECT	v21.CLS_YM                      AS	CLS_YM,
        							v21.ACC_ACT_CD					AS	ACC_ACT_CD,
        							NVL(v21.PM_DR_ACCM_AMT, 0)		AS	PM_DR_ACCM_AMT,
        							NVL(v21.PM_CR_ACCM_AMT, 0)		AS	PM_CR_ACCM_AMT,
        							NVL(v21.TM_DR_AMT, 0)			AS	TM_DR_AMT,
        							NVL(v21.TM_CR_AMT, 0)			AS	TM_CR_AMT
        					  FROM
        								/* 당월발생금액 집계 */
        							(	SELECT	SUBSTR(v31.ACC_CLS_DT, 1, 6)	AS	CLS_YM,
        										v31.ACC_ACT_CD					AS	ACC_ACT_CD,
        										0                               AS	PM_DR_ACCM_AMT,		/* 차변누적금액 */
        										0                               AS	PM_CR_ACCM_AMT,		/* 대변누적금액 */
        										NVL(v31.DR_EXCH_AMT, 0) +
        											NVL(v31.DR_CASH_AMT, 0)		AS	TM_DR_AMT,		    /* 차변금액 */
        										NVL(v31.CR_EXCH_AMT, 0) +
        											NVL(v31.CR_CASH_AMT, 0)		AS	TM_CR_AMT		    /* 대변금액 */
        								  FROM	VN.GGA08M00	v31		/* 회계일계 */
        								 WHERE	v31.ACC_CLS_DT	>=	SUBSTR(I_YYMM, 1, 6) || '01'
        								   AND	v31.ACC_CLS_DT	<=	TO_CHAR(LAST_DAY(TO_DATE(SUBSTR(I_YYMM, 1, 6) || '01', 'YYYYMMDD')), 'YYYYMMDD')
        								   AND	v31.BRCH_CD		=	DECODE(I_BRCH_CD, K_ALL_BRCH, v31.BRCH_CD, I_BRCH_CD)
        								   AND	v31.AGNC_BRCH	=	I_AGNC_BRCH
        							)			v21
        				)			v11
        	  GROUP BY	v11.CLS_YM,
        				v11.ACC_ACT_CD
            ) LOOP

            -- U_8. 회계월계 자료생성
            --IF  C1.PM_DR_ACCM_AMT   =   0   AND C1.PM_CR_ACCM_AMT   =   0   AND
            --    C1.TM_DR_AMT        =   0   AND C1.TM_CR_AMT        =   0   THEN    -- 0인경우 제외
			BEGIN
                INSERT
                  INTO  VN.GGA09M00(
                        TERMS,
                        CLS_YM,
                        BRCH_CD,
                        AGNC_BRCH,
                        ACC_ACT_CD,
                        PM_DR_ACCM_AMT,
                        PM_CR_ACCM_AMT,
                        TM_DR_AMT,
                        TM_CR_AMT,
                        WORK_MN,
                        WORK_DTM,
                        WORK_TRM )
                VALUES  (T_TERMS,
                        C1.CLS_YM,
                        I_BRCH_CD,
                        I_AGNC_BRCH,
                        C1.ACC_ACT_CD,
                        C1.PM_DR_ACCM_AMT,
                        C1.PM_CR_ACCM_AMT,
                        C1.TM_DR_AMT,
                        C1.TM_CR_AMT,
                        I_WORK_MN,
                        SYSDATE,
                        I_WORK_TRM );
		    EXCEPTION WHEN OTHERS THEN
		        RAISE ERR_GGA09M00_INS;
		    END;
            --END IF;

        END LOOP;   -- C1 End Loop


        -- U_9. 회계거래처월마감처리
        FOR C11 IN
        	(	SELECT	v11.CLS_YM					        AS	CLS_YM,
        				v11.ACC_ACT_CD					    AS	ACC_ACT_CD,
						v11.CUST_CD							AS	CUST_CD,
        				NVL(SUM(v11.PM_DR_ACCM_AMT), 0)		AS	PM_DR_ACCM_AMT,
        				NVL(SUM(v11.PM_CR_ACCM_AMT), 0)		AS	PM_CR_ACCM_AMT,
        				NVL(SUM(v11.TM_DR_AMT), 0)		    AS	TM_DR_AMT,
        				NVL(SUM(v11.TM_CR_AMT), 0)		    AS	TM_CR_AMT
        		  FROM
        					/* 전월까지 누적금액 누계 */
        				(	SELECT	v21.CLS_YM                      AS	CLS_YM,
        							v21.ACC_ACT_CD					AS	ACC_ACT_CD,
									NVL(v21.CUST_CD, '0000000000')	AS	CUST_CD,
        							NVL(v21.PM_DR_ACCM_AMT, 0)		AS	PM_DR_ACCM_AMT,
        							NVL(v21.PM_CR_ACCM_AMT, 0)		AS	PM_CR_ACCM_AMT,
        							NVL(v21.TM_DR_AMT, 0)			AS	TM_DR_AMT,
        							NVL(v21.TM_CR_AMT, 0)			AS	TM_CR_AMT
        					  FROM
        								/* 전기이월 집계 */
        							(	SELECT	SUBSTR(I_YYMM, 1, 6)				AS	CLS_YM,
        							            v31.ACC_ACT_CD						AS	ACC_ACT_CD,
												CASE
													WHEN	NVL(v32.ACT_TP, '00')	=	'10'	OR
															NVL(v32.ACT_TP, '00')	=	'20'	THEN	NVL(v31.CUST_CD, '0000000000')
													ELSE	'0000000000'
												END									AS	CUST_CD,
        							            NVL(v31.PM_DR_ACCM_AMT, 0) +
        											NVL(v31.TM_DR_AMT, 0)			AS	PM_DR_ACCM_AMT,		/* 차변누적금액 */
        										NVL(v31.PM_CR_ACCM_AMT, 0) +
        											NVL(v31.TM_CR_AMT, 0)			AS	PM_CR_ACCM_AMT,		/* 대변누적금액 */
        										0									AS  TM_DR_AMT,          /* 차변금액 */
        										0									AS  TM_CR_AMT           /* 대변금액 */
        								  FROM	VN.GGA14M00	v31,		/* 회계거래처월계 */
												VN.GGA02C00	v32
        								 WHERE	v31.TERMS		=	T_TERMS
        								   AND	v31.CLS_YM		=	SUBSTR(I_YYMM, 1, 4) || '00'
        								   AND	v31.BRCH_CD		=	I_BRCH_CD
        								   AND	v31.AGNC_BRCH	=	I_AGNC_BRCH
        								   AND	v31.ACC_ACT_CD	=	v32.ACC_ACT_CD(+)
                                    UNION ALL
        								/* 전월까지발생금액 집계 */
        								SELECT	SUBSTR(I_YYMM, 1, 6)                AS	CLS_YM,
        							            v31.ACC_ACT_CD					    AS	ACC_ACT_CD,
												CASE
													WHEN	NVL(v32.ACT_TP, '00')	=	'10'	OR
															NVL(v32.ACT_TP, '00')	=	'20'	THEN	NVL(v31.CUST_CD, '0000000000')
													ELSE	'0000000000'
												END									AS	CUST_CD,
        							            NVL(v31.TM_DR_AMT, 0)		        AS	PM_DR_ACCM_AMT,		/* 차변누적금액 */
        										NVL(v31.TM_CR_AMT, 0)		        AS	PM_CR_ACCM_AMT,		/* 대변누적금액 */
        										0                                   AS  TM_DR_AMT,          /* 차변금액 */
        										0                                   AS  TM_CR_AMT           /* 대변금액 */
        								  FROM	VN.GGA14M00	v31,		/* 회계거래처월계 */
												VN.GGA02C00	v32
        								 WHERE	v31.TERMS		=	T_TERMS
                    					   AND	v31.CLS_YM		>=	SUBSTR(T_OPN_DT, 1, 6)
                    					   AND	v31.CLS_YM		<	SUBSTR(I_YYMM, 1, 6)
        								   AND	v31.BRCH_CD		=	I_BRCH_CD
        								   AND	v31.AGNC_BRCH	=	I_AGNC_BRCH
        								   AND	v31.ACC_ACT_CD	=	v32.ACC_ACT_CD(+)
        							)			v21
        					UNION ALL
        					/* 당월까지 발생금액 누계 */
        					SELECT	v21.CLS_YM                      AS	CLS_YM,
        							v21.ACC_ACT_CD					AS	ACC_ACT_CD,
									NVL(v21.CUST_CD, '0000000000')	AS	CUST_CD,
        							NVL(v21.PM_DR_ACCM_AMT, 0)		AS	PM_DR_ACCM_AMT,
        							NVL(v21.PM_CR_ACCM_AMT, 0)		AS	PM_CR_ACCM_AMT,
        							NVL(v21.TM_DR_AMT, 0)			AS	TM_DR_AMT,
        							NVL(v21.TM_CR_AMT, 0)			AS	TM_CR_AMT
        					  FROM
        								/* 당월발생금액 집계 */
        							(	SELECT	SUBSTR(v31.SLIP_DT, 1, 6)		AS	CLS_YM,
        										v31.ACC_ACT_CD					AS	ACC_ACT_CD,
												CASE
													WHEN	NVL(v32.ACT_TP, '00')	=	'10'	OR
															NVL(v32.ACT_TP, '00')	=	'20'	THEN	NVL(v31.CUST_CD, '0000000000')
													ELSE	'0000000000'
												END								AS	CUST_CD,
        										0                               AS	PM_DR_ACCM_AMT,		/* 차변누적금액 */
        										0                               AS	PM_CR_ACCM_AMT,		/* 대변누적금액 */
												DECODE(v31.DR_CR_TP, '1',
													NVL(v31.SLIP_AMT, 0), 0)	AS	TM_DR_AMT,		    /* 차변금액 */
												DECODE(v31.DR_CR_TP, '2',
													NVL(v31.SLIP_AMT, 0), 0)	AS	TM_CR_AMT		    /* 대변금액 */
        								  FROM	VN.GGA06M00	v31,		/* 회계전표 */
												VN.GGA02C00	v32
        								 WHERE	v31.SLIP_DT		>=	SUBSTR(I_YYMM, 1, 6) || '01'
        								   AND	v31.SLIP_DT		<=	TO_CHAR(LAST_DAY(TO_DATE(SUBSTR(I_YYMM, 1, 6) || '01', 'YYYYMMDD')), 'YYYYMMDD')
        								   AND	v31.BRCH_CD		=	DECODE(I_BRCH_CD, K_ALL_BRCH, v31.BRCH_CD, I_BRCH_CD)
        								   AND	v31.AGNC_BRCH	=	I_AGNC_BRCH
        								   AND	v31.SLIP_STAT	=	'2'		/* 승인상태 */
        								   AND	v31.ACC_ACT_CD	=	v32.ACC_ACT_CD(+)
        							)			v21
        				)			v11
        	  GROUP BY	v11.CLS_YM,
        				v11.ACC_ACT_CD,
        				v11.CUST_CD
            ) LOOP


            -- U_8. 회계거래처월계 자료생성
			BEGIN
                INSERT
                  INTO  VN.GGA14M00(
                        TERMS,
                        CLS_YM,
                        BRCH_CD,
                        AGNC_BRCH,
                        ACC_ACT_CD,
                        CUST_CD,
                        PM_DR_ACCM_AMT,
                        PM_CR_ACCM_AMT,
                        TM_DR_AMT,
                        TM_CR_AMT,
                        WORK_MN,
                        WORK_DTM,
                        WORK_TRM )
                VALUES  (T_TERMS,
                        C11.CLS_YM,
                        I_BRCH_CD,
                        I_AGNC_BRCH,
                        C11.ACC_ACT_CD,
                        C11.CUST_CD,
                        C11.PM_DR_ACCM_AMT,
                        C11.PM_CR_ACCM_AMT,
                        C11.TM_DR_AMT,
                        C11.TM_CR_AMT,
                        I_WORK_MN,
                        SYSDATE,
                        I_WORK_TRM );
		    EXCEPTION WHEN OTHERS THEN
		        RAISE ERR_GGA14M00_INS;
		    END;
            --END IF;

        END LOOP;   -- C11 End Loop

        -- U_8_2. 고정자산월마감처리
        IF  I_BRCH_CD   =   K_ALL_BRCH  THEN

	        FOR C12 IN
	        	(	SELECT	v11.DEPR_YM					        AS	DEPR_YM,
	        				v11.AST_NO					    	AS	AST_NO,
							MAX(v11.BRCH_CD)					AS	BRCH_CD,
							MAX(v11.AGNC_BRCH)					AS	AGNC_BRCH,
							MAX(v11.DEPT_CD)					AS	DEPT_CD,
							NVL(SUM(v11.GET_AMT), 0)			AS	GET_AMT,
							NVL(SUM(v11.EXPN_AMT), 0)			AS	EXPN_AMT,
							NVL(SUM(v11.MVIN_AMT), 0)			AS	MVIN_AMT,
							NVL(SUM(v11.EXCHIN_AMT), 0)			AS	EXCHIN_AMT,
							NVL(SUM(v11.DISP_AMT), 0)			AS	DISP_AMT,
							NVL(SUM(v11.DISU_AMT), 0)			AS	DISU_AMT,
							NVL(SUM(v11.MVOUT_AMT), 0)			AS	MVOUT_AMT,
							NVL(SUM(v11.EXCJOUT_AMT), 0)		AS	EXCJOUT_AMT,
							NVL(SUM(v11.DEPR_AMT), 0)			AS	DEPR_AMT,
							NVL(SUM(v11.BASE_AMT), 0)			AS	BASE_AMT,
							NVL(SUM(v11.PM_GET_AMT), 0)			AS	PM_GET_AMT,
				            NVL(SUM(v11.PM_EXPN_AMT), 0)		AS	PM_EXPN_AMT,
				            NVL(SUM(v11.PM_MVIN_AMT), 0)		AS	PM_MVIN_AMT,
				            NVL(SUM(v11.PM_EXCHIN_AMT), 0)		AS	PM_EXCHIN_AMT,
				            NVL(SUM(v11.PM_DISP_AMT), 0)		AS	PM_DISP_AMT,
				            NVL(SUM(v11.PM_DISU_AMT), 0)		AS	PM_DISU_AMT,
				            NVL(SUM(v11.PM_MVOUT_AMT), 0)		AS	PM_MVOUT_AMT,
				            NVL(SUM(v11.PM_EXCJOUT_AMT), 0)		AS	PM_EXCJOUT_AMT,
				            NVL(SUM(v11.PM_DEPR_AMT), 0)		AS	PM_DEPR_AMT,
							NVL(SUM(v11.INI_GET_AMT), 0)		AS	INI_GET_AMT,
							NVL(SUM(v11.DEPR_CUM), 0)		    AS	DEPR_CUM,
							NVL(SUM(v11.BASE_AMT), 0) +
								( ( NVL(SUM(v11.GET_AMT), 0) + NVL(SUM(v11.PM_GET_AMT), 0) ) +
								( NVL(SUM(v11.EXPN_AMT), 0) + NVL(SUM(v11.PM_EXPN_AMT), 0) ) +
								( NVL(SUM(v11.MVIN_AMT), 0) + NVL(SUM(v11.PM_MVIN_AMT), 0) ) +
								( NVL(SUM(v11.EXCHIN_AMT), 0) + NVL(SUM(v11.PM_EXCHIN_AMT), 0) ) ) -
								( ( NVL(SUM(v11.DISP_AMT), 0) + NVL(SUM(v11.PM_DISP_AMT), 0) ) +
								( NVL(SUM(v11.DISU_AMT), 0) + NVL(SUM(v11.PM_DISU_AMT), 0) ) +
								( NVL(SUM(v11.MVOUT_AMT), 0) + NVL(SUM(v11.PM_MVOUT_AMT), 0) ) +
								( NVL(SUM(v11.EXCJOUT_AMT), 0) + NVL(SUM(v11.PM_EXCJOUT_AMT), 0) ) +
								( NVL(SUM(v11.DEPR_AMT), 0) + NVL(SUM(v11.PM_DEPR_AMT), 0) ) )		AS	NDEPR_REMN
	        		  FROM
	        					/* 전월까지 누적금액 누계 */
	        				(	SELECT	v21.DEPR_YM						AS	DEPR_YM,
	        							v21.AST_NO						AS	AST_NO,
										v21.BRCH_CD						AS	BRCH_CD,
										v21.AGNC_BRCH					AS	AGNC_BRCH,
										v21.DEPT_CD						AS	DEPT_CD,
	        							0								AS	GET_AMT,
							            0								AS	EXPN_AMT,
							            0								AS	MVIN_AMT,
							            0								AS	EXCHIN_AMT,
							            0								AS	DISP_AMT,
							            0								AS	DISU_AMT,
							            0								AS	MVOUT_AMT,
							            0								AS	EXCJOUT_AMT,
							            0								AS	DEPR_AMT,
	        							NVL(v21.BASE_AMT, 0)			AS	BASE_AMT,
	        							NVL(v21.PM_GET_AMT, 0)			AS	PM_GET_AMT,
							            NVL(v21.PM_EXPN_AMT, 0)			AS	PM_EXPN_AMT,
							            NVL(v21.PM_MVIN_AMT, 0)			AS	PM_MVIN_AMT,
							            NVL(v21.PM_EXCHIN_AMT, 0)		AS	PM_EXCHIN_AMT,
							            NVL(v21.PM_DISP_AMT, 0)			AS	PM_DISP_AMT,
							            NVL(v21.PM_DISU_AMT, 0)			AS	PM_DISU_AMT,
							            NVL(v21.PM_MVOUT_AMT, 0)		AS	PM_MVOUT_AMT,
							            NVL(v21.PM_EXCJOUT_AMT, 0)		AS	PM_EXCJOUT_AMT,
							            NVL(v21.PM_DEPR_AMT, 0)			AS	PM_DEPR_AMT,
							            NVL(v21.INI_GET_AMT, 0)			AS	INI_GET_AMT,
										NVL(v21.DEPR_CUM, 0)		    AS	DEPR_CUM		/* 상각누계액 */
	        					  FROM
	        								/* 전기이월 집계 */
	        							(	SELECT	SUBSTR(I_YYMM, 1, 6)				AS	DEPR_YM,
	        							            v31.AST_NO					    	AS	AST_NO,
													v31.BRCH_CD							AS	BRCH_CD,
													v31.AGNC_BRCH						AS	AGNC_BRCH,
													v31.DEPT_CD							AS	DEPT_CD,
	        							            NVL(v31.BASE_AMT, 0)		    	AS	BASE_AMT,		/* 기초금액 */
	        							            0									AS	PM_GET_AMT,
	        							            0									AS	PM_EXPN_AMT,
	        							            0									AS	PM_MVIN_AMT,
	        							            0									AS	PM_EXCHIN_AMT,
	        							            0									AS	PM_DISP_AMT,
	        							            0									AS	PM_DISU_AMT,
	        							            0									AS	PM_MVOUT_AMT,
	        							            0									AS	PM_EXCJOUT_AMT,
	        							            0									AS	PM_DEPR_AMT,
	        							            NVL(v31.INI_GET_AMT, 0)		    	AS	INI_GET_AMT,
	        										NVL(v31.DEPR_CUM, 0)		    	AS	DEPR_CUM		/* 상각누계액 */
	        								  FROM	VN.GGA25T00	v31	/* 고정자산집계 */
	        								 WHERE	v31.TERMS		=	T_TERMS
	        								   AND	v31.DEPR_YM		=	SUBSTR(I_YYMM, 1, 4) || '00'
	        								   AND	v31.BRCH_CD		=	DECODE(I_BRCH_CD, K_ALL_BRCH, v31.BRCH_CD, I_BRCH_CD)
	        								   AND	v31.AGNC_BRCH	=	I_AGNC_BRCH
	                                    UNION ALL
	        								/* 전월까지발생금액 집계 */
	        								SELECT	SUBSTR(I_YYMM, 1, 6)				AS	DEPR_YM,
	        							            v31.AST_NO					    	AS	AST_NO,
													v31.BRCH_CD							AS	BRCH_CD,
													v31.AGNC_BRCH						AS	AGNC_BRCH,
													v31.DEPT_CD							AS	DEPT_CD,
	        							            0									AS	BASE_AMT,		/* 기초금액 */
	        							            NVL(v31.GET_AMT, 0)		    		AS	PM_GET_AMT,
	        							            NVL(v31.EXPN_AMT, 0)	    		AS	PM_EXPN_AMT,
	        							            NVL(v31.MVIN_AMT, 0)	    		AS	PM_MVIN_AMT,
	        							            NVL(v31.EXCHIN_AMT, 0)	    		AS	PM_EXCHIN_AMT,
	        							            NVL(v31.DISP_AMT, 0)	    		AS	PM_DISP_AMT,
	        							            NVL(v31.DISU_AMT, 0)	    		AS	PM_DISU_AMT,
	        							            NVL(v31.MVOUT_AMT, 0)	    		AS	PM_MVOUT_AMT,
	        							            NVL(v31.EXCJOUT_AMT, 0)	    		AS	PM_EXCJOUT_AMT,
	        							            NVL(v31.DEPR_AMT, 0)	    		AS	PM_DEPR_AMT,
	        										0									AS	INI_GET_AMT,
	        							            0									AS	DEPR_CUM		/* 상각누계액 */
	        								  FROM	VN.GGA25T00	v31	/* 고정자산집계 */
	        								 WHERE	v31.TERMS		=	T_TERMS
	                    					   AND	v31.DEPR_YM		>=	SUBSTR(T_OPN_DT, 1, 6)
	                    					   AND	v31.DEPR_YM		<	SUBSTR(I_YYMM, 1, 6)
	        								   AND	v31.BRCH_CD		=	DECODE(I_BRCH_CD, K_ALL_BRCH, v31.BRCH_CD, I_BRCH_CD)
	        								   AND	v31.AGNC_BRCH	=	I_AGNC_BRCH
	        							)			v21
	        				UNION ALL
	       						/* 당월발생금액 집계 */
								SELECT	v21.DEPR_YM							AS	DEPR_YM,
	        							v21.AST_NO							AS	AST_NO,
										MAX(v21.BRCH_CD)					AS	BRCH_CD,
										MAX(v21.AGNC_BRCH)					AS	AGNC_BRCH,
										MAX(v21.DEPT_CD)					AS	DEPT_CD,
										NVL(SUM(v21.GET_AMT), 0)			AS	GET_AMT,
										NVL(SUM(v21.EXPN_AMT), 0)			AS	EXPN_AMT,
										NVL(SUM(v21.MVIN_AMT), 0)			AS	MVIN_AMT,
										NVL(SUM(v21.EXCHIN_AMT), 0)			AS	EXCHIN_AMT,
										NVL(SUM(v21.DISP_AMT), 0)			AS	DISP_AMT,
										NVL(SUM(v21.DISU_AMT), 0)			AS	DISU_AMT,
										NVL(SUM(v21.MVOUT_AMT), 0)			AS	MVOUT_AMT,
										NVL(SUM(v21.EXCJOUT_AMT), 0)		AS	EXCJOUT_AMT,
										NVL(SUM(v21.DEPR_AMT), 0)			AS	DEPR_AMT,
	        							0									AS	BASE_AMT,
	        							0									AS	PM_GET_AMT,
							            0									AS	PM_EXPN_AMT,
							            0									AS	PM_MVIN_AMT,
							            0									AS	PM_EXCHIN_AMT,
							            0									AS	PM_DISP_AMT,
							            0									AS	PM_DISU_AMT,
							            0									AS	PM_MVOUT_AMT,
							            0									AS	PM_EXCJOUT_AMT,
							            0									AS	PM_DEPR_AMT,
							            NVL(SUM(v21.GET_AMT), 0)			AS	INI_GET_AMT,
										0									AS	DEPR_CUM		/* 상각누계액 */
								  FROM
											/* 당월취득 */
										(	SELECT	SUBSTR(I_YYMM, 1, 6)		AS	DEPR_YM,
	        							            v31.AST_NO					AS	AST_NO,
													MAX(v31.BRCH_CD)			AS	BRCH_CD,
													MAX(v31.AGNC_BRCH)			AS	AGNC_BRCH,
													MAX(v31.DEPT_CD)			AS	DEPT_CD,
													NVL(SUM(v31.VOLA_AMT), 0)	AS	GET_AMT,
													0							AS	EXPN_AMT,
													0							AS	MVIN_AMT,
													0							AS	EXCHIN_AMT,
													0							AS	DISP_AMT,
													0							AS	DISU_AMT,
													0							AS	MVOUT_AMT,
													0							AS	EXCJOUT_AMT,
													0							AS	DEPR_AMT,
													0							AS	PM_DEPR_AMT
											  FROM	VN.GGA22M01	v31
	        								 WHERE	v31.CHG_DT		>=	SUBSTR(I_YYMM, 1, 6) || '01'
	        								   AND	v31.CHG_DT		<=	TO_CHAR(LAST_DAY(TO_DATE(SUBSTR(I_YYMM, 1, 6) || '01', 'YYYYMMDD')), 'YYYYMMDD')
	        								   AND	v31.BRCH_CD		=	DECODE(I_BRCH_CD, K_ALL_BRCH, v31.BRCH_CD, I_BRCH_CD)
	        								   AND	v31.AGNC_BRCH	=	I_AGNC_BRCH
											   AND	v31.CHG_STAT	=	'A'
										  GROUP BY	v31.AST_NO
										UNION ALL
											/* 당월자본적지출 */
											SELECT	SUBSTR(I_YYMM, 1, 6)		AS	DEPR_YM,
	        							            v31.AST_NO					AS	AST_NO,
													MAX(v31.BRCH_CD)			AS	BRCH_CD,
													MAX(v31.AGNC_BRCH)			AS	AGNC_BRCH,
													MAX(v31.DEPT_CD)			AS	DEPT_CD,
													0							AS	GET_AMT,
													NVL(SUM(v31.VOLA_AMT), 0)	AS	EXPN_AMT,
													0							AS	MVIN_AMT,
													0							AS	EXCHIN_AMT,
													0							AS	DISP_AMT,
													0							AS	DISU_AMT,
													0							AS	MVOUT_AMT,
													0							AS	EXCJOUT_AMT,
													0							AS	DEPR_AMT,
													0							AS	PM_DEPR_AMT
											  FROM	VN.GGA22M01	v31
	        								 WHERE	v31.CHG_DT		>=	SUBSTR(I_YYMM, 1, 6) || '01'
	        								   AND	v31.CHG_DT		<=	TO_CHAR(LAST_DAY(TO_DATE(SUBSTR(I_YYMM, 1, 6) || '01', 'YYYYMMDD')), 'YYYYMMDD')
	        								   AND	v31.BRCH_CD		=	DECODE(I_BRCH_CD, K_ALL_BRCH, v31.BRCH_CD, I_BRCH_CD)
	        								   AND	v31.AGNC_BRCH	=	I_AGNC_BRCH
											   AND	v31.CHG_STAT	=	'B'
										  GROUP BY	v31.AST_NO
										UNION ALL
											/* 당월자산수관 */
											SELECT	SUBSTR(I_YYMM, 1, 6)		AS	DEPR_YM,
	        							            v31.AST_NO					AS	AST_NO,
													MAX(v31.BRCH_CD)			AS	BRCH_CD,
													MAX(v31.AGNC_BRCH)			AS	AGNC_BRCH,
													MAX(v31.DEPT_CD)			AS	DEPT_CD,
													0							AS	GET_AMT,
													0							AS	EXPN_AMT,
													NVL(SUM(v31.VOLA_AMT), 0)	AS	MVIN_AMT,
													0							AS	EXCHIN_AMT,
													0							AS	DISP_AMT,
													0							AS	DISU_AMT,
													0							AS	MVOUT_AMT,
													0							AS	EXCJOUT_AMT,
													0							AS	DEPR_AMT,
													0							AS	PM_DEPR_AMT
											  FROM	VN.GGA22M01	v31
	        								 WHERE	v31.CHG_DT		>=	SUBSTR(I_YYMM, 1, 6) || '01'
	        								   AND	v31.CHG_DT		<=	TO_CHAR(LAST_DAY(TO_DATE(SUBSTR(I_YYMM, 1, 6) || '01', 'YYYYMMDD')), 'YYYYMMDD')
	        								   AND	v31.BRCH_CD		=	DECODE(I_BRCH_CD, K_ALL_BRCH, v31.BRCH_CD, I_BRCH_CD)
	        								   AND	v31.AGNC_BRCH	=	I_AGNC_BRCH
											   AND	v31.CHG_STAT	=	'E'
										  GROUP BY	v31.AST_NO
										UNION ALL
											/* 당월자산저장품대체입 */
											SELECT	SUBSTR(I_YYMM, 1, 6)		AS	DEPR_YM,
	        							            v31.AST_NO					AS	AST_NO,
													MAX(v31.BRCH_CD)			AS	BRCH_CD,
													MAX(v31.AGNC_BRCH)			AS	AGNC_BRCH,
													MAX(v31.DEPT_CD)			AS	DEPT_CD,
													0							AS	GET_AMT,
													0							AS	EXPN_AMT,
													0							AS	MVIN_AMT,
													NVL(SUM(v31.VOLA_AMT), 0)	AS	EXCHIN_AMT,
													0							AS	DISP_AMT,
													0							AS	DISU_AMT,
													0							AS	MVOUT_AMT,
													0							AS	EXCJOUT_AMT,
													0							AS	DEPR_AMT,
													0							AS	PM_DEPR_AMT
											  FROM	VN.GGA22M01	v31
	        								 WHERE	v31.CHG_DT		>=	SUBSTR(I_YYMM, 1, 6) || '01'
	        								   AND	v31.CHG_DT		<=	TO_CHAR(LAST_DAY(TO_DATE(SUBSTR(I_YYMM, 1, 6) || '01', 'YYYYMMDD')), 'YYYYMMDD')
	        								   AND	v31.BRCH_CD		=	DECODE(I_BRCH_CD, K_ALL_BRCH, v31.BRCH_CD, I_BRCH_CD)
	        								   AND	v31.AGNC_BRCH	=	I_AGNC_BRCH
											   AND	v31.CHG_STAT	=	'F'
										  GROUP BY	v31.AST_NO
										UNION ALL
											/* 당월자산매각 */
											SELECT	SUBSTR(I_YYMM, 1, 6)		AS	DEPR_YM,
	        							            v31.AST_NO					AS	AST_NO,
													MAX(v31.BRCH_CD)			AS	BRCH_CD,
													MAX(v31.AGNC_BRCH)			AS	AGNC_BRCH,
													MAX(v31.DEPT_CD)			AS	DEPT_CD,
													0							AS	GET_AMT,
													0							AS	EXPN_AMT,
													0							AS	MVIN_AMT,
													0							AS	EXCHIN_AMT,
													NVL(SUM(v31.VOLA_AMT), 0)	AS	DISP_AMT,
													0							AS	DISU_AMT,
													0							AS	MVOUT_AMT,
													0							AS	EXCJOUT_AMT,
													0							AS	DEPR_AMT,
													0							AS	PM_DEPR_AMT
											  FROM	VN.GGA22M01	v31
	        								 WHERE	v31.CHG_DT		>=	SUBSTR(I_YYMM, 1, 6) || '01'
	        								   AND	v31.CHG_DT		<=	TO_CHAR(LAST_DAY(TO_DATE(SUBSTR(I_YYMM, 1, 6) || '01', 'YYYYMMDD')), 'YYYYMMDD')
	        								   AND	v31.BRCH_CD		=	DECODE(I_BRCH_CD, K_ALL_BRCH, v31.BRCH_CD, I_BRCH_CD)
	        								   AND	v31.AGNC_BRCH	=	I_AGNC_BRCH
											   AND	v31.CHG_STAT	=	'J'
										  GROUP BY	v31.AST_NO
										UNION ALL
											/* 당월자산폐기 */
											SELECT	SUBSTR(I_YYMM, 1, 6)		AS	DEPR_YM,
	        							            v31.AST_NO					AS	AST_NO,
													MAX(v31.BRCH_CD)			AS	BRCH_CD,
													MAX(v31.AGNC_BRCH)			AS	AGNC_BRCH,
													MAX(v31.DEPT_CD)			AS	DEPT_CD,
													0							AS	GET_AMT,
													0							AS	EXPN_AMT,
													0							AS	MVIN_AMT,
													0							AS	EXCHIN_AMT,
													0							AS	DISP_AMT,
													NVL(SUM(v31.VOLA_AMT), 0)	AS	DISU_AMT,
													0							AS	MVOUT_AMT,
													0							AS	EXCJOUT_AMT,
													0							AS	DEPR_AMT,
													0							AS	PM_DEPR_AMT
											  FROM	VN.GGA22M01	v31
	        								 WHERE	v31.CHG_DT		>=	SUBSTR(I_YYMM, 1, 6) || '01'
	        								   AND	v31.CHG_DT		<=	TO_CHAR(LAST_DAY(TO_DATE(SUBSTR(I_YYMM, 1, 6) || '01', 'YYYYMMDD')), 'YYYYMMDD')
	        								   AND	v31.BRCH_CD		=	DECODE(I_BRCH_CD, K_ALL_BRCH, v31.BRCH_CD, I_BRCH_CD)
	        								   AND	v31.AGNC_BRCH	=	I_AGNC_BRCH
											   AND	v31.CHG_STAT	=	'K'
										  GROUP BY	v31.AST_NO
										UNION ALL
											/* 당월자산이관 */
											SELECT	SUBSTR(I_YYMM, 1, 6)		AS	DEPR_YM,
	        							            v31.AST_NO					AS	AST_NO,
													MAX(v31.BRCH_CD)			AS	BRCH_CD,
													MAX(v31.AGNC_BRCH)			AS	AGNC_BRCH,
													MAX(v31.DEPT_CD)			AS	DEPT_CD,
													0							AS	GET_AMT,
													0							AS	EXPN_AMT,
													0							AS	MVIN_AMT,
													0							AS	EXCHIN_AMT,
													0							AS	DISP_AMT,
													0							AS	DISU_AMT,
													NVL(SUM(v31.VOLA_AMT), 0)	AS	MVOUT_AMT,
													0							AS	EXCJOUT_AMT,
													0							AS	DEPR_AMT,
													0							AS	PM_DEPR_AMT
											  FROM	VN.GGA22M01	v31
	        								 WHERE	v31.CHG_DT		>=	SUBSTR(I_YYMM, 1, 6) || '01'
	        								   AND	v31.CHG_DT		<=	TO_CHAR(LAST_DAY(TO_DATE(SUBSTR(I_YYMM, 1, 6) || '01', 'YYYYMMDD')), 'YYYYMMDD')
	        								   AND	v31.BRCH_CD		=	DECODE(I_BRCH_CD, K_ALL_BRCH, v31.BRCH_CD, I_BRCH_CD)
	        								   AND	v31.AGNC_BRCH	=	I_AGNC_BRCH
											   AND	v31.CHG_STAT	=	'D'
										  GROUP BY	v31.AST_NO
										UNION ALL
											/* 당월자산저장품체출 */
											SELECT	SUBSTR(I_YYMM, 1, 6)		AS	DEPR_YM,
	        							            v31.AST_NO					AS	AST_NO,
													MAX(v31.BRCH_CD)			AS	BRCH_CD,
													MAX(v31.AGNC_BRCH)			AS	AGNC_BRCH,
													MAX(v31.DEPT_CD)			AS	DEPT_CD,
													0							AS	GET_AMT,
													0							AS	EXPN_AMT,
													0							AS	MVIN_AMT,
													0							AS	EXCHIN_AMT,
													0							AS	DISP_AMT,
													0							AS	DISU_AMT,
													0							AS	MVOUT_AMT,
													NVL(SUM(v31.VOLA_AMT), 0)	AS	EXCJOUT_AMT,
													0							AS	DEPR_AMT,
													0							AS	PM_DEPR_AMT
											  FROM	VN.GGA22M01	v31
	        								 WHERE	v31.CHG_DT		>=	SUBSTR(I_YYMM, 1, 6) || '01'
	        								   AND	v31.CHG_DT		<=	TO_CHAR(LAST_DAY(TO_DATE(SUBSTR(I_YYMM, 1, 6) || '01', 'YYYYMMDD')), 'YYYYMMDD')
	        								   AND	v31.BRCH_CD		=	DECODE(I_BRCH_CD, K_ALL_BRCH, v31.BRCH_CD, I_BRCH_CD)
	        								   AND	v31.AGNC_BRCH	=	I_AGNC_BRCH
											   AND	v31.CHG_STAT	=	'G'
										  GROUP BY	v31.AST_NO
										UNION ALL
											/* 당월상각금액 */
											SELECT	SUBSTR(I_YYMM, 1, 6)		AS	DEPR_YM,
	        							            v31.AST_NO					AS	AST_NO,
													MAX(v31.BRCH_CD)			AS	BRCH_CD,
													MAX(v31.AGNC_BRCH)			AS	AGNC_BRCH,
													MAX(v31.DEPT_CD)			AS	DEPT_CD,
													0							AS	GET_AMT,
													0							AS	EXPN_AMT,
													0							AS	MVIN_AMT,
													0							AS	EXCHIN_AMT,
													0							AS	DISP_AMT,
													0							AS	DISU_AMT,
													0							AS	MVOUT_AMT,
													0							AS	EXCJOUT_AMT,
													NVL(SUM(v31.ALWC_AMT), 0)	AS	DEPR_AMT,
													0							AS	PM_DEPR_AMT
											  FROM	VN.GGA22M01	v31
	        								 WHERE	v31.CHG_DT		>=	SUBSTR(I_YYMM, 1, 6) || '01'
	        								   AND	v31.CHG_DT		<=	TO_CHAR(LAST_DAY(TO_DATE(SUBSTR(I_YYMM, 1, 6) || '01', 'YYYYMMDD')), 'YYYYMMDD')
	        								   AND	v31.BRCH_CD		=	DECODE(I_BRCH_CD, K_ALL_BRCH, v31.BRCH_CD, I_BRCH_CD)
	        								   AND	v31.AGNC_BRCH	=	I_AGNC_BRCH
											   AND	v31.CHG_STAT	=	'C'
										  GROUP BY	v31.AST_NO
										)			v21
							  GROUP BY	v21.DEPR_YM,
										v21.AST_NO
	        				)			v11
	        	  GROUP BY	v11.DEPR_YM,
	        				v11.AST_NO
	            ) LOOP

	            -- U_8. 고정자산월 자료생성
	            --IF  C1.PM_DR_ACCM_AMT   =   0   AND C1.PM_CR_ACCM_AMT   =   0   AND
	            --    C1.TM_DR_AMT        =   0   AND C1.TM_CR_AMT        =   0   THEN    -- 0인경우 제외
				BEGIN
			        INSERT
			          INTO  VN.GGA25T00(
			          		TERMS,
							DEPR_YM,
							AST_NO,
							BRCH_CD,
							AGNC_BRCH,
							DEPT_CD,
							GET_AMT,
							EXPN_AMT,
							MVIN_AMT,
							EXCHIN_AMT,
							DISP_AMT,
							DISU_AMT,
							MVOUT_AMT,
							EXCJOUT_AMT,
							DEPR_AMT,
							BASE_AMT,
							PM_GET_AMT,
							PM_EXPN_AMT,
							PM_MVIN_AMT,
							PM_EXCHIN_AMT,
							PM_DISP_AMT,
							PM_DISU_AMT,
							PM_MVOUT_AMT,
							PM_EXCJOUT_AMT,
							PM_DEPR_AMT,
							INI_GET_AMT,
							DEPR_CUM,
							NDEPR_REMN,
							USE_YN,
							WORK_MN,
							WORK_DTM,
							WORK_TRM,
							MDFY_MN,
							MDFY_DTM,
							MDFY_TRM )
			       VALUES  (T_TERMS,
							C12.DEPR_YM,
							C12.AST_NO,
	                        C12.BRCH_CD,
	                        C12.AGNC_BRCH,
							C12.DEPT_CD,
	                        C12.GET_AMT,
							C12.EXPN_AMT,
							C12.MVIN_AMT,
							C12.EXCHIN_AMT,
							C12.DISP_AMT,
							C12.DISU_AMT,
							C12.MVOUT_AMT,
							C12.EXCJOUT_AMT,
							C12.DEPR_AMT,
							C12.BASE_AMT,
							C12.PM_GET_AMT,
							C12.PM_EXPN_AMT,
							C12.PM_MVIN_AMT,
							C12.PM_EXCHIN_AMT,
							C12.PM_DISP_AMT,
							C12.PM_DISU_AMT,
							C12.PM_MVOUT_AMT,
							C12.PM_EXCJOUT_AMT,
							C12.PM_DEPR_AMT,
							C12.INI_GET_AMT,
							C12.DEPR_CUM,
							C12.NDEPR_REMN,
							'Y',
							I_WORK_MN,
							SYSDATE,
							I_WORK_TRM,
							I_WORK_MN,
							SYSDATE,
							I_WORK_TRM );
			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA25T00_INS;
			    END;
	            --END IF;

	        END LOOP;   -- C12 End Loop

		END IF;


        IF  T_TERM_TP   =   '9'  THEN

            -- U_9. 전기이월 처리
            FOR C2 IN
            	(	SELECT	v11.CLS_YM					    AS	CLS_YM,
            				v11.ACC_ACT_CD					AS	ACC_ACT_CD,
            				v12.DR_CR_TP					AS	DR_CR_TP,
            				0								AS	PM_DR_ACCM_AMT,
            				0								AS	PM_CR_ACCM_AMT,
            				CASE
            					WHEN	v12.DR_CR_TP	=	'1'	THEN
            						NVL(v11.TM_DR_AMT, 0) - NVL(v11.TM_CR_AMT, 0)
            					ELSE	0
            				END								AS	TM_DR_AMT,
            				CASE
            					WHEN	v12.DR_CR_TP	=	'2'	THEN
            						NVL(v11.TM_CR_AMT, 0) - NVL(v11.TM_DR_AMT, 0)
            					ELSE	0
            				END								AS	TM_CR_AMT
            		  FROM
            				(	SELECT	v21.CLS_YM					        AS	CLS_YM,
            							v21.ACC_ACT_CD					    AS	ACC_ACT_CD,
            							NVL(SUM(v21.TM_DR_AMT), 0)		    AS	TM_DR_AMT,
            							NVL(SUM(v21.TM_CR_AMT), 0)		    AS	TM_CR_AMT
            					  FROM
            								/* 전기이월 집계 */
            							(	SELECT	SUBSTR(T_TERMS_NEX, 1, 6)           AS	CLS_YM,
            							            v31.ACC_ACT_CD					    AS	ACC_ACT_CD,
            							            NVL(v31.PM_DR_ACCM_AMT, 0) +
            											NVL(v31.TM_DR_AMT, 0)		    AS	TM_DR_AMT,          /* 차변금액 */
            										NVL(v31.PM_CR_ACCM_AMT, 0) +
            											NVL(v31.TM_CR_AMT, 0)		    AS	TM_CR_AMT           /* 대변금액 */
            								  FROM	VN.GGA09M00	v31	/* 회계월계 */
            								 WHERE	v31.TERMS		=	T_TERMS
            								   AND	v31.CLS_YM		=	SUBSTR(I_YYMM, 1, 6)
            								   AND	v31.BRCH_CD		=	I_BRCH_CD
            								   AND	v31.AGNC_BRCH	=	I_AGNC_BRCH
            							)			v21
            				  GROUP BY	v21.CLS_YM,
            							v21.ACC_ACT_CD
            				)			v11,
            				VN.GGA02C00	v12
            		 WHERE	v11.ACC_ACT_CD	=	v12.ACC_ACT_CD
                  ORDER BY  v11.CLS_YM,
                            v11.ACC_ACT_CD
                ) LOOP

                -- U_9. 회계월계 자료생성
                --IF  C2.TM_DR_AMT        =   0   AND C2.TM_CR_AMT        =   0   THEN    -- 0인경우 제외
                BEGIN
                    INSERT
                      INTO  VN.GGA09M00(
                            TERMS,
                            CLS_YM,
                            BRCH_CD,
                            AGNC_BRCH,
                            ACC_ACT_CD,
                            PM_DR_ACCM_AMT,
                            PM_CR_ACCM_AMT,
                            TM_DR_AMT,
                            TM_CR_AMT,
                            WORK_MN,
                            WORK_DTM,
                            WORK_TRM )
                    VALUES  (T_TERMS + 1,
                            C2.CLS_YM,
                            I_BRCH_CD,
                            I_AGNC_BRCH,
                            C2.ACC_ACT_CD,
                            C2.PM_DR_ACCM_AMT,
                            C2.PM_CR_ACCM_AMT,
                            C2.TM_DR_AMT,
                            C2.TM_CR_AMT,
                            I_WORK_MN,
                            SYSDATE,
                            I_WORK_TRM );
                EXCEPTION WHEN OTHERS THEN
                    RAISE ERR_GGA09M00_INS_1;
                END;
                --END IF;

            END LOOP;   -- C2 End Loop


            -- U_9. 전기이월(거래처) 처리
            FOR C21 IN
            	(	SELECT	v11.CLS_YM					    AS	CLS_YM,
            				v11.ACC_ACT_CD					AS	ACC_ACT_CD,
            				v11.CUST_CD						AS	CUST_CD,
            				v12.DR_CR_TP					AS	DR_CR_TP,
            				0								AS	PM_DR_ACCM_AMT,
            				0								AS	PM_CR_ACCM_AMT,
            				CASE
            					WHEN	v12.DR_CR_TP	=	'1'	THEN
            						NVL(v11.TM_DR_AMT, 0) - NVL(v11.TM_CR_AMT, 0)
            					ELSE	0
            				END								AS	TM_DR_AMT,
            				CASE
            					WHEN	v12.DR_CR_TP	=	'2'	THEN
            						NVL(v11.TM_CR_AMT, 0) - NVL(v11.TM_DR_AMT, 0)
            					ELSE	0
            				END								AS	TM_CR_AMT
            		  FROM
            				(	SELECT	v21.CLS_YM					        AS	CLS_YM,
            							v21.ACC_ACT_CD					    AS	ACC_ACT_CD,
										v21.CUST_CD							AS	CUST_CD,
            							NVL(SUM(v21.TM_DR_AMT), 0)		    AS	TM_DR_AMT,
            							NVL(SUM(v21.TM_CR_AMT), 0)		    AS	TM_CR_AMT
            					  FROM
            								/* 전기이월 집계 */
            							(	SELECT	SUBSTR(T_TERMS_NEX, 1, 6)           AS	CLS_YM,
            							            v31.ACC_ACT_CD					    AS	ACC_ACT_CD,
													CASE
														WHEN	NVL(v32.ACT_TP, '00')	=	'10'	OR
																NVL(v32.ACT_TP, '00')	=	'20'	THEN	NVL(v31.CUST_CD, '0000000000')
														ELSE	'0000000000'
													END									AS	CUST_CD,
            							            NVL(v31.PM_DR_ACCM_AMT, 0) +
            											NVL(v31.TM_DR_AMT, 0)		    AS	TM_DR_AMT,          /* 차변금액 */
            										NVL(v31.PM_CR_ACCM_AMT, 0) +
            											NVL(v31.TM_CR_AMT, 0)		    AS	TM_CR_AMT           /* 대변금액 */
            								  FROM	VN.GGA14M00	v31,		/* 회계거래처월계 */
													VN.GGA02C00	v32
            								 WHERE	v31.TERMS		=	T_TERMS
            								   AND	v31.CLS_YM		=	SUBSTR(I_YYMM, 1, 6)
            								   AND	v31.BRCH_CD		=	I_BRCH_CD
            								   AND	v31.AGNC_BRCH	=	I_AGNC_BRCH
        									   AND	v31.ACC_ACT_CD	=	v32.ACC_ACT_CD(+)
            							)			v21
            				  GROUP BY	v21.CLS_YM,
            							v21.ACC_ACT_CD,
            							v21.CUST_CD
            				)			v11,
            				VN.GGA02C00	v12
            		 WHERE	v11.ACC_ACT_CD	=	v12.ACC_ACT_CD
                  ORDER BY  v11.CLS_YM,
                            v11.ACC_ACT_CD,
                            v11.CUST_CD
                ) LOOP

                -- U_9. 회계거래처월계 자료생성
                BEGIN
                    INSERT
                      INTO  VN.GGA14M00(
                            TERMS,
                            CLS_YM,
                            BRCH_CD,
                            AGNC_BRCH,
                            ACC_ACT_CD,
                            CUST_CD,
                            PM_DR_ACCM_AMT,
                            PM_CR_ACCM_AMT,
                            TM_DR_AMT,
                            TM_CR_AMT,
                            WORK_MN,
                            WORK_DTM,
                            WORK_TRM )
                    VALUES  (T_TERMS + 1,
                            C21.CLS_YM,
                            I_BRCH_CD,
                            I_AGNC_BRCH,
                            C21.ACC_ACT_CD,
                            C21.CUST_CD,
                            C21.PM_DR_ACCM_AMT,
                            C21.PM_CR_ACCM_AMT,
                            C21.TM_DR_AMT,
                            C21.TM_CR_AMT,
                            I_WORK_MN,
                            SYSDATE,
                            I_WORK_TRM );
                EXCEPTION WHEN OTHERS THEN
                    RAISE ERR_GGA14M00_INS_1;
                END;

            END LOOP;   -- C21 End Loop

            -- U_9. 전기이월 처리
        	IF  I_BRCH_CD   =   K_ALL_BRCH  THEN

	            FOR C22 IN
					(	SELECT	v11.DEPR_YM					    AS	DEPR_YM,
								v11.AST_NO					    AS	AST_NO,
								v11.BRCH_CD						AS	BRCH_CD,
								v11.AGNC_BRCH					AS	AGNC_BRCH,
								v11.DEPT_CD						AS	DEPT_CD,
								NVL(v11.BASE_AMT, 0)		    AS	BASE_AMT,
								NVL(v11.INI_GET_AMT, 0)			AS	INI_GET_AMT,
								NVL(v11.DEPR_CUM, 0)			AS	DEPR_CUM,
								NVL(v11.NDEPR_REMN, 0)			AS	NDEPR_REMN
						  FROM
									/* 전기이월 집계 */
								(	SELECT	SUBSTR(T_TERMS_NEX, 1, 6)			AS	DEPR_YM,
								            v21.AST_NO					    	AS	AST_NO,
											v21.BRCH_CD							AS	BRCH_CD,
											v21.AGNC_BRCH						AS	AGNC_BRCH,
											v21.DEPT_CD							AS	DEPT_CD,
								            NVL(v21.NDEPR_REMN, 0)		    	AS	BASE_AMT,		/* 기초금액 */
								            NVL(v21.INI_GET_AMT, 0)		    	AS	INI_GET_AMT,
											NVL(v21.DEPR_CUM, 0) +
												 NVL(v21.PM_DEPR_AMT, 0) +
												 NVL(v21.DEPR_AMT, 0)    		AS	DEPR_CUM,		/* 상각누계액 */
											NVL(v21.NDEPR_REMN, 0)		    	AS	NDEPR_REMN
									  FROM	VN.GGA25T00	v21	/* 고정자산집계 */
									 WHERE	v21.TERMS		=	T_TERMS
									   AND	v21.DEPR_YM		=	SUBSTR(I_YYMM, 1, 6)
									   AND	v21.BRCH_CD		=	DECODE(I_BRCH_CD, K_ALL_BRCH, v21.BRCH_CD, I_BRCH_CD)
									   AND	v21.AGNC_BRCH	=	I_AGNC_BRCH
								)			v11
					  ORDER BY	v11.DEPR_YM,
								v11.AST_NO,
								v11.BRCH_CD,
								v11.AGNC_BRCH,
								v11.DEPT_CD
	                ) LOOP

	                -- U_9. 전기이월 자료생성
	                BEGIN
				        INSERT
				          INTO  VN.GGA25T00(
				          		TERMS,
								DEPR_YM,
								AST_NO,
								BRCH_CD,
								AGNC_BRCH,
								DEPT_CD,
								GET_AMT,
								EXPN_AMT,
								MVIN_AMT,
								EXCHIN_AMT,
								DISP_AMT,
								DISU_AMT,
								MVOUT_AMT,
								EXCJOUT_AMT,
								DEPR_AMT,
								BASE_AMT,
								PM_GET_AMT,
								PM_EXPN_AMT,
								PM_MVIN_AMT,
								PM_EXCHIN_AMT,
								PM_DISP_AMT,
								PM_DISU_AMT,
								PM_MVOUT_AMT,
								PM_EXCJOUT_AMT,
								PM_DEPR_AMT,
								INI_GET_AMT,
								DEPR_CUM,
								NDEPR_REMN,
								USE_YN,
								WORK_MN,
								WORK_DTM,
								WORK_TRM,
								MDFY_MN,
								MDFY_DTM,
								MDFY_TRM )
				       VALUES  (T_TERMS + 1,
								C22.DEPR_YM,
								C22.AST_NO,
		                        C22.BRCH_CD,
		                        C22.AGNC_BRCH,
								C22.DEPT_CD,
		                        0,
								0,
								0,
								0,
								0,
								0,
								0,
								0,
								0,
								C22.BASE_AMT,
								0,
								0,
								0,
								0,
								0,
								0,
								0,
								0,
								0,
								C22.INI_GET_AMT,
								C22.DEPR_CUM,
								C22.NDEPR_REMN,
								'Y',
								I_WORK_MN,
								SYSDATE,
								I_WORK_TRM,
								I_WORK_MN,
								SYSDATE,
								I_WORK_TRM );
	                EXCEPTION WHEN OTHERS THEN
	                    RAISE ERR_GGA09M00_INS_1;
	                END;

	            END LOOP;   -- C22 End Loop

			END IF;

        END IF;


        -- U_10. 회계상대계정 집계 자료조회
        IF  I_BRCH_CD   !=   K_ALL_BRCH  THEN

		    O1_RTN_TBL		:=	NULL ;
			O1_RTN_ERR		:=	NULL ;
			O1_RTN_MSG		:=	NULL ;

			VN.PGG_ACC_MON_ACT(
				SUBSTR(I_YYMM, 1, 6) || '01',														-- 시작일자
				TO_CHAR(LAST_DAY(TO_DATE(SUBSTR(I_YYMM, 1, 6) || '01', 'YYYYMMDD')), 'YYYYMMDD'),	-- 종료일자
				I_BRCH_CD,
				I_AGNC_BRCH,
				I_WORK_MN,
				I_WORK_TRM,
			    O1_RTN_TBL,       	-- Return Table
				O1_RTN_ERR,       	-- Return Error Code
				O1_RTN_MSG) ;		-- Return Message

			IF	TO_NUMBER(O1_RTN_ERR)	<>	0	THEN

				vn.pxc_log_write('pgg_acc_mon_cls', ' [' || O1_RTN_ERR || '] [' || O1_RTN_TBL || '] [' || O1_RTN_MSG|| ']') ;

			END IF ;

        END IF;


    -- *********************
    -- * 회   계   취   소 *
    -- *********************
    ELSIF   I_FLAG  =   'D' THEN

        -- D_1. 회사전체 마감체크
        IF  I_BRCH_CD   !=   K_ALL_BRCH  THEN

            T_CNT   := 0 ;

    		SELECT	COUNT(*)
    		  INTO  T_CNT
    		  FROM	VN.GGA11M00
    		 WHERE	TERMS		=	T_TERMS
    		   AND	CLS_YM		=	SUBSTR(I_YYMM, 1, 6)
    		   AND	BRCH_CD		=   K_ALL_BRCH
    		   AND	AGNC_BRCH	=	'00'
        	   AND	NVL(ACC_CLS_YN, 'N')	=	'Y' ;

            IF  T_CNT   >=  1   THEN
                RAISE ERR_GGA11M00_4;
            END IF;

            IF  I_BRCH_CD   !=   K_BON_BRCH  THEN

                T_CNT   := 0 ;

        		SELECT	COUNT(*)
        		  INTO  T_CNT
        		  FROM	VN.GGA11M00
        		 WHERE	TERMS		=	T_TERMS
        		   AND	CLS_YM		=	SUBSTR(I_YYMM, 1, 6)
        		   AND	BRCH_CD		=   K_BON_BRCH
        		   AND	AGNC_BRCH	=	'00'
            	   AND	NVL(ACC_CLS_YN, 'N')	=	'Y' ;

                IF  T_CNT   >=  1   THEN
                    RAISE ERR_GGA11M00_5;
                END IF;

            END IF;

        END IF;

        -- D_2. 회계월마감체크(당월)
        T_CNT   := 0 ;
		SELECT	COUNT(*)
		  INTO  T_CNT
		  FROM	VN.GGA11M00
		 WHERE	TERMS		=	T_TERMS
		   AND	CLS_YM		=	SUBSTR(I_YYMM, 1, 6)
		   AND	BRCH_CD		=   I_BRCH_CD
		   AND	AGNC_BRCH	=	I_AGNC_BRCH
       	   AND	NVL(ACC_CLS_YN, 'N')	=	'Y' ;

        IF  T_CNT   <=  0   THEN
            RAISE ERR_GGA11M00_6;
        END IF;

        -- D_3. 회계월마감체크(익월)
        T_CNT   := 0 ;
        IF  T_TERM_TP   !=   '9'  THEN
    		SELECT	COUNT(*)
    		  INTO  T_CNT
    		  FROM	VN.GGA11M00
    		 WHERE	TERMS		=	T_TERMS
    		   AND	CLS_YM		=	SUBSTR(T_NEX_YYMM, 1, 6)
    		   AND	BRCH_CD		=   I_BRCH_CD
    		   AND	AGNC_BRCH	=	I_AGNC_BRCH
           	   AND	NVL(ACC_CLS_YN, 'N')	=	'Y' ;

            IF  T_CNT   >=  1   THEN
                RAISE ERR_GGA11M00_2;
            END IF;

        END IF;

        -- D_4. 회계월마감 FLAG SET
        T_CNT   := 0 ;
		SELECT	COUNT(*)
		  INTO  T_CNT
		  FROM	VN.GGA11M00
		 WHERE	TERMS		=	T_TERMS
		   AND	CLS_YM		=	SUBSTR(I_YYMM, 1, 6)
		   AND	BRCH_CD		=   I_BRCH_CD
		   AND	AGNC_BRCH	=	I_AGNC_BRCH ;

        -- D_4. 회계월마감 FLAG SET
        IF  T_CNT   >=  1   THEN
			BEGIN
                UPDATE  VN.GGA11M00
                   SET  ACC_CLS_YN  =   'N',
                        WORK_MN     =   I_WORK_MN,
                        WORK_DTM    =   SYSDATE,
                        WORK_TRM    =   I_WORK_TRM
        		 WHERE	TERMS		=	T_TERMS
        		   AND	CLS_YM		=	SUBSTR(I_YYMM, 1, 6)
        		   AND	BRCH_CD		=   I_BRCH_CD
        		   AND	AGNC_BRCH	=	I_AGNC_BRCH ;
		    EXCEPTION WHEN OTHERS THEN
		        RAISE ERR_GGA11M00_UPD;
		    END;
        -- D_5. 회계월마감 FLAG SET
        ELSE
			BEGIN
                INSERT
                  INTO  VN.GGA11M00(
                        TERMS,
                        CLS_YM,
                        BRCH_CD,
                        AGNC_BRCH,
                        ACC_CLS_YN,
                        WORK_MN,
                        WORK_DTM,
                        WORK_TRM )
                VALUES  (T_TERMS,
                        I_YYMM,
                        I_BRCH_CD,
                        I_AGNC_BRCH,
                        'N',
                        I_WORK_MN,
                        SYSDATE,
                        I_WORK_TRM );
		    EXCEPTION WHEN OTHERS THEN
		        RAISE ERR_GGA11M00_INS;
		    END;
        END IF;

        -- D_6. 회계월계 기존자료 삭제
        DELETE
          FROM  VN.GGA09M00
		 WHERE	TERMS		=	T_TERMS
		   AND	CLS_YM		=	SUBSTR(I_YYMM, 1, 6)
		   AND	BRCH_CD		=   I_BRCH_CD
		   AND	AGNC_BRCH	=	I_AGNC_BRCH ;

        -- D_6. 회계거래처월계 기존자료 삭제
        DELETE
          FROM  VN.GGA14M00
		 WHERE	TERMS		=	T_TERMS
		   AND	CLS_YM		=	SUBSTR(I_YYMM, 1, 6)
		   AND	BRCH_CD		=   I_BRCH_CD
		   AND	AGNC_BRCH	=	I_AGNC_BRCH ;

        -- D_6. 고정자산월계 기존자료 삭제
        DELETE
          FROM  VN.GGA25T00
		 WHERE	TERMS		=	T_TERMS
		   AND	DEPR_YM		=	SUBSTR(I_YYMM, 1, 6)
		   AND	BRCH_CD		=   I_BRCH_CD
		   AND	AGNC_BRCH	=	I_AGNC_BRCH ;

        IF  T_TERM_TP   =   '9'  THEN

            -- D_7. 회계월계 기존자료 삭제(전기이월)
            DELETE
              FROM  VN.GGA09M00
    		 WHERE	TERMS		=	T_TERMS + 1
    		   AND	CLS_YM		=	SUBSTR(T_TERMS_NEX, 1, 6)
    		   AND	BRCH_CD		=   I_BRCH_CD
    		   AND	AGNC_BRCH	=	I_AGNC_BRCH ;

            -- D_7. 회계거래처월계 기존자료 삭제(전기이월)
            DELETE
              FROM  VN.GGA14M00
    		 WHERE	TERMS		=	T_TERMS + 1
    		   AND	CLS_YM		=	SUBSTR(T_TERMS_NEX, 1, 6)
    		   AND	BRCH_CD		=   I_BRCH_CD
    		   AND	AGNC_BRCH	=	I_AGNC_BRCH ;

            -- D_7. 고정자산월계 기존자료 삭제(전기이월)
            DELETE
              FROM  VN.GGA25T00
    		 WHERE	TERMS		=	T_TERMS + 1
    		   AND	DEPR_YM		=	SUBSTR(T_TERMS_NEX, 1, 6)
    		   AND	BRCH_CD		=   I_BRCH_CD
    		   AND	AGNC_BRCH	=	I_AGNC_BRCH ;

        END IF;


        IF  I_BRCH_CD   !=   K_ALL_BRCH  THEN
		    -- U_8. 회계상대계정집계 기존자료 삭제
		    DELETE
		      FROM  VN.GGA08M01
			 WHERE	ACC_CLS_DT	>=	SUBSTR(I_YYMM, 1, 6) || '01'
			   AND	ACC_CLS_DT	<=	TO_CHAR(LAST_DAY(TO_DATE(SUBSTR(I_YYMM, 1, 6) || '01', 'YYYYMMDD')), 'YYYYMMDD')
			   AND	BRCH_CD		=   I_BRCH_CD
			   AND	AGNC_BRCH	=	I_AGNC_BRCH ;
        END IF;

    END IF;

    O_RTN_TBL  :=  'GGA11M00';
    O_RTN_ERR  :=  '0';
    IF  I_FLAG  =   'U' THEN
        --O_RTN_MSG  :=  '[V0602]회계마감 성공! ==> 정상적으로 처리되었습니다.';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','0602');
    ELSIF   I_FLAG  =   'D' THEN
        --O_RTN_MSG  :=  '[V0603]회계마감 취소 성공! ==> 정상적으로 처리되었습니다.';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','0603');
    END IF;
    --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);

EXCEPTION
    WHEN    ERR_GGA01C00  THEN
        O_RTN_TBL  :=  'GGA01C00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2016]자료(회계기수)가 존재하지 않습니다';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016');
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA11M00  THEN
        O_RTN_TBL  :=  'GGA11M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2619]이번 달의 회계 마감을 아직 처리하지 않은 팀점이 있습니다 [' || TO_CHAR(T_CNT) || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2619') || ' [' || TO_CHAR(T_CNT) || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA11M00_1  THEN
        O_RTN_TBL  :=  'GGA11M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2616]이미 회계 월마감이 완료되었습니다! [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2616') || ' 01[' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA10M00  THEN
        O_RTN_TBL  :=  'GGA10M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2623]회계 일마감을 아직 처리하지 않은 팀점이 있습니다 [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2623') || ' 02[' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA11M00_2  THEN
        O_RTN_TBL  :=  'GGA11M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2622]이전 달의 회계 마감을 아직 처리하지 않은 부점이 있습니다 [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2622') || ' 03[' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA11M00_3  THEN
        O_RTN_TBL  :=  'GGA11M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V0000]다음 달의 마감을 이미 처리한 팀점이 있습니다 [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2616') || ' 04[' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA11M00_UPD  THEN
        O_RTN_TBL  :=  'GGA11M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2628]회계 월마감을 처리할 수 없습니다. [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2628') || ' 05[' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA11M00_INS  THEN
        O_RTN_TBL  :=  'GGA11M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2628]회계 월마감을 처리할 수 없습니다. [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2628') || ' 06[' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA09M00_INS  THEN
        O_RTN_TBL  :=  'GGA09M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2628]회계 월마감을 처리할 수 없습니다. [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2628') || ' 07[' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA09M00_INS_1  THEN
        O_RTN_TBL  :=  'GGA09M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2628]회계 월마감을 처리할 수 없습니다. [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2628') || ' 08[' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA14M00_INS  THEN
        O_RTN_TBL  :=  'GGA14M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2628]회계 월마감을 처리할 수 없습니다. [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2628') || ' 09[' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA14M00_INS_1  THEN
        O_RTN_TBL  :=  'GGA14M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2628]회계 월마감을 처리할 수 없습니다. [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2628') || ' 10[' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA25T00_INS  THEN
        O_RTN_TBL  :=  'GGA25T00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2628]회계 월마감을 처리할 수 없습니다. [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2628') || ' 11[' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA11M00_4  THEN
        O_RTN_TBL  :=  'GGA11M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2620]이번 달의 회계 마감을 이미 처리한 지점이 있습니다 [' || K_ALL_BRCH || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2620') || ' 12[' || K_ALL_BRCH || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA11M00_5  THEN
        O_RTN_TBL  :=  'GGA11M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2620]이번 달의 회계 마감을 이미 처리한 지점이 있습니다 [' || K_BON_BRCH || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2620') || ' 13[' || K_ALL_BRCH || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA11M00_6  THEN
        O_RTN_TBL  :=  'GGA11M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2619]이번 달의 회계 마감을 아직 처리하지 않은 팀점이 있습니다 [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2619') || ' 14[' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    OTHERS  THEN
        O_RTN_TBL  :=  'OTHERS';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        O_RTN_MSG  :=  'ERROR ' || SUBSTR(SQLERRM, 1, 100);
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
END PGG_ACC_MON_CLS;
/

