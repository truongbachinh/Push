create function fbm_get_sales_adj_rt(
    i_no_of_mth     number
)
return number
/*
    select fbm_get_sales_adj_rt(
        12      -- i_no_of_mth     number
    ) a
    from dual;
*/
as
    t_proc_nm           varchar2(50)    := 'fbm_get_sales_adj_rt';
    t_min_term_month    number;
    t_rt                number;
    t_err_msg           varchar2(1000)  := '';

    o_rt                number;
begin

    begin
        select min(r6.term_month) min_term_month
        into t_min_term_month
        from vn.rms06m00 r6
        where r6.term_month >= i_no_of_mth;
    exception
        when no_data_found then
            o_rt := 1;
            return o_rt;
        when others then
            t_err_msg   := 'Error when getting term_month from rms06m00'
                        || ' sqlcode= ' || sqlcode
                        || ' sqlerrm= ' || sqlerrm;

            vn.pxc_log_write(t_proc_nm, t_err_msg);
            raise_application_error(-20100, t_err_msg);
    end;

    begin
        select rate_val
        into t_rt
        from vn.rms06m00
        where term_month = t_min_term_month
        ;
    exception
        when no_data_found then
            o_rt := 1;
            return o_rt;
        when others then
            t_err_msg   := 'Error when getting rate_value from rms06m00'
                        || ' sqlcode= ' || sqlcode
                        || ' sqlerrm= ' || sqlerrm;

            vn.pxc_log_write(t_proc_nm, t_err_msg);
            raise_application_error(-20100, t_err_msg);
    end;

    o_rt := t_rt;

    return o_rt;
end;
/

