create PROCEDURE    PGG_AST_MON_CLS
   (I_FLAG          IN      VARCHAR2,       -- I:생성,D:취소
    I_YYMM          IN      VARCHAR2,       -- 상각년월
    I_BRCH_CD       IN      VARCHAR2,       -- 지점
    I_AGNC_BRCH     IN      VARCHAR2,       -- 대리지점
    I_WORK_MN       IN      VARCHAR2,		-- 처리자
    I_WORK_TRM      IN      VARCHAR2,       -- IP_ADDRESS
    O_RTN_TBL       OUT     VARCHAR2,       -- Return Table
	O_RTN_ERR       OUT     VARCHAR2,       -- Return Error Code
	O_RTN_MSG       OUT     VARCHAR2        -- Return Message
	) IS

    -- Constants
    K_MAX_DT        VARCHAR2(8) := '30001231' ; -- 지점종료일

    -- Variables
    T_TERMS         NUMBER := VN.FGG_GET_TERMS(I_YYMM || '01'); -- 회계기수
    T_LAST_DAY      VARCHAR2(8) := TO_CHAR(LAST_DAY(TO_DATE(I_YYMM || '01', 'YYYYMMDD')), 'YYYYMMDD') ;   -- 당월마지막일
    T_PRE_YYMM      VARCHAR2(6) := TO_CHAR(ADD_MONTHS(TO_DATE(I_YYMM || '01', 'YYYYMMDD'), -1), 'YYYYMM') ; -- 전월
    T_NEW_TP		VARCHAR2(1) ;   -- 신규 취득/자본적지출 여부(0:No, A:신규취득, B:자본적지출)

    T_CNT           NUMBER := 0;
    T_TERM_TP       VARCHAR2(1) ;   -- 회기시작구분(0:시작월, 1:그외월, 9:종료월)
    T_CHECK         VARCHAR2(1) ;

    O1_RTN_TBL      VARCHAR2(100) ;      				-- Return Table
	O1_RTN_ERR      VARCHAR2(100) ;      				-- Return Error Code
	O1_RTN_MSG      VARCHAR2(254) ;      				-- Return Message


    -- Exceptions Declare
    ERR_GGA01C00				EXCEPTION;
    ERR_GGA11M00_2				EXCEPTION;
    ERR_GGA11M00_1				EXCEPTION;
    ERR_GGA10M00				EXCEPTION;
    ERR_GGA24H00_AB				EXCEPTION;
    ERR_GGA22M01				EXCEPTION;
    ERR_PGG_AST_RTRN_DEPR0		EXCEPTION;
    ERR_PGG_AST_RTRN_DEPR1		EXCEPTION;

-- *************************< START OF PROCEDURE >****************************
BEGIN

    T_TERM_TP := '1' ;
    T_CHECK   := '1' ;

    BEGIN

    	/* 0. 회기시작구분 */
    	SELECT	CASE
    	   			WHEN	SUBSTR(A.OPN_DT, 5, 2)	=	SUBSTR(I_YYMM, 5, 2)	THEN	'0'
    	   			WHEN	SUBSTR(A.END_DT, 5, 2)	=	SUBSTR(I_YYMM, 5, 2)	THEN	'9'
    	   			ELSE	'1'
    			END				AS	TERM_TP
    	  INTO	T_TERM_TP
    	  FROM	VN.GGA01C00 A
    	 WHERE	I_YYMM || '01'	BETWEEN	A.OPN_DT AND A.END_DT
    	   AND	ROWNUM	<=	1 ;

    	/* 0. 지점시작구분 */
    	SELECT	CASE
    	   			WHEN	SUBSTR(NVL(A.BRCH_OPN_DT, TO_CHAR(SYSDATE, 'YYYYMMDD')), 1, 6)	=	SUBSTR(I_YYMM, 1, 6)	THEN	'0'
    	   			ELSE	'1'
    			END													AS	CHECK_TP
    	  INTO	T_CHECK
    	  FROM	VN.XCC90M00 A
         WHERE	A.BRCH_CD	=	I_BRCH_CD
           AND	A.AGNC_BRCH	=	I_AGNC_BRCH
    	   AND	ROWNUM	<=	1 ;


    EXCEPTION WHEN OTHERS THEN
		RAISE ERR_GGA01C00;
    END;


    -- *********************
    -- * 감 가 상 각 생 성 *
    -- *********************
    IF  I_FLAG  =   'I' THEN

        -- CHK_1. 회계월마감체크(전월)
        T_CNT   := 1 ;
        IF  T_TERM_TP   !=   '0'  OR    T_CHECK   !=   '1'  THEN
    		SELECT	COUNT(*)
    		  INTO  T_CNT
    		  FROM	VN.GGA11M00
    		 WHERE	TERMS		=	T_TERMS
    		   AND	CLS_YM		=	SUBSTR(T_PRE_YYMM, 1, 6)
    		   AND	BRCH_CD		=   I_BRCH_CD
    		   AND	AGNC_BRCH	=	I_AGNC_BRCH
           	   AND	NVL(ACC_CLS_YN, 'N')	=	'Y' ;
        END IF;

        IF  T_CNT   <=  0   THEN
            RAISE ERR_GGA11M00_2;
        END IF;

        -- CHK_2. 회계월마감체크(당월)
        T_CNT   := 0 ;
		SELECT	COUNT(*)
		  INTO  T_CNT
		  FROM	VN.GGA11M00
		 WHERE	TERMS		=	T_TERMS
		   AND	CLS_YM		=	SUBSTR(I_YYMM, 1, 6)
		   AND	BRCH_CD		=   I_BRCH_CD
		   AND	AGNC_BRCH	=	I_AGNC_BRCH
       	   AND	NVL(ACC_CLS_YN, 'N')	=	'Y' ;

        IF  T_CNT   >=  1   THEN
            RAISE ERR_GGA11M00_1;
        END IF;

        -- CHK_3. 회계일마감체크(당월마지막일)
        T_CNT   := 0 ;
		SELECT	COUNT(*)
		  INTO  T_CNT
		  FROM	VN.GGA10M00
		 WHERE	ACC_CLS_DT  =	T_LAST_DAY
		   AND	BRCH_CD		=   I_BRCH_CD
		   AND	AGNC_BRCH	=	I_AGNC_BRCH
       	   AND	NVL(ACC_CLS_YN, 'N')	=	'Y' ;

        IF  T_CNT   >=  1   THEN
            RAISE ERR_GGA10M00;
        END IF;

        -- CHK_4. 신규취득/자본적지출 자산체크
        T_CNT   := 0 ;
		SELECT	COUNT(*)
		  INTO  T_CNT
		  FROM	VN.GGA24H00
		 WHERE	REGI_DT  	>=	SUBSTR(I_YYMM, 1, 6) || '01'
		   AND	REGI_DT  	<=	T_LAST_DAY
		   AND	BRCH_CD		=   I_BRCH_CD
		   AND	AGNC_BRCH	=	I_AGNC_BRCH
		   AND	AST_STAT	IN	('A', 'B')
       	   AND	NVL(AST_PROC_TP, '0')	=	'0' ;

        IF  T_CNT   >=  1   THEN
            RAISE ERR_GGA24H00_AB;
        END IF;

        -- CHK_5. 감가상각 전표처리체크
        T_CNT   := 0 ;
		SELECT	COUNT(*)
		  INTO  T_CNT
		  FROM	VN.GGA22M01
		 WHERE	CHG_DT  	=	T_LAST_DAY
		   AND	BRCH_CD		=   I_BRCH_CD
		   AND	AGNC_BRCH	=	I_AGNC_BRCH
		   AND	SLIP_NO		IS NOT NULL ;

        IF  T_CNT   >=  1   THEN
            RAISE ERR_GGA22M01;
        END IF;

        -- DEL_4. 월감가상각 기존자료 삭제
        DELETE
          FROM  VN.GGA23M00
		 WHERE	TERMS		=	T_TERMS
		   AND	DEPR_YM		=	SUBSTR(I_YYMM, 1, 6)
		   AND	BRCH_CD		=   I_BRCH_CD
		   AND	AGNC_BRCH	=	I_AGNC_BRCH ;

		-- DEL_5. 년감가상각 기존자료 삭제
		IF  T_TERM_TP   =   '0'  THEN

	        DELETE
	          FROM  VN.GGA23M01
			 WHERE	TERMS		=	T_TERMS
			   AND	DEPR_YY		=	SUBSTR(I_YYMM, 1, 4)
			   AND	BRCH_CD		=   I_BRCH_CD
			   AND	AGNC_BRCH	=	I_AGNC_BRCH ;

        END IF;


        -- CHK_6. 년상각액 처리
		O1_RTN_TBL	:=	NULL ;
		O1_RTN_ERR	:=	'0' ;
		O1_RTN_MSG	:=	NULL ;

		VN.PGG_AST_RTRN_DEPR0(
			T_TERM_TP,					-- 회기시작구분(0:시작, 1:기중, 9:종료)
			I_BRCH_CD,					-- 지점
			I_AGNC_BRCH,				-- 대리지점
			T_TERMS,					-- 회계기수
			I_YYMM,						-- 상각년월
			T_LAST_DAY,					-- 처리일
			I_WORK_MN,					-- 처리자
			I_WORK_TRM,					-- IP_ADDRESS
			O1_RTN_TBL,
			O1_RTN_ERR,
			O1_RTN_MSG) ;

		IF  TO_NUMBER(O1_RTN_ERR)   <>   0  THEN
			RAISE ERR_PGG_AST_RTRN_DEPR0;
    	END IF;


    -- *********************
    -- * 감 가 상 각 취 소 *
    -- *********************
    ELSIF   I_FLAG  =   'D' THEN

        -- DEL_1. 회계월마감체크(당월)
        T_CNT   := 0 ;
		SELECT	COUNT(*)
		  INTO  T_CNT
		  FROM	VN.GGA11M00
		 WHERE	TERMS		=	T_TERMS
		   AND	CLS_YM		=	SUBSTR(I_YYMM, 1, 6)
		   AND	BRCH_CD		=   I_BRCH_CD
		   AND	AGNC_BRCH	=	I_AGNC_BRCH
       	   AND	NVL(ACC_CLS_YN, 'N')	=	'Y' ;

        IF  T_CNT   >=  1   THEN
            RAISE ERR_GGA11M00_1;
        END IF;

        -- DEL_2. 회계일마감체크(당월마지막일)
        T_CNT   := 0 ;
		SELECT	COUNT(*)
		  INTO  T_CNT
		  FROM	VN.GGA10M00
		 WHERE	ACC_CLS_DT  =	T_LAST_DAY
		   AND	BRCH_CD		=   I_BRCH_CD
		   AND	AGNC_BRCH	=	I_AGNC_BRCH
       	   AND	NVL(ACC_CLS_YN, 'N')	=	'Y' ;

        IF  T_CNT   >=  1   THEN
            RAISE ERR_GGA10M00;
        END IF;

        -- CHK_5. 감가상각 전표처리체크
        T_CNT   := 0 ;
		SELECT	COUNT(*)
		  INTO  T_CNT
		  FROM	VN.GGA22M01
		 WHERE	CHG_DT  	=	T_LAST_DAY
		   AND	BRCH_CD		=   I_BRCH_CD
		   AND	AGNC_BRCH	=	I_AGNC_BRCH
		   AND	SLIP_NO		IS NOT NULL ;

        IF  T_CNT   <=  0   THEN
            RAISE ERR_GGA22M01;
        END IF;

    END IF;


    -- CHK_7. 월상각액 처리

	O1_RTN_TBL	:=	NULL ;
	O1_RTN_ERR	:=	'0' ;
	O1_RTN_MSG	:=	NULL ;

	VN.PGG_AST_RTRN_DEPR1(
		I_FLAG,						-- I:생성,D:취소
		I_BRCH_CD,					-- 지점
		I_AGNC_BRCH,				-- 대리지점
		T_TERMS,					-- 회계기수
		I_YYMM,						-- 상각년월
		T_LAST_DAY,					-- 처리일
		I_WORK_MN,					-- 처리자
		I_WORK_TRM,					-- IP_ADDRESS
		O1_RTN_TBL,
		O1_RTN_ERR,
		O1_RTN_MSG) ;

	IF  TO_NUMBER(O1_RTN_ERR)   <>   0  THEN
		RAISE ERR_PGG_AST_RTRN_DEPR1;
    END IF;


    O_RTN_TBL  :=  'GGA11M00';
    O_RTN_ERR  :=  '0';
    IF  I_FLAG  =   'I' THEN
        --O_RTN_MSG  :=  '[V0602]회계마감 성공! ==> 정상적으로 처리되었습니다.';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','0602');
    ELSIF   I_FLAG  =   'D' THEN
        --O_RTN_MSG  :=  '[V0603]회계마감 취소 성공! ==> 정상적으로 처리되었습니다.';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','0603');
    END IF;
    --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);

EXCEPTION
    WHEN    ERR_GGA01C00  THEN
        O_RTN_TBL  :=  'ERR_GGA01C00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2016]자료(회계기수)가 존재하지 않습니다';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') || ' [' || O_RTN_TBL || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA11M00_2  THEN
        O_RTN_TBL  :=  'ERR_GGA11M00_2';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2622]이전 달의 회계 마감을 아직 처리하지 않은 부점이 있습니다 [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2622') || ' [' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA11M00_1  THEN
        O_RTN_TBL  :=  'ERR_GGA11M00_1';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2616]이미 회계 월마감이 완료되었습니다! [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2616') || ' [' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA10M00  THEN
        O_RTN_TBL  :=  'ERR_GGA10M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2623]회계 일마감을 아직 처리하지 않은 팀점이 있습니다 [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2623') || ' [' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA24H00_AB  THEN
        O_RTN_TBL  :=  'ERR_GGA24H00_AB';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2016]자료가 존재하지 않습니다';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') || ' [' || O_RTN_TBL || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA22M01  THEN
        O_RTN_TBL  :=  'ERR_GGA22M01';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2016]자료가 존재하지 않습니다';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') || ' [' || O_RTN_TBL || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_PGG_AST_RTRN_DEPR0  THEN
        O_RTN_TBL  :=  'ERR_PGG_AST_RTRN_DEPR0';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2016]자료가 존재하지 않습니다';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') || ' [' || O_RTN_TBL || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_PGG_AST_RTRN_DEPR1  THEN
        O_RTN_TBL  :=  'ERR_PGG_AST_RTRN_DEPR1';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2016]자료가 존재하지 않습니다';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2016') || ' [' || O_RTN_TBL || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    OTHERS  THEN
        O_RTN_TBL  :=  'OTHERS';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        O_RTN_MSG  :=  'ERROR ' || SUBSTR(SQLERRM, 1, 100);
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
END PGG_AST_MON_CLS;
/

