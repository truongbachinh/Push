create PROCEDURE    PGG_ACC_MON_RITS
   (I_FLAG          IN      VARCHAR2,       -- U:처리,D:취소
    I_YYMM          IN      VARCHAR2,       -- 결산년월
    I_BRCH_CD       IN      VARCHAR2,       -- 지점
    I_AGNC_BRCH     IN      VARCHAR2,       -- 대리지점
    I_RITS_SN       IN      VARCHAR2,       -- 결산순번
    I_WORK_MN       IN      VARCHAR2,		-- 처리자
    I_WORK_TRM      IN      VARCHAR2,       -- IP_ADDRESS
    O_RTN_TBL       OUT     VARCHAR2,       -- Return Table
	O_RTN_ERR       OUT     VARCHAR2,       -- Return Error Code
	O_RTN_MSG       OUT     VARCHAR2        -- Return Message
	) IS

    -- Constants
    K_500	        VARCHAR2(12) := '500000000000' ; -- 수익500계정
    K_700	        VARCHAR2(12) := '700000000000' ; -- 수익700계정
    K_600	        VARCHAR2(12) := '600000000000' ; -- 비용600계정
    K_800	        VARCHAR2(12) := '800000000000' ; -- 비용800계정
    K_911	        VARCHAR2(12) := '911000000000' ; -- 손익대체계정
    K_421	        VARCHAR2(12) := '421200000000' ; -- 자본대체계정
	K_SLIP_TP	    VARCHAR2(1) := '6' ; -- 전표구분
	K_RMRK_JOB_TP   VARCHAR2(2) := '40' ;


    K_ALL_BRCH      VARCHAR2(3) := '000' ;      -- 회사전체
    K_BON_BRCH      VARCHAR2(3) := '901' ;      -- 본점
    K_MAX_DT        VARCHAR2(8) := '30001231' ; -- 지점종료일
    K_MAX_YM        VARCHAR2(6) := '200804' ; 	-- 조회시작월

    -- Variables
    T_TERMS         NUMBER := VN.FGG_GET_TERMS(I_YYMM || '01'); -- 회계기수
    T_LAST_WORK     VARCHAR2(8) := VN.FGG_GET_WORK_DT(TO_CHAR(LAST_DAY(TO_DATE(I_YYMM || '01', 'YYYYMMDD')), 'YYYYMMDD'), '-') ;   -- 당월마지막영업일
    T_LAST_DAY      VARCHAR2(8) := TO_CHAR(LAST_DAY(TO_DATE(I_YYMM || '01', 'YYYYMMDD')), 'YYYYMMDD') ;   -- 당월마지막일

    T_CNT           NUMBER := 0;
    T_PROC_CNT      NUMBER := 0;
    T_RITS_SN       VARCHAR2(3) := '001' ;      -- 결산순번
    T_DETL_SN       VARCHAR2(3) := '001' ;      -- 상세순번

    T_GGA06M00_SLIP_DT             GGA06M00.SLIP_DT%TYPE;              --전표일자
    T_GGA06M00_BRCH_CD             GGA06M00.BRCH_CD%TYPE;              --지점코드
    T_GGA06M00_AGNC_BRCH           GGA06M00.AGNC_BRCH%TYPE;            --대리지점
    T_GGA06M00_SLIP_NO             GGA06M00.SLIP_NO%TYPE;              --전표번호
    T_GGA06M00_SLIP_SUB_NO         GGA06M00.SLIP_SUB_NO%TYPE;          --전표부번호
    T_GGA06M00_RMRK_JOB_TP         GGA06M00.RMRK_JOB_TP%TYPE;          --적요업무구분
    T_GGA06M00_SLIP_TP             GGA06M00.SLIP_TP%TYPE;              --전표구분
    T_GGA06M00_ACC_RMRK_CD         GGA06M00.ACC_RMRK_CD%TYPE;          --회계적요코드
    T_GGA06M00_TRD_CNTE            GGA06M00.TRD_CNTE%TYPE;             --거래비고
    T_GGA06M00_DR_CR_TP            GGA06M00.DR_CR_TP%TYPE;             --차변대변구분
    T_GGA06M00_ACC_ACT_CD          GGA06M00.ACC_ACT_CD%TYPE;           --회계계정코드
    T_GGA06M00_OPR_BNH_CD          GGA06M00.OPR_BNH_CD%TYPE;           --상대부점코드
    T_GGA06M00_OPR_AGNC_BRCH       GGA06M00.OPR_AGNC_BRCH%TYPE;        --상대대리지점
    T_GGA06M00_SLIP_AMT            GGA06M00.SLIP_AMT%TYPE;             --전표금액
    T_GGA06M00_DETL_CNTE           GGA06M00.DETL_CNTE%TYPE;            --상세비고
    T_GGA06M00_RECV_SND_TP         GGA06M00.RECV_SND_TP%TYPE;          --수신발신구분
    T_GGA06M00_RECV_YN             GGA06M00.RECV_YN%TYPE;              --수신여부
    T_GGA06M00_AUTO_TP             GGA06M00.AUTO_TP%TYPE;              --자동구분
    T_GGA06M00_SLIP_STAT           GGA06M00.SLIP_STAT%TYPE;            --전표상태
    T_GGA06M00_DRAF_MN             GGA06M00.DRAF_MN%TYPE;              --기안자
    T_GGA06M00_DRAF_DTM            GGA06M00.DRAF_DTM%TYPE;             --기안일시
    T_GGA06M00_CNFM_MN             GGA06M00.CNFM_MN%TYPE;              --승인자
    T_GGA06M00_CNFM_DTM            GGA06M00.CNFM_DTM%TYPE;             --승인일시
    T_GGA06M00_CUST_CD             GGA06M00.CUST_CD%TYPE;              --거래처코드
    T_GGA06M00_SUP_PRI_AMT         GGA06M00.SUP_PRI_AMT%TYPE;          --공급가액
    T_GGA06M00_VAT_AMT             GGA06M00.VAT_AMT%TYPE;              --부가세액
    T_GGA06M00_EVI_TP              GGA06M00.EVI_TP%TYPE;               --증빙구분
    T_GGA06M00_EVI_DT              GGA06M00.EVI_DT%TYPE;               --증빙일자
    T_GGA06M00_EVI_NO              GGA06M00.EVI_NO%TYPE;               --증빙번호
    T_GGA06M00_TAXB_NO             GGA06M00.TAXB_NO%TYPE;              --세무번호
    T_GGA06M00_ORIG_ACNT_NO        GGA06M00.ORIG_ACNT_NO%TYPE;         --원천계좌번호
    T_GGA06M00_ORIG_TRD_DT         GGA06M00.ORIG_TRD_DT%TYPE;          --원천거래일
    T_GGA06M00_ORIG_TRD_SEQ_NO     GGA06M00.ORIG_TRD_SEQ_NO%TYPE;      --원천거래일련번호
    T_GGA06M00_RECV_SND_NO         GGA06M00.RECV_SND_NO%TYPE;          --수신발신번호
    T_GGA06M00_WORK_MN             GGA06M00.WORK_MN%TYPE;              --처리자
    T_GGA06M00_WORK_DTM            GGA06M00.WORK_DTM%TYPE;             --처리일시
    T_GGA06M00_WORK_TRM            GGA06M00.WORK_TRM%TYPE;             --처리단말

    T_GGA16M00_TOT_PFT_EXCH_CNT    GGA16M00.TOT_PFT_EXCH_CNT%TYPE;     --총수익대체건수
    T_GGA16M00_TOT_PFT_EXCH_AMT    GGA16M00.TOT_PFT_EXCH_AMT%TYPE;     --총수익대체금액
    T_GGA16M00_TOT_CST_EXCH_CNT    GGA16M00.TOT_CST_EXCH_CNT%TYPE;     --총비용대체건수
    T_GGA16M00_TOT_CST_EXCH_AMT    GGA16M00.TOT_CST_EXCH_AMT%TYPE;     --총비용대체금액
    T_GGA16M00_TOT_CAP_EXCH_AMT    GGA16M00.TOT_CAP_EXCH_AMT%TYPE;     --총자본대체금액

    -- Exceptions Declare
    ERR_COMMON        	EXCEPTION;
    ERR_GGA10M00        EXCEPTION;
    ERR_GGA11M00_1      EXCEPTION;
	ERR_GGA06M00_INS    EXCEPTION;
	ERR_GGA16M00_SEL    EXCEPTION;
	ERR_GGA16M00_INS    EXCEPTION;
	ERR_GGA16M00_UPD    EXCEPTION;
	ERR_GGA16M01_INS    EXCEPTION;
	ERR_GGA16M01_UPD    EXCEPTION;

-- *************************< START OF PROCEDURE >****************************
BEGIN

	/* 0. 처리 시작월 체크 */
	IF  I_YYMM   <=   K_MAX_YM  THEN
        RAISE ERR_COMMON;
	END IF;

    -- *********************
    -- * 결   산   처   리 *
    -- *********************
    IF  I_FLAG  =   'U' THEN

        -- U_1. 회계월마감체크(당월)
        T_CNT   := 0 ;
		SELECT	COUNT(*)
		  INTO  T_CNT
		  FROM	VN.GGA11M00
		 WHERE	TERMS		=	T_TERMS
		   AND	CLS_YM		=	SUBSTR(I_YYMM, 1, 6)
		   AND	BRCH_CD		=   I_BRCH_CD
		   AND	AGNC_BRCH	=	I_AGNC_BRCH
       	   AND	NVL(ACC_CLS_YN, 'N')	=	'Y' ;

        IF  T_CNT   >=  1   THEN
            RAISE ERR_GGA11M00_1;
        END IF;

        -- U_2. 회계일마감체크
        T_CNT   := 0 ;
		SELECT	COUNT(*)
		  INTO  T_CNT
		  FROM	VN.GGA10M00
		 WHERE	ACC_CLS_DT  =	T_LAST_DAY
		   AND	BRCH_CD		=   I_BRCH_CD
		   AND	AGNC_BRCH	=	I_AGNC_BRCH
       	   AND	NVL(ACC_CLS_YN, 'N')	=	'Y' ;

        IF  T_CNT   >=  1   THEN
            RAISE ERR_GGA10M00;
        END IF;

        -- U_3. 기존결산처리건 체크
        T_CNT   := 0 ;
		SELECT	COUNT(*)
		  INTO  T_CNT
		  FROM	VN.GGA16M00
		 WHERE	RITS_YM		=	I_YYMM
		   AND	BRCH_CD		=	I_BRCH_CD
		   AND	AGNC_BRCH	=	I_AGNC_BRCH
		   AND	NVL(CNCL_YN, 'N')	=	'N' ;

        IF  T_CNT   >=  1   THEN
            RAISE ERR_GGA16M00_SEL;
        END IF;

        -- U_4. 결산순번 발번
		SELECT	LPAD(TO_CHAR(TO_NUMBER(NVL(MAX(RITS_SN), 0)) + 1), 3, '0')
		  INTO  T_RITS_SN
		  FROM	VN.GGA16M00
		 WHERE	RITS_YM  	=	SUBSTR(I_YYMM, 1, 6)
		   AND	BRCH_CD		=   I_BRCH_CD
		   AND	AGNC_BRCH	=	I_AGNC_BRCH ;

        -- U_5. 월결산이력Master Insert
		BEGIN
            INSERT
              INTO  VN.GGA16M00(
                    RITS_YM,
                    BRCH_CD,
                    AGNC_BRCH,
                    RITS_SN,
                    TOT_PFT_EXCH_CNT,
                    TOT_PFT_EXCH_AMT,
                    TOT_CST_EXCH_CNT,
                    TOT_CST_EXCH_AMT,
                    TOT_CAP_EXCH_AMT,
                    CNTE,
                    CNCL_YN,
                    WORK_MN,
                    WORK_DTM,
                    WORK_TRM )
            VALUES  (I_YYMM,
                    I_BRCH_CD,
                    I_AGNC_BRCH,
                    T_RITS_SN,
                    0,
                    0,
                    0,
                    0,
                    0,
                    NULL,
                    'N',
                    I_WORK_MN,
                    SYSDATE,
                    I_WORK_TRM );
	    EXCEPTION WHEN OTHERS THEN
	        RAISE ERR_GGA16M00_INS;
	    END;

        -- U_6. 일계에서 손익자동전표발췌(5XX,7XX,6XX,8XX)
        FOR C11 IN
        	(	SELECT	v11.WORK_KND				AS	WORK_KND,
						v11.RMRK_TRD_TP				AS	RMRK_TRD_TP,
						v11.DR_CR_TP				AS	DR_CR_TP,
						v11.ACC_ACT_CD				AS	ACC_ACT_CD,
						NVL(v11.CUR_AMT, 0)			AS	CUR_AMT
				  FROM
						(	SELECT	v21.WORK_KND				AS	WORK_KND,
									v21.RMRK_TRD_TP				AS	RMRK_TRD_TP,
									DECODE(v22.DR_CR_TP, '1', '2', '1')	AS	DR_CR_TP,
									v21.ACC_ACT_CD				AS	ACC_ACT_CD,
									CASE
										WHEN	v22.DR_CR_TP	=	'1'	THEN
												NVL(v21.CUR_DR_AMT, 0) - NVL(v21.CUR_CR_AMT, 0)
										ELSE	NVL(v21.CUR_CR_AMT, 0) - NVL(v21.CUR_DR_AMT, 0)
									END							AS	CUR_AMT
							  FROM
									(	SELECT	'1'									AS	WORK_KND,
												'950'								AS	RMRK_TRD_TP,
												v31.ACC_ACT_CD						AS	ACC_ACT_CD,
												NVL(SUM(v31.DR_EXCH_AMT), 0) +
													NVL(SUM(v31.DR_CASH_AMT), 0)	AS	CUR_DR_AMT,		/* 현차변금액 */
												NVL(SUM(v31.CR_EXCH_AMT), 0) +
													NVL(SUM(v31.CR_CASH_AMT), 0)	AS	CUR_CR_AMT		/* 현대변금액 */
										  FROM	VN.GGA08M00	v31		/* 회계일계 */
										 WHERE	v31.ACC_CLS_DT	>=	SUBSTR(I_YYMM, 1, 6) || '01'
										   AND	v31.ACC_CLS_DT	<=	T_LAST_DAY
										   AND	v31.BRCH_CD		=	I_BRCH_CD
										   AND	v31.AGNC_BRCH	=	I_AGNC_BRCH
										   AND	v31.ACC_ACT_CD	IN	(	SELECT	v41.ACC_ACT_CD		AS	ACC_ACT_CD
																		  FROM	VN.GGA02C00	v41,
																				(	SELECT	v51.ACC_ACT_CD		AS	ACC_ACT_CD,
																							v51.ACT_UNIT_TP		AS	ACT_UNIT_TP
																					  FROM	VN.GGA02C00	v51
																					 WHERE	v51.ACC_ACT_CD	=	K_500
																				)			v42
																		 WHERE	v42.ACC_ACT_CD	=	DECODE(v42.ACT_UNIT_TP,
																										'1', v41.LVL1_CD, '2', v41.LVL2_CD,
																										'3', v41.LVL3_CD, '4', v41.LVL4_CD,
																										'5', v41.LVL5_CD, v41.ACC_ACT_CD)
																		   AND	NVL(v41.SLIP_OCUR_YN, 'N')	=	'Y'
																	)
									  GROUP BY	v31.ACC_ACT_CD
									UNION ALL
										SELECT	'2'									AS	WORK_KND,
												'970'								AS	RMRK_TRD_TP,
												v31.ACC_ACT_CD						AS	ACC_ACT_CD,
												NVL(SUM(v31.DR_EXCH_AMT), 0) +
													NVL(SUM(v31.DR_CASH_AMT), 0)	AS	CUR_DR_AMT,		/* 현차변금액 */
												NVL(SUM(v31.CR_EXCH_AMT), 0) +
													NVL(SUM(v31.CR_CASH_AMT), 0)	AS	CUR_CR_AMT		/* 현대변금액 */
										  FROM	VN.GGA08M00	v31		/* 회계일계 */
										 WHERE	v31.ACC_CLS_DT	>=	SUBSTR(I_YYMM, 1, 6) || '01'
										   AND	v31.ACC_CLS_DT	<=	T_LAST_DAY
										   AND	v31.BRCH_CD		=	I_BRCH_CD
										   AND	v31.AGNC_BRCH	=	I_AGNC_BRCH
										   AND	v31.ACC_ACT_CD	IN	(	SELECT	v41.ACC_ACT_CD		AS	ACC_ACT_CD
																		  FROM	VN.GGA02C00	v41,
																				(	SELECT	v51.ACC_ACT_CD		AS	ACC_ACT_CD,
																							v51.ACT_UNIT_TP		AS	ACT_UNIT_TP
																					  FROM	VN.GGA02C00	v51
																					 WHERE	v51.ACC_ACT_CD	=	K_700
																				)			v42
																		 WHERE	v42.ACC_ACT_CD	=	DECODE(v42.ACT_UNIT_TP,
																										'1', v41.LVL1_CD, '2', v41.LVL2_CD,
																										'3', v41.LVL3_CD, '4', v41.LVL4_CD,
																										'5', v41.LVL5_CD, v41.ACC_ACT_CD)
																		   AND	NVL(v41.SLIP_OCUR_YN, 'N')	=	'Y'
																	)
									  GROUP BY	v31.ACC_ACT_CD
									UNION ALL
										SELECT	'3'									AS	WORK_KND,
												'960'								AS	RMRK_TRD_TP,
												v31.ACC_ACT_CD						AS	ACC_ACT_CD,
												NVL(SUM(v31.DR_EXCH_AMT), 0) +
													NVL(SUM(v31.DR_CASH_AMT), 0)	AS	CUR_DR_AMT,		/* 현차변금액 */
												NVL(SUM(v31.CR_EXCH_AMT), 0) +
													NVL(SUM(v31.CR_CASH_AMT), 0)	AS	CUR_CR_AMT		/* 현대변금액 */
										  FROM	VN.GGA08M00	v31		/* 회계일계 */
										 WHERE	v31.ACC_CLS_DT	>=	SUBSTR(I_YYMM, 1, 6) || '01'
										   AND	v31.ACC_CLS_DT	<=	T_LAST_DAY
										   AND	v31.BRCH_CD		=	I_BRCH_CD
										   AND	v31.AGNC_BRCH	=	I_AGNC_BRCH
										   AND	v31.ACC_ACT_CD	IN	(	SELECT	v41.ACC_ACT_CD		AS	ACC_ACT_CD
																		  FROM	VN.GGA02C00	v41,
																				(	SELECT	v51.ACC_ACT_CD		AS	ACC_ACT_CD,
																							v51.ACT_UNIT_TP		AS	ACT_UNIT_TP
																					  FROM	VN.GGA02C00	v51
																					 WHERE	v51.ACC_ACT_CD	=	K_600
																				)			v42
																		 WHERE	v42.ACC_ACT_CD	=	DECODE(v42.ACT_UNIT_TP,
																										'1', v41.LVL1_CD, '2', v41.LVL2_CD,
																										'3', v41.LVL3_CD, '4', v41.LVL4_CD,
																										'5', v41.LVL5_CD, v41.ACC_ACT_CD)
																		   AND	NVL(v41.SLIP_OCUR_YN, 'N')	=	'Y'
																	)
									  GROUP BY	v31.ACC_ACT_CD
									UNION ALL
										SELECT	'4'									AS	WORK_KND,
												'980'								AS	RMRK_TRD_TP,
												v31.ACC_ACT_CD						AS	ACC_ACT_CD,
												NVL(SUM(v31.DR_EXCH_AMT), 0) +
													NVL(SUM(v31.DR_CASH_AMT), 0)	AS	CUR_DR_AMT,		/* 현차변금액 */
												NVL(SUM(v31.CR_EXCH_AMT), 0) +
													NVL(SUM(v31.CR_CASH_AMT), 0)	AS	CUR_CR_AMT		/* 현대변금액 */
										  FROM	VN.GGA08M00	v31		/* 회계일계 */
										 WHERE	v31.ACC_CLS_DT	>=	SUBSTR(I_YYMM, 1, 6) || '01'
										   AND	v31.ACC_CLS_DT	<=	T_LAST_DAY
										   AND	v31.BRCH_CD		=	I_BRCH_CD
										   AND	v31.AGNC_BRCH	=	I_AGNC_BRCH
										   AND	v31.ACC_ACT_CD	IN	(	SELECT	v41.ACC_ACT_CD		AS	ACC_ACT_CD
																		  FROM	VN.GGA02C00	v41,
																				(	SELECT	v51.ACC_ACT_CD		AS	ACC_ACT_CD,
																							v51.ACT_UNIT_TP		AS	ACT_UNIT_TP
																					  FROM	VN.GGA02C00	v51
																					 WHERE	v51.ACC_ACT_CD	=	K_800
																				)			v42
																		 WHERE	v42.ACC_ACT_CD	=	DECODE(v42.ACT_UNIT_TP,
																										'1', v41.LVL1_CD, '2', v41.LVL2_CD,
																										'3', v41.LVL3_CD, '4', v41.LVL4_CD,
																										'5', v41.LVL5_CD, v41.ACC_ACT_CD)
																		   AND	NVL(v41.SLIP_OCUR_YN, 'N')	=	'Y'
																	)
									  GROUP BY	v31.ACC_ACT_CD
									)			v21,
									VN.GGA02C00	v22
							 WHERE	v21.ACC_ACT_CD	=	v22.ACC_ACT_CD
						)			v11
				 WHERE	NVL(v11.CUR_AMT, 0)	<>	0
			  ORDER BY	v11.WORK_KND,
						v11.ACC_ACT_CD
            ) LOOP


            -- U_7. 전표지정 실계정
			T_GGA06M00_SLIP_DT      := T_LAST_DAY;		--전표일자
			T_GGA06M00_BRCH_CD      := I_BRCH_CD;		--지점코드
			T_GGA06M00_AGNC_BRCH    := I_AGNC_BRCH;		--대리지점
			T_GGA06M00_SLIP_NO		:= VN.FGG_GET_SLIP_NO(I_BRCH_CD, I_AGNC_BRCH, T_LAST_DAY, K_SLIP_TP);  --전표번호

            T_GGA06M00_RMRK_JOB_TP  := K_RMRK_JOB_TP;	--적요업무구분
            T_GGA06M00_SLIP_TP      := K_SLIP_TP;		--적요입출구분
            T_GGA06M00_ACC_RMRK_CD  := K_RMRK_JOB_TP || C11.RMRK_TRD_TP || '10' ;          	--적요코드

            IF  C11.WORK_KND IN ('1','2') THEN
				T_GGA06M00_TRD_CNTE     := 'Xác định kết quả kinh doanh(' || SUBSTR(C11.ACC_ACT_CD, 1, 4) || '=>911)';       --거래비고
				T_GGA06M00_DETL_CNTE    := 'Xác định kết quả kinh doanh(' || SUBSTR(C11.ACC_ACT_CD, 1, 4) || '=>911)';       --상세비고
            ELSE
				T_GGA06M00_TRD_CNTE     := 'Xác định kết quả kinh doanh(' || SUBSTR(C11.ACC_ACT_CD, 1, 5) || '=>911)';       --거래비고
				T_GGA06M00_DETL_CNTE    := 'Xác định kết quả kinh doanh(' || SUBSTR(C11.ACC_ACT_CD, 1, 5) || '=>911)';       --상세비고
            END IF;

            T_GGA06M00_OPR_BNH_CD   := NULL;           	--상대부점코드
            T_GGA06M00_OPR_AGNC_BRCH := NULL;        	--상대부점코드(출장소)
			T_GGA06M00_SLIP_AMT     := C11.CUR_AMT; 	--전표금액
            T_GGA06M00_RECV_SND_TP  := '9'; 			--수발신 구분
            T_GGA06M00_RECV_YN      := NULL;            --수신여부
            T_GGA06M00_AUTO_TP      := '1';            	--자동구분(1:자동전표,2:수기전표)
            T_GGA06M00_SLIP_STAT    := '1';            	--전표상태(1:미승인,2:승인,3:반려,4:취소)
            T_GGA06M00_DRAF_MN      := I_WORK_MN;     	--기안자
            T_GGA06M00_DRAF_DTM     := SYSDATE;       	--기안일시
            T_GGA06M00_CNFM_MN      := NULL;           	--승인자
            T_GGA06M00_CNFM_DTM     := NULL;           	--승인일시
            T_GGA06M00_CUST_CD      := '0000000000';  	--고객코드
            T_GGA06M00_SUP_PRI_AMT  := NULL;           	--공급가액
            T_GGA06M00_VAT_AMT      := NULL;           	--부가세액
            T_GGA06M00_EVI_TP       := NULL;           	--증빙구분
            T_GGA06M00_EVI_DT       := NULL;           	--증빙일자
            T_GGA06M00_EVI_NO       := NULL;           	--증빙번호
            T_GGA06M00_TAXB_NO      := NULL;           	--세무번호
            T_GGA06M00_ORIG_ACNT_NO := NULL;           	--원천계좌번호
            T_GGA06M00_ORIG_TRD_DT  := NULL;          	--원천거래일
            T_GGA06M00_ORIG_TRD_SEQ_NO := NULL;        	--원천거래일련번호
            T_GGA06M00_RECV_SND_NO  := NULL;           	--수신발신번호
            T_GGA06M00_WORK_MN      := I_WORK_MN;      	--처리자
            T_GGA06M00_WORK_DTM     := SYSDATE;        	--처리일시
            T_GGA06M00_WORK_TRM     := I_WORK_TRM;     	--처리단말

	        FOR C12 IN
				(	SELECT	v21.NO		AS	NO
					  FROM
							(	SELECT	1	AS	NO	FROM	DUAL
							UNION ALL
								SELECT	2	AS	NO	FROM	DUAL
							)			v21
				  ORDER BY	v21.NO
	            ) LOOP

	            T_GGA06M00_SLIP_SUB_NO  := TO_CHAR(C12.NO,'FM000');			--전표부번호

            	IF  C12.NO =	1 THEN
		            T_GGA06M00_DR_CR_TP     := C11.DR_CR_TP;     --차대구분
					T_GGA06M00_ACC_ACT_CD   := C11.ACC_ACT_CD;   --계정
            	ELSE
					IF	C11.DR_CR_TP	=	'1'	THEN
		            	T_GGA06M00_DR_CR_TP     := '2';     --차대구분
					ELSE
		            	T_GGA06M00_DR_CR_TP     := '1';     --차대구분
					END IF;
					T_GGA06M00_ACC_ACT_CD   := K_911;   --계정
            	END IF;

	        	-- U_5. 회계전표 Insert
				BEGIN
		            INSERT
		              INTO  VN.GGA06M00(
							SLIP_DT,                --전표일자
							BRCH_CD,                --지점코드
							AGNC_BRCH,              --대리지점
							SLIP_NO,                --전표번호
							SLIP_SUB_NO,            --전표부번호
							RMRK_JOB_TP,            --적요업무구분
							SLIP_TP,                --전표구분
							ACC_RMRK_CD,            --회계적요코드
							TRD_CNTE,               --거래비고
							DR_CR_TP,               --차변대변구분
							ACC_ACT_CD,             --회계계정코드
							OPR_BNH_CD,             --상대부점코드
							OPR_AGNC_BRCH,          --상대대리지점
							SLIP_AMT,               --전표금액
							DETL_CNTE,              --상세비고
							RECV_SND_TP,            --수신발신구분
							RECV_YN,                --수신여부
							AUTO_TP,                --자동구분
							SLIP_STAT,              --전표상태
							DRAF_MN,                --기안자
							DRAF_DTM,               --기안일시
							CNFM_MN,                --승인자
							CNFM_DTM,               --승인일시
							CUST_CD,                --거래처코드
							SUP_PRI_AMT,            --공급가액
							VAT_AMT,                --부가세액
							EVI_TP,                 --증빙구분
							EVI_DT,                 --증빙일자
							EVI_NO,                 --증빙번호
							TAXB_NO,                --세무번호
							ORIG_ACNT_NO,           --원천계좌번호
							ORIG_TRD_DT,            --원천거래일
							ORIG_TRD_SEQ_NO,        --원천거래일련번호
							RECV_SND_NO,            --수신발신번호
							WORK_MN,                --처리자
							WORK_DTM,               --처리일시
							WORK_TRM )              --처리단말
	     	       VALUES  (T_GGA06M00_SLIP_DT,
							T_GGA06M00_BRCH_CD,
							T_GGA06M00_AGNC_BRCH,
							T_GGA06M00_SLIP_NO,
							T_GGA06M00_SLIP_SUB_NO,
							T_GGA06M00_RMRK_JOB_TP,
							T_GGA06M00_SLIP_TP,
							T_GGA06M00_ACC_RMRK_CD,
							T_GGA06M00_TRD_CNTE,
							T_GGA06M00_DR_CR_TP,
							T_GGA06M00_ACC_ACT_CD,
							T_GGA06M00_OPR_BNH_CD,
							T_GGA06M00_OPR_AGNC_BRCH,
							T_GGA06M00_SLIP_AMT,
							T_GGA06M00_DETL_CNTE,
							T_GGA06M00_RECV_SND_TP,
							T_GGA06M00_RECV_YN,
							T_GGA06M00_AUTO_TP,
							T_GGA06M00_SLIP_STAT,
							T_GGA06M00_DRAF_MN,
							T_GGA06M00_DRAF_DTM,
							T_GGA06M00_CNFM_MN,
							T_GGA06M00_CNFM_DTM,
							T_GGA06M00_CUST_CD,
							T_GGA06M00_SUP_PRI_AMT,
							T_GGA06M00_VAT_AMT,
							T_GGA06M00_EVI_TP,
							T_GGA06M00_EVI_DT,
							T_GGA06M00_EVI_NO,
							T_GGA06M00_TAXB_NO,
							T_GGA06M00_ORIG_ACNT_NO,
							T_GGA06M00_ORIG_TRD_DT,
							T_GGA06M00_ORIG_TRD_SEQ_NO,
							T_GGA06M00_RECV_SND_NO,
							T_GGA06M00_WORK_MN,
							T_GGA06M00_WORK_DTM,
							T_GGA06M00_WORK_TRM );

			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA06M00_INS;
			    END;

	        END LOOP;   -- C12 End Loop

	        -- =============
	        -- 전표승인처리 : GGA08M00(DAILY STATISTICS) APPLY , 전표상태 ==> 승인(2)
	        -- 일계반영
	        -- =============
	        VN.PGG_SLIP_APPROVAL(
				'A',                     -- 'A' : Approval, 'C' : Approval Cancel, 'R' :Return, 'X' : DisUse
				T_GGA06M00_BRCH_CD,      -- PROCESSING BRANCH CODE
				T_GGA06M00_AGNC_BRCH,    -- PROCESSING BRANCH CODE(AGNC)
				T_GGA06M00_SLIP_DT,      -- SLIP DATE
				T_GGA06M00_SLIP_NO,      -- SLIP No.
				I_WORK_MN );

	        -- U_4. 상세순번 발번
			SELECT	LPAD(TO_CHAR(TO_NUMBER(NVL(MAX(DETL_SN), 0)) + 1), 3, '0')
			  INTO  T_DETL_SN
			  FROM	VN.GGA16M01
			 WHERE	RITS_YM  	=	SUBSTR(I_YYMM, 1, 6)
			   AND	BRCH_CD		=   I_BRCH_CD
			   AND	AGNC_BRCH	=	I_AGNC_BRCH
			   AND	RITS_SN		=	T_RITS_SN ;

        	-- U_5. 월결산이력Master Insert
			BEGIN
     	       INSERT
      	        INTO  VN.GGA16M01(
     	              RITS_YM,
        	          BRCH_CD,
	                  AGNC_BRCH,
    	              RITS_SN,
    	              DETL_SN,
        	          WORK_KND,
            	      SLIP_DT,
                	  SLIP_NO,
                   	  CNCL_YN,
                      WORK_MN,
                      WORK_DTM,
                      WORK_TRM )
              VALUES  (I_YYMM,
                  	   I_BRCH_CD,
                       I_AGNC_BRCH,
                       T_RITS_SN,
                       T_DETL_SN,
                       C11.WORK_KND,
                       T_GGA06M00_SLIP_DT,
                       T_GGA06M00_SLIP_NO,
                       'N',
                       I_WORK_MN,
                       SYSDATE,
                       I_WORK_TRM );

		    EXCEPTION WHEN OTHERS THEN
		        RAISE ERR_GGA16M01_INS;
	    	END;

	        -- U_4. 대체금액 집계
			SELECT	NVL(SUM(v11.TOT_PFT_EXCH_CNT), 0)	AS	TOT_PFT_EXCH_CNT,
					NVL(SUM(v11.TOT_PFT_EXCH_AMT), 0)	AS	TOT_PFT_EXCH_AMT,
					NVL(SUM(v11.TOT_CST_EXCH_CNT), 0)	AS	TOT_CST_EXCH_CNT,
					NVL(SUM(v11.TOT_CST_EXCH_AMT), 0)	AS	TOT_CST_EXCH_AMT
			  INTO  T_GGA16M00_TOT_PFT_EXCH_CNT,
    				T_GGA16M00_TOT_PFT_EXCH_AMT,
    				T_GGA16M00_TOT_CST_EXCH_CNT,
    				T_GGA16M00_TOT_CST_EXCH_AMT
			  FROM
					(	SELECT	1						AS	TOT_PFT_EXCH_CNT,
								NVL(v21.SLIP_AMT, 0)	AS	TOT_PFT_EXCH_AMT,
								0						AS	TOT_CST_EXCH_CNT,
								0						AS	TOT_CST_EXCH_AMT
						  FROM	VN.GGA06M00	v21		/* 회계전표 */
						 WHERE	v21.SLIP_DT		=	T_LAST_DAY
						   AND	v21.BRCH_CD		=	I_BRCH_CD
						   AND	v21.AGNC_BRCH	=	I_AGNC_BRCH
						   AND	v21.SLIP_NO		IN	(	SELECT	SLIP_NO
														  FROM	VN.GGA16M01
														 WHERE	RITS_YM		=	I_YYMM
														   AND	BRCH_CD		=	I_BRCH_CD
														   AND	AGNC_BRCH	=	I_AGNC_BRCH
														   AND	RITS_SN		=	T_RITS_SN )
						   AND	v21.DR_CR_TP	=	'1'
						   AND	(v21.ACC_ACT_CD	IN	(	SELECT	v31.ACC_ACT_CD		AS	ACC_ACT_CD
														  FROM	VN.GGA02C00	v31,
																(	SELECT	v41.ACC_ACT_CD		AS	ACC_ACT_CD,
																			v41.ACT_UNIT_TP		AS	ACT_UNIT_TP
																	  FROM	VN.GGA02C00	v41
																	 WHERE	v41.ACC_ACT_CD	=	K_500
																)			v32
														 WHERE	v32.ACC_ACT_CD	=	DECODE(v32.ACT_UNIT_TP,
																						'1', v31.LVL1_CD, '2', v31.LVL2_CD,
																						'3', v31.LVL3_CD, '4', v31.LVL4_CD,
																						'5', v31.LVL5_CD, v31.ACC_ACT_CD)
														   AND	NVL(v31.SLIP_OCUR_YN, 'N')	=	'Y'
													)
						    OR	v21.ACC_ACT_CD	IN	(	SELECT	v31.ACC_ACT_CD		AS	ACC_ACT_CD
														  FROM	VN.GGA02C00	v31,
																(	SELECT	v41.ACC_ACT_CD		AS	ACC_ACT_CD,
																			v41.ACT_UNIT_TP		AS	ACT_UNIT_TP
																	  FROM	VN.GGA02C00	v41
																	 WHERE	v41.ACC_ACT_CD	=	K_700
																)			v32
														 WHERE	v32.ACC_ACT_CD	=	DECODE(v32.ACT_UNIT_TP,
																						'1', v31.LVL1_CD, '2', v31.LVL2_CD,
																						'3', v31.LVL3_CD, '4', v31.LVL4_CD,
																						'5', v31.LVL5_CD, v31.ACC_ACT_CD)
														   AND	NVL(v31.SLIP_OCUR_YN, 'N')	=	'Y'
													))
					UNION ALL
						SELECT	0						AS	TOT_PFT_EXCH_CNT,
								0						AS	TOT_PFT_EXCH_AMT,
								1						AS	TOT_CST_EXCH_CNT,
								NVL(v21.SLIP_AMT, 0)	AS	TOT_CST_EXCH_AMT
						  FROM	VN.GGA06M00	v21		/* 회계전표 */
						 WHERE	v21.SLIP_DT		=	T_LAST_DAY
						   AND	v21.BRCH_CD		=	I_BRCH_CD
						   AND	v21.AGNC_BRCH	=	I_AGNC_BRCH
						   AND	v21.SLIP_NO		IN	(	SELECT	SLIP_NO
														  FROM	VN.GGA16M01
														 WHERE	RITS_YM		=	I_YYMM
														   AND	BRCH_CD		=	I_BRCH_CD
														   AND	AGNC_BRCH	=	I_AGNC_BRCH
														   AND	RITS_SN		=	T_RITS_SN )
						   AND	v21.DR_CR_TP	=	'2'
						   AND	(v21.ACC_ACT_CD	IN	(	SELECT	v31.ACC_ACT_CD		AS	ACC_ACT_CD
														  FROM	VN.GGA02C00	v31,
																(	SELECT	v41.ACC_ACT_CD		AS	ACC_ACT_CD,
																			v41.ACT_UNIT_TP		AS	ACT_UNIT_TP
																	  FROM	VN.GGA02C00	v41
																	 WHERE	v41.ACC_ACT_CD	=	K_600
																)			v32
														 WHERE	v32.ACC_ACT_CD	=	DECODE(v32.ACT_UNIT_TP,
																						'1', v31.LVL1_CD, '2', v31.LVL2_CD,
																						'3', v31.LVL3_CD, '4', v31.LVL4_CD,
																						'5', v31.LVL5_CD, v31.ACC_ACT_CD)
														   AND	NVL(v31.SLIP_OCUR_YN, 'N')	=	'Y'
													)
						    OR	v21.ACC_ACT_CD	IN	(	SELECT	v31.ACC_ACT_CD		AS	ACC_ACT_CD
														  FROM	VN.GGA02C00	v31,
																(	SELECT	v41.ACC_ACT_CD		AS	ACC_ACT_CD,
																			v41.ACT_UNIT_TP		AS	ACT_UNIT_TP
																	  FROM	VN.GGA02C00	v41
																	 WHERE	v41.ACC_ACT_CD	=	K_800
																)			v32
														 WHERE	v32.ACC_ACT_CD	=	DECODE(v32.ACT_UNIT_TP,
																						'1', v31.LVL1_CD, '2', v31.LVL2_CD,
																						'3', v31.LVL3_CD, '4', v31.LVL4_CD,
																						'5', v31.LVL5_CD, v31.ACC_ACT_CD)
														   AND	NVL(v31.SLIP_OCUR_YN, 'N')	=	'Y'
													))
					)			v11 ;

	        -- U_4. 대체금액 저장
			BEGIN
                UPDATE  VN.GGA16M00
                   SET  TOT_PFT_EXCH_CNT  =   T_GGA16M00_TOT_PFT_EXCH_CNT,
                        TOT_PFT_EXCH_AMT  =   T_GGA16M00_TOT_PFT_EXCH_AMT,
                        TOT_CST_EXCH_CNT  =   T_GGA16M00_TOT_CST_EXCH_CNT,
                        TOT_CST_EXCH_AMT  =   T_GGA16M00_TOT_CST_EXCH_AMT
				 WHERE	RITS_YM  	=	SUBSTR(I_YYMM, 1, 6)
				   AND	BRCH_CD		=   I_BRCH_CD
				   AND	AGNC_BRCH	=	I_AGNC_BRCH
				   AND	RITS_SN		=	T_RITS_SN ;

		    EXCEPTION WHEN OTHERS THEN
		        RAISE ERR_GGA16M00_UPD;
		    END;

        END LOOP;   -- C11 End Loop


        -- U_6. 일계에서 자본자동전표발췌(911)
        FOR C21 IN
        	(	SELECT	v11.WORK_KND				AS	WORK_KND,
						CASE
							WHEN	NVL(v11.CUR_AMT, 0)	>	0	THEN	'941'
							ELSE	'942'
						END							AS	RMRK_TRD_TP,
						CASE
							WHEN	NVL(v11.CUR_AMT, 0)	>	0	THEN	'2'
							ELSE	'1'
						END							AS	DR_CR_TP,
						v11.ACC_ACT_CD				AS	ACC_ACT_CD,
						ABS(NVL(v11.CUR_AMT, 0))	AS	CUR_AMT
				  FROM
						(	SELECT	v21.WORK_KND				AS	WORK_KND,
									v21.ACC_ACT_CD				AS	ACC_ACT_CD,
									CASE
										WHEN	v22.DR_CR_TP	=	'1'	THEN
												NVL(v21.CUR_DR_AMT, 0) - NVL(v21.CUR_CR_AMT, 0)
										ELSE	NVL(v21.CUR_CR_AMT, 0) - NVL(v21.CUR_DR_AMT, 0)
									END							AS	CUR_AMT
							  FROM
									(	SELECT	'5'									AS	WORK_KND,
												v31.ACC_ACT_CD						AS	ACC_ACT_CD,
												NVL(SUM(v31.DR_EXCH_AMT), 0) +
													NVL(SUM(v31.DR_CASH_AMT), 0)	AS	CUR_DR_AMT,		/* 현차변금액 */
												NVL(SUM(v31.CR_EXCH_AMT), 0) +
													NVL(SUM(v31.CR_CASH_AMT), 0)	AS	CUR_CR_AMT		/* 현대변금액 */
										  FROM	VN.GGA08M00	v31		/* 회계일계 */
										 WHERE	v31.ACC_CLS_DT	>=	SUBSTR(I_YYMM, 1, 6) || '01'
										   AND	v31.ACC_CLS_DT	<=	T_LAST_DAY
										   AND	v31.BRCH_CD		=	I_BRCH_CD
										   AND	v31.AGNC_BRCH	=	I_AGNC_BRCH
										   AND	v31.ACC_ACT_CD	IN	(	SELECT	v41.ACC_ACT_CD		AS	ACC_ACT_CD
																		  FROM	VN.GGA02C00	v41,
																				(	SELECT	v51.ACC_ACT_CD		AS	ACC_ACT_CD,
																							v51.ACT_UNIT_TP		AS	ACT_UNIT_TP
																					  FROM	VN.GGA02C00	v51
																					 WHERE	v51.ACC_ACT_CD	=	K_911
																				)			v42
																		 WHERE	v42.ACC_ACT_CD	=	DECODE(v42.ACT_UNIT_TP,
																										'1', v41.LVL1_CD, '2', v41.LVL2_CD,
																										'3', v41.LVL3_CD, '4', v41.LVL4_CD,
																										'5', v41.LVL5_CD, v41.ACC_ACT_CD)
																		   AND	NVL(v41.SLIP_OCUR_YN, 'N')	=	'Y'
																	)
									  GROUP BY	v31.ACC_ACT_CD
									)			v21,
									VN.GGA02C00	v22
							 WHERE	v21.ACC_ACT_CD	=	v22.ACC_ACT_CD
						)			v11
				 WHERE	NVL(v11.CUR_AMT, 0)	<>	0
			  ORDER BY	v11.WORK_KND,
						v11.ACC_ACT_CD
            ) LOOP


            -- U_7. 전표지정 실계정
			T_GGA06M00_SLIP_DT      := T_LAST_DAY;		--전표일자
			T_GGA06M00_BRCH_CD      := I_BRCH_CD;		--지점코드
			T_GGA06M00_AGNC_BRCH    := I_AGNC_BRCH;		--대리지점
			T_GGA06M00_SLIP_NO		:= VN.FGG_GET_SLIP_NO(I_BRCH_CD, I_AGNC_BRCH, T_LAST_DAY, K_SLIP_TP);  --전표번호

            T_GGA06M00_RMRK_JOB_TP  := K_RMRK_JOB_TP;	--적요업무구분
            T_GGA06M00_SLIP_TP      := K_SLIP_TP;		--적요입출구분
            T_GGA06M00_ACC_RMRK_CD  := K_RMRK_JOB_TP || C21.RMRK_TRD_TP || '10';          	--적요코드

			T_GGA06M00_TRD_CNTE     := 'và chuyển khoản thành vốn(' || SUBSTR(C21.ACC_ACT_CD, 1, 3) || '=>4212)';       --거래비고
			T_GGA06M00_DETL_CNTE    := 'và chuyển khoản thành vốn(' || SUBSTR(C21.ACC_ACT_CD, 1, 3) || '=>4212)';       --상세비고

            T_GGA06M00_OPR_BNH_CD   := NULL;           	--상대부점코드
            T_GGA06M00_OPR_AGNC_BRCH := NULL;        	--상대부점코드(출장소)
			T_GGA06M00_SLIP_AMT     := C21.CUR_AMT; 		--전표금액
            T_GGA06M00_RECV_SND_TP  := '9'; 			--수발신 구분
            T_GGA06M00_RECV_YN      := NULL;            --수신여부
            T_GGA06M00_AUTO_TP      := '1';            	--자동구분(1:자동전표,2:수기전표)
            T_GGA06M00_SLIP_STAT    := '1';            	--전표상태(1:미승인,2:승인,3:반려,4:취소)
            T_GGA06M00_DRAF_MN      := I_WORK_MN;     	--기안자
            T_GGA06M00_DRAF_DTM     := SYSDATE;       	--기안일시
            T_GGA06M00_CNFM_MN      := NULL;           	--승인자
            T_GGA06M00_CNFM_DTM     := NULL;           	--승인일시
            T_GGA06M00_CUST_CD      := '0000000000';  	--고객코드
            T_GGA06M00_SUP_PRI_AMT  := NULL;           	--공급가액
            T_GGA06M00_VAT_AMT      := NULL;           	--부가세액
            T_GGA06M00_EVI_TP       := NULL;           	--증빙구분
            T_GGA06M00_EVI_DT       := NULL;           	--증빙일자
            T_GGA06M00_EVI_NO       := NULL;           	--증빙번호
            T_GGA06M00_TAXB_NO      := NULL;           	--세무번호
            T_GGA06M00_ORIG_ACNT_NO := NULL;           	--원천계좌번호
            T_GGA06M00_ORIG_TRD_DT  := NULL;          	--원천거래일
            T_GGA06M00_ORIG_TRD_SEQ_NO := NULL;        	--원천거래일련번호
            T_GGA06M00_RECV_SND_NO  := NULL;           	--수신발신번호
            T_GGA06M00_WORK_MN      := I_WORK_MN;      	--처리자
            T_GGA06M00_WORK_DTM     := SYSDATE;        	--처리일시
            T_GGA06M00_WORK_TRM     := I_WORK_TRM;     	--처리단말

	        FOR C22 IN
				(	SELECT	v21.NO		AS	NO
					  FROM
							(	SELECT	1	AS	NO	FROM	DUAL
							UNION ALL
								SELECT	2	AS	NO	FROM	DUAL
							)			v21
				  ORDER BY	v21.NO
	            ) LOOP

	            T_GGA06M00_SLIP_SUB_NO  := TO_CHAR(C22.NO,'FM000');			--전표부번호

            	IF  C22.NO =	1 THEN
		            T_GGA06M00_DR_CR_TP     := C21.DR_CR_TP;     --차대구분
					T_GGA06M00_ACC_ACT_CD   := C21.ACC_ACT_CD;   --계정
            	ELSE
					IF	C21.DR_CR_TP	=	'1'	THEN
		            	T_GGA06M00_DR_CR_TP     := '2';     --차대구분
					ELSE
		            	T_GGA06M00_DR_CR_TP     := '1';     --차대구분
					END IF;
					T_GGA06M00_ACC_ACT_CD   := K_421;   --계정
            	END IF;

	        	-- U_5. 회계전표 Insert
				BEGIN
		            INSERT
		              INTO  VN.GGA06M00(
							SLIP_DT,                --전표일자
							BRCH_CD,                --지점코드
							AGNC_BRCH,              --대리지점
							SLIP_NO,                --전표번호
							SLIP_SUB_NO,            --전표부번호
							RMRK_JOB_TP,            --적요업무구분
							SLIP_TP,                --전표구분
							ACC_RMRK_CD,            --회계적요코드
							TRD_CNTE,               --거래비고
							DR_CR_TP,               --차변대변구분
							ACC_ACT_CD,             --회계계정코드
							OPR_BNH_CD,             --상대부점코드
							OPR_AGNC_BRCH,          --상대대리지점
							SLIP_AMT,               --전표금액
							DETL_CNTE,              --상세비고
							RECV_SND_TP,            --수신발신구분
							RECV_YN,                --수신여부
							AUTO_TP,                --자동구분
							SLIP_STAT,              --전표상태
							DRAF_MN,                --기안자
							DRAF_DTM,               --기안일시
							CNFM_MN,                --승인자
							CNFM_DTM,               --승인일시
							CUST_CD,                --거래처코드
							SUP_PRI_AMT,            --공급가액
							VAT_AMT,                --부가세액
							EVI_TP,                 --증빙구분
							EVI_DT,                 --증빙일자
							EVI_NO,                 --증빙번호
							TAXB_NO,                --세무번호
							ORIG_ACNT_NO,           --원천계좌번호
							ORIG_TRD_DT,            --원천거래일
							ORIG_TRD_SEQ_NO,        --원천거래일련번호
							RECV_SND_NO,            --수신발신번호
							WORK_MN,                --처리자
							WORK_DTM,               --처리일시
							WORK_TRM )              --처리단말
	     	       VALUES  (T_GGA06M00_SLIP_DT,
							T_GGA06M00_BRCH_CD,
							T_GGA06M00_AGNC_BRCH,
							T_GGA06M00_SLIP_NO,
							T_GGA06M00_SLIP_SUB_NO,
							T_GGA06M00_RMRK_JOB_TP,
							T_GGA06M00_SLIP_TP,
							T_GGA06M00_ACC_RMRK_CD,
							T_GGA06M00_TRD_CNTE,
							T_GGA06M00_DR_CR_TP,
							T_GGA06M00_ACC_ACT_CD,
							T_GGA06M00_OPR_BNH_CD,
							T_GGA06M00_OPR_AGNC_BRCH,
							T_GGA06M00_SLIP_AMT,
							T_GGA06M00_DETL_CNTE,
							T_GGA06M00_RECV_SND_TP,
							T_GGA06M00_RECV_YN,
							T_GGA06M00_AUTO_TP,
							T_GGA06M00_SLIP_STAT,
							T_GGA06M00_DRAF_MN,
							T_GGA06M00_DRAF_DTM,
							T_GGA06M00_CNFM_MN,
							T_GGA06M00_CNFM_DTM,
							T_GGA06M00_CUST_CD,
							T_GGA06M00_SUP_PRI_AMT,
							T_GGA06M00_VAT_AMT,
							T_GGA06M00_EVI_TP,
							T_GGA06M00_EVI_DT,
							T_GGA06M00_EVI_NO,
							T_GGA06M00_TAXB_NO,
							T_GGA06M00_ORIG_ACNT_NO,
							T_GGA06M00_ORIG_TRD_DT,
							T_GGA06M00_ORIG_TRD_SEQ_NO,
							T_GGA06M00_RECV_SND_NO,
							T_GGA06M00_WORK_MN,
							T_GGA06M00_WORK_DTM,
							T_GGA06M00_WORK_TRM );

			    EXCEPTION WHEN OTHERS THEN
			        RAISE ERR_GGA06M00_INS;
			    END;

	        END LOOP;   -- C22 End Loop

	        -- =============
	        -- 전표승인처리 : GGA08M00(DAILY STATISTICS) APPLY , 전표상태 ==> 승인(2)
	        -- 일계반영
	        -- =============
	        VN.PGG_SLIP_APPROVAL(
				'A',                     -- 'A' : Approval, 'C' : Approval Cancel, 'R' :Return, 'X' : DisUse
				T_GGA06M00_BRCH_CD,      -- PROCESSING BRANCH CODE
				T_GGA06M00_AGNC_BRCH,    -- PROCESSING BRANCH CODE(AGNC)
				T_GGA06M00_SLIP_DT,      -- SLIP DATE
				T_GGA06M00_SLIP_NO,      -- SLIP No.
				I_WORK_MN );

	        -- U_4. 상세순번 발번
			SELECT	LPAD(TO_CHAR(TO_NUMBER(NVL(MAX(DETL_SN), 0)) + 1), 3, '0')
			  INTO  T_DETL_SN
			  FROM	VN.GGA16M01
			 WHERE	RITS_YM  	=	SUBSTR(I_YYMM, 1, 6)
			   AND	BRCH_CD		=   I_BRCH_CD
			   AND	AGNC_BRCH	=	I_AGNC_BRCH
			   AND	RITS_SN		=	T_RITS_SN ;

        	-- U_5. 월결산이력Master Insert
			BEGIN
     	       INSERT
      	        INTO  VN.GGA16M01(
     	              RITS_YM,
        	          BRCH_CD,
	                  AGNC_BRCH,
    	              RITS_SN,
    	              DETL_SN,
        	          WORK_KND,
            	      SLIP_DT,
                	  SLIP_NO,
                   	  CNCL_YN,
                      WORK_MN,
                      WORK_DTM,
                      WORK_TRM )
              VALUES  (I_YYMM,
                  	   I_BRCH_CD,
                       I_AGNC_BRCH,
                       T_RITS_SN,
                       T_DETL_SN,
                       C21.WORK_KND,
                       T_GGA06M00_SLIP_DT,
                       T_GGA06M00_SLIP_NO,
                       'N',
                       I_WORK_MN,
                       SYSDATE,
                       I_WORK_TRM );

		    EXCEPTION WHEN OTHERS THEN
		        RAISE ERR_GGA16M01_INS;
	    	END;

			BEGIN
                UPDATE  VN.GGA16M00
                   SET  TOT_CAP_EXCH_AMT  =   C21.CUR_AMT
				 WHERE	RITS_YM  	=	SUBSTR(I_YYMM, 1, 6)
				   AND	BRCH_CD		=   I_BRCH_CD
				   AND	AGNC_BRCH	=	I_AGNC_BRCH
				   AND	RITS_SN		=	T_RITS_SN ;

		    EXCEPTION WHEN OTHERS THEN
		        RAISE ERR_GGA16M00_UPD;
		    END;

        END LOOP;   -- C21 End Loop


    -- *********************
    -- * 회   계   취   소 *
    -- *********************
    ELSIF   I_FLAG  =   'D' THEN

        -- U_1. 회계월마감체크(당월)
        T_CNT   := 0 ;
		SELECT	COUNT(*)
		  INTO  T_CNT
		  FROM	VN.GGA11M00
		 WHERE	TERMS		=	T_TERMS
		   AND	CLS_YM		=	SUBSTR(I_YYMM, 1, 6)
		   AND	BRCH_CD		=   I_BRCH_CD
		   AND	AGNC_BRCH	=	I_AGNC_BRCH
       	   AND	NVL(ACC_CLS_YN, 'N')	=	'Y' ;

        IF  T_CNT   >=  1   THEN
            RAISE ERR_GGA11M00_1;
        END IF;

        -- U_2. 회계일마감체크
        T_CNT   := 0 ;
		SELECT	COUNT(*)
		  INTO  T_CNT
		  FROM	VN.GGA10M00
		 WHERE	ACC_CLS_DT  =	T_LAST_DAY
		   AND	BRCH_CD		=   I_BRCH_CD
		   AND	AGNC_BRCH	=	I_AGNC_BRCH
       	   AND	NVL(ACC_CLS_YN, 'N')	=	'Y' ;

        IF  T_CNT   >=  1   THEN
            RAISE ERR_GGA10M00;
        END IF;

        -- U_3. 기존결산처리건 체크
        T_CNT   := 0 ;
		SELECT	COUNT(*)
		  INTO  T_CNT
		  FROM	VN.GGA16M00
		 WHERE	RITS_YM		=	I_YYMM
		   AND	BRCH_CD		=	I_BRCH_CD
		   AND	AGNC_BRCH	=	I_AGNC_BRCH
		   AND	RITS_SN		=	I_RITS_SN
		   AND	NVL(CNCL_YN, 'N')	=	'Y' ;

        IF  T_CNT   >=  1   THEN
            RAISE ERR_GGA16M00_SEL;
        END IF;


        -- U_6. 전표에서 손익자동전표발췌(5XX,7XX,6XX,8XX,4212)
        FOR C31 IN
			(	SELECT	DETL_SN,	SLIP_NO
				  FROM	VN.GGA16M01
				 WHERE	RITS_YM		=	I_YYMM
				   AND	BRCH_CD		=	I_BRCH_CD
				   AND	AGNC_BRCH	=	I_AGNC_BRCH
				   AND	RITS_SN		=	I_RITS_SN
            ) LOOP

	        -- =============
	        -- 전표취소처리 : GGA08M00(DAILY STATISTICS) APPLY , 전표상태 ==> 승인(2)
	        -- 일계반영
	        -- =============
	        VN.PGG_CNCL_VOUCHER(
				T_LAST_DAY,				-- 전표일자
				I_BRCH_CD,      		-- 지점코드
				I_AGNC_BRCH,    		-- 대리지점
				C31.SLIP_NO,      		-- 전표번호
				T_PROC_CNT );

	        -- U_4. 월결산이력Detail 저장
			BEGIN
                UPDATE  VN.GGA16M01
                   SET  CNCL_YN  =   'Y',
                        CNCL_MN  =   I_WORK_MN,
                        CNCL_DTM =   SYSDATE,
                        CNCL_TRM =   I_WORK_TRM
				 WHERE	RITS_YM  	=	I_YYMM
				   AND	BRCH_CD		=   I_BRCH_CD
				   AND	AGNC_BRCH	=	I_AGNC_BRCH
				   AND	RITS_SN		=	I_RITS_SN
				   AND	DETL_SN		=	C31.DETL_SN ;

		    EXCEPTION WHEN OTHERS THEN
		        RAISE ERR_GGA16M01_UPD;
		    END;

        END LOOP;   -- C31 End Loop

        -- U_4. 월결산이력Master 저장
		BEGIN
            UPDATE  VN.GGA16M00
               SET  CNCL_YN  =   'Y',
                    CNCL_MN  =   I_WORK_MN,
                    CNCL_DTM =   SYSDATE,
                    CNCL_TRM =   I_WORK_TRM
			 WHERE	RITS_YM  	=	I_YYMM
			   AND	BRCH_CD		=   I_BRCH_CD
			   AND	AGNC_BRCH	=	I_AGNC_BRCH
			   AND	RITS_SN		=	I_RITS_SN ;

	    EXCEPTION WHEN OTHERS THEN
	        RAISE ERR_GGA16M00_UPD;
	    END;

    END IF;

    O_RTN_TBL  :=  'GGA11M00';
    O_RTN_ERR  :=  '0';
    IF  I_FLAG  =   'U' THEN
        --O_RTN_MSG  :=  '[V0602]회계마감 성공! ==> 정상적으로 처리되었습니다.';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','0602');
    ELSIF   I_FLAG  =   'D' THEN
        --O_RTN_MSG  :=  '[V0603]회계마감 취소 성공! ==> 정상적으로 처리되었습니다.';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','0603');
    END IF;
    --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);

EXCEPTION
    WHEN    ERR_GGA11M00_1  THEN
        O_RTN_TBL  :=  'GGA11M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2616]이미 회계 월마감이 완료되었습니다! [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2616') || ' [' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA10M00  THEN
        O_RTN_TBL  :=  'GGA10M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2617]이미 회계 일마감이 완료되었습니다! [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2617') || ' [' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA06M00_INS  THEN
        O_RTN_TBL  :=  'GGA06M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2627]전표번호 생성중 오류가 발생하였습니다. [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2627') || ' [' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA16M00_SEL  THEN
        O_RTN_TBL  :=  'GGA16M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V2022]처리할 내용이 없습니다 [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','2022') || ' [' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA16M00_INS  THEN
        O_RTN_TBL  :=  'GGA16M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V9008]입력 처리중 오류발생 했습니다 [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','9008') || ' [' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA16M00_UPD  THEN
        O_RTN_TBL  :=  'GGA16M00';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V9006]수정 처리중 오류발생 했습니다. [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','9006') || ' [' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA16M01_INS  THEN
        O_RTN_TBL  :=  'GGA16M01';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  '[V9008]입력 처리중 오류발생 했습니다 [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','9008') || ' [' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_GGA16M01_UPD  THEN
        O_RTN_TBL  :=  'GGA16M01';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        --O_RTN_MSG  :=  'V9006]수정 처리중 오류발생 했습니다. [' || I_BRCH_CD || ']';
        O_RTN_MSG  :=  VN.FXC_GET_ERR_MSG('V','9006') || ' [' || I_BRCH_CD || ']';
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    ERR_COMMON  THEN
        O_RTN_TBL  :=  'COMMON';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        O_RTN_MSG  :=  'ERROR ' || SUBSTR(SQLERRM, 1, 100);
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
    WHEN    OTHERS  THEN
        O_RTN_TBL  :=  'OTHERS';
        O_RTN_ERR  :=  TO_CHAR(SQLCODE);
        O_RTN_MSG  :=  'ERROR ' || SUBSTR(SQLERRM, 1, 100);
        --RAISE_APPLICATION_ERROR(-20100, O_RTN_MSG);
END PGG_ACC_MON_RITS;
/

