create procedure pss_bk_ubk_rgt_tax_qty
( i_tp       in varchar2,
  i_acnt_no  in varchar2,
  i_stk_cd   in varchar2,
  i_qty      in number,
  i_work_mn  in varchar2,
  i_work_trm in varchar2)
as
/* *******************************************************************
  Muc dich: Phong toa, giai toa so luong CPT,Co tuc bang CP can tinh thue

  i_tp: Phan loai nghiep vu can thao tac
    11: Phong toa SL TDCN
    12: Phong toa SL HCCN
    13: Phong toa SL Cho GD TDCN
    14: Phong toa SL Cho GD HCCN
    21: Giai toa SL TDCN
    22: Giai toa SL HCCN
    23: Giai toa SL Cho GD TDCN
    24: Giai toa SL Cho GD HCCN

  Lich su thay doi:
  16-Dec-2020 vnjvthangnm Khoi tao thu tuc.
******************************************************************* */
  v_wtax_qty            number := 0;
  v_wtax_sb_lim_qty     number := 0;
  v_wtax_delay_qty      number := 0;
  v_wtax_delay_sb_qty   number := 0;

  t_qty                 number := 0;
  t_cnte                varchar2(500);
  --t_stk_trd_tp          varchar2(100);
begin

  vn.pxc_log_write('pss_bk_ubk_rgt_tax_qty','Bat dau xu ly cho tai khoan: ' || i_acnt_no || ', MaCK: ' || i_stk_cd || ', SL: ' || to_char(i_qty) || ', type: ' || i_tp);

  if i_tp = '11' then
    v_wtax_qty    := i_qty;
    --t_stk_trd_tp  := 'TDCN';

    begin
      select tax_qty - wtax_qty - v_wtax_qty
        into t_qty
        from ssb05m10
       where acnt_no = i_acnt_no
         and stk_cd  = i_stk_cd;
    exception
      when no_data_found then
        vn.pxc_log_write('pss_bk_ubk_rgt_tax_qty','Phong toa: Khong co du lieu TDCN cho tai khoan: '||i_acnt_no ||', stk_cd: '||i_stk_cd);
        raise_application_error(-20100,'Tai khoan ' || i_acnt_no || ' chua co SL TDCN can tinh thue cho ma ' || i_stk_cd);
    end;
    if t_qty < 0 then
      vn.pxc_log_write('pss_bk_ubk_rgt_tax_qty','SL phong toa TDCN cho tai khoan:' || i_acnt_no || ', ma: ' || i_stk_cd || ' qua nhieu!!!');
      raise_application_error(-20100,'SL phong toa TDCN cho tai khoan: ' || i_acnt_no || ', ma: ' || i_stk_cd || ' qua nhieu!!!');
    end if;

  elsif i_tp = '12' then
    v_wtax_sb_lim_qty := i_qty;
    --t_stk_trd_tp      := 'HCCN';

    begin
      select tax_sb_lim_qty - wtax_sb_lim_qty - v_wtax_sb_lim_qty
        into t_qty
        from ssb05m10
       where acnt_no = i_acnt_no
         and stk_cd  = i_stk_cd;
    exception
      when no_data_found then
        vn.pxc_log_write('pss_bk_ubk_rgt_tax_qty','Phong toa: Khong co du lieu HCCN cho tai khoan: '||i_acnt_no ||', stk_cd: '||i_stk_cd);
        raise_application_error(-20100,'Tai khoan ' || i_acnt_no || ' chua co SL HCCN can tinh thue cho ma ' || i_stk_cd);
    end;
    if t_qty < 0 then
      vn.pxc_log_write('pss_bk_ubk_rgt_tax_qty','SL phong toa HCCN cho tai khoan:' || i_acnt_no || ', ma: ' || i_stk_cd || ' qua nhieu!!!');
      raise_application_error(-20100,'SL phong toa HCCN cho tai khoan: ' || i_acnt_no || ', ma: ' || i_stk_cd || ' qua nhieu!!!');
    end if;

  elsif i_tp = '13' then
    v_wtax_delay_qty  := i_qty;
    --t_stk_trd_tp      := 'Cho GD TDCN';

    begin
      select tax_delay_qty - wtax_delay_qty - v_wtax_delay_qty
        into t_qty
        from ssb05m10
       where acnt_no = i_acnt_no
         and stk_cd  = i_stk_cd;
    exception
      when no_data_found then
        vn.pxc_log_write('pss_bk_ubk_rgt_tax_qty','Phong toa: Khong co du lieu Cho GD TDCN cho tai khoan: '||i_acnt_no ||', stk_cd: '||i_stk_cd);
        raise_application_error(-20100,'Tai khoan ' || i_acnt_no || ' chua co SL Cho GD TDCN can tinh thue cho ma ' || i_stk_cd);
    end;
    if t_qty < 0 then
      vn.pxc_log_write('pss_bk_ubk_rgt_tax_qty','SL phong toa Cho GD TDCN cho tai khoan:' || i_acnt_no || ', ma: ' || i_stk_cd || ' qua nhieu!!!');
      raise_application_error(-20100,'SL phong toa Cho GD TDCN cho tai khoan: ' || i_acnt_no || ', ma: ' || i_stk_cd || ' qua nhieu!!!');
    end if;

  elsif i_tp = '14' then
    v_wtax_delay_sb_qty := i_qty;
    --t_stk_trd_tp        := 'Cho GD HCCN';

    begin
      select tax_delay_sb_qty - wtax_delay_sb_qty - v_wtax_delay_sb_qty
        into t_qty
        from ssb05m10
       where acnt_no = i_acnt_no
         and stk_cd  = i_stk_cd;
    exception
      when no_data_found then
        vn.pxc_log_write('pss_bk_ubk_rgt_tax_qty','Phong toa: Khong co du lieu Cho GD HCCN cho tai khoan: '||i_acnt_no ||', stk_cd: '||i_stk_cd);
        raise_application_error(-20100,'Tai khoan ' || i_acnt_no || ' chua co SL Cho GD HCCN can tinh thue cho ma ' || i_stk_cd);
    end;
    if t_qty < 0 then
      vn.pxc_log_write('pss_bk_ubk_rgt_tax_qty','SL phong toa Cho GD HCCN cho tai khoan:' || i_acnt_no || ', ma: ' || i_stk_cd || ' qua nhieu!!!');
      raise_application_error(-20100,'SL phong toa Cho GD HCCN cho tai khoan: ' || i_acnt_no || ', ma: ' || i_stk_cd || ' qua nhieu!!!');
    end if;

  elsif i_tp = '21' then
    v_wtax_qty := 0 - i_qty;

    begin
      select wtax_qty - i_qty
        into t_qty
        from ssb05m10
       where acnt_no = i_acnt_no
         and stk_cd  = i_stk_cd;
    exception
      when no_data_found then
        vn.pxc_log_write('pss_bk_ubk_rgt_tax_qty','Giai toa: Khong co du lieu TDCN cho tai khoan: '||i_acnt_no ||', stk_cd: '||i_stk_cd);
        raise_application_error(-20100,'Tai khoan ' || i_acnt_no || ' chua co phong toa cho ma ' || i_stk_cd);
    end;
    if t_qty < 0 then
      vn.pxc_log_write('pss_bk_ubk_rgt_tax_qty','SL giai toa TDCN cho tai khoan:' || i_acnt_no || ', ma: ' || i_stk_cd || ' qua nhieu!!!');
      raise_application_error(-20100,'SL giai toa TDCN cho tai khoan: ' || i_acnt_no || ', ma: ' || i_stk_cd || ' qua nhieu!!!');
    end if;

  elsif i_tp = '22' then
    v_wtax_sb_lim_qty := 0 - i_qty;

    begin
      select wtax_sb_lim_qty - i_qty
        into t_qty
        from ssb05m10
       where acnt_no = i_acnt_no
         and stk_cd  = i_stk_cd;
    exception
      when no_data_found then
        vn.pxc_log_write('pss_bk_ubk_rgt_tax_qty','Giai toa: Khong co du lieu HCCN cho tai khoan: '||i_acnt_no ||', stk_cd: '||i_stk_cd);
        raise_application_error(-20100,'Tai khoan ' || i_acnt_no || ' chua co phong toa cho ma ' || i_stk_cd);
    end;
    if t_qty < 0 then
      vn.pxc_log_write('pss_bk_ubk_rgt_tax_qty','SL giai toa HCCN cho tai khoan:' || i_acnt_no || ', ma: ' || i_stk_cd || ' qua nhieu!!!');
      raise_application_error(-20100,'SL giai toa HCCN cho tai khoan: ' || i_acnt_no || ', ma: ' || i_stk_cd || ' qua nhieu!!!');
    end if;

  elsif i_tp = '23' then
    v_wtax_delay_qty := 0 - i_qty;

    begin
      select wtax_delay_qty - i_qty
        into t_qty
        from ssb05m10
       where acnt_no = i_acnt_no
         and stk_cd  = i_stk_cd;
    exception
      when no_data_found then
        vn.pxc_log_write('pss_bk_ubk_rgt_tax_qty','Giai toa: Khong co du lieu Cho GD TDCN cho tai khoan: '||i_acnt_no ||', stk_cd: '||i_stk_cd);
        raise_application_error(-20100,'Tai khoan ' || i_acnt_no || ' chua co phong toa cho ma ' || i_stk_cd);
    end;
    if t_qty < 0 then
      vn.pxc_log_write('pss_bk_ubk_rgt_tax_qty','SL giai toa Cho GD TDCN cho tai khoan:' || i_acnt_no || ', ma: ' || i_stk_cd || ' qua nhieu!!!');
      raise_application_error(-20100,'SL giai toa Cho GD TDCN cho tai khoan: ' || i_acnt_no || ', ma: ' || i_stk_cd || ' qua nhieu!!!');
    end if;

  elsif i_tp = '24' then
    v_wtax_delay_sb_qty := 0 - i_qty;

    begin
      select wtax_delay_sb_qty - i_qty
        into t_qty
        from ssb05m10
       where acnt_no = i_acnt_no
         and stk_cd  = i_stk_cd;
    exception
      when no_data_found then
        vn.pxc_log_write('pss_bk_ubk_rgt_tax_qty','Giai toa: Khong co du lieu Cho GD HCCN cho tai khoan: '||i_acnt_no ||', stk_cd: '||i_stk_cd);
        raise_application_error(-20100,'Tai khoan ' || i_acnt_no || ' chua co phong toa cho ma ' || i_stk_cd);
    end;
    if t_qty < 0 then
      vn.pxc_log_write('pss_bk_ubk_rgt_tax_qty','SL giai toa Cho GD HCCN cho tai khoan:' || i_acnt_no || ', ma: ' || i_stk_cd || ' qua nhieu!!!');
      raise_application_error(-20100,'SL giai toa Cho GD HCCN cho tai khoan: ' || i_acnt_no || ', ma: ' || i_stk_cd || ' qua nhieu!!!');
    end if;

  end if;

  update ssb05m10
     set wtax_qty           = wtax_qty          + v_wtax_qty,
         wtax_sb_lim_qty    = wtax_sb_lim_qty   + v_wtax_sb_lim_qty,
         wtax_delay_qty     = wtax_delay_qty    + v_wtax_delay_qty,
         wtax_delay_sb_qty  = wtax_delay_sb_qty + v_wtax_delay_sb_qty,
         work_mn            = i_work_mn,
         work_dtm           = sysdate,
         work_trm           = i_work_trm
   where acnt_no = i_acnt_no
     and stk_cd  = i_stk_cd;
--  if sql%rowcount = 0 then
--    vn.pxc_log_write('pss_bk_ubk_rgt_tax_qty','Phong toa: Khong co du lieu ' || t_stk_trd_tp || ' cho tai khoan: '||i_acnt_no ||', stk_cd: '||i_stk_cd);
--    raise_application_error(-20100,'Tai khoan ' || i_acnt_no || ' chua co phong toa cho ma ' || i_stk_cd);
--  end if;

  /* Luu lich su vao bang ssb05h10 */
  if i_tp = '11' then t_cnte := 'Phong toa SL TDCN';
  elsif i_tp = '12' then t_cnte := 'Phong toa SL HCCN';
  elsif i_tp = '13' then t_cnte := 'Phong toa SL Cho GD TDCN';
  elsif i_tp = '14' then t_cnte := 'Phong toa SL Cho GD HCCN';
  elsif i_tp = '21' then t_cnte := 'Giai toa SL TDCN';
  elsif i_tp = '22' then t_cnte := 'Giai toa SL HCCN';
  elsif i_tp = '23' then t_cnte := 'Giai toa SL Cho GD TDCN';
  elsif i_tp = '24' then t_cnte := 'Giai toa SL Cho GD HCCN';
  end if;

  begin
    pss_rgt_tax_history
    ( i_acnt_no  ,
      i_stk_cd   ,
      ''         ,
      t_cnte     ,
      i_work_mn  ,
      i_work_trm
    );
  exception
    when others then
      vn.pxc_log_write('pss_change_rgt_tax_qty','Loi khi chay proc pss_rgt_tax_history.');
      raise_application_error(-20100,'Loi khi chay proc pss_rgt_tax_history.');
  end;

  vn.pxc_log_write('pss_bk_ubk_rgt_tax_qty','Xu ly xong.');
end pss_bk_ubk_rgt_tax_qty;
/

