create procedure pss_crd_loan_rt_proc_td
(   i_stk_cd    in  varchar2,
    i_work_mn   in  varchar2,
    i_work_trm  in  varchar2 default '02001')
as
    v_cnt   number := 0;
    o_ct    number := 0;
    /* *********************************************************************************
    Ten     : pss_crd_loan_rt_proc_td
    Muc dich: Thu tuc thuc hien DGTS khi co yeu cau tu man hinh 02001

    Lich su thay doi:
    09-Sep-2021 vnjvthangnm NHSV-1622: Khoi tao thu tuc
    ********************************************************************************* */
begin
    vn.pxc_log_write('pss_crd_loan_rt_proc_td','Bat dau: ' || to_char(sysdate,'DD-Mon-YYYY HH24:MI:SS'));
    vn.pxc_log_write('pss_crd_loan_rt_proc_td','Bat dau thuc hien DGTS cho ma ' || i_stk_cd ||'-'|| i_work_mn||'-'|| i_work_trm);
    -- DGTS nhung tai khoan bi anh huong
    for c1 in
    ( select a.acnt_no, a.sub_no
        from vn.ssb01m00 a
        where a.own_qty > 0
        and a.stk_cd = i_stk_cd
        and a.sub_no <> '00'
    union
    select b.acnt_no, b.sub_no
        from vn.tso04m00 b
        where b.stk_cd = i_stk_cd
        and b.td_buy_mth_qty + b.pd_buy_mth_qty + b.ppd_buy_mth_qty > 0
        and b.sub_no <> '00')
    loop
        vn.pxc_log_write('pss_crd_loan_rt_proc_td','Danh gia tai san cho ' || c1.acnt_no || '-' || c1.sub_no);
        vn.pdl_crd_loan_rt_proc_td(
            vwdate,
            '2', -- '1':cash  '2':stock  '%':All
            c1.acnt_no,
            c1.sub_no,
            1, -- trd_no
            i_work_mn,
            i_work_trm,
            o_ct);
        v_cnt := v_cnt + 1;
    end loop; -- End DGTS
    vn.pxc_log_write('pss_crd_loan_rt_proc_td','Thuc hien DGTS cho ' || to_char(v_cnt) || ' tai khoan.');
    vn.pxc_log_write('pss_crd_loan_rt_proc_td','Ket thuc: ' || to_char(sysdate,'DD-Mon-YYYY HH24:MI:SS'));
end pss_crd_loan_rt_proc_td;
/

