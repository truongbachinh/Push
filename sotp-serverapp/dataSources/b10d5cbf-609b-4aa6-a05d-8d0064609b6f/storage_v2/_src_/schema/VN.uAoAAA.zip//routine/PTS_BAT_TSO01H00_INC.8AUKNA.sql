create procedure pts_bat_tso01h00_inc (
    i_work_dt       in      varchar2,       -- date(yyyymmdd)
	o_err_code      in      number,         -- error code(0:SUCCESS)
	o_err_msg       in      varchar2        -- error message
) as

t_err_code      number        := o_err_code;
t_err_msg       varchar2(600) := rtrim(o_err_msg);
t_chk           varchar2(1);
t_cnt           number;
exp_error       exception;

/*!
    \file     pts_bat_tso10h00_ins
	\brief    tso01m00 select, tso01h00 insert

	\section intro Program Information
		- Program Name              : pts_bat_tso01h00_inc
		- Service Name              :
		- Related Client Program- Client Program ID :
		- Related Tables            : tso01m00, tso01h00
		- Dev. Date                 : 2007/11/27
		- Developer                 : ejlee
		- Business Logic Desc.      :
		- Latest Modification Date  :

	\section history Program Modification History
		- 1.0  2007/11/27

	\section hardcoding Hard-Coding List

	\section info Additional Reference Comments
*/

begin

	t_err_code := 0;
	t_err_msg  := 'SUCCESS';
	t_chk      := 'N';

	-- 1. �� ��ü��Ϸ��ũ Funüũ

	if t_chk = 'N' then
		t_err_code := 0;
	    t_err_msg  := '�� ��ü��̿Ϸ��ϴ� ü��� � ó����ʽÿ�';
		raise_application_error(-20100,'[pts_bat_tso01h00_inc] ' || t_err_msg);
	else
        for  c1  in (

		    select  bnh_cd                  ,
				    ord_no                  ,
				    acnt_no                 ,
				    stk_cd                  ,
				    ord_qty                 ,
				    ord_pri                 ,
				    ord_knd                 ,
				    sell_buy_tp             ,
				    mkt_trd_tp              ,
				    stk_ord_tp              ,
				    crrt_cncl_tp            ,
				    stk_tp                  ,
				    mdm_tp                  ,
				    prgt_ord_tp             ,
				    ord_time                ,
				    ord_veto_cau            ,
				    ord_accp_time           ,
				    org_ord_no              ,
				    first_org_ord_no        ,
				    cncl_qty                ,
				    crrt_qty                ,
				    cncl_cnfm_qty           ,
				    crrt_cnfm_qty           ,
				    mth_qty                 ,
				    mth_amt                 ,
				    nmth_qty                ,
				    org_ord_pri             ,
				    ord_prof_pri            ,
				    cash_prof_rt            ,
				    frgn_tp                 ,
				    sms_yn                  ,
				    work_bnh                ,
				    kfx_accp_no             ,
				    if_seq_no               ,
				    dat_cd                  ,
				    sesn_tp                 ,
				    accp_tp                 ,
				    agnt_idno               ,
				    work_mn                 ,
				    work_dtm                ,
				    work_trm                ,
				    del_yn
			  from  vn.tso01m00

             ) loop

			 insert into vn.tso01h00
			 (      stk_ord_dt              ,
					bnh_cd                  ,
				    ord_no                  ,
				    acnt_no                 ,
				    stk_cd                  ,
				    ord_qty                 ,
				    ord_pri                 ,
				    ord_knd                 ,
				    sell_buy_tp             ,
				    mkt_trd_tp              ,
				    stk_ord_tp              ,
				    crrt_cncl_tp            ,
				    stk_tp                  ,
				    mdm_tp                  ,
				    prgt_ord_tp             ,
				    ord_time                ,
				    ord_veto_cau            ,
				    ord_accp_time           ,
				    org_ord_no              ,
				    first_org_ord_no        ,
				    cncl_qty                ,
				    crrt_qty                ,
				    cncl_cnfm_qty           ,
				    crrt_cnfm_qty           ,
				    mth_qty                 ,
				    mth_amt                 ,
				    nmth_qty                ,
				    org_ord_pri             ,
				    ord_prof_pri            ,
				    cash_prof_rt            ,
				    frgn_tp                 ,
				    sms_yn                  ,
				    work_bnh                ,
				    kfx_accp_no             ,
				    sesn_tp                 ,
				    accp_tp                 ,
				    agnt_idno               ,
				    work_mn                 ,
				    work_dtm                ,
				    del_yn
            ) values (
			        i_work_dt               ,
					c1.bnh_cd               ,
				    c1.ord_no               ,
				    c1.acnt_no              ,
				    c1.stk_cd               ,
				    c1.ord_qty              ,
				    c1.ord_pri              ,
				    c1.ord_knd              ,
				    c1.sell_buy_tp          ,
				    c1.mkt_trd_tp           ,
				    c1.stk_ord_tp           ,
				    c1.crrt_cncl_tp         ,
				    c1.stk_tp               ,
				    c1.mdm_tp               ,
				    c1.prgt_ord_tp          ,
				    c1.ord_time             ,
				    c1.ord_veto_cau         ,
				    c1.ord_accp_time        ,
				    c1.org_ord_no           ,
				    c1.first_org_ord_no     ,
				    c1.cncl_qty             ,
				    c1.crrt_qty             ,
				    c1.cncl_cnfm_qty        ,
				    c1.crrt_cnfm_qty        ,
				    c1.mth_qty              ,
				    c1.mth_amt              ,
				    c1.nmth_qty             ,
				    c1.org_ord_pri          ,
				    c1.ord_prof_pri         ,
				    c1.cash_prof_rt         ,
				    c1.frgn_tp              ,
				    c1.sms_yn               ,
				    c1.work_bnh             ,
				    c1.kfx_accp_no          ,
				    c1.sesn_tp              ,
				    c1.accp_tp              ,
				    c1.agnt_idno            ,
				    c1.work_mn              ,
				    c1.work_dtm             ,
				    c1.del_yn
            );

        end loop;
		commit;
	end if;

	exception when  exp_error then
		t_err_code := sqlcode;
		t_err_msg  := sqlerrm;
		raise_application_error(-20100,'[pts_bat_tso01h00_inc] ' || t_err_msg);

end pts_bat_tso01h00_inc;
/

