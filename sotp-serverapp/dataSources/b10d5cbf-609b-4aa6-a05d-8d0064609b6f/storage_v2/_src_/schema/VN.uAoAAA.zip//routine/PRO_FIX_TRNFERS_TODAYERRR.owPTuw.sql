create PROCEDURE PRO_FIX_TRNFERS_TODAYERRR
(
       o_cnt out number
)
AS
i_cnt number:=0;
i_chk number:=0;
begin

for c1 in
(
  /*SELECT * FROM CWD11M00 WHERE RMRK_CD = '026' AND STD_DT = VWDATE AND CNCL_YN = 'N'
  AND BANK_DESC = 'Hach toan thanh cong'*/
  select * from aaa10m00 where trd_dt = vwdate and rmrk_cd = '025'
 )
  loop
      pxc_log_write('PRO_FIX_TRNFERS_TODAYERRR','BEGIN TREATE FOR RECEIVER ACCOUNT:'|| c1.acnt_no||' '||c1.sub_no|| 'TRD_SEQ_NO'|| c1.trd_seq_no);
     
     /* begin
           update cwd06m00
          set trd_seq_no = c1.trd_seq_no  
          ,CNTE = c1.cnte
           , CNFM_MN    = c1.user_1100
            , CNFM_DTM   = c1.cnfm_dtm
          where acnt_no = c1.acnt_no
          and sub_no = c1.sub_no 
          and seq_no = c1.seq_cwd06
          and rmrk_cd = '026'
          AND CNCL_YN = 'N'
          and to_char(work_dtm,'yyyymmdd') = vwdate;
          exception
            when others then
              pxc_log_write('PRO_FIX_TRNFERS_TODAYERRR','update cwd06m00 error '|| sqlerrm);
      end; */
      
      begin
        select nvl(count(*) ,0) 
        into i_chk
        from cwd06m00
        where acnt_no = c1.acnt_no
        and rmrk_cd = '025'
        and sub_no = c1.sub_no 
        and trd_amt  = c1.trd_amt
        AND CNCL_YN = 'N'
        and mdm_tp = c1.mdm_tp
        and to_char(work_dtm,'yyyymmdd') = vwdate;
      if i_chk = 1 then 
         update cwd06m00
          set 
          trd_seq_no = c1.trd_seq_no  
          /*CNTE = c1.cnte
           , CNFM_MN    = c1.user_1100
           , CNFM_DTM   = c1.cnfm_dtm*/
          where acnt_no = c1.acnt_no
          and rmrk_cd = '025'
          and sub_no = c1.sub_no 
          and trd_amt  = c1.trd_amt
          AND CNCL_YN = 'N'
          and mdm_tp = c1.mdm_tp
          and to_char(work_dtm,'yyyymmdd') = vwdate;
          i_cnt:=i_cnt+1;
       ELSE
         pxc_log_write('PRO_FIX_TRNFERS_TODAYERRR','CANOT FOUND :'|| c1.acnt_no||' '||c1.sub_no|| 'TRD_SEQ_NO'|| c1.trd_seq_no);  
       end if;
       
          exception
            when others then
              i_cnt := i_cnt - 1;
              pxc_log_write('PRO_FIX_TRNFERS_TODAYERRR','update cwd06m00 1 error '|| sqlerrm);
      
      
      end;
   
    end loop;
    o_cnt := i_cnt;
    
  
  
  end;
/

