create procedure pss_update_TaiSan
(   i_dt             in     varchar2,        --
    i_work_mn        in     varchar2,
    i_work_trm       in     varchar2,
    o_cnt            in out number
 ) is
 --i_acnt_no              varchar2(10) := ' ';
-- i_sub_no         varchar2(2) := ' ';
 vn_commit               number := 0;
 vn_commit2               number := 0;
begin
  o_cnt  := 0;

  for c2 in (
     select distinct t.acnt_no acnt_no from ssb01m00 t where t.own_qty > 0 and t.sub_no = '01'
    ) loop
         vn.pxc_log_write('pss_update_TaiSan', 'start' || '[' ||i_dt || ','|| c2.acnt_no|| ','|| '01' || ']');
         begin
             vn.pdl_crd_loan_rt_proc_td(vn.vwdate
               , '2'
               , c2.acnt_no
               , '01'
               , 0
               , i_work_mn
               , i_work_trm
               , o_cnt);
         end;
         vn_commit := vn_commit + 1;
         vn_commit2 := vn_commit2 + 1;
         o_cnt := o_cnt + 1;
        vn.pxc_log_write('pss_update_TaiSan','vn_commit'||to_char(vn_commit) );
        vn.pxc_log_write('pss_update_TaiSan','vn_commit2'||to_char(vn_commit2) );

        if vn_commit >= 500 then
            vn.pxc_log_write('pss_update_TaiSan', 'I will commit now!');
            vn_commit := 0;
            commit;
        end if;

    vn.pxc_log_write('pss_update_TaiSan', 'finish' || '[' || i_dt || ']');
    end loop;
    commit;
   return;
end pss_update_TaiSan;
/

