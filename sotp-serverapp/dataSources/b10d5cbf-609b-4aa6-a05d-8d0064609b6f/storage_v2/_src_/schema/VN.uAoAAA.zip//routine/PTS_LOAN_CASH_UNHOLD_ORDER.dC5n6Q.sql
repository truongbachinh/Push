create PROCEDURE    pts_loan_cash_unhold_order (
    i_sec_cd        IN VARCHAR2,
    i_acnt_no       IN VARCHAR2,
    i_sub_no        IN VARCHAR2,
    i_ord_no        IN VARCHAR2,
    i_cash_amt      IN NUMBER,
    i_hold_tp       IN NUMBER,
    i_unhold_mode   IN VARCHAR2
)
AS
   /*
       \Developer  : Vo Danh
       \Date           : 2018/06/14
       \Parameter
               - i_ord_no:
                   .) Khi i_unhold_mode = 'CR' -> i_ord_no chinh la so hieu cua lenh can un-hold
                   .) Khi i_unhold_mode <> 'CR' -> i_ord_no chinh la
                           + So hieu cua lenh can un-hold voi truong hop lenh moi
                           + SHL cua lenh duoc tao ra (lenh huy hoac sua)
               - i_trd_amt:
                   Gia tri can hold/un-hold tuy thuoc vao i_hold_tp
               - i_hold_tp:
                   .) 1: Hold order (khong xu ly case nay trong source)
                   .) 2: Un-hold order
               - i_unhold_mode:
                   .) CR: Su dung cho process un-hold sau khi thi truong dong cua tai Crontab
                   .) ELSE su dung cho un-hold data cua cac lenh huy/sua

       Chuc nang dung cho khi unhold lenh can tinh toan lai 3 gia tri TSO01M00: CASH_AMT, LOAN_AMT, VD_AMT
           - i_hold_tp = '2': Order Unhold theo thu tu uu tien:VD_AMT->LOAN_AMT va tang CASH_AMT
   */
    t_remain_amt        NUMBER          := 0;
    t_vd_amt            NUMBER          := 0;
    t_tot_order_block   NUMBER          := 0;
    t_nmth_amt          NUMBER          := 0;

    t_proc_nm           VARCHAR2(100)   := 'pts_loan_cash_unhold_order';
    t_msg               VARCHAR2(4000)  := '';
    t_err_msg           VARCHAR2(4000)  := '';

BEGIN

    IF(i_unhold_mode = 'CR') THEN
        t_msg   := 'START unhold boi cronjob cuoi ngay cho: ';
    ELSE
        t_msg   := 'START unhold boi lenh trong ngay cho: ';
    END IF;

    IF (i_hold_tp = 2) THEN      -- Chi unhold voi i_hold_tp = 2
        vn.pxc_log_write ('pts_loan_cash_unhold_order', '');
        vn.pxc_log_write ('pts_loan_cash_unhold_order',
                            t_msg
                        ||  'i_acnt_no['        || i_acnt_no
                        ||  '] sub_no['         || i_sub_no
                        ||  '] ord_no['         || i_ord_no
                        ||  '] trad_amt['       || i_cash_amt
                        ||  '] i_hold_tp['      || i_hold_tp
                        ||  '] i_unhold_mode['  || NVL(i_unhold_mode, '!')
                        ||  ']'
        );

        BEGIN
            SELECT 
                NVL(t.td_cash_prof_gst_amt, 0)      vd_amt,
                NVL(t.td_cash_prof_amt,0) 
                + NVL(t.pd_cash_prof_amt,0) 
                + NVL(t.ppd_cash_prof_amt,0)        tot_order_block
            INTO 
                t_vd_amt,
                t_tot_order_block
            FROM vn.tso02m00 t
            WHERE t.acnt_no = i_acnt_no
            AND t.sub_no = i_sub_no;
        EXCEPTION
            WHEN OTHERS THEN
                t_err_msg := t_proc_nm  || ' Loi khi lay data tu tso02m00: ' 
                                        || TO_CHAR(sqlcode) || ' ' 
                                        || 'i_acnt_no = '   || i_acnt_no 
                                        || ', i_sub_no = '  || i_sub_no;
                raise_application_error(-20100, t_err_msg);
        END;

        vn.pxc_log_write('pts_loan_cash_unhold_order',  'So BL dang hold: '
                                                    || ' t_vd_amt = '     || t_vd_amt
                                                    );

        IF(i_unhold_mode = 'CR') THEN
            BEGIN
                SELECT nmth_qty * ord_prof_pri * (1 + cash_prof_rt) nmth_amt
                INTO t_nmth_amt
                FROM vn.tso01m00
                WHERE acnt_no       = i_acnt_no
                AND sub_no        = i_sub_no
                AND ord_no        = i_ord_no
                AND sell_buy_tp   = '2'
                AND nmth_qty      > 0
                AND cer_rt        > 0
                AND bank_cd       = '9999';
            EXCEPTION 
                WHEN OTHERS THEN
                    t_err_msg := t_proc_nm  || ' Loi khi lay data tu tso01m00: ' 
                                            || TO_CHAR(sqlcode) || ' ' 
                                            || 'i_acnt_no = '   || i_acnt_no 
                                            || ', i_sub_no = '  || i_sub_no
                                            || ', i_ord_no = '  || i_ord_no
                                            ;
                    raise_application_error(-20100, t_err_msg);
            END;

            t_remain_amt    := t_nmth_amt;

        ELSE
            t_remain_amt    := i_cash_amt;
        END IF;

        IF t_vd_amt > t_remain_amt THEN
            t_vd_amt := t_vd_amt - t_remain_amt;
        ELSE
            t_remain_amt := t_remain_amt - t_vd_amt;
            t_vd_amt     := 0;
        END IF;

        t_vd_amt    := GREATEST(t_vd_amt, 0);

        vn.pxc_log_write('pts_loan_cash_unhold_order',  'So BL bi hold con lai: '
                                                    || ' t_vd_amt = '     || t_vd_amt
                                                    );

        BEGIN
            UPDATE vn.tso02m00 t
            SET t.td_cash_prof_gst_amt = t_vd_amt 
            WHERE t.acnt_no = i_acnt_no
            AND t.sub_no = i_sub_no;

        EXCEPTION 
            WHEN OTHERS THEN
                t_err_msg := t_proc_nm  || ' Loi khi update data vao tso02m00: ' 
                                        || TO_CHAR(sqlcode) || ' ' 
                                        || 'i_acnt_no = '   || i_acnt_no 
                                        || ', i_sub_no = '  || i_sub_no;
                raise_application_error(-20100, t_err_msg);
        END;

    END IF; -- END IF hld_tp = 2

    vn.pxc_log_write ('pts_loan_cash_unhold_order', 'END');

END pts_loan_cash_unhold_order;
/

