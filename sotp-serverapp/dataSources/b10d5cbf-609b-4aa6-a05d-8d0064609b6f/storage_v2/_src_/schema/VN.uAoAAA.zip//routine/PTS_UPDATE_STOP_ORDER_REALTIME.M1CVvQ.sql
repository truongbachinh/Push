create procedure pts_update_stop_order_realtime
(
    i_sec_id    in    	varchar2,
    i_acnt_no	in      varchar2,
    i_sub_no    in      varchar2,
    i_ord_no    in      number,
    i_bnh_cd    in      varchar2
)as


t_match_all			varchar2 (1);

t_ord_qty          	number:=0;
t_mth_qty          	number:=0;
t_mth_amt			number :=0;
t_nmth_qty        	number:=0;
t_cncl_qty         	number:=0;
t_crrt_qty         	number:=0;
t_crrt_cncl_tp    	number:=0;
t_org_ord_qty    	number:=0;
/*update qa ngay doi voi lenh khop 1 phan*/

t_mth_amt_m         number:=0;
t_mth_amt_h			number:=0;

begin
    pxc_log_write('pts_update_stop_order_realtime','start ... waiting!');
    pxc_log_write('pts_update_stop_order_realtime','INPUT i_sec_id: '||i_sec_id||' i_acnt_no: '||i_acnt_no||' i_sub_no: '||i_sub_no||' i_ord_no: '||i_ord_no||' i_bnh_cd: '||i_bnh_cd);
    FOR C1 IN
    (
        select
            a.ORD_FRCT_DT			as		ORD_FRCT_DT		,
            a.ORD_END_DT            as		ORD_END_DT		,
            a.ORD_STL               as		ORD_STL			,
            a.ORD_NO                as		ORD_NO			,
            a.BNH_CD                as		BNH_CD			,
            a.ACNT_NO				as		ACNT_NO			,
            a.SUB_NO                as		SUB_NO			,
            a.STK_CD                as		STK_CD			,
            a.ORD_QTY               as		ORD_QTY			,
            a.PROC_TP               as		PROC_TP			,
            b.first_org_ord_no		as		RI_ORD_NO		,
            b.mth_qty				as		mth_qty			,
            b.nmth_qty				as		nmth_qty		,
            b.accp_tp				as		accp_tp			,
            b.crrt_cncl_tp			as		crrt_cncl_tp	,
            b.crrt_cnfm_qty         as		crrt_cnfm_qty	,
            b.cncl_cnfm_qty         as		cncl_cnfm_qty	,
            b.mth_amt				as		mth_amt			,
            a.ORG_ORD_QTY			as		ORG_ORD_QTY		,
			b.ord_no_stl			as		ord_no_stl
        from vn.tso09m00 a, vn.tso01m00 b
        where  a.ord_no = b.ord_no_stl
        and a.ord_frct_dt = b.ord_stl_dt
        and a.acnt_no = b.acnt_no
        and a.sub_no = b.sub_no
        and a.ord_stl = '1'
        and a.ord_stl_eft = '1'
        and b.del_yn = 'N'
        and a.proc_tp = '2'
        and b.accp_tp in ('3','5','4')
        and a.ord_end_dt >= vn.FXC_VORDERDT_G(to_date(vn.vhdate(),'yyyymmdd'), 0)
		and b.ord_no = i_ord_no
		and b.bnh_cd = i_bnh_cd
    and b.acnt_no = i_acnt_no
    and b.sub_no = i_sub_no
    )loop
		t_ord_qty      := c1.ord_qty;
		t_mth_qty      := c1.mth_qty;
		t_nmth_qty     := c1.nmth_qty;
		t_cncl_qty     := c1.cncl_cnfm_qty;
		t_crrt_qty 	   := c1.crrt_cnfm_qty;
		t_crrt_cncl_tp := c1.crrt_cncl_tp;
		t_mth_amt 	   := c1.mth_amt;
		t_org_ord_qty  := c1.ORG_ORD_QTY;
		pxc_log_write('pts_update_stop_order_realtime','accp_tp: '||c1.accp_tp||' t_cncl_qty: '||t_cncl_qty || 't_crrt_qty: '||t_crrt_qty|| 't_crrt_cncl_tp: ' || t_crrt_cncl_tp);

		----------------------
		if c1.accp_tp = '4' or c1.accp_tp = '5' then
			if c1.accp_tp = '4' then
				t_match_all := '2';
			else
				t_match_all := '1';
			end if;


			select nvl(sum(mth_amt), 0)
			  into t_mth_amt_m
			from vn.tso01m00
			where acnt_no = c1.acnt_no
			and		sub_no  = c1.sub_no
			and		ord_no_stl  = c1.ord_no_stl
			and   	ord_stl_dt = c1.ORD_FRCT_DT;


			select nvl(sum(mth_amt), 0)
			  into t_mth_amt_h
			from vn.tso01h00
			where acnt_no = c1.acnt_no
			and		sub_no  = c1.sub_no
			and		ord_no_stl  = c1.ord_no_stl
			and   	ord_stl_dt = c1.ORD_FRCT_DT
			and		stk_ord_dt between c1.ord_frct_dt and c1.ord_end_dt;


			update vn.tso09m00
			set  ord_stl_eft = t_match_all,
				 ord_stl_tp = decode(t_match_all, '2', '3', '2'),
				 ord_qty = t_nmth_qty,
				 mth_qty_stl = decode(t_match_all, '2', t_org_ord_qty, t_org_ord_qty - t_nmth_qty),
				 nmth_qty_stl = t_nmth_qty,
				 mth_amt_stl  = t_mth_amt_m + t_mth_amt_h
			where    ord_frct_dt = c1.ord_frct_dt
			and      ord_stl = '1'
			and      acnt_no = c1.acnt_no
			and      sub_no  = c1.sub_no
			and      ord_no  = c1.ord_no_stl
			and      ord_end_dt >= vn.FXC_VORDERDT_G(to_date(vn.vhdate(),'yyyymmdd'), 0);
		end if;


		if t_crrt_cncl_tp = '2' or t_crrt_cncl_tp = '4' then
			update vn.tso09m00
			set
				 ord_stl_eft = '2',
				 ord_veto_cau = decode(t_crrt_cncl_tp,'2','Modify order_stop when order sucessfully', '4','Cancel order_stop when order sucessfully'),
				 nmth_qty_stl = 0,
				 CNCL_QTY_STL = t_cncl_qty,
				 CRRT_QTY_STL = t_crrt_qty
			where ord_frct_dt = c1.ord_frct_dt
			and      ord_stl = '1'
			and      acnt_no = c1.acnt_no
			and      sub_no  = c1.sub_no
			and 	 ord_no  = c1.ord_no_stl
			and      ord_end_dt >= vn.FXC_VORDERDT_G(to_date(vn.vhdate(),'yyyymmdd'), 0);

		end if;
    END LOOP;
    pxc_log_write('pts_update_stop_order_realtime','-----------------------------------------------');
end pts_update_stop_order_realtime;
/

