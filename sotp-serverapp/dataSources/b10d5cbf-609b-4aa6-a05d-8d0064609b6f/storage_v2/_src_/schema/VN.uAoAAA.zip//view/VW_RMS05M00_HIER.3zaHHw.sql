create view VW_RMS05M00_HIER as
(
    select 
        emp_no                                          emp_no,
        level                                           lvl,
        connect_by_root emp_no                          mng_emp_no,
        ltrim(sys_connect_by_path(emp_no, '-'), '-')    pth,
        connect_by_isleaf                               leaf
    from rms05m00
    -- start with mng_emp_no is null
    connect by nocycle mng_emp_no = prior emp_no
)
/

