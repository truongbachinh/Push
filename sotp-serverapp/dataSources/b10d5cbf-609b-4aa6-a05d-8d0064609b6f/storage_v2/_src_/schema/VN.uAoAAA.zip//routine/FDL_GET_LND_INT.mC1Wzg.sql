create function    fdl_get_lnd_int
(
	i_lnd_tp          in     varchar2,        --
	i_acnt_no         in     varchar2,        --
	i_sub_no          in     varchar2,        --
	i_lnd_bank_cd     in     varchar2,        --
	i_int_tp          in     varchar2,        -- 1:int 2:dly_int 3:all
	i_lnd_dt          in     varchar2,        --
	i_rpy_dt          in     varchar2,        --
	i_expr_dt         in     varchar2,        --
	i_last_rpy_dt     in     varchar2,        --
	i_cpt_rpy_tp      in     varchar2,        --
	i_int_rpy_tp      in     varchar2,        --
	i_lnd_amt         in     number,          --
	i_rpy_amt         in     number,          --
	i_remn_amt        in     number,          --
	i_lnd_int_rt      in     number           --
) return number AS

/*!
   \file     fdl_get_lnd_int.sql
   \brief    interest calculation

   \section intro Program Information
        - Program Name              : interest calculation
        - Service Name              : dl_04513_p1.pc
        - Related Client Program- Client Program ID : w_04513
        - Related Tables            : dlm12m10
        - Dev. Date                 : 2007/11/08
        - Developer                 : Han.
        - Business Logic Desc.      : interest calculation
        - Latest Modification Date  : 2007/11/08

   \section history Program Modification History
    - 1.0       2007/11/08     Han.    New.

   \section hardcoding Hard-Coding List
    - HC-1      2007/11/08     Han.    [»çÀ¯]

   \section info Additional Reference Comments
    - Interest calculation

*/

    t_lnd_int_cal_std_term	NUMBER := 0;
	t_lnd_int_min_term    	NUMBER := 0;
	t_lnd_int_rt            NUMBER := 0; -- 01:lnd_int ratio
	t_lnd_int_rt_min        NUMBER := 0; -- 02:lnd_int ratio for min duration
	t_lnd_int_amt_min       NUMBER := 0; -- 03:min lnd_int amt
	t_lnd_int_rt_dly        NUMBER := 0; -- 04:lnd_int dly_rt
	t_lnd_fee_rt            NUMBER := 0; -- 11:lnd_fee ratio
	t_lnd_fee_rt_min        NUMBER := 0; -- 12:lnd_fee ratio for min duration
	t_lnd_fee_amt_min       NUMBER := 0; -- 13:min lnd_fee amt
	t_lnd_fee_rt_dly        NUMBER := 0; -- 14:min lnd_fee amt

    t_lnd_rm_amt            NUMBER := 0;
    t_tot_prd               NUMBER := 0;
    t_lnd_prd               NUMBER := 0;
    t_dly_prd               NUMBER := 0;
    t_lnd_int               NUMBER := 0;
    t_lnd_int_dly           NUMBER := 0;

	o_lnd_int               NUMBER;
    t_err_txt               VARCHAR2(80)  ; -- error text buffer

begin

    o_lnd_int := 0;

/*============================================================================*/
/* Get apply loan Valiabl                                                     */
/*============================================================================*/
	if i_lnd_tp <> '70' then
	    BEGIN
			vn.pdl_get_lnd_apy_val(
			    i_lnd_tp				,
			    i_acnt_no    			,
			    i_sub_no    			,
			    i_lnd_bank_cd			,
			    i_lnd_dt				,
			    i_cpt_rpy_tp			,
			    i_int_rpy_tp			,
				t_lnd_int_cal_std_term	,
				t_lnd_int_min_term    	,
			    t_lnd_int_rt            ,  -- 01:lnd_int ratio
			    t_lnd_int_rt_min        ,  -- 02:lnd_int ratio for min duration
			    t_lnd_int_amt_min       ,  -- 03:min lnd_int amt
		        t_lnd_int_rt_dly        ,  -- 04:lnd_int dly_rt
			    t_lnd_fee_rt            ,  -- 11:lnd_fee ratio
			    t_lnd_fee_rt_min        ,  -- 12:lnd_fee ratio for min duration
			    t_lnd_fee_amt_min       ,  -- 13:min lnd_fee amt
			    t_lnd_fee_rt_dly        ); -- 14:lnd_cmsn dly_rt
	    EXCEPTION
	    WHEN others then
            vn.pxc_log_write('fdl_get_lnd_int', ' apy_val :'||' lnd_tp ='||i_lnd_tp
                                                            ||' acnt_no   ='||i_acnt_no||'-'||i_sub_no
                                                            ||' lnd_bank_cd ='||i_lnd_bank_cd
                                                            ||' lnd_dt ='||i_lnd_dt
                                                            ||' cpt_rpy_tp ='||i_cpt_rpy_tp
                                                            ||' int_rpy_tp ='||i_int_rpy_tp);
	        raise_application_error(-20100,'ERROR1');
	    END;

	else

		t_lnd_int_cal_std_term	:=  1;
		t_lnd_int_min_term		:=  0;
	    t_lnd_int_rt			:=  0 ; 
	    							    -- 01:lnd_int ratio
	    t_lnd_int_rt_min		:=  0;  -- 02:lnd_int ratio for min duration
	    t_lnd_int_amt_min		:=  0;  -- 03:min lnd_int amt
        t_lnd_int_rt_dly		:=  0; 
	    t_lnd_fee_rt			:=  0;  -- 11:lnd_fee ratio
	    t_lnd_fee_rt_min		:=  0;  -- 12:lnd_fee ratio for min duration
	    t_lnd_fee_amt_min		:=  0;  -- 13:min lnd_fee amt
	    t_lnd_fee_rt_dly		:=  0;  -- 14:lnd_fee dly_rt

	end if;

    vn.pxc_log_write('fdl_get_lnd_int', ' apy_val :'||' lnd_tp ='||i_lnd_tp
                                                        ||' acnt_no   ='||i_acnt_no||'-'||i_sub_no
                                                        ||' t_lnd_int_rt_dly ='||t_lnd_int_rt_dly
                                                        ||' t_lnd_int_rt ='||t_lnd_int_rt
                                                        );

/*============================================================================*/
/* Calculate period                                                           */
/*============================================================================*/
	/* For VIP */
--	if  i_lnd_bank_cd  !=  '9999'  then
	    if  i_lnd_int_rt <> t_lnd_int_rt and i_lnd_int_rt > 0 then
		    t_lnd_int_rt     := i_lnd_int_rt;
	    end if;
--	end if;

	t_tot_prd := to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_lnd_dt, 'yyyymmdd');

    if  i_expr_dt > i_rpy_dt then
        t_dly_prd  :=  0;

        if  i_int_rpy_tp = '1' then
            t_lnd_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_last_rpy_dt, 'yyyymmdd');
        elsif i_int_rpy_tp = '2' then
            t_lnd_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_lnd_dt, 'yyyymmdd');
        else
            t_lnd_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_last_rpy_dt, 'yyyymmdd');
        end if;

    else
        if  i_int_rpy_tp = '1' then
            if  i_expr_dt > i_last_rpy_dt then
                /*==============================================*/
                /* loan period : expire date ~ last repay date  */
                /* dely prriod : repay date ~ expire date       */
                /*==============================================*/
                t_lnd_prd  :=  to_date(i_expr_dt, 'yyyymmdd') - to_date(i_last_rpy_dt, 'yyyymmdd');
                t_dly_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_expr_dt, 'yyyymmdd');
            else
                /*==============================================*/
                /* loan period :                                */
                /* dely prriod : repay date ~ last repay date   */
                /*==============================================*/
                t_dly_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_last_rpy_dt, 'yyyymmdd');
            end if;
        elsif i_int_rpy_tp = '2' then
            if  i_expr_dt > i_last_rpy_dt then
                /*==============================================*/
                /* loan period : expire date ~ lnd date         */
                /* dely prriod : repay date ~ expire date       */
                /*==============================================*/
                /* 2009/10/30 modify
                t_lnd_prd  :=  to_date(i_expr_dt, 'yyyymmdd') - to_date(i_lnd_dt, 'yyyymmdd');
                t_dly_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_expr_dt, 'yyyymmdd');
                */
                t_lnd_prd  :=  to_date(i_expr_dt, 'yyyymmdd') - to_date(i_lnd_dt, 'yyyymmdd');
                t_dly_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_expr_dt, 'yyyymmdd');
            else
                /*==============================================*/
                /* loan period :                                */
                /* dely prriod : repay date ~ last repay date   */
                /*==============================================*/
                /* 2009/10/30 modify
                t_lnd_prd  :=  to_date(i_last_rpy_dt, 'yyyymmdd') - to_date(i_lnd_dt, 'yyyymmdd');
                t_dly_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_last_rpy_dt, 'yyyymmdd');
                */
                t_lnd_prd  :=  to_date(i_expr_dt, 'yyyymmdd') - to_date(i_lnd_dt, 'yyyymmdd');
                t_dly_prd  :=  to_date(i_rpy_dt, 'yyyymmdd') - to_date(i_expr_dt, 'yyyymmdd');
            end if;
        end if;
    end if;


    if  i_int_rpy_tp = '1' then
        /*==================================================*/
        /* int calc : ÀÜ¿©±Ý¾×*¼ö¼ö·áÀ²*±â°£/30             */
        /*==================================================*/
	    if  t_lnd_prd > 0 then
	    	if  t_tot_prd < t_lnd_int_min_term then
	    	    t_lnd_int := i_remn_amt * t_lnd_int_rt_min;
	    	else
	    	    t_lnd_int := i_remn_amt * t_lnd_int_rt * t_lnd_prd / t_lnd_int_cal_std_term;
	    	end if;
	    end if;

        /*==================================================*/
        /* dely interest : ÀÌÀÚ±Ý¾×*¿¬Ã¼ÀÌÀÚÀ²*¿¬Ã¼ÀÏ¼ö/30  */
        /*==================================================*/
	    if  t_dly_prd > 0 then
	        t_lnd_int_dly := i_remn_amt * t_lnd_int_rt_dly * t_dly_prd / t_lnd_int_cal_std_term;
	    end if;

    elsif i_int_rpy_tp = '2' then
        /*==================================================*/
        /* int calc : ´ëÃâ±Ý¾×*¼ö¼ö·áÀ²*±â°£/30             */
        /*==================================================*/
	    if  t_lnd_prd > 0 then
	    	if  t_tot_prd < t_lnd_int_min_term then
	    	    t_lnd_int := i_rpy_amt * t_lnd_int_rt_min;
	    	else
	    	    t_lnd_int := i_rpy_amt * t_lnd_int_rt * t_lnd_prd / t_lnd_int_cal_std_term;
	    	end if;
	    end if;

        /*==================================================*/
        /* dely interest : ÀÌÀÚ±Ý¾×*¿¬Ã¼ÀÌÀÚÀ²*¿¬Ã¼ÀÏ¼ö/30  */
        /*==================================================*/
	    if  t_dly_prd > 0 then
	        t_lnd_int_dly := i_rpy_amt * t_lnd_int_rt_dly * t_dly_prd / t_lnd_int_cal_std_term;
	    end if;

    end if;
/*
dbms_output.put_line('1. tot_prd : '||t_tot_prd ||',lnd_int_min_term : '||t_lnd_int_min_term);
dbms_output.put_line('1. lnd_prd : '||t_lnd_prd ||',lnd_int_cal_std_term : '||t_lnd_int_cal_std_term);
dbms_output.put_line('1. remn_amt: '||i_remn_amt||',lnd_int_rt : '||t_lnd_int_rt);
dbms_output.put_line('1. rpy_amt : '||i_rpy_amt ||',lnd_int_rt : '||t_lnd_int_rt);
dbms_output.put_line('1. lnd_int : '||t_lnd_int );
*/
    /*==================================================*/
    /* interest type : 1.interest 2.delay interest 3.all*/
    /*==================================================*/
    if  i_int_tp = '1' then
        o_lnd_int := round(t_lnd_int);
    elsif i_int_tp = '2' then
        o_lnd_int := round(t_lnd_int_dly);
    else
        o_lnd_int := round(t_lnd_int) + round(t_lnd_int_dly);
    end if;

    return o_lnd_int;

end fdl_get_lnd_int;
/

