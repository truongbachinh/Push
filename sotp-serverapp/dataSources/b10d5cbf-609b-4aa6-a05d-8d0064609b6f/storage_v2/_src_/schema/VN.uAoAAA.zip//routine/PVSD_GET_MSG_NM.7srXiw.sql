create procedure pvsd_get_msg_nm(i_dat_cd   in varchar2,
                                            i_seq      in varchar2,
                                            i_msg_cont in varchar2,
                                            o_name     out varchar2)

 as
  /*
  Create date       : 2017/01/01
  Developer         : long.pham
  Purpose           : Dung de lay Name (Eng or Vie) trong VSD01C02
  */
  p_cnt_dat_tp    number;
  p_cnt_id_mark_1 number;
  p_str_exist_1   number;
  p_str_exist_2   number;
  cursor c_id_mark is
    select dat_tp,
           msg_type,
           id_mark_1,
           nvl(id_mark_2, '!') id_mark_2,
           nvl(decode(name_vi, '', name_en, name_vi), '!') msg_name
      from vn.VSD01C02
     where dat_cd = i_dat_cd;
begin
  vn.pxc_log_write('pvsd_get_msg_nm',
                   'input i_dat_cd ' || i_dat_cd || ' i_seq ' || i_seq);
  -- one dat_cd
  begin
    select count(*)
      into p_cnt_dat_tp
      from vn.VSD01C02
     where dat_cd = i_dat_cd;
  end;
  if p_cnt_dat_tp = 0 then
    o_name := '!';
    return;
  end if;
  if p_cnt_dat_tp = 1 then
    begin
      select nvl(decode(name_vi, '', name_en, name_vi), '!')
        into o_name
        from vn.VSD01C02
       where dat_cd = i_dat_cd;
    exception
      when others then
        o_name := '!';
    end;
    return;
  end if;
  -- more than one dat_cd
  for c1 in c_id_mark loop
    begin
      select instr(i_msg_cont, c1.id_mark_1) into p_str_exist_1 from dual;
    end;
    if p_str_exist_1 < 1 then
      o_name := '!';
    elsif p_str_exist_1 > 0 and c1.id_mark_2 = '!' then
      -- count neu ok thi return luon
      begin
        select count(*)
          into p_cnt_id_mark_1
          from vn.vsd01c02
         where dat_cd = i_dat_cd
           and id_mark_1 = c1.id_mark_1;
      end;
      if p_cnt_id_mark_1 = 1 then
        o_name := c1.msg_name;
      end if;
    elsif p_str_exist_1 > 0 and c1.id_mark_2 <> '!' then
      begin
        select instr(i_msg_cont, c1.id_mark_2)
          into p_str_exist_2
          from dual;
      end;
      if p_str_exist_2 > 0 then
        Select c1.msg_name into o_name from dual;
      end if;
    end if;
    p_str_exist_1 := 0;
    p_str_exist_2 := 0;
    if o_name <> '!' then
      vn.pxc_log_write('pvsd_get_msg_nm', 'output name ' || o_name);
      return;
    end if;
  end loop;
end pvsd_get_msg_nm;
/

