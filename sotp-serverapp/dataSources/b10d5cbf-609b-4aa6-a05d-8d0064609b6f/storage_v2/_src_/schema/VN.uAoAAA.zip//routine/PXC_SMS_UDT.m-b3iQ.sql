create PROCEDURE	pxc_sms_udt
   (
       in_sms_seq_no	IN		NUMBER,
       in_send_st		IN  	VARCHAR2,
       in_sent_dt		IN		VARCHAR2
   ) IS

 	ts_sqlcode      number := 0;

BEGIN

   BEGIN
    UPDATE vn.xcs01m00 t  SET
      	t.send_st    = in_send_st,
       	t.sent_dt    = in_sent_dt,
       	t.re_try_cnt = t.re_try_cnt - 1
 	WHERE t.sms_seq_no = in_sms_seq_no;

   EXCEPTION
      WHEN OTHERS THEN
         ts_sqlcode := sqlcode;
         RAISE_APPLICATION_ERROR(-20100,'error found base_idx -2 ['||ts_sqlcode||']');
   END;

END pxc_sms_udt;
/

