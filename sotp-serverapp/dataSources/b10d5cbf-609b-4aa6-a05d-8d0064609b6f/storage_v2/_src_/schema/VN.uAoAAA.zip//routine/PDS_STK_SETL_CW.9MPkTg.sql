create PROCEDURE    pds_stk_setl_cw
(
  i_setl_dt     IN      VARCHAR2,
  i_acnt_no     IN      VARCHAR2,
  i_sub_no      IN      VARCHAR2,
  i_cw_cd       IN      VARCHAR2,
  i_setl_tp     IN      VARCHAR2,
  i_work_mn     IN      VARCHAR2,        -- user id
  i_work_trm    IN      VARCHAR2,
  o_proc_cnt    IN OUT  NUMBER,
  o_err_cnt     IN OUT  NUMBER
) AS

/* ************************************************************************************************
  Author:         hphan
  Created Date:   01-Feb-2018
  Description:    This procedure is used to implement cw dpo settlement.

  Sample call:
    var o_cnt      number;
    var o_err_cnt  number;
    exec pds_stk_setl_cw('20180131','061C600088','01','VIC','1','system','1.1.1.1',:o_cnt,:o_err_cnt);
    print o_cnt
    print o_err_cnt


  MODIFICATION DETAILS:
  -------------------------------------------------------------------------------------------------
  Modified Date   Modified By       Modification Details
  -------------------------------------------------------------------------------------------------
  29-Jan-2018     hphan             Initial creation

**************************************************************************************************/

    -- Declare variable
    t_sec_id                    VARCHAR(10)     := vn.fxc_sec_cd('R');
    t_vwdate                    VARCHAR2(8)     := NULL;
    t_setl_dt                   VARCHAR2(8)     := NULL;
    t_own_qty                   NUMBER          := 0;
    t_pre_own_qty               NUMBER          := 0;
    t_now_own_qty               NUMBER          := 0;
    t_sell_able_qty             NUMBER          := 0;
    t_book_amt                  NUMBER          := 0;
    t_pre_book_amt              NUMBER          := 0;
    t_now_book_amt              NUMBER          := 0;
    t_setl_comp                 NUMBER(1)       := 0;
    t_new_cw_waiting_exec_qty   NUMBER          := 0;
    t_new_cw_own_qty            NUMBER          := 0;
    t_new_cw_book_amt           NUMBER          := 0;
    t_err_chk                   VARCHAR2(1)     := 'N';
    t_err_msg                   VARCHAR2(500)   := NULL;
BEGIN

    o_proc_cnt := 0;
    o_err_cnt  := 0;

    t_setl_dt := i_setl_dt;
    t_vwdate  := vn.vwdate;

    vn.pxc_log_write('pds_stk_setl_cw','START pds_stk_setl_cw');

    /* **************************************************************************/
    /*  Checking data before implementing settlement  */
    /* **************************************************************************/
    -- Check if input date is not current date
    IF vn.vwdate != i_setl_dt THEN
        t_err_msg := vn.fxc_get_err_msg('V', '2422');
        t_err_msg := t_err_msg || ' Date = ' || i_setl_dt;
        raise_application_error(-20100, t_err_msg);
    END IF;

    -- Check if input date is holiday
    IF vn.fxc_holi_ck(TO_DATE(i_setl_dt, 'yyyymmdd')) != '0' THEN
        IF i_work_mn <> 'DAILY' THEN
            t_err_msg := vn.fxc_get_err_msg('V', '2422');
            t_err_msg := t_err_msg || ' Date = ' || i_setl_dt;
            raise_application_error(-20100, t_err_msg);
        ELSE
            RETURN;
        END IF;
    END IF;

    /* **************************************************************************/
    /* End checking   */
    /* **************************************************************************/

    /* **************************************************************************/
    /* Stock Settlement   */
    /* **************************************************************************/
    FOR c1 in (
        SELECT 
            dc.acnt_no                                      acnt_no,
            dc.sub_no                                       sub_no,
            vn.faa_acnt_nm_g(dc.acnt_no, dc.sub_no)         acnt_nm,
            dc.cw_cd                                        cw_cd,
            dc.cw_qty                                       cw_qty,
            si.cw_tp                                        cw_tp,
            vn.fss_get_setl_pri_cw(dc.cw_cd, dc.setl_dt)    cw_setl_pri,
            vn.fss_get_pd_cls_pri(dc.cw_cd)                 cw_cls_pri,
            dc.setl_dt                                      setl_dt,
            dc.setl_tp                                      setl_tp,
            dc.stk_cd                                       stk_cd,
            dc.stk_qty                                      stk_qty,
            vn.fss_get_setl_pri_cw(dc.stk_cd, dc.exec_dt)   stk_setl_pri,
            dc.stk_setl_yn                                  stk_setl_yn,
            dc.acnt_brch_cd                                 acnt_brch_cd,
            dc.acnt_agnc_cd                                 acnt_agnc_cd,
            si.cw_exec_tp                                   cw_exec_tp
        FROM dcw01m00 dc
        INNER JOIN ssi01m00 si
           ON dc.cw_cd = si.stk_cd
        WHERE dc.acnt_no    LIKE i_acnt_no
          AND dc.sub_no     LIKE i_sub_no
          AND dc.cw_cd      LIKE i_cw_cd
          AND dc.setl_dt       = t_setl_dt
          AND dc.setl_tp    LIKE i_setl_tp
          AND dc.stk_setl_yn   = 'N' 
          -- AND dc.stk_qty       > 0
    )
    LOOP
        o_proc_cnt  := o_proc_cnt + 1;

        vn.pxc_log_write('pds_stk_setl_cw','pds_stk_setl_cw: '
                            || 'acnt_no = '    || c1.acnt_no   || '-' || c1.sub_no
                            || ' | cw_cd = '   || c1.cw_cd
                            || ' | setl_dt = ' || c1.setl_dt);

        -- 1. Get current own_qty and book_amt
        BEGIN
            SELECT 
                own_qty                                                     own_qty,
                vn.fss_get_able_qty_sell(sb.acnt_no, sb.sub_no, sb.stk_cd)  sell_able_qty,
                book_amt                                                    book_amt
            INTO 
                t_own_qty,
                t_sell_able_qty,
                t_book_amt
            FROM vn.ssb01m00 sb
            WHERE sb.acnt_no = c1.acnt_no
            AND sb.sub_no =  c1.sub_no
            AND sb.stk_cd = c1.stk_cd;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    t_own_qty   := 0;
                    t_book_amt  := 0;
        END;

        t_pre_own_qty   := NVL(t_own_qty, 0);
        t_pre_book_amt  := NVL(t_book_amt, 0);

        vn.pxc_log_write('pds_stk_setl_cw','pds_stk_setl_cw: '
                            || 't_pre_own_qty = '       || t_pre_own_qty
                            || ' | t_pre_book_amt = '   || t_pre_book_amt);

        -- 2. Calculate new own_qty and book_amt
        IF(c1.cw_tp = 1)   -- PUT CW
        THEN
            -- Check if the available stock quantity is enough to sell
            IF(t_sell_able_qty < c1.stk_qty)
            THEN
                t_err_msg := vn.fxc_get_err_msg('V','2205');
                raise_application_error(-20100,t_err_msg||' acnt_no='       ||c1.acnt_no    || '-' ||c1.sub_no
                                                        ||' | stk_qty'      ||c1.stk_qty
                                                        ||' | pre_own_qty'  ||t_pre_own_qty);
            END IF; -- END checking available stock quantity

            t_now_own_qty   := t_pre_own_qty - c1.stk_qty;

            IF(t_pre_own_qty = 0) THEN
                t_now_book_amt  := t_pre_book_amt;
            ELSE
                t_now_book_amt  := t_pre_book_amt - TRUNC(t_pre_book_amt * c1.stk_qty / t_pre_own_qty);
            END IF;

        -- END settlement for PUT CW
        ELSIF(c1.cw_tp = 2)    -- CALL CW
        THEN
            t_now_own_qty   := t_pre_own_qty + c1.stk_qty;
            t_now_book_amt  := t_pre_book_amt + (c1.stk_setl_pri * c1.stk_qty);
        END IF; 

        vn.pxc_log_write('pds_stk_setl_cw','pds_stk_setl_cw: '
                            || 't_now_own_qty = '       || t_now_own_qty
                            || ' | t_now_book_amt = '   || t_now_book_amt);

        /*  daily profit and loss create */
        /*
        vn.pds_dsc20m00_ins (
            t_setl_dt,          -- TRD_DT
            c1.acnt_no,         -- ACNT_NO
            c1.sub_no,          -- SUB_NO
            t_trd_seq_no,       -- TRD_SEQ_NO
            c1.stk_cd,          -- STK_CD
            c1.setl_pri,        -- SB_PRI
            c1.stk_qty,         -- SB_QTY
            0,                  -- SB_CMSN
            0,                  -- SB_TAX
            t_sb_pl,            -- SB_PL
            t_pre_own_qty,      -- PRERM_QTY
            t_now_own_qty,      -- NOWRM_QTY
            t_pre_book_amt,     -- PRE_BOOK_AMT
            t_now_book_amt,     -- NOW_BOOK_AMT
            'N',                -- CNCL_YN
            i_work_mn,          -- WORK_MN
            i_work_trm          -- WORK_TRM
        );
        */

        -- 3. Update stock balance
        MERGE INTO vn.ssb01m00 s
        USING ( SELECT  c1.acnt_no  acnt_no,
                        c1.sub_no   sub_no,
                        c1.stk_cd   stk_cd
                FROM DUAL) t
        ON ( s.acnt_no = t.acnt_no
          AND s.sub_no = t.sub_no
          AND s.stk_cd = t.stk_cd)
        WHEN MATCHED THEN
            UPDATE SET  
                own_qty     = t_now_own_qty,
                book_amt    = t_now_book_amt
        WHEN NOT MATCHED THEN
            INSERT (acnt_no,        sub_no,             stk_cd,     stk_tp,
                    own_qty,        book_amt,
                    work_mn,        work_dtm,           work_trm)
            VALUES (t.acnt_no,      t.sub_no,           t.stk_cd,  '70',
                    t_now_own_qty,  t_now_book_amt,
                    'sys',          sysdate,            'sys')
        ;

        -- 4. Update stock settlement status = 'Y'
        UPDATE dcw01m00
        SET stk_setl_yn = 'Y'
        WHERE acnt_no   = c1.acnt_no
          AND sub_no    = c1.sub_no
          AND cw_cd     = c1.cw_cd
          AND setl_dt   = c1.setl_dt
          AND setl_tp   = c1.setl_tp;

    END LOOP;

    vn.pxc_log_write('pds_stk_setl_cw', 'END pds_stk_setl_cw: ' 
                        || ' acnt_no = '    || i_acnt_no   || '-' || i_sub_no
                        || ' | cw_cd = '    || i_cw_cd
                        || ' | date = '     || i_setl_dt
                        || ' | setl_tp = '  || i_setl_tp
                        || ' | err_cnt = '  || o_err_cnt
                        || ' | err_chk = '  || t_err_chk );

    /*
    IF  t_err_chk  =  'Y' THEN
        ROLLBACK WORK;
    ELSE
        COMMIT WORK;
    END IF;
    */

    IF  i_work_mn = 'DAILY' THEN
        IF  o_err_cnt > 0 THEN
            t_err_msg := vn.fxc_get_err_msg('V','9413') || t_err_msg;
            raise_application_error(-20100,t_err_msg);
        END IF;
    END IF;

END pds_stk_setl_cw;
/

