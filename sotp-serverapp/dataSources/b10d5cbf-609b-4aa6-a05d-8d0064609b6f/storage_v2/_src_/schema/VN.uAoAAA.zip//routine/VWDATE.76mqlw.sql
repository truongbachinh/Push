create function vwdate
		return varchar2 as
begin

	return(to_char(wdate(),'yyyymmdd'));

end vwdate;
/

