create PROCEDURE PGG_CUST_RECV_SND_SLIP
/********************
    자동전표 생성 ( from GGA07M00; 자동전표Log로 부터)
********************/
(   I_PROC_DT   IN  VARCHAR2,       -- processing date
    I_PROC_MN   IN  VARCHAR2,       -- processor
    I_PROC_TRM  IN  VARCHAR2,       -- processing ip
    I_PROC_TP   IN  VARCHAR2,       -- processing type (1:미처리분 전체처리, 2:미처리분 일부처리,3:오류분 전체처리,4:오류분 일부처리)
    I_SEQ_NO    IN  NUMBER,         -- SEQ(자동전표LOG 일련번호; PK=일자+일련번호)
    O_PROC_CNT  OUT NUMBER          -- PROC NUMBER
)IS

/*
    611,612 적요를 제외하고 현재 업무들은 P계좌 여부에 상관없이 자동Log에 입력하고 있음
    611,612 적요만 P계좌 회계처리 가능

    P계좌는 901 지점으로 전표를 발생할 것

    025:계좌이체입금, 026:계좌이체출금 적요의 경우 한꺼번에 처리하여야 한다.
    자점분타점, 타점분자점 과 같은 구분은 의미가 없으며,
    입금이 자점계좌인가, 타점계좌인가,
    출금이 자점계좌인가, 타점계좌인가 만 중요하다.
    따라서 계좌이체입출금 적요에서
        자자:입금자점계좌,출금자점계좌
        자타:입금자점계좌,출금타점계좌
        타자:입금타점계좌,출금자점계좌   이다.
*/

    T_C2_CNT        NUMBER;         -- COUNTER OF C2
    T_ABNH_TP       VARCHAR2(2);
    T_ACC_RMRK_CD   GGA06M00.ACC_RMRK_CD%TYPE;
    T_SLIP_NO       GGA06M00.SLIP_NO%TYPE;
    T_ERR_MSG       GGA07M00.AUTO_SLIP_ERR_CONT%TYPE;
    T_AUTO_SLIP_RFLN_TP GGA07M00.AUTO_SLIP_RFLN_TP%TYPE;

--    T_RECURSIVE_CNT NUMBER;
    T_PROC_CNT      NUMBER;
    T_RECURSIVE_PROC_CNT    NUMBER; --RECURSIVE CALL COUNTER FOR PGG_JOB_RECV_SND_SLIP
    T_GGA07M00_ROWID    ROWID;

    T_PROC_BRCH_CD      GGA07M00.PROC_BRCH_CD%TYPE;
    T_PROC_AGNC_BRCH    GGA07M00.PROC_AGNC_BRCH%TYPE;
    T_EXCH_BRCH_CD      GGA07M00.EXCH_BRCH_CD%TYPE;
    T_EXCH_AGNC_BRCH    GGA07M00.EXCH_AGNC_BRCH%TYPE;

    T_LOG_MSG       VARCHAR2(1000);
    T_TOT_CNT       NUMBER;     --TOTAL PROC COUNT
    T_SKIP_CNT      NUMBER;
    T_ERR_CNT       NUMBER;
    T_AUTO_TP       VARCHAR2(1);

    T_CNT           NUMBER := 0;

   -- T_EXCH_INS_BRCH_TP  VARCHAR2(1);    --계좌이체입금 자/타 구분(1:자점계좌, 2:타점계좌)
   -- T_EXCH_OUT_BRCH_TP  VARCHAR2(1);    --계좌이체출금 자/타 구분(1:자점계좌, 2:타점계좌)

   -- T_CUR_HH      VARCHAR2(2);

BEGIN


    -- WRITE LOG
--    T_LOG_MSG := '<<<Start!!!  Proc_DT=['   ||I_PROC_DT          ||']';
--    T_LOG_MSG := T_LOG_MSG ||',Proc_Mn=['   ||I_PROC_MN          ||']';
--    T_LOG_MSG := T_LOG_MSG ||',PROC_TRM=['  ||I_PROC_TRM         ||']';
--    T_LOG_MSG := T_LOG_MSG ||',PROC_TP=['   ||I_PROC_TP          ||']';
--    T_LOG_MSG := T_LOG_MSG ||',SEQ_NO=['    ||TO_CHAR(I_SEQ_NO)  ||'] >>>';


    T_LOG_MSG := 'Start[DT-Mn-Trm-Tp-Seq]=['||I_PROC_DT||'-'||I_PROC_MN||'-'||I_PROC_TRM||'-'||I_PROC_TP||'-'||TO_CHAR(I_SEQ_NO) ||']';
    pxc_log_write('pgg_cust_recv_snd_slip',T_LOG_MSG);

    T_TOT_CNT   := 0;
    T_SKIP_CNT  := 0;
    T_ERR_CNT   := 0;
    O_PROC_CNT  := 0;
    T_PROC_CNT  := 0;


  --  T_CUR_HH = TO_CHAR(SYSDATE,'HH');

    -- 처리구분이 일부처리인경우  자동전표LOG 일련번호를 반드시 입력하여야 함
    IF  I_PROC_TP IN ('2','4') AND NVL(I_SEQ_NO,0) = 0 THEN
        T_LOG_MSG := 'Error... Please Input Seq...';
        pxc_log_write('pgg_cust_recv_snd_slip',T_LOG_MSG);
        RAISE_APPlICATION_ERROR(-20101,T_LOG_MSG);
    END IF;

    --자동전표 LOG에서 당일자 미처리된 LOG를 읽어서 자동전표 처리한다.
    FOR C1  IN(
        SELECT   A.ROWID
                ,A.PROC_DT                  --처리일
                ,A.SEQ_NO                   --일련번호
                ,A.AUTO_SLIP_PROC_TP        --자동전표처리구분
                ,A.PROC_BRCH_CD             --처리지점코드
--                ,A.PROC_AGNC_BRCH           --처리대리지점
                ,'00'      PROC_AGNC_BRCH        --처리대리지점 (출장소 처리 안함)
                ,NVL(A.EXCH_BRCH_CD  ,A.PROC_BRCH_CD) EXCH_BRCH_CD           --대체지점코드
--                ,NVL(A.EXCH_AGNC_BRCH,A.PROC_AGNC_BRCH) EXCH_AGNC_BRCH       --대체대리지점
                ,'00'         EXCH_AGNC_BRCH       --대체대리지점 (출장소 처리 안함)
                ,A.ACNT_NO                  --계좌번호
                ,A.TRD_DT                   --거래일
                ,A.TRD_SEQ_NO               --거래일련번호
                ,A.ORIG_TRD_SEQ_NO          --원천거래일련번호
                ,A.RMRK_JOB_TP              --적요업무구분
                ,A.RMRK_TRD_TP              --적요거래구분
                ,A.DR_AMT_01                 --차변금액01
                ,A.DR_AMT_02                 --차변금액02
                ,A.DR_AMT_03                 --차변금액03
                ,A.DR_AMT_04                 --차변금액04
                ,A.DR_AMT_05                 --차변금액05
                ,A.DR_AMT_06                 --차변금액06
                ,A.DR_AMT_07                 --차변금액07
                ,A.DR_AMT_08                 --차변금액08
                ,A.DR_AMT_09                 --차변금액09
                ,A.DR_AMT_10                 --차변금액10
                ,A.CR_AMT_01                 --대변금액01
                ,A.CR_AMT_02                 --대변금액02
                ,A.CR_AMT_03                 --대변금액03
                ,A.CR_AMT_04                 --대변금액04
                ,A.CR_AMT_05                 --대변금액05
                ,A.CR_AMT_06                 --대변금액06
                ,A.CR_AMT_07                 --대변금액07
                ,A.CR_AMT_08                 --대변금액08
                ,A.CR_AMT_09                 --대변금액09
                ,A.CR_AMT_10                 --대변금액10
                ,A.DRCT_ACC_ACT_ASN_YN --직접회계계정지정여부 2008-01-25 ( D;차변지정, C:대변지정, M:차/대 지정, N or null:지정안함)
                ,A.DR_ACC_ACT_01                --차변회계계정01  2008-01-25
                ,A.DR_ACC_ACT_02               --차변회계계정02  2008-01-25
                ,A.DR_ACC_ACT_03               --차변회계계정03  2008-01-25
                ,A.CR_ACC_ACT_01               --대변회계계정01  2008-01-25
                ,A.CR_ACC_ACT_02               --대변회계계정02  2008-01-25
                ,A.CR_ACC_ACT_03               --대변회계계정03  2008-01-25
                ,A.BANK_CD                      --은행코드 2008-05-27
                ,A.AUTO_SLIP_RFLN_TP        --자동전표반영구분
                ,A.AUTO_SLIP_PROC_MN        --자동전표처리자
                ,A.AUTO_SLIP_PROC_DTM       --자동전표처리일시
                ,A.AUTO_SLIP_PROC_TRM       --자동전표처리단말
                ,A.WORK_MN                  --작업자
                ,A.WORK_DTM                 --작업일시
                ,A.WORK_TRM                 --작업단말
          FROM  GGA07M00    A
         WHERE  NVL(A.AUTO_SLIP_RFLN_TP ,'N')   =   DECODE(I_PROC_TP,'1','N','2','N','3','X','4','X')     --처리구분에 따른 회계LOG 건 만 ㅊ리
           AND  A.PROC_DT   =   I_PROC_DT                   --처리일의 LOG 만..
           AND  A.SEQ_NO  LIKE DECODE(I_PROC_TP,'1','%','3','%','2',I_SEQ_NO,'4',I_SEQ_NO)
    )LOOP

        BEGIN   -- START OF MAIN LOOP
            T_GGA07M00_ROWID    := C1.ROWID;
            -- RECURSIVE CALL COUNTER Initialize
           -- T_RECURSIVE_CNT := 0;


--pxc_log_write('pgg_cust_recv_snd_slip','loop');

            -- 취소거래가 아니면서 전표금액 = 0 ;if slip amt = 0 and is not cancel then do not generate slip...
            IF  NVL(C1.DR_AMT_01,0) + NVL(C1.DR_AMT_02,0) + NVL(C1.DR_AMT_03,0) + NVL(C1.DR_AMT_04,0)
               +NVL(C1.DR_AMT_05,0) + NVL(C1.DR_AMT_06,0) + NVL(C1.DR_AMT_07,0) + NVL(C1.DR_AMT_08,0)
               +NVL(C1.DR_AMT_09,0) + NVL(C1.DR_AMT_10,0) = 0
            AND C1.AUTO_SLIP_PROC_TP <> 'D'     THEN

                T_AUTO_SLIP_RFLN_TP := 'M'; -- 처리대상 아님
                T_ERR_MSG   := 'Skip processing=>SLIP AMT=0!!!';

            --P계좌인 경우
            ELSIF SUBSTRB(C1.ACNT_NO,4,1) = 'P' THEN

                T_AUTO_SLIP_RFLN_TP := 'M'; -- 처리대상 아님
                T_ERR_MSG   := 'Skip processing=>Type P Account!!!';


            -- 상품결제인 경우
            ELSIF C1.RMRK_TRD_TP IN ('611','612') AND C1.RMRK_JOB_TP NOT IN ( '10','11','12','13') THEN
             /*    2007-12-17 상품결제는 매매손익을 분개시에 반영할 수 없으므로 자동분개대상에서 제외하기로 함
                --'611' - '25' (상품단주매수결제)거래는 처리대상 아님
                IF C1.RMRK_TRD_TP = '612' AND C1.RMRK_JOB_TP = '25' THEN
                    T_AUTO_SLIP_RFLN_TP := 'M'; -- 처리대상 아님
                ELSE
                    T_AUTO_SLIP_RFLN_TP := 'Y'; -- 처리대상
                    --상품결제처리는 901을 전표지점으로 처리
                    T_PROC_BRCH_CD      :=  '901';
                    T_PROC_AGNC_BRCH    :=  '00';
                    T_EXCH_BRCH_CD      :=  '901';
                    T_EXCH_AGNC_BRCH    :=  '00';
                END IF;
            */
                T_AUTO_SLIP_RFLN_TP := 'M'; -- 처리대상 아님
                T_ERR_MSG   := 'Skip processing=>Own dealing!!!';


/* 20090519-001 START -------------------------- */
/* 20090519-001 SeoHaeSeok 수정 : 신회계규정집 */

            --매도담보대출/취소는 2008-03-11 현재 회계처리 하지 않음
            --예탁담보대출/취소는 2009-03-11 현재 회계처리 하지 않음
            ELSIF C1.RMRK_TRD_TP IN ('701','702','703','704','705') THEN
            --ELSIF C1.RMRK_TRD_TP IN ('701','702','703','704','705','711','712','713','714','715','716','717','718') THEN

/* 20090519-001 END -------------------------- */

                T_AUTO_SLIP_RFLN_TP := 'M'; -- 처리대상 아님
                T_ERR_MSG   := 'Skip processing=>Payment in advance of selling securities money!!!';

/*
            --권리 배당금/채권이자/단수주대금/매수청구대금 지급 업무는 수기전표로 처리하기로 함 2008-05-14
            ELSIF C1.RMRK_TRD_TP IN ('241','242','243','244') THEN

                T_AUTO_SLIP_RFLN_TP := 'M'; -- 처리대상 아님
                T_ERR_MSG   := 'Skip processing=>Right processing job!!!';
*/
/*
            =======================
            계좌간 이체 입출금/취소
            ======================
            계좌이체출금log에서 출금회계처리는 하지않고
            계좌이체입금log에서 입금/출금 회계처리 모두 함
            계좌이체입금은 항상 계좌관리점으로 전표를 생성(처리점이 아님)

            계좌이체입금시
               출금계좌가 자점계좌 인경우 계좌이체입출금적요   353/353 으로 처리
               출금계좌가 타점계좌 인경우 계좌이체입금(336/353) => 계좌이체본사대체(136/136) => 계좌이체출금(353/336)으로 처리

            회계로그에는 계좌이체출금이 먼저들어있고 계좌이체입금 순으로 있으며,  회계로그 일련번호는 연번이다.
            취소는 반대로..계좌이체입금취소, 계좌이체출금취소 순이며, 회계로그 일련번호는 연번이다.
*/
            --계좌간이체 출금/출금취소
            ELSIF  C1.RMRK_TRD_TP IN ('026','028') THEN

                T_AUTO_SLIP_RFLN_TP := 'M'; -- 처리대상 아님
                T_ERR_MSG   := 'Skip processing=>TRD_TP =['||C1.RMRK_TRD_TP||']!!!';


            -- 계좌이체입금/입금 취소
            ELSIF  C1.RMRK_TRD_TP IN ('025','027') THEN


/* 20080825-001 START -------------------------- */
/* 20080825-001 SeoHaeSeok 수정 : 이체 출금계좌 관리점 가져오기 */

/* ----------------------------------------------------------
                SELECT  A.EXCH_BRCH_CD      --계좌관리점
               --   INTO  T_PROC_BRCH_CD
                  INTO  T_EXCH_BRCH_CD            -- 이체 출금이 될 계좌 관리점
                  FROM  GGA07M00 A
                 WHERE  A.PROC_DT           = C1.PROC_DT
                   AND  A.AUTO_SLIP_PROC_TP = C1.AUTO_SLIP_PROC_TP
                   AND  A.RMRK_JOB_TP       = '10'
                   AND  A.RMRK_TRD_TP = DECODE(C1.RMRK_TRD_TP,'025','026','028')
                   AND  A.CR_AMT_01   = C1.DR_AMT_01
                   AND  A.SEQ_NO =  C1.SEQ_NO - (DECODE(C1.RMRK_TRD_TP,'025',1,-1)); -- 일련번호-1 은 계좌이체 출금임...
-------------------------------------------------------------*/

                T_CNT   := 0 ;

				SELECT	COUNT(*)
				  INTO	T_CNT
				  FROM	VN.AAA01M00 v11
				 WHERE	v11.ACNT_NO	=	(	SELECT	v21.OUTAMT_ACNT_NO
											  FROM	VN.CWD10M00 v21
											 WHERE	v21.OUTAMT_RMRK_CD		=	DECODE(C1.RMRK_TRD_TP, '025', '026', '028')
											   AND	v21.INAMT_ACNT_NO		=	C1.ACNT_NO
											   AND	v21.INAMT_TRD_SEQ_NO	=	C1.TRD_SEQ_NO );
/* 	20080912-001 : SeoHaeSeok : 계좌간이체후 바로 취소처리시 문제발생 :    AND	v21.CNCL_YN = 'N' */

				IF	T_CNT   <=  0	THEN	-- 처리일이 영업일이 아닐경우

					SELECT	v11.ACNT_MNG_BNH		-- 계좌관리점
					  INTO	T_EXCH_BRCH_CD          -- 이체 출금이 될 계좌 관리점
					  FROM	VN.AAA01M00 v11
					 WHERE	v11.ACNT_NO	=	(	SELECT	v21.OUTAMT_ACNT_NO
												  FROM	VN.CWD10H00 v21
												 WHERE	v21.STD_DT				=	C1.PROC_DT
												   AND	v21.OUTAMT_RMRK_CD		=	DECODE(C1.RMRK_TRD_TP, '025', '026', '028')
												   AND	v21.INAMT_ACNT_NO		=	C1.ACNT_NO
												   AND	v21.INAMT_TRD_SEQ_NO	=	C1.TRD_SEQ_NO );
/* 	20080912-001 : SeoHaeSeok : 계좌간이체후 바로 취소처리시 문제발생 :    AND	v21.CNCL_YN = 'N' */

				ELSE		-- 처리일이 영업일 경우

					SELECT	v11.ACNT_MNG_BNH		-- 계좌관리점
					  INTO	T_EXCH_BRCH_CD          -- 이체 출금이 될 계좌 관리점
					  FROM	VN.AAA01M00 v11
					 WHERE	v11.ACNT_NO	=	(	SELECT	v21.OUTAMT_ACNT_NO
												  FROM	VN.CWD10M00 v21
												 WHERE	v21.OUTAMT_RMRK_CD		=	DECODE(C1.RMRK_TRD_TP, '025', '026', '028')
												   AND	v21.INAMT_ACNT_NO		=	C1.ACNT_NO
												   AND	v21.INAMT_TRD_SEQ_NO	=	C1.TRD_SEQ_NO );
/* 	20080912-001 : SeoHaeSeok : 계좌간이체후 바로 취소처리시 문제발생 :    AND	v21.CNCL_YN = 'N' */

				END IF ;

/* 20080825-001 END -------------------------- */

--pxc_log_write('pgg_cust_recv_snd_slip','  SEO_1 : T_EXCH_BRCH_CD ,Err_msg=['||T_ERR_MSG||']');


                T_PROC_AGNC_BRCH    :=  '00';
                T_PROC_BRCH_CD      :=  C1.EXCH_BRCH_CD;   -- 이체 입금이 될 계좌 관리점
            --    T_EXCH_BRCH_CD      :=  C1.EXCH_BRCH_CD;
                T_EXCH_AGNC_BRCH    :=  C1.EXCH_AGNC_BRCH;

                --자점출금자점입금이면  처리를 생략함
                IF T_PROC_BRCH_CD = T_EXCH_BRCH_CD THEN
                    T_AUTO_SLIP_RFLN_TP := 'M'; -- 처리대상 아님
                    T_ERR_MSG   := 'Skip processing=>Pay Dept.['||T_PROC_BRCH_CD ||'] and Recv Dept.['|| T_EXCH_BRCH_CD||'] are same!!!';
                ELSE
                    T_AUTO_SLIP_RFLN_TP := 'Y'; -- 처리대상
                END IF;

            -- 관리점변경인 경우 2008-05-23
            ELSIF  C1.RMRK_TRD_TP IN ('900') THEN
                IF C1.PROC_BRCH_CD  = C1.EXCH_BRCH_CD THEN
                    T_AUTO_SLIP_RFLN_TP := 'M'; -- 처리대상 아님
                    T_ERR_MSG   := 'Skip processing=>From Dept.['||T_PROC_BRCH_CD ||'] and To Dept.['|| T_EXCH_BRCH_CD||'] are same!!!';
                ELSE
                    T_AUTO_SLIP_RFLN_TP := 'Y'; -- 처리대상
                    T_PROC_BRCH_CD      :=  C1.PROC_BRCH_CD;
                    T_PROC_AGNC_BRCH    :=  C1.PROC_AGNC_BRCH;
                    T_EXCH_BRCH_CD      :=  C1.EXCH_BRCH_CD;
                    T_EXCH_AGNC_BRCH    :=  C1.EXCH_AGNC_BRCH;
                END IF;



            -- 위의 모든 예외 경우가 아닌 경우
            ELSE
                T_AUTO_SLIP_RFLN_TP := 'Y'; -- 처리대상
                T_PROC_BRCH_CD      :=  C1.PROC_BRCH_CD;
                T_PROC_AGNC_BRCH    :=  C1.PROC_AGNC_BRCH;
                T_EXCH_BRCH_CD      :=  C1.EXCH_BRCH_CD;
                T_EXCH_AGNC_BRCH    :=  C1.EXCH_AGNC_BRCH;
            END IF; -- end of 계좌간 이체입출금 아닌경우


            --고객거래가 아닌경우 타점구분은 해당사항없음(00)
            --IF  C1.RMRK_JOB_TP <> '10' THEN
            --    T_ABNH_TP := '10';
            IF  C1.RMRK_JOB_TP NOT LIKE '1%'  THEN
                -- T_ABNH_TP := '10';
                T_ABNH_TP := '00';

            --고객거래인경우 처리지점과 대체지점 일치여부를 가지고 자타구분 결정
            ELSE
       --         IF  T_PROC_BRCH_CD  = T_EXCH_BRCH_CD   AND T_PROC_AGNC_BRCH = T_EXCH_AGNC_BRCH THEN
       --       회계는 출장소 회계 처리 하지 않음 2008-02-14
                IF  T_PROC_BRCH_CD  = T_EXCH_BRCH_CD  THEN
                    T_ABNH_TP := '10';      --자자
                ELSE
                    T_ABNH_TP := '20';      --타자
                END IF;

                -- 은행연계계좌인 경우는 무조건 본사대체(40) 이다  2008-05-27
                IF C1.RMRK_JOB_TP IN ('12','13') THEN
                        T_ABNH_TP := '40';      --본사
                        T_PROC_BRCH_CD      :=  '901';  --지점코드(= 본사 9010
                        T_PROC_AGNC_BRCH    :=  '00';--대리지점
                        T_EXCH_BRCH_CD      :=  C1.EXCH_BRCH_CD;
                        T_EXCH_AGNC_BRCH    :=  C1.EXCH_AGNC_BRCH;
/*
                    IF  C1.RMRK_TRD_TP IN ('621','622','712') THEN
                        T_ABNH_TP := '10';      --자자
                    ELSE
                        T_ABNH_TP := '40';      --본사
                    END IF;

                    -- 은행연계계좌인 경우 전표는 본사(901)로 발생하며 매매수수료(621,622), 예탁담보대출상환수수료(712)만 해당 지점으로 발생함 2008-05-27
                    IF  C1.RMRK_TRD_TP  NOT IN ('621','622','712') THEN
                        T_PROC_BRCH_CD      :=  '901';  --지점코드(= 본사 9010
                        T_PROC_AGNC_BRCH    :=  '00';--대리지점
                        T_EXCH_BRCH_CD      :=  C1.EXCH_BRCH_CD;
                        T_EXCH_AGNC_BRCH    :=  C1.EXCH_AGNC_BRCH;
                    ELSE
                        T_PROC_BRCH_CD      :=  C1.PROC_BRCH_CD;
                        T_PROC_AGNC_BRCH    :=  C1.PROC_AGNC_BRCH;
                        T_EXCH_BRCH_CD      :=  C1.EXCH_BRCH_CD;
                        T_EXCH_AGNC_BRCH    :=  C1.EXCH_AGNC_BRCH;
                    END IF;
*/
                END IF;
            END IF;


            --회계적요코드 조합
            T_ACC_RMRK_CD := C1.RMRK_JOB_TP || C1.RMRK_TRD_TP  || T_ABNH_TP;

            FOR    C3 IN(
                SELECT  A.AUTO_TP
                    FROM GGA03C00 A
                  WHERE A.ACC_RMRK_CD = T_ACC_RMRK_CD
            )LOOP
                 T_AUTO_TP  := C3.AUTO_TP;
            END LOOP;

            -- IF Manual DK then Skip...
            IF T_AUTO_TP = '2' THEN
                T_AUTO_SLIP_RFLN_TP := 'M'; -- not processing target!
                T_ERR_MSG   := 'Dinh Khoan['|| T_ACC_RMRK_CD ||']  is Manual Dinh Khoan.  Skip processing !!!';
            END IF;


            -- 처리구분이 'Y' 인경우만 처리
            IF T_AUTO_SLIP_RFLN_TP = 'Y' THEN

                -- -------------
                --입력거래 처리
                -- -------------
                IF  C1.AUTO_SLIP_PROC_TP = 'I' THEN

/*
                        --고객거래가 아닌경우 타점구분은 무조건 자점분자점(10)
                       -- IF  C1.RMRK_JOB_TP <> '10' THEN
                        IF  C1.RMRK_JOB_TP NOT LIKE '1%'  THEN
                            -- T_ABNH_TP := '10';
                            T_ABNH_TP := '40';
                        --고객거래인경우 처리지점과 대체지점 일치여부를 가지고 자타구분 결정
                        ELSE
                        --    IF  T_PROC_BRCH_CD  = T_EXCH_BRCH_CD   AND T_PROC_AGNC_BRCH = T_EXCH_AGNC_BRCH THEN
                       --       회계는 출장소 회계 처리 하지 않음 2008-02-14
                            IF  T_PROC_BRCH_CD  = T_EXCH_BRCH_CD    THEN
                                T_ABNH_TP := '10';      --자자
                            ELSE
                                T_ABNH_TP := '20';      --타자
                            END IF;
                        END IF;


                        --회계적요코드 조합
                        T_ACC_RMRK_CD := C1.RMRK_JOB_TP || C1.RMRK_TRD_TP  || T_ABNH_TP;

*/
                        -- CREATE VOUCHER
                        PGG_CREATE_VOUCHER
                        (
                             C1.PROC_DT                            --전표일자
                            ,C1.AUTO_SLIP_PROC_TP                  --전표처리구분(I:입력전표, D:취소전표)
                            ,T_PROC_BRCH_CD                       --처리지점코드
                            ,T_PROC_AGNC_BRCH                     --처리대리지점
                            ,C1.ACNT_NO                            --계좌번호
                            ,C1.TRD_DT                             --거래일
                            ,C1.TRD_SEQ_NO                         --거래일련번호
                            ,C1.ORIG_TRD_SEQ_NO                    --원천거래일련번호
                            ,C1.RMRK_JOB_TP                        --적요업무구분
                            ,T_ACC_RMRK_CD                         --회계적요코드
                            ,T_EXCH_BRCH_CD                       --대체지점코드(계좌관리점)
                            ,T_EXCH_AGNC_BRCH                     --대체대리지점(계좌관리점)
                            ,C1.DR_AMT_01                          --차변금액01
                            ,C1.DR_AMT_02                          --차변금액02
                            ,C1.DR_AMT_03                          --차변금액03
                            ,C1.DR_AMT_04                          --차변금액04
                            ,C1.DR_AMT_05                          --차변금액05
                            ,C1.DR_AMT_06                          --차변금액06
                            ,C1.DR_AMT_07                          --차변금액07
                            ,C1.DR_AMT_08                          --차변금액08
                            ,C1.DR_AMT_09                          --차변금액09
                            ,C1.DR_AMT_10                          --차변금액10
                            ,C1.CR_AMT_01                          --대변금액01
                            ,C1.CR_AMT_02                          --대변금액02
                            ,C1.CR_AMT_03                          --대변금액03
                            ,C1.CR_AMT_04                          --대변금액04
                            ,C1.CR_AMT_05                          --대변금액05
                            ,C1.CR_AMT_06                          --대변금액06
                            ,C1.CR_AMT_07                          --대변금액07
                            ,C1.CR_AMT_08                          --대변금액08
                            ,C1.CR_AMT_09                          --대변금액09
                            ,C1.CR_AMT_10                          --대변금액10
                            ,C1.DRCT_ACC_ACT_ASN_YN --직접회계계정지정여부 2008-01-25 ( D;차변지정, C:대변지정, M:차/대 지정, N or null:지정안함)
                            ,C1.DR_ACC_ACT_01                --차변회계계정01  2008-01-25
                            ,C1.DR_ACC_ACT_02               --차변회계계정02  2008-01-25
                            ,C1.DR_ACC_ACT_03               --차변회계계정03  2008-01-25
                            ,C1.CR_ACC_ACT_01               --대변회계계정01  2008-01-25
                            ,C1.CR_ACC_ACT_02               --대변회계계정02  2008-01-25
                            ,C1.CR_ACC_ACT_03               --대변회계계정03  2008-01-25
                            ,C1.BANK_CD                         --은행코드 2008-05-27
                            ,C1.WORK_MN                            --작업자
                            ,C1.WORK_DTM                           --작업일시
                            ,C1.WORK_TRM                           --작업단말
                            ,T_SLIP_NO                             --전표번호 (OUT)
                            ,T_PROC_CNT                            -- PROC NUMBER (OUT)
                            );

--pxc_log_write('pgg_cust_recv_snd_slip','  SEO_2 : PGG_CREATE_VOUCHER ,Err_msg=['||T_ERR_MSG||']');


                        -- 생성된 발신전표에 대해 수신전표 생성
                        /*********************/

                        T_RECURSIVE_PROC_CNT := 0;
                        PGG_JOB_RECV_SND_SLIP
                        (   C1.PROC_DT                 --  VOUCHER DATE
                           ,T_PROC_BRCH_CD            --  SENDER
                           ,T_PROC_AGNC_BRCH          --  SENDER
                           ,T_SLIP_NO                  --  VOUCHER NO
                           ,C1.BANK_CD                         --은행코드 2008-05-27
                           ,T_RECURSIVE_PROC_CNT       --  RECURCIVE CALL COUNTER(IN OUT)
                           ,T_PROC_CNT                 -- PROC NUMBER(OUT)
                        );

--pxc_log_write('pgg_cust_recv_snd_slip','  SEO_3 : PGG_JOB_RECV_SND_SLIP ,Err_msg=['||T_ERR_MSG||']');

                -- -------------
                -- 취소거래 처리
                -- -------------
                ELSIF   C1.AUTO_SLIP_PROC_TP = 'D' THEN
/*
pxc_log_write('PGG_CNCL_VOUCHER','C1.PROC_DT=['|| C1.PROC_DT ||'] ');
pxc_log_write('PGG_CNCL_VOUCHER',' T_PROC_BRCH_CD=['|| T_PROC_BRCH_CD  ||'] ');
pxc_log_write('PGG_CNCL_VOUCHER',' T_PROC_AGNC_BRCH=['||  T_PROC_AGNC_BRCH ||'] ');
pxc_log_write('PGG_CNCL_VOUCHER',' C1.ACNT_NO=['||   C1.ACNT_NO||'] ');
pxc_log_write('PGG_CNCL_VOUCHER','  C1.TRD_DT=['||  C1.TRD_DT  ||'] ');
pxc_log_write('PGG_CNCL_VOUCHER','C1.ORIG_TRD_SEQ_NO=['||C1.ORIG_TRD_SEQ_NO  ||'] ');
*/

                    --전표에서 해당 원거래의 전표 찾음
/* 20080825-004 START -------------------------- */
/* 20080825-004 SeoHaeSeok 수정 : 전표에서 해당 원거래의 전표 */

/* ----------------------------------------------------------
                    SELECT  A.SLIP_NO
                      INTO  T_SLIP_NO
                      FROM  GGA06M00 A
                     WHERE  A.SLIP_DT           =   C1.PROC_DT
                       AND  A.BRCH_CD           =   T_PROC_BRCH_CD
                       AND  A.AGNC_BRCH         =   T_PROC_AGNC_BRCH
                       AND  A.ORIG_ACNT_NO      =   C1.ACNT_NO
                       AND  A.ORIG_TRD_DT       =   C1.TRD_DT
                       AND  A.ORIG_TRD_SEQ_NO   =   C1.ORIG_TRD_SEQ_NO
                       AND  A.SLIP_STAT         =   '2'               --승인된 전표만...
                      GROUP BY A.SLIP_NO;
-------------------------------------------------------------*/

                    SELECT  A.SLIP_NO
                      INTO  T_SLIP_NO
                      FROM  GGA06M00 A
                     WHERE  A.SLIP_DT           =   C1.PROC_DT
                       AND  A.BRCH_CD           =   T_PROC_BRCH_CD
                       AND  A.AGNC_BRCH         =   T_PROC_AGNC_BRCH
                       AND  A.ORIG_ACNT_NO      =   C1.ACNT_NO
                       AND  A.ORIG_TRD_DT       =   C1.TRD_DT
                       AND  A.ORIG_TRD_SEQ_NO   =   C1.ORIG_TRD_SEQ_NO
                       AND  A.SLIP_STAT         =   '2'               --승인된 전표만...
                       AND  ROWNUM				<=	1;

/* 20080825-004 END -------------------------- */


--pxc_log_write('PGG_CNCL_VOUCHER','dddddddd] ');


                    PGG_CNCL_VOUCHER
                    (    C1.PROC_DT                   --전표일자
                        ,T_PROC_BRCH_CD              --지점코드
                        ,T_PROC_AGNC_BRCH            --대리지점
                        ,T_SLIP_NO                    --전표번호
                        ,T_PROC_CNT                   --PROC NUMBER
                    );

                -- LOG의 처리구분이 잘못된경우
                ELSE
                    RAISE_APPLICATION_ERROR(-20001,'GGA07M00 AUTO_SLIP_PROC_TP['||C1.AUTO_SLIP_PROC_TP||'] IS INVALID');
                END IF; -- END OF 처리(입력/취소)
                T_ERR_MSG := NULL;

            ELSIF T_AUTO_SLIP_RFLN_TP = 'M' THEN
                T_SKIP_CNT := T_SKIP_CNT + 1;
            END IF; -- END OF T_AUTO_SLIP_RFLN_TP = 'Y'

            -- =============
            -- 자동전표 log 처리완료 표시
            -- =============
            UPDATE  GGA07M00
               SET  AUTO_SLIP_RFLN_TP   =   T_AUTO_SLIP_RFLN_TP  --N:Not processed ,Y:Processed,M:Processed(not apply) ,X:Processing failed
                   ,AUTO_SLIP_PROC_MN   =   I_PROC_MN
                   ,AUTO_SLIP_PROC_DTM  =   SYSDATE
                   ,AUTO_SLIP_PROC_TRM  =   I_PROC_TRM
                   ,AUTO_SLIP_ERR_CONT  =   T_ERR_MSG
                   ,AUTO_SLIP_DT        =   DECODE(T_AUTO_SLIP_RFLN_TP,'Y',C1.PROC_DT           ,NULL)
                   ,AUTO_SLIP_BRCH_CD   =   DECODE(T_AUTO_SLIP_RFLN_TP,'Y',T_PROC_BRCH_CD       ,NULL)
                   ,AUTO_SLIP_AGNC_BRCH =   DECODE(T_AUTO_SLIP_RFLN_TP,'Y',T_PROC_AGNC_BRCH     ,NULL)
                   ,AUTO_SLIP_NO        =   DECODE(T_AUTO_SLIP_RFLN_TP,'Y',T_SLIP_NO            ,NULL)
             WHERE  ROWID = T_GGA07M00_ROWID;
            -- =============
            -- 자동전표 log 한 건 처리 할때 마다 commit;
            -- =============
            O_PROC_CNT  :=  O_PROC_CNT + 1;
            COMMIT;

        EXCEPTION WHEN OTHERS THEN -- EXCEPTION HANDALER OF MAIN LOOP
            T_ERR_MSG   :=  SQLERRM;
            pxc_log_write('pgg_cust_recv_snd_slip','  **Error occured!!! ,Err_msg=['||T_ERR_MSG||']');

            --지금까지 처리한 것 rollback;
            ROLLBACK;

            -- =============
            -- 자동전표 log 처리실패 표시
            -- =============
            UPDATE  GGA07M00
               SET  AUTO_SLIP_RFLN_TP   =   'X'  --N:Not processed ,Y:Processed,M:Processed(not apply) ,X:Processing failed
                   ,AUTO_SLIP_PROC_MN   =   I_PROC_MN
                   ,AUTO_SLIP_PROC_DTM  =   SYSDATE
                   ,AUTO_SLIP_PROC_TRM  =   I_PROC_TRM
                   ,AUTO_SLIP_ERR_CONT  =   T_ERR_MSG
                   ,AUTO_SLIP_DT        =   NULL
                   ,AUTO_SLIP_BRCH_CD   =   NULL
                   ,AUTO_SLIP_AGNC_BRCH =   NULL
                   ,AUTO_SLIP_NO        =   NULL
             WHERE  ROWID = T_GGA07M00_ROWID;
            COMMIT;

            T_ERR_CNT   := T_ERR_CNT + 1;

        END;    -- END OF MAIN LOOP

        T_TOT_CNT := T_TOT_CNT + 1;
    END LOOP;   -- END OF C1
    pxc_log_write('pgg_cust_recv_snd_slip',' End[Tot-Success-Gen-Skip-Err]=['||TO_CHAR(T_TOT_CNT)||'-'||TO_CHAR(O_PROC_CNT)||'-'||TO_CHAR(O_PROC_CNT - T_SKIP_CNT)||'-'||TO_CHAR(T_SKIP_CNT)||'-'||TO_CHAR(T_ERR_CNT)||']');
END PGG_CUST_RECV_SND_SLIP;    -- end of MAIN
/

