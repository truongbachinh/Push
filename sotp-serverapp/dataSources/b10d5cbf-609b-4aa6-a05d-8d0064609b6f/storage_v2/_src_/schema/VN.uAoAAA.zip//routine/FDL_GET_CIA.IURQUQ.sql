create FUNCTION    fdl_get_cia
(
	i_acnt_no  in 		varchar2,
	i_sub_no   in 		varchar2
) return number is

  t_temp           number := 0 ;
  t_avl_dpo        number := 0 ;
  t_dpo            number := 0 ;

  t_err_msg        varchar2(500)  ;
  t_err_code       varchar2(5)    ;
  t_err_txt        varchar2(500)  ;

  t_avl_cash       number := 0 ;

  t_rgt_reuse      number := 0 ; /* rights reuse amount */
  t_rgt_sbst       number := 0 ; /* rights substitution amount */
  t_sbst_dpo       number := 0 ; /* stock substitution amount  */
  t_crd_dpo        number := 0 ; /* margin deposit */
  t_dpo_block      number := 0 ; /* deposit block  */
  t_outq_dpo_bk    number := 0 ; /* deposit block  */
  t_sbst_proof     number := 0 ; /* order block  */
  t_mrgn_shortage  number := 0 ; /* Margin shortage */


  t_margin_loan    number := 0 ; /* margin loan */
  t_money_loan     number := 0 ; /* money loan */
  t_nonrpy_loan    number := 0 ; /* nor repaied loan amount */
  t_buying_loan    number := 0 ; /* colletral loan */
  t_pia            number := 0 ; /* PIA */
  t_mrgn_expt_int  number := 0 ;
  t_rll            number := 0 ; /* RLL */
  t_reuse_sbst     number := 0 ; /* Reuse + SBST */
  t_reuse_sbst_al  number := 0 ; /* Min ( Reuse + SBST, RLL ) */

/* pts */

/* pts_2 */
  t_tot_prof_rel_amt       number := 0;
  t_bfr_prof_rel_amt       number := 0;
  t_tot_prof_cdt_amt       number := 0;
  t_bfr_prof_cdt_amt       number := 0;
  t_tot_all_prof_vit_amt   number := 0;
  t_bfr_all_prof_vit_amt   number := 0;
  t_tot_all_reuse_dpo      number := 0;
  t_tot_all_sbst_diff_amt  number := 0;
  t_tot_ts_sbst_diff_amt   number := 0;
  t_td_prof_rel_amt        number := 0;
  t_td_all_prof_vit_amt    number := 0;
  t_tot_ts_expt_sbst_amt   number := 0;


  t_check          number := 10000000 ; /* SBST deposit */

  t_cia            number := 0 ;
  t_cia_sbst       number := 0 ;
  t_aval_dpo       number := 0 ;
  t_mrgn_expt_amt  number := 0 ;

begin

    begin
	    select  dpo
              , rgt_reuse
			  , rgt_sbst
			  , crd_dpo
			  , dpo_block
			  , outq_dpo_bk
			  , sbst_proof
          into  t_dpo
			  , t_rgt_reuse
			  , t_rgt_sbst
			  , t_crd_dpo
			  , t_dpo_block
			  , t_outq_dpo_bk
			  , t_sbst_proof
	      from vn.cwd01m00
	     where acnt_no = i_acnt_no
		   and sub_no  = i_sub_no;

    EXCEPTION
         WHEN   OTHERS THEN
		 return 0 ;
    END;



    /*
	t_bfr_prof_rel_amt : PBA
	t_td_prof_rel_amt  : TBA
	*/

    BEGIN

    vn.pts_acnt_prof_ord_g(  i_acnt_no
                           , i_sub_no
                           , '9999'
						   , t_tot_prof_rel_amt
						   , t_bfr_prof_rel_amt
						   , t_tot_prof_cdt_amt
						   , t_bfr_prof_cdt_amt
						   , t_tot_all_prof_vit_amt
						   , t_bfr_all_prof_vit_amt
						   , t_tot_all_reuse_dpo
						   , t_tot_all_sbst_diff_amt
						   , t_tot_ts_sbst_diff_amt
						   , t_td_prof_rel_amt
						   , t_td_all_prof_vit_amt
						   , t_tot_ts_expt_sbst_amt
                           , t_err_code
                           , t_err_txt);

    EXCEPTION
    WHEN  OTHERS  THEN
         vn.pxc_log_write('fdl_get_cia','pts_acnt_prof_g -'|| t_err_code );
		 return 0 ;
    END;

    t_pia           := vn.fdl_get_mrgn_rt_01(i_acnt_no , i_sub_no,  '07' , vn.vwdate);
    t_money_loan    := vn.fdl_get_mrgn_rt_01(i_acnt_no , i_sub_no,  '14' , vn.vwdate);
    t_margin_loan   := vn.fdl_get_mrgn_rt_01(i_acnt_no , i_sub_no,  '10' , vn.vwdate);
    t_buying_loan   := vn.fdl_get_mrgn_rt_01(i_acnt_no , i_sub_no,  '13' , vn.vwdate);
    t_nonrpy_loan   := vn.fdl_get_nonrpy_amt_expt_mrtg('%' , i_acnt_no, i_sub_no, '9999') ;
    t_mrgn_shortage := vn.fdl_get_lnd_shrt_amt(i_acnt_no, i_sub_no);
    t_mrgn_expt_int := vn.fdl_get_mrgn_expt_int_amt(i_acnt_no, i_sub_no);

    vn.pxc_log_write('fdl_get_cia','acnt_no       :'|| i_acnt_no );
    vn.pxc_log_write('fdl_get_cia','sub_no        :'|| i_sub_no );
    vn.pxc_log_write('fdl_get_cia','t_pia         :'|| t_pia );
    vn.pxc_log_write('fdl_get_cia','t_money_loan  :'|| t_money_loan );
    vn.pxc_log_write('fdl_get_cia','t_margin_loan :'|| t_margin_loan );
    vn.pxc_log_write('fdl_get_cia','t_buying_loan :'|| t_buying_loan );
    vn.pxc_log_write('fdl_get_cia','t_nonrpy_loan :'|| t_nonrpy_loan );
    vn.pxc_log_write('fdl_get_cia','t_mrgn_shortage :'|| t_mrgn_shortage );
    vn.pxc_log_write('fdl_get_cia','t_mrgn_expt_int :'|| t_mrgn_expt_int );

    /*
	  CIA  ( % : sum )

	    Existed cash                  ( dpo in cwd01m00                      )
	  + Bonus cash waiting to deposit ( rgt_reuse in cwd01m00                )
      + RSA                           ( pts_acnt_prof_g --> t_tot_all_reuse_dpo          )
	  + SSA                           ( sbst_dpo in cwd01m00                 )
	  + Expected SBST                 ( pts_acnt_prof_g --> t_expt_sbst      )
	  - (TBA + PBA)                   ( pts_acnt_prof_g --> o_used_alowa_rel )
	  - PIA                           ( fdl_get_mrgn_rt_01 : 07              )
	  - Margin loan                   ( fdl_get_mrgn_rt_01 : 10              )
      - Money  loan                   ( fdl_get_mrgn_rt_01 : 14              )
	  - Manual blcok                  ( dpo_block                            )
	  - Loan for buying               ( fdl_get_mrgn_rt_01 : 13              )
	  - Non repaid loan               ( fdl_get_nonrpy_amt                   )
	  - Expected Margin loan interests  fdl_get_pia_fee

	  Min(RLL, RSA - PIA + SSA + Expected SBST)
	  RLL : fdl_get_mrgn_rt_01 : 05
    */

    SELECT    stk_evltv
          ,  BUY_WAIT_EVLTV - SELL_WAIT_EVLTV
          ,  reuse_dpo - (sell_cmsn + sell_tax + sell_rgt_tax + sell_fee)
      into    t_sbst_dpo
            , t_tot_ts_sbst_diff_amt
            , t_tot_all_reuse_dpo
      FROM vn.cwd99m00
     WHERE acnt_no = i_acnt_no
       AND sub_no  = i_sub_no;

    t_tot_ts_expt_sbst_amt := 0;

    t_rll        := vn.fdl_get_mrgn_rt_01(i_acnt_no , i_sub_no,  '05' , vn.vwdate); /* RLL */
    t_reuse_sbst := t_tot_all_reuse_dpo
                  + t_rgt_reuse
                  + t_sbst_dpo
                  + t_tot_ts_expt_sbst_amt
			      + t_tot_ts_sbst_diff_amt
				  - t_bfr_prof_rel_amt
                  - t_pia
                  - vn.fdl_get_mrgn_rt_01(i_acnt_no, i_sub_no, '21', vn.vwdate)
				  - t_mrgn_expt_int
		          - t_margin_loan
			      - t_money_loan
			      - t_buying_loan
			      - t_nonrpy_loan
			      - t_mrgn_shortage;


    vn.pxc_log_write('fdl_get_cia','t_rll           :'|| t_rll           );
    vn.pxc_log_write('fdl_get_cia','t_reuse_sbst    :'|| t_reuse_sbst    );

	t_reuse_sbst := least(t_rll, t_reuse_sbst);


	t_sbst_dpo   := t_sbst_dpo + t_tot_ts_expt_sbst_amt + t_tot_ts_sbst_diff_amt;
    vn.pxc_log_write('fdl_get_cia','t_sbst_dpo    :'|| t_sbst_dpo    );

	/*
      t_reuse_sbst > 10M ,don't need to check, from cwd01m00
	  CIA < 10M, it is not an error
	*/

	t_aval_dpo := t_dpo - t_dpo_block - t_outq_dpo_bk;

vn.pxc_log_write('fdl_get_cia','t_dpo          :'|| t_dpo    );
vn.pxc_log_write('fdl_get_cia','t_dpo_block    :'|| t_dpo_block    );
vn.pxc_log_write('fdl_get_cia','t_outq_dpo_bk  :'|| t_outq_dpo_bk    );
vn.pxc_log_write('fdl_get_cia','t_aval_dpo     :'|| t_aval_dpo    );

    t_cia :=  t_aval_dpo + t_reuse_sbst - t_td_prof_rel_amt;

vn.pxc_log_write('fdl_get_cia','t_td_prof_rel_amt     :'|| t_td_prof_rel_amt    );
vn.pxc_log_write('fdl_get_cia','t_cia     :'|| t_cia    );

    /*
      Get excpected margin loan + already issued margin loan
      If there is no margin loan, Margin deposit(10M) doesn't need to be blocked
      else Margin deposit(10M) need to block
    */

    t_mrgn_expt_amt := vn.fdl_get_mrgn_expt_amt(i_acnt_no, i_sub_no, '3');
	vn.pxc_log_write('fdl_get_cia','t_mrgn_expt_amt    :'|| t_mrgn_expt_amt    );

    if t_mrgn_expt_amt = 0 then
       t_crd_dpo := 0;
    else

	   if t_sbst_dpo < t_crd_dpo then
          if t_cia < t_crd_dpo then
	         return -999999999;
          end if;
       else
		  if t_cia < t_crd_dpo then
			 return 0;
          end if;
       end if;

    end if;

    if t_cia >= t_aval_dpo then

	   t_reuse_sbst_al := t_cia - t_aval_dpo ;
       vn.pxc_log_write('fdl_get_cia','t_reuse_sbst_al(cash) :'|| t_reuse_sbst_al );

    else

	   t_reuse_sbst_al := 0;

    end if;

    /* CIA must be greater than 10M( Margin deposit ) */
    vn.pxc_log_write('fdl_get_cia','CIA before :'|| t_cia );
    vn.pxc_log_write('fdl_get_cia','t_td_prof_rel_amt :'|| t_td_prof_rel_amt );

    t_cia_sbst :=  t_reuse_sbst_al
			     - t_crd_dpo
			     - t_tot_prof_rel_amt
			     ;

    vn.pxc_log_write('fdl_get_cia','CIA_SBST :'|| t_cia_sbst );

    return t_cia_sbst  ;

end fdl_get_cia;
/

