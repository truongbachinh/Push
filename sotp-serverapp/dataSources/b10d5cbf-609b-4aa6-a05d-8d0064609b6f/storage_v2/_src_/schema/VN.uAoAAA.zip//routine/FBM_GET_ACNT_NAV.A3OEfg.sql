create function fbm_get_acnt_nav(
    i_acnt_no       varchar2,
    i_sub_no        varchar2,
    i_dt            varchar2
)
/*
    select fbm_get_acnt_nav(
        '039C000006',       -- i_acnt_no       varchar2,
        '01',               -- i_sub_no        varchar2,
        vwdate              -- i_dt            varchar2
    ) a
    from dual;
*/
return number

as
    t_vwdate        varchar2(8)     := vn.vwdate;
    t_nav           number          := 0;
    o_ret           number          := 0;

begin
    -- So du tien: Tien giao dich + Tien ban cho tt chua ung + Co tuc cho ve + Tien phong toa
    -- So du CK: CK giao dich + CK mua cho ve + CK cho giao dich + CK phong toa + CK quyen cho ve
    -- Tong no: No goc margin + Lai vay tam tinh + No phi luu ky

    with stg as(
        select 
            c9.dpo + c9.reuse_dpo + c9.cdr_amt                      cash_balance,
            c9.tot_stk_amt                                          stk_balance,
            c9.mrgn_loan_nowrm + c9.mrgn_loan_int + c1.dpo_fee_bk   tot_loan
        from vn.cwd99m00 c9
        inner join cwd01m00 c1
        on c9.acnt_no = c1.acnt_no
        and c9.sub_no = c1.sub_no
        where t_vwdate = i_dt
        and c9.acnt_no = i_acnt_no
        and c9.sub_no = i_sub_no

        union all

        select 
            c9.dpo + c9.reuse_dpo + c9.cdr_amt                      cash_balance,
            c9.tot_stk_amt                                          stk_balance,
            c9.mrgn_loan_nowrm + c9.mrgn_loan_int + c1.dpo_fee_bk   tot_loan
        from vn.cwd99h00 c9
        inner join cwd01h00 c1
        on c9.acnt_no = c1.acnt_no
        and c9.sub_no = c1.sub_no
        and c9.dt = c1.std_dt
        where t_vwdate <> i_dt
        and c9.dt = i_dt
        and c9.acnt_no = i_acnt_no
        and c9.sub_no = i_sub_no

    )
    select
        cash_balance + stk_balance - tot_loan
    into 
        t_nav
    from stg
    ;

    o_ret := t_nav;

    return o_ret;

end fbm_get_acnt_nav;
/

