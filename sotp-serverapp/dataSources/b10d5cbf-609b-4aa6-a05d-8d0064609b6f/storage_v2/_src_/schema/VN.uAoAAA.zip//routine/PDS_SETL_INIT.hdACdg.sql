create procedure pds_setl_init
(
	i_dt          in     varchar2,        --
	i_bank_cd     in     varchar2,        -- bank_cd
	i_work_mn     in     varchar2,        -- user id
	i_work_trm    in     varchar2,
	o_cnt         in out number
) AS
/*============================================================================*/
-- 1. Process Name : pds_setl_init                                           --
-- 2. Process func : setl_yn change                                           --
-- 3. developer    :                                                          --
-- 4. modifier     :                                                          --
-- 5. note         :                                                          --
/*============================================================================*/

/*!
   \file     pds_setl_init.sql
   \brief    tax calculation

   \section intro Program Information
        - Program Name              : setl_yn change
        - Service Name              :
        - Related Client Program- Client Program ID :
        - Related Tables            : dsc01m00
        - Dev. Date                 : 2007/11/08
        - Developer                 : Han.
        - Business Logic Desc.      : tax calculation
        - Latest Modification Date  : 2007/11/08

   \section history Program Modification History
    - 1.0       2008/11/17     Han.    New.

   \section hardcoding Hard-Coding List
    - HC-1      2007/11/17     Han.    [��]

   \section info Additional Reference Comments
    - tax calculation

var o_cnt number;
exec pds_setl_init('20090119','%','Test','Test',:o_cnt);
print o_cnt

*/

    t_pppre_mth_dt     VARCHAR2(08) := null;  --
    t_ppre_mth_dt      VARCHAR2(08) := null;  --
    t_pre_mth_dt       VARCHAR2(08) := null;  --
    t_now_mth_dt       VARCHAR2(08) := null;  --

    t_sqlcode          NUMBER       := 0;
    t_err_msg          VARCHAR2(500);

begin

    o_cnt  := 0;
    /*========================================================================*/
    /* Set Date                                                               */
    /*========================================================================*/
    t_pppre_mth_dt := vn.fxc_vorderdt_g(to_date(i_dt,'yyyymmdd'), -3);
    t_ppre_mth_dt  := vn.fxc_vorderdt_g(to_date(i_dt,'yyyymmdd'), -2);
    t_pre_mth_dt   := vn.fxc_vorderdt_g(to_date(i_dt,'yyyymmdd'), -1);
    t_now_mth_dt   := i_dt ;

/*============================================================================*/
/* ( Calculateion )                                                           */
/*  when be individual account, have to collect income tax - 2008/12/22       */
/*============================================================================*/
    begin
        for C1 in (
            select  rowid                 arowid
                 ,  setl_dt               setl_dt           --
                 ,  acnt_no               acnt_no           --
                 ,  sub_no				  sub_no
                 ,  setl_frct_seq_no      setl_frct_seq_no  --
                 ,  dpo_setl_yn
                 ,  cmsn_setl_yn
                 ,  tax_setl_yn
              from  vn.dsc01m00
             where  mth_dt    between  t_pppre_mth_dt and i_dt
               and  bank_cd      like  i_bank_cd
               and  (dpo_setl_yn    =  'E'  or
                     cmsn_setl_yn   =  'E'  )
             order  by  setl_dt, acnt_no, sub_no, setl_frct_seq_no
        ) loop
            o_cnt  :=  o_cnt +1;

            --  UPDATE
            update  vn.dsc01m00
               set  dpo_setl_yn       =  decode(dpo_setl_yn,'E','M',dpo_setl_yn)
                 ,  cmsn_setl_yn      =  decode(cmsn_setl_yn,'E','M',cmsn_setl_yn)
                 ,  tax_setl_yn       =  decode(tax_setl_yn,'E','M',tax_setl_yn)
             where  setl_dt           =  C1.setl_dt
               and  acnt_no           =  C1.acnt_no
               and  sub_no            =  C1.sub_no
               and  setl_frct_seq_no  =  C1.setl_frct_seq_no
               and  rowid             =  C1.arowid
            ;

        end loop;

    exception when others then
        t_sqlcode := sqlcode;
        t_err_msg := vn.fxc_get_err_msg('V','2713');
        raise_application_error(-20100,t_err_msg);

    end;


end pds_setl_init;
/

