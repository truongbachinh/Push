create procedure pxc_psb_seq_cret_p (
	i_acnt_no	in	varchar2,
	i_sub_no	in	varchar2,
	i_trd_dt	in	varchar2,
    o_trd_seq	out	number  ,
	o_tot_seq   out number

) as

t_trd_seq	number;
t_tot_seq	number;
t_trd_dt	varchar2(8);
t_rowid     rowid;
t_proc_nm	varchar2(50);
t_err_txt	varchar2(255);

begin

vn.pxc_log_write('pxc_psb_seq_cret_p','i_acnt_no-'||i_acnt_no);
vn.pxc_log_write('pxc_psb_seq_cret_p','i_sub_no-'||i_sub_no);
vn.pxc_log_write('pxc_psb_seq_cret_p','i_trd_dt-'||i_trd_dt);

	t_proc_nm := 'getting sequence';
	o_trd_seq := NULL;

	begin
		select	rowid,
				lst_trd_dt,
				decode(lst_trd_dt, i_trd_dt, nvl(lst_trd_no,0)+1, 1) trd_seq
		  into 	t_rowid,
		  		t_trd_dt,
		  		t_trd_seq
		  from 	vn.aaa01m00
		 where 	acnt_no = i_acnt_no
		   and  sub_no  = i_sub_no
		   for 	update of lst_trd_no;
	exception
		when no_data_found then
			t_err_txt := t_proc_nm
					 ||  '('  ||  i_acnt_no  ||  ')'
					 ||  '('  ||  i_sub_no   ||  ')';
			raise_application_error(-20100, t_err_txt);
	end;

    vn.pxc_log_write('pxc_psb_seq_cret_p','t_trd_seq-'||t_trd_seq);

	begin
		if t_trd_seq = 1 then
			update	vn.aaa01m00
			   set	lst_trd_no     = t_trd_seq
				   ,lst_trd_dt     = i_trd_dt
			 where 	rowid = t_rowid;
		else
			update	vn.aaa01m00
			   set	lst_trd_no = t_trd_seq
			 where 	rowid = t_rowid;
		end if;

	exception
		when others	then
			t_err_txt := t_proc_nm
					 || '거래일련번호 처리 오류 계좌_원장(aaa01m00)'
	                 ||  '('  ||  to_char(sqlcode)  ||  ')';
			raise_application_error(-20100, t_err_txt);
	end;

    begin
        select  sum(decode(lst_trd_dt, i_trd_dt, nvl(lst_trd_no,0), 0)) tot_seq
          into  t_tot_seq
          from  vn.aaa01m00
         where  acnt_no = i_acnt_no
       group by acnt_no  ;
    exception
        when no_data_found then
            t_err_txt := t_proc_nm
                     ||  '('  ||  i_acnt_no  ||  ')'
                     ||  '('  ||  i_sub_no   ||  ')';
            raise_application_error(-20100, t_err_txt);
    end;

	update vn.aaa01m00
	   set tot_lst_trd_no = t_tot_seq
     where acnt_no = i_acnt_no
	   and acnt_stat = '1' ;

    o_trd_seq := t_trd_seq ;
    o_tot_seq := t_tot_seq ;

    vn.pxc_log_write('pxc_psb_seq_cret_p','o_tot_seq-'||o_tot_seq );


end pxc_psb_seq_cret_p;
/

