create function fbm_acnt_grp_nm_q
(
    i_acnt_grp_no   in   varchar2
)
    return          varchar2
as

    o_acnt_grp_nm		varchar2(100) ;
    t_err_txt       varchar2(100)  ; -- error text buffer

begin

    o_acnt_grp_nm  :=  NULL;

vn.pxc_log_write('fbm_acnt_grp_nm_q','i_acnt_grp_no-'||i_acnt_grp_no);

    begin
      	select nvl(acnt_grp_nm, ' ')
		  into o_acnt_grp_nm
          from vn.aaa09m10
         where acnt_grp_no	= i_acnt_grp_no;
    exception
        when  NO_DATA_FOUND  then
			return  '!';
        when  OTHERS         then
            t_err_txt  :=  'Error '||to_char(sqlcode)||']';
            raise_application_error (-20100, t_err_txt);
    end;

    return  o_acnt_grp_nm;

end fbm_acnt_grp_nm_q;
/

