create PROCEDURE    PGG_REP_CA_SUB
   (I_WORK_TRM      IN      VARCHAR2,       -- IP_ADDRESS
    I_BRCH_CD       IN      VARCHAR2,       -- 지점
    I_AGNC_BRCH     IN      VARCHAR2,       -- 대리지점
    I_CLS_DT        IN      VARCHAR2,       -- 기준일자
    I_CLS_DT2       IN      VARCHAR2,       -- 기준일자
    I_TERMS_TP      IN      VARCHAR2,       -- 회기구분(1:당,2:전)
    I_WORK_MN       IN      VARCHAR2,		-- 처리자
    I_FRM_NO        IN      VARCHAR2,		-- 양식번호
    I_FS_TP         IN      VARCHAR2		-- 02:손익계산서
	) IS

    -- Constants
    K_ALL_BRCH      VARCHAR2(3) := '000' ;      -- 회사전체

    -- Variables
    T_DR_AMT_S    NUMBER := 0;    -- 차변금액계
    T_CR_AMT_S    NUMBER := 0;    -- 대변금액계
    T_DR_AMT      NUMBER := 0;    -- 차변금액
    T_CR_AMT      NUMBER := 0;    -- 대변금액

    -- Variables
    T_DR_CR_TP      VARCHAR2(1);
    T_TERMS         NUMBER := 0;
    T_OPN_DT        VARCHAR2(8);
    T_END_DT        VARCHAR2(8);
    T_TERM_TP       VARCHAR2(1);
    T_DR_SUM_AMT    NUMBER := 0;
    T_CR_SUM_AMT    NUMBER := 0;
    T_ACC_CLS_YN    VARCHAR2(1);

    -- 원시자료값 Return
    PROCEDURE GET_SORC_DATA
       (I_CAL_LOC       IN      VARCHAR2,       -- 연산장소
        I_OBJ_CAL_LOC   IN      VARCHAR2,       -- 차/대
        I_ACC_ACT_CD    IN      VARCHAR2,       -- 회계계정코드
        I_OPR_ACT_CD_01 IN      VARCHAR2,       -- 상대계정코드01
        I_OPR_ACT_CD_02 IN      VARCHAR2,       -- 상대계정코드02
        I_OPR_ACT_CD_03 IN      VARCHAR2,       -- 상대계정코드03
        I_OPR_ACT_CD_04 IN      VARCHAR2,       -- 상대계정코드04
        I_OPR_ACT_CD_05 IN      VARCHAR2,       -- 상대계정코드05
        I_OPR_ACT_CD_06 IN      VARCHAR2,       -- 상대계정코드06
        O_DR_AMT        IN OUT  NUMBER,         -- 금액1
        O_CR_AMT        IN OUT  NUMBER			-- 금액2
		) IS

        T_AMT       NUMBER := 0;

    BEGIN
        -- 2_2_2_1_1) 금액항목 초기화
        O_DR_AMT := 0;
        O_CR_AMT := 0;

        -- 2_2_2_1_2) 차변대변잔액구분 조회
        BEGIN
            SELECT  a.DR_CR_TP      AS  DR_CR_TP
              INTO  T_DR_CR_TP
    		  FROM	VN.GGA02C00 a   -- 회계계정
    		 WHERE	a.ACC_ACT_CD	=	I_ACC_ACT_CD
    		   AND	ROWNUM			<=	1 ;
        EXCEPTION WHEN  NO_DATA_FOUND THEN
            T_DR_CR_TP := '1';
        END;

        -- 2_2_2_1_3) 회계기수, 시작일, 종료일, 회기시작구분 조회
        BEGIN
        	SELECT	a.TERMS			AS	TERMS,
        			a.OPN_DT		AS	OPN_DT,
        			a.END_DT		AS	END_DT,
        	   		CASE
        	   			WHEN	SUBSTR(a.OPN_DT, 5, 2)	=	SUBSTR(I_CLS_DT, 5, 2)	THEN	'0'
        	   			ELSE	'1'
        			END				AS	TERM_TP
              INTO  T_TERMS,
                    T_OPN_DT,
                    T_END_DT,
                    T_TERM_TP
        	  FROM	VN.GGA01C00 A
        	 WHERE	I_CLS_DT	BETWEEN	A.OPN_DT AND A.END_DT
        	   AND	ROWNUM	<=	1;
        EXCEPTION WHEN  NO_DATA_FOUND THEN
            T_AMT := 0;
        END;

        BEGIN

			SELECT	NVL(SUM(v11.DR_ACCM_AMT), 0)	AS	DR_ACCM_AMT,
					NVL(SUM(v11.CR_ACCM_AMT), 0)	AS	CR_ACCM_AMT
              INTO  T_DR_SUM_AMT,
                    T_CR_SUM_AMT
			  FROM
					(	SELECT	v21.ACC_ACT_CD					AS	ACC_ACT_CD,
								v21.OPR_ACC_ACT_CD				AS	OPR_ACC_ACT_CD,
								NVL(SUM(v21.DR_ACCM_AMT), 0)	AS	DR_ACCM_AMT,
								NVL(SUM(v21.CR_ACCM_AMT), 0)	AS	CR_ACCM_AMT
						  FROM
								(	SELECT	v31.ACC_CLS_DT					AS	ACC_CLS_DT,
											DECODE(I_BRCH_CD, K_ALL_BRCH,
												K_ALL_BRCH, v31.BRCH_CD)	AS	BRCH_CD,
											v31.AGNC_BRCH					AS	AGNC_BRCH,
											v31.ACC_ACT_CD_DR				AS	ACC_ACT_CD,
											v31.ACC_ACT_CD_CR				AS	OPR_ACC_ACT_CD,
											NVL(v31.DR_ACCM_AMT, 0)			AS	DR_ACCM_AMT,
											0								AS	CR_ACCM_AMT
									  FROM	VN.GGA08M01	v31
									 WHERE	v31.ACC_CLS_DT		>=	I_CLS_DT
									   AND	v31.ACC_CLS_DT		<=	I_CLS_DT2
									   AND	v31.BRCH_CD			=	DECODE(I_BRCH_CD, K_ALL_BRCH, v31.BRCH_CD, I_BRCH_CD)
									   AND	v31.AGNC_BRCH		=	I_AGNC_BRCH
									   AND	v31.ACC_ACT_CD_DR	IN	(	SELECT	v41.ACC_ACT_CD		AS	ACC_ACT_CD
																		  FROM	VN.GGA02C00	v41,
																				(	SELECT	v51.ACC_ACT_CD		AS	ACC_ACT_CD,
																							v51.ACT_UNIT_TP		AS	ACT_UNIT_TP
																					  FROM	VN.GGA02C00	v51
																					 WHERE	v51.ACC_ACT_CD	=	I_ACC_ACT_CD
																				)			v42
																		 WHERE	v42.ACC_ACT_CD	=	DECODE(v42.ACT_UNIT_TP,
																										'1', v41.LVL1_CD, '2', v41.LVL2_CD,
																										'3', v41.LVL3_CD, '4', v41.LVL4_CD,
																										'5', v41.LVL5_CD, v41.ACC_ACT_CD)
																		   AND	NVL(v41.SLIP_OCUR_YN, 'N')	=	'Y'
																	)
								UNION ALL
									SELECT	v31.ACC_CLS_DT					AS	ACC_CLS_DT,
											DECODE(I_BRCH_CD, K_ALL_BRCH,
												K_ALL_BRCH, v31.BRCH_CD)	AS	BRCH_CD,
											v31.AGNC_BRCH					AS	AGNC_BRCH,
											v31.ACC_ACT_CD_CR				AS	ACC_ACT_CD,
											v31.ACC_ACT_CD_DR				AS	OPR_ACC_ACT_CD,
											0								AS	DR_ACCM_AMT,
											NVL(v31.CR_ACCM_AMT, 0)			AS	CR_ACCM_AMT
									  FROM	VN.GGA08M01	v31
									 WHERE	v31.ACC_CLS_DT		>=	I_CLS_DT
									   AND	v31.ACC_CLS_DT		<=	I_CLS_DT2
									   AND	v31.BRCH_CD			=	DECODE(I_BRCH_CD, K_ALL_BRCH, v31.BRCH_CD, I_BRCH_CD)
									   AND	v31.AGNC_BRCH		=	I_AGNC_BRCH
									   AND	v31.ACC_ACT_CD_CR	IN	(	SELECT	v41.ACC_ACT_CD		AS	ACC_ACT_CD
																		  FROM	VN.GGA02C00	v41,
																				(	SELECT	v51.ACC_ACT_CD		AS	ACC_ACT_CD,
																							v51.ACT_UNIT_TP		AS	ACT_UNIT_TP
																					  FROM	VN.GGA02C00	v51
																					 WHERE	v51.ACC_ACT_CD	=	I_ACC_ACT_CD
																				)			v42
																		 WHERE	v42.ACC_ACT_CD	=	DECODE(v42.ACT_UNIT_TP,
																										'1', v41.LVL1_CD, '2', v41.LVL2_CD,
																										'3', v41.LVL3_CD, '4', v41.LVL4_CD,
																										'5', v41.LVL5_CD, v41.ACC_ACT_CD)
																		   AND	NVL(v41.SLIP_OCUR_YN, 'N')	=	'Y'
																	)
								)			v21
						 WHERE	v21.OPR_ACC_ACT_CD	IN	(	SELECT	v31.ACC_ACT_CD		AS	ACC_ACT_CD
															  FROM	VN.GGA02C00	v31,
																	(	SELECT	v41.ACC_ACT_CD		AS	ACC_ACT_CD,
																				v41.ACT_UNIT_TP		AS	ACT_UNIT_TP
																		  FROM	VN.GGA02C00	v41
																		 WHERE	v41.ACC_ACT_CD	LIKE	DECODE(I_OPR_ACT_CD_01, '%', '%', I_OPR_ACT_CD_01)
																	UNION ALL
																		SELECT	v41.ACC_ACT_CD		AS	ACC_ACT_CD,
																				v41.ACT_UNIT_TP		AS	ACT_UNIT_TP
																		  FROM	VN.GGA02C00	v41
																		 WHERE	v41.ACC_ACT_CD	LIKE	DECODE(I_OPR_ACT_CD_02, '%', '%', I_OPR_ACT_CD_02)
																	UNION ALL
																		SELECT	v41.ACC_ACT_CD		AS	ACC_ACT_CD,
																				v41.ACT_UNIT_TP		AS	ACT_UNIT_TP
																		  FROM	VN.GGA02C00	v41
																		 WHERE	v41.ACC_ACT_CD	LIKE	DECODE(I_OPR_ACT_CD_03, '%', '%', I_OPR_ACT_CD_03)
																	UNION ALL
																		SELECT	v41.ACC_ACT_CD		AS	ACC_ACT_CD,
																				v41.ACT_UNIT_TP		AS	ACT_UNIT_TP
																		  FROM	VN.GGA02C00	v41
																		 WHERE	v41.ACC_ACT_CD	LIKE	DECODE(I_OPR_ACT_CD_04, '%', '%', I_OPR_ACT_CD_04)
																	UNION ALL
																		SELECT	v41.ACC_ACT_CD		AS	ACC_ACT_CD,
																				v41.ACT_UNIT_TP		AS	ACT_UNIT_TP
																		  FROM	VN.GGA02C00	v41
																		 WHERE	v41.ACC_ACT_CD	LIKE	DECODE(I_OPR_ACT_CD_05, '%', '%', I_OPR_ACT_CD_05)
																	UNION ALL
																		SELECT	v41.ACC_ACT_CD		AS	ACC_ACT_CD,
																				v41.ACT_UNIT_TP		AS	ACT_UNIT_TP
																		  FROM	VN.GGA02C00	v41
																		 WHERE	v41.ACC_ACT_CD	LIKE	DECODE(I_OPR_ACT_CD_06, '%', '%', I_OPR_ACT_CD_06)
																	)			v32
															 WHERE	v32.ACC_ACT_CD	=	DECODE(v32.ACT_UNIT_TP,
																							'1', v31.LVL1_CD, '2', v31.LVL2_CD,
																							'3', v31.LVL3_CD, '4', v31.LVL4_CD,
																							'5', v31.LVL5_CD, v31.ACC_ACT_CD)
															   AND	NVL(v31.SLIP_OCUR_YN, 'N')	=	'Y'
														)
					  GROUP BY	v21.ACC_ACT_CD,
								v21.OPR_ACC_ACT_CD
					)			v11 ;

            IF  I_OBJ_CAL_LOC  =   '1' THEN
                T_AMT := T_DR_SUM_AMT;
                /* T_AMT := T_DR_SUM_AMT - T_CR_SUM_AMT; */
            ELSE
                T_AMT := T_CR_SUM_AMT;
                /* T_AMT := T_CR_SUM_AMT - T_DR_SUM_AMT; */
            END IF;

        EXCEPTION WHEN  NO_DATA_FOUND THEN
            T_AMT := 0;
        END;

        IF  I_CAL_LOC   =   '1' THEN
            O_DR_AMT := T_AMT;
        ELSE
            O_CR_AMT := T_AMT;
        END IF;

    END;

BEGIN

    /* 0. 회사전체 */
    BEGIN
    	SELECT	A.COL_CD_TP		AS	COL_CD_TP
    	  INTO	K_ALL_BRCH
    	  FROM	VN.XCC01C01 A
         WHERE	A.COL_CD	=	'cmp_full_cd'
    	   AND	ROWNUM	<=	1 ;

    EXCEPTION WHEN OTHERS THEN
        K_ALL_BRCH := '000';
    END;

    -- 1) 기존자료 삭제
    DELETE
      FROM  VN.GGA12T00
     WHERE  WORK_TRM    =   I_WORK_TRM
       AND  BRCH_CD     =   I_BRCH_CD
       AND  AGNC_BRCH   =   I_AGNC_BRCH
       AND  FS_TP       =   I_FS_TP
       AND  TERMS_TP    =   I_TERMS_TP ;

    -- 2) 작업순서, 항목순서별로 항목 도출
    FOR C1 IN
        (   SELECT  a.FS_TP         AS  FS_TP,
                    a.FS_IDX        AS  FS_IDX,
                    a.FS_ITEM       AS  FS_ITEM,
                    a.PRT_YN        AS  PRT_YN,
                    a.UDLN_YN       AS  UDLN_YN
              FROM  VN.GGA05C00 a              /* 재무제표마스터 */
             WHERE  a.FRM_NO	=	I_FRM_NO
               AND	a.FS_TP     =   I_FS_TP    /* 손익계산서 */
          ORDER BY  a.WORK_SN,
                    a.FS_IDX
        ) LOOP

        -- 2_1) 금액항목 초기화
        T_DR_AMT_S := 0;
        T_CR_AMT_S := 0;

        -- 2_2) 작업순서, 항목순서별로 항목 도출
        FOR C2 IN
            (   SELECT  b.FS_TP         AS  FS_TP,
                        b.FS_IDX        AS  FS_IDX,
                        b.FS_SN         AS  FS_SN,
                        b.CAL_LOC       AS  CAL_LOC,
                        b.CAL_TP        AS  CAL_TP,
                        b.CAL_SIG       AS  CAL_SIG,
                        b.ACC_ACT_CD    AS  ACC_ACT_CD,
                        b.CAL_FS_IDX    AS  CAL_FS_IDX,
                        b.OBJ_CAL_LOC   AS  OBJ_CAL_LOC,
                        b.CONST         AS  CONST,
                        NVL(b.OPR_ACT_CD_01, '%') AS  OPR_ACT_CD_01,
                        NVL(b.OPR_ACT_CD_02, 'X') AS  OPR_ACT_CD_02,
                        NVL(b.OPR_ACT_CD_03, 'X') AS  OPR_ACT_CD_03,
                        NVL(b.OPR_ACT_CD_04, 'X') AS  OPR_ACT_CD_04,
                        NVL(b.OPR_ACT_CD_05, 'X') AS  OPR_ACT_CD_05,
                        NVL(b.OPR_ACT_CD_06, 'X') AS  OPR_ACT_CD_06
                  FROM  VN.GGA05C01 b   /* 재무제표양식상세 */
                 WHERE  b.FRM_NO    =   I_FRM_NO
                   AND  b.FS_TP     =   C1.FS_TP
                   AND  b.FS_IDX    =   C1.FS_IDX
              ORDER BY  b.CAL_LOC,
                        b.FS_SN
            ) LOOP

            -- 2_2_1) 금액항목 초기화
            T_DR_AMT := 0;
            T_CR_AMT := 0;

            -- 2_2_2) 연산유형 처리
            IF  C2.CAL_TP   =   '1' THEN        -- 원시자료

                GET_SORC_DATA(C2.CAL_LOC,       -- 연산장소
                              C2.OBJ_CAL_LOC,   -- 차/대
                              C2.ACC_ACT_CD,    -- 회계계정코드
                              C2.OPR_ACT_CD_01, -- 상대계정코드01
                              C2.OPR_ACT_CD_02, -- 상대계정코드02
                              C2.OPR_ACT_CD_03, -- 상대계정코드03
                              C2.OPR_ACT_CD_04, -- 상대계정코드04
                              C2.OPR_ACT_CD_05, -- 상대계정코드05
                              C2.OPR_ACT_CD_06, -- 상대계정코드06
                              T_DR_AMT,         -- 차변금액
                              T_CR_AMT) ;       -- 대변금액

            ELSIF   C2.CAL_TP   =   '2' THEN    -- 계산자료

                FOR C3 IN
                    (   SELECT  DECODE(C2.OBJ_CAL_LOC,
                                    '1', NVL(SUM(a.DR_AMT), 0),
                                    '2', NVL(SUM(a.CR_AMT), 0))  AS  AMT
                          FROM  VN.GGA12T00 a   -- 재무제표출력용
                         WHERE  a.WORK_TRM  =   I_WORK_TRM
                           AND  a.BRCH_CD   =   I_BRCH_CD
                           AND  a.AGNC_BRCH =   I_AGNC_BRCH
                           AND  a.FRM_NO    =   I_FRM_NO
                           AND  a.FS_TP     =   C2.FS_TP
                           AND  a.FS_IDX    =   C2.CAL_FS_IDX
                           AND  a.TERMS_TP  =   I_TERMS_TP
                    ) LOOP
                    IF  C2.CAL_LOC  =   '1' THEN
                        T_DR_AMT := C3.AMT;
                    ELSE
                        T_CR_AMT := C3.AMT;
                    END IF;
                END LOOP;   -- C3 End Loop

            ELSIF   C2.CAL_TP   =   '3' THEN    -- 상수
                IF  C2.CAL_LOC  =   '1' THEN
                    T_DR_AMT := C2.CONST;
                    T_CR_AMT := 0;
                ELSE
                    T_DR_AMT := 0;
                    T_CR_AMT := C2.CONST;
                END IF;
            ELSIF   C2.CAL_TP   =   '4' THEN    -- 별도
                NULL;
            END IF;

            -- 2_2_3) 연산부호 처리
            IF  C2.CAL_SIG  =   '2' THEN        -- -
                T_DR_AMT_S := T_DR_AMT_S - T_DR_AMT;
                T_CR_AMT_S := T_CR_AMT_S - T_CR_AMT;
            ELSIF   C2.CAL_SIG  =   '3' THEN    -- *
                T_DR_AMT_S := T_DR_AMT_S * T_DR_AMT;
                T_CR_AMT_S := T_CR_AMT_S * T_CR_AMT;
            ELSIF   C2.CAL_SIG  =   '4' THEN    -- /
                T_DR_AMT_S := T_DR_AMT_S / T_DR_AMT;
                T_CR_AMT_S := T_CR_AMT_S / T_CR_AMT;
            ELSIF   C2.CAL_SIG  =   '5' THEN    -- !
                T_DR_AMT_S := GREATEST(T_DR_AMT_S - T_DR_AMT, 0);
                T_CR_AMT_S := GREATEST(T_CR_AMT_S - T_CR_AMT, 0);
            ELSE                                -- +
                T_DR_AMT_S := T_DR_AMT_S + T_DR_AMT;
                T_CR_AMT_S := T_CR_AMT_S + T_CR_AMT;
            END IF;

        END LOOP;   -- C2 End Loop

        -- 2_3) 재무제표양식출력용 자료 생성(손익계산서)
        --IF  C1.PRT_YN   =   'Y' THEN        -- 출력여부
            INSERT
              INTO  VN.GGA12T00(
                    WORK_TRM,
                    BRCH_CD,
                    AGNC_BRCH,
                    FRM_NO,
                    FS_TP,
                    FS_IDX,
                    TERMS_TP,
                    DR_AMT,
                    CR_AMT,
                    WORK_MN,
                    WORK_DTM )
            VALUES  (I_WORK_TRM,
                    I_BRCH_CD,
                    I_AGNC_BRCH,
                    I_FRM_NO,
                    C1.FS_TP,
                    C1.FS_IDX,
                    I_TERMS_TP,
                    T_DR_AMT_S,
                    T_CR_AMT_S,
                    I_WORK_MN,
                    SYSDATE );
        --END IF;

    END LOOP;   -- C1 End Loop

EXCEPTION WHEN OTHERS THEN
  	RAISE_APPLICATION_ERROR(-20100,'P:'||SUBSTR(SQLERRM, 5, 78));
END PGG_REP_CA_SUB;
/

