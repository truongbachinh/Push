create function    fbm_get_sales_cls_dt(
    i_tp        varchar2,       -- '1': Ngay chot hoa hong ky hien tai   '2': Ngay chot hoa hong ky truoc
    i_proc_dt   varchar2
)
return varchar2

as
    t_proc_nm                   varchar2(30)    := 'fbm_get_sales_cls_dt';
    t_vwdate                    varchar2(8)     := vn.vwdate;
    t_err_msg                   varchar2(500)   := ' ';

    t_prev_cls_dt               varchar2(10);
    t_next_cls_dt               varchar2(10);

    o_ret                       varchar2(10)    := vn.vwdate;
begin
    if (i_tp = '1') then
        begin
            vn.pbm_get_sales_cls_dt (
                i_proc_dt,      -- i_proc_dt           in varchar2,
                t_prev_cls_dt,  -- o_prev_cls_dt       out varchar2,
                t_next_cls_dt   -- o_next_cls_dt       out varchar2
            );
        exception
            when others then
                t_err_msg  := 'Error when calling pbm_get_sales_cls_dt: ' || sqlcode || ' - ' || sqlerrm;
                raise_application_error(-20100,t_err_msg);
                vn.pxc_log_write(t_proc_nm, t_err_msg);
        end;

        o_ret := t_next_cls_dt;
        return o_ret;
    elsif (i_tp = '2') then
        begin
            vn.pbm_get_sales_cls_dt (
                i_proc_dt,      -- i_proc_dt           in varchar2,
                t_prev_cls_dt,  -- o_prev_cls_dt       out varchar2,
                t_next_cls_dt   -- o_next_cls_dt       out varchar2
            );
        exception
            when others then
                t_err_msg  := 'Error when calling pbm_get_sales_cls_dt: ' || sqlcode || ' - ' || sqlerrm;
                raise_application_error(-20100,t_err_msg);
                vn.pxc_log_write(t_proc_nm, t_err_msg);
        end;

        o_ret := t_prev_cls_dt;
        return o_ret;
    end if;

end fbm_get_sales_cls_dt;
/

